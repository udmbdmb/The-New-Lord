'use strict';
/* THE NEW LORD — "The Shoebox": Agnes Lark's letters to Absalom Vane, 1924–1961, read one at a time, with him listening */
NL.Script.add(String.raw`
# lt.0 arc=tenant night=4,5 label="Open the shoebox. Read one of Agnes's letters." if=has:agnesletters&!flag:lettersReturned&!flag:lt8 prio=2
@focus tenant
tenant: The shoebox. You want to read them. To me.
tenant: ...Go on. One. Not all of them. I couldn't bear all of them.
@gate flag:lt1 ? lt.b2 : lt.1

# lt.b2
@gate flag:lt2 ? lt.b3 : lt.2

# lt.b3
@gate flag:lt3 ? lt.b4 : lt.3

# lt.b4
@gate flag:lt4 ? lt.b5 : lt.4

# lt.b5
@gate flag:lt5 ? lt.b6 : lt.5

# lt.b6
@gate flag:lt6 ? lt.b7 : lt.6

# lt.b7
@gate flag:lt7 ? lt.8 : lt.7

# lt.1
> The first one. Thin blue paper, folded in three, in a typist's neat hand. *December 1924.*
> *"Mr. Vane. You owe the Courthouse one drawer, oak, with lock. I have filled in the form. Please sign at the X and return it to me by hand, as the post is unreliable and so, I suspect, are you.*
> *I enjoyed our tea. I am told by my mother that one should not say so in a first letter. My mother has never had tea with anyone interesting. — A. Lark."*
> Underneath, in a different ink, very small: *P.S. Your car is still smug.*
tenant: She kept a carbon. Of course she did. She was a typist. She kept a carbon of her first letter to me.
* "You signed at the X."  -> lt.1a
* "Did you return it by hand?"  -> lt.1b

# lt.1a
tenant: I signed at the X. I'd never signed for anything I broke in a hundred and sixty years. It felt like confession.
{do flag:lt1=1; sync+1}
@end

# lt.1b
tenant: By hand. On the twenty-sixth. I waited by the side door in the snow for three hours until her shift ended. She said "you could have just left it on the desk." I said I didn't trust the desk.
{do flag:lt1=1; sync+1}
@end

# lt.2
> *March 1926.*
> *"A. — You asked me last night if I was afraid. I said no. I want to correct the record, as I always correct the record: I was terrified. For about a minute. Then I thought: well, he's been perfectly polite for two years, and he's never once bitten anyone in the filing room, which is more than I can say for Mr. Harbottle.*
> *"Does it hurt? You didn't answer. You looked at me as if nobody had asked. I'll ask again next time. I'll keep asking until you answer. — A."*
tenant: She kept asking. Every letter, for a year. "Does it hurt?" At the bottom, like a postscript. I never answered.
* "Does it?"  -> lt.2a
* "Why didn't you answer her?"  -> lt.2b

# lt.2a
> A very long silence.
tenant: ...Yes. All the time. A little. Like a tooth. You stop noticing. You never stop feeling it.
tenant: There. Ninety-nine years late. I've answered.
{do flag:lt2=1; sync+2; comp+1}
@end

# lt.2b
tenant: Because the answer was yes, and I thought if I said yes she'd pity me. I'd have rather been feared than pitied. I was a fool. She'd have done neither. She'd have made me a cup of tea.
{do flag:lt2=1; sync+1}
@end

# lt.3
> *June 1931.*
> *"A. — I'm marrying Albert Dunmore on Saturday. You knew I would. I knew you knew. You never said a word against him, which is either very gentlemanly or very cowardly, and I think with you it's both.*
> *"He's kind. He's alive. He'll grow old with me. You'd grow old with no one. I think you'd like him, if you ever let yourself meet anyone in daylight, which you can't, which is rather the point.*
> *"I'll still write. If you'll still read. Albert says I may. Albert says he'd rather I wrote to a vampire than took up golf. — A."*
tenant: "Rather a vampire than golf." Albert. I never met him. I sent a clock for the wedding. It was too expensive. She sent it back with a note: "Something less smug, please."
* "Were you jealous?"  -> lt.3a
* "That's a kind man."  -> lt.3b

# lt.3a
tenant: Of a man who could stand next to her at noon? Every day for thirty years. Every single day.
{do flag:lt3=1; sync+1}
@end

# lt.3b
tenant: He was. He was. I hated him for it for about a decade and then I didn't. You can't hate someone who makes the person you love that happy. You can only be grateful, and stay out of the photographs.
{do flag:lt3=1; sync+1; comp+1}
@end

# lt.4
> *September 1939.*
> *"A. — They're saying war. Albert's too old, thank God, and his eyes are bad, thank God twice. But the boys from the Courthouse are going. Young Harbottle. The Murphy twins. I typed their papers.*
> *"Will you go? Can your sort go? I imagine you'd be very useful at night. I imagine you'd hate the uniform.*
> *"Don't go. That's not a request. I can't afford to lose two people who matter to me, and Albert's not going anywhere, so it would have to be you. — A."*
tenant: I didn't go. I stayed. I was the Sheriff. Somebody had to keep the Ward while the city was blacked out and the Court was terrified of the bombers.
tenant: I told myself that. I stayed because she told me not to go. That's the truth. Eighty years and I've never told anyone that.
{do flag:lt4=1; sync+2}
@end

# lt.5
> *December 1946.*
> *"A. — Twenty-two years. You've never once missed the twenty-third. Even in the war, even the year of the flood, a card under my door at four in the morning with nothing on it but a drawing of a car. A smug car.*
> *"I worked out this year that I'm going to die before you. I worked it out in the bath. Obviously I knew. But I worked it out. I'm forty-three and you're whatever you are, and one day you'll be sending a card to an empty house.*
> *"Don't. When I'm gone, stop. Promise me. Go to a party. Throw a snowball at someone. — A."*
tenant: I didn't stop. I sent the card every year until 1961. And then I went to the chapel at St. Jude's every December twenty-third until this year and sat at the back.
tenant: I broke the only promise she ever asked me to make.
* "You kept her, instead."  -> lt.5a
* "She'd have forgiven you."  -> lt.5b

# lt.5a
tenant: Kept her. In a chapel. In the dark. Where she'd have hated to be. Yes. That's exactly what I did.
{do flag:lt5=1; sync+1}
@end

# lt.5b
tenant: She would. She'd have been furious first. Then she'd have forgiven me. Then she'd have made me go to a party.
{do flag:lt5=1; sync+1; comp+1}
@end

# lt.6
> *May 1955.*
> *"A. — Albert and I took the train to the coast on Sunday. Saltmarsh. You've never been. You never go anywhere. The harbour was the color of a pigeon's neck: grey, and then green when the light moved, and then purple where the boats were.*
> *"There's a house on the front with a fish painted on the gatepost. Badly. A child did it, you could tell, it had too many fins. I stood and looked at it for ten minutes and Albert said 'what is it, Aggie?' and I said 'I'm memorizing it for someone who can't come.'*
> *"So here it is: a fish with too many fins, on a gatepost, in the sun. Now you've seen it. — A."*
> Something goes through you, cold and bright, like a dropped glass.
nostalgia(8): Saltmarsh. A fish on a gatepost. A child's drawing with too many fins. A house on the front. The same seafront. The same harbour. Robin. Robin's mailbox. You drew it when you were nine because there was one already, faded, on the house next door, and you wanted one too.
tenant: ...Saltmarsh. Your Saltmarsh. Your sister's street.
tenant: She stood in front of the house next door to yours, in 1955, and memorized a fish, for me.
{do flag:lt6=1; sync+2; comp+2:A fish with too many fins}
@end

# lt.7
> *November 1961.*
> The handwriting has changed. It's shaky. It slopes off the line.
> *"A. — They've given me a room with a window that looks at the cemetery. Albert says it's tactless. I say it's convenient.*
> *"I've been thinking about your question, the one you never asked. You always wanted to know if I minded. What you are. Whether it frightened me, having a friend who couldn't come to lunch.*
> *"It didn't. Not once. Thirty-seven years. The only thing that frightened me was that you'd stop writing. You didn't. You're the most reliable man I ever knew, and you've been dead the whole time.*
> *"Come and see me. Before. At night. I know you won't. Come anyway. — A."*
tenant: I didn't go.
tenant: I stood outside the nursing home for three nights. I couldn't go in. I couldn't let her see me unchanged when she was... I couldn't.
tenant: She asked me to come, and I stood in the parking lot.
* "You couldn't have told her anything. You don't know what it's like."  -> lt.7a
* "You were a coward."  -> lt.7b {do lean:candour+1}
* Say nothing.  -> lt.7c

# lt.7a
tenant: No. I didn't know. I still don't. But I could have held her hand while she found out. That was all she wanted. Company. At the door.
{do flag:lt7=1; sync+1}
@end

# lt.7b
tenant: Yes. I was. Thank you. Nobody's ever said it. I've been waiting sixty-four years for someone to say it out loud.
{do flag:lt7=1; sync+2; comp+1}
@end

# lt.7c
> You don't say anything. Neither does he. You sit together, wherever you are, with the letter in your hands, for a long time.
{do flag:lt7=1; comp+1}
@end

# lt.8
> The last one. It isn't from Agnes. It's on cheap white paper, in a man's careful hand, dated January 1962.
> *"Dear Mr. Vane. I found your letters in her desk. All of them, in a shoebox, in order. I didn't read them. I want you to know that. I think they were yours, not mine.*
> *"She talked about you at the end. She said you'd be standing in the parking lot. She said 'don't go out to him, Albert, he'll only bolt.' She was right, I looked out of the window and there you were, under the lamp, in the snow, like a man waiting for a bus that wasn't coming.*
> *"She said to tell you it's only warm. I've told you. That's all. I'm returning the box. — Albert Dunmore."*
> The shoebox has never been opened at the bottom. This letter was under the lining. He never knew it was there.
tenant: ...
tenant: He knew. Albert knew. He watched me from the window. He let me stand there. He let me have it, the standing.
tenant: Sixty-four years, and the man I was jealous of was the kindest of all of us.
{do flag:lt8=1; sync+3; comp+3:Albert; xp:40:The Shoebox}
@end
`,'c_letters');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];if(f.lt8)o.push(['Albert Dunmore','Died in 1977, in Saltmarsh, in a house near the front, two doors down from a gatepost with a fish on it. His letter was under the lining of a shoebox for sixty-four years. Somebody finally read it.']);return o;});
