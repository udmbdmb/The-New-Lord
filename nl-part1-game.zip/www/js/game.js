'use strict';
/* THE NEW LORD — core: state, dialogue, checks, encounters, exploration, cutscenes, panels, save */
(function(){
const NL=window.NL,A=NL.Audio;
const $=(s,r)=>(r||document).querySelector(s);
const h=(tag,cls,html)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e;};
const esc=s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const SAVE_KEY='newlord.campaign.v1';

/* ================= STATE ================= */
function newState(){return {v:2,room:'freezer',pos:null,time:0,tt:0,night:1,vitae:3,comp:7,heat:0,xp:0,lvl:0,pts:0,cash:0,sync:10,texts:[],mut:{},sig:null,promises:{},kills:0,feeds:0,lethal:{},quests:{},
  attrs:{sanguine:2,masquerade:2,nocturne:2,cadaver:2},spent:{},past:null,clan:null,look:{skin:0,hair:0,hairCol:1},
  inv:{},eq:{},th:{known:[],slots:[null,null,null],done:[]},hav:null,flags:{},checks:{},seen:{},once:{},rel:{},dos:{},tasks:{},stats:{checks:0,pushes:0,fails:0},chapter:'cold'};}
let S=newState();
const G={get S(){return S;}};NL.G=G;
G.settings={speed:1,motion:true,quality:-1,advance:'tap',hints:true,tapText:false};
G.hint=k=>{try{NL.Help&&NL.Help.hint(k);}catch(e){}};
try{const st=JSON.parse(localStorage.getItem('newlord.settings')||'null');if(st)Object.assign(G.settings,st);}catch(e){}
function applyQuality(){const q=G.settings.quality<0?(window.innerWidth<900?1:0):G.settings.quality;NL.renderScale=[1,.75,.5][q]||1;}
applyQuality();
function saveSettings(){try{localStorage.setItem('newlord.settings',JSON.stringify(G.settings));}catch(e){}}

/* ================= DERIVED ================= */
G.hunger=()=>{const t=S.clan==='hounds'?5:4;return S.vitae<t?Math.min(4,t-S.vitae):0;};
G.clan=()=>S.clan?NL.CLANS[S.clan]:null;
G.hasAb=(id,t2)=>!!(S.clan&&NL.CLANS[S.clan].ab[id])&&(!t2||!!S.mut[id]);
G.vitMax=()=>clamp(5+S.attrs.cadaver,6,10);
G.thought=id=>S.th.done.includes(id);
G.mortals=new Set(['leo','miller','tariq','tiny','gideon','rostova','harrow','margo','pemberton']);
G.compMax=()=>{let m=5+S.attrs.masquerade+(S.flags.trueName?2:0);S.th.done.forEach(t=>{m+=NL.THOUGHTS[t].compMax||0;});return clamp(m,3,12);};
function modsFrom(){const m={};const add=(o,k)=>{if(!o)return;for(const s in o)m[s]=(m[s]||0)+o[s]*(k||1);};
  for(const sl in S.eq){const it=S.eq[sl];if(it)add(NL.ITEMS[it].mods,sl==='pocket'&&G.thought('relic')?2:1);}
  if(S.past&&NL.PASTS[S.past])add(NL.PASTS[S.past].skill);if(S.sig)m[S.sig]=(m[S.sig]||0)+1;
  if(S.inv.vessel||G.equipped('vessel')){m.sundial=(m.sundial||0)-1;m.apex=(m.apex||0)+2;}
  if(S.flags.harmonized){m.pedigree=(m.pedigree||0)+1;m.web=(m.web||0)+1;}
  if(S.shatter&&S.tt<S.shatter.until)m[S.shatter.sk]=(m[S.shatter.sk]||0)+3;
  const R=NL.ROOMS&&NL.ROOMS[S.room];
  if(R&&S.clan==='choir'&&R.art&&!S.flags['admired_'+S.room])NL.SKILL_ORDER.nocturne.forEach(k=>m[k]=(m[k]||0)-2);
  if(R&&S.clan==='wraiths'&&R.bright&&!(S.eq.face&&NL.ITEMS[S.eq.face].cover)){m.stagecraft=(m.stagecraft||0)-4;m.velvet=(m.velvet||0)-2;}
  if(R&&S.clan==='stray'&&R.elysium)NL.SKILL_ORDER.masquerade.concat(['pedigree']).forEach(k=>m[k]=(m[k]||0)-2);
  if(S.clan==='butchers'&&G.uncanny)NL.SKILL_ORDER.masquerade.forEach(k=>m[k]=(m[k]||0)-1);
  if(S.flags.scav&&S.flags.scav===S.night)m.rigor=(m.rigor||0)+1;
  S.th.done.forEach(t=>add(NL.THOUGHTS[t].done));S.th.slots.forEach(sl=>{if(sl)add(NL.THOUGHTS[sl.id].during);});return m;}
const RES={choleric:{n:'Choleric',d:'Angry blood. Sanguine skills +1, Pulse-Check −1.',c:'#e0563c',m:sk=>(NL.SKILLS[sk].attr==='sanguine'?1:0)-(sk==='pulse'?1:0)},
  melancholic:{n:'Melancholic',d:'Frightened or grieving blood. Cadaver skills and Nostalgia +1, Apex −1.',c:'#6f8fd8',m:sk=>(NL.SKILLS[sk].attr==='cadaver'||sk==='nostalgia'?1:0)-(sk==='apex'?1:0)},
  sanguine:{n:'Sanguine',d:'Giddy, high blood. Masquerade skills +1.',c:'#e06fb0',m:sk=>NL.SKILLS[sk].attr==='masquerade'?1:0},
  phlegmatic:{n:'Phlegmatic',d:'Calm, slow blood. Nocturne skills and Autopsy +1.',c:'#7fc3b1',m:sk=>NL.SKILLS[sk].attr==='nocturne'||sk==='autopsy'?1:0}};
NL.RES=RES;
G.feed=(n,type,src,o)=>{o=o||{};S.feeds++;S.lastFeed=o.kind||'mortal';
  if(S.clan==='sovereign'&&(o.kind==='bag'||o.kind==='rat'||o.kind==='gutter')){G.comp(-2,'Rarefied Palate: you vomit it back up');return;}
  if(S.clan==='rot'&&o.kind==='mortal'&&!o.sick)n=Math.ceil(n/2);
  if(S.clan==='stray'&&o.kind==='rat'&&S.flags.scavNow){n=G.vitMax();S.flags.scav=S.night;}
  G.vitae(n);if(o.kill){S.kills++;S.lethal[S.night]=(S.lethal[S.night]||0)+1;}if(!type)return;if(type==='melancholic'&&G.thought('grief'))G.comp(2,'Grief Eater');const r=RES[type];const was=S.res&&S.res.type;S.res={type,src:src||''};
  setTimeout(()=>{toast('res',`<b>${r.n}</b>${src?' · '+esc(src):''}`,was&&was!==type?'Resonance changed':'Blood resonance');G.hint('resonance');},700);refreshHUD();};
G.skillParts=id=>{const sk=NL.SKILLS[id],rs=S.res&&RES[S.res.type]?RES[S.res.type].m(id)*(G.thought('hedonist')?2:1):0,base=S.attrs[sk.attr],sp=S.spent[id]||0,cl=S.clan?(NL.CLANS[S.clan].mods[id]||0):0,ex=modsFrom()[id]||0,hu0=(sk.attr==='sanguine'&&G.hunger()>0&&id!=='osmosis')?Math.min(4,1+G.hunger()):(sk.attr==='masquerade'&&S.vitae<=2&&S.flags.woke)?-1:0,hu=G.equipped('walkman')&&hu0>0?Math.ceil(hu0/2):hu0;
  if(S.th.done.some(t=>(NL.THOUGHTS[t].zero||[]).includes(id)))return {base,sp,cl,ex,hu,rs,zero:true,total:0};
  return {base,sp,cl,ex,hu,rs,total:Math.max(0,base+sp+cl+ex+hu+rs)};};
G.skillCap=id=>{const at=NL.SKILLS[id].attr;return S.attrs[at]+(S.sig&&NL.SKILLS[S.sig].attr===at?1:0);};
G.skill=id=>G.skillParts(id).total;
G.chance=(sk,dc)=>{const need=dc-G.skill(sk);let ok=0;for(let a=1;a<=6;a++)for(let b=1;b<=6;b++){if(a===6&&b===6){ok++;continue;}if(a===1&&b===1)continue;if(a+b>=need)ok++;}return ok/36;};
G.has=(id,n)=>id==='cash'?(S.cash||0)>=(n||1):(S.inv[id]||0)>=(n||1)||Object.values(S.eq).includes(id);
G.equipped=id=>Object.values(S.eq).includes(id);

/* ================= MUTATORS ================= */
G.flag=(k,v)=>{if(v===undefined)return S.flags[k];S.flags[k]=v;};
G.cash=(n,why)=>{if(n>0&&G.thought('capitalism'))n*=2;S.cash=Math.max(0,(S.cash||0)+n);toast(n>=0?'item':'hurt',`${n>=0?'+':'−'}$${Math.abs(n)}`,why||(n>=0?'Cash':'Paid'));A.sfx(n>=0?'item':'click');refreshHUD();};
G.give=(id,n)=>{n=n||1;if(id==='cash'){G.cash(212,'Register cash');return;}S.inv[id]=(S.inv[id]||0)+n;const it=NL.ITEMS[id];toast('item',`<b>${esc(it.n)}</b>${n>1?' ×'+n:''}`,'Item acquired');if(it.slot)G.hint('wardrobe');A.sfx('item');refreshHUD();};
G.take=(id,n)=>{n=n||1;if(id==='cash'){G.cash(-Math.min(S.cash||0,n>1?n:212));return;}if(S.inv[id]){S.inv[id]-=n;if(S.inv[id]<=0)delete S.inv[id];}else{for(const sl in S.eq)if(S.eq[sl]===id){delete S.eq[sl];updatePlayerLook();break;}}refreshHUD();};
G.vitae=(d,quiet,lethal)=>{const before=S.vitae;S.vitae=clamp(S.vitae+d,(d<0&&!lethal)?Math.min(1,before):0,G.vitMax());if(!quiet&&d)toast(d>0?'vitae':'hurt',`${d>0?'+':''}${d} Vitae`,d>0?'Blood':'Blood spent');if(d>0)A.sfx('drink');refreshHUD();
  if(S.vitae===0&&before>0)setTimeout(()=>gameOver('torpor'),900);};
G.comp=(d,why)=>{const mx=G.compMax();S.comp=clamp(S.comp+d,0,mx);if(d<0){A.sfx('hurt');Wd.world&&(Wd.world.hurt=.8,Wd.world.shake=Math.max(Wd.world.shake,.7));G.hint('mask');toast('hurt',`${d} Composure`,why||'The Mask slips');}
  else if(d>0)toast('comp',`+${d} Composure`,why||'Steadier');refreshHUD();if(S.comp<=0&&d<0)G.pendingBreach=true;};
G.heat=(d)=>{S.heat=clamp(S.heat+d,0,5);if(d>0){toast('heat',`Heat +${d}`,'Mortals are paying attention');G.hint('heat');}refreshHUD();};
G.xp=(n,why)=>{S.xp+=n;toast('xp',`+${n} XP`,why||'');A.sfx('xp');while(S.xp>=(S.lvl+1)*100){S.lvl++;S.pts++;setTimeout(()=>{toast('level','Level up · +1 skill point','Open your character sheet to spend it');A.sfx('level');G.hint('level');},500);}refreshHUD();};
G.rel=(id,d)=>{S.rel[id]=clamp((S.rel[id]||0)+d,-3,3);const c=NL.CHARS[id]||(NL.EXTRAS&&NL.EXTRAS[id])||{n:id};toast('rel',`${esc(c.n)}: ${NL.relName(S.rel[id])} ${d>0?'▲':'▼'}`,'Relationship');};
G.meet=id=>{if(S.dos[id])return;S.dos[id]={facts:[]};if(S.rel[id]==null)S.rel[id]=0;toast('dos',`New dossier: <b>${esc(NL.CHARS[id].n)}</b>`,'Journal');G.hint('dossier');};
G.fact=(id,k)=>{G.meet(id);if(S.dos[id].facts.includes(k))return;S.dos[id].facts.push(k);toast('dos',`${esc(NL.CHARS[id].n)}`,'Dossier updated');};
G.task=(id,st)=>{const t=NL.TASKS[id];if(!t){console.warn('task?',id);return;}if(st==='done'){if(!S.tasks[id]||S.tasks[id]==='done')S.tasks[id]=S.tasks[id]||'active';if(S.tasks[id]==='done')return;S.tasks[id]='done';toast('task',`<s>${esc(t.n)}</s>`,'Task complete');if(t.xp)G.xp(t.xp,'Task complete');}
  else{if(S.tasks[id])return;S.tasks[id]='active';toast('task',esc(t.n),'New task');A.sfx('page');}};
G.offer=id=>{if(!NL.THOUGHTS[id]){console.warn('thought?',id);return;}if(S.th.known.includes(id)||S.th.done.includes(id)||S.th.slots.some(s=>s&&s.id===id))return;S.th.known.push(id);G.hint('thought');toast('thought',`<b>${esc(NL.THOUGHTS[id].n)}</b>`,'New thought · open the Thought Cabinet');A.sfx('thought');pulseBtn('thoughts');};
G.tick=min=>{S.time+=min;S.tt+=min;for(let i=0;i<S.th.slots.length;i++){const sl=S.th.slots[i];if(!sl)continue;const T=NL.THOUGHTS[sl.id];if(S.tt-sl.start>=T.time){S.th.slots[i]=null;S.th.done.push(sl.id);if(T.compMax)S.comp=Math.min(G.compMax(),S.comp+T.compMax);thoughtDone(sl.id);}}refreshHUD();if(NL.Camp)NL.Camp.afterTick(min);};
G.once=(k)=>{if(S.once[k])return false;S.once[k]=1;return true;};
G.seen=k=>!!S.seen[k];
function thoughtDone(id){const T=NL.THOUGHTS[id];toast('thought',`<b>${esc(T.n)}</b> internalized`,'Thought Cabinet');A.sfx('thought');setTimeout(()=>showThoughtReveal(id),300);}

/* ================= TOASTS ================= */
const toastQ=[];let toastBusy=false;
const toastSeen=new Map();
function toast(kind,html,sub){const k=kind+'|'+html+'|'+(sub||''),now=performance.now();if(now-(toastSeen.get(k)||-1e9)<4000)return;toastSeen.set(k,now);toastQ.push({kind,html,sub});if(!toastBusy)nextToast();}
async function nextToast(){toastBusy=true;const box=$('#toasts');while(toastQ.length){const t=toastQ.shift();const e=h('div','toast t-'+t.kind,`<div class="tk">${esc(t.sub||'')}</div><div class="tv">${t.html}</div>`);box.appendChild(e);
  requestAnimationFrame(()=>e.classList.add('in'));setTimeout(()=>{e.classList.remove('in');e.classList.add('out');setTimeout(()=>e.remove(),500);},3200);await sleep(380);}toastBusy=false;}
function pulseBtn(id){const b=$(`#hud [data-p="${id}"]`);if(b){b.classList.remove('pulse');void b.offsetWidth;b.classList.add('pulse');}}

/* ================= HUD ================= */
const DAYS=['Mon','Tue','Wed','Thu','Fri'];G.DAYS=DAYS;
function clockStr(){const m=S.time+21*60,hh=Math.floor(m/60)%24,mm=m%60;return `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}`;}
G.clockStr=clockStr;
function refreshHUD(){
  const hud=$('#hud');if(!hud)return;
  $('#clk').textContent=clockStr();const ns=$('#hud .clock small');if(ns)ns.textContent=`Night ${S.night} of 5 · ${DAYS[S.night-1]||''}`;
  const toDawn=Math.max(0,8*60-S.time);$('#dawnIn').textContent=`Dawn in ${Math.floor(toDawn/60)}h ${String(toDawn%60).padStart(2,'0')}m`;
  $('#dawnArc').style.setProperty('--p',Math.min(1,S.time/(8*60)));
  const mx=G.compMax();let c='';for(let i=0;i<10;i++)c+=`<i class="${i<S.comp?'on':''} ${i>=mx?'cap':''}"></i>`;$('#compPips').innerHTML=c;
  const vm=G.vitMax();let v='';for(let i=0;i<10;i++)v+=`<i class="${i<S.vitae?'on':''} ${i>=vm?'cap':''}"></i>`;$('#vitPips').innerHTML=v;
  $('#compN').textContent=S.comp;$('#vitN').textContent=S.vitae;
  const rb=$('#res');if(rb){const r=S.res&&RES[S.res.type];rb.hidden=!r;if(r){rb.querySelector('b').textContent=r.n;rb.style.setProperty('--c',r.c);}}
  const hu=G.hunger();const hb=$('#hunger');hb.hidden=!hu;if(hu&&S.flags.woke)G.hint('hunger');hb.dataset.l=hu;hb.querySelector('b').textContent=['','Peckish','Hungry','Starving','Ravenous'][hu]||'';
  const ht=$('#heat');ht.hidden=!S.heat;ht.querySelector('b').textContent=S.heat;
  const pts=$('#ptsDot');if(pts)pts.hidden=!S.pts;
  $('#thDot').hidden=!S.th.known.length||S.th.slots.every(Boolean);
  if(Wd.world){Wd.world.hunger+=0;}
  A.heart(hu>=2?60+hu*12:0);
}
G.refresh=refreshHUD;

/* ================= PORTRAIT ================= */
let portrait=null,portraitId=null;const pCanvas=h('canvas','pcanvas');
function portraitInto(host,id,spec,o){if(!portrait){try{portrait=new NL.Portrait(pCanvas);}catch(e){return;}}if(pCanvas.parentNode!==host)host.appendChild(pCanvas);if(host.id!=='pcan')pCanvas.style.visibility='';
  if(id!==portraitId||o&&o.force){portrait.set(id,spec,o);portraitId=id;}portrait.mode=(o&&o.mode)||'head';if(o&&o.rim)portrait.rim=o.rim;if(o&&o.zoom)portrait.zoom=o.zoom;else portrait.zoom=1;}
function paintedInto(id){const host=$('#pcan');let im=host.querySelector('img.painted');const url=NL.PAINTED&&(NL.PAINTED[id]||NL.PAINTED[String(id).replace(/^x:/,'')]);
  $('#pframe').classList.toggle('painted',!!url);
  if(!url){if(im)im.hidden=true;if(pCanvas.parentNode===host)pCanvas.style.visibility='';return false;}
  if(!im){im=document.createElement('img');im.className='painted';im.alt='';host.appendChild(im);}
  if(im.getAttribute('src')!==url)im.src=url;im.hidden=false;if(pCanvas.parentNode===host)pCanvas.style.visibility='hidden';return true;}
G._paintedInto=paintedInto;
G._portraitInto=portraitInto;G._pCanvas=()=>pCanvas;
G.portraitSnapshot=(id,spec,o)=>{if(!portrait){try{portrait=new NL.Portrait(pCanvas);}catch(e){return '';}}const host=$('#snapHost');host.appendChild(pCanvas);portrait.set(id,spec,o);portraitId=id;portrait.render(.016,3);const url=pCanvas.toDataURL('image/png');portraitId=null;return url;};

/* ================= PLAYER LOOK ================= */
function playerSpec(forMirror){
  const L=NL.LOOKS,c=G.clan(),skin=L.skin[S.look.skin].slice();
  if(c&&c.grey){skin[0]=skin[0]*.7+.18;skin[1]=skin[1]*.72+.2;skin[2]=skin[2]*.7+.2;}
  const pale=[skin[0]*.86+.08,skin[1]*.86+.07,skin[2]*.86+.09];
  const spec={skin:pale,hair:{style:L.hair[S.look.hair],color:L.hairCol[S.look.hairCol]},eyes:c?c.eye:[.18,.12,.1],eyeGlow:[0,0,0],shirt:[.56,.53,.52],pants:[.17,.17,.2],shoes:[.08,.07,.07],tie:[.3,.05,.08],lips:[.42,.28,.3],scars:!!(c&&c.scars)};
  {const P_=NL.premadeFor&&S.clan&&S.gender?NL.premadeFor(S.clan,S.gender):null;if(P_&&P_.spec){const ps=JSON.parse(JSON.stringify(P_.spec));if(ps.face)spec.face=Object.assign({},spec.face||{},ps.face);delete ps.face;Object.assign(spec,ps);}else if(S.gender==='f')spec.fem=true;}
  /* before the mirror you don't know your own face: a plain, shadowed figure */
  if(!S.clan&&!forMirror){spec.skin=[.47,.44,.45];spec.hair={style:'crop',color:[.07,.06,.06]};spec.lips=[.36,.3,.31];spec.eyes=[.12,.1,.1];spec.fem=false;spec.face={jaw:1,nose:1,brow:1,cheek:1,chin:1,wide:1,long:1,noseW:1,lips:1,socket:1.1,crown:1,hollow:.2};spec.age=.3;}
  if(!forMirror)for(const sl in S.eq){const it=NL.ITEMS[S.eq[sl]];if(it&&it.look)Object.assign(spec,JSON.parse(JSON.stringify(it.look)));}
  if(forMirror)for(const sl in S.eq){const it=NL.ITEMS[S.eq[sl]];if(it&&it.look&&(it.look.coat||it.look.apron))Object.assign(spec,JSON.parse(JSON.stringify(it.look)));}
  return spec;}
G.playerSpec=playerSpec;
function updatePlayerLook(){if(Wd.player){Wd.player.rebuild(playerSpec());}if(portraitId==='you'&&portrait){portrait.set('you',playerSpec(),{mode:portrait.mode});}}
G.updateLook=updatePlayerLook;
function eyeGlowTick(){const p=Wd.player;if(!p)return;const c=G.clan(),hu=G.hunger();const k=c?(.25+hu*.2+(G.glowBoost||0)):0;const g=c?c.glow:[.6,.05,.05];
  for(const e of p.m.items){if(e.it.tag==='iris')e.it.emis=[g[0]*k,g[1]*k,g[2]*k];}}

/* ================= DIALOGUE UI ================= */
const D={open:false,fastTap:null,feed:null,opts:null};
function speakerInfo(s){
  if(!s||s==='narr')return {kind:'narr'};
  if(s==='you')return {kind:'you',name:'You'};
  if(NL.SKILLS[s]){const sk=NL.SKILLS[s];return {kind:'skill',name:sk.name,color:NL.ATTRS[sk.attr].color,glyph:NL.GLYPH[s],sk:s};}
  if(s==='tenant'){const named=S.flags.tenantNamed;return {kind:'char',id:'tenant',name:named?'The Tenant':'???',color:NL.CHARS.tenant.color,glyph:NL.GLYPH.tenant,tenant:true};}
  if(NL.CHARS[s])return {kind:'char',id:s,name:(S.dos[s]||s==='severine'&&S.flags.marchettiNamed||NL.CHARS[s].known)?NL.CHARS[s].n:(NL.STORY.unknownName&&NL.STORY.unknownName(s,S))||NL.CHARS[s].n,color:NL.CHARS[s].color};
  if(NL.EXTRAS&&NL.EXTRAS[s]){const X=NL.EXTRAS[s];return {kind:'char',id:'x:'+s,name:X.n,color:X.color||'#ccc',spec:X.spec};}
  return {kind:'char',name:s,color:'#ddd'};}
function setHeadFor(info){
  D.lastInfo=info;const head=$('#dlgHead'),pf=$('#pframe'),gl=$('#pglyph'),nm=$('#pname');pf.classList.remove('unknown');
  if(info.kind==='skill'&&NL.PAINTED&&NL.PAINTED['skill_'+info.sk]){pf.classList.remove('glyph');pf.style.setProperty('--c',info.color);paintedInto('skill_'+info.sk);nm.innerHTML=`<b style="color:${info.color}">${esc(info.name)}</b><span>${esc(NL.ATTRS[NL.SKILLS[info.sk].attr].name)}</span>`;return;}
  if(info.kind==='skill'||info.tenant&&!S.flags.tenantSeen){pf.classList.add('glyph');$('#pframe').classList.remove('painted');gl.innerHTML=`<svg viewBox="0 0 48 48">${info.glyph}</svg>`;pf.style.setProperty('--c',info.color);nm.innerHTML=`<b style="color:${info.color}">${esc(info.name)}</b><span>${info.kind==='skill'?esc(NL.ATTRS[NL.SKILLS[info.sk].attr].name):'A voice in the blood'}</span>`;return;}
  if(info.kind==='char'&&info.id){pf.classList.remove('glyph');const C=NL.CHARS[info.id]||{spec:info.spec,role:(NL.EXTRAS[info.id.slice(2)]||{}).role||''};
    if(G.mortals.has(info.id))D.mortalTalk=true;
    if(!paintedInto(info.id))portraitInto($('#pcan'),info.id,C.spec,{breathes:info.id!=='tenant'&&!(info.id==='severine'&&S.night===1&&!S.flags.metSeverine),rim:info.tenant?[.7,.5,1]:[.55,.32,.36]});
    pf.style.setProperty('--c',info.color);nm.innerHTML=`<b style="color:${info.color}">${esc(info.name)}</b><span>${esc(S.dos[info.id]||!NL.CHARS[info.id]?C.role||'':'')}</span>`;return;}
  if(info.kind==='you'&&!S.clan){pf.classList.add('glyph','unknown');pf.classList.remove('painted');pf.style.setProperty('--c','#c9d0dc');gl.innerHTML='<svg viewBox="0 0 48 48"><path d="M24 8a9 10 0 1 1 0 20a9 10 0 1 1 0-20z" stroke-dasharray="3 3"/><path d="M9 42c2-8 8-12 15-12s13 4 15 12" stroke-dasharray="3 3"/><path d="M21 15.5c0-2 1.4-3 3-3s3 1.2 3 3c0 2.4-3 2.6-3 5M24 23.5v.5"/></svg>';nm.innerHTML='<b>You</b><span>You don\'t know your own face yet</span>';return;}
  if(info.kind==='you'){pf.classList.remove('glyph');paintedInto('you');portraitInto($('#pcan'),'you',playerSpec(),{rim:[.6,.15,.2]});nm.innerHTML=`<b>You</b><span>${S.clan?esc(NL.CLANS[S.clan].name):'Whoever you are'}</span>`;}
}
function dlgShow(mode){const d=$('#dlg');d.hidden=false;d.dataset.mode=mode||'talk';requestAnimationFrame(()=>d.classList.add('in'));D.open=true;document.body.classList.add('talking');}
function dlgHide(){const d=$('#dlg');d.classList.remove('in');D.open=false;document.body.classList.remove('talking');setTimeout(()=>{if(!D.open){d.hidden=true;$('#feed').innerHTML='';}},350);$('#encBar').hidden=true;}
G.dlgHide=dlgHide;
function lineHTML(ln,info){
  const t=typeof ln.t==='function'?ln.t(S,G):ln.t;
  if(info.kind==='narr')return `<div class="ln narr">${fmt(t)}</div>`;
  if(info.kind==='skill'){const res=ln.pass!=null?`<em>[${NL.diffName(ln.pass)}: Success]</em>`:'';return `<div class="ln skill" style="--c:${info.color}"><span class="who" data-tip="sk:${info.sk}">${esc(info.name)}</span>${res} — ${fmt(t)}</div>`;}
  if(info.kind==='you')return `<div class="ln you"><span class="who">You</span> — ${fmt(t)}</div>`;
  return `<div class="ln char" style="--c:${info.color}"><span class="who">${esc(info.name)}</span> — ${fmt(t)}</div>`;}
function gtx(t){t=String(t);if(t.indexOf('\u2039')<0)return t;const fem=S.gender==='f';
  return t.replace(/\u2039(sir|Sir)\u203a/g,(_,w)=>{const ad=S.flags.pemAddress;let r=ad==='boss'?'boss':ad==='name'&&S.flags.knowName?'Casey':ad==='sir'?'sir':(fem?'madam':'sir');return w==='Sir'?r[0].toUpperCase()+r.slice(1):r;})
    .replace(/\u2039([^\u203a|]*)\|([^\u203a]*)\u203a/g,(_,a,b)=>fem?b:a);}
G.gtx=gtx;NL.gtx=gtx;
function fmt(t){return esc(gtx(t)).replace(/\*([^*]+)\*/g,'<i>$1</i>').replace(/\[\[([^\]]+)\]\]/g,'<b>$1</b>');}
function scrollFeed(){const f=$('#feed');if(!f)return;const go=(sm)=>f.scrollTo({top:f.scrollHeight,behavior:sm&&G.settings.motion?'smooth':'auto'});go(true);requestAnimationFrame(()=>requestAnimationFrame(()=>go(true)));clearTimeout(scrollFeed.t);scrollFeed.t=setTimeout(()=>go(true),420);}
function tapWait(ms){return new Promise(res=>{let done=false;const fin=()=>{if(done)return;done=true;clearTimeout(tm);D.fastTap=null;res();};const tm=setTimeout(fin,ms);D.fastTap=fin;});}
async function showLine(ln){
  if(ln.if&&!ln.if(S,G))return false;
  if(ln.pass!=null&&NL.SKILLS[ln.s]&&G.skill(ln.s)+6<ln.pass)return false;
  if(ln.do)ln.do(S,G);
  if(ln.fx)runFx(ln.fx);
  if(ln.t==null)return false;
  if(!D.open)dlgShow('talk');
  const info=speakerInfo(ln.s);
  if(info.kind!=='narr')setHeadFor(info);
  const actor=info.id&&Wd.actors[info.id];
  Object.values(Wd.actors).forEach(a=>a.talking=false);if(actor)actor.talking=true;
  if(portrait&&portrait.actor)portrait.actor.talking=info.kind==='char'||info.kind==='you';
  const f=$('#feed');f.querySelectorAll('.ln.cur').forEach(x=>x.classList.remove('cur'));const wrap=h('div');wrap.innerHTML=lineHTML(ln,info);const el=wrap.firstChild;el.classList.add('cur');f.appendChild(el);requestAnimationFrame(()=>el.classList.add('in'));scrollFeed();
  while(f.children.length>80)f.firstChild.remove();
  if(info.kind==='skill'){A.sfx('hover');G.hint('voices');}
  const txt=typeof ln.t==='function'?ln.t(S,G):ln.t;const sp=[1.5,1,.6,0][G.settings.speed]??1;
  const ms=sp?clamp(500+txt.length*24,900,4600)*sp:60;
  if(G.settings.advance==='auto')await tapWait(ln.noWait?Math.min(ms,700):ms);
  else if(ln.noWait)await tapWait(Math.min(ms,450));
  else await continueWait();
  if(actor)actor.talking=false;if(portrait&&portrait.actor)portrait.actor.talking=false;
  return true;}
function lineVis(ln){if(typeof ln==='string')return true;if(ln.t==null)return false;if(ln.if&&!ln.if(S,G))return false;if(ln.pass!=null&&NL.SKILLS[ln.s]&&G.skill(ln.s)+6<ln.pass)return false;return true;}
async function lines(arr,o){if(!arr)return;if(typeof arr==='function')arr=arr(S,G);
  for(let i=0;i<arr.length;i++){let ln=typeof arr[i]==='string'?{t:arr[i]}:arr[i];
    if(o&&o.lastNoWait&&!arr.slice(i+1).some(lineVis))ln=Object.assign({},ln,{noWait:true});
    await showLine(ln);}}
function continueWait(){return new Promise(res=>{const box=$('#opts');box.innerHTML='';
  const b=h('button','opt cont','<span class="ot">Continue</span><span class="arr">▸</span>');let done=false;
  const fin=()=>{if(done)return;done=true;D.fastTap=null;if(b.parentNode)b.remove();res();};
  b.onclick=()=>{A.sfx('click');fin();};box.appendChild(b);box.classList.add('in');D.fastTap=fin;scrollFeed();});}
G.lines=lines;
function runFx(fx){(Array.isArray(fx)?fx:[fx]).forEach(f=>{const [k,v]=String(f).split(':');
  if(k==='shake'&&Wd.world)Wd.world.shake=+(v||1);if(k==='hurt'&&Wd.world)Wd.world.hurt=+(v||1);if(k==='sfx')A.sfx(v);if(k==='music')A.music(v==='none'?null:v);if(k==='flash')flash();});}
function flash(){const f=$('#flash');f.classList.remove('go');void f.offsetWidth;f.classList.add('go');}
G.flash=flash;

/* ---- options ---- */
function optLocked(o){if(!o.ck)return false;const r=S.checks[o.ck.id];if(!r||r.ok)return false;if(o.ck.red)return 'hide';return G.skill(o.ck.sk)<=r.val?'lock':false;}
function optVisible(o,nodeId,i){
  if(o.if&&!o.if(S,G))return false;
  const ok=o.once===true?`${nodeId}:${i}`:o.once;if(ok&&S.once[ok])return false;
  if(o.ab&&!G.hasAb(o.ab,o.t2))return false;
  if(o.item&&!G.has(o.item))return false;
  if(o.ck&&optLocked(o)==='hide')return false;
  if(o.ck&&o.ck.id&&S.checks[o.ck.id]&&S.checks[o.ck.id].ok&&!o.repeat)return false;
  return true;}
function optHTML(o,n){
  const t=typeof o.t==='function'?o.t(S,G):o.t;let pre='';
  if(o.ck){const sk=NL.SKILLS[o.ck.sk],c=NL.ATTRS[sk.attr].color,p=Math.round(G.chance(o.ck.sk,o.ck.dc-(o.ck.mod?o.ck.mod(S,G):0))*100),lk=optLocked(o);
    pre=`<span class="ck ${o.ck.red?'red':'white'}" data-tip="ck:${o.ck.red?'red':'white'}:${o.ck.sk}" style="--c:${c}">${o.ck.red?'Red':'White'} · ${esc(sk.name)} · ${NL.diffName(o.ck.dc)} ${o.ck.dc} · ${p}%${lk==='lock'?' · <s>locked</s>':''}</span>`;}
  if(o.ab){const ab=NL.ABIL[o.ab],cl=NL.CLANS[ab.clan];const cost=abilityCost(o.ab,o);pre=`<span class="ab" data-tip="ab:${o.ab}" style="--c:${cl.aura}">◆ ${esc(o.t2?ab.t2.n:ab.n)} · ${cost} Vitae${cost>0&&S.vitae<=cost?' · <s>too little blood</s>':''}</span>`;}
  else if(o.blood){pre=`<span class="ab" style="--c:#e0263c">◆ ${o.blood} Vitae${S.vitae<=o.blood?' · <s>too little blood</s>':''}</span>`;}
  if(o.item&&o.showItem!==false)pre+=`<span class="itm">▣ ${esc(NL.ITEMS[o.item].n)}</span>`;
  return `<span class="on">${n}.</span><span class="ot">${pre}${fmt(t)}</span>`;}
function bloodCost(o){return o.ab?abilityCost(o.ab,o):(o.blood||0);}
G.bloodCost=bloodCost;
function abilityCost(id,o){const ab=NL.ABIL[id];let c=o&&o.cost!=null?o.cost:ab.c;if(o&&o.t2)c+=1;if((id==='kneel'||id==='fog')&&S.th.done.includes('darwin'))c=0;if(G.thought('vegan')&&S.lastFeed!=='bag'&&S.lastFeed!=='consent')c+=1;return c;}
G.abilityCost=abilityCost;
function chooseOption(list,nodeId){return new Promise(res=>{
  const box=$('#opts');box.innerHTML='';let n=1;
  if(list.some(x=>x.o.ck&&!x.o.ck.red))G.hint('white');if(list.some(x=>x.o.ck&&x.o.ck.red))G.hint('red');if(list.some(x=>x.o.ab))G.hint('ability');
  list.forEach(({o,i})=>{const b=h('button','opt',optHTML(o,n++));const lk=optLocked(o);
    const bc=bloodCost(o);if(lk==='lock'||(bc>0&&S.vitae<=bc)){b.disabled=true;b.classList.add('locked');}
    if(o.end||o.leave)b.classList.add('leave');
    b.onclick=()=>{A.sfx('click');box.innerHTML='';res({o,i});};b.onpointerenter=()=>A.sfx('hover');box.appendChild(b);});
  box.classList.add('in');scrollFeed();
});}

/* ---- dice & checks ---- */
const PIP=['','⚀','⚁','⚂','⚃','⚄','⚅'];
async function doCheck(ck){
  const sk=NL.SKILLS[ck.sk],val=G.skill(ck.sk)+(ck.mod?ck.mod(S,G):0),col=NL.ATTRS[sk.attr].color;
  const f=$('#feed');const el=h('div','ln check',`<span class="dice"><b>⚀</b><b>⚀</b></span><span class="cklab" style="--c:${col}">${ck.red?'Red check':'White check'} · ${esc(sk.name)} ${val} · ${NL.diffName(ck.dc)} ${ck.dc}</span><span class="res"></span>`);
  f.appendChild(el);requestAnimationFrame(()=>el.classList.add('in'));scrollFeed();A.sfx('dice');
  const ds=el.querySelectorAll('.dice b');const t0=performance.now();
  while(performance.now()-t0<620){ds[0].textContent=PIP[1+Math.floor(Math.random()*6)];ds[1].textContent=PIP[1+Math.floor(Math.random()*6)];await sleep(60);}
  const a=1+Math.floor(Math.random()*6),b=1+Math.floor(Math.random()*6);ds[0].textContent=PIP[a];ds[1].textContent=PIP[b];
  let ok=(a===6&&b===6)||(!(a===1&&b===1)&&a+b+val>=ck.dc);
  const res=el.querySelector('.res');S.stats.checks++;
  res.innerHTML=`${a}+${b}+${val} = <b>${a+b+val}</b> · ${ok?'Success':'Failure'}`;el.classList.add(ok?'ok':'no');
  if(!ok){S.stats.fails++;
    if(S.vitae>0&&!ck.noPush){A.sfx('fail');const push=await pushPrompt(ck);if(push){ok=true;S.stats.pushes++;G.vitae(-1,true);A.sfx('push');Wd.world&&(Wd.world.hurt=.6);G.glowBoost=.8;setTimeout(()=>G.glowBoost=0,2500);
        res.innerHTML=`<b>Forced</b> · the blood answers`;el.classList.remove('no');el.classList.add('ok','pushed');toast('hurt','−1 Vitae','Rousing the Blood');}}
    else A.sfx('fail');}
  if(ok&&!el.classList.contains('pushed'))A.sfx('success');
  if(ck.id)S.checks[ck.id]={ok,val};
  if(!ok&&ck.red&&S.clan==='glass'){const all=Object.keys(NL.SKILLS),k=all[Math.floor(Math.random()*all.length)];S.shatter={sk:k,until:S.tt+60};toast('hurt',`Shattered Mind: ${NL.SKILLS[k].name} +3 for an hour`,'The Glass');}
  if(ok)G.xp(ck.red?10:5,`${sk.name} check`);
  await sleep(350);refreshHUD();
  return ok;}
function pushPrompt(ck){G.hint('push');return new Promise(res=>{const box=$('#opts');box.innerHTML='';
  const last=S.vitae<=1;
  const b1=h('button','opt push',`<span class="on">◆</span><span class="ot"><span class="ab" style="--c:#e0263c">Rouse the Blood · 1 Vitae</span>${last?'You have no blood to spare. One more drop and you go back to sleep for good.':'Force it. Burn blood until the world gives way.'}${!last&&(G.hunger()||S.vitae<=4)?' <i>(Your Hunger will rise.)</i>':''}</span>`);
  if(last){b1.disabled=true;b1.classList.add('locked');}
  const b2=h('button','opt leave',`<span class="on">·</span><span class="ot">Accept the failure.</span>`);b1.querySelector('.ab').dataset.tip='push';
  b1.onclick=()=>{box.innerHTML='';res(true);};b2.onclick=()=>{A.sfx('click');box.innerHTML='';res(false);};box.append(b1,b2);scrollFeed();});}

/* ---- talk ---- */
G.busy=0;
async function talk(id,o){
  o=o||{};G.busy++;dlgShow('talk');$('#opts').innerHTML='';
  if(!o.keep)$('#feed').innerHTML='';
  let cur=id,guard=0,nodes=0;D.mortalTalk=false;G.uncanny=false;
  try{
  while(cur&&guard++<400){
    const node=NL.STORY.nodes[cur];if(!node){console.warn('missing node',cur);break;}
    S.seen[cur]=(S.seen[cur]||0)+1;nodes++;if(S.clan==='butchers'&&D.mortalTalk&&nodes>5&&!G.uncanny){G.uncanny=true;toast('hurt','Uncanny Valley: −1 Masquerade','They can feel something is wrong with you');}
    if(node.speaker)setHeadFor(speakerInfo(node.speaker));
    if(node.enter)node.enter(S,G);
    await lines(node.lines,{lastNoWait:!!node.opts&&!node.cs&&!node.next&&!node.enc});
    if(node.lines&&S.night>=2&&S.flags.woke&&S.chapter!=='end'){S.lineAcc=(S.lineAcc||0)+node.lines.length;const m=Math.floor(S.lineAcc/3);if(m>0){S.lineAcc-=m*3;G.tick(m);}}
    if(node.cs){await node.cs(G,S);}
    if(G.pendingBreach){G.pendingBreach=false;await breach();}
    if(node.enc){const r=await encounter(node.enc);cur=r==='win'?node.win:node.lose;if(typeof cur==='function')cur=cur(S,G,r);continue;}
    if(node.next){cur=typeof node.next==='function'?node.next(S,G):node.next;continue;}
    if(node.end||!node.opts){cur=null;break;}
    const vis=node.opts.map((o,i)=>({o,i})).filter(x=>optVisible(x.o,cur,x.i));
    if(!vis.length){cur=null;break;}
    const {o,i}=await chooseOption(vis,cur);
    const ok=o.once===true?`${cur}:${i}`:o.once;if(ok)S.once[ok]=1;
    const ot=typeof o.t==='function'?o.t(S,G):o.t;
    if(!o.silent)await showLine({s:'you',t:ot.replace(/^\[[^\]]*\]\s*/,''),noWait:true});
    G.tick(o.ck?2:1);
    if(o.ab){const c=abilityCost(o.ab,o);G.vitae(-c,true);toast('hurt',`−${c} Vitae`,NL.ABIL[o.ab].n);A.sfx('push');G.glowBoost=1;setTimeout(()=>G.glowBoost=0,2400);flash();}
    if(o.do)o.do(S,G);
    if(o.ck){const r=await doCheck(o.ck);cur=r?o.ok:o.no;}
    else cur=o.go;
    if(o.enc){const r=await encounter(o.enc);cur=r==='win'?o.ok:o.no;}
    if(typeof cur==='function')cur=cur(S,G);
    if(o.end){cur=null;}
    if(G.pendingBreach){G.pendingBreach=false;await breach();}
  }
  } finally {
    G.busy--;G.uncanny=false;
    if(!o.stay){dlgHide();if(Wd.world&&!document.body.classList.contains('cine'))Wd.world.focus=null;if(Wd.player)Wd.player.look=null;}
    Object.values(Wd.actors).forEach(a=>a.talking=false);
    autosave();refreshHUD();
  }
}
G.talk=talk;

/* ================= ENCOUNTERS ================= */
function meter(el,v,mx,label,color){el.innerHTML=`<span class="ml">${esc(label)}</span><span class="mb">${Array.from({length:mx},(_,i)=>`<i class="${i<v?'on':''}"></i>`).join('')}</span><span class="mv">${v}/${mx}</span>`;el.style.setProperty('--c',color);}
async function encounter(id){
  const E=NL.STORY.enc[id];const st=E.start(S,G);st.round=0;st.log=[];
  const bar=$('#encBar');bar.hidden=false;$('#encT').innerHTML=`<b>${esc(E.title)}</b><span>${esc(E.sub||'')}</span>`;
  const upd=()=>{meter($('#encP'),Math.min(st.prog,E.prog.max),E.prog.max,E.prog.name,E.prog.color);meter($('#encX'),Math.min(st.threat,E.threat.max),E.threat.max,E.threat.name,E.threat.color);};
  upd();A.music(E.music||'tense');document.body.classList.add('enc');G.hint('enc');
  if(E.focus)E.focus(G);
  await lines(E.intro);
  let result=null;
  for(;;st.round++){
    const R=E.round(st,S,G);if(!R){break;}
    await lines(R.lines,{lastNoWait:true});if(R.threat){st.threat+=R.threat;upd();if(R.threat>0){Wd.world&&(Wd.world.shake=.5);A.sfx('sting');}}
    if(st.threat>=E.threat.max){result='lose';break;}
    const moves=E.moves(st,S,G).map((o,i)=>({o,i})).filter(x=>optVisible(x.o,'enc_'+id+'_'+st.round,x.i));
    const {o}=await chooseOption(moves,'enc');
    if(o.once)S.once[o.once]=1;
    const ot=typeof o.t==='function'?o.t(S,G):o.t;
    await showLine({s:'you',t:ot.replace(/^\[[^\]]*\]\s*/,''),noWait:true});G.tick(1);
    if(o.ab){const c=abilityCost(o.ab,o);G.vitae(-c,true);toast('hurt',`−${c} Vitae`,NL.ABIL[o.ab].n);A.sfx('push');G.glowBoost=1;setTimeout(()=>G.glowBoost=0,2400);flash();}
    let ok=true;if(o.ck)ok=await doCheck(o.ck);
    const out=ok?(o.ok&&o.ok(st,S,G)):(o.no&&o.no(st,S,G));
    upd();await lines(out);upd();
    if(G.pendingBreach){G.pendingBreach=false;st.breach=true;await breach();}
    if(st.result){result=st.result;break;}
    if(st.prog>=E.prog.max){result='win';break;}
    if(st.threat>=E.threat.max){result='lose';break;}
  }
  if(!result)result=E.decide?E.decide(st,S,G):(st.prog>=st.threat?'win':'lose');
  st.result=result;upd();
  await lines(E.outro(result,st,S,G));
  bar.hidden=true;document.body.classList.remove('enc');A.music(E.after||'night');
  return result;}
G.encounter=encounter;

/* ================= BREACH / GAME OVER ================= */
async function breach(){
  A.sfx('breach');flash();Wd.world&&(Wd.world.shake=2.2,Wd.world.hurt=1.4);
  await lines([{s:'frenzy',t:'THE MASK IS OFF.'},{t:'Your lips peel back. A sound comes out of you that no throat should make. For three long seconds there is no one inside your face at all.'}]);
  S.flags.breaches=(S.flags.breaches||0)+1;
  const witness=NL.STORY.breachWitness&&NL.STORY.breachWitness(S,G);
  if(witness){await lines([{t:witness}]);G.heat(2);}
  S.comp=3;refreshHUD();
  await lines([{s:'stagecraft',t:'...and back. Blink. Close your mouth. Pretend that was a sneeze.'}]);}
function gameOver(kind){
  const go=$('#gameover'),K=NL.STORY.gameovers[kind];if(!K)return;
  A.music(null);A.sfx('dawn');go.querySelector('.go-k').textContent=K.k;go.querySelector('h2').textContent=K.t;go.querySelector('p').textContent=K.d;go.querySelector('.go-a').textContent=K.a||'';go.hidden=false;requestAnimationFrame(()=>go.classList.add('in'));
  G.busy++;}
G.gameOver=gameOver;

/* ================= WORLD / EXPLORATION ================= */
const Wd={world:null,player:null,actors:{},def:null,inter:[],markers:new Map()};G.Wd=Wd;
G.actor=id=>Wd.actors[id];
G.addActor=(id,spec,o)=>{if(Wd.actors[id])G.removeActor(id);const a=new NL.Actor(id,spec,o);a.solid=o&&o.solid!==false;Wd.actors[id]=a;Wd.world.actors.push(a);return a;};
G.removeActor=id=>{const a=Wd.actors[id];if(!a)return;delete Wd.actors[id];Wd.world.actors=Wd.world.actors.filter(x=>x!==a);};
function visRect(){const d=$('#dlg'),r=$('#app').getBoundingClientRect();const top=72,cw=r.width,ch=r.height;
  if(D.open||document.body.classList.contains('talking')){const dr=d.getBoundingClientRect();
    if(cw>=900||(cw>ch&&ch<=560))return {x:0,y:top,w:cw-dr.width,h:ch-top-8};return {x:0,y:top,w:cw,h:Math.max(120,dr.top-top)};}
  return {x:0,y:top,w:cw,h:ch-top-(cw<900?64:20)};}
async function enterRoom(id,spawn,o){
  o=o||{};G.busy++;
  try{
  if(Wd.world&&!o.instant){Wd.world.fadeTarget=1;await sleep(450);}
  hideMarkers();
  S.room=id;const def=NL.ROOMS[id];Wd.def=def;
  Wd.world.actors=[];Wd.actors={};
  Wd.world.load(def,S);
  const sp=spawn||def.spawn;
  Wd.player=G.addActor('you',playerSpec(),{x:sp.x,z:sp.z,ry:sp.ry||0,walkSpeed:2.1,blinks:true});Wd.player.solid=false;
  if(S.pos&&o.restorePos){Wd.player.x=S.pos[0];Wd.player.z=S.pos[1];Wd.player.ry=S.pos[2]||0;}
  NL.STORY.populate(id,S,G);
  buildInter();
  A.ambience(def.ambience);
  $('#rain').hidden=!def.rain;
  Wd.world.fadeTarget=0;Wd.world.fade=1;
  if(!o.noCard)locCard(def.name,def.sub);
  if(NL.STORY.onEnter&&!o.noEnter)await NL.STORY.onEnter(id,S,G,o);
  }finally{G.busy--;}
  autosave();
}
G.enterRoom=enterRoom;
function locCard(t,sub){const c=$('#loc');c.innerHTML=`<b>${esc(t)}</b><span>${esc(sub||'')} · ${clockStr()}</span>`;c.classList.remove('in');void c.offsetWidth;c.classList.add('in');}
function buildInter(){
  const def=Wd.def;Wd.inter=[];
  (def.inter||[]).forEach(it=>Wd.inter.push(Object.assign({kind:'obj'},it)));
  (def.exits||[]).forEach(it=>Wd.inter.push(Object.assign({kind:'exit'},it)));
  (NL.STORY.npcInter?NL.STORY.npcInter(def.id,S,G):[]).forEach(it=>Wd.inter.push(Object.assign({kind:'npc'},it)));
  hideMarkers();}
G.rebuildInter=buildInter;
function hideMarkers(){Wd.markers.forEach(m=>m.remove());Wd.markers.clear();}
function liveInter(){return Wd.inter.filter(it=>!it.if||it.if(S,G)).map(it=>{if(it.kind==='npc'){const a=Wd.actors[it.actor];if(!a||!a.visible)return null;const hp=a.headPos();
  return Object.assign({},it,{at:[hp[0],hp[1]+0.28,hp[2]],box:[a.x-.32,0,a.z-.32,a.x+.32,a.pose==='lie'?0.5:1.9,a.z+.32],stand:it.stand||standNear(a),face:[a.x,a.z]});}return it;}).filter(Boolean);}
function standNear(a){const p=Wd.player,dx=p.x-a.x,dz=p.z-a.z,d=Math.hypot(dx,dz)||1;return [a.x+dx/d*0.95,a.z+dz/d*0.95];}
function updateMarkers(){
  const layer=$('#markers');const show=!G.busy&&!D.open&&!$('#panel').classList.contains('in')&&!document.body.classList.contains('cine');
  layer.classList.toggle('off',!show);if(!Wd.world||!Wd.world.vf)return;
  const live=liveInter();const keep=new Set();const p=Wd.player;
  const dist=it=>p?Math.hypot((it.stand?it.stand[0]:it.at[0])-p.x,(it.stand?it.stand[1]:it.at[2])-p.z):99;
  const nearIds=new Set(live.map(it=>[it.id,dist(it)]).filter(x=>x[1]<2.4).sort((a,b)=>a[1]-b[1]).slice(0,2).map(x=>x[0]));
  for(const it of live){keep.add(it.id);let m=Wd.markers.get(it.id);
    if(!m){m=h('button','mk '+it.kind,`<i></i><span>${esc(typeof it.label==='function'?it.label(S,G):it.label)}</span>`);m.onclick=(e)=>{e.stopPropagation();tapNear(e.clientX,e.clientY,it.id,e.pointerType||lastPT);};layer.appendChild(m);Wd.markers.set(it.id,m);}
    m._label=typeof it.label==='function'?it.label(S,G):it.label;
    const s=Wd.world.project(it.at);m.style.transform=`translate(${s[0]}px,${s[1]}px)`;
    m.classList.toggle('flip',s[0]>($('#markers').clientWidth||window.innerWidth)-170);
    m.classList.toggle('near',nearIds.has(it.id)||layer.classList.contains('all'));
    m.classList.toggle('seen',!!S.seen['use:'+it.id]);}
  Wd.markers.forEach((m,k)=>{if(!keep.has(k)){m.remove();Wd.markers.delete(k);}});}
async function walkTo(x,z,actor){actor=actor||Wd.player;const path=Wd.world.findPath(actor.x,actor.z,x,z,actor);if(!path||!path.length)return false;
  return new Promise(res=>{actor.path=path;actor.onArrive=()=>res(true);});}
G.walkTo=walkTo;
G.walk=(id,x,z)=>walkTo(x,z,Wd.actors[id]);
G.face=(id,x,z)=>{const a=Wd.actors[id];if(a)a.faceTo=[x,z];};
G.place=(id,x,z,ry)=>{const a=Wd.actors[id];if(a){a.x=x;a.z=z;if(ry!=null)a.ry=ry;a.path=null;}};
G.pose=(id,p,k)=>{const a=Wd.actors[id];if(a)a.setPose(p,k);};
G.look=(id,target)=>{const a=Wd.actors[id];if(!a)return;if(!target){a.look=null;return;}if(typeof target==='string'){const b=Wd.actors[target];a.look=b?()=>b.headPos():null;}else a.look=target;};
async function useInter(id){
  if(G.busy||D.open)return;const it=liveInter().find(x=>x.id===id);if(!it)return;
  G.busy++;
  try{
    A.sfx('click');
    const st=it.stand||[it.at[0],it.at[2]];await walkTo(st[0],st[1]);
    if(it.face)Wd.player.faceTo=it.face;
    await sleep(250);
  } finally {G.busy--;}
  S.seen['use:'+id]=1;
  if(it.kind==='exit'){if(NL.STORY.exit&&await NL.STORY.exit(it,S,G)===false)return;if(it.map&&!it.to){if(NL.Camp)NL.Camp.openMap();return;}G.tick(1);await enterRoom(it.to,it.spawn);return;}
  await NL.STORY.use(id,S,G);
}
G.useInter=useInter;
/* tap disambiguation: on touch, a tap picks the nearest marker within a finger's reach; if several are that close, ask */
let lastPT='mouse';document.addEventListener('pointerdown',e=>{lastPT=e.pointerType||'mouse';},true);
function markerCenters(){const out=[];Wd.markers.forEach((m,id)=>{const i=m.querySelector('i');if(!i)return;const r=i.getBoundingClientRect();if(!r.width)return;out.push({id,m,x:r.left+r.width/2,y:r.top+r.height/2});});return out;}
function closePick(){const p=$('#pickMenu');if(p)p.remove();}
function tapNear(x,y,fallback,pt){closePick();if(G.busy||D.open)return false;
  const R=(pt==='touch'||pt==='pen')?34:14;
  const c=markerCenters().map(o=>Object.assign(o,{d:Math.hypot(o.x-x,o.y-y)})).filter(o=>o.d<=R).sort((a,b)=>a.d-b.d);
  if(!c.length){if(fallback){useInter(fallback);return true;}return false;}
  // only ask when the second candidate is about as close as the first
  const amb=c.filter(o=>o.d<=c[0].d+16);
  if(amb.length===1){useInter(amb[0].id);return true;}
  const menu=h('div','');menu.id='pickMenu';
  menu.innerHTML=amb.slice(0,5).map(o=>`<button data-id="${esc(o.id)}">${esc(o.m._label||o.id)}</button>`).join('');
  $('#app').appendChild(menu);const app=$('#app').getBoundingClientRect();
  const w=Math.min(240,app.width-24);menu.style.width=w+'px';const mh=menu.offsetHeight;
  let lx=Math.max(12,Math.min(app.width-w-12,x-app.left-w/2)),ly=y-app.top+18;if(ly+mh>app.height-90)ly=y-app.top-mh-18;
  menu.style.transform=`translate(${lx}px,${Math.max(8,ly)}px)`;
  menu.addEventListener('pointerdown',e=>e.stopPropagation());
  menu.querySelectorAll('button').forEach(b=>b.onclick=e=>{e.stopPropagation();closePick();A.sfx('click');useInter(b.dataset.id);});
  setTimeout(()=>document.addEventListener('pointerdown',function f(ev){if(!ev.target.closest('#pickMenu')){closePick();}document.removeEventListener('pointerdown',f,true);},true),0);
  return true;}
function onTap(e){
  if(D.fastTap){if(G.settings.tapText)D.fastTap();return;}
  if(!Wd.world||G.busy||D.open)return;
  const r=Wd.world.canvas.getBoundingClientRect(),px=e.clientX-r.left,py=e.clientY-r.top;
  if(tapNear(e.clientX,e.clientY,null,e.pointerType))return;
  const hit=Wd.world.pick(px,py,liveInter());
  if(hit){useInter(hit.id);return;}
  const f=Wd.world.floorAt(px,py);if(!f)return;
  const path=Wd.world.findPath(Wd.player.x,Wd.player.z,f[0],f[1],Wd.player);if(path){Wd.player.path=path;Wd.player.onArrive=null;tapRipple(px,py);}
}
function tapRipple(x,y){const r=h('div','ripple');r.style.left=x+'px';r.style.top=y+'px';$('#markers').appendChild(r);setTimeout(()=>r.remove(),600);}
/* barks */
const barkCD={};
function barks(){if(G.busy||D.open||!Wd.player||!NL.STORY.barks)return;const p=Wd.player;
  for(const b of NL.STORY.barks(S.room,S,G)){if(S.once['bark:'+b.id])continue;if(Math.hypot(b.at[0]-p.x,b.at[2]-p.z)>b.r)continue;if(b.if&&!b.if(S,G))continue;if(b.pass&&G.skill(b.s)+6<b.pass)continue;
    S.once['bark:'+b.id]=1;showBark(b);break;}}
function showBark(b){const sk=NL.SKILLS[b.s];const col=sk?NL.ATTRS[sk.attr].color:'#ccc';const e=h('div','bark',`<b style="color:${col}">${esc(sk?sk.name:b.s)}</b> ${fmt(b.t)}`);$('#markers').appendChild(e);
  const pos=()=>{const s=Wd.world.project(b.at);e.style.transform=`translate(${s[0]}px,${s[1]-24}px)`;};pos();const iv=setInterval(pos,50);
  requestAnimationFrame(()=>e.classList.add('in'));A.sfx('hover');setTimeout(()=>{e.classList.remove('in');setTimeout(()=>{clearInterval(iv);e.remove();},600);},5200);}

/* ================= CUTSCENE HELPERS ================= */
G.cine=on=>{document.body.classList.toggle('cine',!!on);};
G.wait=s=>sleep(s*1000*(G.settings.speed===3?0.4:1));
G.focus=(ids,pad,ext)=>{if(!Wd.world)return;if(!ids){Wd.world.focus=null;return;}const pts=[];(Array.isArray(ids)?ids:[ids]).forEach(x=>{if(typeof x==='string'){const a=Wd.actors[x];if(a){pts.push([a.x,1.7,a.z]);pts.push([a.x,0.1,a.z]);}}else pts.push(x);});if(ext)pts.push(...ext);Wd.world.focus={pts,pad:pad||0.8};};
G.camSpeed=v=>{if(Wd.world)Wd.world.camSpeed=v;};
G.shake=v=>{if(Wd.world)Wd.world.shake=v||1;};
G.sfx=(n,o)=>A.sfx(n,o);G.music=m=>A.music(m);G.A=A;
G.fade=async(to,speed)=>{if(!Wd.world)return;Wd.world.fadeSpeed=speed||4;Wd.world.fadeTarget=to;await sleep(Math.min(2500,900/(speed||4)*3));};
G.card=async(title,sub,o)=>{o=o||{};const c=$('#card');c.innerHTML=`${o.k?`<div class="ck">${esc(o.k)}</div>`:''}<h2>${esc(title)}</h2>${sub?`<p>${esc(sub)}</p>`:''}`;c.className='card '+(o.cls||'');c.hidden=false;A.sfx('card');
  requestAnimationFrame(()=>c.classList.add('in'));await sleep((o.hold||3.2)*1000);c.classList.remove('in');await sleep(900);c.hidden=true;};
G.blackout=on=>{$('#black').classList.toggle('in',!!on);};
G.say=async(arr,o)=>{G.busy++;dlgShow('cine');if(!(o&&o.keep))$('#feed').innerHTML='';$('#opts').innerHTML='';try{await lines(arr);}finally{G.busy--;if(!(o&&o.stay))dlgHide();}};
G.burst=(p,n,col)=>Wd.world&&Wd.world.burst(p,n,col);
G.rebuildRoom=()=>{if(Wd.world){Wd.world.rebuild(S);Wd.world.lights=NL.ROOMS[S.room].lights(S);buildInter();}};
G.locCard=locCard;G.toast=toast;G.esc=esc;G.fmt=fmt;G.sleep=sleep;G.h=h;G.$=$;

/* ================= PANELS ================= */
function openPanel(tab){if(G.busy&&!D.open&&tab!=='settings')return;A.sfx('open');const p=$('#panel');p.hidden=false;requestAnimationFrame(()=>p.classList.add('in'));renderPanel(tab);}
function closePanel(){A.sfx('close');const p=$('#panel');p.classList.remove('in');setTimeout(()=>{if(!p.classList.contains('in'))p.hidden=true;},300);if(pCanvas.parentNode&&pCanvas.parentNode.closest('#panel'))$('#snapHost').appendChild(pCanvas);portraitId=null;if(D.open&&D.lastInfo&&D.lastInfo.kind!=='narr')setHeadFor(D.lastInfo);}
G.openPanel=openPanel;G.closePanel=closePanel;
let curTab='char',selItem=null,selPerson=null;
function renderPanel(tab){curTab=tab||curTab;const b=$('#panelBody');
  document.querySelectorAll('#ptabs button').forEach(x=>{x.classList.toggle('on',x.dataset.t===curTab);if(x.dataset.t===curTab&&x.scrollIntoView)x.scrollIntoView({block:'nearest',inline:'nearest'});});
  if(curTab==='char')b.innerHTML=charHTML();
  if(curTab==='inv')b.innerHTML=invHTML();
  if(curTab==='thoughts')b.innerHTML=thoughtsHTML();
  if(curTab==='journal')b.innerHTML=journalHTML();
  if(curTab==='settings')b.innerHTML=settingsHTML();
  wirePanel();}
function sign(n){return n>0?'+'+n:String(n);}
function charHTML(){
  const c=G.clan(),pa=S.past?NL.PASTS[S.past]:null;
  let html=`<div class="sheet"><div class="sheet-l"><div class="doll" id="dollHost"></div><div class="who-card"><div class="k">${c?esc(c.name):'Lineage unknown'}</div><h3>${pa?esc(pa.name):'You don\'t remember'}</h3><p>${c?esc(c.ep):'Find a mirror.'}</p>${S.pts?`<div class="pts">${S.pts} skill point${S.pts>1?'s':''} to spend</div>`:''}</div>
    <div class="stats"><div><span>Composure</span><b>${S.comp}/${G.compMax()}</b></div><div><span>Vitae</span><b>${S.vitae}/${G.vitMax()}</b></div><div><span>Hunger</span><b>${['None','Peckish','Hungry','Starving','Ravenous'][G.hunger()]}</b></div><div><span>Heat</span><b>${S.heat}/5</b></div><div><span>Level</span><b>${S.lvl} · ${S.xp%100}/100 XP</b></div><div data-tip="sync"><span>Diablerie Sync</span><b>${Math.round(S.sync)}%</b></div><div><span>Cash</span><b>$${S.cash||0}</b></div></div></div><div class="sheet-r">`;
  for(const at of ['sanguine','masquerade','nocturne','cadaver']){const A_=NL.ATTRS[at];
    html+=`<section class="attr" style="--c:${A_.color}"><header><b>${A_.name}</b><span>${S.attrs[at]}</span><em>${esc(A_.blurb)}</em></header>`;
    for(const sk of NL.SKILL_ORDER[at]){const P=G.skillParts(sk),SK=NL.SKILLS[sk];const parts=[];if(S.sig===sk)parts.push('signature voice');if((S.spent[sk]||0)>=G.skillCap(sk)&&S.clan)parts.push('at learning cap');if(P.cl)parts.push(`clan ${sign(P.cl)}`);if(P.ex)parts.push(`gear/thoughts ${sign(P.ex)}`);if(P.hu)parts.push(`hunger ${sign(P.hu)}`);if(P.rs)parts.push(`resonance ${sign(P.rs)}`);if(P.sp)parts.push(`learned +${P.sp}`);
      html+=`<div class="skr">${NL.PAINTED&&NL.PAINTED['skill_'+sk]?`<span class="g gi"><img alt="" src="${NL.PAINTED['skill_'+sk]}"></span>`:`<span class="g"><svg viewBox="0 0 48 48">${NL.GLYPH[sk]}</svg></span>`}<div class="sk-t"><b>${esc(SK.name)}</b><small>${esc(SK.d)}</small>${parts.length?`<small class="mods">${esc(parts.join(' · '))}</small>`:''}</div><span class="sv">${P.zero?'—':P.total}</span>${S.pts&&S.clan&&(S.spent[sk]||0)<G.skillCap(sk)?`<button class="plus" data-sk="${sk}" aria-label="Raise ${esc(SK.name)}">+</button>`:''}</div>`;}
    html+='</section>';}
  if(c){html+=`<section class="abil" style="--c:${c.aura}"><header><b>Disciplines</b><em>${esc(c.curse)}</em></header>`;for(const k in c.ab){const a=c.ab[k],mu=!!S.mut[k],mc=S.flags.suppressed?1:2;html+=`<div class="abr"><b>◆ ${esc(a.n)}</b><span>${abilityCost(k)} Vitae</span><small>${esc(a.d)}</small>${a.t2?`<small class="t2 ${mu?'on':''}">Tier 2 · <b>${esc(a.t2.n)}</b>: ${esc(a.t2.d)}${mu?' · unlocked':''}</small>${!mu?`<button class="mut" data-mut="${k}" ${S.pts>=mc?'':'disabled'}>Mutate · ${mc} skill points</button>`:''}`:''}</div>`;}html+='</section>';}
  if(NL.Rep)html+=NL.Rep.html(S);
  return html+'</div></div>';}
let invFilter='all',invSlot=null;
const SLOT_FIX={body:'torso',coat:'torso',head:'face',acc:'pocket',acc1:'pocket',acc2:'pocket'};
function itemSlot(it){if(!it||!it.slot)return null;if(/^tattoo_/.test(it.id||''))return 'ink';return SLOT_FIX[it.slot]||it.slot;}
function itemKind(it){if(itemSlot(it))return 'wear';if(it.use||(NL.ItemUse&&NL.ItemUse[it.id]))return 'use';if(it.type==='read')return 'read';return 'other';}
function modsMini(it){return it.mods?Object.entries(it.mods).map(([k,v])=>`<i class="${v>0?'up':'dn'}" style="--c:${NL.ATTRS[NL.SKILLS[k].attr].color}">${esc(NL.SKILLS[k].name)} ${sign(v)}</i>`).join(''):'';}
function quickBtn(k,it,worn){const sl=itemSlot(it);
  if(worn)return `<button class="qb ghost" data-quick="unequip" data-qi="${k}">Take off</button>`;
  if(sl)return `<button class="qb" data-quick="equip" data-qi="${k}">${sl==='pocket'?'Pocket':sl==='ink'?'Show':'Wear'}</button>`;
  if(it.use&&NL.ItemUse&&NL.ItemUse[k])return `<button class="qb" data-quick="use" data-qi="${k}">${esc(it.use)}</button>`;
  if(it.type==='read'||k==='burner')return `<button class="qb" data-quick="read" data-qi="${k}">${k==='burner'?'Messages':'Read'}</button>`;
  return '';}
function normalizeEq(){for(const sl of Object.keys(S.eq)){const id=S.eq[sl];if(!id||!NL.ITEMS[id]){delete S.eq[sl];continue;}const want=itemSlot(NL.ITEMS[id]);if(want&&want!==sl){delete S.eq[sl];if(!S.eq[want])S.eq[want]=id;else S.inv[id]=(S.inv[id]||0)+1;}}}
G.normalizeEq=()=>normalizeEq();
function invHTML(){
  Object.keys(NL.ITEMS).forEach(k=>{if(NL.ITEMS[k]&&!NL.ITEMS[k].id)NL.ITEMS[k].id=k;});normalizeEq();
  const slots=NL.SLOTS.includes('ink')?NL.SLOTS:NL.SLOTS.concat(['ink']);
  let html='<div class="inv inv2"><div class="inv-l"><div class="doll" id="dollHost"></div><div class="cashline">Cash <b>$'+(S.cash||0)+'</b></div><div class="slots">';
  for(const sl of slots){const it=S.eq[sl];html+=`<button class="slot ${it?'full':''} ${invSlot===sl?'sel':''}" data-slotf="${sl}"><span>${({ink:'Ink'})[sl]||NL.SLOT_NAMES[sl]||sl}</span><b>${it?esc(NL.ITEMS[it].n):'—'}</b></button>`;}
  html+='</div></div><div class="inv-r">';
  const carried=Object.keys(S.inv).filter(k=>NL.ITEMS[k]),worn=Object.values(S.eq).filter(k=>k&&NL.ITEMS[k]);
  const cnt={all:carried.length+worn.length,worn:worn.length,wear:0,use:0,read:0,other:0};carried.forEach(k=>cnt[itemKind(NL.ITEMS[k])]++);
  const F=[['all','All'],['worn','Worn'],['wear','Wearable'],['use','Usable'],['read','Readable'],['other','Other']];
  html+='<div class="ifil">'+F.filter(([k])=>k==='all'||cnt[k]).map(([k,n])=>`<button class="fchip ${invFilter===k&&!invSlot?'on':''}" data-fil="${k}">${n}<em>${cnt[k]}</em></button>`).join('');
  if(invSlot)html+=`<button class="fchip on slotf" data-fil="all">Fits ${esc(({ink:'Ink'})[invSlot]||NL.SLOT_NAMES[invSlot]||invSlot)} ✕</button>`;
  html+='</div><div class="items">';
  let list=[];
  if(invSlot){const w=S.eq[invSlot];if(w)list.push([w,true]);carried.filter(k=>itemSlot(NL.ITEMS[k])===invSlot).forEach(k=>list.push([k,false]));}
  else{if(invFilter==='all'||invFilter==='worn')worn.forEach(k=>list.push([k,true]));if(invFilter!=='worn')carried.filter(k=>invFilter==='all'||itemKind(NL.ITEMS[k])===invFilter).forEach(k=>list.push([k,false]));}
  if(!list.length)html+=`<p class="empty">${invSlot?'Nothing you carry fits there.':cnt.all?'Nothing here.':'Your pockets are empty. Things in the world that can be taken will say so.'}</p>`;
  for(const [k,isWorn] of list){const it=NL.ITEMS[k];const sl=itemSlot(it);
    html+=`<div class="item ${selItem===k?'sel':''} ${isWorn?'worn':''}"><button class="ib" data-item="${k}"><b>${esc(it.n)}</b><span>${isWorn?'Worn · ':''}${sl?(({ink:'Ink'})[sl]||NL.SLOT_NAMES[sl]||sl):({use:'Consumable',tool:'Tool',read:'Readable',money:'Money',relic:'Relic'}[it.type]||'Kept')}${S.inv[k]>1?' ×'+S.inv[k]:''}</span>${it.mods?`<span class="mm">${modsMini(it)}</span>`:''}</button>${quickBtn(k,it,isWorn)}</div>`;}
  html+='</div></div>';
  if(selItem&&NL.ITEMS[selItem]){const it=NL.ITEMS[selItem];const eq=G.equipped(selItem);const sl=itemSlot(it);
    html+=`<div class="isheet"><div class="icard"><button class="ix" data-close="1" aria-label="Close">✕</button><h3>${esc(it.n)}</h3><p>${esc(it.d)}</p>`;
    if(it.mods){html+='<div class="mods">'+Object.entries(it.mods).map(([k,v])=>`<span class="${v>0?'up':'dn'}" style="--c:${NL.ATTRS[NL.SKILLS[k].attr].color}">${v>0?'▲':'▼'} ${esc(NL.SKILLS[k].name)} ${sign(v)}</span>`).join('')+'</div>';}
    if(it.sp)html+=`<p class="sp">◆ ${esc(it.sp)}</p>`;
    if(sl&&!eq&&S.eq[sl]&&NL.ITEMS[S.eq[sl]])html+=`<p class="swap">Replaces <b>${esc(NL.ITEMS[S.eq[sl]].n)}</b></p>`;
    html+='<div class="acts">';
    if(sl)html+=eq?`<button data-act="unequip">Take off</button>`:`<button data-act="equip">${sl==='pocket'?'Pocket it':'Wear it'}</button>`;
    if(it.use)html+=`<button data-act="use">${esc(it.use)}</button>`;
    if(it.type==='read'||selItem==='burner')html+=`<button data-act="read">${selItem==='burner'?'Messages':'Read'}</button>`;
    if(NL.ItemActs&&NL.ItemActs[selItem])NL.ItemActs[selItem].forEach((a,i)=>{if(!a.if||a.if(S,G))html+=`<button data-xact="${i}">${esc(a.n)}</button>`;});
    html+='</div>';if(G.readOut)html+=`<div class="read">${G.readOut}</div>`;html+='</div></div>';}
  return html+'</div>';}
function invAct(id,act){const it=NL.ITEMS[id];if(!it)return;
  if(act==='equip'){const sl=itemSlot(it);if(S.eq[sl]){S.inv[S.eq[sl]]=(S.inv[S.eq[sl]]||0)+1;}S.eq[sl]=id;S.inv[id]--;if(S.inv[id]<=0)delete S.inv[id];A.sfx('item');updatePlayerLook();if(NL.STORY.onEquip)NL.STORY.onEquip(id,S,G);}
  if(act==='unequip'){for(const sl in S.eq)if(S.eq[sl]===id){delete S.eq[sl];S.inv[id]=(S.inv[id]||0)+1;}A.sfx('click');updatePlayerLook();}
  if(act==='use'&&NL.ItemUse&&NL.ItemUse[id]){NL.ItemUse[id](S,G);if(!G.has(id)&&selItem===id)selItem=null;}
  if(act==='read'){selItem=id;G.readOut=id==='burner'?NL.Camp.textsHTML():NL.STORY.readItem(id,S,G);A.sfx('page');}}
function thoughtsHTML(){
  let html='<div class="cab"><p class="lede">Thoughts you can internalize. While a thought is being worked through, it changes you; when it finishes, it changes you for good. Time passes in conversation and when you move between rooms.</p><div class="cslots">';
  S.th.slots.forEach((sl,i)=>{if(sl){const T=NL.THOUGHTS[sl.id],p=clamp((S.tt-sl.start)/T.time,0,1);
      html+=`<div class="cslot busy"><b>${esc(T.n)}</b><div class="prog"><i style="width:${p*100}%"></i></div><small>${Math.max(0,T.time-(S.tt-sl.start))} min left</small><small class="fx">While researching: ${fxText(T.during)||'no effect'}</small><button data-forget="${i}">Forget</button></div>`;}
    else html+=`<div class="cslot"><span>Empty slot</span></div>`;});
  if(S.th.slots.length<6)html+=`<div class="cslot buy"><button data-slotbuy="1" ${S.pts?'':'disabled'}>Open a new slot · 1 skill point</button></div>`;
  html+='</div><h4>Known thoughts</h4>';
  if(!S.th.known.length)html+='<p class="empty">Nothing yet. The voices will offer you ideas as the night goes on.</p>';
  S.th.known.forEach(id=>{const T=NL.THOUGHTS[id],sk=NL.SKILLS[T.from];html+=`<div class="thought" style="--c:${NL.ATTRS[sk.attr].color}"><div><b>${esc(T.n)}</b><small>from ${esc(sk.name)} · ${T.time} min</small><p>${esc(T.q)}</p><small class="fx">While researching: ${fxText(T.during)||'nothing'} · Once internalized: ${fxText(T.done)}${T.bonus?' · '+esc(T.bonus):''}</small></div><button data-intern="${id}" ${S.th.slots.every(Boolean)?'disabled':''}>Internalize</button></div>`;});
  if(S.th.done.length){html+='<h4>Internalized</h4>';S.th.done.forEach(id=>{const T=NL.THOUGHTS[id];html+=`<div class="thought done"><div><b>${esc(T.n)}</b><p>${esc(T.dt)}</p><small class="fx">${fxText(T.done)}${T.bonus?' · '+esc(T.bonus):''}</small></div></div>`;});}
  return html+'</div>';}
function fxText(m){if(!m)return '';return Object.entries(m).map(([k,v])=>`${NL.SKILLS[k].name} ${sign(v)}`).join(', ');}
function journalHTML(){
  let html='<div class="jr"><div class="jr-tasks">';
  const ids=Object.keys(S.tasks).filter(k=>NL.TASKS[k]);if(!ids.length)html+='<h4>Tasks</h4><p class="empty">Nothing yet.</p>';
  [['main','Main'],['clan','Clan'],['side','Side'],['secret','Secret']].forEach(([c,lab])=>{const ks=ids.filter(k=>(NL.TASKS[k].cat||'main')===c);if(!ks.length)return;html+=`<h4>${lab}</h4>`;
    ks.filter(k=>S.tasks[k]!=='done').forEach(k=>html+=`<div class="task">${esc(NL.TASKS[k].n)}${S.quests['note_'+k]?`<small>${esc(S.quests['note_'+k])}</small>`:''}</div>`);
    ks.filter(k=>S.tasks[k]==='done').forEach(k=>html+=`<div class="task done">${esc(NL.TASKS[k].n)}</div>`);});
  html+='</div><div class="jr-people"><h4>People</h4>';
  const ppl=Object.keys(S.dos);if(!ppl.length)html+='<p class="empty">You haven\'t met anyone yet. Well, nobody alive.</p>';
  html+='<div class="plist">';ppl.forEach(id=>{const C=NL.CHARS[id];html+=`<button class="pp ${selPerson===id?'sel':''}" data-person="${id}" style="--c:${C.color}"><img alt="" src="${snap(id)}"><b>${esc(C.n)}</b><span>${NL.relName(S.rel[id]||0)}</span></button>`;});html+='</div>';
  if(selPerson&&S.dos[selPerson]){const C=NL.CHARS[selPerson],r=S.rel[selPerson]||0;
    html+=`<div class="bio" style="--c:${C.color}"><div class="bio-h"><img alt="" src="${snap(selPerson)}"><div><div class="k">${esc(C.role)}</div><h3>${esc(C.full)}</h3><div class="relm">${[-3,-2,-1,0,1,2,3].map(v=>`<i class="${v===r?'on':''} ${v<0?'neg':v>0?'pos':''}"></i>`).join('')}<span>${NL.relName(r)}</span></div></div></div><p>${esc(C.bio)}</p>
      <h5>Schedule</h5>${C.sched.map(s=>`<div class="sch"><b>${esc(s[0])}</b><span>${esc(s[1])}</span></div>`).join('')}
      <h5>What you know</h5>${S.dos[selPerson].facts.length?S.dos[selPerson].facts.map(f=>`<div class="fact">${esc(C.facts[f]||f)}</div>`).join(''):'<p class="empty">Nothing yet.</p>'}</div>`;}
  return html+'</div></div>'+(NL.Help?NL.Help.glossaryHTML():'');}
const snaps={};function snap(id){if(NL.PAINTED&&NL.PAINTED[id])return NL.PAINTED[id];if(!snaps[id])snaps[id]=G.portraitSnapshot(id,NL.CHARS[id].spec,{rim:[.5,.3,.35]})||'';return snaps[id];}
function settingsHTML(){const v=A.vol;
  return `<div class="set"><label>Master volume<input type="range" id="vMaster" min="0" max="1" step=".05" value="${v.master}"></label><label>Music<input type="range" id="vMusic" min="0" max="1" step=".05" value="${v.music}"></label><label>Effects<input type="range" id="vSfx" min="0" max="1" step=".05" value="${v.sfx}"></label><label>Ambience<input type="range" id="vAmb" min="0" max="1" step=".05" value="${v.amb}"></label>
    <label>Graphics<select id="tQual">${[['-1','Automatic'],['0','High'],['1','Balanced'],['2','Battery saver']].map(([v,n])=>`<option value="${v}" ${String(G.settings.quality)===v?'selected':''}>${n}</option>`).join('')}</select></label>
    <label>Tips<select id="tHints"><option value="1" ${G.settings.hints!==false?'selected':''}>Show tips</option><option value="0" ${G.settings.hints===false?'selected':''}>Hide tips</option><option value="r">Show all tips again</option></select></label>
    <label>Dialogue<select id="tAdv"><option value="tap" ${G.settings.advance!=='auto'?'selected':''}>Tap to continue</option><option value="auto" ${G.settings.advance==='auto'?'selected':''}>Advance automatically</option></select></label>
    <label>Tapping the text<select id="tTap"><option value="0" ${!G.settings.tapText?'selected':''}>Only the Continue button advances</option><option value="1" ${G.settings.tapText?'selected':''}>A tap on the text also advances</option></select></label>
    <label>Auto-advance speed<select id="tSpeed">${['Slow','Normal','Fast','Instant'].map((n,i)=>`<option value="${i}" ${G.settings.speed===i?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="chk"><input type="checkbox" id="tMotion" ${G.settings.motion?'checked':''}> Camera motion and screen shake</label>
    <p class="hint">Press Continue to read on; you can scroll back through the conversation at any time. Tap the floor to walk; tap a marker or object to interact. The eye button shows every label in the room.</p>
    <div class="acts"><button id="bRestart">Start a new game</button><button id="bTitle">Return to title</button></div></div>`;}
function wirePanel(){
  const b=$('#panelBody');
  if(curTab==='char'||curTab==='inv'){const host=$('#dollHost');if(host){portraitInto(host,'you',playerSpec(),{mode:'full',rim:[.6,.2,.25],force:true});}}
  b.querySelectorAll('.plus').forEach(x=>x.onclick=()=>{if(!S.pts)return;S.spent[x.dataset.sk]=(S.spent[x.dataset.sk]||0)+1;S.pts--;A.sfx('level');renderPanel();refreshHUD();});
  b.querySelectorAll('[data-item]').forEach(x=>x.onclick=()=>{const id=x.dataset.item;if(!id)return;selItem=selItem===id&&curTab==='inv'?null:id;G.readOut=null;A.sfx('click');renderPanel();});
  b.querySelectorAll('[data-act]').forEach(x=>x.onclick=()=>{invAct(selItem,x.dataset.act);renderPanel();refreshHUD();});
  b.querySelectorAll('[data-quick]').forEach(x=>x.onclick=e=>{e.stopPropagation();invAct(x.dataset.qi,x.dataset.quick);renderPanel();refreshHUD();});
  b.querySelectorAll('[data-fil]').forEach(x=>x.onclick=()=>{invFilter=x.dataset.fil;invSlot=null;A.sfx('click');renderPanel();});
  b.querySelectorAll('[data-slotf]').forEach(x=>x.onclick=()=>{const sl=x.dataset.slotf;invSlot=invSlot===sl?null:sl;A.sfx('click');renderPanel();});
  b.querySelectorAll('[data-close]').forEach(x=>x.onclick=()=>{selItem=null;G.readOut=null;A.sfx('close');renderPanel();});
  b.querySelectorAll('[data-xact]').forEach(x=>x.onclick=()=>{const a=NL.ItemActs[selItem][+x.dataset.xact];closePanel();setTimeout(()=>a.do(S,G),350);});
  b.querySelectorAll('[data-mut]').forEach(x=>x.onclick=()=>{const mc=S.flags.suppressed?1:2;if(S.pts<mc)return;S.pts-=mc;S.mut[x.dataset.mut]=1;A.sfx('level');toast('level',`${esc(NL.ABIL[x.dataset.mut].t2.n)}`,'Blood mutation');renderPanel();refreshHUD();});
  b.querySelectorAll('[data-slotbuy]').forEach(x=>x.onclick=()=>{if(!S.pts||S.th.slots.length>=6)return;S.pts--;S.th.slots.push(null);A.sfx('thought');renderPanel();refreshHUD();});
  b.querySelectorAll('[data-intern]').forEach(x=>x.onclick=()=>{const id=x.dataset.intern,i=S.th.slots.findIndex(s=>!s);if(i<0)return;S.th.slots[i]={id,start:S.tt};S.th.known=S.th.known.filter(k=>k!==id);A.sfx('thought');renderPanel();refreshHUD();});
  b.querySelectorAll('[data-forget]').forEach(x=>x.onclick=()=>{const i=+x.dataset.forget;const sl=S.th.slots[i];if(sl){S.th.known.push(sl.id);S.th.slots[i]=null;}renderPanel();refreshHUD();});
  b.querySelectorAll('[data-person]').forEach(x=>x.onclick=()=>{selPerson=x.dataset.person;A.sfx('page');renderPanel();});
  const vs=[['vMaster','master'],['vMusic','music'],['vSfx','sfx'],['vAmb','amb']];vs.forEach(([i,k])=>{const e=$('#'+i);if(e)e.oninput=()=>{A.setVol(k,+e.value);try{localStorage.setItem('newlord.vol',JSON.stringify(A.vol));}catch(_){}}});
  const th=$('#tHints');if(th)th.onchange=()=>{if(th.value==='r'){NL.Help&&NL.Help.reset();G.settings.hints=true;th.value='1';}else G.settings.hints=th.value==='1';saveSettings();};
  const ta=$('#tAdv');if(ta)ta.onchange=()=>{G.settings.advance=ta.value;saveSettings();};
  const tt=$('#tTap');if(tt)tt.onchange=()=>{G.settings.tapText=tt.value==='1';saveSettings();};
  const ts=$('#tSpeed');if(ts)ts.onchange=()=>{G.settings.speed=+ts.value;saveSettings();};
  const tq=$('#tQual');if(tq)tq.onchange=()=>{G.settings.quality=+tq.value;saveSettings();applyQuality();if(Wd.world)Wd.world.resize(true);};
  const tm=$('#tMotion');if(tm)tm.onchange=()=>{G.settings.motion=tm.checked;saveSettings();document.body.classList.toggle('still',!tm.checked);};
  const br=$('#bRestart');if(br)br.onclick=()=>{closePanel();newGame();};
  const bt=$('#bTitle');if(bt)bt.onclick=()=>{closePanel();showTitle();};}
function showThoughtReveal(id){const T=NL.THOUGHTS[id];const r=$('#reveal');r.innerHTML=`<div class="rv"><div class="k">Thought internalized</div><h2>${esc(T.n)}</h2><p>${esc(T.dt)}</p><small>${fxText(T.done)}${T.bonus?' · '+esc(T.bonus):''}</small><button>Continue</button></div>`;r.hidden=false;requestAnimationFrame(()=>r.classList.add('in'));
  r.querySelector('button').onclick=()=>{r.classList.remove('in');setTimeout(()=>r.hidden=true,400);};}

/* ================= SAVE / LOAD ================= */
function autosave(){if(!Wd.player||S.chapter==='cold'||S.chapter==='end')return;S.pos=[Wd.player.x,Wd.player.z,Wd.player.ry];try{localStorage.setItem(SAVE_KEY,JSON.stringify(S));}catch(e){}}
G.autosave=autosave;
function hasSave(){try{return !!localStorage.getItem(SAVE_KEY);}catch(e){return false;}}
async function loadGame(){document.body.classList.remove('coldopen','cine');let d=null;try{d=JSON.parse(localStorage.getItem(SAVE_KEY));}catch(e){}if(!d){newGame();return;}S=Object.assign(newState(),d);hideTitle();A.music(S.flags.calloArrived&&!S.flags.calloGone?'tense':'night');document.body.classList.toggle('night5',S.night===5);await enterRoom(S.room,null,{restorePos:true,noEnter:true,instant:true});if(S.room==='backroom'&&S.flags.phoneRinging&&!S.flags.callDone)A.ringStart();refreshHUD();}
async function newGame(){document.body.classList.remove('coldopen','cine','talking','enc');D.fastTap=null;dlgHide();$('#encBar').hidden=true;A.ringStop();S=newState();try{localStorage.removeItem(SAVE_KEY);}catch(e){}hideTitle();refreshHUD();$('#gameover').hidden=true;G.busy=0;await NL.STORY.start(S,G);}
G.newGame=newGame;G.loadGame=loadGame;G.setState=s=>{S=s;};
G.rewind=async()=>{const go=$('#gameover');go.classList.remove('in');setTimeout(()=>go.hidden=true,400);G.busy=0;if(hasSave())await loadGame();else await newGame();};

/* ================= TITLE ================= */
function showTitle(){dlgHide();A.ringStop();document.body.classList.remove('coldopen','cine','talking');const t=$('#title');t.hidden=false;requestAnimationFrame(()=>t.classList.add('in'));$('#bCont').hidden=!hasSave();A.music('title');A.ambience('dark');}
function hideTitle(){const t=$('#title');t.classList.remove('in');setTimeout(()=>t.hidden=true,700);}
G.showTitle=showTitle;

/* ================= BOOT ================= */
let last=performance.now();
function frame(now){const dt=Math.min(0.05,(now-last)/1000);last=now;
  try{
    if(Wd.world){Wd.world.resize();const hu=G.hunger();Wd.world.hunger+=((hu?0.25+hu*0.19:0)-Wd.world.hunger)*Math.min(1,dt*2);const dw=S.time>=450?Math.min(1,(S.time-450)/30):0;Wd.world.dawn+=(dw-Wd.world.dawn)*Math.min(1,dt);eyeGlowTick();Wd.world.frame(dt);updateMarkers();barks();stepSounds(dt);}
    if(!NL.noDraw&&portrait&&pCanvas.isConnected&&pCanvas.offsetParent!==null&&!pCanvas.closest('#snapHost'))portrait.render(dt,now/1000);
    if(!$('#rain').hidden)rainFrame(dt);
  }catch(e){console.error(e);}
  requestAnimationFrame(frame);}
let stepT=0;function stepSounds(dt){const p=Wd.player;if(p&&p.speed>0){stepT-=dt;if(stepT<=0){stepT=0.34;A.sfx('step',{f:S.room==='alley'?1200:S.room==='freezer'?500:700});}}else stepT=0;}
const rain={drops:[]};
function rainFrame(dt){const c=$('#rain'),r=c.getBoundingClientRect(),d=Math.min(1.5,window.devicePixelRatio||1);if(c.width!==Math.round(r.width*d)){c.width=Math.round(r.width*d);c.height=Math.round(r.height*d);}
  const x=c.getContext('2d');x.clearRect(0,0,c.width,c.height);while(rain.drops.length<160)rain.drops.push({x:Math.random()*c.width,y:Math.random()*c.height,v:900+Math.random()*700,l:14+Math.random()*22});
  x.strokeStyle='rgba(190,205,230,.28)';x.lineWidth=1*d;x.beginPath();for(const p of rain.drops){p.y+=p.v*dt*d;p.x-=p.v*dt*d*0.18;if(p.y>c.height){p.y=-30;p.x=Math.random()*c.width*1.2;}x.moveTo(p.x,p.y);x.lineTo(p.x+p.l*0.18*d,p.y-p.l*d);}x.stroke();}
function boot(){
  const bootEl=$('#boot');if(bootEl)bootEl.remove();
  try{const v=JSON.parse(localStorage.getItem('newlord.vol')||'null');if(v)Object.assign(A.vol,v);}catch(e){}
  document.body.classList.toggle('still',!G.settings.motion);
  try{Wd.world=new NL.World($('#world'));}catch(e){$('#nogl').hidden=false;console.error(e);return;}
  Wd.world.visRect=visRect;Wd.world.fade=1;Wd.world.fadeTarget=1;
  $('#world').addEventListener('pointerup',onTap);
  /* tapping the text only skips ahead if the player turned that on: otherwise you can scroll back freely and only Continue advances */
  {let sy=0,sx=0,st=0;const dl=$('#dlg');dl.addEventListener('pointerdown',e=>{sx=e.clientX;sy=e.clientY;st=$('#feed').scrollTop;});
   dl.addEventListener('click',e=>{if(e.target.closest('button,a,input,select'))return;if(!G.settings.tapText)return;if(Math.abs(e.clientY-sy)>8||Math.abs(e.clientX-sx)>8||Math.abs($('#feed').scrollTop-st)>4)return;if(D.fastTap)D.fastTap();});}
  document.addEventListener('keydown',e=>{if(e.key===' '||e.key==='Enter'){if(D.fastTap){D.fastTap();e.preventDefault();}}
    const n=parseInt(e.key,10);if(n>=1&&n<=9){const b=document.querySelectorAll('#opts .opt:not([disabled])')[n-1];if(b){b.click();e.preventDefault();}}
    if(e.key==='Escape'&&$('#panel').classList.contains('in'))closePanel();});
  [$('#hud'),$('#tools')].filter(Boolean).forEach(el=>el.addEventListener('click',e=>{const b=e.target.closest('[data-p]');if(!b)return;const p=b.dataset.p;if(p==='eye'){$('#markers').classList.toggle('all');A.sfx('click');return;}if(p==='map')return;openPanel(p);}));
  $('#ptabs').addEventListener('click',e=>{const b=e.target.closest('button');if(b){A.sfx('page');selItem=null;G.readOut=null;renderPanel(b.dataset.t);}});
  $('#pclose').onclick=closePanel;
  $('#bBegin').onclick=()=>{A.init();A.sfx('click');newGame();};
  $('#bCont').onclick=()=>{A.init();A.sfx('click');loadGame();};
  $('#bRewind').onclick=()=>{A.init();G.rewind();};
  $('#bGoTitle').onclick=()=>{const go=$('#gameover');go.classList.remove('in');go.hidden=true;G.busy=0;showTitle();};
  document.addEventListener('pointerdown',()=>{if(A.ctx&&A.ctx.state==='suspended')A.ctx.resume();},{passive:true});
  refreshHUD();
  const hot=window.claude&&window.claude.hot;
  if(hot&&hot.snapshot){hot.snapshot(()=>({S}));}
  const restore=d=>{if(d&&d.S&&d.S.chapter&&d.S.chapter!=='cold'){S=Object.assign(newState(),d.S);hideTitle();$('#title').hidden=true;enterRoom(S.room,null,{restorePos:true,noEnter:true,instant:true});return true;}return false;};
  const start=d=>{if(!restore(d))showTitle();};
  if(hot&&hot.ready)hot.ready(start);else start(hot&&hot.data||{});
  requestAnimationFrame(frame);
}
G.boot=boot;
function fontsReady(){if(!document.fonts||!document.fonts.load)return Promise.resolve();
  const want=['700 40px "Bodoni Moda"','italic 700 40px "Bodoni Moda"','700 20px "Barlow Condensed"','800 20px "Barlow Condensed"','20px Caveat','20px Spectral'];
  return Promise.race([Promise.all(want.map(f=>document.fonts.load(f).catch(()=>null))),sleep(2500)]);}
let booted=false;const go=()=>{if(booted)return;booted=true;boot();};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>fontsReady().then(go));
else fontsReady().then(go);
})();
