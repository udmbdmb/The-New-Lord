'use strict';
/* THE NEW LORD — Night Four, part one: Leo's gig in Elysium, Tariq under curfew, Pemberton, Gideon, Tiny, Mrs. Okafor, the Sheriff's study above the Courthouse, and "Halloran Street, 2011" (Miller's brother) */
(function(){
const X=NL.EXTRAS,S_=NL.Script;
X.teo={n:'Teo',color:'#b0c890',role:'Local 0 · clanless',spec:{face:{long:1.02,cheek:1.2,jaw:0.9},skin:[.72,.56,.44],hair:{style:'curly',color:[.08,.06,.05]},shirt:[.2,.35,.25],coat:{color:[.25,.22,.18],length:.4,collar:true},pants:[.15,.15,.18],eyes:[.6,.45,.2],eyeGlow:[.4,.25,.05],height:.96}};
Object.assign(NL.ITEMS,{
  princefile:{n:'The Prince File',type:'read',d:'A buff folder tied with red ribbon, from the Sheriff\'s desk. LANTERN: photographs of Harrow, Rostova\'s trial protocols, seven names, a federal budget line. Prepared for the Prince. Never delivered.'},
  agnesletters:{n:'Agnes\'s Letters',type:'read',d:'A shoebox of letters in a typist\'s neat hand, 1924–1961. "Today the harbour was the color of a pigeon\'s neck."'},
  mateophoto:{n:'Mateo\'s Photograph',type:'read',d:'A school photo from 2010: a boy with curly hair and a gap in his teeth. On the back, in Miller\'s handwriting: "M., 18. Find him."'}
});
S_.npc({id:'teo',room:'switchyard',at:[10.6,5.6,-2.4],pose:'lean',label:'A clanless boy',if:'night>=4&night<=5&task:s_mateo=active&flag:mateoLead&!flag:teoGone',node:{first:'teo.0',again:'teo.hub'}});
S_.place({id:'courthouse',name:'The Courthouse',block:'B',sub:'The Sheriff\'s rooms, above the night clerk\'s office.',if:'night>=3&night<=5&flag:mapOK&!flag:studyDone',node:'st.0',min:16});
})();
NL.Script.add(String.raw`
// =====================================================================
// LEO · Night Four · the gig
// =====================================================================
# lx4.0 arc=leo night=4 label="\"Are you still doing Thursday?\"" if=room:apt&leo:here&flag:leoGig&!flag:leoGig=no&!flag:leoGigCancelled
@focus leo
> Leo is ironing a shirt. He has never ironed a shirt before. You can tell, because there's a scorch mark the shape of Florida on the back of it.
leo: Eleven o'clock. Downstairs at the Reliquary. Five hundred dollars. I've got fifteen minutes of material and a shirt with Florida on it.
@gate flag:leoGig=guarded ? lx4.guarded : lx4.alone

# lx4.guarded
leo: And you're coming. You said. You said you'd stand there and nobody would eat me. I'm holding you to that. Legally. Spiritually. I'm holding you to it with both hands.
* "I'll be there. Eleven."  -> lx4.there {do lean:loyalty+1}
* "Change of plan. Don't go."  -> lx4.dontgo

# lx4.alone
leo: I'm going by myself. Which is fine. Which is very brave. Which I keep saying out loud in the hope that it becomes true.
* "I'll come with you."  -> lx4.come {do flag:leoGig=guarded; promise:leogig:Stand by Leo at his Reliquary gig on Thursday; lean:loyalty+1}
* "Don't go."  -> lx4.dontgo
* "Good luck."  -> lx4.luck

# lx4.there
leo: Eleven. Okay. If I die I'm going to haunt you. Can a ghost haunt a vampire? Is that like a double negative?
@next lx4.hub

# lx4.come
leo: Really? Oh thank God. Thank God. I was going to wear a crucifix. Under the shirt. Junie mailed me one. It's from a cereal box.
@next lx4.hub

# lx4.dontgo
leo: Don't GO? I've ironed a SHIRT.
? velvet 9 "They're going to use you to find out what you saw on Monday. Then they'll keep you."  -> lx4.dontok | lx4.dontno {id lx4_dont} {mod like:leo}

# lx4.dontok
leo: Keep me. Like a pet. Like a pet comedian. Okay. Okay, that's... specific. Okay.
leo: I'll call in sick. I've never called in sick to anything. I've done open mics with food poisoning.
{do flag:leoGig=no; flag:leoGigCancelled=1; mem:leo:gigcancelled; rel:leo+1}
@next lx4.hub

# lx4.dontno
leo: No. No. I'm going. This is the first time anyone's ever paid me to be funny. I'm not giving that up because you've got a bad feeling. You've ALWAYS got a bad feeling. You're a vampire, a bad feeling is your resting face.
@next lx4.hub

# lx4.luck
leo: Thanks. "Good luck." Like I'm going to a job interview. In a basement. Full of. Yeah.
pulse(5): He wanted you to say you'd come.
@next lx4.hub

# lx4.hub
* "What's the opener?"  -> lx4.opener {once}
* "Junie mailed you a crucifix?"  -> lx4.junie {once}
* "I'll see you there."  -> lx4.bye

# lx4.opener
leo: The freezer. Obviously. "On Monday I got locked in a walk-in freezer with a dead guy and a stranger. That's not a joke. That's my CV." Beat. "The dead guy was the nicest one."
stagecraft(5): It's good. It's very good. And in a room full of Kindred, the line about the dead guy is going to land on three hundred people who knew him.
@next lx4.hub

# lx4.junie
leo: She's on the coast. She's a nurse. She heard "weird" in my voice and decided it meant cult, so she's mailing me crucifixes and articles about deprogramming. She's coming up on Saturday to "check on me". If I'm alive on Saturday.
{do flag:junieSaturday=1}
@next lx4.hub

# lx4.bye
leo: Eleven. Florida shirt. Don't be late. Actually do be late. Be exactly on time. I don't know how vampires do time.
@end

// the gig itself, in the VIP crypt, between 10:40 PM and 12:30 AM
# gig.0
@do tick:30
> They've put a microphone stand in front of the bone chandelier, and a single spotlight, and forty chairs. The chairs are full. The Gilded Court in evening dress. A few Syndicate men in leather at the back, arms folded. Lisette in red by the door. Lord Ashby in the front row with his quizzing glass. And Séverine, on her sarcophagus, like a queen at a hanging.
> Leo walks out into the light in his Florida shirt. He looks at the room. The room looks at him. You can hear him swallow from the back.
leo: Hi. Hello. Good evening. I'm Leo. I'm... you guys are very quiet. That's fine. I've played to quieter. I've played to a funeral, actually, once, a cousin's, it was a mistake.
@gate flag:leoGig=guarded ? gig.you : gig.alone

# gig.you
> He finds you at the back. His shoulders come down an inch.
leo: On Monday I got locked in a walk-in freezer with a dead guy and a stranger. That's not a joke. That's my CV.
> Silence. Then, from Lord Ashby, a single bark of laughter.
leo: The dead guy was the nicest one.
> And there it is: a ripple. Not laughter. A ripple. Three hundred years of dead faces doing something they haven't done in a long time.
* Laugh. Out loud. Give him the room.  -> gig.laugh {do lean:pride-1}
? web 10 Don't laugh. Watch the room. Who doesn't laugh?  -> gig.watch | gig.watchno {id gig_web}
* Watch Séverine.  -> gig.sev

# gig.laugh
> You laugh. Really laugh, the way you would have when you were warm. It's a strange sound in Elysium. A few heads turn. Then a few more people laugh, because now it's allowed.
> Leo does fifteen minutes. The landlord. The meat counter. His mother. The detective with the coffee. When he gets to "Margo said lock the walk-in, Leonard, and she never says Leonard," a woman in the third row drops her glass.
leo: Thank you! You've been. Weird. You've been a very weird crowd. Goodnight!
{do flag:gigLaughed=1; mem:leo:laughed; rel:leo+2; xp:30:The night shift}
@next gig.after

# gig.watch
> You don't laugh. You watch.
> Ashby laughs at everything. Lisette laughs at nothing. Two Syndicate men laugh on cue, glancing at each other. And when Leo says "Margo said lock the walk-in, Leonard, and she never says Leonard," three people don't move at all.
> Séverine. A Court lady in grey pearls you don't know. And a man at the very back in a grey suit and dark glasses, who has no business in Elysium, and who leaves, quietly, before the applause.
web: Séverine knew about the door. The grey lady knew about the door. And Harrow's man was in the room to see who else did.
{do flag:gigWatched=1; flag:knowGreyPearls=1; flag:lanternInElysium=1; mem:leo:watched; xp:40:Faces}
@next gig.after

# gig.watchno
> You watch, but the room is a wall of stillness. Dead faces don't do what living faces do. By the time you've learned to read one, Leo is saying goodnight.
@next gig.after

# gig.sev
> She watches Leo the whole way through. When he gets to the door, Margo, *Leonard*, her fingers tighten very slightly on the edge of the sarcophagus. Then she smiles, slowly, and claps three times, and the whole Court claps with her.
severine: Charming. Utterly charming. Lisette, pay the boy double. And give him a drink. Something mortal.
pulse(5): She's making sure everyone sees her being gracious. She's making sure everyone sees she isn't frightened of him.
{do flag:gigSevWatched=1}
@next gig.after

# gig.alone
> His eyes go along the back wall looking for someone. They don't find them. He grips the mic stand.
leo: On Monday I got locked in a walk-in freezer. With. Um.
> He loses it. The line, the timing, all of it. Ashby laughs anyway, kindly, the way you'd laugh at a child. Leo does nine minutes. Nobody else laughs. When he gets to "Margo said lock the walk-in, Leonard," Séverine stands up.
severine: Thank you, young man. That will do. Lisette: take him somewhere quiet. I'd like to talk to him about Mrs. Kowalski.
@next gig.taken

# gig.taken
> You're there. You came late. You're standing in the doorway in time to see Lisette's hand on Leo's elbow, steering him toward the little chapel with the monks.
* "He's with me." Walk straight across the crypt.  -> gig.claim {do lean:pride+1}
? stagecraft 11 Catch Leo's eye and fake a fire alarm from the stairwell.  -> gig.alarm | gig.alarmno {id gig_stage}
* Let them take him. You can't fight the Court in Elysium.  -> gig.let {do lean:loyalty-2}

# gig.claim
severine: With you. Is he.
> Three hundred heads turn. Séverine looks at you down the length of her own crypt, and for a moment you're quite sure she's going to have you staked in front of everyone. Then she sighs.
severine: Very well. Keep your comedian. But you owe me a conversation about what he knows, before Friday, and you'll have it with me in private, and you'll be honest.
{do flag:leoGig=claimed; flag:sevOwedTalk=1; mem:leo:claimed; rel:leo+2; rel:severine-1}
@next gig.after

# gig.alarm
> A bell, a shout of FIRE from the stairwell in a voice that sounds exactly like Tiny's. Mortal staff panic in the right direction. In the confusion Leo is suddenly beside you on the stairs, white as a sheet, clutching five hundred dollars.
leo: Was that you? Was that... that was you. That was a really good Tiny.
{do flag:leoGig=escaped; mem:leo:alarm; rel:leo+1; heat+1}
@next gig.after

# gig.alarmno
> Your fire alarm comes out as a strangled shout. Lisette looks round at you with real pity and keeps walking.
@next gig.let

# gig.let
> The chapel door closes behind them. You go up the stairs alone.
tenant: She won't hurt him. Not much. She'll take what he saw on Monday and keep him for a while, the way one keeps a souvenir. He'll come out of that chapel adoring her. That's the worst part.
{do flag:leoCourt=1; flag:leoGig=taken; mem:leo:abandoned; rel:leo-2; break:leogig}
@end

# gig.after
@gate flag:leoGig=taken ? gig.end : gig.after2

# gig.after2
> Afterwards, on the stairs, Leo sits down on the loose third step and puts his head between his knees.
leo: I did it. I did fifteen minutes in a vampire nightclub. Or nine. Or. I don't know. I don't know how long it was. Was it good? It felt good. It felt like being hit by a car in slow motion in a good way.
leo: Five hundred dollars. Double. A thousand. They paid me a thousand dollars. I'm going to buy Gerald a friend.
{do keep:leogig; flag:leoGigDone=1}
@next gig.end

# gig.end
@end

// =====================================================================
// TARIQ · Night Four · under the curfew
// =====================================================================
# tx4.0 arc=tariq night=4 label="\"You're still open?\"" if=room:luckymart
@focus tariq
> The floodlights from the crossing at Ferrier and Vine sweep across the shop window every forty seconds, white-violet, and every forty seconds everything in the Lucky Mart throws a shadow the wrong way. Tariq has taped cardboard over half the glass.
tariq: Open. Of course open. Curfew is for people. Shops are not people. Shops are... infrastructure.
tariq: Nobody's come in since ten. Except a policeman, who bought nothing and asked if I'd seen "anyone pale". I said I live on the Abattoir Strip, sir, everyone here is pale, it's the lighting.
@gate mem:tariq.afraid ? tx4.afraid : tx4.normal

# tx4.afraid
> He doesn't come out from behind the counter. He doesn't tell you to leave either.
tariq: I said please don't come in for a while.
* "I know. I'm sorry. I'll go."  -> tx4.go {do lean:mercy+1}
* "I need to know you're all right."  -> tx4.check
* "Tariq. Please."  -> tx4.please

# tx4.go
tariq: ...Wait. Wait. Stay a minute. I'm afraid of you and I'm afraid of the lights. You I know. The lights I don't.
@next tx4.normal

# tx4.check
tariq: All right. I'm all right. I'm scared all the time now instead of only on Wednesdays. That's progress.
@next tx4.normal

# tx4.please
tariq: Okay. Okay. Come in. Mind the cardboard.
@next tx4.normal

# tx4.normal
* "What are the lights doing to the street?"  -> tx4.lights
* "Close the shop. Go home."  -> tx4.home
* "Tomorrow's Friday. Something big is happening."  -> tx4.friday

# tx4.lights
tariq: The cats are gone. Mr. Halloran's cats. All thirty. He was out at nine crying in the street. The man from the Rookery who sleeps behind the bins has burns on his hands. Little ones. Like sunburn. In November.
tariq: And something walked past at three last night. Like before. Tall. But this time it ran. It ran from the light. I have never seen it run.
tenant: Valko, probably. Or one of the old Hounds. They're not used to running in their own city.
{do mem:tariq:lights}
@next tx4.hub

# tx4.home
tariq: Home. My home is a flat above a launderette where I lie on the bed and think about the shop. I would rather be in the shop and think about the flat.
tariq: Also, if I close, who will be open? Somebody should be open. If something happens tonight, somebody should be here with a light on.
{do mem:tariq:stays}
@next tx4.hub

# tx4.friday
tariq: Big. How big? Flood big? Riot big? Big like 2019 big?
* Tell him to stay inside on Friday, whatever he hears.  -> tx4.warn {do lean:mercy+1}
* "Big like the end of something."  -> tx4.end
* "Nothing you need to worry about."  -> tx4.lie {do lean:candour-1}

# tx4.warn
tariq: Inside. Whatever I hear. Okay. I'll put the radio on very loud and sweep.
tariq: You'll come back? After? To tell me if the world ended? I'll want to know.
{do flag:tariqWarned=1; mem:tariq:warned}
@next tx4.hub

# tx4.end
tariq: The end of something. Everybody always says that like it's bad. Some things should end.
{do mem:tariq:end}
@next tx4.hub

# tx4.lie
tariq: Okay. You're a very bad liar for a dead person. Your face does a thing too.
@next tx4.hub

# tx4.hub
* "Can I ask you something? Why bread and salt?"  -> tx4.salt {once} {if mem:tariq.salt}
* "Goodnight, Tariq."  -> tx4.bye

# tx4.salt
tariq: Because if you give a guest bread and salt, they're a guest. And a guest can't harm you in your house. It's the oldest law there is. Older than police. Older than your lot.
tariq: My grandmother gave bread and salt to a soldier in 1974 who came to burn the village. He ate it. He sat there crying. He didn't burn anything.
tariq: I don't know if it works on vampires. But you've never hurt me. So.
{do mem:tariq:saltstory; rel:tariq+1}
@next tx4.hub

# tx4.bye
tariq: Go with God. Or whoever. And mind the lights. They don't stop at the crossings any more. They're on the roofs now too.
@end

// =====================================================================
// PEMBERTON · Night Four
// =====================================================================
# px4.0 arc=pemberton night=4 label="\"Pemberton. One more drive?\"" if=flag:mapOK&!flag:pemDead&!flag:lastCall
@focus pemberton
pemberton: As many as you like, ‹sir›. The gas's on the Court's account. I've always assumed they'd notice one day.
pemberton: I wanted to say, before Friday, in case there's no occasion after: it's been an honour. A strange one. Somewhat like being honoured by a hurricane.
* "Don't talk like that."  -> px4.dont
* "What'll you do if I lose on Friday?"  -> px4.lose
* "What will you do if I win?"  -> px4.win
* "Did you love him?"  -> px4.love

# px4.dont
pemberton: Like what, ‹sir›? Sincerely? I apologize. It's the floodlights. They make everyone sentimental. We've all been looking at our own shadows all night.
@next px4.hub

# px4.lose
pemberton: If you lose, ‹sir›, I expect the Court will reassign me. Ghouls are furniture. I'll drive Lady Séverine, or Lord Ashby, or whoever, and polish their car, and say "very good, my lady" until the blood runs out.
@gate flag:pemFed ? px4.losefed : px4.loseunfed

# px4.losefed
pemberton: Except it's your blood now. So I suppose I'll simply... stop, when you do. One way or another. It's a very neat arrangement, when you think about it. I try not to.
@next px4.hub

# px4.loseunfed
pemberton: Or I'll retire. There's a cottage in Galway my sister left me. I've never seen it. I imagine it rains.
@next px4.hub

# px4.win
pemberton: If you win. If you're Sheriff. Then I'll drive you, ‹sir›, for as long as you'll have me. And I'll keep your calendar, and I'll remind you of birthdays, and I'll tell you when you're being an idiot, which he never let me do.
* "You can tell me now."  -> px4.idiot
* "I'd like that."  -> px4.like {do lean:loyalty+1; rel:pemberton+1}

# px4.idiot
pemberton: ‹Sir›. You are being an idiot about the Vessel, the Hound, the doctor, the boy, and the Lady, in roughly that order.
pemberton: Thank you. That felt wonderful. Forty-one years.
{do mem:pemberton:idiot; rel:pemberton+1}
@next px4.hub

# px4.like
pemberton: So would I, ‹sir›. So would I.
@next px4.hub

# px4.love
> He drives for a full block before he answers.
pemberton: I don't know what the word means for people like us. I'd have died for him. I very nearly did, in 1977. I knew how he took his tea, which he didn't drink, and which shirt he'd want, and when he wanted to be talked to and when he wanted to be driven very slowly round the harbour at four in the morning with nobody saying anything at all.
pemberton: If that's love, then yes. If it's habit, then it was a very good habit, and I'm going to miss it terribly.
tenant: ...I didn't know. I never asked. Forty-one years in the front seat and I never once asked him anything.
{do mem:pemberton:love; sync+2:The front seat}
@next px4.hub

# px4.hub
* "Drive me round the harbour. Slowly. Nobody say anything."  -> px4.harbour {once}
* "Let's go."  -> px4.go

# px4.harbour
> He drives you round the harbour. Slowly. The floodlights don't reach the water. The cranes stand over the black like herons. Nobody says anything for twenty minutes. It's the best twenty minutes of the week.
{do tick:20; comp+3:The harbour; mem:pemberton:harbour; rel:pemberton+1}
@next px4.hub

# px4.go
pemberton: Very good.
@end

// =====================================================================
// GIDEON · Night Four
// =====================================================================
# gx4.0 arc=gideon night=4 label="\"How are you holding up, Gideon?\"" if=room:pawn
@focus gideon
> Gideon has pulled the shutters down and is working by lamplight. On the counter, a box of shotgun shells, a rosary, a ledger and half a pork pie, which tells you everything about his week.
gideon: Holding up. Ha. The Court sent a man at eight to "count" my guests. I said I've got no guests, I've got boxes. He said "then I'll count the boxes". I said boxes are thirty dollars each to look at.
gideon: He paid. Hundred and twenty. He counted four boxes and left. I'll take that.
@gate flag:gideonGuardsMargo&task:s_margo=active ? gx4.margo : gx4.hub

# gx4.margo
gideon: Margo's in the back. She's been sitting in Séverine's box all day with the lid up, knitting. I don't know what. It's very long. It might be a scarf. It might be a noose.
@next gx4.hub

# gx4.hub
* "Why do you do this, Gideon? Really."  -> gx4.why {once}
* "If tomorrow goes badly, close the shop. Go somewhere."  -> gx4.leave {once}
* "Goodnight."  -> gx4.bye

# gx4.why
gideon: Really? Because my father did. Because I'm good at it. Because nobody else will. Because in 1971 a frightened girl in a fur coat came into my shop at dawn with blood on her mouth and said "please" and I'd never heard anyone say please like that.
gideon: Mostly because you're all so *alone*. You walk around for three hundred years and nobody makes you a cup of tea. I can make a cup of tea. That's all I've got. Tea and boxes.
{do mem:gideon:tea; rel:gideon+1}
@next gx4.hub

# gx4.leave
gideon: Close? On the busiest night in fifty years? I'll be rented out by midnight. Every Kindred in the Ward wants somewhere to hide for Friday.
gideon: No. Sunrise guaranteed. That's the rule.
@next gx4.hub

# gx4.bye
gideon: Bring the box back in one piece. That's what I tell everyone. Most of them do.
@end

// =====================================================================
// TINY · Night Four
// =====================================================================
# kx4.0 arc=tiny night=4 label="Look for Tiny on the door." if=room:reliquary
@focus tiny
@gate flag:tinyBetrayed ? kx4.betrayed : kx4.normal

# kx4.betrayed
> There's a new man on the door. Smaller. Meaner. He doesn't have a clicker. He doesn't have a list. He waves people in like a man swatting flies.
> Tiny's clicker is on the floor of the vestibule, cracked.
gutter(4): Gone. Nine years. You told the Lady about Harrow and the Lady asked who told *you*, and you said a name.
tenant: I told you, child. Slower than teeth.
* Ask the new man where Tiny is.  -> kx4.where
* Pick up the clicker.  -> kx4.clicker

# kx4.where
> The new man looks at you like a stain. He's a man called Gary, who tells you Tiny "retired" this afternoon. Somebody drove him home. Somebody "helped him with his bags".
{do flag:tinyGone=1}
@end

# kx4.clicker
> It still works. You click it once. The number reads 41,207. Nine years of faces.
{do flag:tinyGone=1; lean:loyalty-1; comp-1:Tiny}
@end

# kx4.normal
> Tiny is on the door with a scarf round his neck and a thermos at his feet, which he's never had before. He looks grey. He looks like a sidewalk.
tiny: Busy. Everybody wants to be counted before midnight. The whole Ward's in that crypt tonight. Nobody's dancing. They just stand there in their good clothes, waiting.
@gate done:s_tiny ? kx4.helped : kx4.nohelp

# kx4.helped
tiny: The kit's working. I did a session this afternoon. I feel... not grey. Beige. Beige is an improvement.
tiny: Whatever you need tomorrow. I said I'd stand up. I'll stand up. Then I'm walking off this door forever. I've told my mom. She said, "About time, Henry."
* "Henry?"  -> kx4.henry
* "You don't have to do it."  -> kx4.nottestify {do lean:mercy+1}

# kx4.henry
tiny: Don't. Nobody calls me Henry except her. I'm Tiny.
tiny: ...You can call me Henry. Once. After tomorrow. If we're both still here.
{do mem:tiny:henry; rel:tiny+1}
@end

# kx4.nottestify
tiny: I know I don't. That's why I'm doing it. First thing in nine years I've done because I chose to.
{do mem:tiny:chose}
@end

# kx4.nohelp
tiny: I'm fine. Don't ask. I'm a big lad, I'm fine.
pulse(5): He's not fine. His ankles are swollen over the tops of his shoes. His breath smells of ammonia. He's maybe a week from the hospital, maybe less.
* "St. Jude's has dialysis kits. I'll get you one."  -> kx4.kit {if !has:dialysis}
* Give him the dialysis kit.  -> kx4.give {if has:dialysis}
* "Take my blood. It'll keep you going."  -> kx4.blood {blood 1}
* "Take care of yourself, Tiny."  -> kx4.bye

# kx4.kit
tiny: You've said that. Don't say it again. Just do it or don't.
@end

# kx4.give
> He takes the box from you without a word and puts it behind the podium. Then he looks at you for a long time.
tiny: Nobody's ever brought me anything. Not once. Nine years.
{do take:dialysis; task:s_tiny=done; rel:tiny+2; lean:mercy+1; xp:40:Velvet Rope Blues; flag:tinyWitness=1}
@end

# kx4.blood
> He looks at your wrist. He looks at the queue. He looks at the crypt stairs.
tiny: Here? On my door? In front of everyone?
> Then he takes your wrist, quick, like a man taking a pill he's ashamed of, and drinks, and puts the scarf back over his mouth.
tiny: ...Oh. Oh, Christ. That's. That's what it is. That's what they all want.
tenant: You've just made a ghoul of the Lady's doorman on the Lady's doorstep. I'd love to see her face.
{do flag:tinyGhoul=1; task:s_tiny=done; rel:tiny+1; lean:mercy+1; mem:tiny:ghoul}
@end

# kx4.bye
tiny: Yeah. You too.
@end

// =====================================================================
// MRS. OKAFOR · Night Four
// =====================================================================
# ox4.0 arc=okafor night=4 label="Sit with her." if=room:apt&flag:met404
@focus okafor
> Mrs. Okafor has the radio on, low, tuned to something that crackles. She's knitting. She doesn't look up.
okafor: The lights outside. They came on at nine. I watched a man on the corner of Halloran get burned by one. Just his hand. He was reaching for a cigarette he'd dropped. I watched it go red.
okafor: What kind of light burns a man's hand in November?
@gate flag:daniTold ? ox4.told : ox4.nottold

# ox4.told
okafor: Since you told me, I sleep. Not well. But I sleep. The chimney's quiet now. Did you know? It stopped scratching on Wednesday.
@gate flag:ezraFree ? ox4.ezra : ox4.quiet

# ox4.ezra
okafor: Was that you, too? The scratching. Was there something in there?
* "Someone. He's free now."  -> ox4.ezratell {do lean:candour+1}
* "Rats, like Mr. Halloran said."  -> ox4.rats

# ox4.ezratell
okafor: Someone. In my chimney. For ten years.
> She puts the knitting down.
okafor: I used to talk to it. When I thought it was Dani. I used to tell it about my day.
{do mem:okafor:ezra}
@next ox4.hub

# ox4.rats
okafor: Rats. Yes. Mr. Halloran is always right. It's very annoying.
@next ox4.hub

# ox4.quiet
okafor: Funny. Ten years it scratched. And now nothing. I almost miss it.
@next ox4.hub

# ox4.nottold
okafor: You haven't come back to tell me. So you haven't found her. Or you have and you're being kind. Don't be kind. I've had a year of kind.
* Tell her. Now. All of it.  -> ox4.tell {if flag:knowSeven|flag:knowDaniDeath|seen:tr.0} {do lean:candour+1}
* "Tomorrow. After tomorrow I'll know everything."  -> ox4.tomorrow
* "I'm still looking."  -> ox4.looking

# ox4.tell
> You tell her. The trial. The roof. Twenty-two minutes in the sun, laughing. The doctor holding her head. The sheets. Kowalski's.
> She listens to all of it with her knitting in her lap. When you've finished she sits for a long time.
okafor: Twenty-two minutes. In the sun. Laughing.
okafor: She always did love the beach.
{do flag:daniTold=truth; keep:dani; comp+1:You told her; xp:30:Dani; mem:okafor:told}
@next ox4.hub

# ox4.tomorrow
okafor: Tomorrow. Everybody's waiting for tomorrow. All right. I'll wait.
@next ox4.hub

# ox4.looking
okafor: Looking. Yes. That's what Miller says. You sound like Miller.
@next ox4.hub

# ox4.hub
* "What are you knitting?"  -> ox4.knit {once}
* "Stay inside tomorrow night."  -> ox4.warn {once}
* "Goodnight, Mrs. Okafor."  -> ox4.bye

# ox4.knit
okafor: A scarf. Seven colors. One for each of them. When it's done I'm going to tie it to the railings outside St. Jude's and dare them to take it down.
{do flag:okaforScarf=1}
@next ox4.hub

# ox4.warn
okafor: Inside. Tomorrow's Friday. I go to the launderette on Fridays.
okafor: ...Fine. I'll go on Saturday. For you. But only because you never drink my tea and I'm starting to take it personally.
@next ox4.hub

# ox4.bye
okafor: Goodnight. Mind the lights.
@end

// =====================================================================
// THE SHERIFF'S STUDY · above the Courthouse
// =====================================================================
# st.0
> The Courthouse on Reliquary Row closes at six. The night clerk's office stays lit until dawn, because there has been a night clerk since 1871 and nobody has ever thought to stop paying one. The current night clerk is eighty, asleep at his desk under a reading lamp, and doesn't wake when Pemberton opens the side door with a key on his ring.
pemberton: Up the stairs, ‹sir›. Third floor. He kept rooms. I'll wait in the car. I... I'd rather not go up. If that's acceptable. {if !flag:pemDead}
> Three flights. A door with no name on it. It opens to the Sheriff's coat. It's never been locked. Nobody ever dared.
> The study. It's exactly the study from your dreams: the green lamp, the leather, the Bokhara rug with a path worn in it eleven steps long. The curtains stitched shut. The ledger on the desk. The photograph, face down.
tenant: ...Oh.
tenant: I didn't think I'd see it again. With eyes, I mean. It's smaller. Everything's smaller when you're dead.
* Read the ledger.  -> st.ledger
* Open the desk drawers.  -> st.drawers
* Turn the photograph over.  -> st.photo
* Sit in his chair.  -> st.chair

# st.ledger
> Eighty years of tithes in one patient hand. Every business in the Ward. Kowalski's: 10%. The Reliquary: 10%. The Pawn & Coffin: "exempt, by arrangement". The Lucky Mart: "exempt. He keeps a light on." Platform 0: "10%, paid in services, see M."
> The last page: *Sunday. Prince, Friday. Bring everything. Bring C.*
gutter(5): The Lucky Mart was exempt. Because Tariq kept a light on. The Sheriff of the Marrow Ward let one shop off for a lamp in a window.
{do flag:studyLedger=1; mem:tenant:ledger}
@next st.hub

# st.drawers
> Top drawer: fountain pens, a revolver from 1911 with silver bullets, a tin of mints from 1950, unopened. Second drawer: letters from Princes, Courts, Sheriffs of other Wards, a postcard from Valko in Prague in 1974 that just says *Good*.
> Bottom drawer, locked. The lock is old and the key is on Pemberton's ring, which you don't have, or it's a lock you can open some other way.
? autopsy 9 Feel for the mechanism. Old locks have a heartbeat.  -> st.file | st.fileno {id st_lock}
* Break it.  -> st.filebreak {if skill:apex>=3}
* Leave it.  -> st.hub

# st.file
> It gives with a click like a knuckle. Inside: a buff folder tied with red ribbon. On the front, in his hand: *For the Prince. Friday.*
> LANTERN. Harrow's photograph, his federal ID, his travel records. Rostova's protocols, signed and dated. Seven names on a list, with blood types. A budget line from a Department that doesn't exist: *Project LANTERN · Phase II · Hematological Countermeasures · $41,000,000*. And a single sheet in Vane's hand: *They mean to burn us all at once, with the Prince's Magistrate among us. The frequency is the key.*
web(6): This is it. This is what Vane died for. Everything, documented, for a Prince. The Magistrate would have to listen to this.
{do give:princefile; flag:havePrinceFile=1; xp:60:The Prince File; mem:tenant:princefile}
@next st.hub

# st.fileno
> The lock doesn't speak to you. It's a three-hundred-year-old Sheriff's lock and you're four days old.
@next st.hub

# st.filebreak
> You put your thumb through the brass. It's undignified. It works.
@next st.file

# st.photo
> Agnes, in her summer dress, laughing at something outside the frame. Under the frame, tucked into the back, a slip of paper in a typist's neat hand: *Does it hurt? — A.*
> And on the shelf behind the desk, a shoebox. Inside, hundreds of letters. *Today the harbour was the color of a pigeon's neck.* *Today a man on the tram was reading your favorite Dickens and I wanted to tell him he was reading it wrong.* *Today the sun was very bright and I thought of you, and I hoped it didn't make you sad that I could see it.*
tenant: Take them. Please. I can't bear them being here when nobody's here. Take them and read them to me sometimes. I'd like to hear them in a voice.
* Take the letters.  -> st.letters {do lean:mercy+1}
* Leave them. They belong here.  -> st.hub

# st.letters
{do give:agnesletters; flag:haveAgnesLetters=1; sync+3:Agnes's letters; mem:tenant:letters}
@next st.hub

# st.chair
> You sit in his chair. It knows the shape of somebody else. It doesn't like you. Then, slowly, it decides it doesn't mind.
> From here you can see the door, the window, the ledger and the photograph without moving your head. Eighty years of nights in this chair, watching the door.
@gate flag:seizure=surrender|sync>=60 ? st.chairhim : st.chairyou

# st.chairhim
> Your hand goes, by itself, to the inkwell. Your hand writes, by itself, in his beautiful copperplate, on the blotter: *Home.*
tenant: Sorry. Sorry. That was me. I didn't mean to.
{do sync+5:Home}
@next st.hub

# st.chairyou
> It's just a chair. It's a very good chair. You could get used to it. That frightens you more than anything this week.
{do lean:pride+1}
@next st.hub

# st.hub
* "Lisette wanted to know what's in here."  -> st.lisette {once} {if flag:lisetteWantsStudy}
* Leave the study.  -> st.leave

# st.lisette
> You could tell Lisette about the ledger. Or the photograph. Or nothing at all. Or you could take her something.
* Take a page from the ledger for Lisette.  -> st.lisettepage {do flag:lisettePage=1; lean:loyalty-1}
* Tell her nothing.  -> st.hub {do flag:lisetteNothing=1}

# st.lisettepage
> You tear out a page. Kowalski's tithes, 1971 to 1990. Ten percent, every month, in his patient hand.
tenant: Lisette. That little pickpocket. She'll use it to show the Court how much I stole. And she'd be right.
@next st.hub

# st.leave
> You turn off the green lamp. The study goes dark. It's the first time in eighty years, you think, that the lamp has been off at night.
{do flag:studyDone=1}
@end

// =====================================================================
// HALLORAN STREET, 2011 · Miller's brother
// =====================================================================
# ux4m.0 arc=soot night=3,4,5 label="\"Halloran Street. 2011. A boy called Mateo.\"" if=room:shrine&task:s_mateo=active&!flag:mateoLead prio=4
@focus soot
soot: Mateo. Mateo, Mateo. Halloran Street. Cigarettes. Two thousand and eleven.
> She doesn't go to a jar. She goes to a pipe, the oldest one, green with verdigris, and presses her ear to it and listens as if it might still be happening.
soot: He bought cigarettes at the kiosk that isn't there any more. He was walking home. A clanless girl was starving in the alley by the Rookery bins. Hungry, hungry. She hadn't eaten in a week. She was going to take him all the way.
soot: And then she didn't. She stopped. She made him instead. Because she was lonely. Mm. Mm. Because she was nineteen too.
soot: He's still in the Ward. He runs with the clanless now. The union boys. He calls himself Teo. He stands at the edge of Platform 0 with the others and watches the Court go by like a dog watches a butcher's van.
{do flag:mateoLead=1; note:s_mateo|Mateo Miller was Embraced in 2011 by a starving clanless girl. He's still in the Ward, calling himself Teo, running with the clanless on Platform 0.; mem:soot:mateo; rel:soot+1}
soot: That one's free. For the detective. I like the detective. She makes the pipes so *busy*.
@end

# teo.0
@focus teo
> At the far edge of Platform 0, where the light from the fire barrels gives up, a boy leans against a pillar with his hands in his pockets. Nineteen, maybe. Curly hair. A gap in his teeth when he smiles at someone else's joke, which he doesn't, much.
teo: You're the one. The Sheriff-eater. The union guys talk about you like you're a football result.
teo: What do you want? I'm not counted. I'm not on any list. That's the whole point of being me.
* "Your name's Mateo. Your sister's called Ines."  -> teo.name
* "How long have you been clanless?"  -> teo.howlong
* "Do you know a detective called Miller?"  -> teo.miller

# teo.name
> He stops leaning. The hands come out of the pockets.
teo: Don't. Nobody. Nobody says that name. How do you. Who told.
teo: She's still looking? Thirteen years? She's still...
pulse(5): Dead hearts don't race. His hands are shaking anyway.
@next teo.story

# teo.howlong
teo: Thirteen years. Since I was nineteen. Which I still am, apparently. Forever. Nineteen and buying cigarettes.
@next teo.story

# teo.miller
> His face does something terrible and then nothing at all.
teo: Missing Persons. Precinct 9. Yeah. I know her. Everyone on the Strip knows her. I see her sometimes. At the Lucky Mart. Two in the morning. Burnt coffee. I stand across the road and watch her through the window.
teo: She looks old. She looks so *old*.
@next teo.story

# teo.story
teo: Rina made me. In the alley. She was starving, she was going to kill me, she cried and said sorry the whole time, and then she couldn't do it and she gave me her blood instead and I woke up in a bin.
teo: She met the sun in 2014. On purpose. I was there. I've been on my own since.
teo: I couldn't go home. How do I go home? "Hi Ines, I'm dead, I drink people, can I have my old room back?" She'd arrest me. Or worse, she wouldn't.
* "She'd want to know you're alive."  -> teo.want {do lean:candour+1}
* "Then let her keep looking. It's kinder."  -> teo.kinder {do lean:candour-1}
* "Do you want to see her?"  -> teo.see

# teo.want
teo: Alive. I'm not alive. That's the whole problem.
@next teo.choice

# teo.kinder
teo: Kinder. Thirteen years of looking. Is that kind? I don't know. I don't know what's kind any more.
@next teo.choice

# teo.see
teo: Every night. Every single night. Through the window. That's as close as I get.
@next teo.choice

# teo.choice
teo: What do I do? You're the Sheriff-eater. Tell me what to do.
* "I'll bring her to you. After Friday. Somewhere safe."  -> teo.bring {do promise:mateo:Bring Ines Miller to her brother after Friday}
* "Write her a letter. I'll carry it."  -> teo.letter
* "Go to her yourself. Tonight. Before it's too late."  -> teo.go
* "It's your choice. Not mine."  -> teo.yours {do lean:loyalty+1}

# teo.bring
teo: After Friday. Safe. Okay. Okay. If there is an after.
{do flag:mateoPlan=bring; mem:teo:bring}
@next teo.photo

# teo.letter
> He writes it on the back of a flyer for Local 0, with a borrowed pen, crouched on the platform edge. It takes him a long time. He crosses out a lot. He doesn't let you see it.
teo: Don't read it. Just give it to her. Tell her I'm sorry about the cigarettes.
{do flag:mateoPlan=letter; flag:mateoLetter=1; mem:teo:letter}
@next teo.photo

# teo.go
teo: Tonight. Under the lights. With Precinct 9 on every corner and the whole Court counting.
teo: ...Yeah. Okay. If not now, when. She's at the Lucky Mart at two. I'll be across the road. I'll cross the road. I'll actually cross the road this time.
{do flag:mateoPlan=go; flag:teoGone=1; mem:teo:go}
@next teo.photo

# teo.yours
teo: My choice. Huh. Nobody's given me one of those since the alley.
teo: I'll think. I'll think about it. Tell her... no. Don't tell her anything. Not yet.
{do flag:mateoPlan=wait}
@next teo.photo

# teo.photo
> Before you go he takes something out of his jacket. A school photograph, soft with handling. Himself at eighteen with a gap in his teeth. On the back, in a woman's handwriting: *M., 18. Find him.*
teo: She put these on every lamppost in the Ward in 2011. I took one down. I've kept it. Give it to her. Then she'll know you met me. Then she'll know it's true.
{do give:mateophoto; task:s_mateo=done; xp:60:Halloran Street, 2011; mem:teo:photo}
@end

# teo.hub
teo: Still here. Still nineteen.
@end

// Miller gets the news (Night 4 or 5, wherever she is)
# ix4m.0 arc=miller night=4,5 label="\"Ines. I found Mateo.\"" if=has:mateophoto prio=6
@focus miller
> You put the school photograph down in front of her. Face down. Her own handwriting: *M., 18. Find him.*
> She doesn't pick it up. She looks at it for a very long time. Then she turns it over with one finger, the way you'd turn over a card you already know is the one you didn't want.
miller: Where did you get this.
* "From him. He's alive. In a way."  -> ix4m.alive {do lean:candour+1}
* "He's gone, Ines. But he wanted you to have it."  -> ix4m.lie {do lean:candour-1}

# ix4m.alive
miller: In a way.
miller: "In a way". Like you're alive "in a way". Like you don't blink "in a way".
> She stands up. She sits down again. She picks up her coffee and puts it down without drinking it.
miller: He's one of you. Isn't he. My little brother is one of you.
@gate flag:mateoPlan=go ? ix4m.go : ix4m.next

# ix4m.next
@gate flag:mateoLetter ? ix4m.letter : ix4m.where

# ix4m.go
miller: ...He came. Last night. Across the road. He stood in the door of the Lucky Mart and he didn't come in, and I didn't know him, and then I did.
miller: He said "Sorry about the cigarettes." That's all. Then the floodlight came round and he ran.
miller: Thirteen years and he apologized about cigarettes.
{do flag:millerMetMateo=1; mem:miller:mateo2; rel:miller+2; lean:mercy+1}
@next ix4m.end

# ix4m.letter
> You give her the flyer. Local 0, on the front. On the back, a lot of crossings-out and then four lines she reads with her hand over her mouth.
miller: ...That's his handwriting. That's his terrible handwriting.
{do flag:millerLetter=1; mem:miller:mateo2; rel:miller+2}
@next ix4m.end

# ix4m.where
miller: Where is he. Tell me where he is. I'll go now. I'll go right now, I don't care about the lights, I don't care about —
@gate flag:mateoPlan=bring ? ix4m.bring : ix4m.wait

# ix4m.bring
* "After Friday. I'll bring you to him. I promised him."  -> ix4m.end {do mem:miller:after}

# ix4m.wait
* "He's not ready. Give him time."  -> ix4m.end {do mem:miller:wait}
* Tell her: the edge of Platform 0.  -> ix4m.told {do lean:candour+1}

# ix4m.told
miller: Platform 0. Under the Switchyard. Where the other ones go.
miller: Okay. Okay. Friday. Whatever happens on Friday, I'm going down there.
{do flag:millerKnowsTeo=1}
@next ix4m.end

# ix4m.lie
miller: Gone. Okay.
> She looks at the photograph for a long time.
miller: Thank you. For telling me. I've had thirteen years to get ready for "gone". It turns out you can't.
{do flag:millerMateoGone=1; mem:miller:mateolie}
@next ix4m.end

# ix4m.end
miller: I'm going to keep this. Is that all right? I'm going to keep it.
{do take:mateophoto; flag:millerHasPhoto=1; rel:miller+1}
@end
`,'c_n4a');

// the gig: entering the VIP crypt while Leo is booked
NL.Act.pushEnter('vip',async(S,G)=>{if(S.night===4&&S.flags.leoGig&&S.flags.leoGig!=='no'&&!S.flags.leoGigCancelled&&!S.flags.leoGigDone&&!S.flags.leoCourt&&S.time>=100&&S.time<=210&&NL.Act.leoState(S)==='here'&&G.once('gig'))await G.talk('gig.0');});
// if Leo went alone and you never came, the Court keeps him
NL.Camp.tickHooks.push((S,G)=>{if(S.night===4&&S.time>=215&&S.flags.leoGig&&S.flags.leoGig!=='no'&&!S.flags.leoGigCancelled&&!S.flags.leoGigDone&&!S.flags.leoCourt&&!S.once.gig&&NL.Act.leoState(S)==='here'){S.flags.leoCourt=1;S.flags.leoGig='taken';G.text('Leo','did the set. they want me to stay after. the red lady says the boss wants to talk about margo. is that ok?? is this ok');if(S.promises.leogig)G.breakPromise('leogig');}});
