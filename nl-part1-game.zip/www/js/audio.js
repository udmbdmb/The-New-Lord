'use strict';
/* THE NEW LORD — generative WebAudio: ambience, score, sfx */
(function(){
const NL=window.NL;
const A={ctx:null,on:false,vol:{master:.8,music:.6,sfx:.8,amb:.7},layers:{},musicNodes:[],loops:{}};
function noiseBuf(ctx,sec){const b=ctx.createBuffer(1,ctx.sampleRate*sec,ctx.sampleRate),d=b.getChannelData(0);let last=0;for(let i=0;i<d.length;i++){const w=Math.random()*2-1;last=(last+0.02*w)/1.02;d[i]=w*0.6+last*3;}return b;}
function impulse(ctx,sec,decay){const n=ctx.sampleRate*sec,b=ctx.createBuffer(2,n,ctx.sampleRate);for(let c=0;c<2;c++){const d=b.getChannelData(c);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,decay);}return b;}
A.init=function(){
  if(A.ctx){if(A.ctx.state==='suspended')A.ctx.resume();return;}
  const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
  const ctx=A.ctx=new C();A.on=true;
  A.master=ctx.createGain();A.master.gain.value=A.vol.master;A.master.connect(ctx.destination);
  const comp=ctx.createDynamicsCompressor();comp.threshold.value=-18;comp.ratio.value=3;comp.connect(A.master);
  A.out=comp;
  A.rev=ctx.createConvolver();A.rev.buffer=impulse(ctx,3.2,2.6);A.revGain=ctx.createGain();A.revGain.gain.value=.55;A.rev.connect(A.revGain);A.revGain.connect(comp);
  A.mus=ctx.createGain();A.mus.gain.value=A.vol.music;A.mus.connect(comp);A.mus.connect(A.rev);
  A.fx=ctx.createGain();A.fx.gain.value=A.vol.sfx;A.fx.connect(comp);
  A.fxRev=ctx.createGain();A.fxRev.gain.value=.35;A.fx.connect(A.fxRev);A.fxRev.connect(A.rev);
  A.amb=ctx.createGain();A.amb.gain.value=A.vol.amb;A.amb.connect(comp);
  A.noise=noiseBuf(ctx,3);
};
A.setVol=function(k,v){A.vol[k]=v;if(!A.ctx)return;const map={master:A.master,music:A.mus,sfx:A.fx,amb:A.amb};if(map[k])map[k].gain.setTargetAtTime(v,A.ctx.currentTime,.1);};
const now=()=>A.ctx.currentTime;
function osc(type,f,g,dest,t0,dur,o){o=o||{};const ctx=A.ctx,os=ctx.createOscillator(),ga=ctx.createGain();os.type=type;os.frequency.setValueAtTime(f,t0);if(o.to)os.frequency.exponentialRampToValueAtTime(o.to,t0+(o.toT||dur));if(o.detune)os.detune.value=o.detune;
  ga.gain.setValueAtTime(0.0001,t0);ga.gain.exponentialRampToValueAtTime(g,t0+(o.a||0.005));ga.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
  let n=os;if(o.lp){const f2=ctx.createBiquadFilter();f2.type='lowpass';f2.frequency.value=o.lp;os.connect(f2);n=f2;}n.connect(ga);ga.connect(dest);os.start(t0);os.stop(t0+dur+.05);return os;}
function nz(g,dest,t0,dur,o){o=o||{};const ctx=A.ctx,s=ctx.createBufferSource();s.buffer=A.noise;s.loop=true;const f=ctx.createBiquadFilter();f.type=o.type||'bandpass';f.frequency.setValueAtTime(o.f||1000,t0);if(o.to)f.frequency.exponentialRampToValueAtTime(o.to,t0+dur);f.Q.value=o.q||1;
  const ga=ctx.createGain();ga.gain.setValueAtTime(0.0001,t0);ga.gain.exponentialRampToValueAtTime(g,t0+(o.a||0.005));ga.gain.exponentialRampToValueAtTime(0.0001,t0+dur);s.connect(f);f.connect(ga);ga.connect(dest);s.start(t0,Math.random()*2);s.stop(t0+dur+.05);}
A.sfx=function(name,o){if(!A.ctx||A.ctx.state!=='running')return;const t=now(),fx=A.fx;o=o||{};
  switch(name){
    case 'click':osc('sine',1400,.06,fx,t,.05);osc('triangle',700,.04,fx,t,.04);break;
    case 'hover':osc('sine',2200,.015,fx,t,.03);break;
    case 'open':osc('triangle',330,.05,fx,t,.25,{to:495});nz(.03,fx,t,.2,{f:3000,q:.5});break;
    case 'close':osc('triangle',495,.05,fx,t,.22,{to:330});break;
    case 'page':nz(.08,fx,t,.28,{f:2500,to:6000,q:.6,a:.04});break;
    case 'dice':for(let i=0;i<7;i++){const tt=t+i*0.055+Math.random()*.02;nz(.18,fx,tt,.04,{f:2200+Math.random()*1800,q:4});osc('square',180+Math.random()*120,.03,fx,tt,.03);}osc('sine',90,.25,fx,t+.42,.18);nz(.15,fx,t+.42,.12,{f:600,q:1});break;
    case 'success':osc('triangle',523,.12,fx,t,.5);osc('triangle',784,.12,fx,t+.09,.7);osc('sine',1046,.06,fx,t+.18,.9);break;
    case 'fail':osc('sine',110,.3,fx,t,.6,{to:70});nz(.12,fx,t,.3,{f:300,q:.7});osc('sawtooth',155,.05,fx,t,.4,{lp:500});break;
    case 'push':A.sfx('beat');setTimeout(()=>A.sfx('beat'),380);nz(.2,fx,t+.1,.9,{f:200,to:1800,q:.8,a:.3});osc('sawtooth',55,.12,fx,t,1.2,{lp:300,a:.3});break;
    case 'beat':osc('sine',62,.5,fx,t,.18,{to:40});osc('sine',58,.35,fx,t+.16,.2,{to:38});break;
    case 'door':osc('sine',70,.4,fx,t,.5,{to:45});nz(.15,fx,t,.6,{f:400,q:2});nz(.05,fx,t+.1,.9,{f:1800,to:900,q:8});break;
    case 'metal':nz(.2,fx,t,1.2,{f:900,to:300,q:12});osc('square',140,.05,fx,t,.6,{lp:900});osc('sine',60,.5,fx,t,.4);break;
    case 'crash':nz(.5,fx,t,1.4,{f:600,q:.5});osc('sine',50,.7,fx,t,.8,{to:30});nz(.2,fx,t+.05,1.6,{f:2600,to:800,q:10});break;
    case 'knock':for(let i=0;i<(o.n||3);i++){const tt=t+i*.32;osc('sine',95,.55,fx,tt,.16,{to:60});nz(.2,fx,tt,.08,{f:300,q:1});nz(.06,fx,tt,.25,{f:2400,q:10});}break;
    case 'rattle':for(let i=0;i<9;i++){const tt=t+i*.05;nz(.12,fx,tt,.05,{f:1800+Math.random()*900,q:6});}break;
    case 'horn':osc('square',349,.08,fx,t,.55,{lp:1500,a:.02});osc('square',440,.08,fx,t,.55,{lp:1500,a:.02});osc('square',349,.08,fx,t+.75,.4,{lp:1500,a:.02});osc('square',440,.08,fx,t+.75,.4,{lp:1500,a:.02});break;
    case 'item':[880,1108,1318,1760].forEach((f,i)=>osc('triangle',f,.06,fx,t+i*.06,.5));break;
    case 'thought':osc('sine',196,.22,fx,t,3.5,{a:.05});osc('sine',294,.12,fx,t+.02,3,{a:.05});osc('sine',392,.06,fx,t+.04,2.5,{a:.05});break;
    case 'xp':osc('triangle',660,.06,fx,t,.3);osc('triangle',880,.06,fx,t+.07,.4);break;
    case 'level':[392,494,587,784].forEach((f,i)=>osc('triangle',f,.1,fx,t+i*.1,1.2));break;
    case 'hurt':osc('sawtooth',220,.12,fx,t,.6,{to:180,lp:900});osc('sawtooth',233,.12,fx,t,.6,{to:170,lp:900});nz(.1,fx,t,.4,{f:500,q:.5});break;
    case 'drink':for(let i=0;i<4;i++){osc('sine',180-i*12,.25,fx,t+i*.32,.22,{to:120});nz(.06,fx,t+i*.32,.2,{f:500,q:2});}osc('sine',62,.4,fx,t+1.4,.6);break;
    case 'breach':nz(.4,fx,t,1.6,{f:400,to:5000,q:3,a:.2});osc('sawtooth',110,.2,fx,t,1.5,{to:660,lp:2000});break;
    case 'hiss':nz(.25,fx,t,.9,{f:5000,q:.6,a:.05});break;
    case 'ring':osc('sine',440,.07,fx,t,1.6,{a:.01});osc('sine',480,.07,fx,t,1.6,{a:.01});break;
    case 'flip':nz(.15,fx,t,.08,{f:3500,q:2});osc('square',900,.03,fx,t+.02,.04);break;
    case 'card':nz(.25,fx,t,2.2,{f:200,to:60,q:.6,a:.3});osc('sine',41,.4,fx,t,3,{a:.4});break;
    case 'step':nz(.05,fx,t,.07,{f:o.f||700,q:1.4});break;
    case 'swoosh':nz(.15,fx,t,.6,{f:400,to:3000,q:1,a:.2});break;
    case 'sting':osc('sawtooth',98,.12,fx,t,2.2,{lp:700,a:.08});osc('sawtooth',104,.1,fx,t,2.2,{lp:700,a:.08});osc('sine',49,.3,fx,t,2.5,{a:.1});break;
    case 'dawn':nz(.15,fx,t,3,{f:300,to:4000,q:.5,a:1.5});osc('sine',523,.06,fx,t+1,2.5,{a:.8});break;
    case 'zippo':nz(.2,fx,t,.05,{f:4000,q:3});nz(.12,fx,t+.12,.6,{f:900,q:.5,a:.05});break;
  }
};
/* ---- looping phone ring ---- */
A.ringStart=function(){A.ringStop();const go=()=>{A.sfx('ring');A._r2=setTimeout(()=>A.sfx('ring'),2000);};go();A._ring=setInterval(go,6000);};
A.ringStop=function(){clearInterval(A._ring);clearTimeout(A._r2);A._ring=null;};
/* ---- ambience ---- */
A.ambience=function(key){if(!A.ctx)return;if(A.curAmb===key)return;A.curAmb=key;const ctx=A.ctx,t=now();
  Object.values(A.layers).forEach(L=>{L.g.gain.setTargetAtTime(0,t,.6);setTimeout(()=>{L.nodes.forEach(n=>{try{n.stop();}catch(e){}});clearInterval(L.iv);},3000);});A.layers={};
  if(!key)return;const g=ctx.createGain();g.gain.value=0;g.connect(A.amb);g.gain.setTargetAtTime(1,t,1.2);const nodes=[];let iv=null;
  const tone=(type,f,gain,lp,lfo)=>{const o=ctx.createOscillator(),ga=ctx.createGain(),fl=ctx.createBiquadFilter();o.type=type;o.frequency.value=f;fl.type='lowpass';fl.frequency.value=lp;ga.gain.value=gain;o.connect(fl);fl.connect(ga);ga.connect(g);o.start();nodes.push(o);
    if(lfo){const l=ctx.createOscillator(),lg=ctx.createGain();l.frequency.value=lfo[0];lg.gain.value=lfo[1];l.connect(lg);lg.connect(ga.gain);l.start();nodes.push(l);}};
  const hiss=(f,q,gain,type)=>{const s=ctx.createBufferSource();s.buffer=A.noise;s.loop=true;const fl=ctx.createBiquadFilter();fl.type=type||'bandpass';fl.frequency.value=f;fl.Q.value=q;const ga=ctx.createGain();ga.gain.value=gain;s.connect(fl);fl.connect(ga);ga.connect(g);s.start();nodes.push(s);};
  if(key==='freezer'){tone('sawtooth',55,.035,240,[.13,.01]);tone('sawtooth',110.6,.015,300);hiss(700,.6,.02);iv=setInterval(()=>{if(Math.random()<.35){const tt=now();nz(.03,g,tt,.05,{f:5000,q:9});}},1800);}
  if(key==='backroom'){tone('sawtooth',120,.006,2400);tone('square',240,.002,3000);hiss(400,.4,.012);iv=setInterval(()=>{if(Math.random()<.5){const tt=now();osc('sine',1200+Math.random()*500,.05,g,tt,.25,{to:700});}},2600);}
  if(key==='front'){tone('sawtooth',120,.005,1800,[.3,.003]);hiss(900,.4,.03,'lowpass');iv=setInterval(()=>{if(Math.random()<.25){const tt=now();nz(.05,g,tt,2.5,{f:300,to:1200,q:.5,a:1});}},4000);}
  if(key==='alley'){hiss(1400,.3,.06,'lowpass');hiss(5000,.8,.015);tone('sawtooth',36,.05,110,[7,.02]);iv=setInterval(()=>{if(Math.random()<.6){const tt=now();osc('sine',900+Math.random()*900,.04,g,tt,.12,{to:500});}},700);}
  if(key==='dark'){tone('sine',41,.05,200,[.07,.02]);hiss(300,.5,.008);}
  if(key==='store'){tone('sawtooth',60,.012,500,[.2,.004]);tone('square',120,.003,900);hiss(2000,.3,.008);iv=setInterval(()=>{if(Math.random()<.2){const tt=now();osc('sine',880,.03,g,tt,.18);osc('sine',660,.03,g,tt+.2,.25);}},9000);}
  if(key==='club'){const bpm=124,beat=60/bpm;tone('sine',55,.0,100);iv=setInterval(()=>{const tt=now();for(let i=0;i<4;i++){osc('sine',58,.22,g,tt+i*beat,.18,{to:38});if(i%2)nz(.04,g,tt+i*beat,.08,{f:7000,q:2});}if(Math.random()<.5)osc('sawtooth',[220,247,262,196][Math.floor(Math.random()*4)],.025,g,tt,beat*3);},beat*4000);hiss(250,.5,.02,'lowpass');}
  if(key==='crypt'){tone('sine',48,.04,180,[.05,.02]);tone('triangle',96.3,.008,400,[.11,.004]);hiss(600,.7,.006);iv=setInterval(()=>{if(Math.random()<.4){const tt=now();osc('sine',[392,440,523,587][Math.floor(Math.random()*4)],.018,g,tt,3.5);}},5200);}
  if(key==='clinic'){tone('sawtooth',120,.004,2200);hiss(3000,.5,.006);iv=setInterval(()=>{const tt=now();osc('sine',980,.03,g,tt,.09);},1100);}
  if(key==='pawn'){tone('sine',60,.01,300);hiss(800,.4,.006);iv=setInterval(()=>{const tt=now();nz(.03,g,tt,.03,{f:3000,q:6});nz(.02,g,tt+.5,.03,{f:2600,q:6});},1000);}
  if(key==='sewer'){hiss(500,.4,.05,'lowpass');tone('sine',32,.05,90,[.09,.02]);iv=setInterval(()=>{if(Math.random()<.7){const tt=now();osc('sine',1400+Math.random()*700,.03,g,tt,.08,{to:600});}},1300);}
  if(key==='tunnel'){tone('sawtooth',28,.05,80,[.04,.03]);hiss(900,.4,.03,'lowpass');iv=setInterval(()=>{if(Math.random()<.35){const tt=now();nz(.08,g,tt,3,{f:200,to:800,q:.4,a:1.2});}},6000);}
  if(key==='street'){hiss(1200,.3,.04,'lowpass');tone('sawtooth',40,.03,120,[5,.01]);iv=setInterval(()=>{if(Math.random()<.3){const tt=now();nz(.05,g,tt,2.2,{f:400,to:1400,q:.4,a:.8});}},5000);}
  if(key==='roof'){hiss(600,.3,.06,'lowpass');hiss(3000,.6,.01);tone('sine',36,.03,100,[.2,.01]);}
  if(key==='cistern'){tone('sine',36,.06,140,[.03,.03]);tone('sine',72.4,.02,300,[.07,.01]);hiss(400,.6,.02);iv=setInterval(()=>{if(Math.random()<.5){const tt=now();osc('sine',1800+Math.random()*900,.025,g,tt,.1,{to:900});}},2100);}
  A.layers.main={g,nodes,iv};
};
/* ---- score ---- */
const NOTE=n=>440*Math.pow(2,(n-69)/12);
const MOODS={
  title:{chords:[[50,57,62,65],[46,53,58,62],[43,50,55,58],[45,52,57,61]],len:7.5,pluck:[62,65,69,70,72,74],pl:.45,type:'sawtooth',lp:900},
  night:{chords:[[38,45,50,53],[41,48,53,57],[36,43,48,52],[40,47,50,55]],len:9,pluck:[57,60,62,64,65,69],pl:.22,type:'triangle',lp:700},
  tense:{chords:[[37,44,49,52],[38,45,50,53],[36,43,48,51],[37,44,49,52]],len:6,pluck:[61,62,64,65],pl:.5,type:'sawtooth',lp:600,pulse:true},
  mirror:{chords:[[45,52,57,60,64],[41,48,53,57,60],[43,50,55,59,62],[40,47,52,56,59]],len:8,pluck:[69,71,72,76,79],pl:.6,type:'triangle',lp:1400},
  club:{chords:[[45,52,57,60],[43,50,55,59],[41,48,53,57],[40,47,52,55]],len:7.7,pluck:[69,72,76,79],pl:.35,type:'sawtooth',lp:1200},
  dread:{chords:[[36,43,46,51],[35,42,47,50],[36,43,48,51],[34,41,46,49]],len:10,pluck:[58,59,63,66],pl:.25,type:'triangle',lp:500,pulse:true},
  grief:{chords:[[45,52,57,60],[41,48,53,57],[38,45,50,53],[40,47,52,56]],len:10,pluck:[64,69,72,76],pl:.3,type:'triangle',lp:900},
  dawn:{chords:[[50,57,62,66,69],[47,54,59,62,66],[43,50,55,59,62],[45,52,57,61,64]],len:9,pluck:[74,78,81,83,86],pl:.45,type:'triangle',lp:1600},
  end:{chords:[[50,57,62,65,69],[46,53,58,62,65],[48,55,60,64,67],[45,52,57,61,64]],len:8,pluck:[74,77,81,82,84],pl:.5,type:'sawtooth',lp:1100}
};
A.music=function(mood){if(!A.ctx)return;if(A.curMood===mood)return;A.curMood=mood;const t=now();
  A.musicNodes.forEach(n=>{try{n.g.gain.setTargetAtTime(0,t,1.5);n.o.forEach(o=>o.stop(t+6));}catch(e){}});A.musicNodes=[];clearInterval(A._mi);clearInterval(A._pi);
  if(!mood)return;const M=MOODS[mood];let ci=0;
  const play=()=>{const tt=now(),ch=M.chords[ci++%M.chords.length],g=A.ctx.createGain();g.gain.setValueAtTime(0.0001,tt);g.gain.exponentialRampToValueAtTime(.05,tt+2.2);g.gain.setTargetAtTime(0.0001,tt+M.len-1,1.6);
    const f=A.ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=M.lp;f.Q.value=.7;g.connect(f);f.connect(A.mus);const os=[];
    ch.forEach((n,i)=>[-6,6].forEach(dt=>{const o=A.ctx.createOscillator();o.type=M.type;o.frequency.value=NOTE(n);o.detune.value=dt+(i*3);o.connect(g);o.start(tt);o.stop(tt+M.len+3);os.push(o);}));
    if(M.pulse){const l=A.ctx.createOscillator(),lg=A.ctx.createGain();l.frequency.value=1.6;lg.gain.value=.025;l.connect(lg);lg.connect(g.gain);l.start(tt);l.stop(tt+M.len+3);os.push(l);}
    A.musicNodes.push({g,o:os});if(A.musicNodes.length>3)A.musicNodes.shift();};
  play();A._mi=setInterval(play,M.len*1000);
  A._pi=setInterval(()=>{if(Math.random()<M.pl){const tt=now(),n=M.pluck[Math.floor(Math.random()*M.pluck.length)];osc('triangle',NOTE(n),.05,A.mus,tt,2.6,{a:.004});osc('sine',NOTE(n+12),.015,A.mus,tt,1.6,{a:.004});}},900);
};
/* ---- heartbeat loop ---- */
A.heart=function(rate){clearInterval(A._hb);if(!rate)return;A._hb=setInterval(()=>A.sfx('beat'),60000/rate);};
NL.Audio=A;
})();
