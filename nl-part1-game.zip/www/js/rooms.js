'use strict';
/* THE NEW LORD — room dioramas */
(function(){
const NL=window.NL;const {Geo,GeoB,M4}=NL;const PI=Math.PI;

function M(color,o){o=o||{};return Object.assign({color,tex:null,texScale:1,emis:[0,0,0],emisK:0,spec:0.15,mottle:0.25,alpha:1,decal:false},o);}
class RB{
  constructor(){this.groups=new Map();this.decals=[];this.trans=[];this.dep=new GeoB();this.blocks=[];}
  _g(mat){if(mat.decal||mat.alpha<1){const b=new GeoB();(mat.decal?this.decals:this.trans).push({mat,b});return b;}
    if(!this.groups.has(mat))this.groups.set(mat,new GeoB());return this.groups.get(mat);}
  box(mn,mx,mat,o){o=o||{};Geo.boxInto(this._g(mat),mn,mx,o.skip);if(!o.noDepth&&!mat.decal&&!(mat.alpha<1))Geo.boxInto(this.dep,mn,mx,o.skip);if(o.block)this.block(mn[0],mn[2],mx[0],mx[2]);return this;}
  part(g,Mx,mat,o){o=o||{};this._g(mat).append(g,Mx);if(!o.noDepth&&!mat.decal&&!(mat.alpha<1))this.dep.append(g,Mx);return this;}
  cyl(p,rt,rb,h,mat,o){o=o||{};return this.part(Geo.cyl(rt,rb,h,o.seg||16,o.caps),M4.trs(p,o.rot||[0,0,0],o.scl||[1,1,1]),mat,o);}
  cylX(x0,x1,y,z,r,mat,o){return this.part(Geo.cyl(r,r,x1-x0,12),M4.trs([x1,y,z],[0,0,PI/2]),mat,o);}
  cylZ(x,y,z0,z1,r,mat,o){return this.part(Geo.cyl(r,r,z1-z0,12),M4.trs([x,y,z0],[PI/2,0,0]),mat,o);}
  sph(p,s,mat,o){o=o||{};return this.part(Geo.sphere(1,16,10),M4.trs(p,o.rot||[0,0,0],s),mat,o);}
  decal(c,du,dv,n,mat){const b=this._g(mat);const c0=[c[0]-du[0]/2-dv[0]/2,c[1]-du[1]/2-dv[1]/2,c[2]-du[2]/2-dv[2]/2];b.quadPts(c0,du,dv,n,(p,u,v)=>[u,v]);return this;}
  // convenience decals
  wallZ(x,y,w,h,mat,z){return this.decal([x,y,(z||0)+0.012],[w,0,0],[0,h,0],[0,0,1],mat);}
  wallX(z,y,w,h,mat,x){return this.decal([(x||0)+0.012,y,z],[0,0,-w],[0,h,0],[1,0,0],mat);}
  floor(x,z,w,d,mat,y){return this.decal([x,(y||0)+0.006,z],[w,0,0],[0,0,-d],[0,1,0],mat);}
  block(x0,z0,x1,z1){this.blocks.push([Math.min(x0,x1),Math.min(z0,z1),Math.max(x0,x1),Math.max(z0,z1)]);}
  shell(W,D,H,floorMat,wallL,wallR,capMat,o){o=o||{};
    this.box([-0.02,-0.32,-0.02],[W,0,D],floorMat,{skip:{nx:true,nz:true}});
    const lo=o.lowerH||0;
    if(lo){if(!o.leftCustom){this.box([-0.2,0,-0.2],[0,lo,D],o.lowerL||wallL);this.box([-0.2,lo,-0.2],[0,H,D],wallL);}this.box([0,0,-0.2],[W,lo,0],o.lowerR||wallR);this.box([0,lo,-0.2],[W,H,0],wallR);}
    else{if(!o.leftCustom)this.box([-0.2,0,-0.2],[0,H,D],wallL);this.box([0,0,-0.2],[W,H,0],wallR);}
    this.box([-0.21,H,-0.21],[0.01,H+0.05,D],capMat,{noDepth:true});this.box([0,H,-0.21],[W,H+0.05,0.01],capMat,{noDepth:true});
    // skirting shadow line
    this.box([0,0,0],[0.03,0.12,D],capMat);this.box([0,0,0],[W,0.12,0.03],capMat);
  }
  result(){const groups=[];this.groups.forEach((b,mat)=>{if(!b.empty)groups.push({mat,g:b.build()});});
    return {groups,decals:this.decals.map(d=>({mat:d.mat,g:d.b.build()})),trans:this.trans.map(d=>({mat:d.mat,g:d.b.build()})),depth:this.dep.build(),blocks:this.blocks};}
}

/* ---------- shared materials ---------- */
const T=k=>NL.Tex.get(k);
const MAT={};
function mats(){ if(MAT.ready) return MAT;
  Object.assign(MAT,{
    cap:M([.07,.05,.08],{mottle:0,spec:0}),
    steel:M([.86,.95,1.0],{tex:'steel',texScale:1,spec:.5,mottle:.15}),
    steelDark:M([.45,.5,.55],{tex:'steel',texScale:1.5,spec:.5}),
    steelBright:M([.85,.88,.9],{spec:.9,mottle:.1}),
    concCold:M([.78,.86,.92],{tex:'concrete',texScale:.5,spec:.25}),
    quarry:M([1,1,1],{tex:'quarry',texScale:1,spec:.3,mottle:.2}),
    checker:M([1,1,1],{tex:'checker',texScale:.9,spec:.45,mottle:.15}),
    subway:M([1,1,1],{tex:'subway',texScale:1,spec:.45,mottle:.15}),
    plaster:M([1,1,1],{tex:'plaster',texScale:.5,spec:.05}),
    brick:M([1,1,1],{tex:'brick',texScale:.5,spec:.05}),
    asphalt:M([1,1,1],{tex:'asphalt',texScale:.35,spec:.6}),
    wood:M([1,1,1],{tex:'wood',texScale:.8,spec:.2}),
    woodDark:M([.55,.5,.5],{tex:'wood',texScale:.8,spec:.2}),
    card:M([1,1,1],{tex:'cardboard',texScale:2.5,spec:.05}),
    bag:M([.42,.05,.08],{spec:.9,mottle:.35}),
    bagLight:M([.6,.1,.12],{spec:.9,mottle:.35}),
    pig:M([.93,.78,.74],{spec:.3,mottle:.35}),
    pigCut:M([.62,.12,.14],{spec:.5,mottle:.4}),
    ash:M([.46,.45,.44],{mottle:.6,spec:0}),
    coat:M([.16,.16,.19],{mottle:.3,spec:.1}),
    felt:M([.12,.1,.1],{mottle:.2}),
    gold:M([.9,.72,.3],{spec:1.2,mottle:.1}),
    rubber:M([.08,.08,.09],{spec:.3}),
    white:M([.9,.9,.86],{spec:.3}),
    porcelain:M([.92,.93,.9],{spec:.8,mottle:.1}),
    red:M([.62,.08,.1],{spec:.5}),
    green:M([.12,.3,.2],{spec:.3}),
    black:M([.06,.06,.07],{spec:.6}),
    chrome:M([.8,.82,.85],{spec:1.4,mottle:.05}),
    meat:M([.7,.18,.2],{spec:.6,mottle:.5}),
    fat:M([.95,.85,.78],{spec:.4,mottle:.3}),
    sausage:M([.58,.28,.2],{spec:.5,mottle:.4}),
    glass:M([.7,.85,.9],{alpha:.18,spec:1.5,mottle:0}),
    bulb:M([1,1,1],{emis:[1,.98,.9],emisK:0,mottle:0}),
    bulbCold:M([1,1,1],{emis:[.85,.95,1],mottle:0}),
    tube:M([1,1,1],{emis:[.9,1,.95],mottle:0}),
    redLamp:M([1,.2,.15],{emis:[1,.15,.1],mottle:0}),
    sodium:M([1,.7,.3],{emis:[1,.62,.25],mottle:0}),
    // decals
    dBlood:M([1,1,1],{tex:'blood',decal:true,mottle:0,spec:.6}),
    dAsh:M([1,1,1],{tex:'ash',decal:true,mottle:0,spec:0}),
    dFrost:M([1,1,1],{tex:'frost',decal:true,mottle:0,spec:.4,emisK:.15}),
    dGrime:M([1,1,1],{tex:'grime',decal:true,mottle:0,spec:0}),
    dPuddle:M([1,1,1],{tex:'puddle',decal:true,mottle:0,spec:2,emisK:.25}),
    dDrain:M([1,1,1],{tex:'drain',decal:true,mottle:0}),
    dChalk:M([1,1,1],{tex:'chalk',decal:true,mottle:0,spec:0,emisK:.05}),
    dNeon:M([1,1,1],{tex:'neon',decal:true,mottle:0,spec:0,emisK:2.2}),
    dSign:M([1,1,1],{tex:'sign24',decal:true,mottle:0,spec:.1}),
    dMissing:M([1,1,1],{tex:'missing',decal:true,mottle:0,spec:0}),
    dGraffiti:M([1,1,1],{tex:'graffiti',decal:true,mottle:0,spec:0}),
    dTV:M([1,1,1],{tex:'tv',decal:true,mottle:0,emisK:1.3}),
    dLedger:M([1,1,1],{tex:'ledger',decal:true,mottle:0}),
    dSticky:M([1,1,1],{tex:'sticky',decal:true,mottle:0}),
    dWet:M([1,1,1],{tex:'wetfloor',decal:true,mottle:0,spec:.3}),
    dMirror:M([1,1,1],{tex:'mirror',decal:true,mottle:0,spec:1.6,emisK:.25}),
    dBag:M([1,1,1],{tex:'bloodbag',decal:true,mottle:0,spec:.8})
  });
  MAT.ready=true; return MAT;
}

/* ---------- props ---------- */
function crate(rb,x,z,w,d,h,mat){rb.box([x-w/2,0,z-d/2],[x+w/2,h,z+d/2],mat||MAT.card,{block:true});}
function fedora(rb,p,rot,mat){const Mx=M4.trs(p,rot,[1,1,1]);rb.part(Geo.cyl(0.1,0.11,0.11,14),Mx,mat);rb.part(Geo.cyl(0.19,0.19,0.012,18),Mx,mat);}
function hangingPig(rb,x,z,y){const m=MAT;rb.cyl([x,y,z],0.012,0.012,2.45-y,m.steelBright,{noDepth:true});
  const body=Geo.lathe([[0,-1.02],[0.07,-0.98],[0.15,-0.82],[0.22,-0.55],[0.25,-0.3],[0.21,-0.1],[0.12,0.02],[0.05,0.06],[0,0.07]],16);
  rb.part(body,M4.trs([x,y-0.12,z],[0,0.75,0],[1,1,0.62]),m.pig);
  rb.part(Geo.sphere(1,12,8),M4.trs([x-0.07,y-0.62,z-0.1],[0,0.75,0],[0.17,0.4,0.05]),m.pigCut,{noDepth:true});
  [-0.06,0.06].forEach(o=>rb.part(Geo.capsule(0.045,0.035,0.2,8),M4.trs([x+o,y-0.05,z],[0,0,o*3]),m.pig,{noDepth:true}));
  rb.block(x-0.3,z-0.25,x+0.3,z+0.25);}

/* ============================== ROOMS ============================== */
const ROOMS={};

ROOMS.freezer={id:'freezer',name:'The Walk-In',sub:"Kowalski's 24-Hour Meats · The Marrow Ward",W:6,D:5,H:2.8,ambience:'freezer',
  sky:[.17,.21,.27],ground:[.05,.06,.09],cold:true,
  grade:{sh:[.55,.72,1.0],hi:[.98,.98,1.0],ink:[.03,.04,.08],sat:.78,wash1:[.02,.025,.04],wash2:[.07,.09,.12]},
  shadow:{pos:[3.0,2.5,2.4],target:[3.0,0,2.5],fov:2.3,far:8,idx:0},
  lights(S){return [{pos:[3.0,2.5,2.4],color:[.72,.88,1],intensity:1.85,range:6.5},{pos:[4.8,2.35,0.25],color:[1,.15,.1],intensity:1.0,range:2.6},{pos:[5.5,2.4,5.2],color:[.3,.42,.6],intensity:.6,range:7}];},
  flicker(t){return 1-0.06*Math.max(0,Math.sin(t*17))*(Math.sin(t*0.7)>0.85?1:0);},
  build(rb,S){const m=mats(),f=S.flags;
    rb.shell(6,5,2.8,m.concCold,m.steel,m.steel,m.cap);
    for(let i=0;i<6;i++){rb.wallX(0.45+i*0.85,0.32,0.9,0.65,m.dFrost);rb.wallZ(0.5+i*0.95,0.32,1.0,0.65,m.dFrost);}
    rb.floor(3,2.6,0.5,0.5,m.dDrain);rb.floor(2.0,1.6,2.2,2.0,m.dGrime);rb.floor(4.3,3.7,1.4,1.4,m.dBlood);rb.floor(3.2,2.9,0.9,0.9,m.dBlood);
    // shelf (left wall)
    const sx0=0.04,sx1=0.6,sz0=0.35,sz1=2.75;
    [sz0,sz1].forEach(z=>{rb.box([sx0,0,z-0.03],[sx0+0.04,2.1,z+0.03],m.steelDark);rb.box([sx1-0.04,0,z-0.03],[sx1,2.1,z+0.03],m.steelDark);});
    [0.3,0.82,1.34,1.86].forEach((y,si)=>{rb.box([sx0,y,sz0],[sx1,y+0.035,sz1],m.steelDark);
      if(!(si===1&&f.bagsTaken>=3)) for(let k=0;k<7;k++){const z=sz0+0.12+k*0.33,R=NL.Tex.rng(si*31+k);if(R()<.2)continue;
        if(si===3&&k>3){rb.box([sx0+0.06,y+0.035,z-0.14],[sx0+0.48,y+0.3,z+0.14],m.card);continue;}
        const h=0.06+R()*0.03;rb.box([sx0+0.08,y+0.035,z-0.12],[sx0+0.42,y+0.035+h,z+0.12],R()<.5?m.bag:m.bagLight);
        if(R()<.6)rb.box([sx0+0.1,y+0.035+h,z-0.1],[sx0+0.38,y+0.07+h,z+0.1],m.bagLight);}});
    rb.decal([sx1+0.004,1.7,1.0],[0,0,-0.24],[0,0.24,0],[1,0,0],m.dBag);
    if(!f.thermoTaken){rb.cyl([sx1+0.03,1.2,sz1-0.25],0.012,0.012,0.32,m.chrome,{noDepth:true});rb.cyl([sx1+0.03,1.52,sz1-0.25],0.035,0.035,0.035,m.white,{noDepth:true});}
    rb.block(0,0.2,0.75,2.9);
    // boxes by right wall
    crate(rb,3.0,0.45,0.6,0.55,0.55);crate(rb,3.05,0.45,0.5,0.45,0.95,m.card);crate(rb,3.75,0.4,0.5,0.5,0.45);
    // rail + hooks
    rb.cylX(0,5.8,2.48,3.9,0.03,m.steelBright,{noDepth:true});
    [0.6,2.8,5.2].forEach(x=>rb.cyl([x,2.48,3.9],0.02,0.02,0.4,m.steelDark,{noDepth:true}));
    hangingPig(rb,0.95,3.9,2.3);hangingPig(rb,1.75,3.9,2.3);
    rb.cyl([4.7,2.2,3.9],0.012,0.012,0.28,m.steelBright,{noDepth:true});
    if(!f.tedFreed) rb.block(4.3,3.6,5.1,4.2);
    // door (right wall)
    rb.box([4.05,0,0],[4.15,2.25,0.12],m.steelDark);rb.box([5.45,0,0],[5.55,2.25,0.12],m.steelDark);rb.box([4.05,2.15,0],[5.55,2.3,0.12],m.steelDark);
    if(f.doorTorn){rb.box([4.15,0,0],[5.45,2.15,0.02],m.cap);rb.part(Geo.box(1.3,2.1,0.1),M4.trs([5.3,0.3,1.4],[-1.42,0.35,0.15],[1,1,1]),m.steelDark);rb.block(4.5,0.9,6,1.9);}
    else if(f.doorOpen){rb.box([4.15,0,0],[5.45,2.15,0.02],M([.35,.25,.15],{emis:[.14,.1,.06],mottle:.1}));rb.part(Geo.box(1.3,2.1,0.1),M4.trs([5.45+0.05,1.05,0.65],[0,PI/2-0.15,0],[1,1,1]),m.steelDark);}
    else{rb.box([4.15,0,0],[5.45,2.15,0.1],m.steelDark);rb.cyl([4.4,1.05,0.1],0.03,0.03,0.03,m.black,{rot:[PI/2,0,0]});rb.box([4.17,0.02,0.1],[5.43,0.08,0.13],m.rubber);}
    rb.box([4.7,2.32,0.02],[4.9,2.42,0.1],m.redLamp,{noDepth:true});
    // bulb
    rb.cyl([3.0,2.56,2.4],0.006,0.006,0.4,m.black,{noDepth:true});rb.sph([3.0,2.52,2.4],[0.05,0.06,0.05],m.bulbCold,{noDepth:true});
    rb.part(Geo.cyl(0.09,0.06,0.09,10,false),M4.trs([3.0,2.47,2.4]),m.steelDark,{noDepth:true});
    // ash pile & sheriff remains
    rb.part(Geo.lathe([[0,0],[0.5,0],[0.38,0.05],[0.22,0.13],[0.06,0.19],[0,0.2]],20),M4.trs([2.2,0,1.85],[0,0,0],[1,1,0.8]),m.ash);
    rb.floor(2.2,1.85,1.7,1.5,m.dAsh);
    if(!f.ashGone){fedora(rb,[2.65,0.05,1.45],[0.25,0.6,-0.35],m.felt);}
    else{ rb.floor(2.2,1.85,1.2,1.0,m.dAsh); }
    if(!f.coatTaken){rb.part(Geo.sphere(1,12,8),M4.trs([1.75,0.08,2.35],[0,0.4,0],[0.42,0.1,0.28]),m.coat);rb.part(Geo.sphere(1,12,8),M4.trs([1.5,0.06,2.0],[0,1.1,0],[0.32,0.07,0.16]),m.coat);}
    if(f.ashGone==='bucket'){rb.cyl([2.9,0,1.3],0.17,0.15,0.36,m.white);}
    rb.block(1.75,1.45,2.65,2.25);
  },
  spawn:{x:3.1,z:3.15,ry:PI/4},
  exits:[{id:'toBack',label:'Back room',at:[4.8,1.4,0.2],box:[4.15,0,0,5.45,2.15,0.3],stand:[4.8,0.75],face:[4.8,0],if:S=>S.flags.doorOpen||S.flags.doorTorn,to:'backroom',spawn:{x:1.2,z:1.0,ry:0.4}}],
  inter:[
    {id:'ash',label:'Pile of ash',at:[2.2,0.4,1.85],box:[1.7,0,1.4,2.7,0.5,2.3],stand:[2.75,2.55],face:[2.2,1.85]},
    {id:'coat',label:'Heavy coat',at:[1.7,0.3,2.25],box:[1.2,0,1.8,2.2,0.3,2.7],stand:[1.95,2.95],face:[1.7,2.3],if:S=>!S.flags.coatTaken},
    {id:'shelf',label:"Shelf of 'pork stock'",at:[0.35,1.6,1.5],box:[0,0,0.3,0.65,2.1,2.8],stand:[1.05,1.6],face:[0.3,1.6]},
    {id:'pig',label:'Half a pig',at:[1.35,1.9,3.9],box:[0.6,0.9,3.6,2.1,2.3,4.2],stand:[1.35,3.2],face:[1.35,3.9]},
    {id:'door',label:'Freezer door',at:[4.8,1.4,0.15],box:[4.15,0,0,5.45,2.15,0.3],stand:[4.8,0.75],face:[4.8,0],if:S=>!S.flags.doorOpen&&!S.flags.doorTorn},
    {id:'boxes',label:'Cardboard boxes',at:[3.1,1.1,0.45],box:[2.6,0,0.1,4.0,1.0,0.75],stand:[3.3,1.15],face:[3.1,0.4]},
    {id:'bulb',label:'Bare bulb',at:[3.0,2.5,2.4],box:[2.85,2.3,2.25,3.15,2.7,2.55],stand:[2.95,2.95],face:[3.0,2.4]}
  ],
  particles:[{type:'mist',n:26,area:[0.3,5.7,0.3,4.7],y:[0.02,0.35]},{type:'motes',n:40,area:[0.5,5.5,0.5,4.5],y:[0.4,2.5],col:[.8,.9,1]},{type:'ash',n:18,center:[2.2,0.15,1.85],r:0.45}]
};

ROOMS.backroom={id:'backroom',name:'The Cutting Room',sub:"Kowalski's 24-Hour Meats · back of house",W:9,D:6,H:2.9,ambience:'backroom',
  sky:[.2,.22,.2],ground:[.07,.05,.05],
  grade:{sh:[.65,.9,.82],hi:[1.04,.97,.86],ink:[.05,.04,.04],sat:.8,wash1:[.025,.025,.03],wash2:[.09,.08,.08]},
  shadow:{pos:[3.6,2.75,2.6],target:[3.6,0,2.8],fov:2.3,far:8,idx:0},
  lights(S){return [{pos:[3.6,2.75,2.6],color:[.86,1,.9],intensity:1.45,range:7.5},{pos:[6.6,2.75,3.2],color:[.86,1,.92],intensity:.95,range:6},{pos:[7.55,1.28,3.65],color:[1,.68,.38],intensity:1.6,range:3.4},
    {pos:[1.0,2.3,5.0],color:[1,.82,.5],intensity:.95,range:3.2},{pos:[7.9,2.45,0.3],color:[1,.15,.12],intensity:.6,range:2.2}];},
  flicker(t){return 1-0.08*(Math.sin(t*31)>0.6&&Math.sin(t*0.37)>0.9?1:0);},
  build(rb,S){const m=mats(),f=S.flags;
    rb.shell(9,6,2.9,m.quarry,m.plaster,m.plaster,m.cap,{lowerH:1.4,lowerL:m.subway,lowerR:m.subway});
    rb.box([0,1.38,0],[0.04,1.44,6],m.white);rb.box([0,1.38,0],[9,1.44,0.04],m.white);
    rb.floor(4.5,2.85,3.2,2.2,m.dGrime);rb.floor(4.4,3.0,1.2,1.2,m.dBlood);rb.floor(4.6,2.0,0.4,0.4,m.dDrain);rb.floor(1.3,1.5,1.4,1.2,m.dGrime);
    // freezer door (outside)
    rb.box([0.5,0,0],[1.9,2.35,0.18],m.steelDark);rb.box([0.6,0,0.18],[1.8,2.2,0.2],m.cap);
    if(f.doorTorn){rb.part(Geo.box(1.2,2.1,0.1),M4.trs([1.25,0.06,0.9],[-1.5,0.1,0],[1,1,1]),m.steelDark);rb.block(0.6,0.3,1.9,1.5);}
    else rb.part(Geo.box(1.2,2.1,0.1),M4.trs([0.62,1.05,0.75],[0,PI/2+0.25,0],[1,1,1]),m.steelDark);
    rb.wallZ(1.2,2.55,0.6,0.15,M([1,1,1],{decal:true,tex:'sign24',mottle:0}));
    // sink
    rb.box([2.3,0,0.02],[3.3,0.78,0.62],m.steelBright,{block:true});rb.box([2.4,0.62,0.12],[3.2,0.8,0.55],m.cap,{noDepth:true});
    rb.cyl([2.8,0.8,0.08],0.02,0.02,0.32,m.chrome,{noDepth:true});rb.cylZ(2.8,1.1,0.08,0.3,0.018,m.chrome,{noDepth:true});
    // band saw
    rb.box([3.9,0,0.05],[4.9,0.9,0.75],m.green,{block:true});rb.box([4.0,0.9,0.1],[4.8,1.9,0.5],m.green);rb.box([4.05,0.9,0.5],[4.75,0.96,0.7],m.steelBright);rb.cyl([4.4,1.0,0.6],0.008,0.008,0.75,m.chrome,{noDepth:true});
    // coat rack
    rb.cyl([5.7,0,0.4],0.02,0.02,1.85,m.woodDark,{block:true});rb.cyl([5.7,0,0.4],0.22,0.24,0.04,m.woodDark);
    if(!f.apronTaken){rb.box([5.55,0.85,0.48],[5.85,1.75,0.52],M([.86,.84,.8],{mottle:.4}));rb.floor(5.7,0.55,0.4,0.4,m.dBlood,0);}
    if(!f.paperHatTaken) rb.box([5.6,1.82,0.33],[5.82,1.88,0.47],m.white);
    // back door
    rb.box([7.35,0,0],[8.45,2.3,0.08],m.woodDark);rb.box([7.3,2.3,0],[8.5,2.38,0.1],m.cap);
    if(!f.backDoorOpen){rb.cylX(7.5,8.3,1.15,0.11,0.015,m.chrome,{noDepth:true});rb.box([7.85,1.0,0.1],[7.97,1.12,0.15],m.gold);}
    rb.box([7.75,2.42,0.02],[8.05,2.55,0.08],m.redLamp,{noDepth:true});
    // pegboard + knives (left wall)
    rb.box([0,1.2,0.6],[0.03,2.1,2.3],m.woodDark);
    for(let i=0;i<6;i++){const z=0.8+i*0.26;rb.box([0.03,1.45,z-0.04],[0.05,1.95,z+0.04],i%2?m.steelBright:m.chrome,{noDepth:true});rb.box([0.03,1.3,z-0.03],[0.06,1.45,z+0.03],m.black,{noDepth:true});}
    // shelf
    rb.box([0.02,0,2.6],[0.5,1.6,3.5],m.woodDark,{block:true});[0.5,1.0,1.55].forEach(y=>{rb.box([0.05,y,2.65],[0.45,y+0.18,2.95],m.card);rb.box([0.05,y,3.05],[0.4,y+0.24,3.45],m.white);});
    // washroom partition
    rb.box([0,0,3.95],[1.05,2.25,4.05],m.subway,{block:true});rb.box([0,2.25,3.92],[1.05,2.3,4.08],m.cap);
    rb.box([0.02,0.72,4.65],[0.5,0.85,5.35],m.porcelain,{block:true});rb.cyl([0.26,0,5.0],0.06,0.08,0.72,m.porcelain);
    rb.box([0,1.08,4.68],[0.05,1.92,5.32],m.steelDark);rb.wallX(5.0,1.5,0.56,0.76,m.dMirror,0.05);
    rb.box([0.05,0,5.55],[0.55,0.42,5.95],m.porcelain,{block:true});rb.box([0.02,0.42,5.6],[0.2,0.95,5.95],m.porcelain);
    rb.cyl([1.0,2.35,5.0],0.005,0.005,0.6,m.black,{noDepth:true});rb.sph([1.0,2.3,5.0],[0.045,0.055,0.045],m.bulb,{noDepth:true});
    // cutting table
    rb.box([3.4,0.86,2.4],[5.6,0.92,3.35],m.steelBright,{block:true});
    [[3.5,2.5],[5.5,2.5],[3.5,3.25],[5.5,3.25]].forEach(p=>rb.box([p[0]-0.03,0,p[1]-0.03],[p[0]+0.03,0.86,p[1]+0.03],m.steelDark));
    rb.box([3.55,0.15,2.5],[5.45,0.18,3.25],m.steelDark);
    rb.part(Geo.sphere(1,12,8),M4.trs([4.3,0.98,2.9],[0,0.3,0],[0.32,0.07,0.2]),m.meat);rb.part(Geo.sphere(1,10,6),M4.trs([4.42,1.0,2.95],[0,0.3,0],[0.12,0.05,0.09]),m.fat);
    rb.box([4.9,0.92,2.75],[5.25,0.94,2.85],m.chrome,{noDepth:true});rb.box([4.85,0.92,2.72],[4.92,0.96,2.88],m.black,{noDepth:true});
    // office
    rb.box([6.95,0.74,3.15],[8.65,0.8,4.25],m.wood,{block:true});rb.box([7.0,0,3.2],[7.1,0.74,4.2],m.woodDark);rb.box([8.5,0,3.2],[8.6,0.74,4.2],m.woodDark);rb.box([7.1,0.1,3.2],[8.5,0.74,3.3],m.woodDark);
    rb.cyl([7.55,0.8,3.65],0.08,0.1,0.03,m.black);rb.cyl([7.55,0.8,3.65],0.012,0.012,0.4,m.chrome,{noDepth:true});rb.part(Geo.cyl(0.05,0.13,0.14,14,false),M4.trs([7.55,1.18,3.65]),m.green,{noDepth:true});
    rb.box([7.95,0.8,3.45],[8.2,0.88,3.7],m.red);rb.cyl([8.07,0.88,3.58],0.04,0.04,0.02,m.black);rb.cylZ(8.07,0.93,3.45,3.72,0.025,m.red);
    if(!f.ledgerTaken){rb.box([7.2,0.8,3.85],[7.6,0.84,4.15],M([.42,.1,.1]));}
    rb.decal([8.35,0.805,3.95],[0.18,0,0],[0,0,-0.18],[0,1,0],m.dSticky);
    rb.box([8.3,0,1.9],[8.95,1.3,2.75],m.steelDark,{block:true});rb.box([8.28,0.35,2.0],[8.3,0.38,2.65],m.chrome);rb.box([8.28,0.85,2.0],[8.3,0.88,2.65],m.chrome);
    rb.cyl([7.75,0,4.55],0.22,0.24,0.45,m.black);rb.box([7.55,0.45,4.35],[7.95,0.52,4.75],m.rubber);
    // crate for teddy
    crate(rb,2.55,1.35,0.55,0.5,0.45,m.woodDark);
    // tubes
    rb.box([2.8,2.72,2.5],[4.4,2.78,2.7],m.tube,{noDepth:true});rb.box([5.8,2.72,3.1],[7.4,2.78,3.3],m.tube,{noDepth:true});
  },
  spawn:{x:1.2,z:1.0,ry:0.4},
  exits:[
    {id:'toFreezer',label:'Walk-in freezer',at:[1.2,1.4,0.25],box:[0.6,0,0,1.8,2.2,0.4],stand:[1.25,0.9],face:[1.2,0],to:'freezer',spawn:{x:4.8,z:0.9,ry:PI}},
    {id:'toFront',label:'Shop floor',at:[6.0,0.25,5.85],box:[5.4,0,5.5,6.6,0.6,6.1],stand:[6.0,5.6],face:[6.0,6.5],to:'front',spawn:{x:7.9,z:0.9,ry:0}},
    {id:'toAlley',label:'Back door',at:[7.9,1.4,0.15],box:[7.35,0,0,8.45,2.3,0.3],stand:[7.9,0.8],face:[7.9,0],to:'alley',spawn:{x:2.5,z:1.0,ry:0.2},if:S=>S.flags.backDoorOpen}
  ],
  inter:[
    {id:'mirror',label:'Washroom mirror',at:[0.05,1.55,5.0],box:[0,1.1,4.6,0.4,1.95,5.4],stand:[0.85,5.0],face:[0,5.0]},
    {id:'sink',label:'Utility sink',at:[2.8,1.0,0.3],box:[2.3,0,0,3.3,1.1,0.65],stand:[2.8,1.0],face:[2.8,0]},
    {id:'saw',label:'Band saw',at:[4.4,1.5,0.4],box:[3.9,0,0,4.9,1.9,0.75],stand:[4.4,1.15],face:[4.4,0]},
    {id:'rack',label:'Coat rack',at:[5.7,1.3,0.45],box:[5.45,0,0.2,5.95,1.9,0.7],stand:[5.7,1.05],face:[5.7,0.3],if:S=>!S.flags.apronTaken||!S.flags.paperHatTaken},
    {id:'desk',label:"Margo's desk",at:[7.4,0.95,3.95],box:[6.95,0,3.15,8.65,1.0,4.25],stand:[7.6,4.75],face:[7.6,3.7]},
    {id:'phone',label:'Red telephone',at:[8.07,1.0,3.58],box:[7.9,0.75,3.4,8.25,1.0,3.75],stand:[8.2,4.75],face:[8.1,3.6]},
    {id:'cabinet',label:'Filing cabinet',at:[8.6,1.2,2.3],box:[8.3,0,1.9,8.95,1.3,2.75],stand:[7.85,2.35],face:[8.6,2.3]},
    {id:'knives',label:'Pegboard of knives',at:[0.05,1.7,1.45],box:[0,1.2,0.6,0.2,2.1,2.3],stand:[0.8,1.45],face:[0,1.45]},
    {id:'table',label:'Cutting table',at:[4.5,1.05,2.9],box:[3.4,0,2.4,5.6,1.0,3.35],stand:[4.5,3.85],face:[4.5,2.9]},
    {id:'backdoor',label:'Back door',at:[7.9,1.4,0.15],box:[7.35,0,0,8.45,2.3,0.3],stand:[7.9,0.8],face:[7.9,0],if:S=>!S.flags.backDoorOpen}
  ],
  particles:[{type:'motes',n:50,area:[0.5,8.5,0.5,5.5],y:[0.4,2.6],col:[1,.95,.8]}]
};

ROOMS.front={id:'front',name:'The Shop Floor',sub:"Kowalski's 24-Hour Meats · Ferrier Street",W:9,D:6,H:3.0,ambience:'front',
  sky:[.18,.15,.2],ground:[.06,.04,.05],
  grade:{sh:[.8,.62,1.0],hi:[1.06,.96,.9],ink:[.05,.02,.05],sat:.86,wash1:[.03,.015,.03],wash2:[.11,.06,.09]},
  shadow:{pos:[-2.4,2.3,3.0],target:[3.4,0,3.0],fov:1.75,far:14,idx:0},
  lights(S){const L=[{pos:[-2.4,2.3,3.0],color:[1,.6,.3],intensity:2.6,range:12},{pos:[0.35,2.15,2.4],color:[1,.18,.3],intensity:1.4,range:4.5},{pos:[4.5,2.9,3.4],color:[.9,1,.96],intensity:.75,range:7},
    {pos:[4.3,1.0,1.9],color:[.85,.95,1],intensity:.8,range:2.2},{pos:[7.9,0.9,4.7],color:[.6,.85,1],intensity:.7,range:2.2},{pos:[1.1,2.45,0.3],color:[.5,.6,1],intensity:.5,range:2.2}];
    if(S.flags.calloArrived&&!S.flags.calloGone) L.push({pos:[-0.4,1.2,4.1],color:[1,.98,.85],intensity:1.4,range:5});return L;},
  flicker(t){return 1-0.12*(Math.sin(t*23)>0.4&&Math.sin(t*0.23+1)>0.82?1:0);},
  build(rb,S){const m=mats(),f=S.flags;
    rb.shell(9,6,3.0,m.checker,m.plaster,m.subway,m.cap,{lowerH:0.6,lowerR:m.subway,leftCustom:true});
    rb.box([-0.2,0,-0.2],[0,0.6,6],m.brick);rb.box([-0.2,2.72,-0.2],[0,3.0,6],m.plaster);rb.box([-0.2,0.6,-0.2],[0,2.72,0.3],m.plaster);rb.box([-0.2,0.6,5.7],[0,2.72,6],m.plaster);
    rb.box([-0.32,0.6,0.3],[-0.28,2.45,5.7],M([.5,.3,.2],{emis:[.42,.22,.12],mottle:.5,noShadow:true}),{noDepth:true});
    const shutterUp=f.shutterUp;
    for(let y=0.64;y<(shutterUp?0.9:2.6);y+=0.105){rb.box([0.03,y,0.35],[0.045,y+0.06,5.65],m.steel);}
    if(shutterUp) rb.box([0.02,2.3,0.35],[0.25,2.62,5.65],m.steelDark);
    rb.box([0,2.62,0.3],[0.14,2.72,5.7],m.steelDark);[0.3,5.7].forEach(z=>rb.box([0,0.55,z-0.05],[0.12,2.72,z+0.05],m.steelDark));
    rb.decal([0.12,2.2,2.45],[0,0,-1.8],[0,0.45,0],[1,0,0],m.dNeon);
    rb.floor(1.6,3.0,2.6,4.2,m.dGrime);rb.floor(5.0,4.6,1.4,1.1,m.dPuddle);
    // back wall: chalkboard, sign, sausages, tv, swing door
    rb.wallZ(3.6,1.95,1.6,1.2,m.dChalk);rb.wallZ(5.9,2.55,1.9,0.48,m.dSign);
    for(let i=0;i<5;i++){const x=5.1+i*0.25;rb.cyl([x,1.55,0.18],0.006,0.006,0.65,m.black,{noDepth:true});for(let k=0;k<3;k++)rb.part(Geo.capsule(0.035,0.035,0.22,8),M4.trs([x,1.55-k*0.27,0.18],[0,0,0.1*(k%2?1:-1)]),m.sausage,{noDepth:true});}
    rb.box([0.75,2.25,0.02],[1.5,2.75,0.3],m.black);rb.decal([1.12,2.5,0.31],[0.62,0,0],[0,0.4,0],[0,0,1],m.dTV);
    rb.box([7.35,0,0],[8.45,2.2,0.06],m.steelDark);rb.box([7.38,0,0.06],[7.88,1.9,0.1],m.white);rb.box([7.92,0,0.06],[8.42,1.9,0.1],m.white);
    rb.cyl([7.63,1.4,0.1],0.09,0.09,0.02,M([.25,.35,.4],{spec:1.4}),{rot:[PI/2,0,0]});rb.cyl([8.17,1.4,0.1],0.09,0.09,0.02,M([.25,.35,.4],{spec:1.4}),{rot:[PI/2,0,0]});
    // counter & display case
    rb.box([1.6,0,1.5],[7.0,0.62,2.3],m.woodDark,{block:true});rb.box([1.55,0.62,1.45],[7.05,0.68,2.35],m.steelBright);
    rb.box([1.65,0.68,1.55],[6.95,1.2,1.62],m.steelDark);
    for(let i=0;i<9;i++){const x=1.9+i*0.55;rb.box([x,0.69,1.7],[x+0.42,0.74,2.15],m.steelBright,{noDepth:true});
      const R=NL.Tex.rng(200+i);const mt=R()<.33?m.meat:R()<.5?m.sausage:m.fat;rb.part(Geo.sphere(1,10,6),M4.trs([x+0.21,0.79,1.92],[0,R()*2,0],[0.17,0.05,0.15]),mt,{noDepth:true});}
    rb.box([1.6,0.68,2.28],[7.0,1.2,2.3],m.glass,{noDepth:true});rb.box([1.6,1.18,1.55],[7.0,1.2,2.3],m.glass,{noDepth:true});
    rb.decal([4.3,0.35,2.31],[0.4,0,0],[0,0.52,0],[0,0,1],m.dMissing);
    rb.box([6.15,1.2,1.65],[6.65,1.45,2.05],m.black);rb.box([6.2,1.45,1.7],[6.6,1.5,1.85],m.steelDark);
    rb.box([1.85,1.2,1.75],[2.3,1.24,2.1],m.chrome);rb.box([2.0,1.24,1.85],[2.15,1.5,1.95],m.white);
    // customer area props
    rb.decal([5.6,0.5,4.2],[0.32,0,0.32],[0,0.62,0],[0.7,0,-0.7],m.dWet);
    rb.cyl([4.7,0,4.9],0.2,0.17,0.35,m.sodium.color?M([.85,.65,.15]):m.white);rb.cyl([4.75,0.2,4.85],0.012,0.012,1.3,m.woodDark,{rot:[0.2,0,0.15],noDepth:true});
    rb.box([7.2,0,4.2],[8.6,0.9,5.3],m.white,{block:true});rb.box([7.25,0.9,4.25],[8.55,0.93,5.25],M([.7,.85,.95],{alpha:.35,spec:1.5,mottle:0}));rb.box([7.3,0.7,4.3],[8.5,0.86,5.2],M([.55,.75,.9],{emis:[.2,.3,.4]}));
    rb.box([0,0.6,0],[0.35,0.62,5.9],m.cap,{noDepth:true});
    rb.block(7.1,4.1,8.7,5.4);
  },
  spawn:{x:7.9,z:0.9,ry:0},
  exits:[{id:'toBack2',label:'Back room',at:[7.9,1.2,0.15],box:[7.35,0,0,8.45,2.2,0.3],stand:[7.9,0.8],face:[7.9,0],to:'backroom',spawn:{x:6.0,z:5.2,ry:PI}}],
  inter:[
    {id:'shutter',label:'Front shutter',at:[0.08,1.6,4.1],box:[0,0.6,0.35,0.3,2.6,5.65],stand:[0.85,4.1],face:[0,4.1]},
    {id:'register',label:'Cash register',at:[6.4,1.5,1.85],box:[6.1,1.15,1.6,6.7,1.55,2.1],stand:[6.4,2.85],face:[6.4,1.8]},
    {id:'case',label:'Display case',at:[3.6,1.0,1.95],box:[1.6,0.6,1.5,5.8,1.25,2.35],stand:[3.6,2.85],face:[3.6,1.9]},
    {id:'chalk',label:"Today's cuts",at:[3.6,1.95,0.05],box:[2.8,1.35,0,4.4,2.55,0.2],stand:[3.6,1.0],face:[3.6,0],if:S=>true},
    {id:'tv',label:'Little television',at:[1.12,2.5,0.3],box:[0.75,2.25,0,1.5,2.75,0.35],stand:[1.1,1.1],face:[1.1,0]},
    {id:'wetfloor',label:'Wet floor sign',at:[5.6,0.7,4.2],box:[5.35,0,4.0,5.85,0.85,4.4],stand:[5.2,3.6],face:[5.6,4.2]},
    {id:'poster',label:'Missing poster',at:[4.3,0.4,2.32],box:[4.0,0,2.25,4.6,0.65,2.45],stand:[4.3,3.0],face:[4.3,2.3]}
  ],
  particles:[{type:'motes',n:45,area:[0.3,6,0.5,5.5],y:[0.3,2.6],col:[1,.7,.55]}]
};

ROOMS.alley={id:'alley',name:'The Alley',sub:'Behind Ferrier Street',W:10,D:6,H:4.4,ambience:'alley',rain:true,
  sky:[.12,.14,.2],ground:[.04,.04,.06],
  grade:{sh:[.6,.7,1.05],hi:[1.1,.92,.78],ink:[.03,.03,.06],sat:.82,wash1:[.015,.02,.035],wash2:[.06,.07,.1]},
  shadow:{pos:[2.5,3.1,0.7],target:[3.4,0,2.6],fov:2.0,far:12,idx:0},
  lights(S){return [{pos:[2.5,3.1,0.7],color:[1,.6,.26],intensity:2.3,range:8},{pos:[10.2,0.65,4.05],color:[1,.95,.82],intensity:1.4,range:6},{pos:[5,7,5],color:[.35,.45,.75],intensity:.7,range:14},{pos:[5.5,0.6,3.0],color:[1,.1,.08],intensity:.45,range:2.2}];},
  flicker(t){return 1-0.05*Math.max(0,Math.sin(t*9.3));},
  build(rb,S){const m=mats(),f=S.flags;
    rb.shell(10,6,4.4,m.asphalt,m.brick,m.brick,m.cap);
    rb.floor(3.4,3.0,2.4,1.6,m.dPuddle);rb.floor(7.0,1.8,2.2,1.4,m.dPuddle);rb.floor(1.5,4.8,1.6,1.4,m.dPuddle);rb.floor(5.0,0.6,0.5,0.5,m.dDrain);
    rb.wallX(3.4,2.3,3.4,1.7,m.dGraffiti);rb.wallX(1.2,1.5,0.38,0.5,m.dMissing);rb.wallX(1.65,1.45,0.38,0.5,m.dMissing);rb.wallX(5.3,1.55,0.38,0.5,m.dMissing);
    // back door + lamp
    rb.box([1.95,0,0],[3.05,2.3,0.08],m.cap);
    if(f.backDoorOpen) rb.part(Geo.box(1.05,2.25,0.06),M4.trs([3.05,1.12,0.55],[0,PI/2-0.3,0],[1,1,1]),m.woodDark);
    rb.box([2.35,3.0,0],[2.65,3.08,0.55],m.steelDark,{noDepth:true});rb.part(Geo.cyl(0.04,0.16,0.12,12,false),M4.trs([2.5,2.95,0.62]),m.steelDark,{noDepth:true});rb.sph([2.5,2.98,0.62],[0.07,0.04,0.07],m.sodium,{noDepth:true});
    // dumpster
    rb.box([4.2,0.12,0.1],[6.0,1.25,1.2],m.green,{block:true});rb.box([4.15,1.25,0.05],[6.05,1.32,1.25],M([.1,.22,.15]));[[4.35,0.3],[5.85,0.3],[4.35,1.0],[5.85,1.0]].forEach(p=>rb.cyl([p[0],0,p[1]],0.07,0.07,0.12,m.black));
    rb.box([6.4,0,0.1],[7.6,0.5,1.1],m.woodDark,{block:true});rb.box([6.5,0.5,0.15],[7.5,0.62,1.05],m.wood);
    rb.cyl([8.8,0,0.15],0.08,0.08,4.4,m.steelDark);rb.cyl([9.2,0,0.15],0.05,0.05,4.4,m.steelDark);
    // fire escape stub on left wall
    rb.box([0,3.2,1.0],[0.9,3.26,4.2],m.black,{noDepth:true});for(let z=1.0;z<=4.2;z+=0.3)rb.box([0.85,3.26,z-0.01],[0.88,3.75,z+0.01],m.black,{noDepth:true});
    // the car
    const cm=M([1,1,1],{tex:'car',texScale:.6,spec:1.6,mottle:.1});
    rb.box([5.6,0.25,3.35],[9.9,0.85,4.75],cm,{block:true});rb.box([6.6,0.85,3.45],[8.7,1.38,4.65],cm);
    rb.box([6.65,0.9,3.44],[8.65,1.33,3.46],M([.15,.18,.25],{spec:2,emisK:.1}),{noDepth:true});rb.box([6.65,0.9,4.64],[8.65,1.33,4.66],M([.15,.18,.25],{spec:2}),{noDepth:true});
    rb.box([5.58,0.55,3.4],[5.62,0.7,4.7],m.chrome);rb.box([9.88,0.45,3.4],[9.92,0.62,4.7],m.chrome);
    [[6.3,3.33],[6.3,4.77],[9.1,3.33],[9.1,4.77]].forEach(p=>rb.part(Geo.cyl(0.33,0.33,0.24,16),M4.trs([p[0],0.33,p[1]-0.12],[PI/2,0,0]),m.rubber));
    rb.box([9.9,0.55,3.5],[9.95,0.72,3.8],M([1,1,.9],{emis:[1,.97,.85]}),{noDepth:true});rb.box([9.9,0.55,4.3],[9.95,0.72,4.6],M([1,1,.9],{emis:[1,.97,.85]}),{noDepth:true});
    rb.box([5.55,0.6,3.5],[5.6,0.72,3.75],m.redLamp,{noDepth:true});rb.box([5.55,0.6,4.35],[5.6,0.72,4.6],m.redLamp,{noDepth:true});
    rb.box([7.5,1.38,3.9],[7.7,1.42,4.2],m.chrome,{noDepth:true});
  },
  spawn:{x:2.5,z:1.0,ry:0.2},
  exits:[],
  inter:[{id:'car',label:'The long black car',at:[7.7,1.5,4.0],box:[5.6,0,3.35,9.9,1.4,4.75],stand:[6.2,2.75],face:[7,4]},
    {id:'graffiti',label:'Graffiti',at:[0.1,2.3,3.4],box:[0,1.4,1.7,0.2,3.2,5.1],stand:[1.0,3.4],face:[0,3.4]},
    {id:'posters',label:'Missing posters',at:[0.1,1.5,1.45],box:[0,1.2,0.95,0.2,1.8,1.9],stand:[1.0,1.5],face:[0,1.5]},
    {id:'dumpster',label:'Dumpster',at:[5.1,1.4,0.6],box:[4.2,0,0.1,6.0,1.3,1.2],stand:[5.1,1.8],face:[5.1,0.6]}],
  particles:[{type:'motes',n:20,area:[0.5,9.5,0.5,5.5],y:[0.3,3],col:[1,.8,.6]},{type:'exhaust',n:22,center:[5.45,0.32,3.65]}]
};

NL.ROOMS=ROOMS; NL.RB=RB; NL.mats=mats; NL.M=M;
})();
