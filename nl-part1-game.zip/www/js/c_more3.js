'use strict';
/* THE NEW LORD — more arcs: Séverine when she's your enemy, Pemberton after your blood, Tariq after he knows, Rostova's X-ray machine, Gideon's ledger, Okafor after the truth, Halloran's wife, Dot and Mrs. Sallow again, Quill and Pellow on Friday */
NL.Script.add(String.raw`
// =====================================================================
// SÉVERINE · when she's your enemy
// =====================================================================
# sxE.0 arc=severine night=2,3 label="\"We should talk, my lady. Enemy to enemy.\"" if=room:vip&alive:sev&flag:sevEnemy prio=2
@focus severine
severine: Enemy to enemy. How *bracing*. Most people who've lost to me in this crypt don't come back. They write letters. Long ones. Mostly about their feelings.
severine: You beat my Keeper's challenge on Monday by being stubborn and lucky. Neither of those keeps. What do you want?
* "A truce. Until Friday."  -> sxE.truce
* "To know why you hate me. Not him. Me."  -> sxE.why
* "Nothing. I wanted you to see I'm not afraid."  -> sxE.afraid {do lean:pride+1}

# sxE.truce
severine: A truce. With terms?
* "You don't send anyone after my people. I don't send anyone after yours."  -> sxE.terms {do lean:loyalty+1}
* "No terms. Just: not yet."  -> sxE.notyet

# sxE.terms
severine: Your people. The comedian, the shopkeeper, the old man in the car. Very well. I'll leave your mortals alone until Friday. After Friday, the truce ends with the verdict.
{do flag:sevTruce=1; rel:severine+1; mem:severine:truce}
@end

# sxE.notyet
severine: "Not yet." The most honest phrase in the Court. Fine. Not yet.
@end

# sxE.why
severine: You? I don't hate you. I don't know you. I hate what you're *wearing*. Every time you walk into my crypt in that coat, with that walk, Absalom walks in with you.
severine: Take it off. The coat. Just once. Here. Let me look at you without him.
* Take off the coat.  -> sxE.coat {do lean:pride-1}
* "No. He's part of me now."  -> sxE.keep {do sync+2}

# sxE.coat
> You take it off. You stand in the crypt in a shirt that was never yours either, cold, smaller than you were a second ago.
> She looks at you for a long time.
severine: ...There you are. Oh. You're so *young*.
severine: Put it back on. Put it on. Nobody should see you like that down here.
{do rel:severine+2; flag:sevEnemy=0; mem:severine:coatoff}
@end

# sxE.keep
severine: Part of you. Then I'll hate that part. I'm very precise. I can hate a third of a person.
@end

# sxE.afraid
severine: Not afraid. In my crypt. Of me.
> The candles in the bone chandelier flicker, as if a door had opened somewhere very far below.
severine: Good. Neither am I. Of you. We'll see which of us is lying on Friday.
@end

// =====================================================================
// PEMBERTON · after your blood
// =====================================================================
# pxF.0 arc=pemberton night=3,4,5 label="\"How do you feel, Pemberton?\"" if=flag:pemFed&!flag:pemDead prio=2
@focus pemberton
pemberton: Feel, ‹sir›? Younger. Twelve years, I'd say. My knee's stopped. I read the paper this morning without my glasses. I'd forgotten the crossword was in such small print.
pemberton: And... I'll be honest, since you seem to like that. I feel *yours*. Not his. I keep reaching for things he'd want and then stopping, because you wouldn't want them. It's like moving house and keeping the old key on the ring.
* "Is that bad?"  -> pxF.bad
* "You're not mine, Pemberton. You're yours."  -> pxF.yours {do lean:mercy+1}
* "Good. I need you."  -> pxF.need {do lean:loyalty+1}

# pxF.bad
pemberton: Bad? No. Strange. I was the Sheriff's for so long I'd forgotten I was ever anything else. Now I'm... yours, I suppose, and I find I don't mind, and I don't know what that says about me.
@end

# pxF.yours
pemberton: Mine. ‹Sir›, I haven't been mine since 1983. I wouldn't know what to do with myself.
pemberton: ...I might take up gardening. If there's an after. I've always fancied roses. Very difficult. Very thorny. Rather like the job.
{do rel:pemberton+1}
@end

# pxF.need
pemberton: Then you have me, ‹sir›. For as long as the blood lasts. Longer, if I'm honest.
@end

// =====================================================================
// TARIQ · after he knows what you are
// =====================================================================
# txK.0 arc=tariq night=3,4 label="\"Are you still all right with me coming in?\"" if=room:luckymart&flag:tariqKnows prio=1
@focus tariq
tariq: All right? I've been thinking about it for two days. I looked it up. On the internet. There's a lot on the internet about your sort. Most of it's very sexy and very wrong.
tariq: One website said you can't come in unless you're invited. I invited you on Monday without knowing. "Come in, it's warm." So it's my fault.
* "It's no one's fault. Do you want me to stop coming?"  -> txK.stop
* "Garlic doesn't work either."  -> txK.garlic
* "What else did the internet say?"  -> txK.internet

# txK.stop
tariq: Stop? No. No. Then who would stand by the freezer and look at the ice cream? The ice cream would be lonely.
tariq: You're the strangest customer I've ever had and you've never once been rude to me. Come. Keep coming. I'll keep saying "nurse".
{do rel:tariq+1}
@end

# txK.garlic
tariq: I know. I tested. I put a garlic bread in the microwave yesterday when you came in and you said "that smells nice". I was so disappointed.
@end

# txK.internet
tariq: That you sleep in coffins, which I know is true, because Gideon told me. That you can turn into bats, which I hope is not true, because I'm afraid of bats. That you're very lonely.
tariq: That one I believed. That's the one that made me sad.
@end

// =====================================================================
// ROSTOVA · the X-ray machine
// =====================================================================
# rxX.0 arc=rostova night=2,3 label="\"What will you do with the money? The blood money.\"" if=room:stjude&mem:rostova.blood&alive:rostova prio=1
@focus rostova
rostova: The X-ray machine. A new one. The old one's from 1987 and it gives the patients more radiation than the moon.
rostova: Forty dollars a bag, twelve bags a week, for three years. That's an X-ray machine. That's an ultrasound. That's a defibrillator that doesn't need you to kick it.
rostova: Vampire money buys a lot of medicine. I used to think that was a beautiful irony. Now I just think it's maths.
* "And LANTERN's money? What does that buy?"  -> rxX.lantern {if flag:knowTrial|seen:tr.0}
* "That's a good use of it."  -> rxX.good

# rxX.lantern
> She looks at you sharply.
rostova: LANTERN's money buys the basement. And the equipment. And the silence. And seven funerals that never happened.
rostova: Don't. Not in the clinic. I said. In here I'm still a doctor.
@end

# rxX.good
rostova: Is it? I can't tell any more. I used to know what good was. It had a pulse.
@end

// =====================================================================
// GIDEON · the ledger of boxes
// =====================================================================
# gxL.0 arc=gideon night=2,3,4 label="\"Can I see the ledger? Who's slept here?\"" if=room:pawn&mem:gideon.history prio=0
@focus gideon
gideon: The ledger. Fifty-five years of it. Nobody's ever asked to see it. They all assume I don't keep one. I keep three.
> He brings out a cloth-bound book, very thick. Box numbers down the side. Dates. Names in pencil, sometimes, mostly just initials or nothing at all: *Gent., Court. Lady, fur. Young man, crying.*
gideon: 1977, August. Box nine. *Tall gent, long coat, bleeding from the cuffs. Paid in gold. Didn't sleep.* That was your Sheriff. The night after the docks.
gideon: He sat in box nine with the lid open and his hands in his lap until dawn and never said a word. I brought him tea. He looked at it like I'd brought him a baby.
tenant: ...I didn't know where else to go. After Pier Nine. I couldn't go to the study. I couldn't bear the chair.
{do mem:gideon:ledger; sync+1}
@end

// =====================================================================
// MRS. OKAFOR · after the truth
// =====================================================================
# oxT.0 arc=okafor night=3,4,5 label="\"How are you, since?\"" if=room:apt&flag:daniTold prio=1
@focus okafor
okafor: Since. Since you told me. I sleep three hours a night instead of one. I eat. I'm angry. I've never been angry like this. It's very clean. Like bleach.
okafor: I phoned the families. Some of them. The ones Miller's file had numbers for. Mrs. Sowa in 210, Pete's mother. Mr. Mbeki in Corder House. We're going to have a service. We don't have bodies. We'll have a service anyway.
* "I'll come."  -> oxT.come {do promise:service:Go to the service for the seven}
* "What can I do?"  -> oxT.do

# oxT.come
okafor: You. At a church. On a Sunday morning. Can you?
okafor: ...Come to the evening one, then. We'll do one at night too. For you. And for anyone like you who wants to come and doesn't drink the tea.
@end

# oxT.do
okafor: Do? Make them stop. Whoever's left. Make sure there's never an eighth.
okafor: There was an eighth, wasn't there. Miller said. Number eight. Withdrawn.
* "That was me."  -> oxT.me {do lean:candour+1}
* "I don't know."  -> oxT.dontknow

# oxT.me
> She doesn't say anything. She comes across the room, slowly, an old woman with bad knees, and puts both her hands on your face, the way you'd hold a child's face to look at it properly.
okafor: You came back. You were down there with her and you came back.
okafor: Then you're the one who gets to tell it. All of it. On Friday, or whenever it is. You tell them for her.
{do rel:okafor+2; mem:okafor:eight}
@end

# oxT.dontknow
okafor: You don't know. All right. Keep looking.
@end

// =====================================================================
// MR. HALLORAN · his wife
// =====================================================================
# hlW.0 arc=halloran night=3,4 label="\"Mr. Halloran. Is Mrs. Halloran all right?\"" if=room:rookery&actor:halloran prio=1
@focus halloran
halloran: Maureen? She's... she's packed a bag. Again. It's by the door. It's been by the door since Tuesday. She sits next to it and watches the telly.
halloran: She said this time she means it. She said she can't live with a man who loves thirty-one cats more than her. I said they're not my cats. She said that's the problem.
* "Do you love them more than her?"  -> hlW.more
* "Tell her you'll name one. Just one. For her."  -> hlW.name {do lean:mercy+1}
* "Let her go."  -> hlW.go

# hlW.more
halloran: More? No. No. Different. The cats don't need me to be anyone. Maureen needs me to be the man she married in 1973. He was very handsome. He had hair.
halloran: I don't know where he went. I'm trying to find him. He's not in the yard.
@end

# hlW.name
halloran: Name one. For her. A cat called Maureen.
> He thinks about it with his whole face.
halloran: ...She'd hate that. She'd absolutely hate that. She'd laugh. She hasn't laughed since Easter.
halloran: The tabby with the white feet. She always liked that one. She pretended not to. Maureen. A cat called Maureen.
{do flag:catMaureen=1; rel:halloran+2}
@end

# hlW.go
halloran: Let her go. Fifty-one years. Let her go.
> He nods, slowly. He goes inside 302 and shuts the door. You hear the television go off, and two voices, very quiet, for a long time.
@end

// =====================================================================
// DOT · the 9, again
// =====================================================================
# busA.0 street=3,4,5 if=flag:busDone
> At the Halloran stop the 9 pulls up without you hailing it, and Dot leans over and opens the doors.
dot: Hop on, love. No charge. Not after the lad.
@gate flag:busDone=home ? busA.home : busA.other

# busA.home
dot: His mom came to the depot. Mrs. Ferreira. She brought me a cake. A whole cake. In a tin. She said "for the driver who kept the heater on". I've never had a cake. Thirty-one years.
@end

# busA.other
dot: I still look in the back seat at 3:12. Every night. Habit. Some nights I think I see him.
@end

// =====================================================================
// QUILL AND PELLOW · Friday
// =====================================================================
# qp5.0 arc=tenant night=5 label="The two clerks" if=flag:heightsDone&flag:clerkDone prio=3
tenant: Quill and Pellow. The two night clerks. One on the Heights, one in the Courthouse, a hundred and fifty years between them. They've never met, you know. Pellow's father knew Quill's handwriting from the old books. That's all.
tenant: Tonight they'll both be sitting at their desks with the lamp on, at the top and the bottom of the city, while the Magistrate goes down to Platform 0. Two lights. One at each end.
tenant: Every city needs a clerk who stays up. I never told either of them that. I should have.
@end
`,'c_more3');
