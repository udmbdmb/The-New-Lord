'use strict';
/* THE NEW LORD — carried words: people ask you to take a message, and you decide what arrives */
NL.Script.add(String.raw`
# msg.ros arc=rostova night=3,4,5 label="\"Is there anything you want me to tell Mrs. Okafor?\"" if=met:okafor prio=1
@focus rostova
rostova: Tell her...
> She takes her glasses off. She cleans them on her coat, which is dirtier than the glasses.
rostova: Danielle asked for her. At the end. On the fourth floor, in August, the night we lost her. She wasn't frightened. She was annoyed. She said, "Tell my mom she leaves the landing light on too much and it's a waste of money." And then she said "tell her it's okay, I could see it from the window." And then she didn't say anything.
rostova: I never told her. I'm a coward. You tell her. Or don't. You'll know better than me. You've been in her flat.
* "I'll tell her. Exactly what Dani said."  -> msg.ros1
* "I'll tell her Dani wasn't frightened. Nothing else."  -> msg.ros2
* "No. That's yours to carry, Doctor. Not mine."  -> msg.ros3

# msg.ros1
{do flag:msgRos=exact}
rostova: Exactly. Yes. Good. Every word. The landing light.
@end

# msg.ros2
{do flag:msgRos=soft}
rostova: Not frightened. Yes. Maybe that's enough. Maybe that's kinder. I wouldn't know. I gave up deciding what's kind years ago.
@end

# msg.ros3
rostova: Mine. Yes. It is mine.
> She puts her glasses back on. She doesn't say anything else, and you can tell she's going to carry it up the stairs to the fourth floor and set it down on her desk next to the others.
{do lean:candour+1; rel:rostova-1; flag:rosMustTell=1}
@end

# msg.rosO arc=okafor night=3,4,5 label="\"Mrs. Okafor. I've got something from Dani. From the end.\"" if=flag:msgRos&!flag:msgRosDone prio=4
@focus okafor
> She puts the kettle down. She doesn't turn round.
okafor: From the end.
okafor: Go on, then. I've been waiting since August for someone to say that.
@gate flag:msgRos=exact ? msg.rosO1 : msg.rosO2

# msg.rosO1
> You tell her. The landing light. The waste of money. *It's okay, I could see it from the window.*
> For a long moment she doesn't move at all. Then she laughs. It's a terrible laugh, and a real one.
okafor: The landing light. The *landing light*. Dying, and she's telling me off about the electricity bill.
okafor: She could see it. From the window. She could see it.
> She goes out onto the landing in her slippers. The bulb over the stairs is on, as it always is. She stands under it with her arms folded and looks at it like it's a person.
okafor: I'm never turning it off. She can complain all she likes.
{do flag:msgRosDone=1; rel:okafor+3; comp+1; xp:30:The Landing Light}
@end

# msg.rosO2
> You tell her Dani wasn't frightened. That's all.
okafor: Not frightened.
okafor: No. No, she wouldn't have been. She was never frightened of anything except spiders and her father's driving.
okafor: Thank you. Thank you, love. That's... that's enough. I can sleep on that.
> She can. You can see it come off her shoulders. You'll never know what else she might have carried, or what she might have put down.
{do flag:msgRosDone=1; rel:okafor+2; comp+1}
@end

# msg.ros4 arc=rostova night=4,5 label="\"I told her. About the landing light.\"" if=flag:msgRosDone&flag:msgRos=exact prio=2
@focus rostova
rostova: And?
* "She went out and stood under it."  -> msg.ros5

# msg.ros5
rostova: ...
rostova: She stood under it.
> Rostova sits down. For a moment you think she's going to cry. She doesn't. She opens her notebook and writes something, very small, in the margin of a page of blood counts.
> You see it upside down: *Okafor, D. — landing light. Told.*
{do rel:rostova+2; flag:rosRelief=1}
@end

# msg.pem arc=pemberton night=3,4,5 label="\"Do you want me to say anything to Valko?\"" if=!flag:valkoDead&met:valko prio=1
@focus pemberton
pemberton: To Valko. ‹Sir›, Mr. Drăgan and I have shared a car for forty years and said perhaps two hundred words to each other.
pemberton: ...Tell him the seat's still his. The back left. Where he sat with his knees up by his ears because the Sheriff wouldn't let him in the front. Tell him I've kept it clean. I've kept the window down an inch on that side, the way he likes, for the smells.
pemberton: Don't tell him I said "the way he likes". He'll think I've gone soft.
* "I'll tell him exactly that. Including the soft part."  -> msg.pem1
* "I'll tell him the seat's his. Nothing else."  -> msg.pem2
* "Tell him yourself. Next time he's in the car."  -> msg.pem3

# msg.pem1
{do flag:msgPem=soft}
pemberton: ‹Sir›. That is precisely what I asked you not to do.
pemberton: ...Very well.
@end

# msg.pem2
{do flag:msgPem=plain}
pemberton: Thank you, ‹sir›. Brevity. He'll appreciate brevity.
@end

# msg.pem3
pemberton: Myself. In the car. Out loud.
pemberton: I'm sixty-four, ‹sir›. I don't know that I have it in me. But I'll consider it. I'll consider it all the way to the Switchyard and back.
{do rel:pemberton+1; flag:pemSelf=1}
@end

# msg.pemV arc=valko night=3,4,5 label="\"Pemberton says the back seat's still yours.\"" if=flag:msgPem&!flag:msgPemDone&!flag:valkoDead prio=3
@focus valko
valko: The seat.
@gate flag:msgPem=soft ? msg.pemV1 : msg.pemV2

# msg.pemV1
> You tell him. The back left. The knees. The window down an inch, for the smells. *The way he likes.*
> Valko stands there, a sixty-year Hound with a scar through his lip, and goes slowly red from the collar up.
valko: The way I... he said that? The old man said that?
valko: Forty years. Forty years he's been leaving that window down. I thought it was broken. I thought it was a draught. I never said thank you.
valko: Don't tell him I... no. Tell him. Tell him I said thank you. Tell him I'll sit in the front now, if he wants. If you let me.
{do flag:msgPemDone=1; rel:valko+2; rel:pemberton+1; flag:valkoFront=1}
@end

# msg.pemV2
valko: Still mine. Good. Good. Somebody should have a seat that's still theirs, this week.
> He nods once. That's all. But he walks a little straighter for the rest of the night.
{do flag:msgPemDone=1; rel:valko+1}
@end

# msg.sev arc=severine night=3,4 label="\"You want me to carry something to Malakor, don't you.\"" if=alive:sev&!flag:malakorDead&flag:malakorTalked prio=1
@focus severine
severine: How perceptive. Yes.
severine: Tell the Butcher this. The lance he sold me was faulty. It killed a Sheriff instead of a doctor's experiment. I want my money back, all of it, by Thursday, or I'll tell the Magistrate whose hands built the thing that killed Absalom Vane.
severine: Word for word, darling. I'll know if you change a syllable. I always know.
* "Word for word."  -> msg.sev1
? stagecraft 11 "Of course, my lady. (Change every syllable.)"  -> msg.sev2 | msg.sev3 {id msg_sev}
* "Carry your own threats."  -> msg.sev4

# msg.sev1
{do flag:msgSev=exact}
severine: Good. You're more useful than you look.
@end

# msg.sev2
> She doesn't notice. For once in two hundred and fifty years, Séverine Marchetti doesn't notice.
{do flag:msgSev=twist; xp:20}
severine: Good. Thursday.
@end

# msg.sev3
severine: You're going to soften it. I can see you planning it. You have the face of a woman at a christening deciding not to mention the baby's ears.
severine: Word for word. Or I send Ashby. And Ashby will add things.
{do flag:msgSev=exact}
@end

# msg.sev4
severine: My own. How quaint. Very well. Ashby will do it, and Ashby will add things, and then we'll all have a war, and it'll be your fault for being principled.
{do rel:severine-1; flag:sevSentAshby=1}
@end

# msg.sevM arc=malakor night=3,4,5 label="\"I've got a message from Séverine.\"" if=flag:msgSev&!flag:msgSevDone&!flag:malakorDead prio=3
@focus malakor
malakor: Of course you do. She hasn't the nerve to come down the stairs herself. Too many Butchers. Too much honest work. Go on.
@gate flag:msgSev=twist ? msg.sevM3 : msg.sevM0

# msg.sevM0
* Deliver it word for word.  -> msg.sevM1
* Deliver it word for word. Then add: "She's frightened, Malakor. That's all this is."  -> msg.sevM2

# msg.sevM1
> You tell him. The faulty lance. The money by Thursday. The Magistrate.
> He listens. He puts down the bone saw. He picks it back up.
malakor: She wants her money back. For a lance that worked perfectly. That did exactly what it was built to do, in the hands of a woman who didn't know who she was pointing it at.
malakor: Tell her: no. Tell her if she says my name to the Magistrate I'll say hers, and mine's only the hands, and hers is the money. Tell her that word for word. See how *she* likes it.
{do flag:msgSevDone=1; flag:sevMalakorWar=1; rel:malakor+1}
@end

# msg.sevM2
> You tell him. Then you tell him the other thing.
malakor: Frightened.
malakor: ...Huh. Yes. Of course she is. Absalom's dead and she paid for the thing that did it and now there's you, in his coat, carrying her mail.
malakor: Tell her I'm not giving her a dollar. Tell her also that I'm not going to the Magistrate. Tell her that second part first. She'll understand.
{do flag:msgSevDone=1; flag:sevMalakorTruce=1; rel:malakor+2; lean:mercy+1}
@end

# msg.sevM3
> What you tell him is: *Lady Séverine apologizes for the trouble over the lance. She considers the matter closed. She hopes the Syndicate will remember who paid on time.*
> He stares at you for a very long time.
malakor: She said that. Séverine. Apologizes.
malakor: She didn't say that. Nobody's ever heard her say that. You made it up.
malakor: ...I'll take it. I'll take it and I'll pretend she said it. That's the closest thing to peace this Ward's had since 1912.
{do flag:msgSevDone=1; flag:sevMalakorTruce=1; flag:msgLied=1; rel:malakor+1; lean:candour-1}
@end

# msg.sevR arc=severine night=3,4,5 label="\"Malakor sent an answer.\"" if=flag:msgSevDone&!flag:msgSevBack&alive:sev prio=3
@focus severine
@gate flag:sevMalakorWar ? msg.sevR1 : msg.sevR2

# msg.sevR1
severine: "Mine's only the hands, and hers is the money." Yes. I expected that. I hoped for something stupider.
severine: Well. Then we'll both keep quiet on Friday and loathe each other in perfect silence. That's what passes for diplomacy in this city.
{do flag:msgSevBack=1}
@end

# msg.sevR2
severine: He's not going to the Magistrate.
severine: He said to tell me that first. Did he. That vulgar, enormous, sentimental... yes. Yes, I understand.
> She doesn't say anything else. The fan does not move for nearly a minute.
{do flag:msgSevBack=1; rel:severine+1}
@end

# msg.mil arc=miller night=3,4 label="\"Do you want me to say anything to Mrs. Okafor? I see her.\"" if=met:okafor prio=1
@focus miller
miller: You see her. Of course you do. Everybody in the Rookery sees her. She knocks on every door in the building every week with Dani's picture.
miller: Tell her I haven't stopped. Tell her the case is still open on my desk, not in a box. She thinks it's in a box. They told her it went to a box. It didn't.
* "I'll tell her."  -> msg.mil1
* "Why don't you tell her?"  -> msg.mil2

# msg.mil1
{do flag:msgMil=1}
miller: Thanks. And... don't tell her I said it like I'm tired. I'm not tired. Tell her I said it like a cop.
@end

# msg.mil2
miller: Because she'd make me tea. And she'd sit me down. And she'd ask about Mateo, because she always does, because her daughter's missing and mine's... my brother's missing, and we'd sit there, two women with missing people, drinking tea in a flat with a landing light on, and I wouldn't get up again till Thursday.
miller: I can't sit down. If I sit down I stop.
{do flag:msgMil=1; mem:miller:cantsit}
@end

# msg.milO arc=okafor night=3,4,5 label="\"Detective Miller says she hasn't stopped.\"" if=flag:msgMil&!flag:msgMilDone prio=3
@focus okafor
okafor: Hasn't stopped. No. She wouldn't. That girl hasn't stopped since 2011. I've seen her on the stairs at five in the morning, knocking.
okafor: You tell her something from me. You tell her she's to eat something. Proper. Not that cruller from the Lucky Mart she never finishes. And you tell her Dani wouldn't want anybody working themselves to death over her. Dani'd be mortified.
* "I'll tell her."  -> msg.milO1
* "She won't listen."  -> msg.milO2

# msg.milO1
okafor: Good. And take this. It's jollof. It was for Thursday. Take it.
> She puts a foil-covered dish in your hands. It's still warm. You haven't held anything warm in four days that wasn't bleeding.
{do flag:msgMilDone=1; flag:jollofMiller=1; rel:okafor+1}
@end

# msg.milO2
okafor: No. Neither did Dani. Tell her anyway. Some things you say so they've been said.
{do flag:msgMilDone=1; rel:okafor+1}
@end

# msg.milB arc=miller night=3,4,5 label="Give Miller the dish of jollof from Mrs. Okafor." if=flag:jollofMiller&!flag:jollofDone prio=4
@focus miller
miller: What's... is that Mrs. Okafor's dish? With the blue lid?
> You tell her. Eat something. Proper. Dani'd be mortified.
> She takes the lid off. Steam. Rice the color of sunset. She stands on the sidewalk in the rain at two in the morning with a dish of jollof in one hand and a case file in the other.
miller: ...She's got a nerve. She's got a real nerve.
> She eats it with the plastic fork from her coffee lid, standing up, in the rain. All of it.
miller: Don't tell her I ate it standing up. She'll kill me.
{do flag:jollofDone=1; rel:miller+2; comp+1; xp:20:Proper Food}
@end

# msg.ten arc=tenant night=3,4,5 label="\"Is there anything you want me to tell Valko?\"" if=!flag:valkoDead&met:valko prio=-1
@focus tenant
tenant: Valko.
tenant: Sixty years he followed me. Sixty years half a pace behind, with his nose up, hunting whoever I pointed at. I never once told him he'd done well. You don't, to a Hound. It goes to their heads.
tenant: Tell him... no. No. I don't know what to tell him. Tell him whatever you think he needs. You've watched him longer this week than I ever bothered to look.
* "I'll tell him you said he was a good man. Not a good dog. A good man."  -> msg.ten1
* "I'll tell him you were proud of him."  -> msg.ten2
* "I won't make something up for you. Think of it yourself."  -> msg.ten3

# msg.ten1
tenant: A good man. Not a good dog.
tenant: ...Yes. That. That's the thing I never said, because I didn't think of him as either. Say that.
{do flag:msgTen=man; sync+1}
@end

# msg.ten2
tenant: Proud. Yes. That'll do. It's even true. Isn't that strange. I didn't know until you said it.
{do flag:msgTen=proud; sync+1}
@end

# msg.ten3
tenant: ...Fair. Very fair.
tenant: Then tell him this, from me, in my words, which are the only ones I've got: "Valko. You may stop now." That's all. He'll know.
{do flag:msgTen=stop; sync+2; lean:candour+1}
@end

# msg.tenV arc=valko night=3,4,5 label="\"Valko. I've got something from him. From the Sheriff.\"" if=flag:msgTen&!flag:msgTenDone&!flag:valkoDead prio=4
@focus valko
> He goes very still. Hounds go still like the second before a dog jumps: all the movement held in.
valko: From him. He talks to you. In there.
valko: Say it.
@gate flag:msgTen=stop ? msg.tenV3 : msg.tenV0

# msg.tenV0
@gate flag:msgTen=man ? msg.tenV1 : msg.tenV2

# msg.tenV1
> You say it. *A good man. Not a good dog.*
> Valko makes a sound you've never heard a person make. Not a sob. Something lower. He turns away and walks to the edge of the platform and stands with his back to you for a long time.
valko: (not turning round) He never... sixty years. Sixty years and he says it to *you*.
valko: ...Thank you. Thank you for carrying it. It was heavy. I can tell. It's heavy.
{do flag:msgTenDone=1; rel:valko+3; flag:valkoHeard=1}
@end

# msg.tenV2
> You say it. *He was proud of you.*
valko: Proud. Of... of what? Of the finding? Of the killing? He never said what.
> He looks at you, desperate, like a dog that's heard its name and doesn't know if it's in trouble.
* "Of you. Not of anything you did. Of you."  -> msg.tenV4
* "I don't know. He didn't say."  -> msg.tenV5

# msg.tenV4
valko: ...Of me.
> He nods, very fast, several times, and doesn't say anything else.
{do flag:msgTenDone=1; rel:valko+2; flag:valkoHeard=1}
@end

# msg.tenV5
valko: He didn't say. No. He never said what. That's him. That's exactly him.
{do flag:msgTenDone=1; rel:valko+1}
@end

# msg.tenV3
> You say it. In his words. *Valko. You may stop now.*
> For a moment nothing happens. Then something goes out of Valko's shoulders that you didn't know was there: sixty years of being half a pace behind, with his nose up. He sits down. Right there, on the wet concrete, like his strings have been cut.
valko: Stop.
valko: I don't know how. I don't know how to stop. I've never... what do I do now?
* "Whatever you like."  -> msg.tenV6

# msg.tenV6
valko: Whatever I... nobody's ever...
> He sits there for a long time. Then, very slowly, he lies back on the concrete with his hands behind his head and looks at the ceiling of the Switchyard, the iron and the dripping brick, like it's a sky full of stars.
valko: This. I'd like this. For a minute.
{do flag:msgTenDone=1; rel:valko+3; flag:valkoStopped=1; xp:30:You May Stop}
tenant: (very quietly) Look at him. Look at him. I should have said it in 1966.
@end

# msg.soot arc=soot night=3,4,5 label="\"Anything for Séverine, Mother? I'm going up.\"" if=alive:sev prio=0
@focus soot
soot: For the Keeper. Hm. Yes. Tell her I know what the four notes are.
soot: She hums them when she's alone. Every night, for two hundred years, in her crypt, the same four notes. I've listened to them for nearly sixty. Last week I finally found them. In a hymnal in a box in the old Lyon archive the Moths put on the internet.
soot: Tell her. She'll want to know. She'll hate that I know. Both. That's the Keeper.
* "What are they?"  -> msg.soot1
* "I'll tell her you know. Not what they are."  -> msg.soot2

# msg.soot1
soot: The last four notes of a Kyrie. A little one. Written in 1790 for a village choir outside Lyon by a priest called Père Aubert. He was guillotined in the spring of '93.
soot: She hid him in her cellar. Everyone knows that story. Nobody knows he wrote her a tune. He did. Four notes of it are all that's left in her.
{do flag:msgSoot=know; mem:soot:aubert}
@end

# msg.soot2
soot: Clever. Let her keep the asking. Yes.
{do flag:msgSoot=hint}
@end

# msg.sootS arc=severine night=3,4,5 label="\"Mother Soot says she knows what the four notes are.\"" if=flag:msgSoot&!flag:msgSootDone&alive:sev prio=3
@focus severine
> The fan stops halfway open.
severine: Four...
severine: She's been listening to me in the crypt. Of course she has. The old rat. The old, dreadful, patient...
@gate flag:msgSoot=know ? msg.sootS1 : msg.sootS2

# msg.sootS1
* "A Kyrie. Père Aubert. 1790."  -> msg.sootS3
* Say nothing more. Let her ask.  -> msg.sootS2

# msg.sootS3
> She doesn't speak. She doesn't move. The crypt goes so quiet you can hear the music from the dancefloor three floors up, very faint, like a radio in another life.
severine: ...He wrote it in the kitchen. At my table. In Lyon. On the back of a bill from the candle-maker. He sang me the whole thing once, very badly, and burned the paper because it wasn't safe to keep.
severine: I've only ever had four notes. For two hundred and thirty years. Four.
severine: Does she... has she the rest? The whole thing?
* "I'll find out."  -> msg.sootS4

# msg.sootS4
severine: Find out. Yes. Please.
> You've never heard her say please. You don't think anyone has.
{do flag:msgSootDone=1; flag:kyrieQuest=1; rel:severine+2; mem:severine:kyrie}
@end

# msg.sootS2
severine: Tell her... no. Tell her nothing. I'll go down. One night. When this is over. I'll go down to the cistern myself and ask her, and she'll make me pay, and I'll pay.
{do flag:msgSootDone=1; flag:sevToSoot=1; rel:severine+1}
@end

# msg.kyr arc=soot night=3,4,5 label="\"Séverine wants the rest of the Kyrie, Mother.\"" if=flag:kyrieQuest&!flag:kyrieDone prio=4
@focus soot
soot: Of course she does. And she sent you instead of coming herself. Of course she did.
soot: I have it. All of it. Forty-one bars. I had a Moth child print it for me from the archive on a machine that smelled of hot plastic.
soot: The price is: she comes down. Once. Herself. Sits on my step. And says thank you to my face.
* "Done. I'll tell her."  -> msg.kyr1
? velvet 12 "Give it to me, Mother. Let me give it to her. You'll get your thank you. I'll make sure."  -> msg.kyr2 | msg.kyr1 {id msg_kyr}

# msg.kyr1
soot: Good. Tell her. Forty-one bars, for one thank you. That's the cheapest thing I've ever sold.
{do flag:kyrieDone=1; flag:sevToSoot=1; rel:soot+1}
@end

# msg.kyr2
soot: ...You. Hm. You'd keep it, too. That's the trouble. You keep things.
> She gives you a sheet of cheap printer paper, folded in four. Forty-one bars of a Kyrie in an old, careful hand, scanned and printed. At the bottom, in the original ink, faded: *pour S.*
{do flag:kyrieDone=1; flag:kyrieSheet=1; rel:soot+1}
@end

# msg.kyrS arc=severine night=3,4,5 label="Give Séverine the Kyrie." if=flag:kyrieSheet&!flag:kyrieGiven&alive:sev prio=5
@focus severine
> She unfolds the paper. Her gloved finger finds the bottom line. *pour S.*
> She reads the whole thing without moving her lips. Then she starts at the top again and hums it, very softly, behind the fan. It goes on for forty-one bars. On the thirty-eighth, the four notes come, the ones she's always known, and her voice cracks on them, and she keeps going.
severine: He wrote me a tune.
severine: Thank you. And tell the old rat... no. I'll tell her. I'll go down. Tomorrow. I'll sit on her step and tell her myself.
{do flag:kyrieGiven=1; flag:sevToSoot=1; rel:severine+3; xp:40:Pour S.; comp+1}
@end

# msg.leo arc=leo night=3,4,5 label="\"Do you want me to tell Junie anything? If I see her?\"" if=alive:leo&!flag:leoGoneTown prio=0
@focus leo
leo: Junie. If you see... where would you see Junie? She's on the coast. She works nights at Bayside General. She's never come into the Ward in her life, she says it smells like a bus station's armpit.
leo: ...Okay. If you see her. Tell her to tell Bea I'm sorry about the party. Tell Bea the hamster bit's retired, she was right, it was mean to the hamster.
leo: And tell her I'll be at the next one. Ten. I'll be there for ten. I'll bring the good cake. The one with the frosting that's basically just sugar and violence. Not frozen, this time.
* "I'll tell her."  -> msg.leo1
* "Don't make a promise you can't keep, Leo."  -> msg.leo2

# msg.leo1
{do flag:msgLeo=1; promise:pip10:Make sure Leo is at Bea's tenth birthday.}
leo: Thank you. Thank you. Don't say it weird. Say it like I'd say it.
@end

# msg.leo2
leo: Can't keep. Why couldn't I... oh. Oh. Because of you. Because of... the thing. Am I going to... is there going to be a next one, for me?
* "There'll be a next one. I'll make sure."  -> msg.leo1
* "I don't know, Leo."  -> msg.leo3

# msg.leo3
leo: You don't know.
leo: ...Okay. Then tell Junie I love her. And Bea. That one I can keep whatever happens. That one keeps itself.
{do flag:msgLeo=love; lean:candour+1}
@end

# msg.leoJ arc=junie night=5 label="\"Leo asked me to give you a message.\"" if=flag:msgLeo&!flag:msgLeoDone prio=3
@focus junie
@gate flag:msgLeo=love ? msg.leoJ2 : msg.leoJ1

# msg.leoJ1
junie: A message. From Leo. Through a vampire. Of course. Why would he use a phone like a normal person.
> You tell her. Bea. The party. The hamster bit, retired. The next one, ten. The cake with frosting that's basically sugar and violence. Not frozen.
junie: He said "sugar and violence"?
junie: That's his best line. That's his best line and he's wasting it on a cake.
> She thinks about it, very seriously, with her arms folded, the way nurses think about whether a patient's lying about how much they drink.
junie: Tell him okay. Tell him he has to bring two. One for Bea and one for me, because I always say I don't want any and then I eat hers. And tell him if he isn't there for ten, I'll come into this stinking Ward and find him myself, vampires or no vampires.
{do flag:msgLeoDone=1; flag:junieOkay=1; rel:junie+1}
@end

# msg.leoJ2
junie: A message. Is it a joke? He always sends jokes. He sent a joke from the ER when he broke his wrist.
> You tell her. *He loves you. And Bea.* No joke.
junie: ...That's not a joke.
junie: He never says that. He says "love you, Junebug" really fast like it's one word and then hangs up before I can say it back. Lovyoujunebug.
> She looks at you with Leo's exact face, the one he makes when a bit isn't landing and he's deciding whether to push through.
junie: Is he in danger? Don't lie. I'm a nurse. I know the face people make when they're about to tell me it's nothing.
* "He's in danger. He's with me. I'm looking after him."  -> msg.leoJ3
* "I don't know, Junie. I'm trying."  -> msg.leoJ4

# msg.leoJ3
junie: Looking after him. Okay. Then you do it properly. You promised now. You said it out loud to a nurse, that's legally binding.
{do flag:msgLeoDone=1; rel:junie+1; promise:junieleo:Keep Leo safe, for Junie.}
@end

# msg.leoJ4
junie: Trying's okay. Mom says trying's the main thing. Mom says a lot of things.
junie: Tell him lovyoujunebug. Back. Really fast. He'll know.
{do flag:msgLeoDone=1; rel:junie+1; lean:candour+1}
@end
`,'c_messages');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.msgRosDone&&f.msgRos==='exact')o.push(['The landing light, Rookery 404','Is never switched off. The electricity bill comes in at four dollars a month extra. Mrs. Okafor pays it in cash at the post office with a little smile, as if she\'s winning an argument.']);
  if(f.valkoStopped&&!f.valkoDead)o.push(['The Hound, stopped','Valko took a room above a bakery on Kerr Street in December. He sleeps the whole day through. At night, mostly, he walks, with nowhere to be, which he is still very bad at.']);
  else if(f.valkoFront&&!f.valkoDead)o.push(['The front seat of the Continental','Valko sits in it now, knees still up by his ears, window down an inch. Pemberton has been heard, once, to hum.']);
  if(f.kyrieGiven&&!f.sevDead)o.push(['A Kyrie for a village choir','Was sung, in the spring, in the crypt beneath Club Reliquary, for the first time in two hundred and thirty years. Forty-one bars. Mother Soot listened through the pipes and pretended she wasn\'t.']);
  if(f.junieOkay&&!f.leoDead)o.push(['Bea\'s tenth birthday','On the coast, in Bayside. Two cakes. Sugar and violence. Leo told the hamster bit one last time, by request, and the hamster, now very old, attended.']);
  return o;});
