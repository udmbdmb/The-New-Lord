'use strict';
/* THE NEW LORD — "88.1": Marek's pirate broadcasts, which tell the Ward what you did, in his own way */
(function(){NL.ITEMS.radio=NL.ITEMS.radio||{n:'A Transistor Radio',type:'tool',d:'Battery-powered, from the Lucky Mart, $12.99. Tuned permanently to 88.1, which doesn\'t officially exist.'};})();
NL.Script.add(String.raw`
# rd.0 arc=tenant night=4,5 label="Tune the radio to 88.1." if=flag:djDone=guarded&!flag:marekDead|seen:dj.warn&!flag:marekDead prio=0
@focus tenant
> Static. Then a voice through a cheap microphone, very close, a little breathless, with an accent from somewhere east of anywhere.
marek: ...88.1, the station that does not exist, for the people who do not exist. Good evening, Marrow Ward. It is Marek. It is raining. It is always raining. Here is the news.
@gate night:5 ? rd.n5 : rd.n4

# rd.n4
marek: Item. The Lucky Mart on Ferrier Lane has been visited by Officer Dale and Officer Pruitt for the last time, according to sources. The sources are Tariq. Tariq says thank you to "the night customer". I don't know who that is. Thank you, night customer. {if flag:racketDone}
marek: Item. A Wraith on Halloran Street reports that the streetlight outside number 40 has been out since Wednesday. He would like to thank whoever did it. He says he can see the stars. This is the best news I have had all week. {if flag:tobiasDark}
marek: Item. The Vellum footbridge. A young man called Ollie asks me to say on the air that he is okay. He is okay. Hello, Ollie. {if flag:ollieSafe}
marek: Item. The website NIGHTWATCH has gone dark. Its users are very upset. I am not upset. I am eating a celebratory noodle. {if flag:forumDown}
marek: Item. There are grey vans on Ferrier Lane. There are men in grey overalls in the tunnels. There are lamps in the grates under Platform 0. I say this every night. Every night I hope someone is listening.
marek: And now, a song. It is the only song I have. It is a Romanian song about a goat.
tenant: ...A goat. Ambrose would weep.
@end

# rd.n5
marek: Friday. Last broadcast, maybe. Who knows. If the men in grey find my van, this is it.
marek: Item. A woman on the coast called the station at three this morning. She said: tell Casey the porch light is on. I don't know Casey. Casey, the porch light is on. {if flag:sisterSaturday}
marek: Item. Halloran Street is empty tonight. A man in a parka has been knocking on every door saying there is a gas leak. People believe him. I believe him. There is maybe not a gas leak. {if flag:job_leo=street|flag:job_tariq=street|flag:job_miller=street|flag:job_okafor=street}
marek: Item. The Lucky Mart is open. All night. Every light on. Tariq says come in if you are scared. Tariq says the coffee is terrible. Tariq says it is free. {if flag:job_tariq=shop}
marek: Item. The fight on Thursday at the Reliquary cellar was "a disappointment" for the gamblers. A nineteen-year-old won. Or nobody won. The reports are confused. A doorman sends his regards. {if flag:fightDone}
marek: Item. The Ward will hold a Tribunal tonight at one o'clock, under the railway, in a place I am not allowed to say. Somebody is on trial for the death of the Sheriff. I have heard that this somebody says please to shopkeepers.
marek: Whoever you are. Whatever you are. Good luck. The station that does not exist is with you.
{do comp+1}
@end
`,'c_radio');
