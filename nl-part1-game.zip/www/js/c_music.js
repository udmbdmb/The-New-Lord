'use strict';
/* THE NEW LORD — the score, part two: a fuller generative soundtrack (bass, arpeggios, brushes, motifs),
   a mood for every part of the Ward, and a slot for real recorded tracks (NL.MUSIC_FILES[mood] = 'music/x.mp3'). */
(function(){const A=NL.Audio;if(!A)return;
const NOTE=n=>440*Math.pow(2,(n-69)/12);
NL.MUSIC_FILES=NL.MUSIC_FILES||{};
// chords are MIDI note sets; bass = offsets from the chord root, per eighth (null = rest); arp = chord-tone indices per eighth
const MOODS={
  title:{bpm:56,chords:[[50,57,62,65],[46,53,58,62],[43,50,55,58],[45,52,57,61]],bars:2,pad:'saw',lp:900,arp:[0,2,3,2,1,2,3,4],arpV:'bell',arpG:.022,bass:[0,null,null,null,0,null,7,null],motif:[74,72,69,70,69,65,67,null]},
  night:{bpm:60,chords:[[38,45,50,53],[41,48,53,57],[36,43,48,52],[40,47,50,55]],bars:2,pad:'tri',lp:700,arp:[0,null,2,null,3,null,2,null],arpV:'bell',arpG:.016,bass:[0,null,null,null,null,null,null,null],perc:'rain'},
  street:{bpm:72,chords:[[38,45,48,53],[43,50,53,57],[36,43,46,50],[40,46,50,53]],bars:2,pad:'tri',lp:650,bass:[0,null,3,null,5,null,7,6],bassV:'pluck',perc:'brush',arp:[null,3,null,null,null,2,null,null],arpV:'piano',arpG:.02},
  tense:{bpm:84,chords:[[37,44,49,52],[38,45,50,53],[36,43,48,51],[37,44,49,52]],bars:1,pad:'saw',lp:600,pulse:true,bass:[0,0,0,0,0,0,0,0],bassV:'sub',perc:'tick',arp:[3,null,3,null,2,null,1,null],arpV:'bell',arpG:.012},
  dread:{bpm:50,chords:[[36,43,46,51],[35,42,47,50],[36,43,48,51],[34,41,46,49]],bars:2,pad:'tri',lp:500,pulse:true,bass:[0,null,null,null,null,null,null,null],bassV:'sub',perc:'heart'},
  mirror:{bpm:60,chords:[[45,52,57,60,64],[41,48,53,57,60],[43,50,55,59,62],[40,47,52,56,59]],bars:2,pad:'tri',lp:1400,arp:[0,1,2,3,4,3,2,1],arpV:'bell',arpG:.02},
  club:{bpm:118,chords:[[45,52,57,60],[43,50,55,59],[41,48,53,57],[40,47,52,55]],bars:1,pad:'saw',lp:1300,bass:[0,null,0,12,0,null,0,12],bassV:'synth',perc:'four',arp:[2,3,4,3,2,3,4,3],arpV:'pluck',arpG:.012},
  jazz:{bpm:92,chords:[[50,53,57,60,64],[43,47,50,53,57],[48,52,55,59,62],[45,49,52,55,59]],bars:1,pad:'rhodes',lp:1800,bass:[0,null,4,null,7,null,9,null],bassV:'pluck',perc:'brush',motif:[74,null,76,77,null,74,72,null,71,null,72,74,null,null,null,null],motifV:'piano'},
  court:{bpm:76,chords:[[45,52,57,60],[40,47,52,56],[41,48,53,57],[38,45,50,53],[40,47,52,56],[45,52,57,60]],bars:1,pad:'organ',lp:2000,arp:[0,2,1,3,2,4,3,2],arpV:'harpsi',arpG:.018,bass:[0,null,null,null,-5,null,null,null],bassV:'pluck'},
  clock:{bpm:60,chords:[[43,50,55,58],[39,46,51,55],[41,48,53,56],[38,45,50,54]],bars:2,pad:'tri',lp:900,perc:'tick',arp:[null,null,3,null,null,null,2,null],arpV:'music-box',arpG:.02},
  clinic:{bpm:66,chords:[[44,51,56,59],[43,50,55,58],[40,47,52,55],[42,49,54,57]],bars:2,pad:'sine',lp:2400,perc:'monitor',arp:[3,null,null,null,null,null,null,null],arpV:'bell',arpG:.012},
  home:{bpm:64,chords:[[48,55,60,64],[45,52,57,60],[41,48,53,57],[43,50,55,59]],bars:2,pad:'rhodes',lp:1500,bass:[0,null,null,null,7,null,null,null],bassV:'pluck',arp:[0,2,1,3,null,2,null,null],arpV:'piano',arpG:.02,motif:[72,null,71,69,null,67,null,null,69,null,71,72,null,null,null,null],motifV:'piano'},
  syndicate:{bpm:96,chords:[[33,40,45,48],[33,40,44,48],[31,38,43,46],[32,39,44,47]],bars:1,pad:'saw',lp:420,bass:[0,0,null,0,null,0,1,null],bassV:'synth',perc:'metal',arp:null},
  cistern:{bpm:48,chords:[[40,47,52,55,59],[38,45,50,53,57],[36,43,48,52,55],[38,45,50,54,57]],bars:2,pad:'choir',lp:1100,perc:'drip',arp:[4,null,null,null,null,null,null,null],arpV:'bell',arpG:.014},
  church:{bpm:52,chords:[[43,50,55,59,62],[40,47,52,55,59],[45,52,57,60,64],[38,45,50,54,57]],bars:2,pad:'organ',lp:2600,bass:[0,null,null,null,null,null,null,null],bassV:'organ-low',motif:[67,null,null,null,69,null,71,null,72,null,null,null,71,null,69,null],motifV:'choir'},
  grief:{bpm:54,chords:[[45,52,57,60],[41,48,53,57],[38,45,50,53],[40,47,52,56]],bars:2,pad:'tri',lp:900,arp:[0,null,2,null,3,null,4,null],arpV:'piano',arpG:.018,motif:[76,null,null,74,72,null,null,null,69,null,71,null,72,null,null,null],motifV:'piano'},
  tender:{bpm:58,chords:[[48,55,60,64,67],[44,51,56,60,63],[46,53,58,62,65],[43,50,55,59,62]],bars:2,pad:'rhodes',lp:1700,arp:[0,1,2,3,4,3,2,1],arpV:'piano',arpG:.016},
  chase:{bpm:138,chords:[[38,45,50,53],[38,45,50,53],[41,48,53,56],[36,43,48,51]],bars:1,pad:'saw',lp:900,bass:[0,0,12,0,0,12,0,10],bassV:'synth',perc:'drive',arp:[3,2,3,1,3,2,3,0],arpV:'pluck',arpG:.012},
  tribunal:{bpm:64,chords:[[38,45,50,53],[37,44,49,53],[34,41,46,50],[36,43,48,52]],bars:2,pad:'choir',lp:1300,bass:[0,null,null,null,0,null,null,null],bassV:'sub',perc:'taiko',motif:[62,null,null,null,61,null,null,null,58,null,60,null,62,null,null,null],motifV:'choir'},
  dawn:{bpm:60,chords:[[50,57,62,66,69],[47,54,59,62,66],[43,50,55,59,62],[45,52,57,61,64]],bars:2,pad:'tri',lp:1600,arp:[0,1,2,3,4,3,2,1],arpV:'bell',arpG:.02},
  end:{bpm:56,chords:[[50,57,62,65,69],[46,53,58,62,65],[48,55,60,64,67],[45,52,57,61,64]],bars:2,pad:'saw',lp:1100,arp:[0,2,4,2,1,3,4,3],arpV:'bell',arpG:.018,motif:[74,null,77,null,81,null,null,null,79,null,77,null,74,null,null,null]}
};
NL.MOODS=MOODS;
// where you are decides what "night" sounds like
const ROOMMOOD={alley:'street',luckymart:'street',reliquary:'club',vip:'court',pawn:'clock',stjude:'clinic',morgue:'clinic',sjroof:'night',apt:'home',rookery:'home',shrine:'cistern',cistern:'cistern',switchyard:'syndicate'};
NL.ROOMMOOD=ROOMMOOD;
let st=null;
const ctx=()=>A.ctx,t0=()=>A.ctx.currentTime;
function env(g,t,a,peak,d){g.gain.setValueAtTime(0.0001,t);g.gain.exponentialRampToValueAtTime(peak,t+a);g.gain.exponentialRampToValueAtTime(0.0001,t+d);}
function tone(type,f,peak,t,d,dest,o){o=o||{};const c=ctx(),os=c.createOscillator(),g=c.createGain();os.type=type;os.frequency.setValueAtTime(f,t);if(o.det)os.detune.value=o.det;let n=os;
  if(o.lp){const fl=c.createBiquadFilter();fl.type='lowpass';fl.frequency.value=o.lp;fl.Q.value=o.q||.7;os.connect(fl);n=fl;}n.connect(g);env(g,t,o.a||.006,peak,d);g.connect(dest);os.start(t);os.stop(t+d+.05);}
function noise(peak,t,d,dest,o){o=o||{};const c=ctx(),s=c.createBufferSource();s.buffer=A.noise;const f=c.createBiquadFilter();f.type=o.type||'highpass';f.frequency.value=o.f||6000;f.Q.value=o.q||.7;const g=c.createGain();env(g,t,o.a||.002,peak,d);s.connect(f);f.connect(g);g.connect(dest);s.start(t,Math.random()*2);s.stop(t+d+.05);}
function voice(v,n,t,peak,dur,dest){const f=NOTE(n);
  switch(v){
    case 'bell':tone('sine',f,peak,t,dur||2.4,dest);tone('triangle',f*2,peak*.3,t,(dur||2.4)*.6,dest);break;
    case 'piano':tone('triangle',f,peak,t,dur||1.8,dest,{lp:2600});tone('sine',f*2,peak*.25,t,.6,dest);tone('sine',f*3,peak*.08,t,.3,dest);break;
    case 'harpsi':tone('sawtooth',f,peak*.7,t,.55,dest,{lp:3200,q:2});tone('square',f*2,peak*.15,t,.25,dest,{lp:4000});break;
    case 'pluck':tone('sawtooth',f,peak,t,.35,dest,{lp:1400,q:3});break;
    case 'music-box':tone('sine',f*2,peak,t,1.6,dest);tone('sine',f*4,peak*.2,t,.5,dest);break;
    case 'choir':for(const d of [-7,0,7])tone('sawtooth',f,peak*.35,t,dur||2.2,dest,{lp:900,a:.35,det:d});break;
    default:tone('triangle',f,peak,t,dur||1.5,dest);}
}
function bassVoice(v,n,t,dest,step){const f=NOTE(n);
  switch(v){case 'sub':tone('sine',f,.09,t,step*1.8,dest);break;case 'synth':tone('sawtooth',f,.045,t,step*.9,dest,{lp:420,q:4});tone('sine',f,.05,t,step*.9,dest);break;
    case 'organ-low':tone('sine',f,.05,t,step*7.5,dest,{a:.4});tone('sine',f*2,.02,t,step*7.5,dest,{a:.4});break;
    default:tone('triangle',f,.07,t,step*1.4,dest,{lp:700});tone('sine',f,.05,t,step*1.4,dest);}
}
function padChord(M,ch,t,dur,dest){const c=ctx(),g=c.createGain();g.gain.setValueAtTime(0.0001,t);g.gain.exponentialRampToValueAtTime(M.pad==='organ'?.028:.04,t+Math.min(2.2,dur*.3));g.gain.setTargetAtTime(0.0001,t+dur-.6,.9);
  const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=M.lp;f.Q.value=.7;g.connect(f);f.connect(dest);
  const type={saw:'sawtooth',tri:'triangle',sine:'sine',organ:'sine',rhodes:'sine',choir:'sawtooth'}[M.pad]||'triangle';
  ch.forEach((n,i)=>{const dets=M.pad==='organ'?[0]:[-6,6];dets.forEach(d=>{const o=c.createOscillator();o.type=type;o.frequency.value=NOTE(n);o.detune.value=d+i*3;o.connect(g);o.start(t);o.stop(t+dur+2.5);});
    if(M.pad==='organ'){const o2=c.createOscillator();o2.type='sine';o2.frequency.value=NOTE(n+12);const g2=c.createGain();g2.gain.value=.4;o2.connect(g2);g2.connect(g);o2.start(t);o2.stop(t+dur+2.5);}
    if(M.pad==='rhodes'){const o3=c.createOscillator(),g3=c.createGain();o3.type='sine';o3.frequency.value=NOTE(n+12);g3.gain.setValueAtTime(.5,t);g3.gain.exponentialRampToValueAtTime(.01,t+1.2);o3.connect(g3);g3.connect(g);o3.start(t);o3.stop(t+dur+2.5);}});
  if(M.pulse){const l=c.createOscillator(),lg=c.createGain();l.frequency.value=1.6;lg.gain.value=.02;l.connect(lg);lg.connect(g.gain);l.start(t);l.stop(t+dur+2.5);}
}
function perc(kind,i,t,step,dest){
  switch(kind){
    case 'brush':if(i%2===1)noise(.03,t,.09,dest,{f:5000});if(i%4===2)noise(.05,t,.18,dest,{f:2500,type:'bandpass',q:.6});break;
    case 'tick':if(i%2===0)tone('square',2600,.012,t,.02,dest,{lp:5000});break;
    case 'four':if(i%2===0)tone('sine',110,.18,t,.18,dest);if(i%2===1)noise(.025,t,.05,dest,{f:8000});if(i%4===2)noise(.05,t,.15,dest,{f:1800,type:'bandpass',q:.8});break;
    case 'drive':tone('sine',90,i%2===0?.16:.05,t,.12,dest);noise(.02,t,.04,dest,{f:9000});break;
    case 'heart':if(i===0||i===1)tone('sine',58,.22,t+(i?.05:0),.2,dest);break;
    case 'monitor':if(i===0)tone('sine',1320,.018,t,.12,dest);break;
    case 'metal':if(i===0||i===3||i===6)noise(.06,t,.12,dest,{f:3200,type:'bandpass',q:6});if(i===4)tone('sine',70,.2,t,.25,dest);break;
    case 'drip':if(Math.random()<.18){const f=900+Math.random()*900;tone('sine',f,.03,t,.15,dest);tone('sine',f*1.5,.012,t+.02,.1,dest);}break;
    case 'rain':if(Math.random()<.2)noise(.012,t,.05,dest,{f:7000});break;
    case 'taiko':if(i===0)tone('sine',55,.3,t,.6,dest);if(i===6&&Math.random()<.5)tone('sine',62,.14,t,.4,dest);break;}
}
function stopSynth(){if(!st)return;clearInterval(st.iv);st.gain.gain.setTargetAtTime(0.0001,t0(),1.2);const g=st.gain;setTimeout(()=>{try{g.disconnect();}catch(e){}},6000);st=null;}
function startSynth(mood){const M=MOODS[mood];if(!M)return;const c=ctx(),gain=c.createGain();gain.gain.setValueAtTime(0.0001,t0());gain.gain.exponentialRampToValueAtTime(1,t0()+2.5);gain.connect(A.mus);
  const step=60/M.bpm/2,barLen=step*8;let next=t0()+.1,i=0,ci=0,mi=0;
  const s={gain,iv:null};
  const tick=()=>{while(next<t0()+.6){const pos=i%8;
      if(pos===0&&(Math.floor(i/8)%M.bars)===0){const ch=M.chords[ci++%M.chords.length];s.ch=ch;padChord(M,ch,next,barLen*M.bars,gain);}
      const ch=s.ch||M.chords[0];
      if(M.bass){const b=M.bass[pos];if(b!=null)bassVoice(M.bassV,ch[0]-12+b,next,gain,step);}
      if(M.arp){const a=M.arp[pos];if(a!=null)voice(M.arpV,ch[a%ch.length]+12,next,M.arpG||.016,null,gain);}
      if(M.perc)perc(M.perc,pos,next,step,gain);
      if(M.motif&&(Math.floor(i/(M.motif.length))%3===1)){const n=M.motif[mi%M.motif.length];if(n!=null)voice(M.motifV||'bell',n,next,.03,step*3,gain);mi++;}
      i++;next+=step;}};
  tick();s.iv=setInterval(tick,150);st=s;}
/* recorded tracks: two players per track that crossfade at the loop point, and each track remembers where it was */
const decks={};let deck=null;const XF=5;
function mkDeck(url){const c=ctx();const d={url,els:[],gains:[],cur:0,pos:0,iv:null};
  for(let k=0;k<2;k++){const el=new Audio();el.src=url;el.preload=k?'none':'auto';if(/^https?:/.test(location.protocol))el.crossOrigin='anonymous';let g;if(/^https?:/.test(location.protocol)){g=c.createGain();g.gain.value=0.0001;try{c.createMediaElementSource(el).connect(g);}catch(e){}g.connect(A.mus);}
    else{/* opened from a file: Web Audio can't read the track, so fade the element's own volume */el.volume=0;let iv=null;const vol=()=>((A.vol&&A.vol.music!=null?A.vol.music:.6)*(A.vol&&A.vol.master!=null?A.vol.master:.8));
      g={gain:{value:0.0001,cancelScheduledValues(){},setValueAtTime(v){this.value=v;},exponentialRampToValueAtTime(to,t){const from=this.value,dur=Math.max(.05,t-t0()),st=performance.now();clearInterval(iv);const self=this;
        iv=setInterval(()=>{const k=Math.min(1,(performance.now()-st)/(dur*1000));self.value=from+(to-from)*k;el.volume=Math.max(0,Math.min(1,self.value*vol()));if(k>=1)clearInterval(iv);},50);}}};}
    d.els.push(el);d.gains.push(g);}
  return d;}
function fade(g,to,sec){try{g.gain.cancelScheduledValues(t0());g.gain.setValueAtTime(Math.max(0.0001,g.gain.value),t0());g.gain.exponentialRampToValueAtTime(Math.max(0.0001,to),t0()+sec);}catch(e){}}
function stopFile(){if(!deck)return;const d=deck;deck=null;clearInterval(d.iv);const el=d.els[d.cur];d.pos=el.currentTime||0;d.els.forEach((e,k)=>fade(d.gains[k],0.0001,2.2));
  setTimeout(()=>{if(deck!==d)d.els.forEach(e=>{try{e.pause();}catch(_){}});},2600);}
function startFile(url){const d=decks[url]||(decks[url]=mkDeck(url));deck=d;const el=d.els[d.cur];
  if(el.duration&&d.pos>el.duration-XF-2)d.pos=0;try{el.currentTime=d.pos||0;}catch(e){}
  el.play().catch(()=>{});fade(d.gains[d.cur],.9,2.5);clearInterval(d.iv);
  d.iv=setInterval(()=>{if(deck!==d)return;const a=d.els[d.cur];if(!a.duration||a.paused)return;
    if(a.currentTime>=a.duration-XF){const n=1-d.cur,b=d.els[n];b.preload='auto';try{b.currentTime=0;}catch(e){}b.play().catch(()=>{});fade(d.gains[n],.9,XF*0.8);fade(d.gains[d.cur],0.0001,XF);
      const old=a;setTimeout(()=>{if(d.els[d.cur]!==old)old.pause();},XF*1000+300);d.cur=n;}},250);}
NL.MUSIC_FILES=Object.assign({},(()=>{const o={};['title','night','street','tense','dread','mirror','club','jazz','court','clock','clinic','home','syndicate','cistern','church','grief','tender','chase','dawn','end'].forEach(m=>o[m]='music/'+m+'.mp3');o.tribunal='music/tribunal.mp3';return o;})(),NL.MUSIC_FILES);
NL.musicDebug=()=>deck?{url:deck.url,t:deck.els[deck.cur].currentTime,paused:deck.els[deck.cur].paused,dur:deck.els[deck.cur].duration}:null;
const orig=A.music;
A.music=function(mood){if(!A.ctx)return;
  if(mood==='night'&&NL.G&&NL.G.S&&ROOMMOOD[NL.G.S.room])mood=ROOMMOOD[NL.G.S.room];
  if(A.curMood===mood)return;A.curMood=mood;
  clearInterval(A._mi);clearInterval(A._pi);(A.musicNodes||[]).forEach(n=>{try{n.g.gain.setTargetAtTime(0,t0(),1.2);}catch(e){}});A.musicNodes=[];
  stopSynth();stopFile();if(!mood)return;
  if(NL.MUSIC_FILES[mood]){startFile(NL.MUSIC_FILES[mood]);return;}
  if(MOODS[mood])startSynth(mood);else orig.call(A,mood);};
// rooms switch the mood on entry, unless a scene has set something stronger
if(NL.Act&&NL.Act.pushEnter){Object.keys(ROOMMOOD).forEach(r=>NL.Act.pushEnter(r,async()=>{const m=A.curMood;if(!m||m==='night'||Object.values(ROOMMOOD).includes(m))A.music('night');}));}
})();
// give the big confrontations their own cues
(function(){const E=NL.DSL&&NL.DSL.ENC;if(!E)return;if(E.tribunal)E.tribunal.music='tribunal';if(E.hound)E.hound.music='chase';if(E.butcher)E.butcher.music='syndicate';if(E.keeper)E.keeper.music='court';})();
// dialogue-only places get their own music while you're there
(function(){const Camp=NL.Camp,A=NL.Audio;if(!Camp)return;
const PM={lantern:'jazz',choir:'church',chapel:'church',belltower:'church',ashrite:'church',dinner:'home',six_c:'home',doors:'home',mbeki:'home',observatory:'tender',grave:'grief',shelterroof:'tender',the9:'street',bus9:'street',velvet:'club',masque:'court',freddie:'court',roux:'court',study:'clock',pf:'tribunal',servicetunnel:'tense',tattoo:'street',laundry:'street',grand:'jazz',anchor:'jazz',lund:'jazz'};
const orig=Camp.travel;Camp.travel=async function(id){const m=PM[id];if(m&&A.ctx)A.music(m);try{return await orig.apply(this,arguments);}finally{if(m&&A.curMood===m)A.music('night');}};})();
