'use strict';
/* THE NEW LORD — what they say about each other: ask anyone about anyone, and decide whether to take their side */
NL.Script.add(String.raw`
# op.leoMil arc=leo night=2,3,4,5 label="Ask Leo what he makes of Detective Miller." if=met:miller&alive:leo prio=-3
@focus leo
leo: Miller? She scares me. In a good way. In a "this woman would find my body" way.
leo: She came into the shop in September looking for a guy called Luis. Bought a pork chop she didn't want, so it wouldn't look like she was only asking questions. Then she forgot it on the counter. I put it in the fridge for her. She never came back for it. It's probably still there.
leo: She's the only person in this whole city who looks at the Marrow Ward like it matters. Everyone else looks at it like a place you drive through with the windows up.
* "She's going to get herself killed."  -> op.leoMil1
* "She's the best person I've met since I died."  -> op.leoMil2

# op.leoMil1
leo: Yeah. Yeah, probably. Unless somebody stops her. Unless somebody stands next to her. Hint. Hint hint hint.
@end

# op.leoMil2
leo: Since you died. That's a weird way to rank people. That's a great way to rank people. I'm going to start doing that. "Best sandwich since I died."
leo: ...Am I on the list? Don't answer that. Answer it later.
{do rel:leo+1}
@end

# op.leoSev arc=leo night=3,4,5 label="Ask Leo what he thinks of Séverine." if=met:severine&alive:leo&alive:sev prio=-3
@focus leo
leo: The lady in the crypt? With the fan? Okay, so, I have a theory. My theory is she's never once in her whole life been told a knock-knock joke.
leo: Like, ever. Two hundred years. Nobody's ever gone "knock knock" and she's gone "who's there". You can tell. She's got a no-knock-knock face.
* "Go and tell her one."  -> op.leoSev1
* "Leo, if you tell her a knock-knock joke she'll have you drained."  -> op.leoSev2

# op.leoSev1
leo: Me? Tell... no. No no no. What would I even... okay, I've got one. I've got a good one. It's about an interrupting cow. No. I'm not doing it. I'm thinking about doing it.
{do flag:leoKnockKnock=1}
@end

# op.leoSev2
leo: Drained. Over a knock-knock joke. See, that's the thing, that's exactly why somebody needs to.
@end

# op.leoPem arc=leo night=2,3,4,5 label="Ask Leo what he makes of Pemberton." if=met:pemberton&alive:leo&alive:pem prio=-3
@focus leo
leo: Pemberton is the most terrifying man I have ever met and he once offered me a mint.
leo: He's so *polite*. It's like being threatened by a butler in a movie. Except he's not threatening anyone. I think. I think he's just like that. I think he was born holding a door.
leo: He asked me if I wanted the heating on in the car. Nobody asks me if I want the heating on. I cried a little bit. Don't tell him.
* "He'd like you, if you let him."  -> op.leoPem1
* "He's been someone's servant for forty years. That's what polite looks like after forty years."  -> op.leoPem2

# op.leoPem1
leo: Like me. Pemberton. Ha. Okay. I'm going to say thank you next time. Really loudly. He'll hate it.
@end

# op.leoPem2
leo: ...Oh. Oh, that's sad. That's really sad. I didn't think about it like that.
leo: I'm going to ask him what he likes. Like, as a person. Nobody probably asks him that.
{do flag:leoAsksPem=1}
@end

# op.milRos arc=miller night=3,4,5 label="Ask Miller what she thinks of Dr. Rostova." if=met:rostova&alive:miller&alive:rostova prio=-3
@focus miller
miller: Rostova. Hm. I've met a hundred doctors on this job. Ninety of them are tired and nine of them are cruel and one of them is Rostova.
miller: She's the only doctor in the Ninth who's ever rung me back. She rang me back at four in the morning to tell me a John Doe in the morgue had a tattoo that matched a missing person. She was right. She's always right. She's the most frightening kind of person: a good doctor with a grudge.
* "She's hiding something, Ines."  -> op.milRos1
* "She's trying to save people. She just went about it wrong."  -> op.milRos2

# op.milRos1
miller: Everyone's hiding something. She's hiding something big. She's got that look. Like a woman sitting on a suitcase to keep it shut.
miller: I'll keep an eye on her. Thanks.
{do flag:millerWatchesRos=1}
@end

# op.milRos2
miller: Went about it wrong. That's what they say about every one of them, afterwards. "She meant well."
miller: The seven people on her list didn't get "meant well". They got a missing persons report.
{do rel:miller-1}
@end

# op.milHar arc=miller night=3,4,5 label="Ask Miller about Agent Harrow." if=met:harrow&alive:miller&!flag:harrowDead prio=-3
@focus miller
miller: Harrow. Department of Health. Sure. Sure he is. And I'm a ballerina.
miller: He came into the precinct in August with a federal letter and a peppermint, and the next week the Captain signed seven of my files out of the cage and never signed them back in. He offered me a peppermint while he told me it was routine. That's how I knew he was the worst person I'd ever met.
miller: Nobody who's comfortable doing what they're doing offers you a peppermint. He knows. Somewhere in there, he knows.
* "He has a daughter. He's not a monster."  -> op.milHar1 {if flag:harrowDaughter}
* "He's afraid. That's why the peppermints."  -> op.milHar2

# op.milHar1
miller: A daughter. Of course he does. They've all got daughters.
miller: ...That's not fair. Sorry. That's not fair. Okay. He's got a daughter. He's still taking my files.
{do rel:miller+1}
@end

# op.milHar2
miller: Afraid. Yeah. Afraid of what, though? That's the question. Afraid of you lot, or afraid of what he's doing to you lot? Because those are very different men.
@end

# op.sevMil arc=severine night=3,4,5 label="\"What do you think of the detective, my lady?\"" if=met:miller&alive:sev prio=-3
@focus severine
severine: The mortal in the hat. Yes. She's been knocking on doors in the Ward for two months, darling. Every Kindred below Reliquary Row knows her walk.
severine: I find her tiresome. I also find her the only mortal in this city I've ever been afraid of. She's honest, you see. You can't bargain with an honest woman. You can only kill her or wait for her to retire.
* "Don't kill her."  -> op.sevMil1
* "She'll never retire."  -> op.sevMil2

# op.sevMil1
severine: Kill her. Darling, I've never killed anyone in my life who wasn't trying to kill me first. I have people for that, and they're very discreet.
severine: ...No. I won't. You've asked me. Write it down. The Keeper was asked not to and didn't.
{do rel:severine+1; flag:sevSparesMiller=1}
@end

# op.sevMil2
severine: No. She won't. That's what I find so exhausting about her. She'll be knocking on doors at ninety with a cane.
@end

# op.sevSoot arc=severine night=3,4,5 label="\"What do you make of Mother Soot?\"" if=met:soot&alive:sev&alive:soot prio=-3
@focus severine
severine: That old rat. She's been listening to my crypt through the drains since 1966. I had the plumbing replaced in 1981. She was listening again by Christmas.
severine: Do you know, I've never once seen her face? Not in fifty-eight years. I've sent her gifts. She's sent them back. Unopened. With a note. *Not yet.* That's all. *Not yet.*
* "Go and see her. Yourself."  -> op.sevSoot1
* "Maybe that's her way of keeping you."  -> op.sevSoot2

# op.sevSoot1
severine: Go down. Into the sewer. In these shoes.
severine: ...One day. Perhaps. When I'm sure she won't laugh.
{do flag:sevToSoot=1}
@end

# op.sevSoot2
severine: Keeping me. Like a jar on a shelf. Hm. That's a nasty thought. It's also a very Wraith one. You've been listening to her.
@end

# op.sevPem arc=severine night=3,4,5 label="\"You've known Pemberton forty years, haven't you?\"" if=met:pemberton&alive:sev&alive:pem prio=-3
@focus severine
severine: Forty-one. He was twenty-three. A merchant seaman with a broken nose and an accent from somewhere with a lot of rain, and Absalom found him on the docks in a fight he was losing with four men, and won it for him.
severine: He's driven past my window every night since. He has never once looked up. I've always admired that. A man who can drive past the Keeper of Elysium for forty years without looking up is either a saint or a ghoul. He's both.
* "He'd look up if you waved."  -> op.sevPem1
* "Why do you care whether he looks up?"  -> op.sevPem2

# op.sevPem1
severine: Wave. At a chauffeur. From a crypt with no windows, darling, I'd have to go upstairs. Into the club. With the mortals.
severine: ...How very odd. I'd never thought of it.
@end

# op.sevPem2
> The fan stops.
severine: I don't. Be quiet. Go and do something useful.
{do mem:severine:pemwindow}
@end

# op.malSev arc=malakor night=3,4,5 label="\"What do you really think of Séverine?\"" if=met:severine&!flag:malakorDead&alive:sev prio=-3
@focus malakor
malakor: Really. I think she's the bravest coward in the Ward.
malakor: You know how she got the Keeper job? 1966. The Elysium burned. Not the crypt, the old one, the opera house on Vine. Forty Kindred inside. She went back in three times with her dress on fire and brought out eleven. Including Absalom, who'd gone in for his hat.
malakor: Then she walked out, put on a new dress, and has been terrified of everything ever since. Of fire. Of being seen to care. Of the Prince coming back. Of you.
* "I didn't know that."  -> op.malSev1
* "Why are you telling me this?"  -> op.malSev2

# op.malSev1
malakor: Nobody does. The ones who were there don't say. Absalom never said. Most of them are ash now anyway.
{do mem:malakor:sevfire}
@end

# op.malSev2
malakor: Because you're going to stand in the chalk with her on Friday, and you should know who you're standing with. She's not your friend. But she's braver than she lets you see. That's worth knowing about an enemy.
{do mem:malakor:sevfire; rel:malakor+1}
@end

# op.malRos arc=malakor night=3,4,5 label="\"What did you think of the doctor? When she came for the lance?\"" if=fact:malakor:buyer&!flag:malakorDead&alive:rostova prio=-3
@focus malakor
malakor: The masked one. Hm. Steady hands. That's what I noticed. I've had Kindred in this shop who shake when they pick up a lance. She picked it up like a scalpel. Checked the battery. Asked about the focal length.
malakor: Then she said thank you. In Russian. Under her breath. I don't think she knew she'd said it out loud.
malakor: A woman who says thank you in her mother's language to a Butcher who sold her a murder weapon. That's someone who's been alone with something for a long time.
* "She lost her father to one of us."  -> op.malRos1 {if mem:rostova.papa|flag:pyotrDone|seen:pyR.0}
* "That's no excuse."  -> op.malRos2

# op.malRos1
malakor: Her father. Ah. Of course. Of course it's that. It's always a father or a sister or a child.
malakor: I'd have charged her less, if I'd known. I'm sentimental. Don't tell anyone.
{do rel:malakor+1}
@end

# op.malRos2
malakor: No. It isn't. Nothing's an excuse. But everything's a reason. You'll learn the difference, nephew, if you live long enough.
@end

# op.sootGid arc=soot night=2,3,4,5 label="\"What do you think of Gideon?\"" if=met:gideon&alive:soot prio=-3
@focus soot
soot: Gideon. Gideon, Gideon. The only mortal in the Ward I've never sold. Nobody's ever bought him. They've tried.
soot: Every Thursday for fifty years he's left a quart of milk in a glass bottle at the top of my steps. Whole milk. The good kind. He doesn't know what I'd do with it. Neither do I. I pour it in the cistern. The rats are very healthy.
soot: When he dies, I'll know before his son does. I'll hear his heart stop through the pipes under the Pawn & Coffin. And I'll go up. For the first time in forty years, I'll go up the steps. For him.
{do mem:soot:gideonmilk; comp+1}
@end

# op.sootMal arc=soot night=2,3,4,5 label="\"What do you hear about Malakor?\"" if=met:malakor&alive:soot&!flag:malakorDead prio=-3
@focus soot
soot: Malakor sings in the shower. In Polish. Very badly. The same song every night: a lullaby about a goose who goes to the city and gets eaten.
soot: Everything else he does, he does for show. That he does for nobody. That's the only true thing about him.
* "Pay you for the name of the song."  -> op.sootMal1
* "Thank you, Mother."  -> op.sootMal2

# op.sootMal1
soot: The name. You want to sing it to him, don't you? You want to see his face. Wicked child.
soot: Free. That one's free. I want to hear his face too.
{do flag:knowGooseSong=1}
@end

# op.sootMal2
soot: Thank. Hm. Two thank-yous in a week. I'm getting spoiled.
@end

# op.pemVal arc=pemberton night=3,4,5 label="\"What's Valko like? Really?\"" if=met:valko&!flag:valkoDead&alive:pem prio=-3
@focus pemberton
pemberton: Mr. Drăgan, ‹sir›. He eats in the car. With his hands. He's been asked not to for forty years.
pemberton: He cannot read. Did you know that? He hides it very well. In 1991 I started reading the newspaper out loud on long drives, to myself, as if I were practising my diction. I've done it every night since. He's never asked me to. He's never asked me to stop.
pemberton: I think he thinks I don't know. I'd be grateful if he went on thinking that.
* "Your secret's safe."  -> op.pemVal1
* "Teach him, Pemberton. He'd let you, now."  -> op.pemVal2

# op.pemVal1
pemberton: Thank you, ‹sir›. It's a small kindness. It's the only one I've ever been allowed to do without being told.
{do rel:pemberton+1}
@end

# op.pemVal2
pemberton: Teach... a Hound to read. At his age. At mine.
pemberton: ...We'd need a very large-print book. Something with dogs in it. I'll think about it, ‹sir›. I'll think about it very seriously.
{do rel:pemberton+1; flag:pemTeaches=1}
@end

# op.gidSev arc=gideon night=3,4,5 label="\"What do you think of Lady Séverine?\"" if=met:severine&alive:sev prio=-3
@focus gideon
gideon: Séverine Marchetti has rented box eleven in my back room once. 1999. For one day. She paid in gold sovereigns and asked me never to speak of it.
gideon: I won't, then. Except to say: she slept in it the whole day with the lid open a crack, and she cried in her sleep, and she called a name, and it wasn't anyone in this century.
gideon: Everyone in the Ward thinks she's made of marble. Everyone's wrong. Marble doesn't cry in a pawnshop.
{do mem:gideon:sevbox}
@end

# op.gidLeo arc=gideon night=2,3,4,5 label="\"What do you make of Leo?\"" if=met:leo&alive:leo prio=-3
@focus gideon
gideon: The boy from Kowalski's. He came in once, last spring, to pawn his grandfather's watch. To pay for an open mic in another city. A competition.
gideon: I gave him forty dollars for it. It was worth four hundred. I kept it in the window, under the counter, so nobody would buy it. It's still there.
gideon: He never came back for it. He never went to the competition, either. Something about his mother. There's always something about the mother.
* "Give it back to him. From me."  -> op.gidLeo1
* "Keep it till he's ready."  -> op.gidLeo2

# op.gidLeo1
> He takes it out from under the counter. A gold watch on a cracked leather strap, the back engraved *L.P. 1958*. He wraps it in tissue paper and hands it to you.
gideon: Forty dollars, he owes me. Tell him he can pay in jokes.
{do flag:leoWatch=1; rel:gideon+1}
@end

# op.gidLeo2
gideon: Ready. Yes. He'll come. They always come back for their grandfathers.
@end

# op.tarMil arc=tariq night=2,3,4,5 label="\"What do you think of Detective Miller?\"" if=met:miller&alive:tariq prio=-3
@focus tariq
tariq: Black coffee. Burnt. One cruller, never finished. Two a.m. Every night since August.
tariq: She asked me once if I'd seen any of the seven. I said no. I'd seen three of them. I didn't say. I was afraid of the two in the unmarked car.
tariq: She knows I lied. She keeps coming back anyway. She leaves a dollar in the tip jar every night. I think it's her way of saying she's not angry. I think I'd rather she was angry.
* "Tell her. Now. She'll understand."  -> op.tarMil1
* "You were protecting yourself. That's allowed."  -> op.tarMil2

# op.tarMil1
tariq: Tell her. Tonight. At two. With the cruller.
tariq: ...My father would say: a lie you keep is rent you pay forever. Okay. Okay. I'll tell her. If I'm brave at two.
{do flag:tariqTellsMiller=1; rel:tariq+1}
@end

# op.tarMil2
tariq: Allowed. Yeah. It's allowed. It doesn't feel allowed.
@end

# op.rosHar arc=rostova night=3,4,5 label="\"What do you think of Harrow? Honestly.\"" if=met:harrow&alive:rostova prio=-3
@focus rostova
rostova: Honestly. He's the most frightened man I've ever worked with.
rostova: He signs everything twice. Did you know? Every form, every consent, every requisition. Once in the box and once in the margin, very small. As if he's afraid the first signature won't count. Or will.
rostova: I think he joined LANTERN to save people. I think he was right, once. I think he's been in it so long he can't remember which people.
* "Like you?"  -> op.rosHar1
* "Then help him remember."  -> op.rosHar2

# op.rosHar1
rostova: ...Yes. Like me. Thank you for that. I'll be awake all day now.
{do rel:rostova+1; lean:candour+1}
@end

# op.rosHar2
rostova: Help him. Me. The woman who fired the lance.
rostova: Perhaps. Perhaps that's exactly who should. Someone who knows how far the road goes.
{do flag:rosHarrow=1}
@end

# op.valSev arc=valko night=3,4,5 label="\"Why did you listen to Séverine? When she sent you after me?\"" if=alive:sev&!flag:valkoDead&flag:valkoAlly prio=-3
@focus valko
valko: Because she told me first. That he was dead. Before anyone. She came to the station when I got off the train and stood on the platform in the rain and told me herself.
valko: She didn't have to. She could have sent a ghoul. She came herself, and she said "Valko, I'm so sorry", and she put her hand on my arm, and nobody's done that in sixty years.
valko: And then she told me who did it. So I believed her. Because she'd been kind first. That's how she works. You see? Kind first.
* "That's how she got you."  -> op.valSev1
* "Maybe she was being kind. Both things can be true."  -> op.valSev2

# op.valSev1
valko: Yes. Yes. I know. I knew on the platform. I let her. I wanted somebody to put their hand on my arm.
{do rel:valko+1}
@end

# op.valSev2
valko: Both. Hm. Hounds don't like both. We like one smell at a time.
valko: ...But yes. Maybe. She was crying. I could smell it. You can't fake salt.
{do rel:valko+1; rel:severine+1}
@end

# op.okaMil arc=okafor night=3,4,5 label="\"What do you think of Detective Miller?\"" if=met:miller prio=-3
@focus okafor
okafor: That girl. That girl came to my door in August and sat on my couch and wrote down every word I said about Dani in a little notebook and didn't once look at her watch.
okafor: Everyone else looked at their watch. The officer who came first looked at his watch three times. She didn't. She asked what Dani liked for breakfast. Nobody asks that. That's not evidence. She asked anyway.
okafor: I pray for her. Every night, after Dani. She's second on the list. Don't tell her. She'd be embarrassed. She's Catholic. Lapsed. They're the worst for embarrassment.
{do mem:okafor:prays; comp+1}
@end
`,'c_opinions');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.pemTeaches&&!f.valkoDead)o.push(['A large-print book about dogs','Rides in the glovebox of the Continental. On long drives, a sixty-year Hound reads it aloud, very slowly, with his finger under the words, and the driver corrects him only when he asks.']);
  if(f.leoWatch&&!f.leoDead)o.push(['A gold watch, L.P. 1958','Is back on Leo\'s wrist. He owes Gideon forty dollars, payable in jokes. He pays a joke a week. Gideon says he\'s still in deficit.']);
  return o;});
