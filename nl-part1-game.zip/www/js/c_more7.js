'use strict';
/* THE NEW LORD — more people: Tariq's wife, Miller in 404, Gideon's son on the phone, and who made Lisette */
(function(){const X=NL.EXTRAS;
X.samina={n:'Samina',color:'#e0b0c0',role:'Tariq\'s wife',spec:{face:{long:1.0,cheek:1.3,jaw:1.0},skin:[.62,.46,.36],hair:{style:'bun',color:[.08,.06,.05]},shirt:[.45,.2,.35],coat:{color:[.25,.2,.3],length:.7,collar:true},height:.92}};
X.gideonson={n:'Marty Ash',color:'#c0c0a0',role:'Gideon\'s son, on the phone from Florida',spec:{face:{long:1.0,cheek:1.1},skin:[.86,.72,.62],hair:{style:'short',color:[.5,.4,.3]},shirt:[.9,.6,.3]}};
})();
NL.Script.add(String.raw`
// =====================================================================
// SAMINA
// =====================================================================
# smn.0 arc=tariq night=3,4,5 label="\"Tariq, who's in the back?\"" if=alive:tariq&rel:tariq>=2&!flag:saminaMet prio=2
@focus tariq
> Behind the counter, in the doorway to the stockroom, a small woman in a purple headscarf with her arms folded. She has been watching you for some time.
samina: So you're the night customer. The one he saves the coffee for. The one he talks about at dinner.
samina: I'm Samina. His wife. I want to look at you properly.
> She looks at you properly. It takes a while. Tariq, behind the till, has gone very quiet and is restocking the lighters with tremendous concentration.
* Let her look.  -> smn.look
* "It's good to meet you, Samina."  -> smn.hello

# smn.hello
samina: Is it. We'll see.
@next smn.look

# smn.look
samina: Eleven years I've been telling him this street will eat us. Eleven years he says, "Samina, it's a good street." Then two policemen take sixty dollars from us every Wednesday and he says it's a good street.
samina: And now there's you. And he's smiling in his sleep. And the policemen don't come. And I want to know what you are and what it costs.
* "I'm the thing the street was eating you with. I stopped."  -> smn.truth {do lean:candour+1}
* "A friend. It doesn't cost anything."  -> smn.friend
* "Ask Tariq. He knows."  -> smn.tariq

# smn.truth
> She doesn't flinch. She looks at your hands on the counter, at your face under the strip light, at the rain on your coat that doesn't steam.
samina: I thought so. My grandmother in Lahore told me stories. She'd have spat at you.
samina: I'm not my grandmother. I'll make you a deal. You keep this street safe for my husband, who is a fool and a good man. And I keep pretending I don't know what you are, for him. Yes?
* "Yes."  -> smn.deal {do promise:samina:Keep Tariq's street safe}
* "He already knows, Samina."  -> smn.knows

# smn.deal
samina: Good. Shake.
> She holds out her hand. You shake it. Hers is warm and dry and very strong, and she doesn't let go first.
{do flag:saminaMet=1; flag:saminaDeal=1; rel:tariq+1}
@end

# smn.knows
samina: Of course he knows. He's an idiot, not blind. I meant: I'll pretend for him that I don't know that he knows. Marriage is very complicated. You wouldn't understand.
{do flag:saminaMet=1; rel:tariq+1}
@end

# smn.friend
samina: Everything costs something. My father taught me that. He sold carpets. "Samina, if they tell you it's free, count your fingers after."
> She looks at your hands again.
samina: ...Well. You've got all yours. That's something.
{do flag:saminaMet=1}
@end

# smn.tariq
tariq: (without looking up from the lighters) I know nothing. I am restocking.
samina: You see? Eleven years. He knows nothing. He is restocking.
> She laughs, despite herself.
{do flag:saminaMet=1; rel:tariq+1}
@end

// =====================================================================
// MILLER IN 404
// =====================================================================
# mo.0 arc=miller night=4,5 label="\"Ines. Come with me. Mrs. Okafor should hear it from a detective.\"" if=alive:miller&rel:miller>=3&flag:met404&!flag:okaforDead&!flag:millerOkafor&has:payslip|alive:miller&rel:miller>=3&flag:met404&!flag:okaforDead&!flag:millerOkafor&flag:dcSeven prio=4
@focus miller
miller: Okafor. Danielle Okafor. 404. Her mother's filed eleven missing persons reports since August. Every one came across my desk. I sent her a form letter every time.
miller: You want me to go up there. Now. And tell her.
* "She's been waiting for someone with a badge."  -> mo.go
* "Not tonight. When you're ready."  -> mo.not

# mo.not
miller: I'll never be ready. That's the job. You're never ready. You go anyway.
@next mo.go

# mo.go
> Flat 404. Mrs. Okafor opens the door in her dressing gown. She sees Miller's badge. She sees you behind her. She knows. She knew when she heard two sets of footsteps.
okafor: Detective. Come in. I'll put the kettle on.
> Miller sits at the kitchen table, at the end, next to the second cup. She doesn't know about the cup. Mrs. Okafor doesn't tell her. She lets her sit there.
> Miller tells her. Officially. The trial. The fourth floor. Cohort B, number three. The sun. Twenty-two minutes. She uses the words "I'm sorry for your loss" and then stops, and puts her notebook away, and says it again without the notebook.
okafor: Thank you. Thank you for coming yourself. Eleven letters. I've got them all in a drawer. I'm going to burn them now. I don't need them now.
okafor: Will someone go to prison?
* Look at Miller.  -> mo.miller

# mo.miller
miller: Yes. If I have to carry him there myself.
> Mrs. Okafor nods. She pours Miller a second cup of tea, and puts it in front of her, and Miller doesn't know what it means, and drinks it.
{do flag:millerOkafor=1; flag:daniTold=1; rel:okafor+2; rel:miller+2; comp+2}
@end

// =====================================================================
// GIDEON'S SON
// =====================================================================
# gs.0 arc=gideon night=4,5 label="Gideon's phone is ringing. He isn't answering it." if=alive:gideon&rel:gideon>=2&!flag:gsDone prio=1
@focus gideon
> The telephone on the counter of the Pawn & Coffin, a black Bakelite thing from 1960, ringing and ringing. Gideon is doing his crossword and not looking at it.
gideon: My son. Marty. In Florida. He rings every Thursday at this time. He wants me to sell the shop and move into a "community" in Boca Raton with a pool and a man who calls bingo.
gideon: I never answer. He leaves a message. He's very patient. He gets that from his mother.
* Pick it up.  -> gs.pick
* "Answer it, Gideon."  -> gs.ans
* Leave it.  -> gs.leave

# gs.leave
> It rings eleven times and stops. Gideon fills in seven across. He doesn't look up for a long time.
@end

# gs.ans
gideon: ...Fine. Fine. Don't look at me like that. You look like my wife when you look like that.
> He picks it up.
gideon: Martin. Yes. Yes, it's me. No, I'm not dead. No, I'm not selling. ...Yes, I'm eating. ...No, I haven't fallen on the stairs. I have a very good... friend, who comes in. Night shift.
> A long pause. You can hear a man's voice, small and far away and worried, on the other end.
gideon: ...I love you too. I know. I know. I'll come at Christmas. I'll come at Christmas, Marty. I promise.
> He puts the phone down. He looks at it.
gideon: I haven't said that to him since his mother's funeral. Eleven years. I'm going to Boca Raton for Christmas. God help me. Bingo.
{do flag:gsDone=1; flag:gideonChristmas=1; rel:gideon+2; comp+2}
@end

# gs.pick
> You pick it up. A man's voice, fifties, worried, Florida in the vowels.
gideonson: Dad? Dad, is that you? Dad, you never pick up. Are you okay?
* "This is a friend of your father's. He's fine. He's right here."  -> gs.pick2
* Hand the phone to Gideon without a word.  -> gs.ans

# gs.pick2
gideonson: A friend. Dad has a friend? Since when does Dad have friends? He has customers and he has the dead.
gideonson: ...Is he eating? Tell me honestly. He never tells me honestly.
* "He's eating. He does a crossword every night. He talks about you."  -> gs.pick3
* "He's lonely, Marty. Come and see him."  -> gs.pick4

# gs.pick3
gideonson: He talks about me. He does? What does he... no. Don't tell me. I'll cry in the parking lot at Publix.
gideonson: Put him on. Please. Just put him on.
@next gs.ans

# gs.pick4
gideonson: ...Lonely. Dad. Yeah. Yeah, I know. I know. I keep asking him to come here.
gideonson: I'll come. I'll come up. Christmas. Tell him I'm coming whether he likes it or not.
> Gideon, at the counter, has heard every word. He takes his glasses off. He puts them back on.
{do flag:gsDone=1; flag:martyComing=1; rel:gideon+2; comp+1}
@end

// =====================================================================
// LISETTE'S SIRE
// =====================================================================
# lsY.0 arc=lisette night=4,5 label="\"Lisette. Who made you?\"" if=mem:lisette.hamburg&!flag:lisetteGone prio=3
@focus lisette
lisette: Who made me. Hm. Nobody asks that. It's terribly rude. Like asking someone's weight.
lisette: Hamburg, 1919. A man called Konrad, a Gilded portrait painter with consumption and no money, who wanted a model who'd never age so he could take as long as he liked over the painting.
lisette: He took eleven years. Then he walked into the Elbe at dawn because he couldn't get the mouth right. He left the painting unfinished. I've never seen it. Somebody sold it.
web(6): An unfinished portrait. A Gilded painter. The Gilded collect. Someone in this Ward has it on a wall.
* "I'll find it."  -> lsY.find {do promise:lisettepaint:Find Lisette's portrait}
* "Do you want to see it?"  -> lsY.want

# lsY.want
lisette: See myself, as he saw me, in 1919, with the mouth wrong? Darling, I count my teeth every night. What do you think?
@next lsY.find

# lsY.find
lisette: Find it. Hm. People have offered. Nobody's ever done it.
lisette: If you do... I don't know. I'd owe you. I'd hate that. I'd hate it so much I might like you.
{do flag:lisettePaintAsk=1}
@end

# lsY.mal arc=malakor night=4,5 label="\"Malakor. A portrait. Hamburg, 1919. A girl in red. The mouth's wrong.\"" if=flag:lisettePaintAsk&!flag:lisettePaint&alive:malakor prio=5
@focus malakor
malakor: A girl in red. Hamburg. The mouth wrong.
> He goes very quiet. He goes into the back of the chop shop. He comes back with something wrapped in brown paper, the size of a door.
malakor: I bought it in 1958 from a dead man's estate. I hang it in my office. I've never known who she was. I look at it when I'm deciding faces. The mouth is the only thing in the world I've never been able to fix.
malakor: It's Lisette. Of course it's Lisette. God. I've been looking at her every night for sixty years and I never once saw it.
* "Give it to her."  -> lsY.give
* "What do you want for it?"  -> lsY.buy

# lsY.give
malakor: Give. Me. Give a painting.
malakor: ...Fine. Fine. She'll owe me. Good. Somebody in the Gilded Court should owe me something that isn't money.
{do flag:lisettePaint=1; rel:malakor+1}
@next lsY.deliver

# lsY.buy
malakor: Want. Hm. Nothing. For once. Take it. Tell her where it was. Tell her I looked at it every night. Don't tell her I said that last part.
{do flag:lisettePaint=1; rel:malakor+1}
@next lsY.deliver

# lsY.deliver
> You carry it to the Reliquary in the rain under your coat. You find Lisette counting the room. You put it down in front of her and pull off the brown paper.
> A girl in red, on a chair by a window, in Hamburg, in 1919. Her hands in her lap. Her eyes very bright. And the mouth: almost a smile, almost not, caught in the moment between the two, unfinished. Konrad never got it right because it was never one thing.
> Lisette looks at it for a long time. She doesn't count anything.
lisette: ...He didn't get it wrong. Oh, the idiot. He got it right. That's my mouth. That's exactly my mouth. That's what it does.
lisette: Eleven years and he walked into the river because he thought it was wrong.
> She touches the painted mouth with one finger. Then her own.
{do keep:lisettepaint; rel:lisette+4; comp+2; xp:40:The portrait}
@end
`,'c_more7');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.gideonChristmas||f.martyComing)o.push(['Gideon Ash, at Christmas','Boca Raton. A pool. A man who calls bingo. He won twice and complained about the prizes. His son drove him to the airport the day after Christmas and cried in the parking lot, and Gideon pretended not to see, and then didn\'t pretend.']);
  if(f.lisettePaint)o.push(['Lisette','Has a painting in the Reliquary now, behind the bar, of a girl in red in Hamburg in 1919. She has stopped counting her teeth. She counts the room instead, and then she looks at the painting, and she almost smiles, and almost doesn\'t.']);
  if(f.saminaDeal)o.push(['Samina','Has never once let on that she knows. Every night at five she watches her husband pour a coffee for nobody and leave it on the counter, and every night she says "Tariq, you\'re wasting coffee," and every night he says "yes".']);
  return o;});
