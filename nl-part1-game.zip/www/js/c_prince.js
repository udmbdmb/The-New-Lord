'use strict';
/* THE NEW LORD — "The Hall Table": a letter to the Prince who has not been seen since 1912, and the answer that comes back by morning */
(function(){
NL.TASKS.s_letter={n:'The Hall Table',xp:70,cat:'side'};
NL.ITEMS.princereply={n:'A Letter from the Heights',type:'read',d:'Black-edged cream paper. A hand so old the letters lean like trees in wind. Signed with a single initial that might be an M or might be a wave.'};
NL.Script.opt('hg.hub','* "Quill. May I leave a letter on the hall table?"  -> pq.0 {once} {if !flag:princeLetter}','start');
NL.Script.on('princereply',{if:'flag:princeLetter&night:5'},'give:princereply; text:Quill|A reply has come down from the Heights. It is in your coat. She does not usually answer the same night. — Q.');
})();
NL.Script.add(String.raw`
# pq.0
quill: A letter. To the Prince. From the Ward.
quill: People did, once. Hundreds a year. Petitions, threats, love letters, a great many complaints about drains. Nobody has written since 1974. I think they forgot she was there.
quill: There's paper in the hall. And a pen that belonged to a Duke. Mind the nib.
> The hall of the house with no windows: black and white tiles, a long table of dark wood, a single candle, a silver tray. On the tray, nothing. It has been empty for fifty years.
> You sit down with the Duke's pen.
{do task:s_letter; note:s_letter|You are writing a letter to the Prince of the city, who has not been seen since 1912. Quill will leave it on the hall table.}
@next pq.open

# pq.open
> How do you begin a letter to someone who has ruled a city for a century and a half without once showing her face?
* *"Your Highness,"*  -> pq.open1 {do flag:plTone=formal}
* *"Dear Prince,"*  -> pq.open2 {do flag:plTone=plain}
* *"To whoever is behind the door,"*  -> pq.open3 {do flag:plTone=bold}
* *"Madam. I ate your Sheriff."*  -> pq.open4 {do flag:plTone=blunt}

# pq.open1
tenant: Correct. Cold. She'll read the rest.
@next pq.body

# pq.open2
tenant: "Dear." Nobody has called her dear since Victoria. She'll either be charmed or appalled.
@next pq.body

# pq.open3
tenant: Oh, very good. Very good. She'll hate it. She'll read every word.
@next pq.body

# pq.open4
tenant: Child. CHILD. ...Well. It's honest. Go on. You may as well.
@next pq.body

# pq.body
> And then what? What is the one thing you want the Prince to know, before Friday?
* Tell her the truth about Monday. The freezer, the lance, Harrow, why you drank.  -> pq.b_truth {do lean:candour+1}
* Warn her about LANTERN. The lamps. Her Court on top of them.  -> pq.b_warn {if flag:knowLantern|flag:knowCode}
* Ask her for nothing. Tell her about the Ward. Tariq's coffee. Mrs. Okafor's second cup. The cats.  -> pq.b_ward {do lean:pride-1}
* Ask her why she hides.  -> pq.b_why
* Ask her for mercy.  -> pq.b_mercy
* Let the Tenant write it.  -> pq.b_vane {if sync>=40|flag:chord}

# pq.b_truth
> You write it all. The freezer. 4:14. The light through the door. The old man kneeling and burning from the front. Harrow in the doorway, apologizing. Your mouth on his throat, because it was the only way to save anything.
> It takes six pages. The Duke's pen runs dry twice.
{do flag:plBody=truth}
@next pq.close

# pq.b_warn
> You write it plainly, like a report. Project LANTERN. Quartz lamps in the vault under Platform 0. A switch on Ferrier Lane. One o'clock on Friday. Her Magistrate in his chair, her Court in their seats, the sun under all of them.
> You draw a little map. Badly.
{do flag:plBody=warn}
@next pq.close

# pq.b_ward
> You don't write about Friday at all. You write about the Ward. The Lucky Mart at five in the morning with the coffee going cold on the counter. Thirty-one cats behind the bins on Halloran Street. A mother in 404 who leaves two cups out. A boy on the third floor of the Rookery who does twenty minutes about the bus. A man raking gravel at night so someone can hear who comes.
> You tell her it's a good Ward. You tell her it's worth keeping. You don't ask her for anything.
{do flag:plBody=ward}
@next pq.close

# pq.b_why
> You write one question, and then you sit and look at it for a long time.
> *Why don't you ever come out?*
> You add nothing else. It seems like the kind of question that ought to be left alone on a page.
{do flag:plBody=why}
@next pq.close

# pq.b_mercy
> You ask her for your life. You're not proud of how it reads. It reads like what it is: a five-day-old thing in a dead man's coat, asking the oldest thing in the city to let it live.
{do flag:plBody=mercy}
@next pq.close

# pq.b_vane
> You give him the pen. It's the strangest thing you've ever felt: your own hand moving, in a hand that isn't yours, fast and slanted and furious, in a French that's two hundred years out of date.
> When it's done you can't read it. You don't know what he said. He won't tell you.
tenant: It's between her and me. It always was.
{do flag:plBody=vane; sync+3}
@next pq.close

# pq.close
> How do you sign it?
* With your name.  -> pq.sign1 {if name}
* "The Sheriff's child."  -> pq.sign2
* "The thief."  -> pq.sign3
* Don't sign it.  -> pq.sign4

# pq.sign1
{do flag:plSign=name}
@next pq.leave

# pq.sign2
{do flag:plSign=child}
@next pq.leave

# pq.sign3
{do flag:plSign=thief}
@next pq.leave

# pq.sign4
{do flag:plSign=none}
@next pq.leave

# pq.leave
> You fold it. You put it on the silver tray, on the long dark table, in the hall of the house with no windows. The candle flickers. Somewhere upstairs, very faintly, a floorboard creaks.
quill: There. It's on the table. She'll have it by morning. She always does.
quill: Fifty years that tray's been empty. It looks better with something on it.
{do flag:princeLetter=1}
@end

// --- reading the reply ---
# plR.0 arc=tenant night=5 label="Open the letter from the Heights." if=has:princereply&!flag:plRead prio=8
@focus tenant
> Black-edged cream paper. The hand is so old the letters lean like trees in wind. It's short.
@gate flag:plBody=vane ? plR.vane : plR.b

# plR.b
@gate flag:plBody=truth ? plR.truth : plR.b2

# plR.b2
@gate flag:plBody=warn ? plR.warn : plR.b3

# plR.b3
@gate flag:plBody=ward ? plR.ward : plR.b4

# plR.b4
@gate flag:plBody=why ? plR.why : plR.mercy

# plR.truth
> *"Thank you for the six pages. Nobody has told me the truth in a letter since 1912. Most of them told me what they thought I wanted. You told me what happened, which is rarer and much less pleasant. Ambrose will judge the law. I judge nothing. But I will be listening, through him, on Friday. — M."*
{do flag:plRead=1; flag:princeFavour=1; task:s_letter=done; xp:70:The Hall Table}
@next plR.sign

# plR.warn
> *"I know about the lamps. I have known since Tuesday; the rats tell Soot, and Soot tells my gravel. I thank you for your map, which is very bad. I am glad you thought to draw it. Ambrose will sit in his chair on Friday, because he must. Something will be done about what is under it. Do not ask me what. — M."*
{do flag:plRead=1; flag:princeFavour=1; flag:princeKnowsLamps=1; task:s_letter=done; xp:70:The Hall Table}
@next plR.sign

# plR.ward
> *"I had forgotten. That is the honest answer. I have ruled the Ward from this house for a hundred and fifty years and I had forgotten that it has cats in it, and a woman with two cups, and a shop that leaves coffee out for the dead. I have never once been to the Lucky Mart. I am told the coffee is terrible. Thank you for asking me for nothing. It is the only thing anyone has given me in fifty years. — M."*
{do flag:plRead=1; flag:princeFavour=2; task:s_letter=done; xp:80:The Hall Table; comp+2}
@next plR.sign

# plR.why
> *"Because in 1912, at a ball in this house, with every window lit, I looked at my reflection in the great mirror in the hall and saw that I had no face. Not a monster's face. No face at all. Just a dress, and a necklace, and nothing. I had been dead so long I had forgotten what I looked like, and so had the glass.*
> *"I bricked up the windows the next morning. I have not been seen since, because there is nothing to see.*
> *"You are the first person in a hundred years to ask. I find I don't mind. — M."*
tenant: ...I didn't know. Eighty years as her Sheriff. I never knew.
{do flag:plRead=1; flag:princeFavour=1; flag:princeSecret=1; task:s_letter=done; xp:80:The Hall Table; mem:tenant:prince}
@next plR.sign

# plR.mercy
> *"Mercy is not mine to give. I gave it away to Ambrose in 1871 so I would never be tempted to use it. I am sorry. You asked very nicely, which almost nobody does. — M."*
{do flag:plRead=1; task:s_letter=done; xp:50:The Hall Table}
@next plR.sign

# plR.vane
> The reply is in the same old French, and you can't read it, and he reads it for you, aloud, inside your head, very slowly.
tenant: She says: *"Absalom. You fool. You beautiful fool. You went to a mortal for a cure, and now a child carries you. I will not save you. I could not save you in 1888 either. But I am glad you wrote. I am glad of the goat. — M."*
tenant: ...She remembered the goat. Ambrose told her about the goat. Two hundred years and she remembered.
{do flag:plRead=1; flag:princeFavour=2; task:s_letter=done; xp:80:The Hall Table; sync+3}
@next plR.sign

# plR.sign
@gate flag:plSign=name ? plR.name : plR.signend

# plR.name
> There's a postscript, smaller, in the same leaning hand:
> *"P.S. Casey Morrow. I have written it in the book I keep of the names of the Ward. You are the first name added since 1974."*
{do comp+2}
@end

# plR.signend
@gate flag:plTone=blunt ? plR.blunt : plR.end

# plR.blunt
> There's a postscript, smaller:
> *"P.S. 'Madam, I ate your Sheriff.' I laughed for the first time since the Armistice. Quill thought I was dying."*
{do comp+1}
@end

# plR.end
@end
`,'c_prince');

(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;
const st0=ENC.tribunal.start;ENC.tribunal.start=function(S,G){const r=st0.call(this,S,G);const p=S.flags.princeFavour||0;if(p)r.prog+=p;return r;};
const mv=ENC.tribunal.moves;ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
  if(S.flags.princeKnowsLamps)M.push({t:'"Magistrate. The Prince knows what is under your chair. She told me so in writing."',once:'tb_princelamps',ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [T('The Magistrate\'s face does not move. Then, very slightly, it does: the look of a man who has just been told that his employer has been paying attention.'),L('magistrate','...In writing. From the Heights. To a neonate. Hm.')];}});
  return M;};
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.plRead&&f.plBody==='ward')o.push(['The Prince','On a Tuesday in December, at five in the morning, a woman nobody had seen since 1912 came into the Lucky Mart in a veil, and bought a coffee, and drank it standing at the counter. Tariq said it was terrible. She said she knew.']);
  else if(f.princeSecret)o.push(['The Prince','Has a mirror again. Small. In the hall. Covered with a cloth. Sometimes, at night, Quill finds the cloth folded on the table.']);
  else if(f.plRead)o.push(['The hall table','Has letters on it again. Six or seven a week, from the Ward. Quill says she answers every one.']);
  return o;});
})();
