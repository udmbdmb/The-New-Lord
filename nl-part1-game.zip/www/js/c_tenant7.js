'use strict';
/* THE NEW LORD — the Tenant, last things: on the final night, what he wants you to know about the choice you're about to make */
NL.Script.add(String.raw`
# tl.last arc=tenant night=5 label="\"Whatever happens tonight. Is there anything you want?\"" if=time<230 prio=1
@focus tenant
tenant: Want. On the last night. Tonight, in a railway station, with three hundred of them waiting.
tenant: I want you to stop asking me what I want. That's the first thing. You've asked me all week. Nobody has asked me what I wanted since 1787. It's made me very greedy.
tenant: The second thing is harder.
* "Go on."  -> tl.last1

# tl.last1
tenant: Whatever they decide in the chalk, child, you'll come out of it as one of three things. A Sheriff with a dead man in their head. A dead man with a Sheriff's body. Or ash.
tenant: I want you to know I don't mind which of the first two. I thought I would. On Monday I'd have fought you for every inch. Now I find I'd be content either way, as long as the one who walks up those stairs is somebody who'd have helped Earl ask Dolores about the pancakes. {if flag:earlDolores=2}
tenant: Now I find I'd be content either way, as long as the one who walks up those stairs is somebody who'd say please to the Magistrate. {if !flag:earlDolores=2}
* "And if it's ash?"  -> tl.last2
* "I don't want you to fade."  -> tl.last3
* "I want to be the one who walks up the stairs. Me."  -> tl.last4

# tl.last2
tenant: Then it's ash. And we go together, which is more than I managed the first time. I was alone in that freezer before you came in. I'd rather not be alone in the next one.
tenant: But I don't think it'll be ash. You've been very busy. Busy people are hard to burn. The paperwork alone.
{do sync+1}
@end

# tl.last3
tenant: No. I know. That's the strangest thing about this week. Somebody who doesn't want me to fade.
tenant: I'll stay, then. As much as I can. In a corner. Being difficult about the furniture.
{do sync+2}
@end

# tl.last4
tenant: You. Yes. Good. Good. Say it like that in the chalk. Not "the Sheriff". Not "Absalom's killer". You.
tenant: I'll be there. In the back row. Where I always sat, in the end. The back row's the best seat, child. You can see who's leaving.
{do sync+1; comp+1}
@end

# tl.blood arc=tenant night=5 label="\"What will you tell them about my blood? If they ask?\"" if=true prio=-1
@focus tenant
tenant: Your blood. The clan it came out. They'll ask, in the chalk. They always ask what line a fledgling is. It's the first question after the name.
tenant: Tell them the truth. Tell them it came out what it came out, and that it was Absalom Vane's, and that it chose. Blood chooses, child. It looked at everything you were on Monday morning, the job and the sickness and the sister on the coast, and it chose.
tenant: I've never asked mine what it would have chosen, if I'd let it. I let my sire decide. Two hundred years of Sovereign because a man in Ajaccio thought I'd look well in a crown.
* "What do you think yours would have chosen?"  -> tl.blood1

# tl.blood1
tenant: Mine...
tenant: Something quieter. Something that sat in the back of the Courthouse with a typist and watched the pigeons. I don't know if there's a clan for that.
tenant: Perhaps there will be. Perhaps you'll start it.
{do sync+1}
@end

# tl.pact arc=tenant night=5 label="\"Did I choose the right side? On Thursday?\"" if=flag:pact prio=-1
@focus tenant
tenant: The right side. Child, there isn't one. There's only the side you'll be able to look at in the morning.
tenant: You chose Séverine's leash. She'll pull it. Not hard. Just enough that you remember it's there. You'll hate her for it, and you'll understand her for it, and that's the Court. {if flag:pact=court}
tenant: You chose Malakor's stairs. He'll keep his word. Butchers do. And one night in ten years he'll ask you to look away from something, and you'll have to decide whether you meant forever. {if flag:pact=syndicate}
tenant: You chose Miller. A mortal. A detective. In a hat. I'd have laughed at you on Monday. I'm not laughing now. She's the only one of them who'll never ask you for anything except the truth. {if flag:pact=mortal}
tenant: You chose Soot's seat. A hundred years from now, when everyone you know is an echo, you'll go down those steps and sit. I'm sorry. And I think you'll be glad. Both. {if flag:pact=wraiths}
tenant: You chose Local 0. The stool. The napkin. The Court will never forgive you. Good. The Court never forgave me either, and I sat at its right hand. {if flag:pact=union}
tenant: You chose Harrow. I'm not going to pretend that isn't what you did. But it's not morning yet. {if flag:pact=lantern}
{do sync+1}
@end

# tl.name arc=tenant night=5 label="\"Say my name. My real one. Just once.\"" if=name prio=-1
@focus tenant
tenant: Your name. Casey Morrow. Subject Eight. Cohort B. Five hundred dollars.
tenant: No. That's how they'd say it. Let me try again.
tenant: Casey. Casey Morrow, who rode in the back of ambulances, or argued with judges, or ran a door on Dock Road, or found seven files in a dead boy's box. Who has a sister on the coast with a fish on her mailbox. Who walked into a freezer as somebody's experiment and walked out as somebody.
tenant: Casey. There. I've been wanting to say it all week. It felt presumptuous. It's your name. I've only been borrowing your mouth.
* "Say it again."  -> tl.name1
* "Thank you, Absalom."  -> tl.name2

# tl.name1
tenant: Casey.
> He says it the way Agnes's name sounds in his voice. You don't tell him you noticed. He knows you noticed.
{do sync+2; comp+1}
@end

# tl.name2
tenant: Absalom. Nobody calls me that any more. Ambrose does. Séverine, when she's angry. You, now.
tenant: Thank you, Casey. Go on. They're waiting. Let's go down and be looked at.
{do sync+2}
@end
`,'c_tenant7');
