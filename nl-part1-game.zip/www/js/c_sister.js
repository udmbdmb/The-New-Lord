'use strict';
/* THE NEW LORD — "Harbour Row": you had a sister. You have a sister. She's eighty miles away, on the coast, and she's been waiting by the phone since October. */
(function(){
NL.TASKS.s_sister={n:'Harbour Row',xp:80,cat:'side'};
NL.EXTRAS.operator={n:'Information',color:'#b0b0b0',role:'The operator',spec:{face:{long:1.0,cheek:1.1},skin:[.8,.66,.58],hair:{style:'bun',color:[.3,.2,.12]},shirt:[.4,.45,.6],glasses:{type:'round'}}};
NL.EXTRAS.robin={n:'Robin Morrow',color:'#a8d0c8',role:'Your sister · on the telephone',spec:{face:{long:1.02,cheek:1.2,jaw:1.0},skin:[.86,.74,.68],hair:{style:'crop',color:[.18,.12,.08]},shirt:[.55,.6,.5],coat:{color:[.35,.3,.4],length:.5,collar:false}}};
NL.Script.opt('phone.0','* Call Robin Morrow, 14 Harbour Row, Saltmarsh.  -> sr.call {if flag:sisterNum&night>=3&!flag:sisterCalled}','start');
NL.Script.opt('phone.0','* Dial information. Ask for Morrow, Saltmarsh.  -> sr.info {if task:s_sister=active&!flag:sisterNum&!flag:sisterInfoTried}','start');
NL.Script.opt('hc4.hub','* "Leave my sister out of this, Tom."  -> sr.harrow {once} {if task:s_sister|flag:knowSisterAddr}','start');
})();
NL.Script.add(String.raw`
// --- the Tenant brings it up ---
# sr.0 arc=tenant night=3,4,5 label="Ask him what else he saw in your memories." if=name|flag:knowSisterAddr prio=5
@focus tenant
tenant: You want to know what else is in there. In you. Behind the door you can't open.
tenant: I've been looking, while you sleep. It's very rude. I'm sorry. I couldn't help it. It was the only room in the house with the lights on.
tenant: There's a woman. Older than you. Dark hair cut short, with a pencil behind her ear. She's at a kitchen table with a pile of exercise books, marking them in red. She keeps looking at a phone that doesn't ring.
tenant: She's your sister, child. She has been looking at that phone since the middle of October.
* "What's her name?"  -> sr.name
* "I don't want to know. Not yet."  -> sr.notyet

# sr.notyet
tenant: No. Of course. Some doors you open from the inside, when you're ready.
tenant: But she's still looking at the phone.
@end

# sr.name
tenant: You call her Rob. She hates it. Robin. Robin Morrow. She teaches seven-year-olds to read in a school by the sea. She draws fish on things. Envelopes. Your hand, once, in biro, when you were small and wouldn't sit still.
nostalgia(6): A fish in blue biro on the back of your hand. Somebody holding your wrist very gently so it wouldn't smudge.
{do task:s_sister; note:s_sister|Your sister Robin Morrow lives on the coast, in Saltmarsh. You need her number. Miller could run the name; so could the information line from the payphone.; mem:tenant:robin; flag:knowRobin=1}
* "How do I find her?"  -> sr.find

# sr.find
tenant: The detective. She runs names. It's her one pleasure in life. Or the telephone on Ferrier Lane; they still have operators, I'm told, for people with nobody else to ask.
tenant: And child. Be quick. If I know where she is, so does the man with the peppermints. He knows everything about you. He's had a year.
@end

// --- Miller runs the name ---
# srM.0 arc=miller night=3,4,5 label="\"Ines. Run a name for me. Robin Morrow, Saltmarsh.\"" if=task:s_sister=active&!flag:sisterNum&alive:miller prio=6
@focus miller
miller: Run a name. For you. On the department's computer, which logs every search with my badge number.
@gate rel:miller>=2 ? srM.yes : srM.maybe

# srM.maybe
miller: Why should I?
* "Because she's my sister. And she doesn't know I'm dead."  -> srM.sister {do lean:candour+1}
? velvet 10 "Because Harrow already has her address. And I don't."  -> srM.harrow | srM.no {id srM_v}

# srM.sister
> She looks at you a long time.
miller: Your sister.
miller: ...My brother went missing in 2011. I didn't know for thirteen years. I'd have given anything for a phone call. Even from a dead man.
@next srM.yes

# srM.harrow
miller: Harrow. Has your sister's address. Christ.
@next srM.yes

# srM.no
miller: No. Sorry. Not on my badge. Find another way.
@end

# srM.yes
> She sits in her car outside the Lucky Mart with the laptop on the steering wheel. The screen lights her face blue. She types with two fingers, very fast.
miller: Morrow, Robin E. Forty-one. Fourteen Harbour Row, Saltmarsh. Teacher, Saltmarsh Primary. No record. One parking ticket, 2019, contested, won.
miller: ...And a missing persons report. Filed October 17th. For a "Casey Morrow, sibling". Filed in Saltmarsh, sent here, sat on a desk at Precinct 9 for two weeks.
miller: My desk. It was on my desk. Under seven other ones.
> She writes a phone number on the back of a Lucky Mart receipt and gives it to you.
miller: She rang the precinct nine times. I've got the log. Nine times. Every one says the same thing: "Has anyone found my brother?" Or sister. It changes. The operator wasn't sure.
* "Casey. Just Casey. That's what she'd have said."  -> srM.casey

# srM.casey
miller: Casey. Right.
miller: Call her. Not for you. For her. Nine times.
{do flag:sisterNum=1; rel:miller+1; note:s_sister|Robin's number is on a Lucky Mart receipt. She's filed a missing persons report. She's rung Precinct 9 nine times. The payphone on Ferrier Lane will do.}
@end

// --- information line ---
# sr.info
> You dial the information line. A woman with a cold puts you through to another woman with a worse one.
operator: City and listing?
* "Saltmarsh. Morrow. Robin."  -> sr.info2

# sr.info2
operator: I've got an R. Morrow on Harbour Row. That's a private listing, I can't give that out without... sorry, who's calling?
? stagecraft 10 "Saltmarsh Primary. It's about one of her students. It's urgent."  -> sr.infook | sr.infono {id sr_info}
? velvet 11 "Her family. Please. It's been a very long month."  -> sr.infook | sr.infono {id sr_info2}

# sr.infook
operator: ...Okay. Okay. You didn't get this from me. Have you got a pen?
> You don't have a pen. You remember it anyway. Numbers stick to you now. Everything sticks.
{do flag:sisterNum=1; flag:sisterInfoTried=1}
@end

# sr.infono
operator: I'm sorry. I can't. You'll have to write to her.
> The line clicks. You try again. The same woman, the same cold, the same answer.
{do flag:sisterInfoTried=1}
@end

// --- the call ---
# sr.call
> Three in the morning. Rain on the payphone's steel hood. Fifty cents. Eleven numbers.
> It rings once. Twice. You hear it pick up before it's finished the second ring, the way a phone picks up in a house where someone sleeps with it on the pillow.
robin: Hello? Hello?
> Her voice. You didn't know you knew it. You know it the way you know the floor is under your feet.
nostalgia(4): Her voice reading *The Owl Who Was Afraid of the Dark* to you at four years old, doing all the voices, getting the owl wrong on purpose because it made you laugh.
{do flag:sisterCalled=1}
robin: Hello? Who is this? ...Casey? Casey, is that you?
* "Rob."  -> sr.rob
* Say nothing.  -> sr.silent
* "Ms. Morrow, this is Precinct 9. It's about your missing persons report."  -> sr.police {do lean:candour-1}

# sr.silent
> You stand in the rain and say nothing. You can hear her breathing. You can hear a radio in her kitchen, very low. You can hear her chair scrape back.
robin: Casey. I know it's you. I know it's you. Nobody else breathes like that on the phone. Like they're trying not to.
robin: You don't have to say anything. Just... don't hang up. Please don't hang up.
* Stay on the line. Say nothing. Let her talk.  -> sr.listen
* "Rob."  -> sr.rob
* Hang up.  -> sr.hang

# sr.hang
> You put the receiver down very gently, as if it might break. The coins don't come back.
> On Ferrier Lane, in the rain, you stand by the payphone for a long time. It doesn't ring. You knew it wouldn't. She doesn't have the number.
{do comp-2:You hung up; flag:sisterHung=1}
tenant: Oh, child.
@end

# sr.listen
> She talks. She talks for twenty minutes. She talks the way people talk to the sleeping in hospitals: steady, ordinary, to keep them company.
> The school's doing *Joseph* for Christmas and a boy called Ashton is the coat. Mom's grave needs weeding. The fish on the mailbox has faded and she's not repainting it until you come home and do it with her, because you did it the first time, when you were nine, with a Sharpie, and got grounded.
> She tells you she rang the police nine times. She tells you a detective rang back on Tuesday and said they were looking. She tells you she doesn't believe them.
> She tells you she isn't angry. She tells you she just wants to know you're warm.
robin: Are you warm, Case? Wherever you are. Are you warm?
* "...No."  -> sr.warmno {do lean:candour+1}
* "Yes."  -> sr.warmyes

# sr.warmno
> A long silence. Then a sound like someone sitting down on a kitchen floor.
robin: Okay. Okay. Then I'll keep the heating on. For both of us. Okay?
{do comp+3:Rob; xp:40:Harbour Row; task:s_sister=done; flag:sisterTalked=1}
@next sr.end

# sr.warmyes
robin: Liar. You were always a terrible liar. You used to go red. Are you going red?
* "I can't go red any more, Rob."  -> sr.red

# sr.red
robin: ...What does that mean? Casey? What does that mean?
@next sr.truth

# sr.police
> You do a voice. A tired detective's voice. You've heard enough of them this week.
robin: Precinct... is it Detective Miller? Have you found... have you found Casey?
> And then, before you can answer:
robin: Wait. Wait. That's... Casey, that's YOU. You're doing the voice. You did that voice at Dad's funeral to make me laugh. The traffic warden. Casey.
* "...Yeah. It's me."  -> sr.rob
* Keep the voice going. "Ms. Morrow, I'm afraid I have bad news."  -> sr.policebad

# sr.policebad
> You tell her, in a stranger's voice, that her sibling Casey Morrow died in an industrial accident in the Marrow Ward on the morning of Monday the 28th. That the body was not recoverable. That the department is very sorry for her loss.
> She doesn't say anything for a long time.
robin: ...Okay. Thank you, Detective. Thank you for calling.
robin: Casey, if you ever want to stop being dead, I'm at Harbour Row. I'll always be at Harbour Row.
> She hangs up.
{do flag:sisterToldDead=1; task:s_sister=done; xp:30:Harbour Row; comp-1}
tenant: She knew. Every word. She knew, and she let you do it, because you needed to. That is what sisters are for, I'm told. I never had one.
@end

# sr.rob
> She makes a noise. You've never heard anyone make that noise. It goes up and down at the same time.
robin: Casey. Oh my God. Oh my God. Where ARE you? Are you okay? Are you hurt? I've been... I rang the police nine times, Case. NINE TIMES. Where have you BEEN?
* "I can't tell you."  -> sr.canttell
* "Something happened to me. I'm okay. I'm not okay. I'm here."  -> sr.something
* Tell her the truth. All of it.  -> sr.truth

# sr.canttell
robin: Can't tell me. Can't. Are you in trouble? Is it money? Is it a guy? Is it... Case, are you using again?
web(5): Again. *Again.* There's a whole life back there, behind the freezer door, that you don't remember and she does.
* "No. Nothing like that. I promise."  -> sr.something
* "...I don't remember."  -> sr.dontrem

# sr.dontrem
robin: You don't... remember? What don't you remember?
* "Most of it. Most of me. I'm finding it again in pieces."  -> sr.pieces

# sr.pieces
robin: Pieces. Okay. Okay, I've got pieces. I've got loads of pieces. Do you want some?
* "Yes. Tell me something about me."  -> sr.tellme
* "Not over the phone."  -> sr.something

# sr.tellme
robin: Something about you. God. Okay.
robin: You hated peas. You hid them in your sock. You wanted to be a marine biologist until you found out it was mostly maths, then you wanted to be a lighthouse keeper, then a nurse, then nothing for ages. You did the fish on the mailbox. You can't whistle. You always, always say please. Even to the dog. Even to the toaster. Mom used to say you'd say please to a burglar.
> The Tenant, in your blood, very quietly, laughs.
tenant: Harrow said that. "You say please to shopkeepers." It's been you all along. It's the first thing about you that was never me.
{do sync-3:Please; comp+3:Rob; mem:robin:please; flag:sisterPieces=1}
@next sr.something

# sr.something
robin: Something happened. Okay. Okay. When are you coming home?
* "Saturday. If I can. If I'm still... if I can."  -> sr.saturday {do promise:sisterhome:Go home to Harbour Row}
* "I don't think I can, Rob. Not ever."  -> sr.never
* "Rob. Someone might come to the house. A man in a brown coat. Don't let him in."  -> sr.warn

# sr.saturday
robin: Saturday. Okay. Saturday. I'll make the soup. The leek one. You can tell me then. All of it. I don't care what it is.
robin: I'm going to paint the fish. On Saturday. Bring a Sharpie.
{do flag:sisterSaturday=1; comp+3; xp:60:Harbour Row; task:s_sister=done; flag:sisterTalked=1}
@next sr.end

# sr.never
robin: Not ever. What does that... Casey, what does that MEAN?
@next sr.truth

# sr.warn
robin: A man... what man? Casey, what's going on? Is someone after you?
robin: ...There was a man. In September. In a brown coat. He said he was from the insurance, about Dad's policy. He asked about you. He had peppermints. I gave him a cup of tea.
web(7): Harrow sat in your sister's kitchen and drank her tea. In September. Before any of this. He's been in your life longer than the Tenant has.
* "If he comes back, call Detective Ines Miller, Precinct 9. Nobody else."  -> sr.warnmiller {if alive:miller}
* "If he comes back, go to the neighbors. Don't be alone with him."  -> sr.warnneighbour

# sr.warnmiller
robin: Ines Miller. Precinct 9. She's the one who rang me back. Okay. Okay. I've written it on my hand.
{do flag:sisterWarned=1; flag:sisterMiller=1}
@next sr.something2

# sr.warnneighbour
robin: Mrs. Tully. Next door. She's eighty-four and she's got a baseball bat. Okay.
{do flag:sisterWarned=1}
@next sr.something2

# sr.something2
robin: Casey. Just tell me you're coming home.
* "Saturday. If I can."  -> sr.saturday {do promise:sisterhome:Go home to Harbour Row}
* "I don't know, Rob."  -> sr.never

# sr.truth
> You tell her. You don't know why. The freezer. The light. Monday, 4:14. The old man in the coat. What you are now. The rain on you that doesn't steam.
> You expect her to hang up. You expect her to scream, or laugh, or call you sick. You expect anything except what she does, which is listen, all the way to the end, in silence, the way you listened to her.
robin: ...Okay.
robin: Okay. So. You're a vampire.
* "Yes."  -> sr.truthyes

# sr.truthyes
robin: Okay. I'm a primary school teacher. We've all got our problems.
> And then she's laughing, and then she's crying, and then she's doing both, and so are you, on Ferrier Lane, in the rain, by a payphone, and if anyone is watching they'll think it's just the rain.
robin: Can you still come to Saturday soup? Is that a thing? Can you eat soup?
* "No. But I can sit with you while you eat it."  -> sr.soup
* "I can't come in daylight, Rob. And I can't come if they're watching."  -> sr.cantcome

# sr.soup
robin: Then you're sitting with me. Saturday. After dark. I'll leave the porch light on. Don't you dare not come.
{do flag:sisterKnows=1; flag:sisterSaturday=1; promise:sisterhome:Go home to Harbour Row; comp+4:Rob knows; xp:80:Harbour Row; task:s_sister=done; flag:sisterTalked=1; lean:candour+1}
@next sr.end

# sr.cantcome
robin: Then I'll come to you. Tell me where. I'll get the train. I've got a car. I've got savings. I'll come.
* "Not yet. Not till it's safe. I'll call. I promise I'll call."  -> sr.callpromise {do promise:sistercall:Call Robin again}
* "Don't, Rob. Please. Stay by the sea."  -> sr.stay

# sr.callpromise
robin: You'll call. Okay. You'll call. Every week. Sunday. Three in the morning, if that's your time now. I'll be up. I'm always up.
{do flag:sisterKnows=1; flag:sisterSunday=1; comp+4:Rob knows; xp:80:Harbour Row; task:s_sister=done; flag:sisterTalked=1; lean:candour+1}
@next sr.end

# sr.stay
robin: Stay by the sea. Okay. I'm good at that. I've been staying by the sea for forty-one years.
{do flag:sisterKnows=1; comp+2; xp:70:Harbour Row; task:s_sister=done; flag:sisterTalked=1}
@next sr.end

# sr.end
> The pips go. Fifty cents doesn't buy long, at three in the morning, eighty miles.
robin: Casey, the money's going, I love you, I love you, don't you dare...
> Click.
> You stand by the payphone on Ferrier Lane. You put your hand flat on the steel. It's cold. You're cold. Somewhere eighty miles away, a woman is sitting on her kitchen floor with the phone in her lap, and the heating on, and you've never been warmer in your life.
@end

// --- Harrow and the sister ---
# sr.harrow
> A silence on the line. Then, quietly:
harrow: Robin. Yes. She makes very good tea. Proper tea, in a pot, with a cosy shaped like a fish.
harrow: I'd never hurt her. I want you to know that. She isn't part of this. She was just... the only person who had your photograph.
* "If you go near her again, Tom, I will find you on whatever road you run down."  -> sr.harrowthreat {do lean:mercy-1}
* "Then promise me. You promised you'd never lie on this phone."  -> sr.harrowpromise {if flag:hcDeal}

# sr.harrowthreat
harrow: Yes. I believe you would. Noted.
@next hc4.hub

# sr.harrowpromise
harrow: I promise. I'll take her file out of the system tonight. I'll put it through the shredder myself. Nobody from the program goes to Harbour Row. Ever.
harrow: That one's free. That one isn't a negotiation.
{do flag:sisterSafe=1; rel:harrow+1}
@next hc4.hub
`,'c_sister');

NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.sisterKnows&&f.sisterSaturday)o.push(['Robin Morrow','Left the porch light on on Saturday night. At twenty past nine, someone knocked. She made the leek soup. They sat at the kitchen table, one eating, one not, until four in the morning. On Sunday night they repainted the fish on the mailbox with a Sharpie, by flashlight.']);
  else if(f.sisterSunday)o.push(['Robin Morrow','Stays up every Sunday until three. The phone rings at three. It always rings at three.']);
  else if(f.sisterSaturday)o.push(['Robin Morrow','Made the leek soup on Saturday. Left the porch light on.'+(S.chapter==='end'&&(f.ending==='ash')?' Nobody came. She left it on anyway, every night, for a year.':' Somebody came.')]);
  else if(f.sisterToldDead)o.push(['Robin Morrow','Buried an empty coffin in Saltmarsh churchyard in December, next to her mother. Never once believed it. Still hasn\'t repainted the fish.']);
  else if(f.sisterHung)o.push(['Robin Morrow','Got a phone call at three in the morning on a Thursday in November from someone who didn\'t say anything. She kept the line open for an hour after they\'d gone. She knows. She just doesn\'t know what she knows.']);
  if(f.sisterWarned&&!f.sisterSafe&&!f.harrowDead&&!f.harrowWalked)o.push(['Harbour Row','A man in a brown coat knocked on the door in December. Mrs. Tully next door came out with a baseball bat. He went away.']);
  return o;});
