'use strict';
/* THE NEW LORD — more of the people on the edges, part two: the Prophet reads you, Ezra after the chimney, Ottoline and the broken promise */
NL.Script.add(String.raw`
// =====================================================================
// THE PROPHET · what he sees now
// =====================================================================
# prX.0 arc=prophet night=4,5 label="\"What do you see now, Prophet?\"" if=room:switchyard prio=1
@focus prophet
prophet: Now? Now. Hm. Give me your hand. No, the other one. That one's his.
> He holds your left hand in both of his, which are very cold and very dirty, and closes his eyes.
@gate rep:mercy>=3 ? prX.merc : prX.b

# prX.b
@gate rep:mercy<=-3 ? prX.ruth : prX.c

# prX.c
@gate rep:candour>=3 ? prX.true : prX.plain

# prX.merc
prophet: I see doors. Lots of doors. All open. People going in and out of them in the rain. Somebody's put a coffee on a counter for each one.
prophet: You're going to have a very crowded life. Everyone will come to you. You'll never be alone again. It will be exhausting.
prophet: That's not a curse. I'm just telling you. Buy more chairs.
{do comp+1}
@next prX.end

# prX.ruth
prophet: I see a big room. A beautiful room. Velvet. A chair at the top of it. You in the chair.
prophet: And nobody else in the room. Nobody at all. Just you, and the chair, and a lot of velvet, for a very long time.
prophet: You can still change it. That's the thing about seeing. It's never the thing. It's just the shape of the thing, if you keep walking the same way.
{do comp-1}
@next prX.end

# prX.true
prophet: I see you talking. On and on. To everyone. And everyone listening, because you never lie, and they don't know what to do with it.
prophet: Some of them are going to hate you for it. The ones who need lies to stand up. Be gentle with them. They're very tired.
@next prX.end

# prX.plain
prophet: I see... fog. Hm. Fog. You haven't decided yet. You're still deciding. That's good. That's very good. Most people decided years ago and they're just walking now.
@next prX.end

# prX.end
prophet: Now give me something warm. Not blood. A coat, a cup, a word. Seeing makes me cold.
* Give him your coat.  -> prX.coat {if has:greatcoat} {do lean:mercy+1}
* Tell him something kind.  -> prX.word
* "I've got nothing, Prophet."  -> prX.nothing

# prX.coat
> You give him the Sheriff's coat. He looks at it, and at you, and wraps it round himself with a sigh like a kettle coming off the boil.
prophet: Absalom's. Ha. He never once let me touch it. Thank you. I'll give it back on Saturday. If you're there. If you're not, I'll keep it. It's very warm.
> You stand on Platform 0 in your shirtsleeves. It's colder than you'd think, being dead.
{do take:greatcoat; flag:prophetCoat=1; rel:prophet+2}
@end

# prX.word
> You tell him he's not mad. You tell him people listen to him more than they let on. You tell him the trains are coming back.
prophet: The trains. You see them too? You see the trains?
> He laughs, delighted, like a child.
{do rel:prophet+1; comp+1}
@end

# prX.nothing
prophet: Nothing. Yes. That's the most honest thing anyone's given me in years. Thank you for the nothing.
@end

// =====================================================================
// EZRA · after the chimney
// =====================================================================
# ezX.0 arc=ezra night=4,5 label="\"Ezra. How are you?\"" if=flag:ezraFree&room:apt prio=2
@focus ezra
> He's sitting in the corner of 404, where he always sits now, with his arms round his knees, watching the window. Mrs. Okafor has put a blanket round him. He hasn't moved it.
ezra: How am I. Nobody's asked that since 2016. I've been asking it in the chimney. To myself. Every night. "How are you, Ezra?" "Hungry." "How are you, Ezra?" "Hungry."
ezra: I'm... I'm not hungry. That's new. I don't know what I am if I'm not hungry.
* "You're free."  -> ezX.free
* "Tell me what happened in 2016."  -> ezX.2016
* "Do you want to stay here? With Mrs. Okafor?"  -> ezX.stay

# ezX.free
ezra: Free. In a flat. With a woman who leaves out two cups. Watching a window.
ezra: ...Yes. I suppose that's what free looks like. It's smaller than I thought. That's all right. I've been somewhere very small. This is huge.
{do comp+1}
@end

# ezX.2016
ezra: The men with the light. They had a list. A doctor gave it to them. Kindred and the mortals who fed them. I was on it. I ran.
ezra: I ran into a chimney because it was the only dark place in the building and I was too frightened to come out. Then they bricked it up. Renovations. They didn't know I was there. Nobody knew I was there.
ezra: Nine years. The woman who lived here before Mrs. Okafor used to sing in the kitchen. I learned every song. I can sing you all of them. Shall I?
* "Sing one."  -> ezX.sing
* "Not now, Ezra."  -> ezX.notnow

# ezX.sing
> He sings. A song from an old musical, very quietly, in a voice like dust. He knows every word. He sings it the way the woman sang it, with her pauses, with the bit where she always forgot the second verse and hummed.
> In the kitchen, Mrs. Okafor stops washing up and listens.
{do comp+2; rel:okafor+1}
@end

# ezX.notnow
ezra: Not now. Later. There's always later now. I keep forgetting.
@end

# ezX.stay
ezra: Stay. She hasn't asked me to go. She hasn't asked anything. She brings me a blanket and talks about her daughter and the price of gas.
ezra: I think... I think I'd like to. If she'll have me. I can't eat her food. I can listen to her talk. I'm very good at listening. I had nine years of practice.
{do flag:ezraStays=1; rel:okafor+1}
@end

// =====================================================================
// OTTOLINE · the promise of 1802
// =====================================================================
# otX.0 arc=ottoline night=3,4,5 label="\"Ottoline. You came back to Port Vellum.\"" if=room:apt prio=1
@focus ottoline
ottoline: I did. For my sister. Her funeral. Saturday last. She was two hundred and nine and she walked into the sea at Ostend. She left a note: "Bury me in Port Vellum, where Ottie can't come." She thought it was funny.
ottoline: I promised in 1802 never to return. An Alchemist's word is a physical law. The moment my foot touched the platform at Central, I felt it break. Like a bone.
* "What happens when an Alchemist breaks her word?"  -> otX.break
* "Why come, if it costs you?"  -> otX.why

# otX.break
ottoline: Depends on the word. Small ones, a fever. Big ones, a curse. A promise to a city... I don't know. Nobody's ever been stupid enough to break one.
ottoline: I've been bleeding from my gums since Monday. My reflection's started to lag a little. When I turn my head, it turns a second later. It's very disconcerting.
web(6): A broken Alchemist promise, eating her from the inside. There might be a way to mend it. A new contract to replace the old. Someone would have to agree to it.
@next otX.hub

# otX.why
ottoline: Because she was my sister. Because I'd rather bleed than be the one who didn't come.
ottoline: Isn't that what you'd do?
@next otX.hub

# otX.hub
* "Can a new promise mend it? Make one to me."  -> otX.mend
* "Is there anything I can do?"  -> otX.do
* "Go home, Ottoline. Before it gets worse."  -> otX.home

# otX.mend
> She looks at you sharply. The green in her eyes flares.
ottoline: A new promise. To replace the broken one. A trade. The city takes the old word back if it gets a new one of equal weight.
ottoline: It would have to be big. And it would have to bind me. Forever. And you'd be the one I made it to.
* "Promise to protect the Ward. Whenever it needs you."  -> otX.ward
* "Promise to come back every year. For her."  -> otX.sister
* "Promise me nothing. Just go home and get well."  -> otX.home

# otX.ward
ottoline: Protect the Ward. Whenever it needs me. From Ostend. For as long as I last.
ottoline: ...That's a very big promise. That's my whole life.
> She takes a pin from her hair. She pricks her thumb. A bead of blood, very dark, almost green.
ottoline: I, Ottoline Vass, promise to the Marrow Ward, in the presence of this witness: whenever the Ward calls, I come.
> Something in the air goes *click*, like a lock. She takes a breath, a real one. The color comes back into her lips.
ottoline: There. Oh. There. It's gone. The old one's gone. Oh, that's... I can feel my teeth again.
{do flag:ottolineWard=1; rel:ottoline+3; xp:40:A new promise}
@end

# otX.sister
ottoline: Every year. For her. On the day.
> She pricks her thumb. Dark green-black blood.
ottoline: I, Ottoline Vass, promise to return to Port Vellum every year on the anniversary of my sister's death, and to stand at her grave, for as long as I last.
> Click. Her shoulders drop. She breathes.
ottoline: A promise to come back, instead of a promise to stay away. That's... that's better. That's so much better. Why didn't I think of it?
{do flag:ottolineSister=1; rel:ottoline+3; xp:40:A new promise}
@end

# otX.do
ottoline: You've done it. You asked. Nobody else in this city knows I'm here except Mrs. Okafor, who thinks I'm a lodger with a skin complaint.
@next otX.hub

# otX.home
ottoline: Home. Ostend. A flat over a chip shop. Yes. Maybe it'll heal if I leave. Maybe not.
ottoline: Thank you for caring either way. Alchemists don't usually get that. We get "what's it going to cost me".
@end
`,'c_more5');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.ottolineWard)o.push(['Ottoline Vass','Lives over a chip shop in Ostend. Twice since November, when the Ward was in trouble, the air in the right room went click, and a copper-haired woman in a bathrobe stepped out of nowhere and fixed it.']);
  else if(f.ottolineSister)o.push(['Ottoline Vass','Comes back to Port Vellum once a year now, on the day, and stands at her sister\'s grave in the rain, and laughs at the note, and goes home.']);
  if(f.ezraStays)o.push(['Ezra','Lives in the corner of 404 under a blanket, watching the window. Mrs. Okafor talks. He listens. On Sundays he sings her the songs he learned in the chimney, and she says they\'re terrible, and asks for another.']);
  if(f.prophetCoat)o.push(['The Prophet','Wears the Sheriff\'s coat on Platform 0. Nobody dares ask for it back. He says he sees trains in the lining.']);
  return o;});
