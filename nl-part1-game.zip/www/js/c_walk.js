'use strict';
/* THE NEW LORD — "The Walk": he asks you to take him round the Ward, one more time, to the places he remembers. You can say no. */
(function(){NL.TASKS.s_walk={n:'The Walk',xp:60,cat:'side'};})();
NL.Script.add(String.raw`
# wa.0 arc=tenant night=3,4 label="He wants to go for a walk." if=sync>=20&!flag:walkDone prio=1
@focus tenant
tenant: I want to ask you something, and you can say no. You've said no to me before. I respected it. Mostly.
tenant: I'd like to go for a walk. Round the Ward. To the places I remember. I'm in your body; I can't go anywhere you don't take me. I'd like you to take me. Once. Before Friday.
* "All right. Where first?"  -> wa.start
* "Not tonight."  -> wa.no

# wa.no
tenant: Not tonight. Of course. Another night. There may not be another night. That's all right too.
@end

# wa.start
{do task:s_walk; note:s_walk|The Tenant asked you to walk him round the Ward to the places he remembers.}
tenant: The Courthouse. Assize Street. The side door. Please.
@next wa.court

# wa.court
> Assize Street at three in the morning. The Courthouse is dark, a big Victorian pile of soot-black stone with columns and a clock that stopped in 1977. The side door, down three steps, under a lamp.
tenant: Here. This door. December 23rd, 1924. I came in through here to read a file I wasn't supposed to read and broke a drawer, and a typist with ink on her fingers told me I'd have to sign for it.
tenant: I came back to this door every night for two years. Not to read files. To walk her to the tram.
* "Do you want to go in?"  -> wa.court1
* Put your hand on the door.  -> wa.court2

# wa.court1
tenant: No. No. She's not in there. Only the drawer. They'll have fixed the drawer.
@next wa.court3

# wa.court2
> You put your hand flat on the door. Cold iron. Paint over paint over paint. Somewhere under all of it, a hundred years ago, she leaned against it in the snow and laughed at his car.
tenant: ...Thank you.
{do sync+1}
@next wa.court3

# wa.court3
tenant: Next. The Heights. There's a bank on Cedar Row. It used to be a café.
@next wa.cafe

# wa.cafe
> Cedar Row on the Heights. A bank, all glass and brushed steel, with a cash machine glowing blue in the wall and a man asleep in a sleeping bag under it.
tenant: There. The cash machine. That's where our table was. By the window. She had a currant bun and I had a cup of tea I didn't drink and we talked until four.
tenant: Now there's a man asleep where she sat.
* Leave the man some money.  -> wa.cafe1 {if cash>=10}
* "It's still the same place."  -> wa.cafe2

# wa.cafe1
> You fold ten dollars into the top of his sleeping bag without waking him.
tenant: She'd have bought him a bun. You've done better. She'd have liked you very much. She'd have told you off for not drinking your tea.
{do cash-10; comp+1; lean:mercy+1}
@next wa.next1

# wa.cafe2
tenant: It is. It is. The window's the same window. The light's different. That's all.
@next wa.next1

# wa.next1
tenant: The docks. Pier Nine. I know. I know. Just to the end of it.
@next wa.pier

# wa.pier
> Pier Nine, the end of it, in the wind. The container cranes like herons. The black sea.
tenant: 1977. You know what happened here. I won't tell it again.
tenant: I just want to stand where he stood. Rask. On the bollard. Looking at the water. I never once stood where he stood. I stood behind him with the Prince's order in my pocket.
* Sit on the bollard.  -> wa.pier1
* "Valko should be here."  -> wa.pier2 {if flag:valkoAlly&!flag:valkoDead}

# wa.pier1
> You sit on the bollard. You look at the black sea. The wind comes off it full of salt and diesel and a long way away.
tenant: Oh. Oh, I see. You can see the lights on the far shore from here. All the little houses. He wasn't looking at the water. He was looking at the houses. All those people with somewhere to go home to.
{do sync+2; comp+1}
@next wa.next2

# wa.pier2
> Valko is already there. Of course he is. He's sitting on the next bollard along, very still, watching the water. He doesn't look round.
valko: I come here every night. Did you know? Every night since 1977. I never told anyone.
tenant: (through your mouth, quietly) Nor did I.
> The three of you sit there for a while. Nobody says anything else. It's the best conversation you've ever had.
{do sync+2; rel:valko+2; comp+2}
@next wa.next2

# wa.next2
tenant: Vine Street. The bus shelter. There used to be a gallows there. I watched a man hanged there in 1888, the week I came to the city. I thought: what a barbaric place. I stayed a hundred and thirty-seven years.
@next wa.vine

# wa.vine
> The bus shelter on Vine Street. A timetable. An ad for car insurance. On the roof, a striped deckchair, empty. {if !flag:mqOldPrince&!mem:oldkin.lyon}
> The bus shelter on Vine Street. On the roof, in a striped deckchair, wrapped in tartan: the old Prince of Lyon, watching the buses. He raises a hand to you without looking down. {if flag:mqOldPrince|mem:oldkin.lyon}
tenant: He's still there. The old Prince. I've walked past him a thousand times and never once looked up.
* Look up. Raise a hand.  -> wa.vine1 {if flag:mqOldPrince|mem:oldkin.lyon}
* Keep walking.  -> wa.next3

# wa.vine1
> You raise a hand. On the roof of the bus shelter, the old Prince of Lyon raises his. Two Sheriffs, one old and one inside you, and a Prince who walked away, saying nothing to each other at three in the morning.
{do sync+1}
@next wa.next3

# wa.next3
tenant: Last one. St. Jude's. The chapel. Please.
@next wa.chapel

# wa.chapel
> The chapel at St. Jude's. Eight pews. The bad electric candle. The child's drawing of a sun.
> Father Dominic is in the front pew with a crossword. He looks up. He sees you. He sees, possibly, something in the way you're standing, in the way you look at the back pew. {if !flag:dominicDead}
dominic: Ah. Both of you, tonight. Sit where you like. {if !flag:dominicDead}
> The chapel is empty. Somebody has folded a square of sandwich foil neatly and left it on the front pew. {if flag:dominicDead}
tenant: The back. Please. The back pew. Just once more.
* Sit in the back pew.  -> wa.back
* Sit in the front pew.  -> wa.front

# wa.back
> You sit in the back pew. It's hard and narrow and it creaks. He sat here nineteen Decembers. You can feel the shape of him in it, almost: the way he'd have sat, very straight, glasses on, not praying.
tenant: There. That's where I was. That's the whole of my life, really: the back of a room, watching a door.
tenant: Thank you. You can take me anywhere you like now. I've seen it.
{do flag:walkDone=1; task:s_walk=done; xp:60:The Walk; sync+2}
@end

# wa.front
> You sit in the front pew. He doesn't say anything for a long time.
tenant: The front. Of course. You'd take me to the front.
tenant: ...It's very bright up here. It's only an electric candle. It's very bright.
tenant: Thank you, child. Thank you. I've seen it from the front. Nobody ever let me. I never let myself.
{do flag:walkDone=1; flag:walkFront=1; task:s_walk=done; xp:60:The Walk; sync+3; comp+2}
@end
`,'c_walk');
