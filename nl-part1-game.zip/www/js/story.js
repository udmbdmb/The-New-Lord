'use strict';
/* THE NEW LORD — Prologue: "The Sun-Bleached Crime Scene" */
(function(){
const NL=window.NL;const A=NL.Audio;
const N={};const ENC={};
const L=(s,t,o)=>Object.assign({s,t},o||{});
const T=(t,o)=>Object.assign({t},o||{});
const O=(t,go,o)=>Object.assign({t,go},o||{});
const C=(sk,dc,t,ok,no,o)=>Object.assign({t,ck:{sk,dc,id:(o&&o.id)||('ck_'+sk+'_'+t.length),red:!!(o&&o.red),mod:o&&o.mod,noPush:o&&o.noPush},ok,no},o||{});
const F=S=>S.flags;
const hungry=S=>S.vitae<4;
const tedUnresolved=S=>!['forgot','ally','thrall','paid'].includes(S.flags.tedState);

/* ======================= COLD OPEN ======================= */
N['cold.0']={lines:[T('Darkness. Not the restful kind. The kind with a hum in it.'),
  L('sundial','Nine o\'clock. Post meridiem. You are awake. That is the first problem.'),
  L('parasite','There is a heartbeat in here. Not yours; yours stopped some time ago. This one is fast. A hundred and thirty. A hundred and forty. Somebody nearby is very, very frightened.'),
  L('tenant','Get. UP. You are lying in my remains.')],next:'cold.hub'};
N['cold.hub']={opts:[O('"Who said that?"','cold.who',{once:true}),O('"Whose heartbeat is that?"','cold.heart',{once:true}),
  O('"Your remains?"','cold.remains',{once:true,if:S=>S.seen['cold.who']}),
  O('Go back to sleep.',S=>S.flags.slept?'cold.sleep2':'cold.sleep1'),O('Open your eyes.','cold.eyes')]};
N['cold.who']={lines:[L('tenant','Said? I didn\'t *say* anything. I was silenced, quite thoroughly, thank you. Now I merely... reside.'),
  L('pedigree','The accent is three hundred years old and has never once apologized for anything.',{pass:6}),
  L('web','A voice that knows your body better than you do. Hold that thought. Hold it at arm\'s length.',{pass:8}),
  L('tenant','You may call me the Tenant. I came with the property.',{do:(S,G)=>{S.flags.tenantNamed=1;G.meet('tenant');G.fact('tenant','intro');G.offer('tenant');}})],next:'cold.hub'};
N['cold.heart']={lines:[L('parasite','Male. Mid-twenties. Iron-rich: red meat every day and cheap lager on top. There\'s adrenaline in it like ice in a drink. Delicious. Clinically. *Clinically* delicious.'),
  L('pulse','He\'s terrified. Of you, probably.',{pass:8}),L('frenzy','GOOD.')],next:'cold.hub'};
N['cold.remains']={lines:[L('tenant','My remains. My *ashes*. You have your elbow in what used to be my ribcage, and I would like you to remove it.'),
  L('autopsy','Ash doesn\'t have ribs. Point of order.',{pass:8}),L('tenant','I don\'t have a *body* either. Allow me some poetry.')],next:'cold.hub'};
N['cold.sleep1']={lines:[L('sundial','You could. The hum is very soothing. Dawn is at nine minutes past five, and the sun does not care how tired you are.'),
  L('rigor','But it *is* comfortable down here. Cold. Still. Like a drawer.',{pass:6,do:S=>S.flags.slept=1})],next:'cold.hub'};
N['cold.sleep2']={lines:[T('You let the hum take you. It is very easy. It is the easiest thing you have ever done.')],cs:async G=>{await G.wait(.8);G.dlgHide();G.gameOver('sleep');},end:true};
N['cold.eyes']={lines:[T('Your eyelids are stuck. Frost. You blink it loose, and the world comes back in pieces: steel, light, meat.')],cs:async G=>{G.dlgHide();await STORY.wake(G);},end:true};

/* ======================= FREEZER ======================= */
N['ash.0']={lines:[
  T('A heap of grey ash the size of a sleeping dog, still faintly warm, which is wrong in a freezer. Buttons in it. Half a pair of spectacles. A wide-brimmed hat beside it, lying at an angle that looks almost deliberate.',{if:S=>S.seen['ash.0']===1}),
  T('The ash. Still warm. Still him.',{if:S=>S.seen['ash.0']>1}),
  L('autopsy','Fire leaves bone. This left nothing but powder, the way very old things go when they stop pretending to be a body.',{pass:8,if:S=>S.seen['ash.0']===1}),
  L('tenant','Do *not* touch me.',{if:S=>S.seen['ash.0']===1}),
  L('frenzy','There might still be some in there. Lick the floor.',{if:hungry})],next:'ash.hub'};
N['ash.hub']={opts:[
  C('autopsy',8,'Examine the ash properly.','ash.autOk','ash.autNo',{id:'ash_aut'}),
  C('osmosis',10,'Put your palm flat on it, and *listen*.','ash.osmOk','ash.osmNo',{id:'ash_osm'}),
  O('Sift through it with your fingers.','ash.search',{if:S=>!S.flags.ashSearched}),
  O('"Who were you?"','ash.who',{once:true}),
  O('"Who killed you?"','ash.killed',{once:true,if:S=>S.seen['ash.who']}),
  O('Deal with the remains.','ash.dispose',{if:S=>S.seen['ash.who']&&!S.flags.ashGone}),
  O('Leave him be.',null,{end:true,leave:true})]};
N['ash.autOk']={lines:[L('autopsy','A scorch ring at the edge, but no fire. The frost on the floor is undisturbed except where *you* were lying. No struggle.'),
  L('autopsy','The pile is shaped like a kneeling man. He went down on his knees before he went to powder.'),
  L('autopsy','And the hat: a small round hole through the brim, clean as a punch. Silver-tipped bolt, probably. It missed.'),
  L('web','A hole from a weapon that missed, and no weapon anywhere in the room. Someone else was in here, and they took their crossbow home.',{pass:10,do:S=>S.flags.knowsBolt=1}),
  T(null,{do:(S,G)=>{G.offer('coroner');G.xp(10,'Forensics');}})],next:'ash.hub'};
N['ash.autNo']={lines:[T('You stir the ash with one finger. It gets under your nail. It was a man. It was a man yesterday, or this morning.'),
  L('pulse','You are wiping a person off your hand and onto your trousers.',{do:(S,G)=>{if(!S.th.done.includes('coroner'))G.comp(-1,'You touched the remains');}})],next:'ash.hub'};
N['ash.osmOk']={lines:[L('osmosis','The ash is cool under your palm, and then it isn\'t. It\'s—',{fx:['flash','sfx:sting']}),
  T('*— a freezer door swinging shut. A woman laughing, low and amused: "You\'re late, Absalom." Very far away, a shop bell.*'),
  T('*— an oxblood ledger open in gloved hands. Columns of numbers. A finger stopping on a line.*'),
  T('*— teeth. Your teeth. His throat. And the strangest thing of all: he lets you.*'),
  L('osmosis','He didn\'t fight you. At the end, he *offered*.'),
  L('tenant','...I don\'t remember that. I would remember that. Wouldn\'t I?',{do:(S,G)=>{S.flags.memLaugh=1;G.meet('tenant');G.fact('tenant','noMemory');G.xp(10,'Blood memory');}})],next:'ash.hub'};
N['ash.osmNo']={lines:[T('You press your palm into the ash and get a red, roaring nothing. Static. Hunger. Somebody else\'s scream in your own throat.',{fx:['hurt:1','shake:.6']}),
  T(null,{do:(S,G)=>G.comp(-1,'Bad resonance')})],next:'ash.hub'};
N['ash.search']={lines:[T('You sift. Buttons of horn and brass. A collar stud. Two lenses fused together. And then three cool, solid things that did not burn.'),
  T('A handcuff key, small and silver-plated.',{do:(S,G)=>G.give('cuffkey')}),
  T('A heavy gold signet ring.',{do:(S,G)=>G.give('signet')}),
  T('A silver pocket watch, its hands stopped at 4:51.',{do:(S,G)=>{G.give('watch');G.offer('fourfiftyone');}}),
  L('pulse','Your hands are grey to the wrist. You are going to need a sink.',{do:(S,G)=>{S.flags.ashSearched=1;S.flags.dirty=1;if(!S.th.done.includes('coroner'))G.comp(-1,'You went through a dead man\'s pockets');}}),
  L('tenant','Those are *mine*.'),L('gutter','They\'re evidence now. Or currency. Mostly currency.',{pass:8})],next:'ash.hub'};
N['ash.who']={lines:[L('tenant','Absalom Vane. Sheriff of the Marrow Ward. Keeper of the Ninth Ward Peace. Three-time fencing champion of the Court of Port Vellum. *Former.* Former all of those, it would seem.',{do:(S,G)=>{S.flags.tenantNamed=1;S.flags.tenantSeen=1;G.meet('tenant');G.fact('tenant','name');}}),
  L('pedigree','A Sheriff. Of the Court. You drank a *policeman*.',{pass:6}),
  L('tenant','You drank me, you graceless thing. All of me. The blood, the years, the soul, if you want to be medieval about it, and I do. That is why I am in here with you, and why your head is so crowded.'),
  L('tenant','The Court has a word for what you did. It is a short word, and it is usually followed by a stake.'),
  L('web','So nobody can know. Not tonight. Not until you know what happened in here.',{pass:8,do:(S,G)=>{G.offer('tenant');G.task('remains');}})],next:'ash.hub'};
N['ash.killed']={lines:[L('tenant','You did! ...Probably. My memory is somewhat foggy towards the end, which I am told is common when one is being drunk.'),
  L('tenant','But I remember a sound. The latch of that door, closing from the *outside*. A sharp little click. Somebody wanted us both in here when the sun came up.'),
  L('sundial','There\'s no sun in a freezer.'),
  L('tenant','There is no sun in a freezer *yet*. Somebody may have been planning to open the door at dawn and let it in.'),
  L('rigor','Two vampires in a box. Open the lid at sunrise. Very clean.',{pass:8,do:(S,G)=>G.fact('tenant','noMemory')})],next:'ash.hub'};
N['ash.dispose']={lines:[T('The Sheriff of the Marrow Ward, a hat, and roughly two kilograms of very fine powder. Options present themselves.'),
  L('abattoir','There\'s a grinder in the back. Casings. Fennel. Nobody checks the bratwurst.',{pass:8,do:(S,G)=>G.offer('bratwurst')}),
  L('tenant','Over. My. Dead. Body. ...That came out wrong.')],next:'ash.dhub'};
N['ash.dhub']={opts:[O('Sweep him into the white bucket by the boxes.','ash.bucket'),
  O('Burn what\'s left with the brass lighter. Leave nothing.','ash.burn',{item:'lighter'}),
  C('abattoir',10,'Plan the bratwurst. Thoroughly.','ash.brat','ash.bratNo',{id:'ash_brat'}),
  O('Leave him where he is, for now.','ash.hub')]};
N['ash.bucket']={lines:[T('You sweep the Sheriff into a white plastic bucket with the edge of a flattened carton. It takes longer than you\'d like. Some of him gets into your shoes.',{fx:'sfx:swoosh'}),
  L('tenant','I am in a bucket. Three hundred years, and I am in a bucket that says PORK STOCK.'),
  L('gutter','It\'s the most accurately labelled thing in this freezer.',{do:(S,G)=>{S.flags.ashGone='bucket';G.task('remains','done');G.rebuildRoom();}})],next:'ash.hub'};
N['ash.burn']={lines:[T('You flick the lighter. The flame is the size of a fingernail.',{fx:'sfx:zippo'}),
  L('sundial','FIRE. FIRE. That is FIRE, in your HAND, why is it in your HAND—',{fx:'shake:.8'}),
  T('The ash takes the flame strangely, like paper soaked in brandy. It burns blue, then white, then nothing. When it\'s done there is a dark oval on the concrete and a smell like an empty church.',{do:(S,G)=>{G.comp(-2,'You held fire');S.flags.ashGone='burnt';G.task('remains','done');G.rebuildRoom();}}),
  L('tenant','...Well. That\'s *that*, then.'),
  L('pulse','He said it like he meant something else.',{pass:10})],next:'ash.hub'};
N['ash.brat']={lines:[L('abattoir','Two kilograms of ash, cut with rusk and fennel at one part in eight. Forty sausages. Kowalski\'s moves sixty a week. By Friday he\'d be... distributed.'),
  L('tenant','I will haunt you. I will haunt you from inside every sausage in Port Vellum.'),
  L('nostalgia','You used to love bratwurst. At the street fair. With the sharp mustard.',{pass:8}),
  T('You don\'t do it. Not tonight. But you have thought it through, from first cut to shop window, and you can\'t un-think it.',{do:(S,G)=>{G.offer('bratwurst');S.flags.bratPlan=1;}})],next:'ash.dhub'};
N['ash.bratNo']={lines:[L('abattoir','Ash doesn\'t bind. You\'d need a binder. Egg? Rusk? You are a vampire in a freezer doing sausage arithmetic.'),L('tenant','*Thank* you.')],next:'ash.dhub'};

N['coat.0']={lines:[T('A long charcoal greatcoat lies crumpled beside the ash, sleeves flung out as if someone had climbed out of it in a hurry. Which, in a sense, he did.'),
  L('tenant','That coat was cut in Vienna in 1922 by a man who wept when he finished it. Do *not* get ash on the lining.'),
  L('echo','Something heavy in the inside pocket. Two somethings.',{pass:8})],opts:[O('Take the coat.','coat.take'),O('Leave it.',null,{end:true,leave:true})]};
N['coat.take']={lines:[T('It\'s heavy, and warm the way the ash is warm, and it smells of cedar, cigars and something burnt.',{do:(S,G)=>{G.give('greatcoat');S.flags.coatTaken=1;G.rebuildRoom();}}),
  T('In the inside pocket: a battered flip phone with twelve missed calls, and a brass lighter engraved A.V.',{do:(S,G)=>{G.give('burner');G.give('lighter');}}),
  L('tenant','Wear it, then. It\'s cold. Well, *you* aren\'t. But it is *cold*.'),
  L('stagecraft','A dead man\'s coat over a dead man. It\'ll hide the state of your shirt. It won\'t hide the ash.',{do:(S,G)=>G.toast('task','Open the bag icon to wear it','Inventory')})],end:true};

const TASTES=['Tastes of: a night nurse on a double shift. Coffee, nicotine, quiet despair.','Tastes of: a marathon runner. Iron, salt, smugness.','Tastes of: a student who donated for the free pizza. Pepperoni. Optimism.','Tastes of: a retired priest. Communion wine, and a secret he never told.','Tastes of: a man who cried at a wedding. Champagne. Relief.'];
N['shelf.0']={lines:[
  T('Steel shelving, furred with frost. Rows of vacuum-sealed bags, dark red and heavy. The printed labels say PORK STOCK · 1 PINT. The handwriting under the labels says B-NEG. O-POS. A-POS.',{if:S=>S.seen['shelf.0']===1}),
  L('parasite','That is not pork.',{pass:6,if:S=>S.seen['shelf.0']===1}),
  L('gutter','A blood bank wearing a butcher\'s apron. Somebody\'s moving product. No hospital barcodes, so not hospital overstock. Not *officially*.',{pass:8,if:S=>S.seen['shelf.0']===1}),
  L('web','A dead Sheriff in a blood smuggler\'s freezer. Either he was here to shut it down, or he was a customer.',{pass:10,if:S=>S.seen['shelf.0']===1}),
  L('frenzy','Bite. Through. The plastic.',{if:hungry})],next:'shelf.hub'};
N['shelf.hub']={opts:[
  O('Tear a bag open and drink it here.','shelf.drink',{if:S=>(S.flags.bagsTaken||0)<5}),
  O('Take a bag for later.','shelf.hub',{if:S=>(S.flags.bagsTaken||0)<5,do:(S,G)=>{S.flags.bagsTaken=(S.flags.bagsTaken||0)+1;G.give('bloodbag');}}),
  O('Take the meat thermometer hanging off the end of the rack.','shelf.thermo',{if:S=>!S.flags.thermoTaken}),
  C('web',10,'Read the handwriting on the cartons.','shelf.webOk','shelf.webNo',{id:'shelf_web'}),
  O('Step away from the shelf.',null,{end:true,leave:true})]};
N['shelf.drink']={lines:[T('You tear the corner with your teeth. Cold, thick, sweet-salt. It goes down like something you have been waiting for your whole life, which, technically, you have.',{do:(S,G)=>{S.flags.bagsTaken=(S.flags.bagsTaken||0)+1;S.flags.drankBag=(S.flags.drankBag||0)+1;G.feed(3,STORY.bagRes(S),'blood bag');}}),
  L('parasite',S=>TASTES[(S.flags.drankBag-1)%TASTES.length]),
  L('pulse','Somebody gave this in a clinic, with a cookie afterwards. They thought it would save a life.',{pass:8}),
  L('frenzy','It did.',{pass:6})],next:'shelf.hub'};
N['shelf.thermo']={lines:[T('A steel probe thermometer: a long thin spike with a dial on the end. Margo\'s, probably. It goes in a pocket.',{do:(S,G)=>{G.give('thermometer');S.flags.thermoTaken=1;G.rebuildRoom();}}),
  L('echo','Long. Thin. Exactly the shape of a hole where a release knob used to be.',{if:S=>S.flags.knowsLatch})],next:'shelf.hub'};
N['shelf.webOk']={lines:[L('web','Same hand on every bag, in small capitals. And on the side of the carton above, a delivery schedule in that same hand: TUES · ST. ADA\'S, BACK DOOR. THURS · THE GILDED HOUSE.'),
  L('web','In from a hospital on Tuesdays, out to a club on Thursdays. Initials on the carton flap: M.B.'),
  L('pedigree','The Gilded Court is a Court establishment. Velvet ropes. A waiting list for the waiting list.',{pass:10,do:(S,G)=>{G.meet('margo');G.fact('margo','trade');}})],next:'shelf.hub'};
N['shelf.webNo']={lines:[L('web','Letters. Numbers. Frost. Your eyes slide right off them. It\'s been a long day, and you were dead for most of it.')],next:'shelf.hub'};

N['pig.0']={lines:[T('Half a pig hangs from a hook, frosted like a wedding cake.'),
  L('nostalgia','Christmas. Your aunt\'s ham, pineapple rings and cloves. You were nine. You wanted a bicycle. You got socks.',{pass:6,if:S=>S.seen['pig.0']===1}),
  L('abattoir','A clean cut along the spine. Professional. Margo would have made a good surgeon. Or a good murderer. The skill sets overlap more than people like to think.',{pass:8,if:S=>S.seen['pig.0']===1}),
  L('frenzy','It\'s cold, it\'s dead, pig blood is decaf. ...We\'d still drink it.',{if:hungry})],
  opts:[O('Drink from the pig.','pig.drink',{once:true}),O('Punch the pig.','pig.punch',{once:true}),O('Leave it hanging.',null,{end:true,leave:true})]};
N['pig.drink']={lines:[T('You put your mouth to a frozen pig and suck. A trickle, slow as syrup. You get maybe a mouthful.',{do:(S,G)=>G.vitae(1)}),
  L('nostalgia','Somewhere, your mother is crying and doesn\'t know why.',{do:(S,G)=>{G.comp(-1,'You drank from a pig');G.offer('meat');}}),
  L('parasite','Tastes of: pig. A truck. Disappointment, mostly yours.')],next:'pig.0'};
N['pig.punch']={lines:[T('You punch the pig. It swings away and swings back. You punch it again.',{fx:['sfx:knock','shake:.4']}),
  L('frenzy','AGAIN.'),
  T('You punch it eleven more times. It doesn\'t help with anything. It does help, a little, with everything.',{do:(S,G)=>G.comp(1,'Frenzy, briefly satisfied')}),
  L('rigor','Your knuckles should be split. They aren\'t. They\'re not even pink.',{pass:8})],next:'pig.0'};

N['boxes.0']={lines:[T('Cardboard boxes. PORK STOCK · THIS SIDE UP. One has been opened and resealed with a different brand of tape.'),
  L('echo','Fresh tape. Inside, packed in dry ice: more bags, and a receipt book with the top sheet torn out.',{pass:10}),
  L('gutter','Somebody was counting the stock. Or skimming it.',{pass:8})],end:true};
N['bulb.0']={lines:[T('A bare bulb in a wire cage, swaying very slightly, though there is no draught.'),
  L('sundial','It isn\'t the sun. You know it isn\'t the sun. You keep checking anyway.'),
  L('nostalgia','Your grandmother\'s cellar. Jars of plums. A bulb exactly like this one.',{pass:8})],end:true};

/* ----- Leo, hanging ----- */
N['leo.0']={enter:(S,G)=>{G.focus(['you','leo'],.7);G.look('leo','you');G.look('you','leo');},
  lines:[T('A young man in a bloody apron, his wrists cuffed around the shank of a meat hook. His toes just about reach the floor. There are two neat holes in the side of his neck, and he is trying very hard not to look at you.'),
  L('leo','Okay. Okay okay okay. Hi. Hello. Please don\'t — I have a sister. That\'s not a bit. I don\'t have any material about her.'),
  L('parasite','He\'s down a pint and a half. Maybe two. His pulse is a hummingbird in a shoebox.',{pass:6}),
  L('pulse','He isn\'t only scared of you. He keeps glancing at the door, as if he\'s waiting for someone else to come back through it.',{pass:8})],
  next:S=>(S.vitae<4&&!S.flags.beastDone)?'leo.beast':'leo.hub'};
N['leo.again']={enter:(S,G)=>{G.focus(['you','leo'],.7);G.look('leo','you');},lines:[L('leo',S=>S.flags.bitLeo?'Oh. You again. Hi. Please stay at least one arm\'s length away. One of *my* arms. Which I can\'t feel.':'Still here. Still hanging. Still a hundred percent available to be rescued.')],
  next:S=>(S.vitae<4&&!S.flags.beastDone)?'leo.beast':'leo.hub'};
N['leo.beast']={lines:[L('frenzy','Two holes already. Somebody opened him up for you. It would be *rude* not to.'),T('The room tilts. His heartbeat is the loudest thing in it.',{fx:['sfx:sting','shake:.6']})],enc:'beast',win:'leo.beastWin',lose:'leo.beastLose'};
N['leo.beastWin']={lines:[L('leo','— and my mom makes this lasagna, right, with boiled eggs in it, which sounds disgusting, and *is*, but — are you okay? You went really still.'),
  L('pulse','He\'s been talking the whole time. He talked you down without knowing he was doing it.'),
  L('leo','You stopped. Whatever you were about to do. Thanks for stopping.',{do:(S,G)=>{S.flags.beastDone=1;G.rel('leo',1);G.meet('leo');}})],next:'leo.hub'};
N['leo.beastLose']={lines:[T('You don\'t remember crossing the floor. You remember his collar under your hand, the heat of him, the taste of copper and lager and terror, and his voice, very small, saying *please*.',{fx:['flash','sfx:drink']}),
  L('pulse','Stop. STOP.'),
  T('You stop. It takes everything you have. He sags on the hook, grey-lipped, still breathing. Just.',{do:(S,G)=>{G.feed(3,'melancholic',"Leo's fear");if(!S.th.done.includes('meat'))G.comp(-2,'You fed on him');G.meet('leo');G.rel('leo',-2);S.flags.bitLeo=1;S.flags.beastDone=1;G.offer('meat');}}),
  L('leo','...ow.')],next:'leo.hub'};
N['leo.hub']={opts:[
  O(S=>S.flags.bitLeo?'"I won\'t hurt you again."':'"I\'m not going to hurt you."','leo.calm',{once:true}),
  O('"What\'s your name?"','leo.name',{once:true}),
  O('"What happened in here?"','leo.what',{once:true}),
  O('"Who shut the door?"','leo.door',{once:true,if:S=>S.seen['leo.what']}),
  O('"Did you see me come in?"','leo.me',{once:true,if:S=>S.seen['leo.what']}),
  O('Unlock the handcuffs.','leo.free',{item:'cuffkey'}),
  C('frenzy',12,'Rip the hook out of the rail.','leo.hookOk','leo.hookNo',{id:'ted_hook',red:true,if:(S,G)=>!G.has('cuffkey')}),
  O('Bite him.','leo.bite',{if:S=>!S.flags.bitLeo}),
  O('"Hang in there."',null,{end:true,leave:true})]};
N['leo.calm']={lines:[T(S=>S.flags.bitLeo?'He flinches so hard the hook squeaks.':'He looks at you the way a deer looks at headlights that have just told it a joke.'),
  L('leo','That\'s exactly what someone who was going to hurt me would say. Not that I\'m judging. You\'re doing great. You\'re doing really great.'),
  L('velvet','Lower your voice. Slower. Soft vowels. Let him think he\'s the one calming *you* down.',{pass:8,do:(S,G)=>{if(!S.flags.bitLeo&&G.once('tedcalm'))G.rel('leo',1);}})],next:'leo.hub'};
N['leo.name']={lines:[L('leo','Leo. Leonard Pruitt. I do the night counter here, Monday to Thursday? I also do stand-up. Tuesdays, at the Lantern Room on Ferrier. You should come. No, you shouldn\'t come. Sorry. Forget I said that.',{do:(S,G)=>{G.meet('leo');G.fact('leo','name');G.fact('leo','standup');}}),
  L('nostalgia','The Lantern Room. You know it. Sticky floors, a stamp on the back of your hand, a lot of people being brave in front of a microphone.',{pass:8})],next:'leo.hub'};
N['leo.what']={lines:[L('leo','I was doing close-down. Freezer inventory. And the tall guy with the hat was already *in* here, holding Margo\'s ledger, the red one, and he said, real calm, "Don\'t scream." And then he did the — the *bitey* thing.'),
  L('leo','And then you came in. And you two didn\'t fight, exactly. You kind of... it was like a *dance*? A really bad one. And then he was a pile and you were on the floor, and somebody shut the door.',{do:(S,G)=>{G.meet('leo');G.fact('leo','saw');G.fact('leo','door');}}),
  L('web','The Sheriff had the ledger in here. So where is it now?',{pass:8,do:S=>S.flags.wantLedger=1})],next:'leo.hub'};
N['leo.door']={lines:[L('leo','I didn\'t see! I was hanging on a *hook*! I heard it, though. The latch. And the safety thing on the inside didn\'t work. There\'s supposed to be a knob you push. Margo had it "fixed" last week, and now it\'s just a hole.',{do:(S,G)=>{S.flags.knowsLatch=1;G.meet('margo');G.fact('margo','release');G.fact('leo','margo');}}),
  L('echo','A hole. And a probe thermometer hanging off the end of the shelf. Long. Thin.',{pass:6,if:S=>!S.flags.thermoTaken})],next:'leo.hub'};
N['leo.me']={lines:[L('leo','You came in *after* him. Hands in your pockets like you were looking for your keys. You looked... normal? Tired. Like ‹a guy|a girl› who works nights. And then the hat guy said your name.'),
  L('leo','I didn\'t catch it! Something with a V? Or an R? I was being exsanguinated, I wasn\'t taking notes.',{do:S=>S.flags.heardV=1}),
  L('web','You walked into a freezer with a Sheriff in it, on purpose, and he knew your name. Why?',{pass:10})],next:'leo.hub'};
N['leo.free']={lines:[T('The key turns easily. The cuffs fall open, and Leo drops off the hook like a coat off a peg.',{fx:'sfx:metal',do:(S,G)=>{G.pose('leo','slump',3);G.take('cuffkey');}}),
  L('leo','Oh. Oh, my arms. I can\'t feel my — that\'s fine. That\'s fine. Thank you. Thank you, thank you.'),
  L('rigor','He\'s cold to the bone. Another hour in here and he\'d have stopped shivering, which is the bad kind of not shivering.',{pass:8}),
  L('leo','I\'m going to sit somewhere warm. I\'m going to sit somewhere warm and think about my life.',{do:(S,G)=>{S.flags.tedFreed=1;S.flags.tedState='hiding';G.rel('leo',1);G.xp(15,'Rescue');G.task('leo');G.rebuildRoom();}})],end:true};
N['leo.hookOk']={lines:[T('You take hold of the rail and *pull*. Steel groans. Bolts sing. The whole rail comes down at one end with a crash that rattles your teeth, and Leo with it.',{fx:['sfx:crash','shake:1.6'],do:(S,G)=>G.pose('leo','slump',3)}),
  L('leo','AAAH — okay — okay, I\'m down. I\'m down! I\'m still handcuffed, but I\'m *down*.'),
  L('tenant','Subtle.',{do:(S,G)=>{S.flags.tedFreed=1;S.flags.tedState='hiding';S.flags.loud=1;G.rel('leo',1);G.task('leo');G.rebuildRoom();}})],end:true};
N['leo.hookNo']={lines:[T('You take the rail in both hands and heave. It doesn\'t move. Something in your shoulder does.',{fx:'sfx:hurt'}),
  L('leo','Please stop doing whatever that is. The hook is attached to my *wrists*.',{do:(S,G)=>G.comp(-1,'Strain')})],next:'leo.hub'};
N['leo.bite']={lines:[L('frenzy','Yes. Yes yes yes.'),L('pulse','He\'s already half empty. He has a *sister*.')],
  opts:[O('Just a sip. Just enough.','leo.sip'),O('No. Not him.','leo.hub')]};
N['leo.sip']={lines:[T('You lean in. He goes very quiet, and then he says, in a perfectly reasonable voice, "Okay." That is the worst part.'),
  T('You drink. Not much. Enough that the room stops tilting.',{fx:['flash','sfx:drink'],do:(S,G)=>{G.feed(3,'melancholic',"Leo's fear");if(!S.th.done.includes('meat'))G.comp(-2,'You fed on him');G.meet('leo');G.rel('leo',-2);S.flags.bitLeo=1;S.flags.beastDone=1;G.offer('meat');}}),
  L('leo','...Are you done? You\'re done. Okay. Okay. I\'m going to faint now, if that\'s cool.')],next:'leo.hub'};
N['leo.leave']={lines:[L('leo','Wait — wait, you\'re *leaving*? You\'re leaving me on the *hook*?')],
  opts:[O('"I\'ll come back for you."','leo.leaveOk'),O('"Find your own way down."','leo.leaveCold'),O('Stay a moment longer.',null,{end:true,do:S=>S.flags.cancelExit=1})]};
N['leo.leaveOk']={lines:[L('leo','Okay. Okay. I believe you. I have to believe you, I\'m on a hook.')],end:true};
N['leo.leaveCold']={lines:[L('leo','That\'s — wow. Okay. Cool. Cool cool cool.',{do:(S,G)=>G.rel('leo',-1)}),L('pulse','You left a man on a meat hook. Notice how easy that was.',{pass:8})],end:true};

/* ----- freezer door ----- */
N['door.0']={lines:[
  T('A heavy steel door with a fat rubber gasket. No handle on this side, only a round hole where the safety release should be, ringed with fresh, bright scratches.',{if:S=>S.seen['door.0']===1}),
  L('echo','The release plunger has been unscrewed. Recently: the threads are still shiny. Somebody wanted this freezer to stay shut from the inside.',{pass:8,do:S=>S.flags.knowsLatch=1}),
  L('sundial','Eight hours of night left. Plenty of time to be trapped in a box.',{if:S=>S.seen['door.0']===1})],next:'door.hub'};
N['door.hub']={opts:[
  O('Push the door.','door.push',{once:true}),
  O('Bang on the door and shout.','door.bang',{once:true}),
  C('echo',10,'Look for another way to trip the latch.','door.echoOk','door.echoNo',{id:'door_echo',if:S=>!S.flags.knowsLatch}),
  O('Feed the meat thermometer through the hole and feel for the latch.','door.probe',{item:'thermometer'}),
  C('rigor',10,'Put your shoulder into it until something gives.','door.rigorOk','door.rigorNo',{id:'door_rigor'}),
  C('frenzy',13,'Tear it off its hinges.','door.frenzyOk','door.frenzyNo',{id:'door_frenzy',red:true}),
  O('Step back.',null,{end:true,leave:true})]};
N['door.push']={lines:[T('You push. Nothing. Not even a rattle. Latched from the outside.')],next:'door.hub'};
N['door.bang']={lines:[T('You pound on the steel. It booms like a church bell. Nobody comes. On the other side, very faintly, a radio is playing a song about summer.',{fx:['sfx:knock','shake:.3']}),
  L('sundial','Don\'t listen to it. *Don\'t listen to it.*'),
  L('leo','I tried that. For like an hour. Before you woke up.',{if:S=>!S.flags.tedFreed})],next:'door.hub'};
N['door.echoOk']={lines:[L('echo','The latch bar runs straight through the door. Through the hole you can see the end of the rod, a finger\'s length in. Something long and thin could push it.',{do:S=>S.flags.knowsLatch=1}),
  L('echo','There was a meat thermometer hanging off the end of the shelf.',{if:(S,G)=>!G.has('thermometer')})],next:'door.hub'};
N['door.echoNo']={lines:[L('echo','Steel. Rubber. Darkness. A hole. It is a door, and you are on the wrong side of it.')],next:'door.hub'};
const openDoor=(S,G,how)=>{S.flags[how]=1;G.task('freezer','done');G.rebuildRoom();if(S.flags.tedFreed)S.flags.tedInBack=1;};
N['door.probe']={lines:[T('You feed the probe into the hole. Steel scrapes on steel. You find the end of the rod, and lean.',{fx:'sfx:metal'}),
  L('abattoir','Like finding a vein. Gentle. Gentle. *There.*',{pass:6}),
  T('Something clunks. The gasket sighs. The door swings open on a warm yellow room that smells of bleach and old meat.',{fx:'sfx:door',do:(S,G)=>openDoor(S,G,'doorOpen')}),
  L('leo','YES. Yes! You\'re a genius! A weird, cold genius!',{if:S=>!S.flags.bitLeo})],end:true};
N['door.rigorOk']={lines:[T('You set your shoulder and push, and keep pushing, past the point where a living person would stop because it hurt. You don\'t have that point any more.',{fx:['sfx:metal','shake:1']}),
  T('The hinge pins shear. The door lurches open a foot and jams. It\'s enough.',{do:(S,G)=>{S.flags.loud=1;openDoor(S,G,'doorOpen');}})],end:true};
N['door.rigorNo']={lines:[T('You shove until your shoulder makes a sound like snapping celery. You pop it back in. It doesn\'t hurt. That\'s the worst part.',{fx:'sfx:hurt',do:(S,G)=>G.comp(-1,'Your shoulder came out')})],next:'door.hub'};
N['door.frenzyOk']={lines:[T('The red comes up like a tide.',{fx:['hurt:1','sfx:sting']}),
  T('You get your fingers into the gasket and *rip*. The door comes off its hinges with a scream of steel and goes over like a felled tree.',{fx:['sfx:crash','shake:2.2'],do:(S,G)=>{S.flags.loud=1;G.heat(1);openDoor(S,G,'doorTorn');}}),
  L('leo','WHAT. What. Okay. What.',{if:S=>!S.flags.tedFreed}),
  L('tenant','Subtle. Very subtle. The whole street heard that.')],end:true};
N['door.frenzyNo']={lines:[T('You throw yourself at the door. The door throws you back.',{fx:['sfx:crash','shake:1.2'],do:(S,G)=>{G.vitae(-1);G.comp(-1,'You hit a steel door');}}),
  L('frenzy','Again. AGAIN.'),L('rigor','No.')],next:'door.hub'};

/* ======================= BACK ROOM ======================= */
N['sink.0']={lines:[T('A deep steel sink with a tap that only runs hot. A cake of pink soap. A nailbrush with most of its bristles gone.'),
  L('nostalgia','Warm water. Remember baths? Remember being *warm*?',{pass:6,if:S=>S.seen['sink.0']===1})],
  opts:[O('Scrub your hands and face.','sink.wash',{if:S=>!S.flags.washed}),O('Leave it.',null,{end:true,leave:true})]};
N['sink.wash']={lines:[T('The water runs grey, then pink, then clear. You scrub until the nailbrush gives up. In the dented steel above the tap, something like a face looks back, less dirty than it was.',{fx:'sfx:swoosh',do:(S,G)=>{S.flags.washed=1;S.flags.dirty=0;G.comp(1,'Clean hands');}}),
  L('stagecraft','Good. Ash on the hands is a hard thing to explain to a living person. "Gardening" will only take you so far.')],end:true};
N['saw.0']={lines:[T('A green band saw, tall as a person, its blade wiped clean and its table not.'),
  L('abattoir','You could fit a whole Sheriff through this in nine minutes.',{pass:6}),L('tenant','I\'m *ash*.'),L('abattoir','Then four.'),
  L('frenzy','Turn it on. Just to hear it.',{if:hungry})],end:true};
N['rack.0']={lines:[T('A bentwood coat rack. On it: a night-counter apron, stiff with old blood, and a folded paper hat with a red stripe.')],
  opts:[O('Take the apron.','rack.apron',{if:S=>!S.flags.apronTaken}),O('Take the paper hat.','rack.hat',{if:S=>!S.flags.paperHatTaken}),O('Leave them.',null,{end:true,leave:true})]};
N['rack.apron']={lines:[T('You lift it off the hook. It holds its shape, like armour.',{do:(S,G)=>{G.give('apron');S.flags.apronTaken=1;G.rebuildRoom();}}),
  L('stagecraft','Nobody ever looks twice at the person in the apron. You are furniture with a pulse. Well. Furniture.')],next:'rack.0'};
N['rack.hat']={lines:[T('A paper hat. Kowalski\'s, in red. It weighs nothing.',{do:(S,G)=>{G.give('paperhat');S.flags.paperHatTaken=1;G.rebuildRoom();}}),
  L('apex','Absolutely not.'),L('stagecraft','Absolutely yes.')],next:'rack.0'};
N['knives.0']={lines:[T('A pegboard of knives: cleavers, boners, a long slicer, a steel. Each one has its outline drawn on the board in marker, so you\'d know at once if one went missing.'),
  L('echo','None are missing. Whoever was here last didn\'t bring their own, and didn\'t borrow one.',{pass:10}),
  L('frenzy','Pick one. Any one.')],
  opts:[O('Take the boning knife.','knives.take',{if:S=>!S.flags.knifeTaken}),O('Leave them.',null,{end:true,leave:true})]};
N['knives.take']={lines:[T('Six inches of flexible steel. It slides into your pocket and sits there like a held breath.',{do:(S,G)=>{G.give('knife');S.flags.knifeTaken=1;}}),
  L('pulse','Its outline on the board is empty now. Margo will know. Margo always knows.',{pass:8})],end:true};
N['table.0']={lines:[T('A stainless cutting table, scrubbed and scarred. A slab of pork belly sits on it under a cleaver, waiting for a shift that isn\'t coming.'),
  L('osmosis','The blood on the board is pig. Only pig. You\'re almost disappointed.',{pass:8}),
  L('autopsy','Wiped down at about eight. Everything after eight happened in the freezer.',{pass:10})],end:true};
N['cabinet.0']={lines:[T('A grey filing cabinet. INVOICES. TAX (DON\'T). And a third drawer with COURT written on the label in red marker.'),
  T('The COURT drawer is empty.'),
  L('echo','Clean rectangles in the dust. It held three thick folders until very recently. Tonight, probably.',{pass:8}),
  L('web','Someone shut you in, put the ledger back, and took the Court\'s files. That isn\'t panic. That\'s a *checklist*.',{pass:10})],end:true};
N['desk.0']={lines:[T('Margo\'s desk: a green banker\'s lamp, a red telephone, an adding machine, and a sticky note on the blotter in capitals: IF COURT CALLS, WE ARE CLOSED.'),
  L('pedigree','"Court", with a capital C. She knows exactly who her customers are.',{pass:8,if:S=>S.seen['desk.0']===1})],next:'desk.hub'};
N['desk.hub']={opts:[O('Look at the ledger.','desk.ledger',{if:S=>!S.flags.ledgerTaken}),O('Search the drawers.','desk.drawer',{once:'desk_drawer'}),O('Step away.',null,{end:true,leave:true})]};
N['desk.ledger']={lines:[T('An oxblood ledger. The one Leo saw in the Sheriff\'s hands. It\'s back on the desk now, squared neatly to the edge of the blotter.'),
  L('web','He had it in the freezer. Somebody carried it back out here and put it away, tidily. Somebody who shut a door on two vampires, and then *tidied*.',{pass:8,if:S=>S.flags.wantLedger})],
  opts:[C('web',10,'Make sense of the columns.','desk.ledgerOk','desk.ledgerNo',{id:'ledger_web'}),O('Take the ledger with you.','desk.take'),O('Put it down.','desk.hub')]};
N['desk.ledgerOk']={lines:[L('web','Dates, pints, prices. In from ST. ADA\'S on Tuesdays. Out to G.H., the Gilded Court, on Thursdays, at four hundred a pint.'),
  L('web','And on the far right, every single week, a tenth of the take: A.C. — 10%.'),
  L('tenant','That is a forgery. ...Ten percent is entirely standard.'),
  L('gutter','The Sheriff of the Marrow Ward took a cut of the blood trade he was meant to police. Everybody in this city takes a cut. Even the law. *Especially* the law.',{pass:6,do:(S,G)=>{G.offer('tenpercent');G.fact('tenant','cut');G.meet('margo');G.fact('margo','trade');}}),
  L('web','The last entry is today\'s date, in a different pen, pressed hard enough to dent the page: "New arrangement. S. says the Sheriff is a problem."',{do:(S,G)=>{G.fact('margo','v');S.flags.sawV=1;G.xp(15,'The ledger');}}),
  L('web','V. Leo said the Sheriff called you by a name with a V in it.',{pass:8,if:S=>S.flags.heardV}),
  L('tenant','V. I don\'t know any V. I know *several* V\'s. None of them would dare.')],next:'desk.ledger'};
N['desk.ledgerNo']={lines:[L('web','Numbers. Initials. Your eyes keep sliding to the bottom of the page, where the ink is fresh.')],next:'desk.ledger'};
N['desk.take']={lines:[T('You tuck the ledger under your arm.',{do:(S,G)=>{G.give('ledger');S.flags.ledgerTaken=1;G.rebuildRoom();}}),L('gutter','Whoever put this back will notice it\'s gone. Good. Let them sweat.',{pass:8})],next:'desk.hub'};
N['desk.drawer']={lines:[T('Top drawer: rubber bands, a tin of mints, a pair of tortoiseshell reading glasses.',{do:(S,G)=>G.give('glasses')}),
  T('Bottom drawer: a padlock key on a fob that says BACK · DON\'T LOSE (MARGO), and a framed photograph lying face down.',{do:(S,G)=>G.give('backkey')}),
  T('The photograph shows a woman in her sixties holding a cleaver and a prize ribbon, beside a tall man in a wide-brimmed hat. They are both smiling. Neither is looking at the camera. They are looking at each other.'),
  L('tenant','1987. The county fair. She took best in show for a pork loin, and I won forty dollars betting on her. Margo. Oh, *Margo*.'),
  L('pulse','He loved her. Present tense, mostly.',{pass:10,do:(S,G)=>{G.meet('margo');G.fact('margo','owner');}})],next:'desk.hub'};
N['phone.idle']={lines:[T('A red rotary telephone. Somebody has drawn a tiny skull on the dial in biro.'),L('tenant','Margo\'s line. I rang it every Thursday for thirty years.',{pass:8})],end:true};

/* ----- the mirror ----- */
N['mirror.pre']={lines:[T('A small mirror over a small sink, speckled with toothpaste and age.',{if:S=>!S.clan}),T('There is a reflection in it. Probably.',{if:S=>!S.clan}),
  L('tenant','Look. *Look*. I need to know what I\'ve become.',{if:S=>!S.clan})],cs:async(G,S)=>{if(!S.clan){G.dlgHide();await STORY.mirror(G,S);}},next:S=>S.clan&&!S.flags.mirrorReacted?'mirror.react':'mirror.again'};
N['mirror.again']={lines:[T(S=>NL.CLANS[S.clan].ghost?'The mirror shows the washroom, the open door, the light. It does not show you.':'Your face looks back. It still doesn\'t look quite like anyone you know.')],end:true};
const REACT={
  sovereign:[['tenant','A Sovereign. Well. At least you have *taste*. My blood would hardly have stayed down otherwise.'],['pedigree','The same lineage as the man you drank. The Court will call that cannibalism. The Court will also be jealous.']],
  glass:[['tenant','Glass. Wonderful. Now there will be someone in here reading my mind while I read yours.'],['web','The crack in the corner of the mirror wasn\'t there a minute ago.']],
  butchers:[['tenant','A Butcher! Of course. In a *butcher\'s shop*. Somebody up there has a sense of humour.'],['abattoir','Your scars itch. Not in a bad way.']],
  rot:[['tenant','The Rot. Grey and damp and eternal. My blood, in a sewer king. I would be sick if I still could.'],['parasite','The rats in the walls just stopped moving. They\'re listening to you.']],
  wraiths:[['tenant','There\'s... no one there. Oh. A *Wraith*. I have been drunk by a draught.'],['echo','No reflection. But your shadow is on the wall behind you, and it looks worried.']],
  stray:[['tenant','No clan at all. A *mongrel*. I have been eaten by a stray dog.'],['gutter','Nobody owns you. Remember that when they start asking.']],
  gilded:[['tenant','Gilded. Hm. You *are* rather beautiful. It\'s mostly my cheekbones.'],['velvet','Smile. No, less. There.']],
  choir:[['tenant','The Choir. Blood-singers. You\'ll hum. You will hum all night, and I will go mad, if I\'m not already.'],['osmosis','The blood in the sink trap is humming back at you.']],
  hounds:[['tenant','A Hound. The Court\'s dogs. If you\'d been on duty tonight, they\'d have sent you to find *me*.'],['apex','Sit? No. Never again.']],
  moths:[['tenant','A Moth? What is a Moth? Is that a clan now? What *year* is it?'],['web','The flip phone in your pocket is going to buzz. You know it half a second before it does.']]
};
N['mirror.react']={lines:S=>[T(S=>NL.PASTS[S.past].mem),...REACT[S.clan].map(r=>L(r[0],r[1])),
  L('sundial','Enough looking. You can admire yourself on Saturday, if there is one.',{do:(S,G)=>{S.flags.mirrorReacted=1;G.task('mirror','done');G.xp(20,'You remember who you are. Some of it.');}})],
  cs:async(G,S)=>{G.dlgHide();await G.wait(1.6);if(!S.flags.phoneRinging&&!S.flags.callDone)await STORY.ringPhone(G,S);},end:true};

/* ----- Leo, freed (back room) ----- */
N['tedf.0']={enter:(S,G)=>{G.focus(['you','leo'],.7);G.look('leo','you');G.look('you','leo');},
  lines:[T('Leo is sitting on an upturned crate by the sink, wrapped in flattened cartons, holding his own wrists like they belong to somebody else.',{if:S=>S.seen['tedf.0']===1}),
  L('leo',S=>S.flags.bitLeo?'Hey. Hi. You bit me. I want to say up front that I\'m not mad. I\'m a *lot* of other things.':'Hey. Thanks for, you know. The hook thing.',{if:S=>S.seen['tedf.0']===1}),
  L('leo',S=>({forgot:'Weirdest nightmare. Ammonia, hooks, a guy who turned into a pile. Anyway! Hi!',ally:'Hey, night person.',thrall:'You\'re back! Hi! Do you need anything? I could get you anything.',paid:'I didn\'t see anything. Hi.'}[S.flags.tedState]||'Still here. Head down. Very quiet.'),{if:S=>S.seen['tedf.0']>1})],next:'tedf.hub'};
N['tedf.hub']={opts:[
  O('"How are you holding up?"','tedf.how',{once:true}),
  O('"Tell me a joke."','tedf.joke',{once:true}),
  O('"Who\'s Margo?"','tedf.margo',{once:true}),
  O('Pinch the nerve in his neck and close the holes with your thumb.','tedf.carve',{ab:'nerve',once:true}),
  O('Listen to the thing he\'s loudest about not saying.','tedf.coldread',{ab:'coldread',once:true}),
  O('Touch his collar. Read what\'s soaked into it.','tedf.augury',{ab:'touch',once:true}),
  O('Taste the fleck of blood on his collar.','tedf.augury',{ab:'vintage',once:true}),
  O('Try the truth. Watch it go wrong. Rewind.','tedf.fault',{ab:'dejavu',once:true}),
  O('Crown of Fog: take tonight out of his head.','tedf.kneel',{ab:'fog',if:tedUnresolved}),
  O('Encore: let him hear his own joke again until it lands.','tedf.muse',{ab:'encore',if:tedUnresolved}),
  O('Siren\'s Pitch: sing him the punchline he\'s missing.','tedf.muse',{ab:'siren',if:tedUnresolved}),
  C('velvet',12,'"It was an ammonia leak. None of this happened."','tedf.ammOk','tedf.ammNo',{id:'ted_amm',if:tedUnresolved}),
  C('pulse',10,'Tell him the truth.','tedf.truthOk','tedf.truthNo',{id:'ted_truth',if:S=>tedUnresolved(S)&&!S.flags.tedTruthEasy}),
  O('Tell him the truth. He can take it.','tedf.truthOk',{if:S=>tedUnresolved(S)&&S.flags.tedTruthEasy}),
  C('gutter',8,'Hand him the register cash. "You didn\'t see anything."','tedf.payOk','tedf.payNo',{id:'ted_pay',item:'cash',if:tedUnresolved}),
  O('Open your wrist and offer it. "Drink."','tedf.bond',{if:tedUnresolved,blood:1}),
  O('"Stay here. Keep your head down."',null,{if:S=>tedUnresolved(S),end:true,do:S=>S.flags.tedState='hiding'}),
  O('Leave him be.',null,{end:true,leave:true,if:S=>!tedUnresolved(S)})]};
N['tedf.how']={lines:[L('leo','Honestly? I\'ve been better. I\'ve also been worse. I did a bachelorette party once where they threw a shoe at me. A *heel*. This is... comparable.'),
  L('leo','It\'s my niece\'s birthday. Bea. Junie\'s kid, my sister\'s. She\'s nine today. I was supposed to drive the cake out to the coast after close. It\'s in the walk-in. It\'s probably fine. Cakes are fine in freezers, right?',{do:(S,G)=>G.fact('leo','sister')}),
  L('nostalgia','Birthday cake from a butcher\'s freezer. It will taste faintly of pork. She\'ll love it anyway.',{pass:8}),
  L('leo','Also my mom has called me forty-one times.',{do:(S,G)=>G.fact('leo','mom')})],next:'tedf.hub'};
N['tedf.joke']={lines:[L('leo','Okay. Okay okay. Work in progress. What do you call a vampire who works in a butcher\'s?'),
  L('leo','...I don\'t have the end yet. I\'ve had the start for two years. Here, you read it, tell me if any of it\'s funny.',{do:(S,G)=>G.give('notebook')}),
  L('gutter','"The night shift." Everybody on the night shift is a vampire, one way or another.',{pass:8}),
  L('leo','Oh, that\'s *depressing*. I\'ll use it.',{if:(S,G)=>G.skill('gutter')+6>=8,do:(S,G)=>G.rel('leo',1)})],next:'tedf.hub'};
N['tedf.margo']={lines:[L('leo','Margo Kowalski. Owns the place. Sixty-three, built like a fridge, can bone a chicken in nine seconds. Nice to me. Pays cash. Doesn\'t ask why I\'m always tired, and I don\'t ask why we sell pork stock to a nightclub.'),
  L('leo','She went home at eight, same as always. Said, "Lock the walk-in when you\'re done, Leonard." That\'s weird, right? She never says that. We never lock the walk-in.',{do:(S,G)=>{G.meet('margo');G.fact('margo','owner');S.flags.margoLock=1;}}),
  L('web','She *never* says that.',{pass:8})],next:'tedf.hub'};
N['tedf.carve']={lines:[T('You find the nerve under his jaw and press. His shoulders drop; the throbbing stops. Then your thumb over the holes, and the skin knits under it like warm wax. When you take your hand away there\'s nothing there at all.'),
  L('leo','Okay, that\'s amazing and I hate it. Thank you.',{do:(S,G)=>{G.rel('leo',1);S.flags.tedHealed=1;}})],next:'tedf.hub'};
N['tedf.coldread']={lines:[T('His loudest silence comes through like a station on an old radio: *I should\'ve been at Bea\'s party. I\'m always at the shop. I\'m always tired. She drew me a picture and I haven\'t even looked at it.*'),
  L('pulse','He thinks he\'s a bad uncle. There\'s a folded drawing in his back pocket and he\'s too ashamed to open it.'),
  L('you','"Look at the picture in your back pocket, Leo."'),
  L('leo','How did you — ...oh. Oh, it\'s me. On a stage. She gave me a crown.',{do:(S,G)=>{G.rel('leo',1);G.fact('leo','sister');}})],next:'tedf.hub'};
N['tedf.augury']={lines:[T('The fleck of his blood comes to you in layers: lager, fear, a birthday candle, and under it two nights from now, twice over, like a double exposure.'),
  T('*A spotlight. A microphone. A crown drawn in crayon.* And over it: *his face on a MISSING poster, pasted to a wet brick wall.*'),
  L('osmosis','Both are true. Neither is decided. That part is up to you.')],next:'tedf.hub'};
N['tedf.fault']={lines:[T('You tell him a lie. You watch it go into him. You watch it come out of him, three weeks from now, in a police interview room, as a scream. Then you are back, mouth closed, nothing said.'),
  T('He won\'t break if you tell him the truth. He\'ll break if you lie to him and he ever finds out. Into very small pieces.',{do:S=>S.flags.tedTruthEasy=1})],next:'tedf.hub'};
N['tedf.kneel']={lines:[T('You catch his eyes and hold them, and reach behind them for the last hour, the way you\'d reach for a coat on a hook.'),
  L('you','"You fell asleep in the walk-in. You had a nightmare. You cut your neck on a hook. You\'re going to go home and eat cake."'),
  L('leo','...I fell asleep in the walk-in. What a nightmare. I cut my neck on a hook. I\'m gonna go home and eat cake.'),
  L('pulse','It worked. He looks so relieved. He doesn\'t know what he\'s relieved about.',{do:(S,G)=>{S.flags.tedState='forgot';G.task('leo','done');G.offer('darwin');}})],end:true};
N['tedf.muse']={lines:[T('You hum, very low, the note under his own nervous laugh, and let an idea fall into him like a coin into a well.'),
  L('leo','...The night shift. What do you call a vampire butcher? *The night shift*. Oh my God. That\'s it. That\'s the end. That\'s the whole tight five.'),
  L('leo','I don\'t know what you are, but you\'re my favorite person.',{do:(S,G)=>{S.flags.tedState='ally';G.rel('leo',2);G.task('leo','done');}})],end:true};
N['tedf.ammOk']={lines:[L('you','"Leo. The compressor\'s been leaking ammonia all night. You\'ve been breathing it for hours. Hallucinations. Hooks. Fangs. None of it happened."'),
  L('leo','...Oh my God. Ammonia. That makes so much *sense*. I thought you had *fangs*. I thought the guy turned into a *pile*.'),
  L('velvet','He wants it to be true so much that he\'s doing half the work for you.',{do:(S,G)=>{S.flags.tedState='forgot';G.task('leo','done');}})],end:true};
N['tedf.ammNo']={lines:[L('leo','Ammonia doesn\'t put holes in your *neck*. I work nights. I\'m not *stupid*.',{do:(S,G)=>G.rel('leo',-1)})],next:'tedf.hub'};
N['tedf.truthOk']={lines:[L('you','"I\'m a vampire. So was he. I think I killed him, and I don\'t remember why. I need you to keep that to yourself until I find out who locked us in."'),
  L('leo','...'),
  L('leo','Okay. Okay. So you\'re a night person. I\'m a night person! We\'re both night people.'),
  L('leo','I won\'t tell anyone. Who would I tell? My mom? She thinks comedy is a *phase*.',{do:(S,G)=>{S.flags.tedState='ally';G.rel('leo',2);G.task('leo','done');}}),
  L('pedigree','You just told a mortal. The Court has a word for that, too.',{pass:8})],end:true};
N['tedf.truthNo']={lines:[L('leo','A vampire. Sure. And I\'m the Pope. You\'re messing with me. Right? You\'re messing with me.'),
  L('pulse','He\'s laughing, and his hands are shaking. He believes you. He just can\'t afford to.',{do:(S,G)=>G.rel('leo',-1)})],next:'tedf.hub'};
N['tedf.payOk']={lines:[L('you','"Two hundred and twelve dollars says you didn\'t see anything tonight."'),
  L('leo','And a Canadian quarter. Okay. Okay, I didn\'t see anything. I\'m very good at not seeing things. I work *here*.',{do:(S,G)=>{G.take('cash');S.flags.tedState='paid';G.task('leo','done');}})],end:true};
N['tedf.payNo']={lines:[L('leo','You\'re paying me with money from Margo\'s *register*? She counts that! She\'ll think *I* took it!',{do:(S,G)=>G.rel('leo',-1)})],next:'tedf.hub'};
N['tedf.bond']={lines:[L('pedigree','Making a thrall without the Court\'s leave is a crime. A serious one. The Sheriff used to enforce it. ...You ate the Sheriff.'),
  T('You open your wrist with a thumbnail. The blood comes up dark and slow. Leo stares at it.'),
  L('leo','You want me to... drink that? Is this a hazing thing? Is this how I get promoted?')],
  opts:[O('"Drink."','tedf.bondDo'),O('Close your wrist. "Never mind."','tedf.hub')]};
N['tedf.bondDo']={lines:[T('He drinks. Two swallows, and then a third he doesn\'t mean to take. When he looks up, his pupils are huge and soft and entirely yours.',{do:(S,G)=>{G.vitae(-1);S.flags.tedState='thrall';S.flags.illegalThrall=1;G.rel('leo',3);G.task('leo','done');}}),
  L('leo','Oh. Oh, *wow*. I feel *great*. I feel like I could do a ninety-minute set. Do you need anything? Can I get you anything? I love you. Is that weird? That\'s weird. I love you.'),
  L('pulse','You did that to him. It took about four seconds.',{do:(S,G)=>G.comp(-1,'You made a thrall')})],end:true};

/* ----- phone ----- */
N['call.0']={enter:(S,G)=>{A.ringStop();G.sfx('flip');G.pose('you','phone');},lines:[T('You lift the receiver. Static, and then a woman\'s voice, clipped and expensive.'),
  L('severine','Absalom. You\'re *late*. You were due at Court at midnight with your report on the Marrow Ward disappearances, and the Prince does not *wait*, darling. She *notices*.'),
  L('tenant','Lady Séverine. Keeper of Elysium. She has hated me since the Coolidge administration, with real devotion. Let me talk. Repeat after me.',{do:(S,G)=>{S.flags.marchettiNamed=1;G.meet('severine');G.fact('severine','feud');G.fact('severine','call');}})],next:'call.hub'};
N['call.hub']={opts:[
  C('stagecraft',10,'Let the Tenant talk through you. Do his voice.','call.voiceOk','call.voiceNo',{id:'call_voice'}),
  C('pedigree',10,'Answer with her full title, the way he would.','call.pedOk','call.pedNo',{id:'call_ped'}),
  O('Listen past her voice. Who else is on the line?','call.signal',{ab:'coldread',once:true}),
  O('Feel for what she owes, and to whom.','call.ledger',{ab:'blueblood',once:true}),
  O('Spark the line and listen to the car around her.','call.signal',{ab:'spark',once:true}),
  O('"This isn\'t Absalom."','call.honest'),
  O('Hang up.','call.hangup')]};
N['call.voiceOk']={lines:[T('The Tenant\'s words come up your throat like wine. Your mouth does something with them it has never done before.'),
  L('you','"Séverine. The night is young, and so, regrettably, are you."'),
  L('severine','...*Charming*. You sound hoarse. Have you been drinking someone *interesting*?'),
  L('tenant','Tell her the disappearances are in hand.'),L('you','"The disappearances are in hand."'),
  L('severine','Then you\'ll have no trouble bringing the Prince a name. Friday, Absalom. The Court convenes Friday at midnight. Bring her a culprit, or she\'ll decide it\'s you.',{do:S=>S.flags.callGood=1})],next:'call.end'};
N['call.voiceNo']={lines:[T('You open your mouth to do the Tenant\'s voice and your own comes out, small and flat.'),L('you','"Uh. Absalom\'s... in the bathroom."')],next:'call.who'};
N['call.pedOk']={lines:[L('you','"Lady Séverine. Lady of the Long Hall. Keeper of the Prince\'s Calendar."'),
  L('severine','...You remembered the Long Hall. Absalom *never* remembers the Long Hall.'),
  L('pedigree','She sounds flattered. Then she sounds suspicious about sounding flattered.'),
  L('severine','Friday at midnight, then. The Court convenes. The Prince expects a culprit for the disappearances, and if you haven\'t found one, she has a habit of choosing whoever is standing closest.',{do:S=>S.flags.callGood=1})],next:'call.end'};
N['call.pedNo']={lines:[L('you','"Lady... Keeper of Elysium... of the... hall?"'),L('severine','Have you been hit on the head?')],next:'call.who'};
N['call.who']={lines:[L('severine','...Who *is* this?')],opts:[
  C('velvet',12,'"His new assistant. He\'s indisposed. He sends his regrets."','call.assistOk','call.assistNo',{id:'call_velvet'}),O('Hang up.','call.hangup')]};
N['call.assistOk']={lines:[L('severine','An assistant. How *modern* of him. Tell your employer the Court convenes Friday at midnight, and the Prince will be expecting a culprit for the disappearances. If he hasn\'t got one, she\'ll take him instead.'),
  L('severine','And darling, whoever you are: do wash your hands. I can *hear* the ash.',{do:S=>S.flags.marchettiSus=1})],next:'call.end'};
N['call.assistNo']={lines:[L('severine','*Indisposed*. Absalom has not been indisposed since the Spanish flu, and he enjoyed that.'),
  L('severine','I don\'t know who you are, but you\'re standing in his favorite shop answering his telephone. Friday at midnight the Court convenes, and someone is going to be named for the Marrow Ward. Do try not to be that someone.',{do:S=>S.flags.marchettiSus=2})],next:'call.end'};
N['call.honest']={lines:[L('severine','No? Then where is he?')],opts:[O('"He\'s... indisposed."','call.assistNo'),O('"He\'s dead. I drank him."','call.truth')]};
N['call.truth']={lines:[L('severine','...'),L('severine','Ha! Oh, I *like* you. Nobody has made me laugh on this line in forty years.'),
  L('severine','Tell him he has until Friday at midnight to bring the Prince a culprit for the Marrow Ward. If he hasn\'t got one, he\'ll *be* one, and then you really can drink him.'),
  L('tenant','She didn\'t believe you. No one ever believes the truth from a voice with no title.',{do:S=>S.flags.toldTruth=1})],next:'call.end'};
N['call.signal']={lines:[T('You lean into the static. Under her voice: an engine, rain on a roof, the tick of an indicator. She\'s in a car.'),
  T('And breathing. Someone else in the car with her, close to the phone. A man, very quietly: "Is it him?"'),
  L('web','She isn\'t alone. And whoever is with her isn\'t sure the Sheriff is still the Sheriff.',{do:(S,G)=>{G.fact('severine','car');G.xp(10,'Eavesdropping');}})],next:'call.hub'};
N['call.ledger']={lines:[T('You let the Vane blood listen. Debts have a smell, even down a telephone line. Hers smells of old paper and older promises.'),
  L('apex','She owes the Prince everything. And she owes someone *else* something small, recent and very, very secret.'),
  L('web','Someone outside the Court has a hold on the Court\'s Keeper of Elysium.',{do:S=>S.flags.marchettiDebt=1})],next:'call.hub'};
N['call.hangup']={lines:[T('You put the receiver down. The phone rings again at once. Then stops. Then nothing at all, which is somehow worse.',{fx:'sfx:ring'}),
  L('tenant','Oh, she\'ll *love* that.'),
  L('tenant','She\'ll have been calling about Friday. The Court convenes Friday at midnight. If I was meant to bring the Prince a culprit for the disappearances, I suppose that duty has... transferred.',{do:S=>{S.flags.marchettiSus=2;S.flags.hungUp=1;}})],next:'call.end'};
N['call.end']={enter:(S,G)=>G.pose('you','idle'),lines:[T('The line goes dead.',{if:S=>!S.flags.hungUp}),
  L('tenant','Friday. Midnight. A culprit for the disappearances. That was *my* job. Now it\'s yours, because if you don\'t bring them a culprit they will look very closely at whoever is wearing my coat.'),
  L('sundial','Five nights. Monday, Tuesday, Wednesday, Thursday, Friday. Five dawns between you and that Court.',{do:(S,G)=>{G.task('phone','done');G.task('friday');G.fact('severine','friday');S.flags.callDone=1;}}),
  L('leo','Was that your mom?',{if:S=>S.room==='backroom'&&S.flags.tedInBack&&S.flags.tedFreed})],
  cs:async(G,S)=>{G.dlgHide();await STORY.knock(G,S);},end:true};

/* ======================= SHOP FRONT ======================= */
N['shutter.pre']={lines:[T('A roll-down steel shutter over the shop window and door. Neon bleeds through the slats in pink: BROOKER\'S, backwards.'),
  L('nostalgia','Rain out there. You can hear it. You used to love the smell of it.',{pass:8})],end:true};
N['shutter.knock']={lines:[T('The shutter shudders under a fist. Through the slats: a long coat, a paper cup of coffee, the white eye of a flashlight.',{fx:'sfx:rattle'}),
  L('miller','I can hear you in there. I\'m not going anywhere. I\'ve got a thermos and nowhere to be.')],next:'shutter.hub'};
N['shutter.hub']={opts:[O('Raise the shutter halfway.','callo.in'),
  C('rigor',8,'Stand perfectly still until she gives up.','shutter.still','shutter.stillNo',{id:'shut_rig'}),
  O('Not yet.',null,{end:true,leave:true})]};
N['shutter.still']={lines:[T('You go still. Corpse-still. Five minutes. Ten. The rain keeps time.',{do:(S,G)=>G.tick(10)}),
  L('miller','...I can see your shadow under the shutter, you know. It hasn\'t moved in ten minutes. That\'s honestly *more* suspicious.'),
  L('rigor','Living people fidget. You forgot to fidget.',{do:S=>S.flags.stillWeird=1})],next:'shutter.hub'};
N['shutter.stillNo']={lines:[T('You manage nearly a minute before your foot starts tapping on its own.'),L('miller','There we go. Hi. Open up.')],next:'shutter.hub'};
N['callo.in']={cs:async(G,S)=>{G.dlgHide();await STORY.calloIn(G,S);},
  lines:[],next:'callo.meet'};
N['callo.meet']={enter:(S,G)=>{G.focus(['you','miller'],.8);G.look('miller','you');G.look('you','miller');},lines:[
  T('A woman ducks under the shutter, shaking rain off a paper cup of coffee. Forties. Badge on a lanyard. The steady, tired eyes of someone who has knocked on a great many doors with bad news behind them.'),
  L('miller','Detective Ines Miller, Missing Persons. Evening. You\'re not Leo Pruitt.',{do:(S,G)=>{G.meet('miller');G.fact('miller','name');G.fact('miller','leo');}}),
  L('stagecraft','BREATHE. Visibly. It\'s cold and wet out there; she\'ll expect a little steam. And blink. You haven\'t blinked since the mirror.',{pass:6}),
  L('nostalgia','That coffee is from Dot\'s on Ferrier. You can smell the burnt pot from here.',{pass:8,do:(S,G)=>G.fact('miller','coffee')}),
  L('parasite','Her blood: caffeine, ibuprofen, two hours of sleep, and a cold coming on. She\'s running on fumes and spite.',{pass:8})],
  enc:'miller',win:'callo.after',lose:'callo.after'};
N['callo.after']={cs:async(G,S)=>{G.dlgHide();await STORY.calloOut(G,S);},end:true};

N['register.0']={lines:[T('An old brass register with a dent in the drawer, as if someone once kicked it shut.')],opts:[O('Open the drawer.','register.open',{once:'reg_open'}),O('Leave it.',null,{end:true,leave:true})]};
N['register.open']={lines:[T('*Ka-ching.* The drawer jumps out. $212 in small bills and one Canadian quarter. Under the tray, a lost-and-found: a single earring, a bus pass, and a pair of aviator sunglasses.',{fx:'sfx:item'})],
  opts:[O('Take the cash.','register.open',{once:'reg_cash',do:(S,G)=>G.give('cash')}),O('Take the sunglasses.','register.open',{once:'reg_sun',do:(S,G)=>G.give('aviators')}),O('Close the drawer.',null,{end:true,leave:true})]};
N['case.0']={lines:[T('The display case hums. Chops, mince, a pyramid of sausages, a tongue on a doily like something in a museum.'),
  L('frenzy','MEAT.',{if:hungry}),L('nostalgia','Saturday mornings. Your father, number twenty-two on a paper ticket. Half a pound of the good ham, sliced thin.',{pass:8}),
  L('parasite','All of it dead for days. Nothing in here has a heartbeat but you. And you don\'t.',{pass:6})],end:true};
N['chalk.0']={lines:[T('TODAY\'S CUTS, in chalk. Pork chops, 4.99. Brisket, 8.49. Pig trotters, 1.29. Tongue: (ask Margo). And at the bottom, underlined: *No credit. No questions.*'),
  L('gutter','"No questions." That\'s not shop policy. That\'s a business model.',{pass:8})],end:true};
N['tv.0']={lines:[T('A little television on a bracket, the sound off. A news ticker crawls under a photograph of a brick wall papered with posters: 7TH MISSING · THE SHAMBLES · POLICE "NOT LINKING" CASES.'),
  L('web','Seven. In two months. In one ward. "Not linking."',{pass:6}),
  L('tenant','My ward. My *disappearances*. I was supposed to report on them at midnight.')],end:true};
N['wetfloor.0']={lines:[T('A yellow CAUTION: WET FLOOR sign standing over a floor that has been dry for hours.'),
  L('rigor','You could stand next to it for three hours and nobody would notice. They\'d think you were a second sign.'),
  L('stagecraft','Please don\'t.')],end:true};
N['poster.0']={lines:[T('A MISSING poster taped to the counter. A young woman laughing at someone outside the photo. DANIELLE "DANI" OKAFOR, 22. LAST SEEN: THE SHAMBLES. Call PVPD, Det. Miller.'),
  L('pulse','Somebody chose that photo because she looks happy in it. Somebody wanted strangers to like her enough to look.',{pass:8}),
  L('web','Miller. Missing Persons. She\'s the one name on every one of these.',{pass:8})],end:true};
N['shutter.after']={lines:[T('The shutter is half up. Rain hisses on Ferrier Street. Across the road, a parked car with its lights off, and someone in the driver\'s seat holding a paper cup.'),
  L('echo','She\'s still out there. Watching the front. Use the back.')],end:true};

/* ======================= ALLEY ======================= */
N['pem.0']={enter:(S,G)=>{G.focus(['you','pemberton'],.9);G.look('pemberton','you');G.look('you','pemberton');},lines:[
  T('Rain. A long black car with its engine running, older than you and polished like a coffin. Beside it, under a black umbrella, an elderly man in a chauffeur\'s coat.'),
  L('pemberton','Good evening. You are not the Sheriff.'),
  L('tenant','PEMBERTON! Pemberton, it\'s me! — He can\'t hear me. Of course he can\'t hear me.'),
  L('pemberton','And yet you are wearing his coat. And, if my nose serves, rather a lot of his blood.',{if:(S,G)=>G.equipped('greatcoat')}),
  L('pemberton','And his ring. Well.',{if:(S,G)=>G.has('signet')})],next:'pem.hub'};
N['pem.hub']={opts:[O('"Who are you?"','pem.who',{once:true}),O('"I can explain."','pem.explain',{once:true}),O('"Did you shut me in that freezer?"','pem.door',{once:true}),
  O('"Whose are you now?"','pem.bond',{once:true}),O('"Take me home."','pem.end')]};
N['pem.who']={lines:[L('pemberton','Pemberton. Forty-one years in the Sheriff\'s service. Driver, valet, keeper of the calendar, drinker of the occasional sacrament.',{do:(S,G)=>{G.meet('pemberton');G.fact('pemberton','name');G.fact('pemberton','car');G.fact('tenant','pemberton');}}),
  L('pedigree','A thrall. Fed on a vampire\'s blood until the loyalty went all the way down.',{pass:8})],next:'pem.hub'};
N['pem.explain']={lines:[L('pemberton','Please don\'t. Explanations are for people with time. You have until Friday.'),L('pemberton','Lady Séverine has already telephoned the car. Twice.')],next:'pem.hub'};
N['pem.door']={lines:[L('pemberton','I was asleep in the car until eleven, as I am every night until eleven. The Sheriff liked me rested.')],
  opts:[C('pulse',13,'Watch his face while he says it.','pem.pulseOk','pem.pulseNo',{id:'pem_pulse',red:true}),O('Listen to what he isn\'t saying.','pem.cold',{ab:'coldread'}),
    O('Smell the car for a trail.','pem.scent',{ab:'scent'}),O('Let it go.','pem.hub')]};
N['pem.pulseOk']={lines:[L('pulse','A flicker at the corner of his mouth, gone in a quarter of a second. Not guilt. *Relief.*'),
  L('web','He wasn\'t surprised that someone walked out of that freezer. He was relieved it was *you*.',{do:(S,G)=>{G.fact('pemberton','relief');S.flags.pemRelief=1;}})],next:'pem.hub'};
N['pem.pulseNo']={lines:[L('pulse','His face is a closed shop with the blinds down.')],next:'pem.hub'};
N['pem.cold']={lines:[T('His loudest regret is very old and has nothing to do with tonight: a woman on a station platform in 1983, and a train he didn\'t get on.'),
  T('Underneath it, much quieter, much newer: *I told him not to go in there alone.*',{do:(S,G)=>{G.fact('pemberton','relief');S.flags.pemRelief=1;}})],next:'pem.hub'};
N['pem.scent']={lines:[T('You breathe in. Leather, cigars, rain, the Tenant\'s cologne. And on the rear door handle, faint and only hours old: a woman\'s perfume, smoky and expensive.'),
  L('web','Somebody else rode in this car tonight.',{do:S=>S.flags.carPerfume=1})],next:'pem.hub'};
N['pem.bond']={lines:[L('pemberton','The blood decides who I serve, I\'m afraid. It has always been a very decisive sort of blood.'),L('pemberton','And it has decided.',{do:(S,G)=>G.fact('pemberton','bond')}),
  L('tenant','Forty-one years. He didn\'t even ask if I was in here.')],next:'pem.hub'};
N['pem.end']={lines:[L('pemberton','Very good.'),
  T('He opens the rear door. The car smells of leather and cigars and the Tenant\'s cologne, which, you realize, is also yours now.'),
  L('pemberton','Where to, my lord?'),
  L('pedigree','"My lord."'),
  L('tenant','...Home, Pemberton. Tell him *home*.')],cs:async(G,S)=>{G.dlgHide();await STORY.ending(G,S);},end:true};
N['car.0']={lines:[T('A 1971 Continental, black as a hearse, with suicide doors and a hood ornament shaped like a crane on one leg.'),L('tenant','*My* car.'),L('pemberton','*The* car.')],end:true};
N['graffiti.0']={lines:[T('Red paint on brick, still tacky: WHO DRINKS THE MARROW WARD?'),L('web','Not "who\'s taking people". Who *drinks*. Somebody out here knows.',{pass:8}),L('pedigree','That is a Masquerade breach in letters four feet high.',{pass:6})],end:true};
N['posters.0']={lines:[T('Three MISSING posters, one on top of another, rain lifting their corners. Dani Okafor. A man called Pete Sowa. A face so water-damaged it could be anyone.'),
  L('pulse','The newest one is on top of the oldest. Nobody took the old one down. Nobody has given up on it.',{pass:8})],end:true};
N['dumpster.0']={lines:[T('A green dumpster. Inside: offcuts, cardboard, and a smell that would make a living person gag.'),L('parasite','Rats. Eleven of them. All very, very quiet. Listening to you.',{pass:8})],end:true};

/* ======================= ENCOUNTERS ======================= */
ENC.beast={title:'THE BEAST',sub:'Hunger rises · keep your teeth to yourself',music:'tense',after:'night',
  prog:{name:'Restraint',max:5,color:'#e2c27e'},threat:{name:'Frenzy',max:6,color:'#d23246'},
  focus:G=>G.focus(['you','leo'],.5),
  start:(S,G)=>({prog:0,threat:1+G.hunger()}),
  intro:[L('frenzy','HIS NECK. IT\'S RIGHT THERE.'),T('Your fangs are down. You didn\'t tell them to come down.')],
  round(st,S,G){const R=[
    {lines:[T('His pulse thunders. The room narrows to two small holes in the side of his neck.')],threat:1},
    {lines:[L('frenzy','You can taste it already. Copper and lager. One step. ONE STEP.')],threat:1},
    {lines:[L('leo','Hey. Hey, you okay? You\'re kind of staring at my — I\'m gonna keep talking. I talk when I\'m nervous.')],threat:1},
    {lines:[T('He whimpers. It sounds like a dinner bell.')],threat:2},
    {lines:[T('Your vision runs red at the edges.')],threat:2}];return st.round<R.length?R[st.round]:null;},
  moves(st,S,G){return [
    C('nostalgia',10,'Think of something human. Anything.',null,null,{id:'b_nos'+st.round,noLock:true,ok:st=>{st.prog+=2;return [L('nostalgia','Diner coffee. Burnt-pot, two a.m., a chipped mug and a waitress who called you "hon". You hold onto it like a railing.')];},no:st=>{st.threat+=1;return [L('nostalgia','You reach for a memory and find only his neck.')];},once:'beast_nos'}),
    C('pulse',8,'Look at his face. Really look.',null,null,{id:'b_pul'+st.round,ok:st=>{st.prog+=2;return [L('pulse','Freckles. A chipped tooth. A cold sore he\'s embarrassed about. A person. He is a *person*.')];},no:st=>{st.threat+=1;return [L('pulse','You try to look at his face. You look at his neck.')];},once:'beast_pul'}),
    C('rigor',10,'Go still. Corpse-still. Corpses don\'t eat.',null,null,{id:'b_rig'+st.round,ok:st=>{st.prog+=2;return [L('rigor','Nothing moves. Not a finger. Not a fang. The Beast paces the inside of a coffin and finds it closed.')];},no:st=>{st.threat+=1;return [L('rigor','Your hands are already reaching. You didn\'t tell them to.')];},once:'beast_rig'}),
    C('sundial',8,'Count the minutes until dawn.',null,null,{id:'b_sun'+st.round,ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [L('sundial','Seven hours, fifty-one minutes. Seven hours, fifty. Counting is a fence. Stay behind it.')];},no:st=>{st.threat+=1;return [L('sundial','Seven hours and... something. The numbers keep turning into heartbeats.')];},once:'beast_sun'}),
    {t:'Tear open a blood bag and drink it instead.',item:'bloodbag',ok:(st,S,G)=>{G.take('bloodbag');S.flags.drankBag=(S.flags.drankBag||0)+1;G.feed(3,STORY.bagRes(S),'blood bag');st.result='win';return [T('Cold, thick, sweet-salt. The Beast takes it like a dog takes a thrown steak, sulks, and lies down.')];}},
    {t:'Give in.',ok:(st)=>{st.result='lose';return [L('frenzy','YES.')];}}];},
  decide:st=>st.prog>=3?'win':'lose',
  outro(r,st){return r==='win'?[T('The red recedes. Your fangs slide back up where they belong. Your jaw aches with how hard you were clenching it.')]:[];}
};

function calloBase(S,G){let s=2;const why=[];
  if(S.flags.dirty&&!S.flags.washed){s++;why.push('ash on your hands');}
  if(G.equipped('greatcoat')){s++;why.push('ash on the coat');}
  if(G.hunger()>=2&&!G.equipped('aviators')){s++;why.push('your eyes');}
  if(G.equipped('aviators')){s++;why.push('sunglasses at night');}
  if(S.clan==='wraiths'&&!(S.eq.face&&NL.ITEMS[S.eq.face].cover)){s+=2;why.push('your grey face under the lights');}
  if(S.past==='clerk'){s--;why.push('she half-recognizes you from the evidence cage');}
  if(S.flags.loud){s++;why.push('the noise');}
  if(S.flags.stillWeird)s++;
  if(G.equipped('dampapron')){s-=2;why.push('the clean apron helps');}if(G.equipped('apron')){s++;why.push('the bloody apron does not help');}
  if(G.equipped('paperhat')){s--;why.push('the paper hat helps');}
  return {s:Math.max(0,Math.min(6,s)),why};}
const tedReady=S=>S.flags.tedFreed&&S.flags.tedInBack;
ENC.miller={title:'THE DETECTIVE',sub:'Ines Miller · Missing Persons',music:'tense',after:'night',
  prog:{name:'Convinced',max:6,color:'#e2c27e'},threat:{name:'Suspicion',max:10,color:'#d23246'},
  focus:G=>G.focus(['you','miller'],.7),
  start(S,G){const b=calloBase(S,G);return {prog:0,threat:b.s,why:b.why};},
  intro:(S,G)=>{const b=calloBase(S,G);return [L('web',b.why.length?`She clocked it all in the first second: ${b.why.join(', ')}.`:'She looks you over once, top to toe, and finds nothing she can hold on to. Yet.',{pass:6})];},
  round(st,S,G){
    const Q=[
      ()=>({lines:[L('miller','So. Who are you, and where is Leo Pruitt? His mother\'s called the precinct six times since this morning.')],threat:tedReady(S)?0:1}),
      ()=>({lines:[L('miller',(S.flags.dirty&&!S.flags.washed)||G.equipped('greatcoat')?'What\'s that grey stuff all over you? Is that... ash?':'What\'s that smell? Bleach? Somebody\'s been cleaning.')]}),
      ()=>({lines:[L('miller',S.flags.loud?'Lady upstairs called in a crash about an hour ago. Like a car hitting a wall. Know anything about that?':'Why is it so cold in here? It\'s like a morgue.')]}),
      ()=>({lines:[L('miller','Mind if I take a look in the back?')]}),
      ()=>({lines:[L('miller','Well. Thanks for your time.',{do:()=>{}}),T('She holds out her hand to shake.')]})];
    return st.round<Q.length?Q[st.round]():null;},
  moves(st,S,G){const r=st.round,M=[];const sus=n=>st2=>{st2.threat+=n;};
    const once=k=>'callo_'+k;
    if(r===4){
      if(G.equipped('latex')||G.equipped('gloves')||st.warm)M.push({t:'Shake her hand. Firmly.',ok:st=>{st.prog+=2;return [T(st.warm?'Your hand is warm. Butcher-warm. She doesn\'t notice a thing.':'Latex gloves. She makes a face at the squeak and notices nothing else.'),L('miller','...Firm. Okay.')];}});
      else M.push(C('stagecraft',12,'Rub your hands together first, then shake.',null,null,{id:'c_hand',ok:st=>{st.prog+=2;return [L('miller','Cold hands.'),L('stagecraft','"Cold hands, warm heart." Say it. Smile.'),L('miller','Ha. Sure.')];},no:st=>{st.threat+=3;return [T('Her hand closes around yours and goes still. Your hand is the temperature of the pork chops in the case.'),L('miller','...Jesus. You need to see a doctor.')];}}));
      M.push(C('velvet',8,'"Better not. I\'ve been handling raw meat all night."',null,null,{id:'c_meat',ok:st=>{st.prog+=1;return [L('miller','Fair enough.')];},no:st=>{st.threat+=1;return [L('miller','Your hands look pretty clean to me.')];}}));
    }
    if(r===3){
      M.push({t:'"Sure. Go ahead."',ok:(st,S,G)=>{if(!S.flags.tedFreed){st.result='found';return [T('She steps past you, through the swing door, into the back. You hear her footsteps stop.')];}
        if(tedReady(S)&&!st.teddyOut){st.teddyOut=true;st.prog+=3;return STORY.teddyOut(st,S,G);}if(st.teddyOut){st.prog+=1;return [T('She takes a slow lap of the back room, frowns at the band saw, and comes back out.'),L('miller','Clean. Weirdly clean.')];}st.threat+=1;return [T('She looks around the back room, sniffs, frowns at the band saw, and comes back out.')];}});
      M.push(C('gutter',8,'"No warrant, no partner, no overtime. You\'re off the clock, aren\'t you, Detective?"',null,null,{id:'c_warrant',ok:st=>{st.prog+=1;return [L('miller','...Lucky guess.'),T(null,{do:(S,G)=>G.fact('miller','offclock')})];},no:st=>{st.threat+=2;return [L('miller','I can come back with a warrant. I\'d rather not. I\'d rather you just let me look.')];}}));
    }
    if(r===2&&(S.flags.doorTorn||S.flags.loud))M.push(C('velvet',10,'"The freezer door came off its hinges. Old building. Old door."',null,null,{id:'c_door',ok:st=>{st.prog+=2;return [L('miller','Huh. My building\'s the same. Radiator fell off the wall in March.')];},no:st=>{st.threat+=2;return [L('miller','Doors don\'t just come off. Somebody takes them off.')];}}));
    if(r===2&&!(S.flags.doorTorn||S.flags.loud))M.push(C('gutter',8,'"Walk-in compressor\'s busted. Margo won\'t pay for the repair."',null,null,{id:'c_comp',ok:st=>{st.prog+=2;return [L('miller','Sounds like every landlord I\'ve ever had.')];},no:st=>{st.threat+=1;return [L('miller','Then why\'s it this cold out *here*?')];}}));
    if(r===1&&G.equipped('apron'))M.push({t:'"Band saw. Brisket. I work here."',ok:st=>{st.prog+=2;return [L('miller','...Right. Yeah. Apron. Okay.')];}});
    // generics
    M.push(C('velvet',10,'Lie. Smoothly.',null,null,{id:'c_lie'+r,ok:st=>{st.prog+=2;return [L('velvet','There. Every word of it slid in like a key.'),L('miller','Mm-hm.')];},no:st=>{st.threat+=2;return [L('miller','You paused before you answered. People only do that when they\'re choosing which version to tell me.')];}}));
    M.push(C('stagecraft',10,'Act alive. Breathe, blink, rub your arms against the cold.',null,null,{id:'c_alive'+r,ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [L('stagecraft','A little cloud of breath you had to fake from your own cold lungs. A blink. A sniff. Perfect. Award-winning.')];},no:st=>{st.threat+=2;return [L('miller','Are you... holding your breath?')];}}));
    if(!S.once[once('dots')])M.push(C('nostalgia',8,'"Is that Dot\'s? Get the pie next time. The cherry."',null,null,{id:'c_dots',once:once('dots'),ok:(st,S,G)=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);G.rel('miller',1);return [L('miller','...The cherry\'s good. I never finish it. I keep meaning to.')];},no:st=>{st.threat+=1;return [L('miller','I don\'t eat pie.')];}}));
    M.push(C('gutter',10,'Talk like a night-shift lifer. Tired, bored, unimpressed.',null,null,{id:'c_gut'+r,ok:st=>{st.prog+=2;return [L('miller','Yeah. Yeah, I know the type. I *am* the type.')];},no:st=>{st.threat+=1;return [L('gutter','Too much. You sound like a movie.')];}}));
    if(!st.readHer&&!S.once[once('read')])M.push(C('pulse',10,'Read her. What does she actually want?',null,null,{id:'c_read',once:once('read'),ok:(st)=>{st.readHer=true;return [L('pulse','Every question she asks is about Leo, and every look is at the posters. She isn\'t here for Leo. She\'s here for someone who never came home.')];},no:st=>[L('pulse','She\'s a closed book with a cop\'s bookmark in it.')]}));
    if(st.readHer&&!S.once[once('bro')])M.push(C('pulse',8,'"Who did you lose, Detective?"',null,null,{id:'c_bro',once:once('bro'),ok:(st,S,G)=>{st.prog+=3;st.threat=Math.max(0,st.threat-2);G.rel('miller',2);G.fact('miller','brother');G.fact('miller','seven');return [L('miller','...My brother. Mateo. 2011. He walked to the corner shop for cigarettes, right around here, and never walked back.'),L('miller','Seven people in two months. Nobody at the precinct wants to call it a pattern. I\'m calling it a pattern.')];},no:st=>{st.threat+=2;return [L('miller','That\'s none of your business.')];}}));
    if(st.offclock&&!S.once[once('off')])M.push({t:'"Shouldn\'t you be off the clock, Detective? Your lieutenant seems to think so."',once:once('off'),ok:(st,S,G)=>{st.prog+=3;G.fact('miller','offclock');return [L('miller','...How do you know that?'),L('miller','Don\'t answer. I don\'t want to know. Fine. Fine.')];}});
    M.push(C('apex',12,'Stare her down until she blinks.',null,null,{id:'c_apex'+r,ok:st=>{st.prog+=2;st.threat+=1;return [T('She blinks first. She doesn\'t like that she blinked first.')];},no:st=>{st.threat+=3;return [L('miller','Are we doing a staring contest? I do this for a living.')];}}));
    // items
    if(G.has('cash')&&!S.once[once('cash')])M.push({t:'Slide the register cash across the counter.',once:once('cash'),ok:(st,S,G)=>{st.threat+=3;G.rel('miller',-1);return [L('miller','Put that away before I pretend I didn\'t see it. I\'m not that kind of cop. I\'m too tired to be that kind of cop.')];}});
    if(tedReady(S)&&!st.teddyOut&&r<3)M.push({t:'Call Leo out from the back.',ok:(st,S,G)=>{st.teddyOut=true;st.prog+=3;return STORY.teddyOut(st,S,G);}});
    // abilities
    const ab=(id,t,fn,extra)=>M.push(Object.assign({t,ab:id,ok:fn},extra||{}));
    ab('kneel','"Go home, Detective. There\'s nothing here."',(st,S,G)=>{st.result='dominated';G.offer('darwin');return [T('One word, the way the Tenant would say it: low, certain, already done. Her feet obey before the rest of her does.'),L('miller','...There\'s nothing here. I should go home.')];});
    ab('kneel','Royal Decree: "Go home. Forget the boy. Call his mother and tell her he\'s fine."',(st,S,G)=>{st.result='dominated';S.flags.decreeMiller=1;return [T('You stack the commands like plates and she carries every one of them out of the door.')];},{t2:true});
    ab('fog','Take the last fifteen minutes back.',(st,S,G)=>{st.result='unseen';S.flags.fogMiller=1;return [T('You reach into her like a hand into a coat pocket and take out the last quarter of an hour. She blinks at the shop, at the cold, at you, as if she has walked into the wrong room.'),L('miller','...Sorry. I think I\'ve got the wrong address.')];});
    if(!st.blue)ab('blueblood','Feel where she sits in the pecking order.',(st,S,G)=>{st.blue=true;st.offclock=true;st.prog+=1;return [T('The weight of her comes to you like a smell: no partner, no backup, a lieutenant who wants her gone. Nobody knows she is here.')];});
    if(!st.readHer)ab('coldread','Hear the thing she\'s loudest about not saying.',(st,S,G)=>{st.readHer=true;st.prog+=1;G.fact('miller','brother');return [T('Her silence comes through like a siren: *Mateo. Mateo. Mateo. It\'s been fifteen years and I still check every face.*')];});
    if(!st.dv)ab('dejavu','Live the next answer badly, then rewind it.',(st)=>{st.dv=true;st.threat=Math.max(0,st.threat-2);st.prog+=1;return [T('You watch yourself say the wrong thing, watch her hand drift to her holster, and then you are back two seconds earlier with your mouth already closing.')];});
    ab('splinter','Splinter: give her a sudden horror of the back room.',(st)=>{st.result='scared';return [T('You lodge a sliver of dread in her like glass in a foot. The swing door. The cold behind it. Something hanging. She takes a step back without knowing why.'),L('miller','I — I\'ll be. I\'ll be in touch.')];});
    ab('nerve','Pinch the nerve under your own jaw until the blood rushes into your face.',(st)=>{st.warm=true;st.threat=Math.max(0,st.threat-2);return [T('You find the nerve and lean on it. Your cheeks flush, your hands pinken, your lips go from dead-grey to merely tired.')];});
    ab('encore','Encore: lock her into repeating the last five seconds.',(st)=>{st.prog+=2;return [T('She asks her question. She asks her question again, with exactly the same tilt of the head. A third time. When it lets go of her she has lost her thread entirely.'),L('miller','...Where was I?')];});
    ab('siren','Siren\'s Pitch: "What do you actually want, Detective?"',(st,S,G)=>{st.readHer=true;st.prog+=3;st.threat=Math.max(0,st.threat-1);G.fact('miller','brother');return [L('miller','I want to find one of them alive. Just one. Before I stop being able to tell the difference.'),L('pulse','She didn\'t mean to say that. She is looking at her own mouth as if it belongs to someone else.')];});
    ab('miasma','Breathe out slowly. Let it smell like a gas leak.',(st)=>{st.result='gas';return [T('A grey-green breath curls out of you and spreads along the floor. It smells like rotten eggs and a funeral home.'),L('miller','Is that — is that *gas*? Out. Out, out, *out*.')];});
    ab('veil','Go still in the shadow behind the counter, and stop being there.',(st)=>{st.result='unseen';return [T('You become furniture, then less than furniture. She keeps talking for another minute, to the counter, then to the shop in general, then stops, confused.'),L('miller','...Hello?')];});
    ab('pack','Alpha Howl: call every dog on the Strip.',(st)=>{st.result='dogs';return [T('Out on Ferrier Street, every dog for six blocks starts barking at once. Something big hits her car door. The alarm starts screaming.'),L('miller','Oh, you have *got* to be kidding me.')];},{t2:true});
    if(!st.sniffed)ab('scent','Smell where she\'s been tonight.',(st,S,G)=>{st.sniffed=true;st.prog+=1;G.fact('miller','coffee');return [T('Burnt coffee from the Lucky Mart. Gun oil. A hospital corridor. A man\'s aftershave on her sleeve, expensive and federal.')];});
    ab('ward','Seal the swing door behind you with a line of your blood.',(st,S,G)=>{st.threat=Math.max(0,st.threat-2);S.flags.wardBack=1;return [T('You lean on the swing door and draw a line along its edge with a bitten thumb. Later, when she tries it, it will not open, and she will decide it was always stiff.')];});
    ab('vintage','Taste the drop of coffee she spilled on the counter.',(st)=>{st.prog+=2;st.threat=Math.max(0,st.threat-1);return [T('Caffeine, ibuprofen, two hours of sleep, a cold coming on, and under it a grief fifteen years old. You know her next three questions. You have answers waiting.')];});
    ab('shadowstep','While she blinks, step through the dark and fix everything.',(st)=>{st.threat=Math.max(0,st.threat-3);return [T('Into the shadow under the counter and out of the one by the freezer: the cartons stacked, the ash brushed off, the hook swung still. She opens her eyes on a tidier world.')];});
    ab('snuff','Snuff: kill her radio and the bodycam on her lanyard.',(st,S,G)=>{st.threat=Math.max(0,st.threat-2);S.flags.noRecording=1;return [T('Every light in the shop dies for a heartbeat. Her radio pops. The little red light on her lanyard camera does not come back.'),L('miller','Oh, come *on*. Brand new.')];});
    if(!st.offclock)ab('spark','Touch the counter near her radio and listen to the spark.',(st)=>{st.offclock=true;return [T('A crackle jumps from your fingertip into her earpiece. Under it, a bored dispatcher: *Miller, you\'re off the clock. Lieutenant says go home. Repeat, go home.*')];});
    ab('badluck','Bad Luck Charm: let her fumble.',(st)=>{st.prog+=2;return [T('Her cup slips. Coffee everywhere: her shoes, her notebook, the posters. By the time she is done swearing and mopping, she has forgotten what she just asked.')];});
    ab('claws','End this. One strike.',(st)=>{st.result='attack';return [T('You move.')];});
    ab('boil','Boil the Vein: heat her blood until she wants to leave.',(st)=>{st.result='scared';return [T('You think about her blood, and it listens. She goes red at the collar, then white. Sweat on her lip in a room as cold as a fridge.'),L('miller','I — need some air. I\'ll be in touch.')];});
    M.push(C('frenzy',13,'Go for her throat.',null,null,{id:'c_frenzy',red:true,ok:st=>{st.result='attack';return [T('You move.')];},no:st=>{st.result='shot';return [T('You move. She is faster than she looks.')];}}));
    return M;},
  decide(st,S,G){return (st.prog>=5||st.threat<6)?'win':'lose';},
  outro(r,st,S,G){
    S.flags.calloOutcome=r;
    const map={
      win:[L('miller','Okay. Okay. If Leo turns up, you call me. Here.'),T('She leaves a card on the counter: DET. I. MILLER · MISSING PERSONS · PRECINCT 9, and a mobile number written on the back in biro.'),T(null,{do:(S,G)=>{G.rel('miller',1);G.fact('miller','seven');}})],
      leo:[L('miller','Come on, Leo. Your mom\'s waiting. I\'ll drive you.'),T('She looks back at you from under the shutter, a long careful look, as if she\'s taking a photograph for later.'),L('miller','One down. Six to go.',{do:(S,G)=>{G.rel('miller',1);G.fact('miller','seven');S.flags.tedGone=1;}})],
      lose:[L('miller','I\'ll be back. With a warrant, a partner, and a lot more coffee.'),T('She doesn\'t leave a card. She doesn\'t need to. She knows exactly where you are.',{do:(S,G)=>{G.heat(1);G.rel('miller',-1);}})],
      dominated:[T('She leaves without another word, walking very carefully, like someone carrying a full glass.'),L('pulse','She\'ll wake tomorrow with a blank hour and a headache. People like her hate blank hours.',{do:(S,G)=>G.rel('miller',-1)})],
      scared:[T('She backs out under the shutter and is in her car before you hear the door.'),L('web','She\'ll tell herself it was the cold, and the hour, and too much coffee. It works for about a week.',{do:(S,G)=>G.heat(1)})],
      shattered:[T('After a while she gets up, picks up her cup, and leaves without looking at you.'),L('pulse','You did that. You know what that was. You did it anyway.',{do:(S,G)=>{G.comp(-1,'You broke her open');G.heat(1);G.rel('miller',-2);}})],
      gas:[T('She\'s out under the shutter in seconds, coughing, already on her phone to the gas company.'),L('gutter','They\'ll be here by dawn. With meters. Better be gone.',{do:(S,G)=>G.heat(1)})],
      unseen:[T('She leaves a card on the counter "for whoever\'s in charge" and goes, rubbing her eyes.'),L('stagecraft','The trick is not to be interesting. You\'ve never been less interesting in your life.')],
      dogs:[T('She runs. Somewhere up the block a German shepherd is sitting on her bonnet like a hood ornament.'),L('gutter','She\'ll be back. But not tonight.')],
      muse:[T('She leaves already dialling, muttering about delivery schedules and the back entrance at St. Jude\'s.'),L('web','You just sent a Missing Persons detective straight at Margo\'s supply line. That is either very smart or very, very stupid.',{do:S=>S.flags.calloAda=1})],
      attack:[T('You are on her before the coffee hits the floor. She goes down hard. Not dead. You check. Twice.',{fx:['shake:1.8','sfx:crash']}),
        T('You carry her out to her car through the rain, put her in the driver\'s seat, and set her coffee in the cup-holder. She\'ll wake with a headache and a story nobody at the precinct will believe.'),
        L('pulse','You knocked out a detective who came looking for a missing boy.',{do:(S,G)=>{G.comp(-2,'You attacked a detective');G.heat(2);G.rel('miller',-3);}})],
      shot:[T('The gun is out before you\'ve crossed the tiles. Two shots. Both hit. It\'s much, much louder than you\'d expect.',{fx:['shake:2.5','sfx:crash','hurt:1.5']}),
        T('You don\'t fall down. That frightens her more than anything else could have. She backs out under the shutter with the gun up, already shouting into her radio.',{do:(S,G)=>{G.vitae(-3);G.comp(-2,'You were shot');G.heat(3);G.rel('miller',-3);}}),
        L('sundial','Leave. Leave NOW.')],
      found:[T('You hear her stop. You hear her say, very quietly, "Jesus Christ."'),T('When she comes back through the swing door her gun is in one hand and the other arm is around Leo, who is grey and shaking and still wearing the cuffs.'),
        L('miller','Don\'t. Move.'),T('She backs out under the shutter with him, into the rain, and the gun never leaves the middle of your chest.',{do:(S,G)=>{G.heat(3);G.rel('miller',-3);G.rel('leo',-1);S.flags.tedGone=1;S.flags.tedRescuedByCop=1;}})]
    };return map[r]||map.win;}
};

/* ======================= STORY OBJECT ======================= */
const STORY={nodes:N,enc:ENC,
  unknownName(id,S){return {leo:'Young man',miller:'Detective',severine:'Woman on the line',pemberton:'Old man',margo:'Margo'}[id];},
  gameovers:{
    sleep:{k:'The sun rose on Tuesday',t:'Five More Minutes',d:'You slept through the night, and then through the morning, and at nine minutes past five somebody opened the freezer door to let the daylight in. After that, the Sheriff\'s remains and your own were very hard to tell apart.',a:'Rewind, and try opening your eyes.'},
    torpor:{k:'Vitae: zero',t:'Torpor',d:'You spent the last of the blood. The Beast curls up inside you like a dog in front of a dead fire and takes you down with it. Somebody will find you in a few decades. Probably Margo\'s grandchildren.',a:'Rewind to your last save.'}},
  tasteNote:S=>TASTES[((S.flags.drankBag||1)-1)%TASTES.length],
  bagRes:S=>['melancholic','choleric','sanguine','phlegmatic','sanguine'][((S.flags.drankBag||1)-1)%5],
  readItem(id,S,G){
    if(id==='notebook'){const r=NL.ITEMS.notebook.read;return r.map(x=>`<p>${G.esc(x)}</p>`).join('')+(S.flags.tedState==='ally'?'<p><i>New, in fresh biro: "The night shift." Underlined three times.</i></p>':'');}
    if(id==='ledger'){if(!S.checks.ledger_web||!S.checks.ledger_web.ok)return '<p>Columns of dates, pints and prices. Initials. Your eyes keep sliding to the fresh ink at the bottom of the page.</p>';
      return '<p>TUES · ST. ADA\'S — 40 pt · 2,400<br>THURS · G.H. — 38 pt · 15,200<br>A.C. — 10%</p><p><i>Last entry, today, different pen: "New arrangement. S. says the Sheriff is a problem."</i></p>';}
    if(id==='burner')return '<p>Twelve missed calls from S. One text, unread: <i>"Friday. Don\'t make me come down there. — S."</i></p>';
    return '<p>'+G.esc(NL.ITEMS[id].d)+'</p>';},
  breachWitness(S,G){if(S.room==='front'&&S.flags.calloArrived&&!S.flags.calloGone)return 'Detective Miller sees all of it. Her coffee hits the tiles.';
    if(G.actor('leo'))return 'Leo sees all of it. He makes a very small sound and doesn\'t make another.';return null;},
  onEquip(id,S,G){if(id==='greatcoat'&&G.once('coat_on'))G.toast('dos','The Tenant approves. Mostly.','Sheriff\'s Greatcoat');},
  barks(room,S,G){return ({
    freezer:[{id:'fz_bags',s:'parasite',at:[0.6,1.2,1.5],r:1.5,t:'That is not pork.'},{id:'fz_door',s:'sundial',at:[4.8,1,0.3],r:1.4,t:'Locked. Of course it\'s locked.',if:S=>!S.flags.doorOpen&&!S.flags.doorTorn},
      {id:'fz_ash',s:'autopsy',at:[2.2,.3,1.85],r:1.2,t:'He died kneeling.',pass:8},{id:'fz_pig',s:'nostalgia',at:[1.35,1.6,3.9],r:1.3,t:'Christmas ham.'}],
    backroom:[{id:'br_saw',s:'abattoir',at:[4.4,1,0.6],r:1.5,t:'Nine minutes per Sheriff.'},{id:'br_sink',s:'nostalgia',at:[2.8,1,0.6],r:1.3,t:'Warm water. Remember baths?'},
      {id:'br_desk',s:'pedigree',at:[7.6,1,3.7],r:1.5,t:'"IF COURT CALLS." Capital C.'},{id:'br_knives',s:'frenzy',at:[0.4,1.6,1.45],r:1.4,t:'Pick one. Any one.'},{id:'br_cab',s:'echo',at:[8.4,1,2.3],r:1.3,t:'A drawer marked COURT. Empty.',pass:8}],
    front:[{id:'fr_case',s:'frenzy',at:[3.6,1,2.4],r:1.4,t:'MEAT.',if:S=>S.vitae<4},{id:'fr_wet',s:'rigor',at:[5.6,.5,4.2],r:1.2,t:'You could stand here for hours.'},{id:'fr_tv',s:'web',at:[1.1,2,0.6],r:1.6,t:'Seven missing. Seven.'}],
    alley:[{id:'al_post',s:'echo',at:[0.5,1.5,1.5],r:1.6,t:'Missing. Missing. Missing.'}]}[room]||[]);},
  npcInter(room,S,G){const L_=[];
    if(G.actor('leo'))L_.push({id:'leo',actor:'leo',label:()=>S.dos.leo?'Leo':'Young man'});
    if(G.actor('miller')&&!S.flags.calloGone)L_.push({id:'miller',actor:'miller',label:'Detective'});
    if(G.actor('pemberton'))L_.push({id:'pemberton',actor:'pemberton',label:()=>S.dos.pemberton?'Pemberton':'Old man'});
    return L_;},
  populate(room,S,G){const C_=NL.CHARS;
    if(room==='freezer'&&!S.flags.tedInBack&&!S.flags.tedGone){
      if(!S.flags.tedFreed){const a=G.addActor('leo',C_.leo.spec,{x:4.7,z:3.9,ry:-2.5,breathes:true,pose:'hang'});a.panic=true;a.y=0;}
      else G.addActor('leo',C_.leo.spec,{x:4.6,z:3.45,ry:-2.3,breathes:true,pose:'slump'});}
    if(room==='backroom'&&S.flags.tedFreed&&S.flags.tedInBack&&!S.flags.tedGone){const a=G.addActor('leo',C_.leo.spec,{x:2.55,z:1.35,ry:0.35,breathes:true,pose:'sit'});a.solid=true;}
    if(room==='front'&&S.flags.calloArrived&&S.flags.calloIn&&!S.flags.calloGone)G.addActor('miller',C_.miller.spec,{x:1.5,z:4.2,ry:1.2,breathes:true,pose:'hold'});
    if(room==='alley')G.addActor('pemberton',C_.pemberton.spec,{x:5.2,z:2.75,ry:-2.2,breathes:true,pose:'umbrella'});
    if(room==='freezer'&&Wd().player&&S.chapter==='freezer'&&!S.flags.woke)Wd().player.setPose('lie',30);},
  async use(id,S,G){
    const map={ash:'ash.0',coat:'coat.0',shelf:'shelf.0',pig:'pig.0',door:'door.0',boxes:'boxes.0',bulb:'bulb.0',
      sink:'sink.0',saw:'saw.0',rack:'rack.0',knives:'knives.0',table:'table.0',cabinet:'cabinet.0',desk:'desk.0',
      register:'register.0',case:'case.0',chalk:'chalk.0',tv:'tv.0',wetfloor:'wetfloor.0',poster:'poster.0',
      car:'car.0',graffiti:'graffiti.0',posters:'posters.0',dumpster:'dumpster.0'};
    if(id==='leo'){if(S.room==='freezer'&&!S.flags.tedFreed)return G.talk(S.seen['leo.0']?'leo.again':'leo.0');
      if(S.room==='freezer')return G.say([L('leo','I\'m good. I\'m sitting. I\'m going to follow you out of here the second that door opens.')]);return G.talk('tedf.0');}
    if(id==='pemberton')return G.talk('pem.0');
    if(id==='mirror')return G.talk('mirror.pre');
    if(id==='phone')return G.talk(S.flags.phoneRinging?'call.0':'phone.idle');
    if(id==='shutter'){if(S.flags.calloGone)return G.talk('shutter.after');if(S.flags.calloArrived)return G.talk('shutter.knock');return G.talk('shutter.pre');}
    if(id==='backdoor')return STORY.backdoor(G,S);
    if(map[id])return G.talk(map[id]);},
  async exit(it,S,G){
    if(it.id==='toBack'&&!S.flags.tedFreed&&!S.flags.tedGone&&!S.flags.leftTed){S.flags.cancelExit=0;await G.talk('leo.leave');if(S.flags.cancelExit){S.flags.cancelExit=0;return false;}S.flags.leftTed=1;}
    if(it.id==='toBack'&&S.flags.tedFreed)S.flags.tedInBack=1;
    if(it.id==='toFront'&&!S.clan){await G.say([L('tenant','Not out there. Not yet. Find a *mirror* first; I want to know what I\'m wearing.')]);return false;}
    if(it.id==='toFront'&&S.flags.phoneRinging){await G.say([L('sundial','The phone. Answer the phone. Or don\'t. But decide.')]);}
    return true;},
  async onEnter(room,S,G){
    if(room==='backroom'&&S.flags.phoneRinging&&!S.flags.callDone)A.ringStart();else A.ringStop();
    if(room==='backroom'&&!S.flags.enteredBack){S.flags.enteredBack=1;S.chapter='backroom';
      G.cine(true);G.focus(['you'],1.6);await G.wait(.6);
      if(S.flags.tedFreed){const a=G.actor('leo');if(a){a.x=1.2;a.z=0.4;a.setPose('idle');G.walk('leo',2.55,1.6).then(()=>{G.place('leo',2.55,1.35,0.35);G.pose('leo','sit',3);});}}
      await G.say([T('Warmer in here, or it would be, if you were the kind of thing that noticed warmth. Fluorescent tubes buzz overhead. Red quarry tiles, a cutting table, a band saw, and in the far corner a little washroom with its door propped open.'),
        L('tenant','There will be a mirror in there. Go and look. I want to see what I\'ve become. What *we\'ve* become. God help us both.')]);
      G.task('mirror');G.cine(false);G.focus(null);}
    if(room==='front'&&!S.flags.enteredFront){S.flags.enteredFront=1;
      await G.say([T('The shop floor. Black-and-white tiles, a long glass case of meat lit like a jeweller\'s window, and the steel shutter pulled down over the street. Pink neon bleeds through the slats.'),
        L('miller','Port Vellum PD! Come on. I can see you moving in there.',{if:S=>S.flags.calloArrived&&!S.flags.calloIn,fx:'sfx:knock'})]);}
    if(room==='alley'&&!S.flags.enteredAlley){S.flags.enteredAlley=1;S.chapter='alley';A.music('night');G.cine(true);await G.wait(.8);G.cine(false);await G.talk('pem.0');}
  },
  async start(S,G){
    S.chapter='cold';document.body.classList.add('coldopen');G.blackout(true);A.music(null);A.ambience('dark');
    await G.enterRoom('freezer',null,{instant:true,noCard:true,noEnter:true});
    Wd().world.fadeTarget=1;Wd().world.fade=1;Wd().player.setPose('lie',40);Wd().player.cur=NL.POSES.lie(Wd().player,0);
    G.blackout(false);
    await G.wait(1.2);
    await G.talk('cold.0');},
  async wake(G){const S=G.S;S.chapter='freezer';S.flags.woke=1;document.body.classList.remove('coldopen');
    G.cine(true);G.camSpeed(40);G.focus(['you'],.5);await G.wait(.2);G.camSpeed(1.2);
    Wd().world.fadeSpeed=.7;Wd().world.fadeTarget=0;A.ambience('freezer');A.music('night');
    await G.wait(2.4);
    await G.card('Night One','Monday · 9:02 PM · The Marrow Ward, Port Vellum',{k:'The New Lord · Prologue',cls:'loc',hold:3});
    G.pose('you','crouch',1.4);await G.wait(1.8);G.pose('you','idle',2.2);await G.wait(1.2);
    G.focus(['you','leo'],.8);G.look('you','leo');
    await G.say([L('leo','Oh no. Oh no no no. It\'s up. It\'s *up*.'),
      L('stagecraft','You are standing in a freezer. You should be shivering. You aren\'t. You should be breathing. You aren\'t doing that either.'),
      L('sundial','Eight hours until dawn. Spend them wisely. Spend them *anywhere but here*.')]);
    G.look('you',null);G.focus(null);G.camSpeed(3.2);G.cine(false);
    G.task('freezer');G.task('what');
    await G.wait(.6);G.toast('task','Tap the floor to walk. Tap a marker to look closer.','How to play');
    G.autosave();},
  async mirror(G,S){await openMirror(G,S);},
  async ringPhone(G,S){S.flags.phoneRinging=1;A.ringStart();
    await G.say([T('Somewhere in the back room, a telephone starts to ring. An old one, with real bells.',{fx:'shake:.2'}),
      L('tenant','Don\'t answer that. — No. Answer it. It\'ll be *her*. It\'s always her.')]);G.task('phone');},
  async knock(G,S){S.flags.phoneRinging=0;A.ringStop();await G.wait(1.4);G.sfx('knock',{n:3});G.shake(.4);await G.wait(1.1);G.sfx('knock',{n:3});
    S.flags.calloArrived=1;
    await G.say([T('Then, from the front of the shop: knocking. Heavy, patient, official. A flashlight beam slides under the swing door and sweeps the tiles.'),
      L('miller','Port Vellum PD! I can see the light\'s on, Mr. Pruitt. I just want to talk.'),
      L('gutter','Cop knock. Three, pause, three. They teach it at the academy.',{pass:6}),
      L('leo','That\'s — that\'s for *me*? Oh God, my mom called the cops.',{if:S=>G.actor('leo')}),
      L('sundial','You have time. Some time. Not much.')]);
    G.task('front');A.music('tense');G.autosave();},
  async calloIn(G,S){G.cine(true);G.sfx('rattle');S.flags.shutterUp=1;G.rebuildRoom();
    const a=G.addActor('miller',NL.CHARS.miller.spec,{x:0.55,z:4.15,ry:1.4,breathes:true,pose:'hold'});a.solid=true;S.flags.calloIn=1;
    G.focus(['you','miller'],1);await G.wait(.3);await G.walk('miller',1.6,4.0);G.face('miller',Wd().player.x,Wd().player.z);
    if(Math.hypot(Wd().player.x-1.6,Wd().player.z-4)>2.2)await G.walkTo(2.7,3.6);G.face('you',1.6,4.0);await G.wait(.4);G.cine(false);G.rebuildInter();},
  async calloOut(G,S){
    const r=S.flags.calloOutcome;G.cine(true);
    const ted=G.actor('leo');
    if(r==='shattered')G.pose('miller','slump',2);
    await G.wait(r==='shattered'?2:.6);
    if(r==='attack'){G.pose('miller','slump',4);await G.wait(1.5);}
    G.pose('miller','idle');
    const go=G.walk('miller',0.45,4.15);if(ted){await G.wait(.4);G.walk('leo',0.6,3.7);}
    await go;G.removeActor('miller');if(ted&&S.flags.tedGone){await G.wait(.6);G.removeActor('leo');}
    S.flags.calloGone=1;G.rebuildRoom();G.task('front','done');G.focus(null);G.cine(false);
    await G.wait(1.2);G.sfx('horn');await G.wait(.6);
    await G.say([T('From the alley behind the shop: a car horn. Two notes, polite and unhurried, like a butler clearing his throat.'),
      L('tenant','...Pemberton.'),L('sundial','Whoever it is, they\'re early. Everyone tonight is early, except you.')]);
    S.flags.hornHeard=1;G.task('leave');A.music('night');G.autosave();},
  async backdoor(G,S){
    if(!S.flags.calloArrived)return G.say([T('A heavy wooden back door with a chain through the handle and a padlock the size of a fist.'),L('tenant','And go *where*? We don\'t know who did this. Find a mirror first. Then we can talk about doors.',{if:S=>!S.clan}),L('sundial','Not yet. Something is coming. You can feel it, like weather.',{if:S=>!!S.clan})]);
    if(!S.flags.calloGone)return G.say([T('A flashlight beam sweeps under the back door too. There\'s a second car idling in the alley.'),L('echo','Going out this way means walking straight into it. Deal with the front.')]);
    return G.talk('bd.0');},
  teddyOut(st,S,G){const out=[];const s=S.flags.tedState;
    out.push(T('Leo shuffles out through the swing door in a blanket of flattened cartons.',{do:(S,G)=>{const a=G.addActor('leo',NL.CHARS.leo.spec,{x:7.9,z:0.8,ry:0.3,breathes:true});a.solid=false;G.walk('leo',2.6,3.3);}}));
    if(s==='forgot')out.push(L('leo','Detective! Hi! I fell asleep in the walk-in. Ammonia, I think? I had the *wildest* nightmare. Is my mom mad?'));
    else if(s==='ally')out.push(L('leo','I\'m fine. I fell asleep in the walk-in and this nice night-shift person found me. Long night. *Very* long night. Hi.'),L('pulse','He winks at you. Badly. She doesn\'t see it.'));
    else if(s==='thrall')out.push(L('leo','Everything\'s GREAT, Detective! I love my job! I love everyone here!'),L('miller','...Are you on something, Leo?'));
    else if(s==='paid')out.push(L('leo','I didn\'t see anything. I mean — I was asleep. In the freezer. So I didn\'t see anything. Because I was asleep.'));
    else out.push(L('leo','I\'m okay! I\'m okay. I just — I got stuck in the walk-in. It\'s been a weird night.'),L('miller','Leo, what happened to your *neck*?',{if:S=>!S.flags.tedHealed}));
    out.push(T(null,{do:(S,G)=>{st.result=(s==='thrall'||(!['forgot','ally','paid'].includes(s)&&!S.flags.tedHealed))?null:'leo';if(s==='thrall'||(!['forgot','ally','paid'].includes(s)&&!S.flags.tedHealed))st.threat+=2;}}));
    out.push(L('miller','Okay. Okay, Leo. You\'re coming with me. Your mom\'s been calling every hour.',{if:()=>st.result==='leo'}));
    return out;},
  async ending(G,S){S.chapter='end';G.cine(true);
    const car=[6.4,2.9];await G.walkTo(car[0],car[1]);G.face('you',6.6,3.6);await G.wait(.6);
    G.sfx('door');Wd().world.fadeSpeed=.5;Wd().world.fadeTarget=1;A.music('end');await G.wait(2.6);
    Wd().player.visible=false;
    await G.card('The New Lord','Prologue · The Sun-Bleached Crime Scene',{cls:'title',hold:4.2});
    showSummary(G,S);}
};
const Wd=()=>NL.G.Wd;

/* ----- back door ----- */
N['bd.0']={lines:[T('A heavy wooden back door. A chain through the handle and a padlock the size of a fist.'),
  L('parasite','An engine idling outside. And one heartbeat, slow as a metronome. Sixty a minute, exactly.',{pass:6})],next:'bd.hub'};
N['bd.hub']={opts:[O('Unlock the padlock.','bd.open',{item:'backkey'}),O('Tear the chain apart with Iron Claws.','bd.wither',{ab:'claws'}),O('Bone-Key: dislocate a finger and pick it.','bd.open',{ab:'bonekey'}),O('Step into the dark under the door and out of the dark beyond it.','bd.wall',{ab:'shadowstep'}),
  C('frenzy',10,'Snap the chain.','bd.snap','bd.snapNo',{id:'bd_frenzy'}),O('Not yet.',null,{end:true,leave:true})]};
const bdOpen=(S,G)=>{S.flags.backDoorOpen=1;G.rebuildRoom();};
N['bd.open']={lines:[T('The key turns with a gritty click. The chain slides free and pools on the tiles.',{fx:'sfx:metal',do:bdOpen})],end:true};
N['bd.wither']={lines:[T('You close your hand around the padlock. It goes brown, then orange, then soft, then nothing at all. Rust sifts through your fingers like cinnamon.',{do:bdOpen})],end:true};
N['bd.wall']={lines:[T('You put your hand flat on the door and push, and your hand goes *in*. Cold wood, dark grain, the inside of a knot. Then you\'re through, and the rain is on your face.',{do:bdOpen})],cs:async(G)=>{G.dlgHide();await G.enterRoom('alley',{x:2.5,z:0.9,ry:0.2});},end:true};
N['bd.snap']={lines:[T('You wrap the chain around your fist and pull. The links stretch like taffy and part with a crack like a gunshot.',{fx:['sfx:metal','shake:.8'],do:bdOpen})],end:true};
N['bd.snapNo']={lines:[T('The chain holds. Your fingers don\'t, entirely. They slide back into place on their own, which is new, and horrible.',{do:(S,G)=>G.comp(-1,'Your fingers broke')})],next:'bd.hub'};

/* ======================= MIRROR UI ======================= */
function openMirror(G,S){return new Promise(resolve=>{
  const $=G.$,h=G.h,esc=G.esc;const m=$('#mirror');m.hidden=false;A.music('mirror');
  requestAnimationFrame(()=>m.classList.add('in'));
  let step=0;const pick={past:S.past||null,clan:S.clan||null,look:Object.assign({},S.look)};
  const preview=()=>{const save={clan:S.clan,look:S.look};S.clan=pick.clan;S.look=pick.look;const spec=G.playerSpec(true);
    const c=pick.clan?NL.CLANS[pick.clan]:null;if(c){spec.eyeGlow=c.glow.map(v=>v*.9);if(c.mismatch)spec.eyes2=c.mismatch;if(c.ghost)spec.alpha=.1;}
    S.clan=save.clan;S.look=save.look;return spec;};
  const host=$('#miCan');
  const refresh=()=>{const c=pick.clan?NL.CLANS[pick.clan]:null;m.style.setProperty('--aura',c?c.aura:'#6b6f80');m.dataset.clan=pick.clan||'';
    const P=NL.G._portraitInto;P(host,'mirror_'+(pick.clan||'x')+'_'+JSON.stringify(pick.look),preview(),{rim:c?hex(c.aura):[.5,.5,.6],zoom:.78});render();};
  const render=()=>{const box=$('#miStep');let html='';
    if(step===0){html=`<div class="mk">I · Memory</div><h2>Who were you, before?</h2><p class="mlede">The face in the glass is smeared with somebody else\'s years. Underneath, something of yours is still there. Reach for it.</p><div class="mgrid">`+
      Object.entries(NL.PASTS).map(([k,p])=>`<button class="mcard ${pick.past===k?'sel':''}" data-past="${k}"><b>${esc(p.name)}</b><span>${Object.entries(p.attrs).map(([a,v])=>`<em style="--c:${NL.ATTRS[a].color}">${esc(NL.ATTRS[a].name)} +${v}</em>`).join(' ')}</span><small>${esc(p.mem)}</small></button>`).join('')+'</div>';}
    if(step===1){const L_=NL.LOOKS;const chips=(arr,names,key,colorize)=>arr.map((v,i)=>`<button class="chip ${pick.look[key]===i?'sel':''}" data-look="${key}" data-i="${i}">${colorize?`<i style="background:rgb(${v.map(x=>Math.round(x*255)).join(',')})"></i>`:''}${esc(names[i])}</button>`).join('');
      html=`<div class="mk">II · The face</div><h2>Lean closer.</h2><p class="mlede">Paler than it was. It will get paler.</p><h5>Skin</h5><div class="chips">${chips(L_.skin,L_.skinNames,'skin',true)}</div><h5>Hair</h5><div class="chips">${chips(L_.hair,L_.hairNames,'hair')}</div><h5>Color</h5><div class="chips">${chips(L_.hairCol,L_.hairColNames,'hairCol',true)}</div>`;}
    if(step===2){const c=pick.clan?NL.CLANS[pick.clan]:null;
      html=`<div class="mk">III · The blood</div><h2>Examine your fangs, your eyes, your aura.</h2><div class="clist">`+NL.CLAN_ORDER.map(k=>{const cc=NL.CLANS[k];return `<button class="cl ${pick.clan===k?'sel':''}" data-clan="${k}" style="--c:${cc.aura}"><b>${esc(cc.name)}</b><span>${esc(cc.ep)}</span></button>`;}).join('')+'</div>';
      if(c)html+=`<div class="cdet" style="--c:${c.aura}"><p>${esc(c.d)}</p><div class="cmods">${Object.entries(c.mods).map(([k,v])=>`<span class="${v>0?'up':'dn'}">${esc(NL.SKILLS[k].name)} ${v>0?'+':''}${v}</span>`).join('')}</div><div class="cabs">${Object.values(c.ab).map(a=>`<div><b>◆ ${esc(a.n)}</b> <em>${a.c} Vitae</em><small>${esc(a.d)}</small></div>`).join('')}</div><p class="curse"><b>Curse.</b> ${esc(c.curse)}</p></div>`;}
    box.innerHTML=html;
    box.querySelectorAll('[data-past]').forEach(b=>b.onclick=()=>{pick.past=b.dataset.past;A.sfx('click');render();});
    box.querySelectorAll('[data-look]').forEach(b=>b.onclick=()=>{pick.look[b.dataset.look]=+b.dataset.i;A.sfx('click');refresh();});
    box.querySelectorAll('[data-clan]').forEach(b=>b.onclick=()=>{pick.clan=b.dataset.clan;A.sfx('thought');refresh();box.querySelector('.cdet')&&box.querySelector('.cdet').scrollIntoView({block:'nearest'});});
    $('#miBack').hidden=step===0;const nx=$('#miNext');nx.textContent=step===2?'This is what I am':'Next';
    nx.disabled=(step===0&&!pick.past)||(step===2&&!pick.clan);};
  $('#miBack').onclick=()=>{step=Math.max(0,step-1);A.sfx('page');render();};
  $('#miNext').onclick=()=>{if(step<2){step++;A.sfx('page');render();return;}
    S.past=pick.past;S.look=pick.look;S.clan=pick.clan;S.attrs={sanguine:2,masquerade:2,nocturne:2,cadaver:2};Object.entries(NL.PASTS[pick.past].attrs).forEach(([k,v])=>S.attrs[k]+=v);
    A.sfx('level');G.updateLook();G.refresh();m.classList.remove('in');setTimeout(()=>{m.hidden=true;$('#snapHost').appendChild(G._pCanvas());resolve();},600);A.music('night');};
  refresh();});}
function hex(c){const n=parseInt(c.slice(1),16);return [(n>>16&255)/255,(n>>8&255)/255,(n&255)/255];}

/* ======================= SUMMARY ======================= */
function showSummary(G,S){
  G.cine(false);document.body.classList.remove('talking','enc');
  const $=G.$,esc=G.esc,f=S.flags,c=NL.CLANS[S.clan],p=NL.PASTS[S.past];
  const ted={forgot:'Believes it was an ammonia nightmare. Went home to eat cake.',ally:'Knows what you are. Is keeping it to himself. Has a new closer for his tight five.',thrall:'Blood-bound to you, illegally. Devoted. Worryingly so.',paid:'Took $212 and a Canadian quarter to forget.',hiding:'Still sitting on a crate in the back, waiting for you to decide.'}[f.tedState]||(f.tedFreed?'Freed, and left to make his own way.':'Left hanging in the freezer. Someone will find him.');
  const tedLine=f.tedRescuedByCop?'Carried out of the shop by a detective with her gun on you.':f.tedGone&&f.calloOutcome==='leo'?'Driven home by Detective Miller. Case closed: one of seven.':ted;
  const callo={win:'Left her card. Thinks you\'re a tired night-shift worker. For now.',leo:'Found her missing person, and remembers your face.',lose:'Left without a card. Coming back with a warrant.',dominated:'Walked out under your command with a blank hour in her head.',scared:'Fled. Will tell herself it was the cold.',shattered:'You broke her open on the shop floor.',gas:'Called the gas company. They\'ll be there by dawn.',unseen:'Talked to an empty shop and went home confused.',dogs:'Chased off by every dog on Ferrier Street.',muse:'Heading for St. Jude\'s back entrance. Straight at Margo\'s supply line.',attack:'Knocked out and left in her car.',shot:'Shot you twice. Radioed it in.',found:'Found Leo on the hook. Has your face in her head and her gun in her hand.'}[f.calloOutcome]||'—';
  const ash={bucket:'In a bucket labelled PORK STOCK.',burnt:'Burned to nothing with his own lighter.'}[f.ashGone]||(f.bratPlan?'Still on the floor. You have a sausage plan.':'Still on the freezer floor, for anyone to find.');
  const call=f.callGood?'Believes she spoke to Absalom.':f.toldTruth?'Laughed at the truth.':f.hungUp?'Was hung up on. Furious.':f.marchettiSus?'Suspicious of the Sheriff\'s "assistant".':'—';
  const door=f.doorTorn?'Torn off its hinges.':f.loud?'Shouldered open.':'Opened neatly with a meat thermometer.';
  const rows=[['Lineage',`${c.name} · ${p.name}`],['The Sheriff\'s remains',ash],['Leo Pruitt',tedLine],['Det. Ines Miller',callo],['Lady Séverine',call],['The freezer door',door],
    ['Thoughts internalized',S.th.done.length?S.th.done.map(t=>NL.THOUGHTS[t].n).join(', '):'None yet'],['Checks · Blood pushed',`${S.stats.checks} rolled · ${S.stats.pushes} forced with Vitae`],['Blood resonance',S.res&&NL.RES[S.res.type]?`${NL.RES[S.res.type].n}${S.res.src?' · '+S.res.src:''}`:'None. You went the night on what was already in you.'],['Heat',`${S.heat} / 5`],['Clues',[f.sawV&&'"S. says the Sheriff is a problem."',f.memLaugh&&'A woman\'s laugh: "You\'re late, Absalom."',f.margoLock&&'Margo told Leo to lock the walk-in.',f.pemRelief&&'Pemberton was relieved it was you.',f.carPerfume&&'Perfume on the car door.',f.knowsBolt&&'A crossbow bolt through the hat.'].filter(Boolean).join(' · ')||'Few. Look harder next time.']];
  const el=$('#summary');el.innerHTML=`<div class="sm"><div class="mk">End of the Prologue · ${G.clockStr()}</div><h2>Four nights until the Court convenes.</h2><p class="mlede">You came out of the freezer with a dead man in your blood and his coat on your back. Here is what you left behind you.</p>
    <dl>${rows.map(r=>`<dt>${esc(r[0])}</dt><dd>${esc(r[1])}</dd>`).join('')}</dl>
    <p class="next">Night Two picks up in the back of a 1971 Continental with a thrall who knows more than he says, a ledger with a V in it, and a Court that wants a name by Friday.</p>
    <div class="acts"><button id="smAgain">Play the prologue again</button><button id="smTitle" class="ghost">Title screen</button></div></div>`;
  el.hidden=false;requestAnimationFrame(()=>el.classList.add('in'));
  $('#smAgain').onclick=()=>{el.classList.remove('in');setTimeout(()=>el.hidden=true,500);G.cine(false);G.newGame();};
  $('#smTitle').onclick=()=>{el.classList.remove('in');setTimeout(()=>el.hidden=true,500);G.cine(false);G.showTitle();};
  try{localStorage.removeItem('newlord.prologue.v1');}catch(e){}}

/* ---------- act registries: later nights plug in here ---------- */
const H={use:{},populate:{},npc:{},enter:{},barks:{},exit:{},names:{},equip:[],breach:[]};
const _use=STORY.use,_pop=STORY.populate,_npc=STORY.npcInter,_enter=STORY.onEnter,_barks=STORY.barks,_exit=STORY.exit,_un=STORY.unknownName,_bw=STORY.breachWitness,_eq=STORY.onEquip;
STORY.use=async function(id,S,G){const f=H.use[id];if(f){const r=await f(S,G);if(r!==false)return r;}return _use.call(STORY,id,S,G);};
STORY.populate=function(room,S,G){_pop.call(STORY,room,S,G);(H.populate[room]||[]).forEach(f=>f(S,G));};
STORY.npcInter=function(room,S,G){const L_=_npc.call(STORY,room,S,G);(H.npc[room]||[]).forEach(f=>{const r=f(S,G);if(r)L_.push(...[].concat(r));});return L_;};
STORY.onEnter=async function(room,S,G,o){await _enter.call(STORY,room,S,G,o);for(const f of (H.enter[room]||[]))await f(S,G,o);for(const f of (H.enter['*']||[]))await f(S,G,o,room);};
STORY.barks=function(room,S,G){return _barks.call(STORY,room,S,G).concat(H.barks[room]||[]);};
STORY.exit=async function(it,S,G){const f=H.exit[it.id];if(f){const r=await f(it,S,G);if(r===false)return false;}return _exit.call(STORY,it,S,G);};
STORY.unknownName=function(id,S){const f=H.names[id];if(f)return typeof f==='function'?f(S):f;return _un.call(STORY,id,S);};
STORY.breachWitness=function(S,G){for(const f of H.breach){const r=f(S,G);if(r)return r;}return _bw.call(STORY,S,G);};
STORY.onEquip=function(id,S,G){_eq.call(STORY,id,S,G);H.equip.forEach(f=>f(id,S,G));};
NL.DSL={N,ENC,L,T,O,C,H,STORY,openMirror:(G,S)=>openMirror(G,S),showSummary:(G,S)=>showSummary(G,S)};
NL.STORY=STORY;
})();
