'use strict';
/* THE NEW LORD — the Tenant keeps score: what the dead man in your head makes of what you've done with his week */
NL.Script.add(String.raw`
# tj.kill arc=tenant night=3,4,5 label="\"Say it. You saw what I did tonight.\"" if=kills>=1 prio=2
@focus tenant
tenant: I saw.
tenant: I've killed, child. More than I've ever counted, because a Sheriff who counts stops being a Sheriff. I'm not going to sit in your skull like a preacher and tut.
tenant: But I'll tell you what I noticed, because nobody told me. Afterwards, you wiped your mouth with the back of your hand. Like a child after jam. And then you looked at your hand. For a long time. You didn't know I was watching you look.
* "I didn't want to do it."  -> tj.kill1
* "I'd do it again."  -> tj.kill2
* "Tell me how you stopped counting."  -> tj.kill3

# tj.kill1
tenant: No. Most of us don't, the first time. The trick is to keep not wanting to. The ones who start wanting to are the ones the Court gives titles to.
{do sync+1; lean:restraint+1}
@end

# tj.kill2
tenant: Yes. I expect you would. So would I. That's what frightens me about us, child. Not that we'd do it. That we'd say so.
{do lean:mercy-1; sync-1}
@end

# tj.kill3
tenant: I didn't. I lied. I know every one. Forty-one. The forty-first was a Hound from out of town in 1977 who'd eaten a family on the river road, and I don't regret him, and I know his name, and it was Owen.
tenant: You don't stop counting. You just stop telling anyone the number.
{do sync+2; lean:candour+1; mem:tenant:fortyone}
@end

# tj.clean arc=tenant night=4,5 label="\"I haven't killed anyone. Not one.\"" if=kills=0 prio=1
@focus tenant
tenant: No. You haven't. Four nights in the Marrow Ward with my hunger in your teeth and you haven't killed a soul.
tenant: Do you know how rare that is? I'm not flattering you. I've seen a hundred fledglings. Most of them kill someone in the first week by accident. A bouncer who grabs their arm. A girlfriend who won't stop crying. One kiss too long.
tenant: You've been hungry every night. I've felt it. You've walked past it every night.
* "It's not hard. You just say no."  -> tj.clean1
* "It's the hardest thing I've ever done."  -> tj.clean2
* "I'm saving it. For Friday. For whoever fired the lance."  -> tj.clean3

# tj.clean1
tenant: It's not hard. Listen to you. It's the hardest thing in the world and you say it like it's turning down a second cookie.
{do sync+1}
@end

# tj.clean2
tenant: Yes. I know. I've been in here for it.
tenant: I want you to know something. Whatever happens on Friday: you did that. Four nights. Nobody can take it off you, not the Court, not the Magistrate, not God. It's yours.
{do sync+2; comp+1}
@end

# tj.clean3
tenant: Saving it. Like a bottle of good wine. For a special occasion.
tenant: ...I understand. I don't approve. I understand completely. I had a bottle like that, once. 1888. I drank it in 1924 and it wasn't worth the wait.
{do lean:mercy-1; sync+1}
@end

# tj.broke arc=tenant night=3,4,5 label="\"I broke my word to someone.\"" if=broke prio=2
@focus tenant
tenant: Yes. I felt it go. It's like a tooth coming out. A little crack, very far back.
tenant: The Sovereign line doesn't forgive broken promises, child. Not in others. In ourselves it forgives everything, eventually, after a century or so of sulking.
* "How do I fix it?"  -> tj.broke1
* "It was the right thing to do. The promise was the mistake."  -> tj.broke2
* "Everyone breaks promises."  -> tj.broke3

# tj.broke1
tenant: You don't fix it. You go back and say: I broke it. I'm sorry. I won't pretend I didn't.
tenant: Then you let them hate you. That's the fix. It isn't a very good one. It's the only one there is.
{do sync+1; lean:candour+1}
@end

# tj.broke2
tenant: Possibly. Possibly. I made Agnes a promise in 1926 that I'd never let her see me feed. I broke it in 1931 to save her husband's life. She never forgave me. She was right not to, and I was right to break it, and both of those things are still true.
{do sync+2; mem:tenant:agnespromise}
@end

# tj.broke3
tenant: Everyone. Yes. Everyone dies, too. Doesn't make it pleasant to watch.
{do sync-1; lean:loyalty-1}
@end

# tj.heat arc=tenant night=3,4,5 label="\"Are they looking for us? The police?\"" if=heat>=3 prio=2
@focus tenant
tenant: Looking for us. Child, half the Ninth Precinct has your description on a Post-it note on their dashboard. A man in a dead man's coat with grey skin and an aversion to mirrors.
tenant: I kept the Masquerade for a hundred and thirty-six years in this city. One mayor's memory. A few photographs. Some unfortunate business with a newspaper in 1973. You've done more damage to it in four nights than I did in a century.
* "Then help me. How do I go quiet?"  -> tj.heat1
* "Maybe the Masquerade should break."  -> tj.heat2
* "I'm not you. I don't have a century."  -> tj.heat3

# tj.heat1
tenant: Stop being interesting. That's all the Masquerade is. Be dull for a week. Walk, don't run. Pay in cash. Don't save anybody in public.
tenant: That last one's the hard one, for you. I've noticed.
{do sync+1; heat-1}
@end

# tj.heat2
tenant: ...
tenant: Say that on Friday and they'll burn you before you've finished the sentence. Say it to me in here and I'll... think about it. I've thought about it before. In 1958, sitting on the end of a good man's bed with his memories in my hands.
{do sync+1; flag:tenantMasq=1}
@end

# tj.heat3
tenant: No. You don't. You've got four nights and a temper.
{do sync-1}
@end

# tj.cruel arc=tenant night=3,4,5 label="\"You've gone quiet. Why?\"" if=rep:mercy<=-2 prio=2
@focus tenant
tenant: Because I'm listening to you. And I don't like the sound of it, and I don't know how to say that to someone I live inside.
tenant: You're becoming very good at this. The cruelty. I recognize it. I was good at it too. I used to think it was a talent. Then Agnes asked me, once, in 1929, why I was so cold to waiters. And I didn't have an answer, so I made one up, and the one I made up was worse than the truth.
* "What was the truth?"  -> tj.cruel1
* "I'm surviving. You don't get to judge that."  -> tj.cruel2
* "I don't like it either."  -> tj.cruel3

# tj.cruel1
tenant: The truth was that cruelty is cheap. It costs nothing in the moment. The bill comes in ninety years, all at once, and you're sitting in a study with nobody to talk to but a chauffeur who can't refuse you.
{do sync+1; lean:mercy+1}
@end

# tj.cruel2
tenant: No. I don't. I'm a dead man in a borrowed skull. I gave up the right to judge when I let you drink me.
tenant: But I'm going to keep noticing. I can't help that.
{do sync-2}
@end

# tj.cruel3
tenant: No? Good. Hold onto not liking it. That's the whole of it. Everyone in the Court likes it now. None of them did at first.
{do sync+2; lean:mercy+1}
@end

# tj.kind arc=tenant night=4,5 label="\"Do you think I'm soft?\"" if=rep:mercy>=3 prio=1
@focus tenant
tenant: Soft. Yes. Very.
tenant: You've given away blood. You've carried an old man down six flights of stairs. You told a doctor who murdered me that you forgave her, which I'm still angry about, and you meant it, which I'm angrier about.
tenant: I think you're the softest thing that's ever worn this coat. I think the Court will try to eat you for it. And I think, child, God help me, I think I'd rather be in here than anywhere else in the Ward.
* "Thank you."  -> tj.kind1
* "Soft things survive. Ask the moss."  -> tj.kind2

# tj.kind1
tenant: Don't thank me. Keep being soft. That's how you thank me.
{do sync+2}
@end

# tj.kind2
tenant: The moss. Ha. Agnes would have liked you. She grew moss in a jar on her desk at the Courthouse. She said it was the only thing in the building that wasn't trying to be important.
{do sync+2; comp+1}
@end

# tj.liar arc=tenant night=3,4,5 label="\"You don't like how much I lie.\"" if=rep:candour<=-2 prio=2
@focus tenant
tenant: Like it. I'm impressed by it. That's different. I used to lie for a living. You're better at it than I was by the end.
tenant: But here's what nobody tells you. The lies don't stay out there. They come in here. I can feel them stacking up like plates in a sink. Every one you tell Miller. Every one you tell Leo. They're in here with me, and they don't go anywhere.
* "Then I'll stop."  -> tj.liar1
* "They're keeping people alive."  -> tj.liar2
* "Then learn to share a sink."  -> tj.liar3

# tj.liar1
tenant: Stop. Just like that. You say that like it's possible. I tried, in 1961. I lasted until breakfast.
tenant: Try. I'll help. I'll make a noise like a teacup every time. You'll hate it.
{do sync+1; lean:candour+1; flag:tenantTeacup=1}
@end

# tj.liar2
tenant: Some of them. Yes. And some of them are keeping *you* alive, which is not the same thing, and you know which ones they are, and so do I.
{do sync+1}
@end

# tj.liar3
tenant: Share a sink. Ha. Fine. Fine. I've lived in worse. The Prince's palazzo in 1900 had worse.
{do sync-1}
@end

# tj.honest arc=tenant night=4,5 label="\"Why do you look at me like that? From in there?\"" if=rep:candour>=3 prio=1
@focus tenant
tenant: Because you keep telling the truth. To everyone. Miller. Séverine. The Magistrate's driver. A child on a bicycle.
tenant: Do you know what it does, in a city like this? It's like walking into the Elysium with a lamp. Everyone squints. Some of them hiss. And a few of them, a very few, come and stand next to it, because they've been cold for a hundred years and they'd forgotten what light was like.
tenant: I never had the nerve. I want you to know I noticed.
{do sync+2}
@end

# tj.proud arc=tenant night=4,5 label="\"Do I wear the coat well?\"" if=rep:pride>=3 prio=1
@focus tenant
tenant: Well. Too well. You've started standing with one hand behind your back.
tenant: You didn't know? You've been doing it since Wednesday. Like a heron that's cross with the river. Agnes's phrase. It's my habit, in your shoulders.
* "Should I stop?"  -> tj.proud1
* "Good. Let them see you in me."  -> tj.proud2

# tj.proud1
tenant: Stop. No. Yes. I don't know.
tenant: Stop when you want to. Not because I'm in here. The coat is just a coat. It only gets heavy if you start believing the Court when they bow to it.
{do sync+1; lean:pride-1}
@end

# tj.proud2
tenant: Let them... yes. Yes, all right. Let them see. Séverine will hate it. Ashby will do an impression. Pemberton will cry in the car and pretend it's hay fever.
{do sync+2; lean:pride+1}
@end

# tj.street arc=tenant night=4,5 label="\"You don't recognize the Sheriff I'm turning into.\"" if=rep:pride<=-3 prio=1
@focus tenant
tenant: No. I don't. You sit on curbs. You drink coffee from the Lucky Mart. You let Dutch call you ‹"brother"|"sister"›. You said "thanks, man" to a Rot, on Kerr Street, I heard it, I'll never recover.
tenant: I was a Sheriff for the Court. I think you might be a Sheriff for the Ward. They're different jobs. I always thought they were the same, and I was wrong, and it took somebody eating me to find out.
{do sync+1}
@end

# tj.hungry arc=tenant night=3,4,5 label="\"Why do you keep counting the feeds?\"" if=feeds>=5 prio=1
@focus tenant
tenant: Because you don't. Five. Six, if you count the bag. You drank more this week than I drank in a month at the end.
tenant: It's the blood. My blood. It's very old and it's very thirsty and it's in a body that doesn't know how to say no to it yet.
* "Help me say no."  -> tj.hungry1
* "I'm healing. I'm fighting. I need it."  -> tj.hungry2

# tj.hungry1
tenant: I'll try. When you're about to, I'll talk about Corsica. Goats. Goat cheese. The smell of a goat in August. It's very effective. It worked on me in 1803.
{do sync+1; lean:restraint+1; flag:tenantGoats=1}
@end

# tj.hungry2
tenant: You do. You do. I'm not saying you don't. I'm saying, one night soon, you'll need it and there'll be a person in front of you, and not a bag, and I want you to have thought about it before then.
{do sync+1}
@end

# tj.synchi arc=tenant night=4,5 label="\"Some nights I can't tell which thoughts are yours.\"" if=sync>=60 prio=2
@focus tenant
tenant: No. Nor can I.
tenant: Last night you thought about Agnes for an hour, and I don't think it was me thinking it. I think it was you. I think you *miss* her. You never met her. You miss her.
tenant: That's how it goes. Ottoline's grandmother wrote about it. The Vessel and the Tenant, a hundred years in, are one person with two memories. Neither of them can remember which childhood was theirs.
* "Does that frighten you?"  -> tj.synchi1
* "I don't want to be one person with you."  -> tj.synchi2
* "I think I'd like that."  -> tj.synchi3

# tj.synchi1
tenant: Terribly. And the other thing. The opposite of frightened. I don't have a word for it. I've been alone in my own head for two hundred and sixty-three years. You're the first visitor who stayed.
{do sync+1}
@end

# tj.synchi2
tenant: No. Of course not. I'll... I'll keep to my side of the room. I don't know where the walls are, child. But I'll try.
{do sync-3; flag:tenantWalls=1}
@end

# tj.synchi3
tenant: ...
tenant: You'd like... nobody has ever... I don't know what to say. Two hundred and sixty-three years and I've finally been left speechless by a fledgling in my own coat.
{do sync+3; comp+1}
@end

# tj.synclo arc=tenant night=4,5 label="\"You're getting fainter.\"" if=sync<=20 prio=2
@focus tenant
tenant: Am I? I hadn't noticed. Yes. Yes, I suppose I am.
tenant: It's all right, you know. It's what's supposed to happen. The Tenant fades and the Vessel goes on. I'd made my peace with it before Monday. I'd made my peace with a lot of things before Monday.
tenant: I'd like to say one thing before I'm too faint to say it. You're going to be a better Sheriff than me, if you live. Not because you're kinder. Because you don't need anyone to tell you you're right.
* "I don't want you to fade."  -> tj.synclo1
* "Thank you. I'll remember."  -> tj.synclo2

# tj.synclo1
tenant: Don't you. Well. Well. Then talk to me. That's all it takes. Talk to me and I'm here.
{do sync+3}
@end

# tj.synclo2
tenant: You will. That's the cruelest part. You'll remember everything. I made sure of that, didn't I. By being delicious.
{do sync+1}
@end

# tj.millc arc=tenant night=3,4,5 label="\"You think I shouldn't have told Miller.\"" if=flag:millerConfess=killed prio=1
@focus tenant
tenant: Told a police detective, in an alley, in the rain, that you killed the Sheriff of the Marrow Ward. Yes. I think it was the stupidest thing I've ever seen anyone do, and I once watched Ashby challenge a bear.
tenant: And she believed you, and she didn't arrest you, and she went to church. I heard her think about it in the car. She went to church because of you.
tenant: I never once made anybody go to church. I made a lot of people need to.
{do sync+1}
@end

# tj.memgone arc=tenant night=3,4,5 label="\"I can't remember what my mother's kitchen smelled like.\"" if=flag:sootMemPaid=kitchen prio=2
@focus tenant
tenant: No. You gave it to Soot. On Tuesday. For a key and a rumour.
tenant: I can remember it, you know. Not yours. Mine. Ajaccio. Fish and lemons and charcoal and my mother swearing at the stove in Corsican. I've had it for two hundred and sixty years. It's never faded.
* "Give me yours. Since I gave mine away."  -> tj.memgone1
* "Keep it. It's yours."  -> tj.memgone2

# tj.memgone1
tenant: Give... yes. Yes. I don't know if I can. Hold still.
> Something moves behind your eyes, very gently, like someone setting a cup down in another room.
> Fish. Lemons. Charcoal. A woman's voice, swearing, and laughing while she swears. It isn't your mother's kitchen. It's somebody's. It'll do.
tenant: There. That's yours now too. Don't give that one to Soot. She'd charge me for it.
{do sync+3; comp+2:A borrowed kitchen; flag:tenantKitchen=1}
@end

# tj.memgone2
tenant: Mine. Yes. It is. Thank you for letting me keep one thing.
{do sync+1}
@end

# tj.lied arc=tenant night=3,4,5 label="\"I put words in Séverine's mouth. To Malakor.\"" if=flag:msgLied prio=1
@focus tenant
tenant: You did. "Lady Séverine apologizes." I nearly laughed out loud in your skull. Nobody's put those words in that mouth since 1793.
tenant: And it worked. That's what I can't get over. A lie in a Butcher's shop and two people who've hated each other for forty years stood down. I spent a century trying to make peace between those two with the truth.
tenant: It may be the best lie ever told in this Ward. Don't do it again. It won't work twice.
{do sync+1}
@end
`,'c_tenant5');
