'use strict';
/* THE NEW LORD — the Tenant has opinions about what you did today */
NL.Script.add(String.raw`
# tnO.leoemb arc=tenant night=4,5 label="He hasn't said anything about Leo. Ask him." if=flag:leoEmbraced prio=3
@focus tenant
tenant: The boy. You made him. On a mattress in a studio with a cactus watching.
tenant: I won't tell you it was wrong. I don't know if it was wrong. I'll tell you what my sire told me, the night after: "Now you have something to lose that can't die of old age. Congratulations. That's the worst thing there is."
* "Was he right?"  -> tnO.leoemb1

# tnO.leoemb1
tenant: Yes. He was right. And I'd have given anything to have what you have now. Someone who chose you. Mine certainly didn't.
{do sync+1}
@end

# tnO.sevbond arc=tenant night=4,5 label="Ask him what she tasted like to him, in 1888." if=flag:sevBond prio=3
@focus tenant
tenant: Jasmine. And a ballroom. And a cellar in Lyon. Yes. The same. She hasn't changed in two hundred years.
tenant: You'll want her for a while. Then you'll want her less. Then you'll catch yourself thinking about her wrist at the strangest moments, buying root beer, watching a cat. That lasts.
tenant: Don't go back for the second taste. Whatever she says. Promise me that, if nothing else.
* "I promise."  -> tnO.sb1 {do promise:nosecond:Never take Séverine's second taste}
* "I can't promise that."  -> tnO.sb2

# tnO.sb1
tenant: Thank you. I'll hold you to it. I'll be very annoying about it.
@end

# tnO.sb2
tenant: No. I couldn't either. I went back twice. Nine years. Remember that I told you.
@end

# tnO.freddie arc=tenant night=4,5 label="Freddie. Ask him." if=flag:freddieDead prio=2
@focus tenant
tenant: Freddie. I knew him a hundred years. He was the funniest person at every party and the worst person at every funeral.
tenant: I don't mourn him. I find I don't. That frightens me a little. I'd have mourned him once.
@gate flag:rostovaRevenge ? tnO.fr1 : tnO.fr2

# tnO.fr1
tenant: You let her do it. The doctor. Her own hands. That was... that was the kindest cruel thing I've ever seen anyone do.
@end

# tnO.fr2
tenant: You did it yourself. So she wouldn't have to. Or so you would. I'm not sure you know which.
@end

# tnO.harrowdrink arc=tenant night=4,5 label="Harrow. You drank him. Ask him what's left." if=flag:harrowDeadEarly prio=3
@focus tenant
tenant: There's a little of him in us now. Not much. A taste. Menthol. Peppermint. And something underneath: a servants' wing in Virginia, a woman at a sink, a spider plant on the windowsill.
tenant: He wanted to be us. He's got his wish. A thimbleful of him, in a corner of the room, next to the rug.
tenant: I don't hate him. I thought I would. He's very quiet. He keeps saying please.
{do sync+1}
@end

# tnO.harrowwalk arc=tenant night=5 label="He walked away. Ask the Tenant what he thinks." if=flag:harrowWalked prio=3
@focus tenant
tenant: He walked. Down the beltway, with a coffee. Away from forty million dollars and twenty years.
tenant: I've never once in my life walked away from anything. I stayed for everything. Every war, every Court, every Sheriff's chair. I thought that was courage.
tenant: He's braver than me. A mortal with a spider plant. I'll never forgive him for it.
@end

# tnO.confess arc=tenant night=3,4,5 label="Ask him what he thought of the priest." if=flag:confessed prio=2
@focus tenant
tenant: A plywood chapel, an electric candle, an old man with a crossword. And nothing burned.
tenant: I was raised Catholic, you know. Ajaccio, 1760s. I haven't set foot in a church since the night I was made. I thought the walls would scream.
tenant: They didn't. They just... let you in. Like a draught. I've spent two hundred years being afraid of a building that only wanted to keep the rain off.
{do sync+1}
@end

# tnO.dom arc=tenant night=3,4,5 label="Father Dominic. He's dead. Ask him." if=flag:dominicDead prio=3
@focus tenant
tenant: Two hundred and nine names in a notebook. And now his.
tenant: He knew what we were, and he sat in a chapel every night, alone, with the door open. He was the bravest mortal in the Ward and you were hungry.
tenant: I'm not going to say anything else. You know. I can feel that you know.
{do comp-1}
@end

# tnO.cables arc=tenant night=5 label="Three cables. Ask him how it feels." if=flag:cablesCut prio=2
@focus tenant
tenant: Three cuts. Under three buildings. With your bare hands, once, and a boy with bolt cutters, and a Butcher's crew, and rats, and a coal chute I used in 1926.
tenant: You've done in one night what I couldn't do in eighty years: you've found the thing aimed at us and turned it off. No speeches. No duels. No Tribunals. Wires.
tenant: I'd have liked to have been the kind of Sheriff who thought of wires.
{do sync+1; comp+1}
@end

# tnO.roof arc=tenant night=5 label="The roof. Ask him what he thought." if=flag:roofDone&!flag:councilHome prio=1
@focus tenant
tenant: A comedian in pyjamas. A doorman. A Hound. A detective. A shopkeeper. A dinner lady. A man in a good coat with an umbrella over nobody.
tenant: When I was Sheriff I had a council of nine Elders who hated each other and me. I never once had a roof.
tenant: Look after them tonight. That's all a Sheriff is, in the end. The one who decides where everyone stands, and is sorry about it.
@end

# tnO.walk arc=tenant night=4,5 label="Thank him for the walk." if=flag:walkDone prio=0
@focus tenant
tenant: Thank ME? You carried me. Up Assize Street, down to the pier, into a chapel. I didn't do anything but remember.
tenant: ...Well. All right. You're welcome. I'd do it again. I'd like to do it again, if there's another night. There's a lot of Ward I haven't shown you. There's a staircase on Kerr Street that was built for a duel.
{do sync+1}
@end

# tnO.robin arc=tenant night=4,5 label="Ask him about Robin." if=flag:sisterTalked prio=1
@focus tenant
tenant: Your sister. On the telephone. "Are you warm, Case?"
tenant: Nobody's asked me that in two hundred years. Not once. They ask if I'm well, if I'm fed, if I'm satisfied with the tithe. Nobody asks if I'm warm.
tenant: I listened to every word. I'm sorry. I couldn't not. She's wonderful. She's exactly as stubborn as you.
{do comp+1}
@end

# tnO.kills arc=tenant night=4,5 label="He's counting again. Ask him the number." if=kills>=3 prio=1
@focus tenant
tenant: Three. Four. I don't need to tell you. You know.
tenant: I'm not going to lecture you. I've killed more than you. I'll kill more than you, through you, if we last.
tenant: But I'll tell you the thing I learned too late: the number doesn't get heavier. It gets lighter. Each one weighs less than the last. That's the danger. Not the weight. The lightness.
{do comp-1}
@end

# tnO.nokill arc=tenant night=5 label="Ask him if he's noticed you haven't killed anyone." if=kills=0&feeds>=2 prio=1
@focus tenant
tenant: Noticed. Child, I've been counting every night. Every time you stopped. Every time you laid them down on their side in a doorway like they teach on first-aid courses.
tenant: Five nights. Zero. I didn't manage zero for five nights until 1919. And then only because I was ill.
tenant: Whatever happens in the chalk, you'll walk in with nothing on your hands but his blood. That's... that's very rare. Hold onto it.
{do sync+1; comp+2}
@end

# tnO.cohort arc=tenant night=4,5 label="Cohort B. He's been quiet since the shelter." if=flag:metCohort prio=1
@focus tenant
tenant: They were made with my blood. Marisol and Jerome and the boy on the bus. A pint I gave in August, for leukaemia research, signed on a form I didn't read.
tenant: I'm their... I don't know what I am to them. Not their sire. Something worse. The thing they were made out of without being asked.
tenant: I'd like to do something for them. I can't. I'm in you. So: do something for them, please. For me. I'll owe you.
@end

# tnO.letters arc=tenant night=5 label="Albert's letter. Ask him." if=flag:lt8 prio=2
@focus tenant
tenant: Albert. "Don't go out to him, he'll only bolt." She knew me so well. He knew me through her.
tenant: Do you know, if I could choose one thing to have done differently in two hundred years. Not Marseille. Not the pier. I'd have gone in. In 1961. Through the front door of that nursing home, in my coat, at night, past Albert, and sat by her bed and told her the truth. "Yes, Aggie. It hurts. It's all right."
tenant: I'll never get to. You know that. I'm telling you anyway, so somebody knows I wanted to.
{do sync+2; comp+1}
@end
`,'c_tenant3');
