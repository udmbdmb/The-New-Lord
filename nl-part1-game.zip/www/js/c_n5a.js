'use strict';
/* THE NEW LORD — Night Five: last conversations before the Tribunal, new evidence and witnesses at the Tribunal, and the extended epilogue */
(function(){
const S_=NL.Script;
S_.npc({id:'miller',room:'luckymart',at:[2.7,4.0,-1.6],pose:'hold',label:'Miller',if:'night:5&time<235&!flag:millerN5Gone'});
})();
NL.Script.add(String.raw`
// =====================================================================
// FRIDAY · last words, before one o'clock
// =====================================================================
# lx5.0 arc=leo night=5 label="\"Leo. Tonight's the night.\"" if=room:apt&leo:here
@focus leo
> Leo is sitting on the couch with Gerald on his knees and the TV on with the sound off. A weather map. A storm coming in off the coast that isn't coming in.
leo: I know. I can tell. You've got your Friday face on. It's the same as your other faces, but more.
leo: Is it going to be okay?
* "Yes."  -> lx5.yes {do lean:candour-1}
* "I don't know."  -> lx5.dontknow {do lean:candour+1}
* "Whatever happens, you'll be okay."  -> lx5.you

# lx5.yes
leo: Liar. That's fine. I like it. Lie to me some more. Tell me I'm going to be on TV.
@next lx5.hub

# lx5.dontknow
leo: Okay. Honest. Okay. That's worse and better at the same time. Like a jalapeño popper.
@next lx5.hub

# lx5.you
leo: Me. Yeah. I'm always okay. I'm the guy who's okay. It's my whole thing.
leo: I want *you* to be okay. That's not a joke. I don't have a joke for that.
{do rel:leo+1}
@next lx5.hub

# lx5.hub
* "If I don't come back, go to Junie's. Tonight."  -> lx5.junie {once}
* "Tell me a joke. A new one."  -> lx5.joke {once}
* "Thank you, Leo. For everything this week."  -> lx5.thanks {once}
* "I have to go."  -> lx5.bye

# lx5.junie
leo: Tonight? With the lights and the cops and the... okay. Okay. If you don't come back by sunrise I'll get the bus. The first one. Five-forty. I'll take Gerald.
{do flag:leoBackupPlan=1}
@next lx5.hub

# lx5.joke
leo: New one. Okay. Uh. Okay.
leo: A vampire walks into a butcher's at four in the morning. The guy behind the counter says, "We're closed." The vampire says, "That's fine. I'll just have whatever's in the freezer."
> He waits.
leo: ...It's not finished. The ending's not there yet. I'll tell you the ending when you come back.
{do flag:leoJokeOwed=1; mem:leo:joke}
@next lx5.hub

# lx5.thanks
leo: For what? Getting bitten? Getting locked in a freezer? Having the worst week of my life?
leo: ...Best week. Weirdly. Don't tell anyone. Best week of my life. I did a set in a vampire crypt and got paid a thousand dollars and I've got a friend who's dead. That's a week.
{do mem:leo:bestweek; rel:leo+1}
@next lx5.hub

# lx5.bye
leo: Go. Go. Come back. You owe me an ending.
@end

# lx5c.0 arc=severine night=5 label="\"Where's Leo, my lady?\"" if=room:vip&alive:sev&flag:leoCourt prio=5
@focus severine
severine: Your comedian? In my chapel, with Brother Anselm, eating a sandwich. He's perfectly well. He thinks I'm wonderful.
severine: I've asked him everything I wanted to know. I'm finished with him. I could give him back. I could keep him; he's very funny about his mother.
* "Give him back. Please."  -> lx5c.please {do lean:pride-1}
* "What do you want for him?"  -> lx5c.price
? pedigree 11 "Keeping a mortal pet in Elysium during a Tribunal? The Magistrate will ask."  -> lx5c.threat | lx5c.threatno {id lx5c_ped}

# lx5c.please
severine: Please. You keep saying please. It's charming. It's going to get you killed. Harrow says so too, I imagine. He's said it to me.
severine: Very well. Take him. He'll be confused for a day or two. He'll miss me. Everybody does.
{do flag:leoCourt=0; flag:leoReturned=1; rel:severine-1; mem:leo:returned}
@end

# lx5c.price
severine: Tonight, in the chalk circle, you will not mention Mrs. Kowalski's screwdriver.
* "Agreed."  -> lx5c.agree {do promise:nomargo:Say nothing about Margo's screwdriver at the Tribunal; lean:loyalty+1}
* "No."  -> lx5c.refuse

# lx5c.agree
severine: Lovely. Lisette, bring the boy. And a coat for him. It's cold out.
{do flag:leoCourt=0; flag:leoReturned=1; flag:silentOnMargo=1; mem:leo:returned}
@end

# lx5c.refuse
severine: Then he stays. Until Saturday. After that we'll see who has the right to ask me for anything.
@end

# lx5c.threat
severine: ...Fine. *Fine.* You're very tiresome when you're right.
{do flag:leoCourt=0; flag:leoReturned=1; mem:leo:returned}
@end

# lx5c.threatno
severine: Ask what? Whether I am entertaining a guest? He'll applaud.
@end

# tx5.0 arc=tariq night=5 label="\"I came to say goodnight.\"" if=room:luckymart
@focus tariq
tariq: Goodnight. Not goodbye. Goodnight. My grandmother said never say goodbye to someone going into the dark. You say goodnight and you leave a light on.
@gate flag:tariqLamp ? tx5.lamp : tx5.nolamp

# tx5.lamp
> The ugly brass lamp with the green shade is on by the till. He's put a coaster under it.
tariq: See? On. All night. If you come back and it's off, it means I died of a heart attack, and you should call my mother.
@next tx5.hub

# tx5.nolamp
tariq: I'll leave the big lights on. All of them. The whole shop. It'll look like a spaceship. You'll see it from Platform 0.
@next tx5.hub

# tx5.hub
* Ask him for bread and salt.  -> tx5.salt {once} {if mem:tariq.saltstory|mem:tariq.salt}
* "Thank you, Tariq. For the coffee."  -> tx5.coffee {once}
* "Goodnight."  -> tx5.bye

# tx5.salt
> He looks at you for a long moment. Then he goes into the back and comes out with a bread roll from the bakery tray and a sachet of salt from the hot dog stand. He tears the roll in half. He puts salt on it. He holds it out.
tariq: There. You're a guest. You can't harm me, and nobody in my house can harm you.
> You can't eat it. You both know that. You take it anyway and hold it, and he nods as if you have.
{do flag:breadSalt=1; comp+2:Bread and salt; rel:tariq+1; mem:tariq:breadsalt}
@next tx5.hub

# tx5.coffee
tariq: You never drank it. Not once. Forty cups. I counted.
tariq: You're welcome.
@next tx5.hub

# tx5.bye
tariq: Goodnight. Light's on.
@end

# gx5.0 arc=gideon night=5 label="\"One last box, Gideon?\"" if=room:pawn
@focus gideon
gideon: Last? Don't say last. Bad for business. Say "next".
gideon: Every box in the shop's rented tonight. Fourteen Kindred in the back, hiding from the Tribunal. A Wraith in the umbrella stand. I've never been so full.
* "Why aren't you scared, Gideon?"  -> gx5.scared
* "If I don't come back, keep my box empty."  -> gx5.empty
* "Thank you. For the dark."  -> gx5.thanks

# gx5.scared
gideon: I'm seventy-four. I've buried two wives and a son and a cat called Bismarck. I've rented boxes to monsters for fifty-five years. I've got a shotgun under the counter and a rosary in the till.
gideon: Scared went a long time ago. What's left is curious.
@next gx5.hub

# gx5.empty
gideon: Empty. Like Winter's. Forty years.
gideon: No. If you don't come back, I'll rent your box to the first frightened young thing who comes in at dawn and says please. That's what you'd want. That's what she'd want.
{do mem:gideon:empty}
@next gx5.hub

# gx5.thanks
gideon: Sunrise guaranteed.
gideon: Fifty-five years and nobody's ever thanked me for the *dark*. They thank me for the box. The dark's free. The dark's the only thing I give away.
{do rel:gideon+1}
@next gx5.hub

# gx5.hub
* "Goodnight, Gideon."  -> gx5.bye

# gx5.bye
gideon: Bring the coat back. It's a good coat.
@end

# px5.0 arc=pemberton night=5 label="\"Pemberton. Before we go down.\"" if=flag:mapOK&!flag:pemDead&!flag:lastCallDone=sunrise
@focus pemberton
pemberton: ‹Sir›. The car is by the north stair. Engine running. If it goes badly, I'll be there. If it goes well, I'll be there. That's the job.
* "Whatever happens. Thank you."  -> px5.thanks
* "If it goes badly, don't wait. Drive."  -> px5.drive
* "Come down with me."  -> px5.come

# px5.thanks
pemberton: ‹Sir›.
> He doesn't say anything else. He straightens your collar, the way he must have straightened the Sheriff's ten thousand times, and steps back.
{do rel:pemberton+1}
@end

# px5.drive
pemberton: I've been driving away from things for forty-one years, ‹sir›. I'm not very good at it. I always come back.
@end

# px5.come
pemberton: Down? To the Tribunal? Ghouls stand at the back, ‹sir›. Against the wall. With the coats.
pemberton: ...But I'll stand at the back of *that* wall. Where you can see me.
{do flag:pemAtTribunal=1; rel:pemberton+1}
@end

# vx5.0 arc=valko night=5 label="\"Left hand, Valko.\"" if=flag:valkoAlly&room:switchyard
@focus valko
valko: Left hand.
@end

# ox5.0 arc=okafor night=5 label="\"I came to see you before.\"" if=room:apt&flag:met404
@focus okafor
okafor: Before. Before what? Everybody keeps saying before tonight.
@gate flag:okaforScarf ? ox5.scarf : ox5.noscarf

# ox5.scarf
> The scarf is finished. Seven colors. It's very long and slightly uneven and the green stripe is wider than the others.
okafor: Done. The green's for Dani. I made it wider. Nobody will notice. I'll notice.
okafor: I'm tying it to the railings outside St. Jude's in the morning. If you're there, you can help me with the knot.
@next ox5.end

# ox5.noscarf
okafor: I'll be here. Making tea. You won't drink it. Come back and not drink it.
@next ox5.end

# ox5.end
@end

# ix5.0 arc=miller night=5 label="\"Ines. Tonight.\"" if=room:luckymart&actor:miller
@focus miller
miller: Tonight. I've got a judge in the car, a flask of terrible coffee, two squad cars from Precinct 4 that owe me favours, and a warrant with the wrong name spelled right.
miller: I have no idea what I'm walking into. I'd like you to tell me.
* Tell her everything about the Tribunal. The lamps.  -> ix5.lamps {do lean:candour+1}
* "Wait in the car. When I call, come down. Not before."  -> ix5.wait
* "Don't come at all."  -> ix5.dont

# ix5.lamps
miller: Lamps. Under the grates. With three hundred of you on the platform. And Harrow on the street with his thumb on the button.
miller: That's not a warrant. That's a massacre with paperwork.
miller: Okay. Okay. Then I come early. Then I'm on the street with Abernathy when he reaches for the button, and I say his name.
{do flag:millerEarly=1; mem:miller:lamps}
@next ix5.end

# ix5.wait
miller: When you call. On the burner. Okay. I've been waiting thirteen years. I can wait an hour.
@next ix5.end

# ix5.dont
miller: Not come. To the end of the biggest case of my life. Not come.
miller: No. Sorry. I like you. Not that much.
@next ix5.end

# ix5.end
miller: See you on the other side of Friday.
{do flag:millerN5Gone=1}
@leave miller

// =====================================================================
// THE TRIBUNAL · Soot speaks first, if promised
// =====================================================================
# tbs.soot
soot: Me first. Me first. I was promised. Mm.
soot: Magistrate. The pipes heard everything this week. I'll tell it short, because I'm old and the young ones are hungry.
soot: The Lady paid a butcher to fix a door. The doctor fired a light. The grey man paid the doctor. The Sheriff knew about the doctor and went shopping anyway. And the little one in the dock drank him to stop him burning.
soot: That's all. That's all true. Mm. Mm. I'm done. I'll sit.
@end
`,'c_n5a');

/* ---------- Tribunal: new evidence and witnesses from this week ---------- */
(function(){
const {L,T,ENC}=NL.DSL;const G=NL.G;
if(!ENC.tribunal)return;
const st0=ENC.tribunal.start;
ENC.tribunal.start=function(S,G){const r=st0.call(this,S,G);
  if(S.flags.sootSpeaksFirst&&!S.flags.sootDead){r.prog+=1;}
  if(S.flags.breadSalt)r.threat=Math.max(0,r.threat-0);
  if(S.flags.lisetteAlly)r.prog+=0;
  return r;};
const mv0=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv0.call(this,st,S,G);
  if(G.has('princefile'))M.push({t:'Untie the red ribbon. "Magistrate: the Sheriff\'s own file, for the Prince. He was bringing it tonight."',once:'tb_pf',ok:(st,S)=>{st.prog+=3;return [T('The Magistrate reads every page. It takes a long time. Nobody on Platform 0 moves. When he gets to the budget line he laughs, once, a sound like a coffin lid.'),L('magistrate','Forty-one million dollars. To burn us. I am almost flattered.')];}});
  if(G.has('vaneletter'))M.push({t:'Read them the Sheriff\'s letter. "To whoever drinks me."',once:'tb_vl',ok:(st,S)=>{st.prog+=2;S.flags.letterRead=1;return [T('You read it aloud, all of it, the cure and the seven and the eighth and Pemberton. By the end, half the Court is looking at the floor.'),L('magistrate','His hand. His seal. His shame. Yes. This is Absalom.'),L('pemberton','(from the back wall, very quietly) That\'s him, my lord. That\'s him.',{if:S=>S.flags.pemAtTribunal&&!S.flags.pemDead})];}});
  if(G.has('payslip'))M.push({t:'Hand up Dani Okafor\'s pay stub. "LANTERN RESEARCH LLC. Five hundred dollars. Cohort B, number three."',once:'tb_ps',ok:st=>{st.prog+=1;return [L('magistrate','They paid them. Like piecework.')];}});
  if(S.flags.tinyWitness&&!S.flags.tinyBetrayed&&!S.flags.tinyGone)M.push({t:'"Tiny. On the Reliquary door. Tell them who came downstairs on Sunday."',once:'tb_tiny',ok:(st,S)=>{st.prog+=2;S.flags.tinySpoke=1;return [T('He comes down the steps from the street in his scarf, six foot six, mortal, grey, and stands in the chalk circle, and three hundred Kindred look at him like a buffet he has walked into on purpose.'),L('tiny','Sunday, half eleven. Grey suit, sunglasses. Lisette walked him down herself. He was with the Lady an hour. He came up with a folder and her perfume on him. I don\'t forget faces. Ever.'),L('severine','Tiny.',{if:S=>!S.flags.sevDead}),L('tiny','I quit, Lady. Effective now.')];}});
  if(S.flags.knowOttilie)M.push({t:'"Ask Lady Ottilie Brand who she\'s been reporting to since 2016."',once:'tb_ott',ok:(st,S)=>{st.prog+=2;S.flags.ottilieExposed=1;return [T('In the front row, a woman in grey pearls stands up very fast and sits down again faster. Two Court ghouls are already beside her.'),L('magistrate','Lady Ottilie. Remain seated. You will be remaining seated for some considerable time.')];}});
  if(S.flags.gigWatched)M.push({t:'"On Thursday, when a mortal comedian joked about the freezer door, three people in Elysium didn\'t laugh. One of them was the Keeper."',once:'tb_gig',ok:(st,S)=>{st.prog+=1;st.threat+=S.flags.side_court?1:0;return [L('severine','You brought a *comedian* as evidence.',{if:S=>!S.flags.sevDead}),L('magistrate','I find comedians very reliable witnesses. They notice everything, because they are afraid.')];}});
  if(S.flags.sevConfessed&&!S.flags.silentOnMargo)M.push({t:'"My lady told me herself: she took Harrow\'s offer. She fixed a door. She says doors are not hands."',once:'tb_sevc',ok:(st,S)=>{st.prog+=1;st.threat+=S.flags.side_court?2:1;S.flags.sevExposed=1;return [L('severine','...I said that in confidence. In my own crypt.',{if:S=>!S.flags.sevDead}),L('magistrate','Then you should have said it to someone less honest, Keeper.')];}});
  if(S.flags.valkoKnowsName)M.push({t:'"Valko. You know the name. Say it."',once:'tb_vname',ok:st=>{st.prog+=1;return [L('valko','Rostova fired it. Harrow ordered it. The Lady opened the door. The thief here pulled him out of the light with its teeth. I smelled every one of them on Monday and I didn\'t know what I was smelling until this week.')];}});
  if(S.flags.lisetteAlly&&S.flags.lisettePage)M.push({t:'Nod to Lisette.',once:'tb_lis',ok:(st,S)=>{st.prog+=1;return [L('lisette','Magistrate, if I may: the late Sheriff kept a ledger. One page has come to me. It shows he skimmed the Keeper\'s tithe for twenty years, and she never noticed. I raise it only so the record shows that nobody in this room is clean.'),T('The Court murmurs. Séverine smiles at Lisette with all her teeth, and Lisette smiles back with all of hers.')];}});
  if(S.flags.ashbyStands)M.push({t:'"Lord Ashby. You said you\'d stand."',once:'tb_ash',ok:st=>{st.prog+=1;return [L('ashby','And I do! Edmund Ashby, Ninth Baronet of nothing, vouches for the accused\'s *manners*, which are excellent, and their swordsmanship, which is tolerable.')];}});
  if(S.flags.margoTestify&&S.flags.silentOnMargo)M.forEach((m,i)=>{if(m.once==='tb_margo')M.splice(i,1);});
  if(S.flags.millerKnowsAll&&S.flags.millerEarly&&!S.flags.harrowDead)M.push({t:'Text Miller: "Now."',once:'tb_mil',ok:(st,S)=>{st.prog+=1;S.flags.side_miller=S.flags.side_miller||'tribunal';return [T('Up on the street, faintly, through the grate: sirens that aren\'t federal, and a woman\'s voice through a loudhailer saying a man\'s name.'),L('magistrate','...The mortals have arrived. How punctual of them.')];}});
  return M;};
// Soot speaks first if she was promised the floor
const intro0=ENC.tribunal.intro;
ENC.tribunal.intro=S=>{const base=typeof intro0==='function'?intro0(S):(intro0||[]);if(S.flags.sootSpeaksFirst&&!S.flags.sootDead){G.keep&&G.keep('sootfirst');return [...base,...NL.STORY.nodes['tbs.soot'].lines];}return base;};
})();

/* ---------- the extended epilogue: what everyone remembers ---------- */
(NL.Act.extraFates=NL.Act.extraFates||[]).push(S=>{const f=S.flags,out=[],R=NL.Rep;const rem=(id,k)=>NL.G.remembers(id,k);const like=id=>R.like(S,id);
  if(S.dos.tariq&&!f.dalekilled)out.push(['The Lucky Mart',f.breadSalt?'Keeps the other half of the bread roll in a jar by the till. Tells customers it\'s for "a guest".':f.tariqLamp?'Leaves the green lamp on every night. Nobody on the Strip knows why. Everybody on the Strip knows.':rem('tariq','slept')?'Sleeps four hours a night now. Says a nurse cured him.':'Still awake at four in the morning. In case.']);
  if(S.dos.tiny||f.tinyGone)out.push(['Tiny',f.tinyBetrayed?'"Retired" on Thursday. Nobody knows where. His clicker is in a drawer at the Reliquary, still reading 41,207.':f.tinySpoke?'Walked off the door forever after the Tribunal. Works at a garden center on the Heights. Knows every customer\'s face. Never tells.':f.tinyGhoul?'Still on the door, younger every month, and nobody can work out why.':S.tasks.s_tiny==='done'?'Back to three sessions a week. Beige, he says. Beige is an improvement.':'Hospital, the week after. He didn\'t tell anyone. He never does.']);
  if(S.dos.gideon)out.push(['Gideon',f.winterAwake?'Fixed the lid on box twelve. At the first frost, the bell over the door rang.':f.winterDone==='left'?'Goes down to the cistern every Tuesday with a thermos and sits by the still water for an hour.':'Still renting boxes. Sunrise guaranteed.']);
  if(f.ashbyDueled||S.tasks.s_coral)out.push(['Lord Ashby',f.ashbyDueled==='cheat'?'Never spoke to you again. Told everyone in Elysium you fight like a dog.':f.ashbyPaysWinter?'Founded the Winter Trust. A man with a tarpaulin still stands on Gideon\'s roof every dawn.':'Sends you a card every Christmas. Spelled correctly.']);
  if(S.tasks.s_coral)out.push(['Coral',f.ashbyCoral==='promised'?'Paid for her sister\'s whole degree. Quit dancing. Opened a dance school above the launderette.':'Still dancing. Still giving her elbows to someone downstairs.']);
  if(f.lisetteAlly||f.lisetteAmbition)out.push(['Lisette',f.sevDead?'Keeper of Elysium, by Saturday night. Nobody saw it coming except you.':f.lisettePage?'Standing behind Séverine\'s chair. Closer every year.':'Watching your doors. Always watching your doors.']);
  if(S.tasks.s_mateo)out.push(['Mateo "Teo" Miller',f.millerMetMateo?'Has dinner with his sister every Sunday at midnight. She cooks. He doesn\'t eat. They both pretend.':f.millerLetter?'Ines keeps his letter in her badge wallet. She hasn\'t been down to Platform 0 yet. She will.':f.millerMateoGone?'Ines closed his case. "Deceased." He reads about it in the paper, at the edge of Platform 0.':'Still at the edge of Platform 0. Still nineteen.']);
  if(f.readVaneLetter)out.push(['The Sheriff\'s letter',f.vaneLetterBurned?'Ashes, on Ferrier Lane.':f.letterRead?'Read aloud on Platform 0. Entered into the Prince\'s records. Pemberton has a copy, framed.':'In your coat. You read it again some nights.']);
  if(f.knowName)out.push(['Casey Morrow',f.cured?'Got ‹his|her› library card renewed. The librarian said, "You\'ve been away." Casey said, "Yes."':rem('tenant','read')?'Reads a letter from Agnes aloud every Friday, to the voice in their blood. He always cries at the same line.':'Says the name out loud sometimes, in the dark, just to hear it.']);
  // the reputation the Ward settled on
  const words=Object.keys(R.AXES).map(k=>R.word(S,k)).filter(w=>w!=='Undecided');
  if(words.length)out.push(['What the Ward says about you',words.join(', ')+'.']);
  return out;});
