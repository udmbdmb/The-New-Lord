'use strict';
/* THE NEW LORD — Teo and Ines before the platform; Junie's questions; Dutch on Friday; Ken after the shop */
NL.Script.add(String.raw`
# teY.0 arc=teo night=4,5 label="\"Teo. What will you say to her?\"" if=task:s_mateo&!flag:teoGone&!flag:millerMetMateo prio=3
@focus teo
teo: Say. To Ines. If I... when I...
teo: I've had thirteen years to work it out. Every night I stand across the road from the Lucky Mart and practice. "Hi, Ines." "Ines, it's me." "Ines, don't shoot."
teo: Last time I got as far as crossing the road. A bus came. I got back on the sidewalk and waited for it to pass, and when it had, I'd walked home.
* "You don't have to say anything. Just stand next to her."  -> teY.stand
* "Tell her the truth. All of it. She's had thirteen years of not knowing."  -> teY.truth
* "Do you want me to tell her first?"  -> teY.me

# teY.stand
teo: Stand next to her. Like when we were kids at the bus stop. She'd stand in front of me so the big guys couldn't see me.
teo: ...Yeah. I can do standing. I'm good at standing.
{do flag:teoStand=1; rel:teo+1}
@end

# teY.truth
teo: All of it. The girl in the alley, Rina, who was sorry. The union. The windows. Thirteen years of watching her through the windows like a... like a ghost.
teo: She'll hate me. She'll hate me for every one of those years.
? velvet 10 "She won't. She'll hate the years. Not you. There's a difference."  -> teY.truthok | teY.truthno {id teY_v}

# teY.truthok
teo: ...The years. Not me. Yeah. Yeah, maybe.
{do flag:teoTruth=1; rel:teo+2}
@end

# teY.truthno
teo: You don't know her. She hates everything. She hates the coffee and she drinks it every night anyway.
@end

# teY.me
teo: You. Tell her. Before I... yeah. Yeah. Would you? Just so the first time she hears it isn't from my face.
* "I'll tell her."  -> teY.me2 {do promise:teoines:Tell Ines about Teo before he sees her}

# teY.me2
teo: Thanks. Thanks. Tell her I'm sorry about the Twix. She'll know.
{do flag:teoAskedYou=1; rel:teo+2}
@end

# teY.ines arc=miller night=4,5 label="\"Ines. Sit down. It's about Mateo.\"" if=flag:teoAskedYou&!flag:millerMetMateo prio=9
@focus miller
> She sits. She sees your face. She puts her coffee down very carefully on the magazine rack, as if it might explode.
miller: Is he dead. Just say it. I've had thirteen years to get ready. Just say it.
* "He's dead. And he's not. He's like me. And he's been watching you every night since 2011."  -> teY.ines2

# teY.ines2
> She doesn't say anything for a long time. Her hand goes to her mouth.
miller: ...Watching me.
miller: The Lucky Mart. Two in the morning. A kid across the road in a hoodie. I thought he was a dealer. I nearly arrested him in 2017.
miller: That was Teo. That was Teo, and I nearly...
> She laughs, horribly, and then puts her face in her hands.
miller: He says he's sorry about the Twix, doesn't he. He'd say that. The idiot. He'd say that.
{do keep:teoines; rel:miller+2; flag:millerKnowsTeo=1}
@end

# juY.0 arc=junie night=5 label="\"Junie. Ask me anything.\"" if=room:rookery&!flag:junieDone prio=-1
@focus junie
junie: Anything. Okay. I've got a list. I'm a nurse. We make lists.
junie: One. Does sunlight hurt or does it just kill you? Two. Do you have a pulse? Three. If Leo gets bitten again, what do I do? Four. Are there more of you in the hospital, because I think there's one on nights in Pathology.
* Answer them all. Honestly.  -> juY.all {do lean:candour+1}
* "Three's the important one."  -> juY.three

# juY.all
> You answer them all. She writes it all down on the back of a prescription pad. It hurts and then it kills. No pulse. Clean the wound, call you, don't let him go to a stranger. And probably, yes, Pathology; they always end up in Pathology.
junie: Okay. Okay. That's actually really useful. Thank you. Nobody ever answers the list.
{do rel:junie+2; rel:leo+1}
@end

# juY.three
junie: Three. If he gets bitten. Okay. Tell me.
> You tell her. She writes it down. She underlines it twice.
junie: Thank you. I'm going to laminate this.
{do rel:junie+1}
@end

# duY.0 arc=dutch night=5 label="\"Dutch. Whatever happens tonight.\"" if=flag:side_union&room:switchyard prio=2
@focus dutch
dutch: Whatever happens. Yeah. I know.
dutch: Thirty-eight years I've been chair of Local 0. I've never once won a vote at Elysium. Never once been asked. Tonight, sixty-three of us are walking onto the Court's platform, in our boots, for the Sheriff-eater.
dutch: If it goes wrong, they'll remember our faces. They'll come for us on Saturday. I know that. The membership knows that. We voted anyway. Unanimous.
* "Then I'll make sure it doesn't go wrong."  -> duY.1
* "Go home, Dutch. All of you. It's not worth it."  -> duY.2

# duY.1
dutch: Make sure. Ha. Nobody can make sure. But I like that you said it. Item five, in the minutes.
{do rel:dutch+1}
@end

# duY.2
dutch: Not worth it. Brother, sister, whatever. Nothing we've ever done has been worth it. That's not why we do it.
dutch: We're staying.
@end

# kpY.0 arc=kenpruitt night=5 label="\"Ken. Are you all right?\"" if=flag:pruittShamed|flag:kenConfessRosa|flag:daleConfess prio=1
@focus kenpruitt
kenpruitt: All right. I'm on the cordon tonight, round the Switchyard. "Gas leak." I know what it is now. I know what's down there.
kenpruitt: I've decided something. When it starts, whatever it is, I'm not holding the line. I'm going to walk off the cordon and stand outside 3B. Where my nephew is. I've never once stood outside anything for anyone.
* "Good."  -> kpY.1
* "Stay on the cordon. Keep the mortals out. That's how you protect him."  -> kpY.2

# kpY.1
kenpruitt: Good. Yeah. Good. Rosa'd say good. Rosa'd say "about time, Kenneth".
{do rel:kenpruitt+1}
@end

# kpY.2
kenpruitt: The cordon. Keep them out. ...Yeah. Yeah, that's smarter. That's actually protecting him. Okay.
kenpruitt: I'll stand at the end of Halloran Street. Nobody comes down it. Nobody.
{do rel:kenpruitt+1; flag:kenCordon=1}
@end

# hlZ.0 arc=halloran night=4 label="\"Mr. Halloran. How is Maureen?\"" if=room:rookery&!flag:halloranGone&rel:halloran>=2 prio=1
@focus halloran
halloran: All right. She's fine. She's always fine. She's upstairs with her feet up watching a program about people buying houses in Spain. She's never been to Spain. She hates the sun.
halloran: Fifty-one years. You know what she said to me this morning? "Desmond, if you die before me I'll never forgive you." That's love, that is. That's what love sounds like after fifty-one years.
* "What did you say?"  -> hlZ.1

# hlZ.1
halloran: I said, "Maureen, I'll do my best." And she said, "You always say that." And she's right. I always say that.
> He rattles the bag of cat food. Somewhere below, thirty-one cats that aren't his start to come.
{do rel:halloran+1; comp+1}
@end
`,'c_more8');
