'use strict';
/* THE NEW LORD — the wider Marrow Ward: Night One locations (more are appended by later nights) */
(function(){
const NL=window.NL;const {Geo,M4}=NL;const PI=Math.PI;const ROOMS=NL.ROOMS,M=NL.M,mats=NL.mats,TX=NL.Tex;

/* ---------- textures ---------- */
function sign(txt,o){o=o||{};return()=>{const w=o.w||512,h=o.h||128,c=TX.cv(w,h),x=c.getContext('2d');if(o.bg){x.fillStyle=o.bg;x.fillRect(0,0,w,h);}else x.clearRect(0,0,w,h);
  if(o.frame){x.strokeStyle=o.frame;x.lineWidth=6;x.strokeRect(5,5,w-10,h-10);}
  x.font=o.font||'800 64px "Barlow Condensed",sans-serif';x.textAlign='center';x.textBaseline='middle';if(o.glow){x.shadowColor=o.glow;x.shadowBlur=o.blur||20;}
  x.fillStyle=o.fg||'#fff';if(o.mirror){x.save();x.translate(w,0);x.scale(-1,1);}
  (Array.isArray(txt)?txt:[txt]).forEach((t,i,a)=>x.fillText(t,w/2,h/2+(i-(a.length-1)/2)*(o.lh||70)));if(o.glow){x.shadowBlur=(o.blur||20)/2;(Array.isArray(txt)?txt:[txt]).forEach((t,i,a)=>x.fillText(t,w/2,h/2+(i-(a.length-1)/2)*(o.lh||70)));}
  if(o.mirror)x.restore();return c;};}
TX.add('sLucky',sign('LUCKY MART · 24H',{fg:'#b8ffcf',glow:'#30ff8a',font:'800 66px "Barlow Condensed",sans-serif'}));
TX.add('sReliq',sign('RELIQUARY',{fg:'#ffd0f0',glow:'#ff3ab0',font:'italic 700 84px "Bodoni Moda",serif',blur:26}));
TX.add('sPawn',sign(['PAWN & COFFIN','LOANS · BOXES · NO QUESTIONS'],{bg:'#2a1a10',fg:'#e8c87a',frame:'#8a6a30',font:'700 40px "Barlow Condensed",sans-serif',lh:46}));
TX.add('sJude',sign(['ST. JUDE\'S','NIGHT CLINIC · ENTRANCE'],{bg:'#e8eef0',fg:'#14506a',frame:'#14506a',font:'800 46px "Barlow Condensed",sans-serif',lh:50}));
TX.add('sExit',sign('EXIT',{w:256,h:96,bg:'#0d2a14',fg:'#5cff8a',glow:'#2aff6a',font:'800 60px "Barlow Condensed",sans-serif'}));
TX.add('sVip',sign('VIP · PRIVATE',{w:384,h:96,fg:'#ffc8e8',glow:'#ff40a0',font:'700 52px "Barlow Condensed",sans-serif'}));
TX.add('lino',()=>{const c=TX.cv(512),x=c.getContext('2d'),R=TX.rng(301);x.fillStyle='#bfc4b6';x.fillRect(0,0,512,512);for(let i=0;i<8;i++)for(let j=0;j<8;j++){const v=R();x.fillStyle=(i+j)%2?`rgba(120,130,118,${.25+v*.1})`:`rgba(235,238,225,${.2+v*.1})`;x.fillRect(i*64,j*64,64,64);}
  TX.blotch(x,512,512,R,24,(R,a)=>`rgba(70,70,60,${a})`,.16,20,90);TX.speckle(x,512,512,R,2000,R=>R()<.5?'#6a6e64':'#e8ebe0',.12,.3,.4,1.4);x.strokeStyle='rgba(60,60,55,.3)';for(let i=0;i<=8;i++){x.beginPath();x.moveTo(i*64,0);x.lineTo(i*64,512);x.moveTo(0,i*64);x.lineTo(512,i*64);x.stroke();}return c;});
TX.add('stone',()=>{const c=TX.cv(512),x=c.getContext('2d'),R=TX.rng(311);x.fillStyle='#4a4038';x.fillRect(0,0,512,512);for(let j=0;j<8;j++){const off=(j%2)*48;for(let i=-1;i<6;i++){const v=R();x.fillStyle=`rgb(${92+v*30},${80+v*24},${70+v*20})`;x.fillRect(i*96+off+3,j*64+3,90,58);}}
  TX.blotch(x,512,512,R,30,(R,a)=>R()<.5?`rgba(20,15,12,${a})`:`rgba(150,130,110,${a})`,.22,20,80);TX.speckle(x,512,512,R,2500,R=>R()<.5?'#2a221c':'#a8988a',.15,.4,.5,1.6);return c;});
TX.add('velvet',()=>{const c=TX.cv(256),x=c.getContext('2d'),R=TX.rng(321);x.fillStyle='#5a0d22';x.fillRect(0,0,256,256);for(let i=0;i<256;i+=8){x.fillStyle=`rgba(255,120,160,${.04+R()*.05})`;x.fillRect(i,0,3,256);}TX.blotch(x,256,256,R,12,(R,a)=>`rgba(20,0,6,${a})`,.25,20,70);return c;});
TX.add('dance',()=>{const c=TX.cv(512),x=c.getContext('2d');x.fillStyle='#08060c';x.fillRect(0,0,512,512);const cols=['#ff3ab0','#3ad0ff','#7a3aff','#ff7a3a'];for(let i=0;i<4;i++)for(let j=0;j<4;j++){const g=x.createRadialGradient(i*128+64,j*128+64,4,i*128+64,j*128+64,62);g.addColorStop(0,cols[(i*3+j)%4]);g.addColorStop(1,'rgba(0,0,0,0)');x.globalAlpha=.55;x.fillStyle=g;x.fillRect(i*128+3,j*128+3,122,122);}x.globalAlpha=1;return c;});
TX.add('shelfgoods',()=>{const c=TX.cv(512,256),x=c.getContext('2d'),R=TX.rng(331);x.fillStyle='#222';x.fillRect(0,0,512,256);const cols=['#d23246','#e2c27e','#3a8ad0','#5ac04a','#f0f0e8','#ff8a2a','#8a3ad0','#30c0b0'];
  for(let r=0;r<4;r++){let px=2;while(px<510){const w=10+R()*26,h=30+R()*30;x.fillStyle=cols[Math.floor(R()*cols.length)];x.fillRect(px,r*64+62-h,w-2,h);x.fillStyle='rgba(255,255,255,.25)';x.fillRect(px,r*64+62-h,2,h);px+=w;}x.fillStyle='#bbb';x.fillRect(0,r*64+60,512,4);}return c;});
TX.add('fridge',()=>{const c=TX.cv(256,512),x=c.getContext('2d'),R=TX.rng(341);x.fillStyle='#cfe8f0';x.fillRect(0,0,256,512);const cols=['#d23246','#2a6ad0','#f0d020','#30b040','#f07020','#e0e0e0'];
  for(let r=0;r<6;r++){for(let i=0;i<8;i++){x.fillStyle=cols[Math.floor(R()*cols.length)];x.fillRect(8+i*30,r*84+20,20,58);x.fillStyle='rgba(255,255,255,.4)';x.fillRect(10+i*30,r*84+24,4,48);}x.fillStyle='#9ab';x.fillRect(0,r*84+80,256,4);}x.strokeStyle='#555';x.lineWidth=10;x.strokeRect(0,0,256,512);return c;});
TX.add('stained',()=>{const c=TX.cv(256,512),x=c.getContext('2d'),R=TX.rng(351);x.fillStyle='#120a14';x.fillRect(0,0,256,512);const cols=['#c02040','#2050c0','#e0b030','#30a060','#8030c0'];
  for(let i=0;i<70;i++){x.fillStyle=cols[Math.floor(R()*cols.length)];x.globalAlpha=.75;x.beginPath();const cx=R()*256,cy=R()*512;x.moveTo(cx,cy);for(let k=0;k<4;k++)x.lineTo(cx+(R()-.5)*90,cy+(R()-.5)*90);x.fill();}
  x.globalAlpha=1;x.strokeStyle='#120a14';x.lineWidth=6;for(let i=0;i<40;i++){x.beginPath();x.moveTo(R()*256,R()*512);x.lineTo(R()*256,R()*512);x.stroke();}x.lineWidth=14;x.strokeRect(0,0,256,512);x.beginPath();x.arc(128,120,128,PI,0);x.stroke();return c;});
TX.add('clinicwall',()=>{const c=TX.cv(512),x=c.getContext('2d'),R=TX.rng(361);x.fillStyle='#a8c4b8';x.fillRect(0,0,512,512);x.fillStyle='#7fa898';x.fillRect(0,330,512,182);x.fillStyle='#5a7a70';x.fillRect(0,326,512,8);TX.blotch(x,512,512,R,20,(R,a)=>`rgba(60,70,60,${a})`,.12,20,90);TX.speckle(x,512,512,R,1500,R=>'#5a6a60',.08,.2,.5,1.2);return c;});
TX.add('poster2',sign(['GIVE BLOOD','SAVE A LIFE'],{w:256,h:340,bg:'#f0e8e0',fg:'#c02030',frame:'#c02030',font:'800 46px "Barlow Condensed",sans-serif',lh:56}));
TX.add('flyer',sign(['TUESDAY','OPEN MIC','LANTERN ROOM'],{w:256,h:340,bg:'#1a1a1a',fg:'#ffd040',font:'800 40px "Barlow Condensed",sans-serif',lh:52}));
TX.add('clock',()=>{const c=TX.cv(128),x=c.getContext('2d');x.fillStyle='#e8e0d0';x.beginPath();x.arc(64,64,58,0,7);x.fill();x.strokeStyle='#222';x.lineWidth=6;x.stroke();x.lineWidth=4;x.beginPath();x.moveTo(64,64);x.lineTo(64,26);x.moveTo(64,64);x.lineTo(92,70);x.stroke();return c;});

/* ---------- extra materials ---------- */
let XM=null;
function xm(){if(XM)return XM;const m=mats();XM={
  lino:M([1,1,1],{tex:'lino',texScale:.6,spec:.6,mottle:.15}),stone:M([1,1,1],{tex:'stone',texScale:.45,spec:.15}),velvet:M([1,1,1],{tex:'velvet',texScale:1.2,spec:.25}),
  dance:M([1,1,1],{tex:'dance',texScale:.5,spec:1.2,emisK:.9,mottle:0}),shelf:M([1,1,1],{tex:'shelfgoods',texScale:1,spec:.3,mottle:.05}),fridge:M([1,1,1],{tex:'fridge',texScale:1,emisK:.7,spec:.8,mottle:0}),
  stained:M([1,1,1],{tex:'stained',texScale:1,emisK:1.1,mottle:0}),clinic:M([1,1,1],{tex:'clinicwall',texScale:.4,spec:.15}),
  darkFloor:M([.08,.07,.1],{spec:1.6,mottle:.2}),brass:M([.75,.55,.25],{spec:1.3,mottle:.1}),mahog:M([.35,.16,.1],{tex:'wood',texScale:.8,spec:.5}),
  pale:M([.85,.88,.86],{spec:.3}),blue:M([.3,.5,.62],{spec:.4}),candle:M([1,1,1],{emis:[1,.75,.35],mottle:0}),magenta:M([1,1,1],{emis:[1,.2,.7],mottle:0}),cyan:M([1,1,1],{emis:[.2,.85,1],mottle:0}),
  greenGlow:M([1,1,1],{emis:[.3,1,.55],mottle:0}),curtain:M([.55,.7,.68],{spec:.1,mottle:.3}),bone:M([.88,.84,.74],{spec:.3,mottle:.3}),coffin:M([.18,.1,.07],{tex:'wood',texScale:.9,spec:.7}),
  sLucky:M([1,1,1],{tex:'sLucky',decal:true,mottle:0,emisK:2}),sReliq:M([1,1,1],{tex:'sReliq',decal:true,mottle:0,emisK:2.4}),sPawn:M([1,1,1],{tex:'sPawn',decal:true,mottle:0,emisK:.3}),
  sJude:M([1,1,1],{tex:'sJude',decal:true,mottle:0,emisK:.6}),sExit:M([1,1,1],{tex:'sExit',decal:true,mottle:0,emisK:1.6}),sVip:M([1,1,1],{tex:'sVip',decal:true,mottle:0,emisK:2}),
  poster2:M([1,1,1],{tex:'poster2',decal:true,mottle:0}),flyer:M([1,1,1],{tex:'flyer',decal:true,mottle:0}),clock:M([1,1,1],{tex:'clock',decal:true,mottle:0})
};return XM;}
NL.xm=xm;

/* ---------- prop helpers ---------- */
const P={
  shelf(rb,x0,z0,x1,z1,h,face){const m=mats(),x=xm();rb.box([x0,0,z0],[x1,h,z1],m.steelDark,{block:true});
    const d=0.012;if(face==='z')rb.decal([(x0+x1)/2,h/2+0.05,z1+d],[x1-x0-0.06,0,0],[0,h-0.12,0],[0,0,1],M([1,1,1],{tex:'shelfgoods',decal:true,mottle:0,spec:.3}));
    if(face==='x')rb.decal([x1+d,h/2+0.05,(z0+z1)/2],[0,0,-(z1-z0-0.06)],[0,h-0.12,0],[1,0,0],M([1,1,1],{tex:'shelfgoods',decal:true,mottle:0,spec:.3}));},
  chair(rb,x,z,rot,mat){const m=mats();const Mx=M4.trs([x,0,z],[0,rot||0,0]);rb.part(Geo.box(0.44,0.05,0.42),M4.mul(Mx,M4.trs([0,0.45,0])),mat||m.black);rb.part(Geo.box(0.44,0.45,0.05),M4.mul(Mx,M4.trs([0,0.7,-0.2])),mat||m.black);
    [[-0.19,-0.18],[0.19,-0.18],[-0.19,0.18],[0.19,0.18]].forEach(p=>rb.part(Geo.cyl(0.015,0.015,0.45,6),M4.mul(Mx,M4.trs([p[0],0,p[1]])),m.steelDark,{noDepth:true}));rb.block(x-0.25,z-0.25,x+0.25,z+0.25);},
  candle(rb,x,y,z){const m=mats(),X=xm();rb.cyl([x,y,z],0.02,0.022,0.12,X.bone,{noDepth:true});rb.sph([x,y+0.15,z],[0.012,0.025,0.012],X.candle,{noDepth:true});},
  bottles(rb,x0,x1,y,z,n){const m=mats();const cols=[M([.15,.35,.2],{spec:1.6,mottle:0}),M([.4,.2,.08],{spec:1.6,mottle:0}),M([.7,.75,.8],{alpha:.5,spec:1.8,mottle:0}),M([.3,.05,.1],{spec:1.6,mottle:0})];
    for(let i=0;i<n;i++){const x=x0+(x1-x0)*i/(n-1);const c=cols[i%4];rb.cyl([x,y,z],0.035,0.035,0.2,c,{noDepth:true});rb.cyl([x,y+0.2,z],0.012,0.03,0.08,c,{noDepth:true});}},
  door(rb,x0,x1,z,h,mat){const m=mats();rb.box([x0-0.06,0,z],[x1+0.06,h+0.06,z+0.05],m.steelDark);rb.box([x0,0,z+0.05],[x1,h,z+0.09],mat||m.woodDark);rb.box([x1-0.14,h*0.48,z+0.09],[x1-0.08,h*0.52,z+0.13],m.chrome,{noDepth:true});},
  doorX(rb,z0,z1,x,h,mat){const m=mats();rb.box([x,0,z0-0.06],[x+0.05,h+0.06,z1+0.06],m.steelDark);rb.box([x+0.05,0,z0],[x+0.09,h,z1],mat||m.woodDark);rb.box([x+0.09,h*0.48,z1-0.14],[x+0.13,h*0.52,z1-0.08],m.chrome,{noDepth:true});},
  tube(rb,x0,x1,y,z){const m=mats();rb.box([x0,y,z-0.05],[x1,y+0.05,z+0.05],m.tube,{noDepth:true});},
  tubeZ(rb,z0,z1,y,x){const m=mats();rb.box([x-0.05,y,z0],[x+0.05,y+0.05,z1],m.tube,{noDepth:true});},
  exitMat(rb,x,z,w,d){const m=mats();rb.floor(x,z,w,d,M([.12,.1,.09],{decal:true,mottle:.3,spec:0}));}
};
NL.PROPS=P;

/* ---------- extra poses ---------- */
const PO=NL.POSES;
PO.dance=(a,t)=>{const o=PO.idle(a,t);const p=t*4.1+a.seed*3;o['hips.y']=-Math.abs(Math.sin(p))*0.05;o['hips.rz']=Math.sin(p*0.5)*0.12;o['spine.rz']=-Math.sin(p*0.5)*0.1;o['shL.rx']=-0.6-Math.sin(p)*0.5;o['shR.rx']=-0.6+Math.sin(p)*0.5;o['elL.rx']=-1.2;o['elR.rx']=-1.2;o['head.rx']=Math.sin(p)*0.12;o['knL.rx']=Math.max(0,Math.sin(p))*0.3;o['knR.rx']=Math.max(0,-Math.sin(p))*0.3;return o;};
PO.lean=(a,t)=>{const o=PO.idle(a,t);o['spine.rx']=-0.05;o['shL.rx']=-0.3;o['elL.rx']=-1.6;o['shR.rx']=0.25;o['hipR.rx']=-0.2;o['knR.rx']=0.3;o['hips.rz']=0.08;return o;};
PO.kneel=(a,t)=>{const o=PO.idle(a,t);o['hips.y']=-0.48;o['hipL.rx']=-1.5;o['knL.rx']=1.5;o['hipR.rx']=0.1;o['knR.rx']=1.55;o['anR.rx']=0.4;o['spine.rx']=0.25;o['head.rx']=0.35;return o;};
PO.cower=(a,t)=>{const o=PO.crouch(a,t);o['shL.rx']=-2.4;o['shR.rx']=-2.4;o['elL.rx']=-1.9;o['elR.rx']=-1.9;o['head.rx']=0.5;o['spine.rx']=0.6;return o;};
PO.point=(a,t)=>{const o=PO.idle(a,t);o['shR.rx']=-1.45;o['shR.rz']=-0.1;o['elR.rx']=-0.05;return o;};
PO.wipe=(a,t)=>{const o=PO.idle(a,t);const p=t*3;o['shR.rx']=-0.7+Math.sin(p)*0.12;o['elR.rx']=-1.3;o['shR.ry']=Math.sin(p)*0.4;o['spine.rx']=0.15;o['head.rx']=0.3;return o;};
PO.typing=(a,t)=>{const o=PO.sit(a,t);o['shL.rx']=-0.8;o['shR.rx']=-0.8;o['elL.rx']=-1.1;o['elR.rx']=-1.1;o['head.rx']=0.35;o['elL.rz']=Math.sin(t*9)*0.05;return o;};

/* ---------- Ferrier Lane (the prologue alley becomes Block A's street) ---------- */
const AL=ROOMS.alley;AL.name='Ferrier Lane';AL.sub='Block A · the Abattoir Strip';AL.map=true;AL.ambience='alley';
const alBuild=AL.build.bind(AL);
AL.build=function(rb,S){alBuild(rb,S);const m=mats(),X=xm();
  // Lucky Mart side door on the back wall
  P.door(rb,7.75,8.6,0,2.2,M([.55,.75,.7],{alpha:.55,spec:1.6,mottle:0}));rb.box([7.78,0,0.02],[8.57,2.15,0.04],M([.6,1,.75],{emis:[.25,.6,.35],mottle:0}),{noDepth:true});
  rb.wallZ(8.18,2.65,1.5,0.38,X.sLucky);
  // payphone on the left wall
  rb.box([0,1.0,5.25],[0.22,1.85,5.75],m.steelDark,{block:true});rb.box([0.22,1.25,5.35],[0.26,1.7,5.65],m.chrome);rb.box([0.2,1.55,5.3],[0.3,1.62,5.42],m.black,{noDepth:true});
  rb.box([0,1.88,5.15],[0.45,1.95,5.85],m.steelDark,{noDepth:true});rb.wallX(5.5,2.1,0.6,0.24,M([1,1,1],{tex:'sExit',decal:true,mottle:0,emisK:.4}));
  rb.wallX(4.6,1.1,0.4,0.52,X.flyer);
};
const alLights=AL.lights.bind(AL);
AL.lights=S=>alLights(S).concat([{pos:[8.2,1.6,0.7],color:[.4,1,.6],intensity:.9,range:3.5}]);
AL.exits=[{id:'toMart',label:'Lucky Mart',at:[8.18,1.5,0.1],box:[7.75,0,0,8.6,2.2,0.2],stand:[8.18,0.85],face:[8.18,0],to:'luckymart',spawn:{x:1.55,z:0.9,ry:0}},
  {id:'toBackKow',label:'Kowalski\'s back door',at:[2.5,1.3,0.1],box:[1.95,0,0,3.05,2.3,0.2],stand:[2.5,0.95],face:[2.5,0],to:'backroom',spawn:{x:7.6,z:5.3,ry:PI},if:S=>S.flags.backDoorOpen&&S.flags.mapOK}];
AL.inter=AL.inter.concat([{id:'payphone',label:'Rusty payphone',at:[0.25,1.5,5.5],box:[0,1,5.2,0.3,1.9,5.8],stand:[0.95,5.5],face:[0,5.5]},
  {id:'flyer',label:'Open-mic flyer',at:[0.05,1.1,4.6],box:[0,0.8,4.35,0.15,1.4,4.85],stand:[0.9,4.6],face:[0,4.6]}]);

/* ---------- The Midnight Lucky Mart ---------- */
ROOMS.luckymart={id:'luckymart',name:'The Midnight Lucky Mart',sub:'Block A · Ferrier Lane',W:8,D:6,H:3,ambience:'store',bright:true,
  sky:[.24,.28,.26],ground:[.1,.1,.1],
  grade:{sh:[.75,.9,.85],hi:[1.05,1.02,.92],ink:[.03,.05,.05],sat:.92,wash1:[.02,.03,.03],wash2:[.07,.09,.08]},
  shadow:{pos:[4,2.9,3],target:[3.6,0,2.6],fov:2.2,far:10,idx:0},
  lights(S){return [{pos:[4,2.9,3],color:[.92,1,.95],intensity:1.6,range:10},{pos:[2,2.9,2],color:[.95,1,.96],intensity:.9,range:6},{pos:[5.4,1.2,0.5],color:[.7,.9,1],intensity:.9,range:3.5},{pos:[1.5,1.4,0.4],color:[1,.65,.3],intensity:.7,range:3}];},
  flicker(t){return 1-0.08*(Math.sin(t*31)>0.92?1:0);},
  build(rb,S){const m=mats(),X=xm();
    rb.shell(8,6,3,X.lino,m.plaster,m.plaster,m.cap,{lowerH:1.1,lowerL:m.subway,lowerR:m.subway});
    // entrance (glass) on back wall
    P.door(rb,1.0,2.1,0,2.3,M([.5,.65,.75],{alpha:.45,spec:1.8,mottle:0}));rb.box([1.02,0,0.02],[2.08,2.25,0.04],M([1,.7,.35],{emis:[.55,.33,.12],mottle:0}),{noDepth:true});
    rb.floor(1.55,0.6,1.2,0.8,M([.15,.14,.13],{decal:true,mottle:.4,spec:0}));
    // drink fridges
    for(let i=0;i<4;i++){const x=3.2+i*1.1;rb.box([x,0,0],[x+1.05,2.3,0.55],m.steelDark,{block:true});rb.decal([x+0.52,1.15,0.56],[0.95,0,0],[0,2.1,0],[0,0,1],M([1,1,1],{tex:'fridge',decal:true,mottle:0,emisK:.9,spec:1.2}));}
    // counter along z, cigarette rack behind
    rb.box([1.3,0,1.7],[2.0,1.0,3.9],m.woodDark,{block:true});rb.box([1.25,1.0,1.65],[2.05,1.05,3.95],m.steelBright);
    rb.box([1.4,1.05,2.3],[1.85,1.35,2.75],m.black);rb.box([1.45,1.35,2.35],[1.8,1.42,2.6],m.steelDark,{noDepth:true});
    rb.box([1.45,1.05,3.1],[1.9,1.5,3.55],m.steelDark);rb.cyl([1.6,1.05,3.25],0.07,0.07,0.22,M([.15,.1,.05],{spec:1.4}),{noDepth:true});rb.cyl([1.75,1.05,3.4],0.07,0.07,0.22,M([.15,.1,.05],{spec:1.4}),{noDepth:true});
    rb.box([0,1.1,1.6],[0.35,2.4,3.8],m.woodDark);rb.decal([0.36,1.75,2.7],[0,0,-2.1],[0,1.2,0],[1,0,0],M([1,1,1],{tex:'shelfgoods',decal:true,mottle:0}));
    // aisles
    P.shelf(rb,3.4,1.6,7.2,2.0,1.45,'z');P.shelf(rb,3.4,3.0,7.2,3.4,1.45,'z');P.shelf(rb,3.4,4.4,6.4,4.8,1.45,'z');
    // magazine rack + coffee
    rb.box([2.3,0,4.6],[3.0,1.0,5.2],m.steelDark,{block:true});rb.decal([2.65,0.6,5.21],[0.6,0,0],[0,0.7,0],[0,0,1],M([1,1,1],{tex:'shelfgoods',decal:true,mottle:0}));
    // restroom door + lottery poster on left wall
    P.doorX(rb,4.6,5.4,0,2.1,m.white);rb.wallX(4.1,1.5,0.4,0.52,X.flyer);rb.wallX(1.0,2.6,0.5,0.4,X.clock);
    P.tube(rb,2.5,6.5,2.9,1.6);P.tube(rb,2.5,6.5,2.9,3.6);P.tubeZ(rb,1.5,4.5,2.9,1.65);
    rb.box([0.6,0,5.6],[1.2,0.9,6.0],m.red,{block:true});
  },
  spawn:{x:1.55,z:0.95,ry:0.3},map:false,
  exits:[{id:'martOut',label:'Ferrier Lane',at:[1.55,1.4,0.1],box:[1.0,0,0,2.1,2.3,0.2],stand:[1.55,0.85],face:[1.55,0],to:'alley',spawn:{x:8.18,z:1.0,ry:PI*0.9}}],
  inter:[{id:'coffee',label:'Coffee machine',at:[1.68,1.55,3.3],box:[1.4,1,3.05,1.95,1.6,3.6],stand:[2.6,3.3],face:[1.7,3.3]},
    {id:'martmirror',label:'Restroom',at:[0.1,1.4,5.0],box:[0,0,4.6,0.2,2.1,5.4],stand:[0.85,5.0],face:[0,5.0]},
    {id:'aisle',label:'Aisle 2',at:[5.3,1.6,3.2],box:[3.4,0,3.0,7.2,1.45,3.4],stand:[5.3,3.9],face:[5.3,3.2]},
    {id:'fridges',label:'Drinks fridges',at:[5.4,1.6,0.6],box:[3.2,0,0,7.6,2.3,0.6],stand:[5.4,1.2],face:[5.4,0]}],
  particles:[{type:'motes',n:25,area:[0.5,7.5,0.5,5.5],y:[0.4,2.6],col:[.8,1,.9]}]
};

/* ---------- Club Reliquary ---------- */
ROOMS.reliquary={id:'reliquary',name:'Club Reliquary',sub:'Block B · Reliquary Row',W:11,D:7,H:4.4,ambience:'club',art:true,map:true,
  sky:[.16,.08,.2],ground:[.05,.02,.06],
  grade:{sh:[.9,.55,1.1],hi:[1.1,.92,1.05],ink:[.04,.01,.06],sat:1.05,wash1:[.03,.01,.04],wash2:[.1,.03,.12]},
  shadow:{pos:[5.5,4.2,2.2],target:[5.4,0,3.4],fov:2.1,far:12,idx:0},
  lights(S){return [{pos:[5.5,4.2,2.2],color:[1,.25,.75],intensity:2.2,range:11},{pos:[2.2,3.6,4.5],color:[.25,.8,1],intensity:1.6,range:8},{pos:[8.8,3.2,5.2],color:[.6,.3,1],intensity:1.3,range:7},{pos:[5.5,2.4,0.4],color:[1,.6,.4],intensity:1.1,range:5},{pos:[10,1.6,1.2],color:[1,.3,.6],intensity:.9,range:3}];},
  flicker(t){return 0.85+0.15*Math.sin(t*8.2)*Math.sin(t*1.3);},
  build(rb,S){const m=mats(),X=xm();
    rb.shell(11,7,4.4,X.darkFloor,X.stone,X.stone,m.cap);
    rb.floor(5.4,3.9,4.4,3.2,X.dance);
    // stage + DJ booth under the stained glass (it was a church)
    rb.box([3.3,0,0],[7.7,0.45,1.5],X.mahog,{block:true});rb.box([4.6,0.45,0.3],[6.4,1.4,0.9],m.black,{block:true});rb.box([4.7,1.4,0.35],[6.3,1.46,0.85],X.cyan,{noDepth:true});
    rb.decal([5.5,2.9,0.012],[1.4,0,0],[0,2.6,0],[0,0,1],X.stained);rb.decal([3.0,2.9,0.012],[0.8,0,0],[0,2.0,0],[0,0,1],X.stained);rb.decal([8.0,2.9,0.012],[0.8,0,0],[0,2.0,0],[0,0,1],X.stained);
    rb.decal([5.5,4.05,0.02],[3.2,0,0],[0,0.7,0],[0,0,1],X.sReliq);
    // organ pipes on the left wall (the choir loft)
    for(let i=0;i<9;i++){const z=1.2+i*0.32,h=2.2+Math.sin(i*1.1)*0.6+(4-Math.abs(i-4))*0.25;rb.cyl([0.25,1.6,z],0.09,0.09,h,X.brass);}
    rb.box([0,1.3,0.9],[0.55,1.6,4.3],X.mahog);
    // bar along the left wall, front
    rb.box([0.9,0,4.6],[1.7,1.1,6.8],X.mahog,{block:true});rb.box([0.85,1.1,4.55],[1.75,1.16,6.85],m.chrome);
    rb.box([0,1.4,4.5],[0.35,1.45,6.9],m.steelDark,{noDepth:true});P.bottles(rb,0.15,0.15,1.45,4.7,2);for(let k=0;k<7;k++)P.bottles(rb,0.15,0.16,1.45,4.7+k*0.3,2);
    rb.box([0.88,1.16,5.0],[1.2,1.2,5.4],X.magenta,{noDepth:true});
    // VIP stair: velvet rope and arch at the back right
    rb.box([9.2,0,0],[10.9,3.0,0.2],X.stone);rb.box([9.5,0,0.05],[10.6,2.6,0.12],M([.02,.01,.02],{mottle:0}),{noDepth:true});rb.decal([10.05,2.85,0.21],[1.0,0,0],[0,0.26,0],[0,0,1],X.sVip);
    [9.35,10.75].forEach(x=>{rb.cyl([x,0,1.2],0.04,0.04,0.95,X.brass);rb.sph([x,0.98,1.2],[0.06,0.06,0.06],X.brass,{noDepth:true});});
    for(let i=0;i<10;i++){const x=9.4+i*0.14,y=0.82-Math.sin(i/9*PI)*0.18;rb.sph([x,y,1.2],[0.045,0.045,0.045],X.velvet,{noDepth:true});}
    rb.block(9.3,1.05,10.8,1.35);
    // booths on the right side
    rb.box([7.6,0,5.9],[10.6,0.45,6.9],X.velvet,{block:true});rb.box([7.6,0.45,6.6],[10.6,1.2,6.9],X.velvet);rb.box([8.4,0,5.1],[9.8,0.72,5.6],X.mahog,{block:true});
    P.candle(rb,8.8,0.72,5.35);P.candle(rb,9.4,0.72,5.35);
    // street door + exit sign on the back wall, left
    P.door(rb,0.8,1.8,0,2.4,m.black);rb.wallZ(1.3,2.65,0.6,0.22,X.sExit);
    rb.floor(1.3,0.6,1.2,0.8,M([.1,.08,.1],{decal:true,mottle:.3,spec:0}));
  },
  spawn:{x:1.3,z:1.0,ry:0.6},
  exits:[{id:'clubOut',label:'Reliquary Row (street)',at:[1.3,1.5,0.1],box:[0.8,0,0,1.8,2.4,0.2],stand:[1.3,0.9],face:[1.3,0],map:true},
    {id:'toVip',label:'VIP stairs',at:[10.05,1.7,0.2],box:[9.5,0,0,10.6,2.6,0.3],stand:[10.05,0.75],face:[10.05,0],to:'vip',spawn:{x:6.0,z:5.2,ry:-2.4}}],
  inter:[{id:'bar',label:'The bar',at:[1.3,1.4,5.6],box:[0.9,0,4.6,1.7,1.2,6.8],stand:[2.3,5.6],face:[1.3,5.6]},
    {id:'stage',label:'The DJ booth',at:[5.5,1.8,0.6],box:[3.3,0,0,7.7,1.5,1.5],stand:[5.5,2.2],face:[5.5,0.5]},
    {id:'organ',label:'Organ pipes',at:[0.3,2.6,2.6],box:[0,1.3,0.9,0.6,4.0,4.3],stand:[1.2,2.6],face:[0,2.6]},
    {id:'window',label:'Stained glass',at:[5.5,3.0,0.05],box:[4.8,1.6,0,6.2,4.2,0.1],stand:[5.5,2.0],face:[5.5,0],if:S=>S.clan==='choir'}],
  particles:[{type:'motes',n:70,area:[1,10,1,6.5],y:[0.5,4],col:[1,.5,.9]}]
};
ROOMS.reliquary.exits[0].to=null;

/* ---------- The VIP Crypt ---------- */
ROOMS.vip={id:'vip',name:'The VIP Crypt',sub:'Beneath Club Reliquary · Elysium',W:7,D:6,H:3.2,ambience:'crypt',elysium:true,art:true,
  sky:[.2,.1,.12],ground:[.06,.03,.04],
  grade:{sh:[.9,.6,.75],hi:[1.12,.95,.82],ink:[.05,.02,.03],sat:.95,wash1:[.03,.01,.015],wash2:[.1,.04,.05]},
  shadow:{pos:[3.6,3.0,3.6],target:[3.2,0,2.4],fov:2.0,far:10,idx:0},
  lights(S){return [{pos:[3.6,2.6,2.3],color:[1,.62,.32],intensity:1.6,range:7},{pos:[1.2,1.4,1.2],color:[1,.55,.25],intensity:.9,range:3.5},{pos:[5.6,1.6,1.1],color:[1,.55,.25],intensity:.9,range:3.5},{pos:[3.5,1,5.5],color:[.6,.2,.5],intensity:.8,range:4}];},
  flicker(t){return 0.92+0.08*Math.sin(t*6.3)*Math.sin(t*2.1+1);},
  build(rb,S){const m=mats(),X=xm();
    rb.shell(7,6,3.2,X.stone,X.stone,X.stone,m.cap);
    rb.floor(3.5,2.6,3.6,2.6,M([1,1,1],{tex:'velvet',decal:true,mottle:.2,spec:.2}));
    // the great booth
    rb.box([1.6,0,0.2],[5.6,0.5,1.2],X.velvet,{block:true});rb.box([1.6,0.5,0.2],[5.6,1.5,0.45],X.velvet);rb.box([1.4,0,0.2],[1.7,1.1,1.6],X.velvet,{block:true});rb.box([5.5,0,0.2],[5.8,1.1,1.6],X.velvet,{block:true});
    rb.box([2.5,0,1.6],[4.6,0.7,2.4],X.mahog,{block:true});rb.box([2.45,0.7,1.55],[4.65,0.74,2.45],m.gold);
    P.candle(rb,2.9,0.74,2.0);P.candle(rb,3.6,0.74,1.8);P.candle(rb,4.2,0.74,2.1);rb.cyl([3.3,0.74,2.15],0.04,0.03,0.18,M([.5,.05,.1],{alpha:.7,spec:2,mottle:0}),{noDepth:true});
    // niches with candles, guest coffins on the left wall
    for(let i=0;i<3;i++){const z=1.2+i*1.5;rb.box([0,0,z],[0.6,0.55,z+1.1],X.coffin,{block:true});rb.box([0,0.55,z+0.05],[0.58,0.62,z+1.05],X.brass,{noDepth:true});}
    for(let i=0;i<4;i++){const x=0.9+i*1.5;rb.box([x,1.6,0],[x+0.5,2.3,0.12],M([.02,.01,.01]),{noDepth:true});P.candle(rb,x+0.25,1.62,0.06);}
    // portrait frames
    rb.box([2.2,1.8,0],[3.2,2.8,0.06],m.gold);rb.box([2.28,1.88,0.06],[3.12,2.72,0.08],M([.15,.05,.08]),{noDepth:true});
    rb.box([3.9,1.8,0],[4.9,2.8,0.06],m.gold);rb.box([3.98,1.88,0.06],[4.82,2.72,0.08],M([.1,.08,.15]),{noDepth:true});
    // stairs up, front right
    for(let i=0;i<4;i++)rb.box([6.2-i*0.0,i*0.18,5.0+i*0.25],[7,i*0.18+0.18,6],X.stone,{block:i===0});
    rb.box([6.9,0,0],[7.0,3.2,0.6],X.stone);
  },
  spawn:{x:6.0,z:5.2,ry:-2.4},
  exits:[{id:'vipUp',label:'Back up to the club',at:[6.6,0.9,5.6],box:[6.2,0,5.0,7,0.8,6],stand:[5.8,5.3],face:[6.6,5.6],to:'reliquary',spawn:{x:10.05,z:1.6,ry:-2.6}}],
  inter:[{id:'coffins',label:'Guest coffins',at:[0.3,0.8,2.8],box:[0,0,1.2,0.6,0.62,5.7],stand:[1.2,2.8],face:[0,2.8]},
    {id:'portraits',label:'Portraits',at:[3.55,2.3,0.08],box:[2.2,1.8,0,4.9,2.8,0.1],stand:[3.55,3.0],face:[3.55,0]},
    {id:'vipmirror',label:'Mirror',at:[5.95,1.6,0.06],box:[5.75,1.2,0,6.15,2.0,0.1],stand:[5.95,2.6],face:[5.95,0]}],
  particles:[{type:'motes',n:40,area:[0.5,6.5,0.5,5.5],y:[0.3,2.8],col:[1,.7,.45]}]
};
const vipB=ROOMS.vip.build;ROOMS.vip.build=function(rb,S){vipB.call(this,rb,S);const m=mats();rb.box([5.7,1.15,0],[6.2,2.05,0.05],m.gold);rb.decal([5.95,1.6,0.06],[0.42,0,0],[0,0.8,0],[0,0,1],m.dMirror);};

/* ---------- The Pawn & Coffin ---------- */
ROOMS.pawn={id:'pawn',name:'The Pawn & Coffin',sub:'Block B · Reliquary Row',W:8,D:6,H:3,ambience:'pawn',map:true,
  sky:[.2,.16,.12],ground:[.06,.05,.04],
  grade:{sh:[.85,.72,.6],hi:[1.1,.98,.82],ink:[.04,.03,.02],sat:.85,wash1:[.025,.02,.012],wash2:[.09,.07,.05]},
  shadow:{pos:[3.5,2.8,3.4],target:[3.5,0,2.4],fov:2.1,far:10,idx:0},
  lights(S){return [{pos:[3.5,2.6,2.6],color:[1,.78,.45],intensity:2.2,range:9.5},{pos:[6.6,1.6,1.2],color:[1,.6,.3],intensity:.9,range:3.5},{pos:[1.4,1.8,4.4],color:[.6,.8,1],intensity:.9,range:4},{pos:[6.0,2.4,4.6],color:[1,.7,.4],intensity:1.0,range:5}];},
  flicker(t){return 1;},
  build(rb,S){const m=mats(),X=xm();
    rb.shell(8,6,3,m.wood,m.plaster,m.plaster,m.cap,{lowerH:1.0,lowerL:X.mahog,lowerR:X.mahog});
    // glass counter
    rb.box([0.8,0,1.6],[4.6,0.95,2.2],X.mahog,{block:true});rb.box([0.8,0.95,1.6],[4.6,1.0,2.2],M([.7,.85,.9],{alpha:.3,spec:1.6,mottle:0}),{noDepth:true});
    for(let i=0;i<6;i++){rb.box([1.0+i*0.6,0.62,1.75],[1.3+i*0.6,0.66,2.05],i%2?m.gold:m.chrome,{noDepth:true});}
    rb.box([3.6,1.0,1.7],[4.1,1.3,2.05],m.black);
    // walls: guitars, clocks, televisions
    for(let i=0;i<4;i++){const x=0.8+i*0.8;rb.part(Geo.box(0.32,0.9,0.06),M4.trs([x,2.0,0.08],[0,0,0.05*(i%2?1:-1)]),i%2?X.mahog:M([.6,.15,.1],{spec:1}),{noDepth:true});}
    rb.wallZ(4.3,2.3,0.5,0.5,X.clock);rb.wallZ(4.9,2.0,0.4,0.4,X.clock);rb.wallX(1.2,2.2,0.45,0.45,X.clock);
    for(let k=0;k<3;k++){rb.box([0,0.2+k*0.55,3.2],[0.55,0.7+k*0.55,4.2],m.black,{block:k===0});rb.box([0.55,0.28+k*0.55,3.3],[0.57,0.62+k*0.55,4.1],M([.2,.3,.35],{emis:[.08,.12,.14],spec:1.2}),{noDepth:true});}
    rb.box([0,1.9,1.2],[0.4,1.95,5.6],m.woodDark,{noDepth:true});
    // coffin-boxes at the back right
    for(let i=0;i<3;i++){rb.box([5.2,i*0.55,0.1],[7.8,i*0.55+0.5,1.0],X.coffin,{block:i===0});rb.box([5.25,i*0.55+0.5,0.15],[7.75,i*0.55+0.53,0.95],X.brass,{noDepth:true});}
    rb.box([7.0,0,1.6],[7.8,2.2,2.4],X.coffin,{block:true});
    // the river safe
    rb.box([5.6,0,3.4],[6.4,0.8,4.1],M([.18,.22,.2],{spec:.8,mottle:.6}),{block:true});rb.cyl([6.0,0.45,4.1],0.12,0.12,0.04,m.chrome,{rot:[PI/2,0,0]});
    // shop door + sign
    P.door(rb,2.6,3.6,0,2.3,M([.5,.6,.65],{alpha:.45,spec:1.8,mottle:0}));rb.wallZ(3.1,2.6,1.3,0.33,X.sPawn);
    P.tube(rb,1.5,4.5,2.9,3.0);
  },
  spawn:{x:3.1,z:0.95,ry:0.2},
  exits:[{id:'pawnOut',label:'Reliquary Row (street)',at:[3.1,1.5,0.1],box:[2.6,0,0,3.6,2.3,0.2],stand:[3.1,0.85],face:[3.1,0],map:true}],
  inter:[{id:'counter',label:'The counter',at:[2.7,1.2,1.9],box:[0.8,0,1.6,4.6,1.1,2.2],stand:[2.7,2.9],face:[2.7,1.9]},
    {id:'coffinbox',label:'Coffin-boxes',at:[6.5,1.7,0.6],box:[5.2,0,0.1,7.8,1.6,1.0],stand:[6.5,1.7],face:[6.5,0.5]},
    {id:'safe',label:'The river safe',at:[6.0,1.0,3.75],box:[5.6,0,3.4,6.4,0.8,4.1],stand:[6.0,4.8],face:[6.0,3.8]},
    {id:'window',label:'The window display',at:[4.6,1.4,1.9],box:[4.1,0.6,1.6,4.6,1.2,2.2],stand:[4.6,2.9],face:[4.6,1.9]}],
  particles:[{type:'motes',n:35,area:[0.5,7.5,0.5,5.5],y:[0.3,2.6],col:[1,.85,.6]}]
};

/* ---------- St. Jude's Night Clinic ---------- */
ROOMS.stjude={id:'stjude',name:'St. Jude\'s Night Clinic',sub:'Block C · Triage',W:10,D:6,H:3,ambience:'clinic',bright:true,map:true,
  sky:[.24,.28,.28],ground:[.08,.09,.09],
  grade:{sh:[.75,.92,.9],hi:[1.04,1.04,.98],ink:[.03,.05,.06],sat:.82,wash1:[.02,.03,.03],wash2:[.06,.09,.09]},
  shadow:{pos:[5,2.9,3],target:[5,0,2.6],fov:2.3,far:12,idx:0},
  lights(S){return [{pos:[5,2.9,3],color:[.9,1,1],intensity:1.6,range:11},{pos:[2,2.9,2],color:[.9,1,1],intensity:1.0,range:6},{pos:[8.4,1.6,0.8],color:[.6,.8,1],intensity:.8,range:3.5},{pos:[1.6,1.5,0.6],color:[1,.6,.4],intensity:.6,range:3}];},
  flicker(t){return 1-0.06*(Math.sin(t*27)>0.95?1:0);},
  build(rb,S){const m=mats(),X=xm();
    rb.shell(10,6,3,X.lino,X.clinic,X.clinic,m.cap);
    // entrance (sliding doors) on back wall, left
    P.door(rb,0.9,2.3,0,2.3,M([.55,.7,.75],{alpha:.4,spec:1.8,mottle:0}));rb.box([0.92,0,0.02],[2.28,2.25,0.04],M([1,.7,.4],{emis:[.4,.25,.1],mottle:0}),{noDepth:true});rb.wallZ(1.6,2.65,1.4,0.32,X.sJude);
    // reception desk
    rb.box([3.0,0,1.2],[5.6,1.05,1.9],X.pale,{block:true});rb.box([2.95,1.05,1.15],[5.65,1.1,1.95],m.steelBright);rb.box([4.4,1.1,1.3],[4.9,1.45,1.5],m.black);rb.box([4.45,1.13,1.5],[4.85,1.42,1.52],M([.3,.45,.6],{emis:[.12,.2,.3]}),{noDepth:true});
    rb.box([3.3,1.1,1.4],[3.8,1.14,1.75],M([.9,.88,.8]),{noDepth:true});
    // waiting chairs
    for(let r=0;r<2;r++)for(let i=0;i<4;i++)P.chair(rb,1.0+i*0.6,3.6+r*1.2,PI,X.blue);
    // curtained cubicles on the right
    for(let i=0;i<2;i++){const x=6.4+i*1.6;rb.box([x,2.6,0.1],[x+0.03,2.65,2.2],m.steelDark,{noDepth:true});rb.box([x,0.3,1.9],[x+1.5,2.4,1.96],X.curtain,{noDepth:true});rb.box([x+0.2,0,0.4],[x+1.3,0.65,1.5],X.pale,{block:true});rb.box([x+0.25,0.65,0.45],[x+1.25,0.75,1.45],m.white);}
    // blood fridge + elevator + restroom on left wall
    rb.box([0,0,2.4],[0.6,1.9,3.1],m.white,{block:true});rb.box([0.6,0.2,2.5],[0.62,1.7,3.0],M([.7,.2,.25],{emis:[.25,.05,.06],spec:1.2}),{noDepth:true});
    rb.box([0,0,4.2],[0.08,2.4,5.4],m.steelBright);rb.box([0.08,0,4.3],[0.1,2.3,4.78],m.steel,{noDepth:true});rb.box([0.08,0,4.82],[0.1,2.3,5.3],m.steel,{noDepth:true});rb.box([0.05,1.2,5.5],[0.12,1.35,5.6],X.cyan,{noDepth:true});
    P.doorX(rb,1.0,1.8,0,2.1,m.white);
    rb.wallZ(6.0,1.6,0.4,0.52,X.poster2);rb.wallZ(5.0,2.4,0.5,0.4,X.clock);
    P.tube(rb,2,8,2.9,2.0);P.tube(rb,2,8,2.9,4.0);
  },
  spawn:{x:1.6,z:0.9,ry:0.4},
  exits:[{id:'judeOut',label:'The street',at:[1.6,1.4,0.1],box:[0.9,0,0,2.3,2.3,0.2],stand:[1.6,0.85],face:[1.6,0],map:true}],
  inter:[{id:'entrylog',label:'Entry log',at:[3.55,1.3,1.55],box:[3.2,1.05,1.3,3.9,1.2,1.8],stand:[3.55,2.6],face:[3.55,1.5]},
    {id:'bagfridge',label:'Blood fridge',at:[0.4,1.4,2.75],box:[0,0,2.4,0.65,1.9,3.1],stand:[1.3,2.75],face:[0,2.75]},
    {id:'elevator',label:'Staff elevator',at:[0.1,1.4,4.8],box:[0,0,4.2,0.15,2.4,5.4],stand:[0.95,4.8],face:[0,4.8]},
    {id:'judemirror',label:'Restroom',at:[0.1,1.3,1.4],box:[0,0,1.0,0.15,2.1,1.8],stand:[0.95,1.4],face:[0,1.4]},
    {id:'cubicle',label:'Cubicle 2',at:[8.75,1.0,1.0],box:[8.0,0,0.2,9.5,1.2,1.9],stand:[8.75,2.6],face:[8.75,1.2]}],
  particles:[{type:'motes',n:20,area:[0.5,9.5,0.5,5.5],y:[0.4,2.6],col:[.9,1,1]}]
};

// exits with map:true open the travel map instead of a room
NL.ROOMS.__mapExit=true;
})();
