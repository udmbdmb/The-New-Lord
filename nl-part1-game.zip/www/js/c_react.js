'use strict';
/* THE NEW LORD — reputation reactions: everybody on the Marrow Ward has started to form an opinion of what you are, and some of them will say it to your face */
NL.Script.add(String.raw`
// =====================================================================
// LEO · mercy, candour
// =====================================================================
# rL.merc arc=leo night=3,4,5 label="\"You're looking at me funny, Leo.\"" if=alive:leo&rep:mercy>=3&!flag:leoThrall prio=-1
@focus leo
leo: Am I? Sorry. It's just... people talk. On the street. Tariq said you sat with a bloke who'd been glassed outside the Lucky Mart till the ambulance came. Margo said you gave someone your coat.
leo: I keep waiting for you to turn into the thing from the films. And you keep not doing it. It's really annoying. I had a whole bit about it.
* "What was the bit?"  -> rL.mercbit
* "I'm not as good as they're saying."  -> rL.mercnot {do lean:candour+1}
* "Don't get used to it."  -> rL.mercwarn

# rL.mercbit
leo: "My mate's a vampire. Very polite. Last week he helped an old lady across the road. Then he drank her." And the twist was you didn't drink her. And then there's no punchline. The bit just stops being funny and starts being sweet. Which is death, in comedy.
leo: Maybe that's the act now. "My mate the vampire, who is nicer than me." Ten minutes. Bomb every Tuesday.
{do rel:leo+1; comp+1}
@end

# rL.mercnot
leo: Nobody is. That's the thing. Nobody's as good as they're saying. Doesn't mean you have to stop.
{do rel:leo+1}
@end

# rL.mercwarn
> His face drops a bit.
leo: Right. Okay. Noted. I'll get used to it slowly, then, in secret, and not tell you.
@end

# rL.ruth arc=leo night=3,4,5 label="\"Leo. Say it.\"" if=alive:leo&rep:mercy<=-3&!flag:leoThrall prio=-1
@focus leo
> He doesn't come to the door when you knock. When he does, he keeps the chain on.
leo: People are talking. About you. About the... about what's in the gutters. Kenny downstairs said they found someone by the canal with their throat open. Said the police aren't even calling it in.
leo: Was that you?
* "Yes."  -> rL.ruthyes {do lean:candour+1}
* "No."  -> rL.ruthno {do lean:candour-1}
* "Does it matter?"  -> rL.ruthmatter

# rL.ruthyes
> The chain stays on.
leo: ...Okay. Okay. Thanks for not lying. I don't know what to do with it. I'm going to sit in here with it for a bit.
leo: Don't go. Just... stay on that side of the door for a minute. I want to know you're still the same person who's on that side of the door.
{do rel:leo-1; flag:leoChain=1}
@end

# rL.ruthno
> He looks at you through the gap for a long time.
leo: Okay. I believe you. I'm choosing to believe you. That's a different thing, you know. I'm being very clear with myself that it's a different thing.
> He takes the chain off.
{do rel:leo-1}
@end

# rL.ruthmatter
leo: Does it MATTER. Does it... Christ. Yeah. It matters to me. It matters to his mom. It mattered to him.
> The door shuts. A long time later, through it:
leo: I'll see you tomorrow. Probably. I'm not making any promises tonight.
{do rel:leo-2; lean:mercy-1}
@end

# rL.liar arc=leo night=3,4,5 label="\"What did I do, Leo?\"" if=alive:leo&rep:candour<=-3&!flag:leoThrall prio=-1
@focus leo
leo: Nothing. Nothing! You didn't... nothing.
leo: It's just I realized today I don't know a single true thing about you. I thought I did. You told me loads of stuff. And then I tried to tell Mom about you on the phone and I couldn't think of one thing that I was sure wasn't made up.
* Tell him one true thing.  -> rL.liartrue {do lean:candour+1}
* "You know I'd never hurt you."  -> rL.liarhurt

# rL.liartrue
> You tell him something true. It doesn't matter what. It's small. It's yours. He listens like it's a set at the Apollo.
leo: ...Okay. That's one. That's a start. Tell me another one tomorrow.
{do rel:leo+2}
@end

# rL.liarhurt
leo: See, that's exactly the kind of thing a liar would say. Not that you're... I'm not saying... ugh. Forget it. Forget it. Do you want a tea? You can't have a tea. I'm making one anyway.
@end

// =====================================================================
// MILLER · candour, mercy
// =====================================================================
# rM.true arc=miller night=3,4,5 label="\"You've stopped trying to arrest me, Detective.\"" if=alive:miller&rep:candour>=3 prio=-1
@focus miller
miller: I haven't stopped. I've postponed. There's a difference. One of them involves paperwork.
miller: You've not lied to me once since Monday. You know how rare that is? I've had nuns lie to me. I've had my own mother lie to me about where she parked.
miller: Everything you've told me has checked out. Every awful, impossible, insane thing. I don't know what that makes you. It's starting to make you the most reliable witness I've got.
* "And that worries you."  -> rM.truew
* "Then trust me on Friday."  -> rM.truef
* "I've lied to you once. Small thing."  -> rM.trueconf {do lean:candour+1}

# rM.truew
miller: Worries me. It terrifies me. If the most honest person on Halloran Street is a corpse, what does that say about Halloran Street?
{do rel:miller+1}
@end

# rM.truef
miller: Friday. I don't know what Friday is. Nobody will tell me. But okay. Okay. One time. You get one time.
{do rel:miller+1; flag:millerTrustFri=1}
@end

# rM.trueconf
> She stops. She actually laughs, a short surprised bark.
miller: Of course you have. What was it?
> You tell her. It's small. It's about the root beer, or the time, or where you were on Tuesday.
miller: ...That's the most honest thing anyone's ever said to me. Confessing to a lie I didn't know about. You're unbelievable. Literally. I can't put you in a report.
{do rel:miller+2}
@end

# rM.lie arc=miller night=3,4,5 label="\"Something wrong, Detective?\"" if=alive:miller&rep:candour<=-3 prio=-1
@focus miller
> She has her notebook open. She's been writing in it before you arrived. She turns it round so you can see.
> Two columns. *SAID* and *TRUE*. The *TRUE* column is mostly question marks.
miller: I've been keeping score. Old habit. You're on eleven to two.
miller: I'm not angry. I'm just letting you know that I know. Every time you open your mouth I'm going to be writing.
* "Then I'll give you a true one now."  -> rM.lietrue {do lean:candour+1}
* "Write whatever you like."  -> rM.liewhat
? stagecraft 12 "Those aren't lies. They're protections. For you."  -> rM.lieprot | rM.lieprotno {id rM_prot}

# rM.lietrue
> You give her one. Something real, about the freezer, about Harrow, about the way the light came through.
> She writes it down in the *TRUE* column without asking whether it is.
miller: Twelve to three.
{do rel:miller+1}
@end

# rM.liewhat
miller: I will. I always do. That's the job.
{do rel:miller-1}
@end

# rM.lieprot
> She looks at the notebook. She looks at you. She closes the notebook.
miller: ...You know, that's exactly what Ray used to say. "I'm not lying, Ines, I'm protecting you." Right up until he went in the river.
miller: Fine. Protections. I'll start a third column.
{do rel:miller+1}
@end

# rM.lieprotno
miller: Protections. Right. Twelve to two.
@end

# rM.kill arc=miller night=3,4,5 label="\"Ines. You're shaking.\"" if=alive:miller&kills>=2 prio=-1
@focus miller
miller: There are two open murders on my desk since Monday. Both throats. Both drained. My sergeant's calling it a "dog attack" because the alternative is losing his pension.
miller: I'm not stupid. I know what I'm standing next to. I just need you to tell me why I shouldn't put two in your chest right now and see if it works.
* "Because it won't."  -> rM.killwont
* "Because I'm trying to stop the man who's going to do worse."  -> rM.killharrow {if flag:knowLantern|flag:knowHarrow}
* "You should. Go on."  -> rM.killgo
* Tell her you're sorry. Mean it.  -> rM.killsorry {do lean:mercy+1}

# rM.killwont
miller: No. Probably not. You'd just be annoyed and I'd be dead. That's a bad trade, as trades go.
> She doesn't take her hand off her holster.
{do rel:miller-1}
@end

# rM.killharrow
miller: Worse. There's worse.
miller: ...God help me, I believe you. There's always worse. That's the first thing they teach you.
{do rel:miller+0}
@end

# rM.killgo
> She draws. She points it at your chest. Her hand doesn't shake.
> Then it does. She holsters it.
miller: No. No, you'd like that. You'd like someone to do it for you. I'm not doing you that favour.
{do rel:miller-1; comp-1}
@end

# rM.killsorry
> She looks at you for a long time. She has looked at a lot of people saying sorry.
miller: Sorry doesn't bring them back.
miller: ...But it's more than anyone else on this street has said. Don't do it again. That's not a request. That's a warning from the only person in the city who's still trying to treat you like a person.
{do rel:miller+1}
@end

// =====================================================================
// TARIQ · mercy, loyalty
// =====================================================================
# rT.loyal arc=tariq night=3,4,5 label="\"You saved me a coffee again, Tariq.\"" if=alive:tariq&rep:loyalty>=3 prio=-1
@focus tariq
tariq: I always save you a coffee. You never drink it. It's a ritual now. My wife says I'm making offerings to a ghost.
tariq: People say you keep your word. Gideon says it. The Russian doctor says it, in a way that sounds like she's angry about it. That woman on the platform with the handbag.
tariq: My father kept his word. He kept it until it killed him. In 1982 he promised a man in Lahore he would pay back a loan, and he did, every rupee, and it took nineteen years and there was nothing left for medicine.
* "Was it worth it?"  -> rT.loyalworth
* "I'm not sure I'm that strong."  -> rT.loyalweak

# rT.loyalworth
tariq: My mother says no. My father, on his deathbed, said yes. I think they were both right. That's the trouble with keeping your word. You never get to know.
{do rel:tariq+1}
@end

# rT.loyalweak
tariq: Nobody is. That's why it counts.
> He pushes the coffee across the counter. You don't drink it. He doesn't expect you to.
{do rel:tariq+1; comp+1}
@end

# rT.faith arc=tariq night=3,4,5 label="\"Tariq?\"" if=alive:tariq&rep:loyalty<=-3 prio=-1
@focus tariq
> No coffee on the counter tonight. He's looking at the till.
tariq: I heard you made a promise and broke it. Maybe more than one. People talk in here. They buy cigarettes and they talk.
tariq: I'm not your father. I'm not your priest. I sell scratch cards. But I want you to know that I noticed. Because nobody else will say it to you, because they're scared.
* "You should be scared too."  -> rT.faithscare
* "You're right. I'll do better."  -> rT.faithbetter
* "Things changed. I couldn't keep it."  -> rT.faithchange

# rT.faithscare
tariq: I am scared. I've been scared since Monday. Doesn't mean I stop telling the truth in my own shop.
{do rel:tariq-1}
@end

# rT.faithbetter
> He looks at you. Then he reaches under the counter and puts a cup down and pours the coffee.
tariq: Do better, then. I'll be watching. I'll be here at five with a coffee either way.
{do rel:tariq+1}
@end

# rT.faithchange
tariq: Things always change. That's what a promise is for. To be the thing that doesn't.
@end

// =====================================================================
// TINY · loyalty, street
// =====================================================================
# rY.street arc=tiny night=3,4,5 label="\"Tiny. You let me straight in.\"" if=!flag:tinyBetrayed&!flag:tinyGone&rep:pride<=-2 prio=-1
@focus tiny
tiny: Course I did. You're one of us now. Not one of them upstairs. One of us.
tiny: You know how I know? You talk to me. Nine years on this door. You know how many of the Court have asked me my name? Two. One of them was to tell me to change it.
tiny: You've been out on the street with Valko and the rats and the bus driver. You've been in the Lucky Mart at four in the morning. You've got sick on your shoes. You're Street. Don't let the old ones tell you different.
* "I'll take that."  -> rY.streetok {do rel:tiny+1}
* "I'm going to be Sheriff, Tiny. I can't be Street."  -> rY.streetsher

# rY.streetok
tiny: You'd better. It's the only compliment I've got.
@end

# rY.streetsher
tiny: Why not? Who says? The Sheriff's the one who's meant to look after the Ward. The Ward's down here. It's not up in the Heights.
tiny: Be a Street Sheriff. Nobody's ever done it. Do it first.
{do rel:tiny+1; flag:tinyStreetSheriff=1}
@end

# rY.court arc=tiny night=3,4,5 label="\"Evening, Tiny.\"" if=!flag:tinyBetrayed&!flag:tinyGone&rep:pride>=3 prio=-1
@focus tiny
> He opens the rope for you without looking at your face. He looks at your shoes. He's started looking at your shoes the way he looks at the Court's shoes.
tiny: Evening. Go on through. They're waiting for you downstairs.
* "Tiny. Look at me."  -> rY.courtlook
* Go through. You've got business.  -> rY.courtgo {do lean:pride+1}

# rY.courtlook
tiny: ...You're turning into one of them. You know that? The way you walk. The way you stand at the bar like you've paid for it.
tiny: It's fine. It's not my business. It's just I liked the other one better. The one who threw up on my shoes.
* "I'm still him."  -> rY.courtstill {do rel:tiny+1}
* "He wasn't going to survive Friday."  -> rY.courtsurvive

# rY.courtstill
tiny: Prove it. Come out for a smoke. You don't smoke. Come out and stand there while I smoke.
> You stand in the rain while he smokes. Neither of you says anything. It helps.
{do comp+1; tick:10}
@end

# rY.courtsurvive
tiny: No. Maybe not. Maybe the one who's going to survive is the one who walks like that.
tiny: Doesn't mean I have to like him.
{do rel:tiny-1}
@end

# rY.courtgo
> You go through. Behind you, very quietly, you hear him say something to the next person in line. It's the same thing he says to Séverine. *Evening, my lady.*
@end

// =====================================================================
// GIDEON · loyalty
// =====================================================================
# rG.loyal arc=gideon night=3,4,5 label="\"You've opened the ledger to a new page, Gideon.\"" if=alive:gideon&rep:loyalty>=3 prio=-1
@focus gideon
gideon: I have. Your page. I've kept a page for every Kindred who's slept in my boxes since 1974. Most of them are a column of debts.
gideon: Yours is a column of debts *paid*. Promises kept. I've never had to rule a line under your name in red ink.
> He turns it round. Your page. Neat copperplate. A short list. At the top, where the name goes, a blank space.
gideon: Absalom's page was like yours. Forty years. Never once in red. When I heard he was dead, I closed his book and I wept. I'm not ashamed of it.
* "Put my name at the top, when I find it."  -> rG.loyalname
* "Don't weep for me. I'm not worth it."  -> rG.loyalworth

# rG.loyalname
gideon: I'll leave the space. When you know it, come and tell me. I'll write it in my best hand.
{do rel:gideon+1; flag:gideonSpace=1}
@end

# rG.loyalworth
gideon: Let me decide what's worth weeping for. It's one of the few pleasures left to a man my age.
{do rel:gideon+1}
@end

# rG.red arc=gideon night=3,4,5 label="\"Gideon. Is that red ink?\"" if=alive:gideon&rep:loyalty<=-3 prio=-1
@focus gideon
> He doesn't hide it. Your page in the ledger. A neat red line under your column, the first one.
gideon: It is. I don't use it lightly. I've used it for nine Kindred in fifty years. Three of them are ash. Six of them left the city.
gideon: I'm not threatening you. I'm too old to threaten anyone. I'm just recording. The Ward will read this book when I'm gone. It's the only history most of us will ever have.
* "Can I earn the line back?"  -> rG.redback
* "Burn the book, old man."  -> rG.redburn {do lean:pride+1}

# rG.redback
gideon: No. Ink doesn't come out. But you can write underneath it. Something better. Most people never bother.
{do rel:gideon+1}
@end

# rG.redburn
> He closes the ledger. He puts both hands on it.
gideon: Absalom said the same thing once. In 1971. He came back the next night and apologized. He brought me a Hermès scarf for my wife. She wore it until she died.
gideon: I'll wait and see if you come back.
{do rel:gideon-1}
@end

// =====================================================================
// PEMBERTON · loyalty, station
// =====================================================================
# rP.court arc=pemberton night=3,4,5 label="\"You approve, Pemberton.\"" if=alive:pemberton&rep:pride>=3&!flag:pembertonGone prio=-1
@focus pemberton
pemberton: I would never presume to approve or disapprove. I am a servant.
pemberton: ...But I will say that you have begun to stand correctly. The weight on the back foot. The chin at an angle that suggests one has never once been surprised. The Sheriff took forty years to learn it. You've managed it in a week.
pemberton: The Court notices these things. They are frightened of you in a way they weren't on Monday.
* "Good."  -> rP.courtgood {do lean:pride+1}
* "I don't want them frightened. I want them to listen."  -> rP.courtlisten
* "Show me what else he did. How he stood."  -> rP.courtteach

# rP.courtgood
pemberton: Quite. One should be careful, though. Fear is a currency that devalues rapidly if overprinted.
@end

# rP.courtlisten
pemberton: The two are not so very different, at Court. But I take your point, and I respect it. The Sheriff used to say the same thing. He was rarely listened to. He was always feared.
{do rel:pemberton+1}
@end

# rP.courtteach
> For twenty minutes, in a back room that smells of starch, Pemberton teaches you how a Sheriff enters a room. How he holds a glass he isn't going to drink. How he says "I see" in a way that means "you are about to regret this".
> You're good at it. Too good. It's like remembering.
tenant: He's teaching you me. He doesn't realize. He's teaching you me, and I'm in you already, and I'm laughing.
{do rel:pemberton+1; sync+2; tick:20}
@end

# rP.street arc=pemberton night=3,4,5 label="\"Something on your mind, Pemberton?\"" if=alive:pemberton&rep:pride<=-3&!flag:pembertonGone prio=-1
@focus pemberton
pemberton: I would never... very well. Since you ask.
pemberton: You were seen in the Lucky Mart at four in the morning, sitting on the floor by the freezers, eating potato chips you cannot digest with a mortal shopkeeper. You were seen on the bus. You were seen *running*.
pemberton: The Court is not frightened of you. The Court is laughing at you. And if they're laughing at you on Friday, they will burn you, because it costs them nothing to burn a joke.
* "Let them laugh."  -> rP.streetlaugh
* "What should I do?"  -> rP.streetask
* "The Court can burn."  -> rP.streetburn {do lean:pride-1}

# rP.streetlaugh
pemberton: As you wish. I'll lay out the black suit for Friday regardless. One should at least be cremated in good tailoring.
@end

# rP.streetask
pemberton: Stop running. Sheriffs do not run. If you must be somewhere quickly, arrive slowly, and be already there.
pemberton: And for pity's sake, stop eating potato chips.
{do rel:pemberton+1}
@end

# rP.streetburn
> His face does nothing at all. His hands, folded behind his back, tighten.
pemberton: The Sheriff said that once. In 1968. It took him nine years to get back in their good graces. You do not have nine years. You have three nights.
{do rel:pemberton-1}
@end

// =====================================================================
// SÉVERINE · station (and a taste for ruthlessness)
// =====================================================================
# rS.cruel arc=severine night=3,4,5 label="\"You've changed your tone, my lady.\"" if=alive:sev&rep:mercy<=-3&!flag:sevEnemy prio=-1
@focus severine
severine: Have I. Yes. I suppose I have.
severine: I heard about the canal. And the other one. You didn't hide them, you didn't apologize for them, you didn't come crawling to me for cover. You simply... did as you liked.
severine: Do you know how many neonates in my long life have shown that much spine? Four. Three of them are my best friends. The fourth I had to kill.
* "Which one am I going to be?"  -> rS.cruelwhich
* "I'm not proud of it."  -> rS.cruelnot {do lean:mercy+1}

# rS.cruelwhich
severine: That depends entirely on Friday. Sit with me. Have a glass of something. Let's see.
{do rel:severine+1}
@end

# rS.cruelnot
> The interest goes out of her face like a lamp turned down.
severine: Ah. A conscience. How disappointing. I thought for a moment you might be interesting.
{do rel:severine-1}
@end

# rS.soft arc=severine night=3,4,5 label="\"My lady.\"" if=alive:sev&rep:mercy>=4&!flag:sevEnemy prio=-1
@focus severine
severine: The saint of Halloran Street. I hear you've been giving your coat to beggars and your blood to the dying. Next you'll be washing feet.
severine: It's very touching. It's also how they'll kill you. Mercy is a door left open. Everyone in this room can see it from across the platform.
* "Then let them come in."  -> rS.softcome
* "Maybe I'm not as soft as I look."  -> rS.softnot
? velvet 12 "You were merciful once. What happened?"  -> rS.softonce | rS.softonceno {id rS_once}

# rS.softcome
severine: Oh, they will. They'll come in with stakes and smiles.
@end

# rS.softnot
severine: Perhaps. I'd like to see it. Show me on Friday.
@end

# rS.softonce
> For a moment she doesn't answer. She looks at the Capuchin bones on the wall, at Brother Anselm with his cracked jaw.
severine: Lyon. 1793. I hid a priest in my cellar from the Terror. Three weeks. I fed him, I read to him, I fell a little in love with him.
severine: They found him because he went to the window to watch the sunrise. He said he missed it. He said it was worth the risk. They took his head off in the square at dusk the next day, and I watched from a carriage with the blinds an inch open, because I couldn't look away.
severine: That's what happened, darling. Mercy goes to the window.
{do rel:severine+1; mem:severine:lyon}
@end

# rS.softonceno
severine: Don't psychoanalyse me. I was old when Freud's grandmother was a twinkle.
@end

// =====================================================================
// MALAKOR · candour
// =====================================================================
# rK.true arc=malakor night=3,4,5 label="\"You're smiling, Malakor.\"" if=alive:malakor&rep:candour>=3 prio=-1
@focus malakor
malakor: Am I? How embarrassing. It's very bad for business.
malakor: You've told the truth all week. To me, to the detective, to the Court. Even when it cost you. Especially when it cost you.
malakor: In my trade, we call that a terrible negotiating strategy. In my private life, which nobody believes I have, I call it the rarest thing in this city. I'd like to buy some. It isn't for sale. That's why I want it.
* "What would you pay?"  -> rK.truepay
* "You could try it yourself."  -> rK.truetry

# rK.truepay
malakor: Everything. Nothing. A discount. Ten percent off, for life. That's the most generous offer I've made since 1912.
{do rel:malakor+1; flag:malakorDiscount=1}
@end

# rK.truetry
malakor: The truth. Me. Ha! I'd go bankrupt by Thursday.
> He thinks about it, though. You can see him think about it.
malakor: ...My real name is Mikołaj. I was a butcher's boy in Kraków. I wanted to be a violinist. There. That's three true things. I feel quite ill.
{do rel:malakor+2; mem:malakor:name}
@end

# rK.lie arc=malakor night=3,4,5 label="\"Malakor. You're quieter.\"" if=alive:malakor&rep:candour<=-3 prio=-1
@focus malakor
malakor: I'm listening. It's a very different noise from talking.
malakor: You lie. Everybody lies. I've no objection to lying. I do it beautifully. But you lie *badly*, to people who trust you, for no profit. That's not business. That's a habit.
malakor: And in my experience, people with that habit eventually lie to the wrong person. A Butcher, say. I'd rather not be standing next to you when it happens.
* "Are you threatening me?"  -> rK.liethreat
* "Teach me to lie well, then."  -> rK.lieteach

# rK.liethreat
malakor: Never. I'm advising. For free. Which should frighten you more than a threat.
{do rel:malakor-1}
@end

# rK.lieteach
malakor: Ha! Now that's a commission.
malakor: Rule one: never lie about anything you can't afford to lose. Rule two: always lie about something the other person wants to be true. Rule three: never, ever lie to yourself. That's the only one that's fatal.
{do rel:malakor+1; xp:15:Butcher's rules}
@end

// =====================================================================
// SOOT · faith (she distrusts honesty)
// =====================================================================
# rO.loyal arc=soot night=3,4,5 label="\"Mother. The rats are following me.\"" if=alive:soot&rep:loyalty>=3 prio=-1
@focus soot
soot: Following. Yes. They do that. They follow the ones who come back. Mm.
soot: You said you'd come back and you came back. You said you'd bring the thing and you brought it. The rats tell me. They tell me everything. They say you're a good one. A coming-back one.
soot: Here. Here. For a coming-back one.
> She presses something into your hand. A rat's tooth on a piece of red string.
soot: So they know you. In the pipes. If you're ever lost down there. Mm.
{do rel:soot+1; flag:sootTooth=1; comp+1}
@end

# rO.truth arc=soot night=3,4,5 label="\"Mother? You're hiding from me.\"" if=alive:soot&rep:candour>=4 prio=-1
@focus soot
> She's behind the biggest pile of jars, and she won't come out.
soot: You tell everybody everything. Mm. Mm. The rats don't like it. Too many words. Words go up the pipes and out into the street and the grey men hear them.
soot: Secrets keep you alive. Secrets are the only warm thing. You give yours away like bread. You'll be cold soon. Cold and known.
* "Then I'll keep yours. I promise."  -> rO.truthkeep {do promise:sootsecret:Keep Mother Soot's secrets}
* "Better known than hiding in a sewer, Mother."  -> rO.truthsewer

# rO.truthkeep
> One eye appears round the jars. Then the rest of her.
soot: ...Promise. Mm. A promise is a secret you tell the future. All right. All right. I'll come out.
{do rel:soot+1}
@end

# rO.truthsewer
soot: Sewer. SEWER. This is a SHRINE.
> The candles gutter. The rats, all at once, go quiet.
{do rel:soot-2}
@end

// =====================================================================
// ROSTOVA · mercy, candour
// =====================================================================
# rR.merc arc=rostova night=3,4,5 label="\"Doctor. You're not reaching for the stake today.\"" if=alive:rostova&rep:mercy>=3 prio=-1
@focus rostova
rostova: No. I took it out of my pocket on Wednesday. I'm a doctor. I should not be carrying stakes into Oncology.
rostova: The nurses say you sat with Mr. Feeney in bed nine. All night. You held his hand. He died at four. He said there was an angel with cold hands.
rostova: I've spent twenty years thinking things like you were a disease. Then a disease sits with my patients when I can't.
* "He was scared. Nobody else was there."  -> rR.mercsc
* "Don't make me into something I'm not."  -> rR.mercnot

# rR.mercsc
rostova: No. Nobody ever is. That is the scandal of my profession. We are very good at keeping people alive, and very bad at being with them when we can't.
{do rel:rostova+1}
@end

# rR.mercnot
rostova: I don't make things into anything. I observe. I observed you. You make yourself.
{do rel:rostova+1}
@end

# rR.cold arc=rostova night=3,4,5 label="\"Doctor?\"" if=alive:rostova&rep:mercy<=-3 prio=-1
@focus rostova
> She doesn't turn round from the X-ray light box. On it: a neck. A mortal neck, with two very clean punctures and a crushed hyoid.
rostova: This came in last night. Nineteen. Waitress. Bled out on the canal path.
rostova: I would like to say I don't know who did it. I would like to say I am not a hypocrite, standing in this hospital beside the person who probably did it, because I need him for Friday.
* "It was me."  -> rR.coldme {do lean:candour+1}
* "It wasn't me."  -> rR.coldnot
* Say nothing.  -> rR.coldsil

# rR.coldme
rostova: Yes. I know. I wanted to hear you say it. I wanted to see what your face did.
rostova: It didn't do enough.
{do rel:rostova-1}
@end

# rR.coldnot
rostova: Perhaps not. There are others. I'll choose to believe you. I am getting very good at choosing to believe things.
@end

# rR.coldsil
> She switches off the light box. The neck goes dark.
rostova: Friday. Then I never want to see you again.
{do rel:rostova-1}
@end

// =====================================================================
// OKAFOR · mercy, candour
// =====================================================================
# rO2.merc arc=okafor night=3,4,5 label="\"Mrs. Okafor. You've made tea.\"" if=rep:mercy>=3&!flag:okaforDead prio=-1
@focus okafor
okafor: Two cups. I know you can't. I like having two cups out. Dani always had two cups out, one for her and one in case somebody came.
okafor: The whole building talks about you now. The cats lady. Kenny. That lad from the bus. They say you're kind. They don't know what you are and they say you're kind.
okafor: I know what you are. I say it too.
* Sit with her and her two cups.  -> rO2.sit
* "Dani would have liked you to have company."  -> rO2.dani {if flag:met404}

# rO2.sit
> You sit in Dani's mother's kitchen with a cup of tea going cold in front of you. She talks about nothing: the price of gas, the woman in 601, the radio. You listen. That's all she wants.
{do rel:okafor+1; comp+2; tick:20}
@end

# rO2.dani
okafor: She'd have liked YOU. She liked anyone who wasn't boring. She'd have asked you a hundred questions and written the answers in a notebook.
{do rel:okafor+1; comp+1}
@end

// =====================================================================
// VALKO · faith, indulgence
// =====================================================================
# rV.loyal arc=valko night=3,4,5 label="\"You're wagging, Valko.\"" if=flag:valkoAlly&!flag:valkoDead&rep:loyalty>=3 prio=-1
@focus valko
valko: I am NOT wagging. Hounds don't wag. That's a myth.
valko: ...The pack talks. Dogs on the docks, cats on the roofs. They say you keep your word. They say you came back for the bus driver. They say you didn't sell out the old woman with the rats.
valko: Rask kept his word. Seventy years. And nobody ever came back for him. I want... I'd like to be the one who comes back. For you. If it comes to it.
* "It might come to it on Friday."  -> rV.loyalfri
* "You owe me nothing, Valko."  -> rV.loyalowe

# rV.loyalfri
valko: Then I'll be there. Not because of Rask. Because of you. That's new. I've never done anything because of somebody before.
{do rel:valko+1; flag:valkoFriday=1}
@end

# rV.loyalowe
valko: That's exactly why I want to.
{do rel:valko+1}
@end

# rV.tame arc=valko night=3,4,5 label="\"Valko. You're keeping your distance.\"" if=flag:valkoAlly&!flag:valkoDead&rep:restraint>=4 prio=-1
@focus valko
valko: You don't eat. You don't fight. You don't run. You walk around the city like a man in a church.
valko: It's unnatural. Hounds like a bit of mess. Hounds like it when you lose it sometimes. It means you're alive. Even if you're not.
* "Want to race me to the docks?"  -> rV.tamerace
* "I can't afford to lose it."  -> rV.tamecant

# rV.tamerace
> He grins with too many teeth.
> You race. Over the dumpsters, across the roofs of Kerr Street, down the fire escapes, through the container yard, out to the end of Pier Nine. He wins by a nose. He'd have won by a street if he wasn't letting you keep up.
> At the end of the pier you're both laughing like idiots in the rain.
{do rel:valko+2; comp+2; tick:25; lean:restraint-1}
@end

# rV.tamecant
valko: No. I know. Rask couldn't either. In the end it all came out at once.
@end

// =====================================================================
// MARGO · mercy, faith
// =====================================================================
# rG2.merc arc=margo night=4,5 label="\"Margo. You saved me a seat.\"" if=rep:mercy>=2&!flag:margoDead prio=-1
@focus margo
margo: I always save a seat. Forty-one years of saving seats on Platform 0. Usually it's for nobody.
margo: You're a kind one, under it all. I can tell by how you sit. Kind people sit like they're not sure they're allowed.
{do rel:margo+1; comp+1}
@end
`,'c_react');
