'use strict';
/* THE NEW LORD — "Petitions": the Sheriff's study is empty and the Ward keeps knocking. Somebody has to hear them. On Nights Three and Four, Pemberton will open the door for you. */
(function(){const X=NL.EXTRAS,S_=NL.Script;
const P=(n,role,skin,hair,shirt,coat,o)=>Object.assign({n,role,color:'#c8b8a0',spec:Object.assign({skin,hair:{style:hair[0],color:hair[1]},shirt,coat:coat?{color:coat,length:.6,collar:true}:null},o||{})});
Object.assign(X,{
  gaston:P('Gaston','Séverine\'s ghoul, forty years',[.86,.76,.7],['slick',[.3,.25,.2]],[.9,.9,.9],[.1,.05,.08]),
  brannigan:P('Mrs. Brannigan','A widow from Kerr Street',[.84,.72,.66],['bun',[.6,.55,.5]],[.3,.3,.35],[.25,.2,.25],{height:.9}),
  kestrel:P('Kestrel','Red Syndicate, a collector',[.7,.6,.56],['shaved',[.2,.2,.2]],[.15,.15,.15],[.4,.05,.05],{eyeGlow:[.35,.05,.05]}),
  plume:P('Lady Plume','The Gilded Court',[.9,.84,.82],['long',[.9,.8,.5]],[.7,.6,.75],[.5,.4,.55],{eyeGlow:[.35,.1,.2]}),
  mrsfinch:P('Doreen Finch','The Rookery Tenants\' Association',[.6,.44,.36],['crop',[.6,.6,.6]],[.7,.3,.3],[.3,.25,.25]),
  tobias:P('Tobias','Wraith, Halloran Street',[.62,.64,.66],['long',[.3,.3,.32]],[.2,.2,.22],[.25,.25,.27],{alpha:.9,eyeGlow:[.2,.25,.3]})
});
NL.TASKS.s_petition2={n:'Petitions',xp:80,cat:'side'};
S_.place({id:'study',name:'The Sheriff\'s Study',block:'B',sub:'Behind the ossuary at the Reliquary. Pemberton says people have been leaving petitions under the door since Monday.',if:'night>=3&night<=4&flag:mapOK&alive:pemberton&!flag:petitionsDone',node:'pt.0',min:6});
})();
NL.Script.add(String.raw`
# pt.0
@gate flag:ptSeen ? pt.again : pt.first

# pt.first
> Absalom Vane's study, behind the Capuchin ossuary at Club Reliquary: the desk the size of a car, the green lamp, the map of the Ward under glass. On the floor inside the door, a drift of envelopes, like leaves.
pemberton: Petitions. They've been coming under the door since Monday morning. The Sheriff heard them every Wednesday from nine until two. Nobody has told the Ward he isn't hearing them any more.
pemberton: Several of the petitioners are waiting in the corridor. They've been waiting for some hours. I have given them chairs.
tenant: You don't have to. You're not the Sheriff. Not yet. Nobody will blame you.
tenant: ...Though I'll admit I'd like to see what you do.
{do flag:ptSeen=1; task:s_petition2; note:s_petition2|Petitioners have been waiting outside the Sheriff's study since Monday. Nobody has told them he's dead. Hearing them is not your job yet.}
* Sit in the Sheriff's chair. "Send in the first."  -> pt.hub
* "Tell them to come back on Saturday."  -> pt.later

# pt.later
pemberton: Very good. I'll tell them. They'll be disappointed. They were disappointed with him too, often. It's part of the service.
@end

# pt.again
pemberton: There are still some waiting, if you wish to hear them.
@next pt.hub

# pt.hub
> The green lamp. The desk. The chair, which is too big for you, and fits you anyway.
* Lady Plume and Kestrel, arguing in the corridor.  -> pt.ground {once}
* Gaston, Séverine's ghoul, holding his hat.  -> pt.gaston {once}
* Mrs. Brannigan, a mortal widow from Kerr Street, who should not know this door exists.  -> pt.widow {once}
* Doreen Finch, of the Rookery Tenants' Association.  -> pt.finch {once}
* A Wraith called Tobias, who has been waiting since 1959.  -> pt.tobias {once}
* "That's enough for tonight, Pemberton."  -> pt.close

// =====================================================================
// THE HUNTING GROUND
// =====================================================================
# pt.ground
> Two of them, in the doorway, both talking at once. A woman in lilac silk with a fan, and a shaven man in red leather with a collector's ledger.
plume: Sheriff... ah. Not the Sheriff. The Sheriff's *child*. Well. You'll do, I suppose.
kestrel: The Lucky Mart block. Ferrier to Kerr, the river to Vine. It's been Syndicate hunting ground since 1979. Sealed by Vane himself.
plume: It was GILDED ground until 1979. Vane gave it to the Syndicate to pay a gambling debt. It was never his to give.
kestrel: Possession is nine-tenths.
plume: Possession is vulgar.
pulse(5): Neither of them cares about the block. They care about who you rule for. This is a test, and both of them know it.
* Rule for the Syndicate. "Vane's seal stands."  -> pt.gr_syn {do lean:loyalty+1}
* Rule for the Court. "A gambling debt isn't a deed."  -> pt.gr_gil {do lean:pride+1}
* "Neither. The Lucky Mart block is closed to all hunting. Forever."  -> pt.gr_none {do lean:mercy+1}
* "Split it. Ferrier for one, Kerr for the other. Toss for which."  -> pt.gr_split

# pt.gr_syn
kestrel: The child honours its father. Good. Malakor will be pleased. Malakor is rarely pleased.
plume: You'll regret this. Not tonight. In about a decade. We keep very good records.
{do flag:ptGround=syn; rel:malakor+1; rel:severine-1}
@next pt.hub

# pt.gr_gil
plume: There. You see? Breeding. It shows even in a neonate.
kestrel: Malakor will hear about this. He'll put it on your invoice.
{do flag:ptGround=gil; rel:severine+1; rel:malakor-1}
@next pt.hub

# pt.gr_none
> They both stare at you as if you'd taken off your face.
kestrel: Closed. To ALL hunting. That's... there's eleven hundred people on that block.
* "Yes. Eleven hundred people. And a corner shop that leaves coffee out for us. Nobody eats where they're fed."  -> pt.gr_none2

# pt.gr_none2
plume: ...How extraordinarily sentimental.
kestrel: How extraordinarily expensive.
plume: I find I don't entirely hate it.
{do flag:ptGround=none; rel:tariq+1}
@next pt.hub

# pt.gr_split
> You toss a coin from Absalom's desk. It's Roman. It comes down heads, which nobody had assigned, so you have to toss it again.
> Ferrier for the Court, Kerr for the Syndicate. Both of them leave unhappy, which, Pemberton tells you later, is how you know it was fair.
{do flag:ptGround=split}
@next pt.hub

// =====================================================================
// GASTON
// =====================================================================
# pt.gaston
> A man of about sixty in impeccable livery, holding a bowler hat in both hands. Séverine's ghoul. You've seen him behind her chair every night, pouring.
gaston: Forgive me. I shouldn't be here. My lady doesn't know. If she knew she would be... disappointed.
gaston: I've served the Gilded Court for forty-one years. I drink from my lady's wrist every Sunday. I am sixty-three, and I look forty, and my hands are steady, and I would like to stop.
gaston: My daughter has a baby. In Ohio. I have never seen her. My lady says the Court needs me. I would like the Sheriff to release me from service. Only the Sheriff can.
web(6): A ghoul's release. Old law. A ghoul can petition the Sheriff to be freed from a bond, and the Sheriff's word outranks the domitor's. Séverine will be furious.
* "Released. Go to Ohio, Gaston."  -> pt.ga_free {do lean:mercy+1}
* "I can't. I'm not the Sheriff. I can't make it stick."  -> pt.ga_cant
* "Wait until Saturday. If I'm Sheriff, you go. If I'm ash, ask whoever's next."  -> pt.ga_wait
* "Does Séverine know you want this? Ask her yourself."  -> pt.ga_ask

# pt.ga_free
gaston: ...Just like that.
> He holds the bowler hat against his chest like a shield.
gaston: You know what happens. Without the Sunday cup. I'll be sixty-three in a month. Sixty-three properly. My hands will shake. My knees will go.
gaston: I'll be able to hold the baby, though. For a while. That's the trade. I've thought about it for nine years.
{do flag:gastonFree=1; rel:severine-2; comp+1}
pemberton: (after he's gone, very quietly) Forty-one years. I'd have liked someone to say "go to Ohio" to me, once. Not that I have a daughter. Not that I'd have gone.
@next pt.hub

# pt.ga_cant
gaston: No. Of course. Forgive me. I'll pour her wine tonight as usual.
@next pt.hub

# pt.ga_wait
gaston: Saturday. If you're... yes. Yes. I'll wait. I'm very good at waiting. It's most of the job.
{do flag:gastonWait=1; promise:gaston:Free Gaston on Saturday, if you can}
@next pt.hub

# pt.ga_ask
gaston: Ask her. Ask my lady. I have tried, three times, since 2015. Each time she smiled and asked me to fetch her shawl.
gaston: I'll fetch the shawl. It's what I do.
{do lean:pride+1}
@next pt.hub

// =====================================================================
// THE WIDOW
// =====================================================================
# pt.widow
> A mortal woman in her seventies, in a good coat and sensible shoes, sitting bolt upright on the chair Pemberton gave her. She has a handbag on her knees and a photograph in her hand. She's terrified. She's furious. She's both, and she's handling it better than most Elders.
brannigan: You're the one. You're the one who sits here now. I found the door. I followed one of you here from the Row. I've been following them for two years.
brannigan: Patrick Brannigan. My husband. A night porter at the Courthouse. 2022. They said a heart attack in the parking lot. He had two marks on his neck. I'm not stupid.
brannigan: I want you to find the one who did it. And I want you to give them to me.
pedigree(6): A mortal who knows. Who found Elysium. Who walked into the Sheriff's study. By the old law, she should not leave this room remembering it.
* "I'll find who did it. And then I'll decide."  -> pt.wi_find
* "I can't give you one of us. But I can make sure they answer for it."  -> pt.wi_answer
* "Mrs. Brannigan. You need to forget this door."  -> pt.wi_forget
* "Who told you how to find this place?"  -> pt.wi_who

# pt.wi_who
brannigan: Nobody told me. I watched. I watched for two years. You think you're invisible. You're not. You walk like you own the sidewalk and you never, ever buy anything in the shops.
@next pt.widow2

# pt.widow2
* "I'll find who did it. And then I'll decide."  -> pt.wi_find
* "I can't give you one of us. But I can make sure they answer for it."  -> pt.wi_answer
* "Mrs. Brannigan. You need to forget this door."  -> pt.wi_forget

# pt.wi_find
> Pemberton, without being asked, opens a ledger from the shelf: the Sheriff's own. *Breaches and Deaths, 2022.* He runs a finger down a column.
pemberton: Patrick Brannigan. March. The Courthouse parking lot. The Sheriff noted: "Lord Ashby, drunk. Fined, ten percent, three years." That's all.
brannigan: Fined. Fined. My Patrick, for ten percent.
* "Lord Ashby will come and say he's sorry. To your face."  -> pt.wi_ashby {if !flag:ashbyDead&!flag:ashbyGone}
* "Ashby will pay. Properly. I'll see to it."  -> pt.wi_pay
* Give her his name and let her do what she likes with it.  -> pt.wi_name

# pt.wi_ashby
brannigan: Sorry. To my face. A vampire. Saying sorry.
brannigan: ...I want to see that. I want to see him have to do it.
{do flag:ashbyApology=1; note:s_petition2|Lord Ashby killed Patrick Brannigan in the Courthouse parking lot in 2022. You promised his widow Ashby would apologize to her face.; promise:brannigan:Make Ashby apologize to Mrs. Brannigan}
@next pt.hub

# pt.wi_pay
brannigan: Pay. What does a thing like you pay with?
* "Your mortgage. Your heating. For the rest of your life. From his money."  -> pt.wi_pay2

# pt.wi_pay2
brannigan: Blood money. From the man who drank Patrick.
brannigan: ...My heating bill was four hundred dollars last winter. Patrick always did the bills. I'll take it. I'll hate it and I'll take it.
{do flag:brannPaid=1}
@next pt.hub

# pt.wi_name
> You tell her. Edmund Ashby. The Reliquary. The VIP. The man with the glass in his hand and the horse in his dreams.
> She writes it on the back of the photograph in biro. She doesn't thank you. She puts it in her handbag and walks out of the Sheriff's study without looking back.
{do flag:brannName=1; lean:candour+1; lean:mercy-1}
@next pt.hub

# pt.wi_answer
brannigan: Answer for it. How? To who? To you?
* "To me. I'll find out, and they'll pay, and you'll know it was done."  -> pt.wi_find

# pt.wi_forget
? velvet 10 "Look at me. Go home. You came here looking for an office that isn't here. You'll remember a dream."  -> pt.wi_forgot | pt.wi_noforget {id pt_wi}

# pt.wi_forgot
> Her eyes go soft. She stands up. She says "excuse me, I think I've got the wrong floor," and goes out with her handbag, past Pemberton, who holds the door.
pemberton: (quietly) The Sheriff did that to her twice. In 2022 and 2023. She keeps finding the door.
{do flag:brannForgot=1; lean:candour-1}
@next pt.hub

# pt.wi_noforget
brannigan: Don't you DARE. Don't you dare do your eyes at me. The last one tried it. It doesn't work on me. Patrick said I was the most stubborn woman in the state.
@next pt.widow2

// =====================================================================
// DOREEN FINCH · the Rookery
// =====================================================================
# pt.finch
> A large woman in a red cardigan with a clipboard, who has clearly been told about this door by someone, and has clearly decided not to be frightened of it.
mrsfinch: Doreen Finch. Chair, Rookery Tenants' Association. I'm told you're the person to talk to about the building, now the tall gentleman's not around.
mrsfinch: The landlord's selling. To a developer. They want to knock it down and put up flats with gyms in. Forty-two households. Eighty-one-year-olds. Babies. A man with thirty-one cats.
mrsfinch: The tall gentleman used to make these things go away. In 1988, a man from the council came round with plans. Next week he'd moved to Arizona. I never asked. I'm asking now.
pulse(5): She knows. Not what you are. Just that you're the thing you go to when the council won't listen.
* "Who's the developer?"  -> pt.fi_who
* "I'll make it go away."  -> pt.fi_away

# pt.fi_who
mrsfinch: Corvid Holdings. Offices in the Heights. Nobody's ever met them. Their letters are on very nice paper.
web(7): Corvid. The Heights. Very nice paper. That's a Court shell company. Someone in the Gilded Court wants the Rookery gone. Something about the building. Or someone in it.
@next pt.fi_away

# pt.fi_away
mrsfinch: Go away. How?
* "I'll talk to the developer. Personally."  -> pt.fi_talk
* "Get me the plans. Malakor can lose them."  -> pt.fi_mal {if alive:malakor}
* "I'll buy the building."  -> pt.fi_buy {if cash>=500}
* "I don't know yet. But it will."  -> pt.fi_promise {do promise:rookery:Save the Rookery from Corvid Holdings}

# pt.fi_talk
mrsfinch: Personally. Like the tall gentleman did with the council man.
mrsfinch: ...I'm not going to ask.
{do flag:rookeryTalk=1}
@next pt.hub

# pt.fi_mal
mrsfinch: Lose them. Right. I'll get you the plans. I've got copies. I've got copies of everything. My late husband said I was a one-woman filing cabinet.
{do flag:rookeryMal=1; rel:malakor+0}
@next pt.hub

# pt.fi_buy
> You put five hundred dollars on the desk. She looks at it.
mrsfinch: Five hundred dollars. For a six-storey tenement in the Marrow Ward.
mrsfinch: Love, that wouldn't buy the boiler.
@next pt.fi_away

# pt.fi_promise
mrsfinch: It will. Right. That's what the tall gentleman always said. "It will, Mrs. Finch." And it always did.
mrsfinch: I'll hold you to it. I'll write it in the minutes.
@next pt.hub

// =====================================================================
// TOBIAS · 1959
// =====================================================================
# pt.tobias
> The last chair in the corridor has had someone in it so long that Pemberton has stopped seeing him. A Wraith, grey, very thin, in a suit from the fifties, translucent at the edges like a photograph left in the sun.
tobias: Oh. Oh, it's my turn. Goodness. I've been waiting since November 1959. I brought a petition about a streetlight.
tobias: There's a streetlight outside 40 Halloran Street. It's too bright. It shines into the alley where I sleep. I wrote to the Sheriff. He said he'd look into it.
pemberton: (very quietly, appalled) ...He did say that. I remember. I gave him the letter. He put it in the drawer.
tobias: Sixty-six years. Well. I'm sure he was very busy.
* "Pemberton. Get me a ladder."  -> pt.to_ladder
* "I'll have it moved. Tonight."  -> pt.to_moved
* "I'm sorry, Tobias. I'm so sorry he never answered."  -> pt.to_sorry

# pt.to_ladder
> Halloran Street at three in the morning. Pemberton holds the ladder. You climb the lamp post outside number 40 and unscrew the bulb with your bare hand. It's warm. It doesn't hurt. It's only an ordinary bulb.
> Tobias stands in the alley, looking up at the dark where the light was, with his hands clasped.
tobias: Oh. Oh, that's lovely. That's lovely. I can see the stars. I'd forgotten there were stars.
{do flag:tobiasDark=1; comp+3; tick:20; lean:mercy+1}
tenant: Sixty-six years. One bulb. God forgive me. One bulb.
@next pt.hub

# pt.to_moved
tobias: Tonight. After sixty-six years. Gosh.
tobias: You know, I'd almost got used to it. Isn't that awful? I'd almost started to like it.
{do flag:tobiasDark=1; comp+1}
@next pt.hub

# pt.to_sorry
tobias: Sorry. Oh, there's no need to be sorry. He was a busy man. I'm a very small thing to be busy about.
tobias: ...Thank you, though. Thank you for saying it. Nobody's said anything to me since 1959. It's very nice to be said something to.
{do comp+1}
@next pt.hub

# pt.close
pemberton: Very good. I'll tell the rest to come back on Saturday. If there is a Saturday.
pemberton: You were... I won't say "very like him". You were not very like him at all. He'd have heard two and gone to bed.
{do flag:petitionsDone=1; task:s_petition2=done; xp:80:Petitions; rel:pemberton+1}
@end

// --- Ashby's apology ---
# ptA.0 arc=ashby night=4,5 label="\"Edmund. Patrick Brannigan. 2022.\"" if=flag:ashbyApology&!flag:ashbyApologised&!flag:ashbyDead&!flag:ashbyGone prio=8
@focus ashby
ashby: ...Brannigan.
> The glass goes down. It doesn't come back up.
ashby: The Courthouse. The parking lot. March. I was... I'd been to the theatre. Lisette had dared me to... it doesn't matter what. I remember his torch. He was checking the doors. He said "you can't be in here, sir." He was very polite.
ashby: Absalom fined me. Ten percent. I paid it gladly. I thought that was the end of it.
* "His widow wants you to say sorry. To her face."  -> ptA.1

# ptA.1
ashby: To her FACE. A mortal. In her house. Me.
? velvet 11 "You said sorry to Coral. You said sorry to a Wraith girl in a broken mask. You know how. Do it once more."  -> ptA.yes | ptA.no {id ptA_v} {mod like:ashby}
? apex 11 "It wasn't a request, Edmund."  -> ptA.yes | ptA.no {id ptA_a} {red}

# ptA.yes
> He goes. You go with him. A terraced house on Kerr Street, a doorbell that plays a tune. Mrs. Brannigan opens the door in her dressing gown and sees him and doesn't scream.
> Lord Edmund Ashby, Ninth Baronet of nothing whatsoever, takes his hat off on a doorstep at four in the morning and says: "Mrs. Brannigan. I killed your husband. I was drunk and bored and he was kind to me. I'm sorry. I have no right to be forgiven and I don't ask it."
> She looks at him for a long time.
brannigan: No. You don't.
> She shuts the door. Not slammed. Just shut. Ashby stands on the step with his hat in his hands until the porch light goes off.
ashby: ...That was the worst thing I've ever done. Worse than Patrick. Isn't that terrible? I'm going to need a drink. I'm not going to have one.
{do flag:ashbyApologised=1; keep:brannigan; rel:ashby+2; lean:candour+1}
@end

# ptA.no
ashby: No. I can't. I won't. I'll pay her. Anything. I won't go to her door.
{do rel:ashby-1}
@end
`,'c_petitions');

NL.Act.extraFates.push(S=>{const f=S.flags,o=[];if(!f.ptSeen)return o;
  if(f.ptGround==='none')o.push(['The Lucky Mart block','Closed to all hunting by order of a neonate who had no authority to close anything. Somehow the order stuck. Eleven hundred people live there and none of them know why it\'s the safest block in the Ward.']);
  if(f.gastonFree)o.push(['Gaston','Lives in Ohio. Sixty-three properly. His hands shake. He holds the baby anyway, very carefully, on his lap, and sings it French songs from the Gilded Court that are far too rude for a baby.']);
  if(f.ashbyApologised)o.push(['Mrs. Brannigan','Never forgave him. Never told anyone. On the anniversary of Patrick\'s death, a wreath arrives with no card. She puts it on the grave anyway.']);
  else if(f.brannName&&!f.ashbyDead)o.push(['Mrs. Brannigan','Kept a name on the back of a photograph. In February she bought a crossbow. Nobody knows what happened next. Lord Ashby stopped going to the Reliquary.']);
  if(f.rookeryTalk||f.rookeryMal)o.push(['The Rookery','Corvid Holdings withdrew its offer in December, citing "unforeseen structural concerns". The plans were never found. Doreen Finch wrote it in the minutes: Item 7, the building stays.']);
  if(f.tobiasDark)o.push(['40 Halloran Street','The streetlight outside has been out since a Thursday in November. The council has sent a man four times. Each time, the next night, it\'s out again. In the alley, a Wraith in a fifties suit lies on his back and looks at the stars.']);
  return o;});
