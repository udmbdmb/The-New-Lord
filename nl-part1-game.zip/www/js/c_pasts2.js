'use strict';
/* THE NEW LORD — who you were, part two: the paramedic, the litigator, the promoter and the clerk, as the Ward sees them */
(function(){const {L,T,C,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);const f=S.flags;
  if(S.past==='paramedic')M.push(C('autopsy',10,'"I was a paramedic for six years. I know how a body lies when it fell, and how it lies when somebody put it there. Absalom Vane was put there."',null,null,{id:'tb_medic',once:'tb_medic',ok:st=>{st.prog+=2;return [T('You describe the freezer floor the way you\'d describe it to an ER doctor at four in the morning: position, lividity, the ash pattern, the scuff on the tiles where a heel dragged.'),L('magistrate','...A medic. Hm. That is the first testimony this week that sounded like it had been in a room with a corpse.')];},no:st=>{st.threat+=1;return [L('severine','A medic. How touching. Did you put a bandage on him before you drank him?')];}}));
  if(S.past==='litigator'&&f.tribLoophole)M.push({t:'"Point of order, Magistrate. Rule four of the Tribunal of 1888 says the Accuser must name the crime before the Accused is asked to answer. Nobody has named it."',once:'tb_rule4',ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-2);return [T('A silence like a held breath under the railway.'),L('magistrate','...Rule four. Rule *four*. Nobody has cited rule four since Absalom Vane wrote it.'),L('magistrate','The Accuser will name the crime.'),L('severine','(through her teeth) Murder. Diablerie. Theft of station.'),L('magistrate','Three. Good. Now we know what we\'re doing. Thank you, counsel.')];}});
  if(S.past==='promoter'&&f.promoterRoom)M.push({t:'"I\'ve worked rooms like this for ten years. Look at who\'s standing at the back. Every one of them came because they want to see the Court lose."',once:'tb_room',ok:st=>{st.prog+=1;return [T('Three hundred heads turn, without meaning to, to look at the back of the platform. Local 0. The Rot. The fledglings in jeans. They look back.'),L('magistrate','...Hm. Yes. A full house. Rare, for a Tribunal. Usually only the accused comes.')];}});
  if(S.past==='clerk'&&f.clerkChain)M.push({t:'"The chain of custody on Absalom Vane\'s ash. Kowalski\'s, Monday, 4:14. St. Jude\'s morgue, 4:31, a John Doe. Back at Kowalski\'s by 4:45. The watch stops at 4:51. I can account for every minute he\'s been dead. Can the Accuser?"',once:'tb_chain',ok:st=>{st.prog+=2;return [L('magistrate','Every minute.'),L('magistrate','Lady Séverine. Can you account for every minute?'),T('She can\'t. She doesn\'t try.')];}});
  return M;};})();
NL.Script.add(String.raw`
# ps.medT arc=tenant night=2,3,4,5 label="\"In the freezer. Did you hear what I said to you?\"" if=past:paramedic prio=1
@focus tenant
tenant: Hear it. Child, I've been hearing it every night since.
tenant: Your teeth in my neck and the dawn not far off, and you had your hand on my chest like you were feeling for a heartbeat, and you said "stay with me". Over and over. "Stay with me. Stay with me."
tenant: I'd been alive for two hundred and sixty-three years. Nobody had ever said that to me. Not my sire. Not Agnes. Not once.
* "It's what I said to everyone. It was a habit."  -> ps.medT1
* "And you stayed."  -> ps.medT2
* "I'm sorry. I didn't mean you to hear it."  -> ps.medT3

# ps.medT1
tenant: A habit. Yes. Ruth told you. Drunks and old ladies in the bath and boys from the Strip with knives in them. You said it to all of them.
tenant: I don't mind that it was a habit. I mind that it worked. I did stay. I'm still here. Your habit's the only reason there's anyone in here to talk to you.
{do sync+2; lean:candour+1}
@end

# ps.medT2
tenant: I stayed. God help us both. I took you literally. I'm a very literal man, it's a Sovereign failing.
{do sync+3; comp+1}
@end

# ps.medT3
tenant: Don't be sorry. Don't ever be sorry for that. Of everything that happened in that freezer, that's the one thing nobody should be sorry for.
{do sync+1; comp+1}
@end

# ps.medR arc=rostova night=2,3,4 label="\"You signed my consent form, Doctor.\"" if=past:paramedic prio=2
@focus rostova
rostova: ...
rostova: Yes. July. You came up from Station 4 on your break in your greens with a hemoglobin of seven and asked me if the trial paid. I said five hundred. You said, "Doc, that's a month of rent and I'm going to die anyway."
rostova: I liked you. You know that? You were the only medic who ever brought the night staff doughnuts. I signed your form and I liked you, and I'd do it again, and I'd still like you.
* "Why me?"  -> ps.medR1
* "You'd do it again."  -> ps.medR2
* "I forgive you. Not because you deserve it. Because I'm too tired not to."  -> ps.medR3

# ps.medR1
rostova: Because you were sick in exactly the right way. Anaemic. Your blood was already hungry. The protocol needed bodies that were already halfway to wanting it.
rostova: That's the truth. You want a kinder one? I haven't got one. I ran out of kind ones in Petersburg in 1993.
{do lean:candour+1; rel:rostova-1; mem:rostova:whyme}
@end

# ps.medR2
rostova: Yes. Because it nearly worked. Because there are children on the third floor with blood that's eating them, and you were the closest I've ever come.
rostova: Hate me for it. You'd be right to. But don't pretend you wouldn't have signed it anyway. I saw your face. You wanted to be useful, even dying. You still do. It's all over you.
{do rel:rostova+1}
@end

# ps.medR3
> She sits down. She's been standing for twelve hours and she sits down in the plastic chair by the window like a building coming down.
rostova: Too tired not to.
rostova: That's the most honest thing anyone's said in this clinic in a year. Thank you. I don't accept it. Thank you.
{do rel:rostova+2; lean:mercy+1; flag:medForgave=1}
@end

# ps.medS arc=leo night=2,3,4,5 label="Look at Leo's knee. Properly. Like a medic." if=past:paramedic&alive:leo prio=1
@focus leo
leo: My knee? My knee's fine. My knee's... ow. Okay. Ow. How did you know it was that bit?
> Your hands know before you do. The joint's swollen, warm, a bruise going yellow at the edges. He's been walking on it for three nights.
* Strap it. Properly. With the tape from the Lucky Mart first-aid kit.  -> ps.medS1
? abattoir 9 "Hold still. I can do better than tape."  -> ps.medS2 | ps.medS3 {id ps_meds}

# ps.medS1
> You strap it in a figure of eight, the way Ruth taught you, talking about nothing the whole time. The weather. Baseball. He doesn't notice when you pull it tight.
leo: You're good at this. You're weirdly good at this. Were you a nurse? Were you a nurse before you were a... a Sheriff-vampire?
* "A paramedic. Station 4. Six years."  -> ps.medS4
* "Something like that."  -> ps.medS5

# ps.medS4
leo: A paramedic. Oh my God. You were an actual hero. You were an actual, real-life, rides-in-the-loud-van hero and now you're... okay. Okay. This is going in the act. Not as a joke. As a... I don't know what. As a thing.
{do rel:leo+2; comp+1; flag:leoKnowsMedic=1}
@end

# ps.medS5
leo: Something like that. Sure. Mysterious. Cool. I'll pretend I don't want to know.
{do rel:leo+1}
@end

# ps.medS2
> You put your thumb on the swelling and think about it going down. It goes down. The bruise fades from yellow to nothing in the time it takes him to say "what are you".
leo: ...That's not first aid. That's, like, fifth aid.
{do rel:leo+1; flag:leoKneeFixed=1}
@end

# ps.medS3
> It hurts him. It hurts him a lot. Then it's better. Not fixed. Better.
leo: OW. Okay. Okay. That was a lot. I think it's better? It's better. It's better and I hate you.
{do rel:leo+1}
@end

# ps.litT arc=tenant night=2,3,4,5 label="\"You never told me you knew I was a lawyer.\"" if=past:litigator prio=1
@focus tenant
tenant: Didn't I? I knew on Monday morning. You died arguing. Your teeth in my throat and you were still making a closing statement in your head. I could hear it. "The defence would ask the court to consider..."
tenant: I wrote the rules of the Tribunal, child. In 1888. Eleven rules, on a single sheet of the Prince's notepaper. I was very proud of them. Nobody has read them since.
* "Show me the rules."  -> ps.litT1
* "You wrote the rules that are going to try me."  -> ps.litT2

# ps.litT1
tenant: In the study. Third drawer down, under the pistols. Read rule four. I wrote it on a bad night, after a Tribunal in Boston where a fledgling was burned before anybody had said what for.
tenant: "The Accuser must name the crime before the Accused is asked to answer." Nobody ever cites it. They all assume they know what the crime is. You'd be astonished how often they don't agree.
{do flag:tribLoophole=1; mem:tenant:rule4; xp:25:Rule Four}
@end

# ps.litT2
tenant: Yes. That's the joke, isn't it? Hoist with my own notepaper.
tenant: They're good rules, mostly. I'm prouder of them than of anything else I did as Sheriff. If they burn you anyway, at least they'll have to do it properly.
{do sync+1}
@end

# ps.litS arc=severine night=3,4 label="\"My lady. The Accuser's brief. Have you drafted it?\"" if=past:litigator prio=2
@focus severine
severine: Drafted. Darling, it's a Tribunal, not a divorce. I'll stand in the chalk and say you ate Absalom, and three hundred people will nod.
? pedigree 10 "Then you'll lose on a procedural point and look a fool in front of the whole Court. Rule four."  -> ps.litS1 | ps.litS2 {id ps_lits} {if flag:tribLoophole}
* "Then I look forward to it."  -> ps.litS3

# ps.litS1
> She stops. The fan stops.
severine: Rule four. Rule *four*. Absalom's little sheet of notepaper. Nobody has...
severine: You've *read* them. Of course you've read them. You're a lawyer. Oh, God, they've sent me a lawyer.
severine: Very well. I'll draft a brief. You'll have it Thursday. It will be eleven pages and you'll find nothing in it to object to.
{do rel:severine+1; flag:sevBrief=1}
@end

# ps.litS2
severine: Procedural points. In a chalk circle under a railway. Darling, you've been watching too much television.
@end

# ps.litS3
severine: Do you. How brave. How very American.
@end

# ps.litSh arc=pemberton night=3,4,5 label="\"Pemberton. Did the Sheriff leave a will?\"" if=past:litigator prio=1
@focus pemberton
pemberton: A will, ‹sir›. Yes. In the safe at the house. Drafted in 1961. Witnessed by me and by Mrs. Agnes Dunmore's husband, who was, I believe, a lawyer by then.
pemberton: I've never read it. It's not my place. I've thought about it every night since Monday.
* "Bring it to me. I'll read it."  -> ps.litSh1
* "Read it yourself, Pemberton. You're a witness. You've every right."  -> ps.litSh2

# ps.litSh1
> He brings it in a manila envelope gone soft as cloth with age. Three pages in a lawyer's hand. The last will and testament of Absalom Vane, Sheriff of the Marrow Ward.
> Most of it is nothing: the house to the office of the Sheriff, the pistols to the Prince, a sum to the Courthouse widows' fund. Then the last clause.
> *To my driver, Mr. Pemberton, the Continental and its keys, and my apology, which I find I cannot make to his face. He may decide for himself whom he serves.*
pemberton: ...
pemberton: Would you read the last line again, ‹sir›. Slowly.
{do flag:vaneWill=1; rel:pemberton+2; xp:30:The Last Clause}
tenant: (very quietly) I'd forgotten I wrote that. I forgot on purpose.
@end

# ps.litSh2
pemberton: Every right. ‹Sir›, I've had no rights since 1983. I don't know how to hold one.
> But he takes the envelope. He sits in the driver's seat of the Continental with the interior light on and reads it, all three pages, twice. Then he folds it and puts it in his breast pocket and starts the car and says nothing at all for six miles.
pemberton: He left me the car.
pemberton: And something else. I'll tell you another time, ‹sir›. Perhaps on Saturday. If I've decided by Saturday.
{do flag:vaneWill=1; flag:pembReadWill=1; rel:pemberton+3; lean:mercy+1}
@end

# ps.proT arc=tenant night=2,3,4,5 label="\"Did you ever go to the clubs?\"" if=past:promoter prio=1
@focus tenant
tenant: The clubs. Child, I *was* the clubs. The Cotton Club. Small's. A speakeasy under a funeral parlour on Halloran Street called the Wake, 1926, where the gin was made in a coffin and the band was all Rot.
tenant: I took Agnes once. She danced with a trombonist called Wick. The same Wick, I think, who died in the fire. I never asked. I didn't dance. Sovereigns don't. I stood at the bar with one hand behind my back and looked disapproving and had the best night of my life.
tenant: You'd have liked it. You'd have run the door.
* "I'd have let you in."  -> ps.proT1
* "I'd have made you dance."  -> ps.proT2

# ps.proT1
tenant: You'd have let me in. A Sovereign, in a cape, looking disapproving. You'd have let me in because I'd have been funny to watch.
tenant: That's what you did at the Velvet Hour, isn't it. Let in the people who'd be funny to watch.
{do sync+1; flag:promoterRoom=1}
@end

# ps.proT2
tenant: You'd have tried. You'd have failed. And then at three in the morning, when the trombonist played something slow, perhaps not.
{do sync+2; flag:promoterRoom=1}
@end

# ps.proL arc=leo night=2,3,4,5 label="\"Leo. Did you ever play the Velvet Hour?\"" if=past:promoter&alive:leo prio=2
@focus leo
leo: The Velvet... wait. Wait wait wait. The Velvet Hour. On Dock Road. With the disco ball. I played there. Once. Two years ago. Comedy night on a Thursday that nobody came to, in a room built for nine hundred people.
leo: Eleven people. I counted. And this promoter at the back, in a jacket with sequins on it, laughing at every single joke. *Every* single joke. Even the bus one.
leo: ...That was you. Oh my God. That was you. You booked me.
* "It was me. You were good."  -> ps.proL1
* "It was me. You were terrible. I laughed anyway."  -> ps.proL2

# ps.proL1
leo: I was not good. I was a guy doing nine minutes about his sister's hamster to eleven people and a bar staff.
leo: But you said I was good. After. You came to the green room, which was a cupboard, and said "come back in a year, you'll be great". I've been holding onto that for two years. I didn't know it was you. I've been holding onto a vampire.
{do rel:leo+2; comp+1; mem:leo:velvet}
@end

# ps.proL2
leo: Terrible! I was terrible. Okay. Yes. I was terrible. Thank you. Nobody else will say it.
leo: But you laughed. That's what I remember. One person laughing at the back. That's why I kept going. It's literally why I'm still doing this. It was YOU?
{do rel:leo+2; lean:candour+1; mem:leo:velvet}
@end

# ps.proTi arc=tiny night=2,3,4,5 label="\"Tiny. The list. The night the seven left with the Court.\"" if=past:promoter&flag:velvetList prio=2
@focus tiny
tiny: The list. Your list. The Velvet Hour sent people up to us every Thursday after you closed. Your guests. You'd write their names on a card and I'd let them in.
tiny: Seven names left with Court people. I saw them go up the stairs to the crypt. Lisette. Ashby. A man with a silver ring. I let them go. That's my job. That's the door. You let people in and you let them go.
* "It wasn't your fault."  -> ps.proTi1
* "You knew. You knew where they were going."  -> ps.proTi2

# ps.proTi1
tiny: No. It wasn't. And it wasn't yours. You made a list of people who wanted a good night and somebody used it to make a different list.
tiny: I'm keeping the cards. Every one. If you need them on Friday, they're in the box under my stool.
{do rel:tiny+1; flag:tinyCards=1}
@end

# ps.proTi2
tiny: I knew where they were going. Upstairs. I didn't know what upstairs meant. I know now.
> He looks at the rope. He looks at it for a long time, like it's something he's never seen before.
{do rel:tiny-1; lean:candour+1}
@end

# ps.clkT arc=tenant night=2,3,4,5 label="\"Why do you keep counting the minutes?\"" if=past:clerk prio=1
@focus tenant
tenant: I don't. You do. You've been doing it since Monday. 4:14. 4:31. 4:45. 4:51. Chain of custody. Every minute since I died, in order, in your head, like a ledger.
tenant: I used to think evidence clerks were the dullest people in the world. I've been in your head for four days. You're not dull. You're the only person in the Ward who knows exactly where I've been every minute since I died. Including me.
* "Somebody has to."  -> ps.clkT1
* "Walk me through it. Monday morning. Every minute."  -> ps.clkT2

# ps.clkT1
tenant: Somebody has to. Yes. Agnes used to say that about the Courthouse files. "Somebody has to know where everything is, Absalom, or it's all just paper."
{do sync+1}
@end

# ps.clkT2
tenant: 3:50, the two of us at Kowalski's back door. 4:14, the light. 4:20, you run, carrying something long. 4:31, a John Doe signed into the morgue at St. Jude's by someone with your face. 4:45, back. 4:51, my watch stops, and the gate locks behind you.
tenant: ...And somewhere between 4:31 and 4:45 you gave an old woman in the drains a key, and she made you sign for it in blood. You don't remember that. I do. You held my key in your fist so tightly it left a mark.
{do sync+2; flag:clerkChain=1; xp:25:Chain of Custody}
@end

# ps.clkM arc=miller night=2,3,4,5 label="\"Black, burnt, no sugar.\"" if=past:clerk prio=2
@focus miller
> You put the coffee down in front of her. The Lucky Mart's worst. Black. Burnt. No sugar.
miller: ...How do you know how I take it?
> She looks at the cup. She looks at you. Her face is doing something complicated.
miller: The clerk. At the cage. Every Thursday for eight years I brought them this exact coffee when I came down for my brother's box. I never asked how they took it. They drank it anyway. Then they got moved to traffic. Then they got sick.
miller: Then they were dead.
* "I'm not dead. Not exactly. Hello, Detective."  -> ps.clkM1
* "A lot of people take it like that."  -> ps.clkM2

# ps.clkM1
> She doesn't move. She doesn't reach for her gun. She reaches, very slowly, for the coffee, and drinks some, and puts it down.
miller: You found the seven files. Before me. You found them last summer. O'Keefe told me Wednesday. He said "the clerk found them first, Ines, and look what happened."
miller: I looked for you. You know that? When they said you'd died abroad. I pulled your file. There was nothing in it. Eight years of Thursdays and there was nothing in it.
* "There's something in it now."  -> ps.clkM3

# ps.clkM3
miller: ...Yeah. Yeah. I guess there is.
> She drinks the coffee. All of it. She never finishes a coffee.
{do rel:miller+3; flag:millerKnowsClerk=1; lean:candour+1; mem:miller:clerk}
@end

# ps.clkM2
miller: Yeah. A lot of people.
> She doesn't drink it. She holds it with both hands, the way you'd hold something warm on a cold night, and looks at you over it until you have to look away.
{do rel:miller+1}
@end

# ps.clkK arc=kenpruitt night=2,3,4 label="\"Officer Pruitt. Badge 4471. I signed in every seizure you ever made.\"" if=past:clerk prio=2
@focus kenpruitt
kenpruitt: ...What did you say?
> He takes a step back. A big man, a careful man, a man who's been very careful for eleven years, taking a step back on a wet sidewalk.
kenpruitt: You're the clerk. The clerk from the cage. They said you were... I signed the card. For the collection. I put in ten.
* "You seized twelve hundred dollars from a Lucky Mart in March and logged four hundred. I noticed. I didn't say anything. Why didn't I say anything, Ken?"  -> ps.clkK1
* "Your nephew's alive. Leo. He's with me. He's fine."  -> ps.clkK2 {if alive:leo}

# ps.clkK1
kenpruitt: Because you knew about Rosa. My sister. Leo's mom. You knew she was behind on the house. You knew I was paying it. You covered for me because you were a soft touch, and I let you.
kenpruitt: ...What do you want? What do you want for it? Just say.
* "Stop collecting from Tariq. That's all. Stop."  -> ps.clkK3
* "Nothing. I'm not a cop any more. I'm not anything any more."  -> ps.clkK4

# ps.clkK3
kenpruitt: Stop. Dale won't stop. Dale's got a boat.
kenpruitt: ...I'll stop. I'll tell Dale I'm out. He'll be angry. I've been more scared of Dale than I've been of anything. Until about thirty seconds ago.
{do flag:kenOut=1; rel:kenpruitt+1; xp:30:Badge 4471}
@end

# ps.clkK4
kenpruitt: Nothing. Nobody wants nothing. Not in the Ninth.
> He walks away fast. Halfway down the block he stops and comes back.
kenpruitt: Thank you. For March. I never said. Thank you.
{do rel:kenpruitt+2; lean:mercy+1}
@end

# ps.clkK2
kenpruitt: He's... with you. With a... is he...
kenpruitt: Is he warm? Just tell me if he's warm.
* "He's warm. He's annoying. He's fine."  -> ps.clkK5

# ps.clkK5
> Officer Ken Pruitt, Precinct 9, eleven years on the Abattoir Strip, sits down on the hood of his patrol car and puts his face in his hands. When he takes them away, he's laughing.
kenpruitt: Annoying. Yeah. That's Leo. That's Leo.
{do rel:kenpruitt+2; flag:kenKnowsLeo=1}
@end
`,'c_pasts2');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.vaneWill&&!f.pemDead)o.push(['The Continental',f.pembReadWill?'Is registered, as of December, to a Mr. R. Pemberton of Halloran Street. He still drives the Sheriff. He has started, occasionally, to drive somewhere else first.':'Is registered, as of December, to a Mr. R. Pemberton. The last clause of the will is framed on the dashboard. He reads it at red lights.']);
  if(f.kenOut)o.push(['Wednesdays at the Lucky Mart','No unmarked car. Tariq keeps waiting for it at three, out of habit, with the envelope ready. In February he stops putting the envelope together.']);
  if(f.millerKnowsClerk)o.push(['The evidence cage, Precinct 9','Every Thursday, a cup of coffee is left on the clerk\'s desk. Black, burnt, no sugar. Nobody drinks it. Nobody throws it away until Friday.']);
  return o;});
