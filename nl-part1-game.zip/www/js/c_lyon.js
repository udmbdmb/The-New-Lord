'use strict';
/* THE NEW LORD — "The Deckchair": the old man on the bus shelter was the Prince of Lyon in 1793. Séverine was his courtier. Neither knows the other is in the Ward. */
(function(){NL.TASKS.s_lyon={n:'The Deckchair',xp:60,cat:'side'};
NL.Script.place({id:'shelterroof',name:'The Bus Shelter, Vine Street',block:'A',sub:'An old man in a striped deckchair on the roof of a bus shelter, watching the buses.',if:'night>=3&night<=5&flag:mapOK&mem:oldkin.lyon&!flag:lyonDone|night>=3&night<=5&flag:mapOK&flag:mqOldPrince&!flag:lyonDone',node:'ly.0',min:6});})();
NL.Script.add(String.raw`
# ly.0
> Vine Street. The bus shelter. On its roof, in a striped deckchair, wrapped in tartan, the old Kindred who was the Prince of Lyon. He doesn't look down. He lifts the corner of his blanket, which is apparently an invitation.
oldkin: The two-voiced one. Again. Come up. The second deckchair is still wet. It's always wet. That's its function.
> You climb up. You sit. The buses go by below, lit, empty, at three in the morning.
{do task:s_lyon}
* "In Lyon, in 1793. Did you know a girl called Séverine?"  -> ly.sev {if alive:sev}
* "What did it feel like? Walking away?"  -> ly.walk
* "Do you ever want to go back?"  -> ly.back

# ly.walk
oldkin: Like setting down a suitcase you've carried so long you forgot it wasn't your arm.
oldkin: For about a month I kept reaching for it. Then I stopped. Now I watch buses. The 9 is late again. It's always late. The driver is in love with a woman at the Kerr Street stop.
nostalgia(5): Leo's bus bit. The one nobody laughs at. It's true.
@next ly.hub

# ly.back
oldkin: Back. To a court. To being looked at. To being *something*.
oldkin: Every night. Every single night. That's why I sit up here, where nobody looks up. If I sat on the sidewalk, someone would recognize me, and ask, and I'd say yes.
@next ly.hub

# ly.hub
* "In Lyon, in 1793. Did you know a girl called Séverine?"  -> ly.sev {once} {if alive:sev}
* "Goodnight, Your Highness."  -> ly.bye

# ly.sev
> He goes very still. The blanket slips off one shoulder and he doesn't notice.
oldkin: Séverine. Séverine d'Aubigny. Seventeen years in my court. The youngest Keeper I ever had. She hid a priest in her cellar during the Terror and thought I didn't know.
oldkin: I knew. I let her. When they took him I... I didn't stop it. I could have. One word, to the Committee. I didn't say it. I'd already decided to walk away, you see, and a Prince who is about to walk away doesn't spend favours.
oldkin: She's here? In this city?
* "She's the Keeper of Elysium. Three streets away. She doesn't know you're alive."  -> ly.she
* "No. I was asking."  -> ly.lie {do lean:candour-1}

# ly.lie
oldkin: Ah. Asking. Of course.
> He doesn't believe you. He lets you have it anyway, the way old people let children have small lies.
@next ly.bye

# ly.she
oldkin: Keeper of Elysium. Of course she is. She was always going to be. She had the walk at seventeen.
oldkin: Three streets.
> He looks down Vine Street toward Reliquary Row as if he could see through the buildings.
* "Do you want to see her?"  -> ly.see
* "Should I tell her you're here?"  -> ly.tell
* "Leave it. Some doors stay shut."  -> ly.shut

# ly.see
oldkin: See her. And have her see me. In a deckchair. Under a tartan blanket from a charity shop.
oldkin: ...Yes. God help me. Yes. Once. Before I lose my nerve. I lost my nerve in 1793 and it took me two hundred years to find it was gone.
* "I'll bring her here."  -> ly.bring

# ly.bring
> It takes a great deal of persuading. You tell Séverine only that someone on Vine Street knew her in Lyon. She goes very white and asks no questions and puts on her gloves.
> Vine Street, the bus shelter, three in the morning. Séverine stands on the sidewalk in her evening coat, looking up at an old man in a deckchair. He looks down at her.
> Neither of them says anything for the whole length of a bus going by.
severine: ...Monseigneur.
oldkin: Séverine. You've got older.
severine: You haven't. You've got smaller.
oldkin: Yes. That was the idea.
> She climbs onto the roof of the bus shelter. In her evening dress. You've never seen anything so undignified, and so dignified, at once. She sits in the wet second deckchair, and he puts half the tartan blanket over her knees.
> You leave them there. As you go, you hear her say "Antoine," and him say "I know. I know. I'm sorry," and her not say anything at all.
{do flag:lyonDone=1; flag:lyonReunion=1; task:s_lyon=done; xp:60:The Deckchair; rel:severine+3}
tenant: (very quietly) I sat in that court. I saw them both. I never once thought they'd be sitting on a bus shelter together two hundred years later. You do the strangest things to people, child.
@end

# ly.tell
oldkin: Tell her. And let her choose. Yes. That's better. She was always better at choosing than I was.
{do flag:lyonTell=1}
@next ly.bye

# ly.shut
oldkin: Some doors stay shut. Yes. That's what I told myself in 1793.
oldkin: ...You're right, of course. Let her keep her Prince the way she remembers him. Tall. In a court. Not in a deckchair.
{do flag:lyonDone=1; task:s_lyon=done; xp:40:The Deckchair}
@end

# ly.bye
oldkin: Goodnight. Mind the second step. The council keeps meaning to fix it.
@end

# lyS.0 arc=severine night=3,4,5 label="\"My lady. Someone in the Ward knew you in Lyon.\"" if=flag:lyonTell&!flag:lyonDone&alive:sev prio=7
@focus severine
> She doesn't ask who. She knows there's only one person it could be who would not have come to her himself.
severine: He's alive. The Prince. He walked into the sun in 1793. Everyone saw.
severine: ...Nobody saw. They said they saw. Where is he?
* Tell her. Vine Street. The bus shelter.  -> lyS.tell

# lyS.tell
severine: A bus shelter. The Prince of Lyon. On a bus shelter.
> She's very quiet for a long time.
severine: I'll go. Not tonight. Not this week. When this is over. I'll go and sit with him and not say anything, and he'll not say anything back, and that will be the conversation we never had in 1793.
{do flag:lyonDone=1; flag:lyonLater=1; task:s_lyon=done; xp:50:The Deckchair; rel:severine+2}
@end
`,'c_lyon');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.lyonReunion&&!f.sevDead)o.push(['The bus shelter on Vine Street','Has two deckchairs on its roof now. Both dry. Every Sunday, at three, the Keeper of Elysium and the Prince who walked away sit on it in silence and watch the 9 come in late.']);
  else if(f.lyonLater&&!f.sevDead)o.push(['The bus shelter on Vine Street','In December a lady in an evening coat stood on the sidewalk beneath it for an hour without climbing up. In January she climbed up.']);
  return o;});
