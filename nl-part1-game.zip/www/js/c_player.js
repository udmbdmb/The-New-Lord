'use strict';
/* THE NEW LORD — who you see in the mirror: a premade face for every clan, as a man or a woman.
   NL.PREMADE[clan][m|f] sets skin/hair indices (into NL.LOOKS) and extra model params.
   Painted portraits, when supplied, live at NL.PAINTED['you_<clan>_<m|f>']. */
(function(){
const C=NL.CHARS,X=NL.EXTRAS;
/* women in the cast get the narrower-shouldered build */
['severine','miller','rostova','margo','soot','lisette','okafor','coral','mina','mrsfinch','maureen','nell','dot','robin','rosa','ottilie','quill','wen','kestrel','aisling','margaret','bartender','dancer','nurse','prophet','rina','dani','danielle','grace','ruth','agnes','doreen','mbeki','aunt','bea','lucia','neonate','fledgling','ines','hollis','brannigan','vend','sallow','okafor'].forEach(id=>{const t=C[id]||X[id];if(t&&t.spec&&t.spec.fem==null&&id!=='prophet')t.spec.fem=true;});

/* skin: 0 Porcelain 1 Olive 2 Bronze 3 Umber 4 Ebony · hair: 0 crop 1 slick 2 long 3 bun 4 curly 5 shaved · colour: 0 Raven 1 Chestnut 2 Copper 3 Ash 4 Oxblood 5 Silver */
const P={
 sovereign:{
  m:{t:'The Heir',d:'A face built for portraits. Silver at the temples a decade early. A mouth that has never once had to ask twice.',skin:0,hair:1,hairCol:0,spec:{face:{jaw:1.25,chin:1.2,nose:1.15,brow:1.1,cheek:1.3,long:1.03},age:0.45,eyeSize:0.95}},
  f:{t:'The Heiress',d:'Cheekbones you could cut a contract on. Black hair pinned like a crown. Gold eyes that price you to the cent.',skin:1,hair:3,hairCol:0,spec:{fem:true,face:{jaw:0.85,cheek:1.6,nose:0.95,chin:1.0,long:1.04},lips:[.5,.12,.16],age:0.3}}},
 wraiths:{
  m:{t:'The Gaunt',d:'Shaved to the bone, cheeks fallen in, the grey already under the skin. Strangers look straight through you. Good.',skin:2,hair:5,hairCol:0,spec:{face:{hollow:1,cheek:1.6,socket:1.5,jaw:1.1,wide:0.95},age:0.55}},
  f:{t:'The Revenant',d:'Long ash hair that never quite dries. A face like a photograph left in a window. You could be thirty. You could be dead a century.',skin:0,hair:2,hairCol:3,spec:{fem:true,face:{hollow:0.9,socket:1.45,cheek:1.5,long:1.06,wide:0.94},age:0.35}}},
 glass:{
  m:{t:'The Seer',d:'Copper curls, chewed nails, eyes a little too wide, as if the room is louder than it looks. Somebody once called you sensitive. They were being kind.',skin:0,hair:4,hairCol:2,spec:{face:{jaw:0.8,chin:0.9,nose:1.05,wide:0.96},eyeSize:1.15,age:0.2}},
  f:{t:'The Oracle',d:'White-silver hair in a long fall, pale lashes, a stare that lands half a second after everyone else\'s and twice as deep.',skin:1,hair:2,hairCol:5,spec:{fem:true,face:{jaw:0.8,chin:0.9,long:1.05},eyeSize:1.18,age:0.25}}},
 choir:{
  m:{t:'The Crooner',d:'Chestnut hair swept back, a mouth made for the microphone, lashes people mention. You look like an album cover from a better decade.',skin:2,hair:1,hairCol:1,spec:{face:{jaw:0.95,cheek:1.45,lips:1.3,nose:0.95},age:0.25}},
  f:{t:'The Diva',d:'Oxblood hair down to the shoulder blades, a red mouth, a profile that stops conversations in the next room.',skin:3,hair:2,hairCol:4,spec:{fem:true,face:{cheek:1.55,lips:1.45,nose:0.9,jaw:0.8},lips:[.55,.08,.14],age:0.2}}},
 butchers:{
  m:{t:'The Surgeon',d:'Shaved head, neat seams at the scalp line, a jaw squared off by somebody\'s scalpel. Possibly your own.',skin:1,hair:5,hairCol:0,spec:{face:{jaw:1.45,chin:1.3,brow:1.25,nose:1.2,wide:1.03},beard:'stubble',age:0.4}},
  f:{t:'The Anatomist',d:'Raven hair scraped into a surgical knot. A face too symmetrical to be born that way, with a fine white scar from ear to collarbone.',skin:0,hair:3,hairCol:0,spec:{fem:true,face:{jaw:1.05,cheek:1.4,nose:1.0,chin:1.1},age:0.35}}},
 hounds:{
  m:{t:'The Tracker',d:'Close-cropped, three days of stubble, a runner\'s neck and a broken nose that set itself. Amber eyes that never stop counting exits.',skin:3,hair:0,hairCol:0,spec:{face:{jaw:1.3,nose:1.3,noseW:1.2,brow:1.2,cheek:1.2},beard:'stubble',width:1.04,age:0.35}},
  f:{t:'The Huntress',d:'Copper hair cropped short for speed, freckles gone pale, a wiry build that looks like it could run all night. It can.',skin:2,hair:0,hairCol:2,spec:{fem:true,face:{jaw:1.0,cheek:1.4,nose:1.1,chin:1.05},age:0.25}}},
 alchemists:{
  m:{t:'The Notary',d:'Ash-blond hair parted like a ledger, wire-rimmed spectacles, ink on the second finger. You look like you\'d read the small print. You wrote it.',skin:0,hair:1,hairCol:3,spec:{face:{jaw:1.0,nose:1.15,chin:1.1,long:1.04},glasses:{type:'reading',color:[.6,.55,.45]},age:0.4}},
  f:{t:'The Apothecary',d:'Chestnut hair pinned up with a pencil, olive skin, a mouth that always seems about to name a price. Green light in the eyes.',skin:1,hair:3,hairCol:1,spec:{fem:true,face:{cheek:1.4,nose:1.05,jaw:0.9},age:0.3}}},
 hollow:{
  m:{t:'The Absence',d:'The mirror shows a coat, standing up on its own. Others say: black hair slicked back, porcelain skin, a face like a held breath. You\'ll have to take their word for it.',skin:0,hair:1,hairCol:0,spec:{face:{jaw:1.15,cheek:1.4,hollow:0.5,long:1.05},age:0.3}},
  f:{t:'The Eclipse',d:'The mirror shows a dress, and nothing in it. Others say: long black hair, a pale oval face, eyes that seem to sit further back than eyes should.',skin:0,hair:2,hairCol:0,spec:{fem:true,face:{long:1.06,cheek:1.45,hollow:0.4,jaw:0.85},age:0.25}}},
 rot:{
  m:{t:'The Gravedigger',d:'Bald, broad, slow-moving, skin gone the grey of wet concrete. You smell faintly of turned earth and you don\'t mind at all.',skin:4,hair:5,hairCol:0,spec:{face:{jaw:1.4,wide:1.06,nose:1.25,noseW:1.3,brow:1.35},width:1.08,bulk:1.05,age:0.6}},
  f:{t:'The Mourner',d:'Close-cropped, grey-skinned, heavy-lidded, very still. You look like someone who sits up with the dead and isn\'t frightened of them. You are.',skin:3,hair:0,hairCol:0,spec:{fem:true,face:{jaw:1.1,cheek:1.3,brow:1.2},age:0.45}}},
 stray:{
  m:{t:'The Mongrel',d:'Black curls grown out, a split eyebrow, mismatched eyes and a grin that\'s been punched more than once. Nobody\'s anything. Yours.',skin:4,hair:4,hairCol:0,spec:{face:{jaw:1.15,brow:1.2,nose:1.2,lips:1.2},beard:'stubble',age:0.25}},
  f:{t:'The Alley Cat',d:'Box-dye red crop, a nose ring taken out years ago, mismatched eyes and a jacket from somebody else\'s band. You\'ve slept in worse.',skin:1,hair:0,hairCol:4,spec:{fem:true,face:{jaw:0.95,cheek:1.35,nose:1.05},age:0.2}}}
};
NL.PREMADE=P;
NL.premadeFor=(clan,g)=>P[clan]&&P[clan][g==='f'?'f':'m']||null;
/* the player's painted portrait follows clan and gender */
NL.PAINTED=NL.PAINTED||{};
try{Object.defineProperty(NL.PAINTED,'you',{configurable:true,enumerable:false,get(){const S=NL.G&&NL.G.S;if(!S||!S.clan)return null;return NL.PAINTED['you_'+S.clan+'_'+(S.gender==='f'?'f':'m')]||null;}});}catch(e){}
})();
/* one set of equipment slots: older items used body/coat/head/acc */
(function(){const FIX={body:'torso',coat:'torso',head:'face',acc:'pocket',acc1:'pocket',acc2:'pocket'};
Object.keys(NL.ITEMS).forEach(k=>{const it=NL.ITEMS[k];if(!it||!it.slot)return;it.id=it.id||k;if(/^tattoo_/.test(k))it.slot='ink';else if(FIX[it.slot])it.slot=FIX[it.slot];});
if(!NL.SLOTS.includes('ink'))NL.SLOTS.push('ink');NL.SLOT_NAMES.ink='Ink';})();
