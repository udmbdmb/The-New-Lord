'use strict';
/* THE NEW LORD — "Open Mic": after Leo's set at the Lantern Room on Tuesday, there's a space on the list. You could put your name down. */
NL.EXTRAS.host=NL.EXTRAS.host||{n:'The host',color:'#c0b0a0',role:'The Lantern Room',spec:{face:{long:1.0,cheek:1.1},skin:[.84,.72,.66],hair:{style:'bun',color:[.4,.3,.2]},shirt:[.5,.35,.3],coat:{color:[.45,.3,.28],length:.5,collar:false}}};
document.addEventListener('DOMContentLoaded',()=>{const N=NL.STORY.nodes,{O}=NL.DSL;const n=N['lan.0'];if(!n)return;
  n.end=false;n.opts=[O('Put your name down on the list. There\'s a gap after the guy with the ukulele.','om.0'),O('Slip out before the next act.','om.leave')];});
NL.Script.add(String.raw`
# om.leave
> You slip out up the stairs. Behind you, a man with a ukulele begins a song about his ex-wife's new boyfriend's boat.
@end

# om.0
> The list is on a clipboard by the bar, in biro. Nine names. Leo's is third, crossed out with a flourish. The gap is eighth.
> You write something. Your hand writes it before you decide.
* Write "Casey".  -> om.name {if name}
* Write "The Night Shift".  -> om.name2
* Write nothing. Just a line.  -> om.name3

# om.name
{do flag:omName=casey}
@next om.wait

# om.name2
{do flag:omName=shift}
@next om.wait

# om.name3
{do flag:omName=line}
@next om.wait

# om.wait
> Leo sees you at the clipboard from across the room. His face goes through about nine emotions in a second.
leo: (hissing, at your elbow) What are you DOING? You can't... you're... what are you going to DO up there?
* "I don't know yet."  -> om.wait2
* "Watch."  -> om.wait2

# om.wait2
> The ukulele man finishes. Polite applause. The host, a tired woman in a cardigan, squints at the clipboard.
host: Next up we have... I can't read this... somebody. Give it up for somebody.
> Twelve tables. Forty people. A microphone stand that leans to the left. The light is a single bulb in a tin shade, and it's warm, and it's on you.
stagecraft(4): Forty faces. Most of them drunk. Most of them kind. All of them waiting. You've done this before. Somewhere. You've stood in front of people. Your body remembers how to hold a microphone.
* Tell them the truth. "I died on Monday."  -> om.truth
* Do Leo's material, better than Leo does it.  -> om.leo
* Sing.  -> om.sing
* Read them something. A letter.  -> om.letter {if flag:readAgnes|flag:agnesPost}
* Let the Tenant have the microphone.  -> om.tenant {if sync>=30}
* Freeze.  -> om.freeze

# om.truth
> You lean into the microphone.
> "Hi. I died on Monday."
> A couple of people laugh, uncertainly. You keep going.
> "I woke up in a freezer. In a butcher's. I didn't know my own name. There was an old man in there with me who was on fire, and I drank him, because it seemed like the only way to save him. He's still here. He lives in me now. He has opinions about my coat."
? stagecraft 9 "Keep it deadpan. Never smile. Let them decide it's a bit."  -> om.truthok | om.truthno {id om_truth} {mod flag:leoJokeTested}

# om.truthok
> They decide it's a bit. The best bit of the night. By the time you get to "and now I'm on trial on Friday for eating my landlord", the front table is crying. A man at the back shouts "MORE ABOUT THE COAT."
> Leo, at the bar, has his face in his hands. He's laughing so hard he's shaking.
tenant: (somewhere in your blood, appalled and delighted) They think I'm a joke. They think I'm a JOKE. ...Oh, I don't mind. I don't mind at all.
{do flag:omResult=killed; comp+3:The set; rel:leo+2; xp:30:Open mic; lean:candour+1}
@next om.after

# om.truthno
> You smile. Just once, at the wrong moment, and they see your teeth in the warm light.
> The laughter stops. Not all at once. Table by table, like lights going off down a corridor. Forty people looking at you very carefully.
> A woman at the front says "is this... is this a performance art thing?" in a very small voice.
pedigree(7): Too much. Too close. That was a Masquerade breach in a basement bar with a two-drink minimum.
* "Yes. It's performance art. Thank you, you've been lovely."  -> om.truthsave
* Walk off. Fast.  -> om.walk

# om.truthsave
> You bow. It's a good bow. Someone claps, out of relief, and then everyone does. The host says "...okay! Performance art! Wow!" and calls the next name very quickly.
{do flag:omResult=art; heat+1}
@next om.after

# om.walk
> You walk off and up the stairs and out into the rain. Behind you, very faintly, someone says "was that real?" and someone else says "don't be stupid."
{do flag:omResult=walked; heat+1; comp-1}
@end

# om.leo
> You do Leo's set. The night shift. The freezer. "Mom, it's both." You do it slower than he does, and drier, and you put the pause in the right place.
> It kills. It absolutely kills. Twice as hard as it did for him.
> At the bar, Leo is laughing, and then he isn't.
leo: (afterwards, outside, in the rain) That was MY set. That was my set and you did it BETTER. Do you know how... I've been doing that bit for four months.
* "I'm sorry, Leo. I shouldn't have."  -> om.leo1
* "You wrote it. I just borrowed the timing. Use the pause."  -> om.leo2

# om.leo1
leo: No. No, don't be sorry. It was... it was good. It was really good. I hate it.
leo: Can you show me where the pause goes?
{do flag:omResult=leo; rel:leo+0}
@end

# om.leo2
leo: The pause. Where did you... after "Mom". Before "it's both". Huh.
leo: ...Huh. Okay. Okay. That's going to change my life, isn't it. That pause.
{do flag:omResult=leo; rel:leo+1; flag:leoPause=1}
@end

# om.sing
> You don't know what you're going to sing until you open your mouth. It's the Caruso. Séverine's gramophone. *Una furtiva lagrima.*
> You don't have Caruso's voice. You don't have anybody's voice. But you have a dead man's breath control, and two hundred years of having heard it sung properly in Naples, and in the warm light of a basement bar on Halloran Street, it comes out of you like something being let go.
> Nobody laughs. Nobody talks. When you finish, forty people sit in a silence so complete you can hear the fridge behind the bar.
> Then the woman in the cardigan starts clapping, slowly. Then everybody. {if !flag:choirHarmony}
> Then, from somewhere in the crowd, a woman in white you didn't notice stands and walks out without clapping. Choir. She heard the third in it. {if flag:choirHarmony}
{do flag:omResult=sang; comp+3:You sang; sync+2; xp:30:Open mic}
@next om.after

# om.letter
> You take a piece of paper out of your coat. You unfold it. You read, in a voice that isn't quite yours, a letter from 1961 that was never sent.
> *"...I want you to know I wasn't afraid. I want you to know it's only warm. And I want you to stop wearing those ridiculous glasses indoors."*
> You fold it up. You say "thank you". You walk off.
> There's a pause. A man at the front table, a big man in a fleece, is crying openly. He doesn't seem embarrassed. The room starts clapping, gently, the way you'd clap at a funeral if people did that.
tenant: ...You read it to strangers. In a bar. She'd have loved that. She'd have been mortified, and she'd have loved it.
{do flag:omResult=letter; comp+3; sync+3; xp:30:Open mic}
@next om.after

# om.tenant
> You step back from the microphone, inside yourself, and let him come forward.
tenant: (out loud, through your mouth, to forty people) Good evening. I have been dead since 1787 and this is the first time anyone has given me a microphone.
> Laughter. He blinks. You feel him blink.
tenant: I was the Sheriff of this neighborhood for eighty years. I never once came to this bar. I'm told the beer is dreadful. I'm told the comedian before me is related to a policeman.
> More laughter. He's warming up. Two hundred years of dinner parties.
tenant: In 1815 I won a bet on Waterloo and a man who is now a very important judge has refused to pay me for two hundred and ten years. If he's here tonight: Ambrose, you owe me forty guineas.
> It goes on for nine minutes. It's the strangest set the Lantern Room has ever seen. A dead aristocrat doing crowd work. At the end, he bows from the waist, the way nobody has bowed since the Regency.
{do flag:omResult=tenant; sync+4; comp+2; xp:30:Open mic}
@next om.after

# om.freeze
> You stand in the light. You open your mouth. Nothing comes out.
> Ten seconds. Twenty. Forty people waiting. Someone coughs.
> And then Leo is next to you on the stage, with his arm round your shoulders, grabbing the microphone.
leo: This is my mate! They're shy! They died on Monday! Big round of applause for my dead mate!
> And they laugh, and they clap, and he walks you off, and nobody knows it wasn't a bit.
{do flag:omResult=froze; rel:leo+2; comp+1}
@next om.after

# om.after
> Afterwards, outside, in the rain on Halloran Street. Leo, with his hands in his pockets, looking at you like you're a strange new kind of weather.
leo: Who ARE you? I mean... who were you? Before?
* "I don't know yet."  -> om.after1
* "Someone who's done that before, I think."  -> om.after2

# om.after1
leo: Me neither. About me, I mean. I'm thirty-four and I don't know who I am either. That's the whole act, really.
@end

# om.after2
nostalgia(6): A microphone. A stage. A room full of faces. Someone shouting your name. You've done this. Somewhere, somewhen, you stood in front of people and they listened.
@end
`,'c_openmic');
