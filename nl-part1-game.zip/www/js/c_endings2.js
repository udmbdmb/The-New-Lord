'use strict';
/* THE NEW LORD — codas, part two: last things you can say, if the week gave you the people to say them to */
(function(){const O=NL.Script.opt;
O('cd.lord','* "Leo. At the back. Come up here. Stand next to me."  -> cd2.leo {if alive:leo&flag:job_leo=platform|alive:leo&flag:leoSeenAtTribunal|flag:leoEmbraced&alive:leo}',1);
O('cd.lord','* "Dutch. Local 0. Pull up a chair. With a napkin."  -> cd2.union {if flag:side_union}',1);
O('cd.lord','* "Ambrose. Christmas Eve. The car. Bring the forty francs."  -> cd2.amb {if flag:magHeardVane}',1);
O('cd.lord','* Look for the old man at the top of the stairs. Bow to him.  -> cd2.lyon {if flag:mqOldPrince|mem:oldkin.lyon}',1);
O('cd.tenant','* Ask him, before you sleep, to go to Row J. To the front.  -> cd2.rowj {if mem:tenant.agnesstory|flag:readAgnes|flag:lt8}',1);
O('cd.tenant','* Ask him to ring a number on the coast. Just to say you\'re all right.  -> cd2.robin {if flag:sisterTalked}',1);
})();
NL.Script.add(String.raw`
# cd2.leo
> Three hundred Kindred turn round. At the back of the platform, a man in a parka over a T-shirt that says I SURVIVED THE LANTERN ROOM OPEN MIC goes the color of a fire hydrant.
leo: Me? Up... there? With... okay. Okay. Okay.
> He walks the length of Platform 0 between the Gilded Court and the Syndicate and Local 0, past the chalk, past the Magistrate's empty chair, and stops beside you. He's shaking. He doesn't stop walking until he's there.
leo: (out of the side of his mouth) What do I do now?
* "Stand there. That's all."  -> cd2.leo2

# cd2.leo2
> He stands there. Three hundred dead faces look at the Sheriff of the Marrow Ward and the mortal comedian standing next to them, and they don't understand it at all, and they never will, and that's the point.
{do flag:coda=leo; rel:leo+2}
@next end.show.lord

# cd2.union
> Dutch stares at you. Then he turns round to the sixty-three, and there's a noise from Local 0 like a football crowd, and somebody unfurls the bedsheet banner after all: WE ARE ALSO THE WARD.
> Somebody from the Gilded Court, very quietly, fetches a chair. And a napkin.
dutch: (holding the napkin like a relic) Big Sal. Big Sal, this is for you.
{do flag:coda=union; flag:unionSeat=1; keep:local0}
@next end.show.lord

# cd2.amb
> At the top of the stairs, half into the grey street, the Magistrate stops. He doesn't turn round. Three hundred Kindred watch his back.
> Then, very slightly, he lifts one hand, the way you'd lift it to a cab.
tenant: (very quietly, from inside you) He'll come. He'll come. He always comes. And he'll never pay.
{do flag:coda=ambrose; flag:magChristmas=1}
@next end.show.lord

# cd2.lyon
> At the very top of the Switchyard stairs, half in the street, an old man in a plain black mask is sitting on the step like it's a bus shelter. You look up at him over three hundred heads. You bow.
> The Court turns to see who the new Sheriff is bowing to. They see nobody. An old man on a step. They don't recognize him. Most of them were never in Lyon.
> Séverine was. She turns. She sees. Her fan stops.
{do flag:coda=lyon}
@next end.show.lord

# cd2.rowj
> He hears you. Of course he hears you. He's in your skull.
tenant: Row J. Plot 112. The front. Yes.
> The last thing you see before you sleep, through his eyes, is a hillside on the Heights in the grey before dawn, wet grass, a headstone, AGNES DUNMORE, and his own hands, which are your hands, setting a single white rose on it. Not at the gate. At the stone.
{do flag:coda=rowj; flag:tenantFront=1}
@next end.show.tenant

# cd2.robin
tenant: The coast. The fish on the mailbox. Yes. I'll ring her. I'll tell her you're asleep, which is true, and that you're all right, which is nearly true.
> The last thing you hear, very far away, through somebody else's ears: a phone ringing once, twice, and a woman's voice saying "Casey?" and a much older voice, very gently, saying: "No, Miss Morrow. A friend. They asked me to tell you they're warm."
{do flag:coda=robin}
@next end.show.tenant
`,'c_endings2');
