'use strict';
/* THE NEW LORD — "The Candle Rafts": in the cistern, Mother Soot lights a little raft for everyone the river has taken. She'll let you light some. */
(function(){NL.TASKS.s_rafts={n:'The Candle Rafts',xp:40,cat:'side'};})();
NL.Script.add(String.raw`
# rf2.0 arc=soot night=3,4,5 label="\"Mother. The candle rafts in the cistern.\"" if=alive:soot&rel:soot>=2 prio=0
@focus soot
soot: The rafts. Yes. Yes. Mm. For the drowned. Every one the river takes, Soot makes a raft. A bit of cork, a bit of wax, a wick. Mm. A hundred and eleven years of rafts.
soot: You want to make one? You know someone? Mm. Everyone knows someone, in this city. The river's very hungry.
{do task:s_rafts}
> In the cistern under the Switchyard, the black water that hasn't moved since 1911. Candle-rafts drift on it, a hundred of them, more, each a tiny circle of light with its reflection under it. The vaulted roof is gold with them.
> Soot gives you a lump of wax and a cork and a wick and shows you how, with her twig fingers. Then she gives you another. And another.
@next rf2.who

# rf2.who
soot: Who? Mm. Say the name. Then light it. Then let it go. That's all.
* Ray Dunleavy. Miller's partner. 2019.  -> rf2.ray {once} {if task:s_cold|flag:millerRayJar}
* Daniel. Margaret's son. 2014.  -> rf2.dan {once} {if flag:lampDone|seen:lp.ch}
* Rask. Pier Nine. 1977.  -> rf2.rask {once} {if mem:tenant.rask|flag:valkoAlly}
* Pyotr Rostov. The Fontanka. 1993.  -> rf2.pyo {once} {if task:s_pyotr}
* The twenty-three with crosses on Valentin's drawings.  -> rf2.roux {once} {if flag:knowRoux}
* Somebody nobody else knows. Make one for whoever's missing.  -> rf2.nobody {once}
* That's enough rafts.  -> rf2.end

# rf2.ray
> *Ray Dunleavy.* You light it. You set it on the water. It goes out slowly toward the others, turning, and settles among them as if it had always been there.
soot: Ray. Mm. The detective who said "bring the good cookies". I kept his jar. Now he's got a raft. That's both. That's good.
{do comp+1}
@next rf2.who

# rf2.dan
> *Daniel.* You don't know his surname. You light it anyway.
soot: No surname. That's all right. The river doesn't need surnames. Mm. It takes first names only.
{do comp+1}
@next rf2.who

# rf2.rask
> *Rask.* A big raft. Soot makes it bigger. She says Hounds need room.
> You light it. It goes out across the black water and somehow, though there's no current, finds its way to the far side, alone, and stays there, a little apart from the rest. Like a dog that won't come in.
soot: There. He'll keep watch. Mm. Somebody should.
{do comp+1; rel:valko+1}
@next rf2.who

# rf2.pyo
> *Pyotr.* The Fontanka isn't this river. Soot says it doesn't matter; all rivers are one river underneath.
> You light it. It sits on the water next to Ray's, two men who went out for something ordinary and didn't come back.
{do comp+1}
@next rf2.who

# rf2.roux
> Twenty-three rafts. It takes a long time. Soot doesn't help; she says each one has to be made by the person who knows. You don't know their names. You make them anyway. A boy in a football scarf. A girl with a nose ring. A young man in a graduation gown.
> When the twenty-three are on the water together, the whole cistern is brighter. You can see the mosaics on the roof for the first time: fish, and boats, and a woman with a lamp.
soot: Twenty-three. Mm. Mm. Nobody ever did twenty-three at once. You'll be tired.
{do comp+3; tick:40}
@next rf2.who

# rf2.nobody
> You make one for whoever's missing. Whoever nobody's lit one for. Whoever's on the bottom of the Vellum and doesn't have a name in anyone's jar.
soot: For nobody. That's the best one. That's the one Soot makes every night. Mm. Now you've made it too.
{do comp+2; rel:soot+1}
@next rf2.who

# rf2.end
> You sit on the stone steps of the cistern with Mother Soot and watch the rafts. Neither of you says anything. A rat climbs into your lap and goes to sleep.
{do task:s_rafts=done; xp:40:The Candle Rafts; rel:soot+1}
@end
`,'c_rafts');
NL.Script.add(String.raw`
# nb.0 arc=leo night=3,4,5 label="\"Leo. Can I read your notebook?\"" if=alive:leo&rel:leo>=3&!flag:nbRead&!flag:leoThrall prio=0
@focus leo
leo: My... the joke notebook? NO. No. Absolutely not. It's private. It's like a diary. It's worse than a diary. A diary's just sad. This is sad AND trying to be funny.
leo: ...Fine. FINE. One page. You pick. Don't laugh. Do laugh. I don't know. Here.
> A spiral-bound notebook, battered, coffee-ringed, with a sticker on the front that says COMEDY GOLD (ALLEGEDLY).
* Open it at random.  -> nb.rand
* Open it at the last page.  -> nb.last
* Open it at the first page.  -> nb.first

# nb.first
> The first page, in very careful handwriting, from years ago:
> *RULES FOR COMEDY (by Leonard Pruitt, age 22)*
> *1. Never do jokes about your mom. (Broken: 2016)*
> *2. Always end on a big one. (Broken: every gig)*
> *3. If nobody laughs, keep going. Keep going. KEEP GOING.*
> *4. Be honest. The funny bit is always the true bit.*
> Under rule 4, in newer ink: *still true.*
leo: Oh God. Twenty-two. I thought I was going to be on TV by twenty-five.
{do flag:nbRead=1; rel:leo+1; comp+1}
@end

# nb.rand
> A page from somewhere in the middle. Crossings out. Arrows. A doodle of a fox.
> *Bit about the bus — the 9 is always late because the driver is in love with the woman at the Kerr St stop and waits for her. Is this true? Ask Tariq. (Tariq says yes.) (Tariq says she's married.) (Tariq says the driver is also married.) (TOO SAD, CUT)*
leo: That's the bus bit. Everyone hates the bus bit. I love the bus bit. Nobody understands the bus bit.
{do flag:nbRead=1; rel:leo+1}
@end

# nb.last
> The last page. This week. The handwriting's faster, messier.
> *Bit: My mate is a vampire. (NO.)*
> *Bit: My mate is a "night person". (better)*
> *Bit: My mate says please to the cash machine.*
> *Bit: My mate has an old man living in their head who has opinions about my rug. (I DON'T HAVE A RUG. Get a rug? For the bit?)*
> And at the bottom, not a bit at all, small:
> *Whatever happens Friday, write it down. Somebody should.*
leo: That one's not a joke. That one's just... that one's not a joke.
{do flag:nbRead=1; rel:leo+2; comp+2}
@end
`,'c_notebook');
