'use strict';
/* THE NEW LORD — other ways in, part two: on Wednesday, the racket and the Hound can be met with what you know about the people involved, not only with fear or blood */
(function(){const O=NL.Script.opt;
O('rk.hub','* Look past Dale, at the other one. "Officer Pruitt. Your nephew works nights at the butcher\'s."  -> pp.nephew {once} {if flag:knowPruittNephew}','start');
O('rk.hub','* "Detective Miller\'s on her way. She asked me to keep you here."  -> pp.miller {once} {if rel:miller>=2}','start');
O('rk.hub','* "Tariq. Show them the calendar. The one your father wrote on."  -> pp.calendar {once} {if rel:tariq>=3}','start');
O('rk.hub','* Buy a coffee. Stand at the counter. Say nothing. Wait them out.  -> pp.wait {once} {if rep:restraint>=2}','start');
})();
NL.Script.add(String.raw`
# pp.nephew
> Pruitt's coffee stops halfway to his mouth. Dale doesn't notice. Dale's counting.
pruitt: ...What did you say?
* "Leo. Third floor of the Rookery. He does stand-up on Tuesdays. He's terrible. He'd be ashamed of you."  -> pp.neph2
* "I said nothing. I'm sure your sister's very proud."  -> pp.neph3

# pp.neph2
> Pruitt looks at the cup. He looks at Dale. He looks at Tariq, who has stopped pretending to restock the cigarettes.
pruitt: Dale. Put it back.
dale: You what?
pruitt: Put the money back. In the till. We're done here. Done with this shop.
dale: Ken, have you lost your...
pruitt: PUT IT BACK.
> Dale puts it back. He looks at his partner like a man who's just found out his dog can talk. They go out into the rain, Dale first, Pruitt slower. At the door Pruitt stops and doesn't turn round.
pruitt: Don't tell him. Leo. Don't tell him I was here.
{do flag:racketDone=nephew; task:s_tariq=done; rel:tariq+2; xp:40:Wednesday; flag:pruittShamed=1; lean:candour+1}
@next rk.end

# pp.neph3
pruitt: ...How do you know my sister?
dale: Ken. Ken. Focus.
> Pruitt doesn't focus. He's thinking about a woman in Scranton who makes stew for every crisis.
pruitt: Let's go, Dale. Let's just... let's leave it this week.
{do flag:racketDone=nephew; task:s_tariq=done; rel:tariq+1; xp:30:Wednesday; flag:pruittShamed=1}
@next rk.end

# pp.miller
dale: Miller. Ines Miller. From Missing Persons. Coming HERE.
? stagecraft 10 "Two minutes out. She's got a body cam. She said, and I quote, 'finally'."  -> pp.millerok | pp.millerno {id pp_mil}

# pp.millerok
> Dale goes the color of the coffee. The money goes back in the till so fast it rips. They're out of the door and in the car and gone before Tariq has closed his mouth.
tariq: Is she... is she coming?
* "No."  -> pp.millerno2

# pp.millerno2
tariq: No. Of course not. Ha. HA. Oh, that was beautiful. Do it again next week.
{do flag:racketDone=bluff; task:s_tariq=done; rel:tariq+2; xp:30:Wednesday; lean:candour-1}
@next rk.end

# pp.millerno
dale: Miller. Sure. And I'm the Pope. She got moved to cold cases, pal. She's in a basement with a box of Ray Dunleavy's socks.
@next rk.hub

# pp.calendar
> Tariq looks at you. Then he takes the 2014 calendar down from behind the counter and holds it out to Dale, turned to the page where his father's handwriting is. A phone number, and a name, and a word in Urdu.
tariq: My father wrote this in 2014. The number of the man who sold him this shop. And the word means "patience". He paid you every week for nine years with patience.
tariq: I don't have his patience. I'm sorry. No more.
? velvet 11 "He's done paying. Find somewhere else. There's a lot of shops."  -> pp.calok | pp.calno {id pp_cal} {mod like:tariq}

# pp.calok
> Dale looks at the calendar. Then at Tariq. Something in his big red face, under all the years, flinches.
dale: ...Your old man was all right. He used to give me a Mars bar. Every week. Like I was a kid.
dale: Fine. Fine. Whatever. Ken, come on.
{do flag:racketDone=calendar; task:s_tariq=done; rel:tariq+3; xp:40:Wednesday; lean:mercy+1}
@next rk.end

# pp.calno
dale: Patience. Great. Patience is sixty a week, same as everything else.
@next rk.hub

# pp.wait
> You buy a coffee. You stand at the counter with it, not drinking it, between Dale and the till. You don't look at him. You don't say anything. You stand there with the patience of something that has stood in a freezer for three hours without moving.
> One minute. Five. Ten. Dale tries to talk. You don't answer. Pruitt goes to the door twice and comes back. The coffee goes cold in your hand.
rigor(5): Stillness. It's what you're best at now. You could stand here until morning.
? rigor 9 "Don't move. Don't blink. Let them break."  -> pp.waitok | pp.waitno {id pp_wait}

# pp.waitok
> At twenty-two minutes Dale breaks. He says "this is weird, man, this is really weird," to nobody, and puts the money back, and leaves. Pruitt follows. At the door he looks back at you as if you're a statue that's moved.
tariq: You just... stood there.
* "Sometimes that's all it takes."  -> pp.waitend

# pp.waitend
{do flag:racketDone=wait; task:s_tariq=done; rel:tariq+2; xp:40:Wednesday; lean:restraint+1; tick:20}
@next rk.end

# pp.waitno
> At eight minutes you blink. Dale laughs.
dale: Thought you were a mannequin for a second. Freaky. Anyway.
@next rk.hub
`,'c_paths2');

/* the Hound: what you've learned can be said to him too */
(function(){const {L,T,C,ENC}=NL.DSL;if(!ENC.hound)return;const mv=ENC.hound.moves;
ENC.hound.moves=function(st,S,G){const M=mv.call(this,st,S,G);
  if(G.remembers('tenant','agnes')||S.flags.knowAgnesGrave)M.push({t:'"He stood at the back of Agnes Dunmore\'s funeral in the snow, and never went in. You drove him."',once:'vk_agnes',ok:st=>{st.prog+=2;return [L('valko','...The Heights. 1961. He made me wait at the gate with the engine running. He came back with snow on his glasses and didn\'t speak for a week.'),L('valko','Nobody knows that. Nobody but me.')];}});
  if(S.flags.knowHarrowWar||S.flags.knowLantern)M.push({t:'"The man who killed him smokes menthols and says please. You\'ve smelled him on the pier."',once:'vk_harrow',ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [T('His nostrils flare. Something old and terrible moves behind his amber eyes.'),L('valko','Menthol. Yes. On Pier Nine. In 1977. And again, on Monday, at Kowalski\'s back door.')];}});
  if(S.clan==='hounds')M.push({t:'Drop to a crouch. Bare your throat. The old way, Hound to Hound.',once:'vk_clan',ok:st=>{st.prog+=2;st.threat=Math.max(0,st.threat-2);return [T('He stops dead. He looks at your throat, offered, and at your eyes, which are a Hound\'s eyes now whether you like it or not.'),L('valko','...Pack-blood. In his killer. Of course. Of course it is.')];}});
  if(S.feeds===0||S.kills===0&&S.night>=3)M.push(C('pulse',8,'"Smell me, Valko. I haven\'t killed anyone. Not even him. He was already burning."',null,null,{id:'vk_clean',once:'vk_clean',ok:st=>{st.prog+=2;return [L('valko','...No death on you. None. Only his. And his is... old. Burnt. Before you.'),T('He sits back on his heels, very slowly.')];},no:st=>{st.threat+=1;return [L('valko','Everyone smells of death, thief. Everyone.')];}}));
  return M;};})();
