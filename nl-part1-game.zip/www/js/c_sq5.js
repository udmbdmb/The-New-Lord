'use strict';
/* THE NEW LORD — side quests, set five: "Confession" (Father Dominic, the hospital chaplain who knows), "The Fight Card" (Tiny's brother in the Reliquary cellar), "Leo's Mother" (a visitor on Halloran Street) */
(function(){
const X=NL.EXTRAS,S_=NL.Script;
X.dominic={n:'Father Dominic',color:'#c8c0a8',role:'Hospital chaplain, St. Jude\'s',spec:{face:{long:1.06,cheek:1.1,jaw:1.2},skin:[.78,.66,.58],hair:{style:'short',color:[.55,.55,.55]},coat:{color:[.06,.06,.07],length:.8,collar:true},shirt:[.06,.06,.07],eyes:[.4,.5,.6],height:1.02}};
X.marcus={n:'Marcus',color:'#d0a070',role:'Tiny\'s little brother',spec:{face:{long:.98,cheek:1.2,jaw:1.4},skin:[.42,.3,.24],hair:{style:'buzz',color:[.05,.04,.04]},shirt:[.85,.85,.85],pants:[.15,.15,.18],height:1.06,bulk:1.25}};
X.vossler={n:'Vossler',color:'#b0b860',role:'Fight promoter, a ghoul',spec:{face:{long:1.02,cheek:1.0,jaw:1.1},skin:[.82,.72,.64],hair:{style:'slick',color:[.75,.6,.3]},coat:{color:[.45,.4,.15],length:.6,collar:false},shirt:[.1,.1,.1],eyes:[.6,.55,.2]}};
X.rosa={n:'Rosa Pruitt',color:'#e8b0a0',role:'Leo\'s mother',spec:{face:{long:1.0,cheek:1.3,jaw:1.0},skin:[.86,.74,.68],hair:{style:'bun',color:[.55,.42,.32]},coat:{color:[.55,.3,.3],length:.7,collar:true},shirt:[.8,.75,.7],height:.94}};
Object.assign(NL.TASKS,{s_confess:{n:'Confession',xp:70,cat:'side'},s_fight:{n:'The Fight Card',xp:70,cat:'side'},s_rosa:{n:'Leo\'s Mother',xp:60,cat:'side'}});
Object.assign(NL.ITEMS,{
  dominiclist:{n:'Father Dominic\'s Notebook',type:'read',d:'A black notebook in a priest\'s neat hand. Thirty years of names: patients who died with two small wounds, nurses who quit on night shift, a Sheriff who sat in the chapel every December. A careful man has been counting the dead.'},
  rosary:{n:'A Wooden Rosary',slot:'pocket',mods:{nostalgia:1,rigor:1},d:'Plain olive wood, worn smooth. It doesn\'t burn you. You\'re not sure if that means something about you, or about God.'},
  fightpurse:{n:'A Fat Brown Envelope',type:'read',d:'The night\'s takings from the Reliquary cellar. Somebody is going to want this back.'}
});
S_.place({id:'chapel',name:'The Chapel at St. Jude\'s',block:'B',sub:'Ground floor, past the vending machines. Open all night for the dying and the people who love them.',if:'night>=2&night<=5&flag:mapOK&!flag:dominicGone',node:'dm.0',min:8});
S_.place({id:'cellar',name:'The Reliquary Cellar',block:'B',sub:'Under the club. Thursday fight night. Cash only. Bring your own towel.',if:'night:4&flag:mapOK&task:s_fight=active&!flag:fightDone',node:'fg.cellar',min:6});
})();
NL.Script.add(String.raw`
// =====================================================================
// CONFESSION · Father Dominic
// =====================================================================
# dm.0
@gate flag:metDominic ? dm.again : dm.first

# dm.first
> A narrow room with eight pews, a plywood altar, an electric candle that flickers because the bulb is cheap. Somebody has left a child's drawing of a sun pinned to the noticeboard.
> In the front pew, a priest in his sixties is eating a sandwich out of foil and doing the crossword. He doesn't look up.
dominic: Seven letters. "One who has gone before." Second letter R.
* "Ancestor."  -> dm.cross1
* "Forerunner. No, that's ten."  -> dm.cross1
* Say nothing.  -> dm.silent

# dm.cross1
dominic: Ancestor. Yes. Thank you. Sit down if you like. Nobody comes in here at this hour who doesn't need to sit down.
{do flag:metDominic=1}
@next dm.look

# dm.silent
> You stand at the back. He finishes the crossword in pen. He folds the foil into a neat square and puts it in his pocket.
dominic: You can sit, you know. It's not a trap. The building's consecrated but the pews are from IKEA.
{do flag:metDominic=1}
@next dm.look

# dm.look
> He looks at you properly for the first time. He has very pale eyes, very tired. He looks at your face, and at your hands, and at the absence of breath fogging in a room with a broken radiator.
pulse(6): His heart skips. One beat. Then it settles, steady as a man laying bricks. He knows exactly what you are. He has seen it before.
dominic: Ah. You're new. I can always tell the new ones. You still check the doors.
* "You know what I am."  -> dm.know
* "I'm a visitor. My friend's on the third floor."  -> dm.lie {do lean:candour-1}
* Move closer. He's alone. It's late.  -> dm.hungry {if vitae<=6}

# dm.know
dominic: I've been chaplain at St. Jude's for thirty-one years. On nights. Do you know how many people die on the night shift with two little holes nobody can explain? Nobody else counts them. I count them.
dominic: And there's a man who used to come and sit in that pew every December. Very tall. Dark glasses, even indoors. He'd stay until the window started to go grey. He never prayed. He'd just sit.
tenant: ...I didn't think he'd noticed me. I was always so careful.
dominic: He stopped coming this year. And now there's you, with his walk.
@next dm.hub

# dm.lie
dominic: Of course. Third floor. That's Oncology. Very good of you to visit at three in the morning.
dominic: I'm sixty-three years old and I have sat with eleven thousand dying people. I know what a living face looks like when it's worried about someone. You're not worried. You're hungry.
dominic: It's all right. Sit. I'm not going to scream. I'm too old to scream, and it upsets the patients.
@next dm.know

# dm.hungry
> You take a step down the aisle. Then another. The electric candle flickers.
> He doesn't move. He takes a small glass bottle out of his jacket and puts it on the pew beside him, like a man putting his car keys on a table.
dominic: Holy water. Tap water, really, but I said the words over it. I've never had to find out if it works. I'd rather not find out tonight. Would you?
frenzy(5): A sixty-three-year-old man in an empty room. A bottle of tap water. He's BLUFFING. You could be on him before he got the cork out.
? rigor 10 "Stop. Sit down. Talk to him."  -> dm.know | dm.attack {id dm_hold}

# dm.attack
> The hunger has you before you decide anything. The pew goes over. The bottle goes over. Water on the lino, harmless, steaming faintly where it touches your shoe. He doesn't fight. He says "oh, my dear" quite softly, as if you'd dropped something.
* Drink. Stop when his heart slows.  -> dm.drink {blood}
* Drink everything.  -> dm.kill {blood}

# dm.drink
> Old blood. Tea and cheap sandwiches and something else, something bright and clean that makes your teeth ache. You stop. You make yourself stop.
> He's on the floor between the pews with his collar askew. He looks up at you without any fear at all.
dominic: There. Now we've both done something we're ashamed of. That's how most confessions start.
{do feed:3:Choleric:Father Dominic:mortal; flag:fedDominic=1; lean:restraint-1; rel:dominic-1}
@next dm.hub

# dm.kill
> You don't stop. The bright clean thing in his blood burns all the way down and you don't stop. When he goes, he goes saying a name you don't know. Somebody he loved, a long time ago.
> In his pocket: the foil from his sandwich, folded into a neat square. A notebook. A wooden rosary.
{do feed:5:Choleric:Father Dominic:mortal; kill; flag:dominicDead=1; flag:dominicGone=1; give:dominiclist; give:rosary; lean:mercy-2}
tenant: Thirty-one years he counted the dead. And now he is one of them, and nobody will count him.
@end

# dm.again
> Father Dominic, front pew. A fresh crossword. A thermos of tea. He lifts a hand without looking up.
dominic: The night visitor. Sit. Sit.
@next dm.hub

# dm.hub
* "Will you hear my confession?"  -> dm.conf {once} {if !task:s_confess=done}
* "What do you know about the man in dark glasses?"  -> dm.vane {once}
* "The dead on the night shift. Who's doing it?"  -> dm.count {once}
* "Who else knows what you know?"  -> dm.who {once} {if seen:dm.count}
* "Do you believe I have a soul?"  -> dm.soul {once}
* "Pray for someone for me."  -> dm.pray {once} {if night>=3}
* "Father. There are men coming. Federal men. Leave the city."  -> dm.warn {once} {if night>=4&flag:knowLantern}
* Leave him to his crossword.  -> dm.bye {leave}

# dm.vane
dominic: Every December. Always the twenty-third, the night before Christmas Eve. I asked him once, the third year, who he was mourning.
dominic: He said, "A woman who died in 1961 who would have hated this chapel. She thought church was for people who'd run out of better ideas."
dominic: And then he laughed. I've never heard a sadder laugh. And he said, "She was right. Here I am."
tenant: ...Agnes. December twenty-third. The night we met. It was snowing on the Heights and she threw a snowball at my car.
{do mem:tenant:dominicvane; sync+1}
* "He's dead. In a way. He's in me."  -> dm.vanein
* "He's dead."  -> dm.hub

# dm.vanein
> Father Dominic takes his glasses off and cleans them on his cassock, which makes them dirtier.
dominic: In you. Like a lodger.
dominic: I suppose that's not so strange. The faithful have been saying for two thousand years that the dead live in us. You've just been unusually literal about it.
@next dm.hub

# dm.count
> He takes a black notebook out of his inside pocket. It's soft with handling.
dominic: Two hundred and nine names in thirty-one years. Most of them are what you'd expect. A drunk in a doorway. A homeless man. A girl from a club who "fell asleep in the cold". Six, seven a year. Steady. Somebody's always hungry.
dominic: But this year it changed. This year there are seven names from one week in October, all from the same ward, all from a *study*. Fourth floor. Dr. Rostova's floor.
{do fact:dominic:seven; flag:dominicSeven=1}
web(7): Seven. A study on the fourth floor. LANTERN's seven mortals. Dominic has been counting them without knowing what he was counting.
* "Can I see the notebook?"  -> dm.book
* "Have you told anyone?"  -> dm.who

# dm.book
dominic: You can read it. You can't have it. It's the only record some of these people will ever have.
? autopsy 9 "Read the seven entries carefully. Look for a pattern."  -> dm.bookok | dm.bookno {id dm_book}

# dm.bookok
> Name, age, date, cause. *Cardiac arrhythmia. Cardiac arrhythmia. Cardiac arrhythmia.* All seven between 4:00 and 4:30 AM. All seven with the same note in his hand, underlined twice: *skin very warm. Warm after death. Two hours after.*
autopsy(9): Warm after death. Their bodies were trying to make heat they couldn't hold. Whatever was put in them was burning them from the inside, the way the dawn burns you.
{do fact:dominic:warm; flag:sevenWarm=1; xp:20:Warm after death}
@next dm.hub

# dm.bookno
> Names, ages, dates. His handwriting gets smaller as the year goes on, as if he's running out of room.
@next dm.hub

# dm.who
dominic: I wrote to the Bishop in 2004. He sent me on a retreat. I wrote to the police in 2011, about a boy from Halloran Street. A detective came. Very kind. He said it was a mugging.
dominic: And on Tuesday, a man came. A nice man in a brown coat, with peppermints. He said he was from the Department of Health and could I possibly lend him my notebook for a few days.
web(6): Harrow. Already here. Already asking.
dominic: I told him I'd lost it. It's the first lie I've told in nine years. I enjoyed it more than I should have.
* "He'll come back. When he does, give it to him. It's not worth your life."  -> dm.give {do lean:mercy+1}
* "Never give it to him. Whatever he says."  -> dm.keep
* "Give it to me instead. I'll keep it safer than you can."  -> dm.take

# dm.give
dominic: My life. Yes. You'd know about that, I suppose, being on the other side of it.
dominic: All right. If he comes back, I'll give him the notebook. And I'll make a copy first, by hand, tonight, and post it to the Bishop. Let him send *that* on a retreat.
{do flag:dominicSafe=1; rel:dominic+1}
@next dm.hub

# dm.keep
dominic: Good. No. I didn't intend to. But thank you for saying it. It's nice when the devil agrees with you.
{do flag:dominicDefiant=1; rel:dominic+1; lean:pride+1}
@next dm.hub

# dm.take
dominic: Safer. With you.
? velvet 11 "With me. Nobody looks in a dead man's pockets."  -> dm.takeok | dm.takeno {id dm_take} {mod like:dominic}

# dm.takeok
> He looks at the notebook for a long time. Then he hands it to you, and keeps his hand on it a moment after you've taken it, like a man passing on a baby.
dominic: Two hundred and nine. Don't lose any of them.
{do give:dominiclist; flag:haveDomList=1; flag:dominicSafe=1; rel:dominic+1}
@next dm.hub

# dm.takeno
dominic: No. I'm sorry. I've known you for twenty minutes. I've known them for thirty-one years.
@next dm.hub

# dm.soul
> He considers the question properly. He takes his time. You get the impression he's been asked it before, and has never given the same answer twice.
dominic: I believe that you came into a chapel at three in the morning, when you could have been anywhere else in the city, and asked a tired old man if you have a soul.
dominic: I don't think things without souls ask that question. I think they just eat.
* "That's not an answer."  -> dm.soul2
* "...Thank you."  -> dm.hub {do comp+2}

# dm.soul2
dominic: No. It's a priest's answer. They're never answers. That's why people keep coming back.
@next dm.hub

# dm.pray
dominic: For whom?
* "For Leo Pruitt. He's a comedian. He's not very good."  -> dm.prayleo {if alive:leo}
* "For Dani Okafor."  -> dm.praydani {if flag:met404}
* "For the seven."  -> dm.prayseven {if flag:dominicSeven}
* "For Absalom Vane."  -> dm.prayvane
* "For me."  -> dm.prayme

# dm.prayleo
> He bows his head. He prays out loud, plainly, the way you'd ask a neighbor to keep an eye on your house.
dominic: Lord, look after Leo Pruitt, who's a comedian and isn't very good. Let him be a bit better. Let him have a decent crowd on a Tuesday. Amen.
{do comp+2; rel:dominic+1}
@next dm.hub

# dm.praydani
dominic: Lord, for Dani Okafor, who her mother is still waiting up for. Wherever she is now, let her be warm. Amen.
nostalgia(5): *Feed the fish.*
{do comp+2; rel:dominic+1}
@next dm.hub

# dm.prayseven
dominic: For the seven on the fourth floor, who signed a form because they needed four hundred dollars, and who were warm two hours after they died. Lord, let somebody answer for it. Amen.
{do comp+2; rel:dominic+1; lean:mercy+1}
@next dm.hub

# dm.prayvane
dominic: Lord, for the man in the dark glasses who sat at the back every December. Let him find his Agnes. Let him be allowed in. Amen.
tenant: ...Amen.
> You didn't say it. You felt it said, in your throat, in a voice older than yours.
{do sync+2:Amen; comp+2}
@next dm.hub

# dm.prayme
> He looks at you with those pale tired eyes.
dominic: I don't know your name.
* Tell him your name.  -> dm.prayname {if flag:knowName}
* "Neither do I."  -> dm.praynoname

# dm.prayname
dominic: Lord, for Casey Morrow, who has forgotten a great deal and remembered the thing that matters, which is to ask. Amen.
{do comp+3:Somebody prayed for you; rel:dominic+2}
@next dm.hub

# dm.praynoname
dominic: Lord, for this one, whose name I don't know and who doesn't know it either. You know it. That'll have to do for both of us. Amen.
{do comp+3:Somebody prayed for you; rel:dominic+2}
@next dm.hub

# dm.warn
dominic: Leave. My chapel. My eleven thousand. Because some men in suits might be coming.
dominic: My dear. I've buried better reasons than that.
? velvet 12 "If you stay, you're one more name in somebody else's notebook."  -> dm.warnok | dm.warnno {id dm_warn} {mod like:dominic}

# dm.warnok
dominic: ...One more name. Yes. Who'd count me?
> He takes his glasses off.
dominic: My sister has a cottage in Wexford. She's been asking me to visit since 1997. I'll go on Friday. I'll take the notebook. I'll come back when it's over, if there's anything to come back to.
{do flag:dominicWexford=1; flag:dominicSafe=1; rel:dominic+1}
@next dm.hub

# dm.warnno
dominic: No. I'm sorry. Thank you. But no. Somebody has to sit with the dying on Friday night, and it's not going to be the Department of Health.
{do flag:dominicStays=1}
@next dm.hub

# dm.conf
> He moves along the pew. There's no booth. There's never been a booth. Just a tired man in a cassock, a bad electric candle, and the radiator ticking.
dominic: Go on, then. In your own words. I don't need the Latin. God's had enough Latin.
{do task:s_confess; note:s_confess|Father Dominic will hear a confession from anything that asks. What you tell him is up to you.}
* Tell him about the freezer. All of it.  -> dm.c_freezer
* Tell him about the people you've fed on.  -> dm.c_feed {if feeds>=1}
* Tell him about the people you've killed.  -> dm.c_kill {if kills>=1}
* Tell him about a promise you broke.  -> dm.c_break {if broke}
* Tell him something that isn't true, to see what he does.  -> dm.c_lie {do lean:candour-1}
* "I can't. I'm sorry."  -> dm.c_cant

# dm.c_freezer
> You tell him. The freezer. The lance. The light at 4:14. Harrow in the doorway. The old man burning from the front, kneeling, and you, with your mouth on his throat, drinking, because it was the only way to save anything at all.
> He doesn't interrupt. When you finish, the radiator has stopped ticking. You've been talking for forty minutes.
dominic: Did you want to?
* "No."  -> dm.c_fr_no
* "Yes. Part of me wanted to."  -> dm.c_fr_yes {do lean:candour+1}
* "I don't know."  -> dm.c_fr_dk

# dm.c_fr_no
dominic: Then it isn't murder. It's something sadder. It's what happens when somebody grabs the only hand in the room.
{do comp+3; tick:40}
@next dm.absolve

# dm.c_fr_yes
dominic: Thank you. That's the first honest thing anyone's said in this room since Easter.
dominic: Part of you wanted to. Part of everybody wants things. The whole of you stopped and asked a priest whether it was wrong. Hold onto the whole.
{do comp+4; tick:40; rel:dominic+1}
@next dm.absolve

# dm.c_fr_dk
dominic: Nobody ever does. That's why it's called confession and not an exam.
{do comp+3; tick:40}
@next dm.absolve

# dm.c_feed
> You tell him about the necks and the wrists. The man on the bench who said "Mom?" in his sleep. The girl in the club who laughed. How warm. How good. How you think about it in the day, in the box, in the dark.
dominic: Did any of them die?
@gate kills>=1 ? dm.c_feeddie : dm.c_feedno

# dm.c_feeddie
* "Yes."  -> dm.c_kill
* "...No. Not those ones."  -> dm.c_feedno

# dm.c_feedno
dominic: Then you've taken from people without asking, and you've given them back their lives. That's not innocence. But it's a long way from the other thing.
dominic: Most of the people who sit in this pew have done worse to people they love, sober, in daylight, for less reason.
{do comp+2; tick:25}
@next dm.absolve

# dm.c_kill
> You tell him their faces. Not their names. You don't know most of their names.
> He listens. At some point he takes your cold hand in his warm one, and you let him, and you don't know when it happened.
dominic: How many?
* Tell him the truth.  -> dm.c_killtrue {do lean:candour+1}
* Tell him fewer.  -> dm.c_killfew {do lean:candour-1}

# dm.c_killtrue
dominic: ...Then you have a great deal to carry. I can't take it off you. Nobody can. That's not what this is for.
dominic: What I can do is tell you that you can stop. Tonight. You can be a creature that *has* killed. You don't have to be a creature that *kills*. The tense matters. It's the only thing that does.
{do comp+3; tick:30; rel:dominic+1; flag:dominicTense=1}
@next dm.absolve

# dm.c_killfew
> He looks at you for a long moment. He doesn't say anything. He just keeps holding your hand, and you know, the way you know the sun is coming, that he knows the number is wrong.
dominic: All right.
{do tick:20}
@next dm.absolve

# dm.c_break
dominic: To whom?
> You tell him. He nods.
dominic: Can you mend it?
* "Maybe. I don't know."  -> dm.c_brk2
* "No. It's too late."  -> dm.c_brk3

# dm.c_brk2
dominic: Then that's your penance. Not ten Hail Marys. Go and find out.
{do comp+2; tick:15}
@next dm.absolve

# dm.c_brk3
dominic: Then remember it. Forever, which in your case is quite a long time. Let it make you careful.
{do comp+1; tick:15}
@next dm.absolve

# dm.c_lie
> You tell him something terrible that you never did. You make it vivid. You watch his face.
> His face doesn't change at all.
dominic: Mm. And now the real one?
stagecraft(6): He's been lied to by murderers, addicts, husbands and children for thirty-one years. You never had a chance.
* Tell him the freezer.  -> dm.c_freezer
* Laugh. "You're good."  -> dm.c_lielaugh

# dm.c_lielaugh
dominic: I'm adequate. I've had practice. Come back when you want to do it properly.
@next dm.hub

# dm.c_cant
dominic: That's all right. Sometimes the confession is just sitting here not saying it. I'll sit with you.
> You sit together in the bad light. You don't say anything. Neither does he. After a long time he hums something, very quietly, a hymn you half-know from somewhere you can't remember.
{do comp+2; tick:30}
@next dm.hub

# dm.absolve
> He makes the sign of the cross over you. You brace for it to burn.
> It doesn't burn. It's just an old man's hand moving in the air, and a word in Latin he said he wouldn't use.
@gate kills>=3 ? dm.abs_heavy : dm.abs_light

# dm.abs_heavy
> Something does happen. Not fire. A weight, settling on your shoulders, very gently, like a coat put on you by somebody who thinks you're cold.
tenant: The Church used to burn us. In Marseille, in 1720, they burned three of us in the square. And now a priest in a plywood chapel blesses you and nothing burns at all. I don't know if that means God has changed his mind, or that he never had one.
{do task:s_confess=done; xp:70:Confession; comp+2; give:rosary; flag:confessed=1}
dominic: Take this. It was my mother's. Don't argue. I've got eleven.
@end

# dm.abs_light
> Nothing happens. Nothing at all. And it's the nothing that undoes you. You expected to burn.
dominic: There. That's it. That's all it ever is. You'd be amazed how many people are disappointed.
{do task:s_confess=done; xp:70:Confession; comp+3; give:rosary; flag:confessed=1}
dominic: Take this. It was my mother's. Don't argue. I've got eleven.
@end

# dm.bye
dominic: God bless. Mind the step, it's loose. It's been loose since 1994.
@end

// Dominic at the vigil / fates
# dmV.0 arc=tenant night=5 label="\"Father Dominic.\"" if=flag:confessed&!flag:dominicDead&!flag:dominicWexford&!seen:dmV.0 prio=-1
@focus tenant
tenant: The priest. He's staying, isn't he. In his chapel. On Friday. With the vans on the street.
tenant: I sat in his chapel for nineteen Decembers and I never once told him my name. I would like, before dawn, if there's time, for somebody to tell him.
{do flag:wantTellDominic=1}
@end

// =====================================================================
// THE FIGHT CARD · Tiny's brother
// =====================================================================
# fg.0 arc=tiny night=3,4 label="\"Tiny. You look like you haven't slept.\"" if=room:reliquary&!flag:tinyBetrayed&!flag:tinyGone prio=1
@focus tiny
> Tiny's on the door, same as always, but his hands won't keep still. He keeps checking his phone. He keeps putting it away.
tiny: I don't sleep. I'm a doorman. Doormen sleep in the daytime like you lot.
tiny: ...It's my brother. Marcus. He's nineteen. He's got himself on Vossler's card for Thursday.
* "Vossler?"  -> fg.voss
* "The card?"  -> fg.voss

# fg.voss
tiny: Vossler runs fights in the cellar on Thursdays. Bare knuckle, cash, two hundred people in a room built for forty. Been going since the nineties. The Court lets him because the Court likes to watch.
tiny: Marcus thinks he's going to make enough on Thursday to get Mom out of the apartment on Kerr Street. He's fighting a lad called Brick. Brick's been on the card six times. Brick doesn't lose.
tiny: Brick doesn't lose because Brick drinks what's in Vossler's flask before every fight. And Vossler drinks what's in Lisette's wrist.
pedigree(6): A ghoul's ghoul. Two removes from Kindred blood. Strong enough to put a fist through a door, not enough to know when to stop.
tiny: Marcus doesn't know. I can't tell him. If I tell him, he'll fight anyway, to prove he's not scared. He's nineteen.
{do task:s_fight; note:s_fight|Tiny's brother Marcus is fighting Brick on Thursday's card in the Reliquary cellar. Brick is a ghoul, two removes from Kindred blood, and he doesn't lose.}
* "I'll talk to Vossler."  -> fg.planv
* "I'll talk to Marcus."  -> fg.planm
* "I could give Marcus something of his own. A taste."  -> fg.planb {do lean:restraint-1}
* "Let him fight. He's a grown man."  -> fg.planno

# fg.planv
tiny: Vossler. He's a slimy bastard but he's a businessman. Everything's for sale. He's in the cellar from eleven on Thursday setting up.
{do flag:fightPlan=voss}
@end

# fg.planm
tiny: Marcus. He'll be at the gym on Kerr Street till ten, then he comes here. He won't listen to me. He might listen to someone scary.
{do flag:fightPlan=marcus}
@end

# fg.planb
> Tiny's face goes very still.
tiny: A taste. Of you. So my baby brother can go in there with your blood in him and put Brick through the wall.
tiny: And then what? Then he's like Brick. Then he needs it. Then he's Vossler's, or yours, or whoever's got the flask.
* "Then he's mine. I'll look after him."  -> fg.planb2 {do lean:pride+1}
* "You're right. Forget I said it."  -> fg.planm

# fg.planb2
tiny: ...I don't know. I don't know. Let me think about it. Don't do anything till I've thought about it.
{do flag:fightPlan=blood; rel:tiny-1}
@end

# fg.planno
tiny: A grown man. He's NINETEEN. He still sleeps with the landing light on.
tiny: ...Fine. Fine. I'll be there. I'll be standing at the back watching my brother get his head caved in, and you'll be wherever you are. Thanks.
{do rel:tiny-2; flag:fightPlan=none}
@end

# fg.cellar
> The cellar under Club Reliquary: brick vaults, bare bulbs, the smell of sweat and sawdust and spilled beer. Two hundred people in a space meant for forty. A ring of rope tied between four scaffolding poles.
> Up on a crate by the far wall, counting cash into a cash-box, a man in a mustard-colored coat with hair the color of brass.
@gate flag:fightPlan=marcus ? fg.mfirst : fg.cellar2

# fg.cellar2
* Find Vossler.  -> fg.v0
* Find Marcus.  -> fg.m0
* Find Brick.  -> fg.b0
* Find a spot at the back and watch.  -> fg.watch

// --- Vossler ---
# fg.v0
vossler: Ah, ah, ah. A new face. And not a living one, by the look. Welcome, welcome. Betting's at the bar. House takes fifteen. Who are you backing, friend? Brick's two to nine.
* "Pull Marcus off the card."  -> fg.vpull
* "What's in the flask, Vossler?"  -> fg.vflask
* "I want to bet on Marcus. Everything I've got."  -> fg.vbet {if cash>=100}
* "How much to fix it?"  -> fg.vfix

# fg.vpull
vossler: Pull him. Pull my main event. Two hundred tickets sold on the kid's face, the kid's story. Poor boy, sick mom, big brother on the door. They love it. You can't buy that.
vossler: I could replace him, I suppose. With you. A Kindred on the card. That'd sell out the next six months.
* "Fine. Put me in against Brick."  -> fg.vme {do lean:pride+1}
? apex 11 "You'll pull him. Or I'll pull your arms off."  -> fg.vapex | fg.vapexno {id fg_apex} {red}
? velvet 12 "Lisette knows you're watering her blood with gin. How long before she finds out how much?"  -> fg.vvel | fg.vvelno {id fg_vel} {if flag:metLisette|seen:ls.0}

# fg.vme
vossler: Oh. Oh, that's... yes. Yes! Ladies and gentlemen, a CHANGE to the card! I love you. I genuinely love you. Go and get changed. Well, don't get changed. Go as you are. The coat's good. The coat's very good.
{do flag:fightMe=1}
@next fg.mefight

# fg.vapex
> You let him see what you are for one second. Just one. The thing behind your face.
> He drops the cash-box. Coins everywhere. Nobody in the cellar notices; they're too busy shouting.
vossler: Pulled. He's pulled. He's pulled! Brick gets a walkover. Nobody's happy. I'm not happy. Please put your face back.
{do flag:marcusPulled=1; heat+1}
@next fg.pullres

# fg.vapexno
vossler: Ooh. Scary. Very scary. You know who else is scary? Lisette. Who drinks for free from my takings every Thursday. Threaten me again and I'll tell her you tried to muscle in. See how scary she finds you.
@next fg.cellar2

# fg.vvel
> His smile freezes. His eyes go very quickly to the bar, where a woman in red is not, tonight, sitting.
vossler: ...I don't know what you're talking about. And I'll pull the kid. For no reason. Because I'm a generous man.
{do flag:marcusPulled=1; flag:vosslerOwes=1}
@next fg.pullres

# fg.vvelno
vossler: Gin? In Lisette's? Do I look suicidal? Go and bet or go and leave.
@next fg.cellar2

# fg.vflask
> He pats his coat, where something heavy sits.
vossler: Tonic. For the boys. Keeps the bones knitting. It's all very medical.
pedigree(7): A hip flask with a little red ribbon on it. The ribbon is Lisette's. It means: property of the Gilded Court. He's selling the Court's blood to mortals by the sip and paying the Court in cash.
* "Give me the flask."  -> fg.vflask2
* "Does Lisette know how much you skim?"  -> fg.vvel {if flag:metLisette|seen:ls.0}
* Leave it.  -> fg.cellar2

# fg.vflask2
vossler: I... no. That's Brick's. That's the main event.
? apex 10 "Now."  -> fg.vflaskok | fg.vflaskno {id fg_flask}

# fg.vflaskok
> He hands it over with shaking hands. It's warm. You can smell it through the metal: Lisette, jasmine, and something cheap mixed in to stretch it.
vossler: Brick's going to be fighting on beer tonight. Brick's going to be *upset*.
{do flag:brickDry=1}
@next fg.cellar2

# fg.vflaskno
vossler: No, I don't think so. I'll call Tiny. Oh wait. Tiny's the brother. Awkward. Bet or leave.
@next fg.cellar2

# fg.vbet
vossler: On the KID? At nine to two? Oh, you're my favorite person this week. How much?
* Bet a hundred.  -> fg.vbet1 {do cash-100; flag:betMarcus=100}
* Bet everything.  -> fg.vbet2 {if cash>=200}

# fg.vbet1
vossler: A hundred on the kid. Lovely. Lovely.
@next fg.cellar2

# fg.vbet2
vossler: Everything. Everything! On the kid! I'm going to buy a boat.
{do flag:betMarcus=all}
@next fg.cellar2

# fg.vfix
vossler: Fix it? Me? I'm a sporting man.
vossler: ...Five hundred. Brick goes down in the third. Marcus walks out with the purse. Nobody knows but you, me and Brick, and Brick doesn't know anything, it's part of his charm.
* Pay him.  -> fg.vfixpay {if cash>=500}
* "That's a lot of money for an honest man."  -> fg.vfixhag
* "No. Forget it."  -> fg.cellar2

# fg.vfixpay
> You pay him. He counts it twice.
vossler: Third round. Marcus will think he did it. Don't tell him. Never tell them. It's the kindest thing.
{do cash-500; flag:fightFixed=1}
@next fg.cellar2

# fg.vfixhag
? velvet 10 "Two hundred. And I don't mention the flask to Lisette."  -> fg.vfixhagok | fg.vfixhagno {id fg_hag}

# fg.vfixhagok
vossler: You're a monster. You're a monster. Two hundred. Fine.
{do cash-200; flag:fightFixed=1}
@next fg.cellar2

# fg.vfixhagno
vossler: Five hundred, friend. Fixed prices. Ha. Fixed.
@next fg.cellar2

# fg.pullres
> Up by the rope, a nineteen-year-old in a white vest hears the announcement and turns round. He's huge and young and his face goes slack, then red. He looks for someone to blame.
> He finds Tiny at the back. He goes for Tiny.
* Get between them.  -> fg.between
* Let the brothers have it out.  -> fg.brothers

# fg.between
marcus: Was it you? Did you do this? I needed this! Mom needs this!
? velvet 10 "He didn't do it. I did. Because Brick would have killed you, and I'd rather you hated me than your brother."  -> fg.betok | fg.betno {id fg_bet}

# fg.betok
> Marcus stares at you. He's nineteen and he's never been looked at by anything like you before. He doesn't understand what you are. He understands that you mean it.
marcus: ...Killed me?
tiny: He drinks blood, Marc. Brick. Before fights. Vossler's got a flask. That's why he doesn't lose.
marcus: That's... that's mental. That's... is that true?
> He looks at you. You let him look.
marcus: ...Oh my God.
{do flag:marcusSafe=1; rel:tiny+3; task:s_fight=done; xp:70:The Fight Card; flag:fightDone=1}
@next fg.after

# fg.betno
> Marcus shoves past you. It's like being shoved by a door. He and Tiny go at it by the bar, the way brothers do, until both of them are crying and neither of them will admit it.
{do flag:marcusSafe=1; rel:tiny+1; task:s_fight=done; xp:50:The Fight Card; flag:fightDone=1}
@next fg.after

# fg.brothers
> You let them have it out. Two enormous men, one older, one younger, shouting and then shoving and then, after a long time, holding onto each other in the middle of two hundred people who've stopped watching the ring to watch them instead.
{do flag:marcusSafe=1; rel:tiny+2; task:s_fight=done; xp:60:The Fight Card; flag:fightDone=1}
@next fg.after

// --- Marcus ---
# fg.mfirst
> You find Marcus before you find anyone else, in a corner by the boiler, wrapping his hands. White vest. Nineteen. He looks like Tiny if you took twenty years and all the sadness off him.
@next fg.m0

# fg.m0
marcus: You're the one. Tiny's mate. The one he won't talk about.
marcus: He sent you, didn't he. To tell me to pull out.
* "Yes."  -> fg.myes {do lean:candour+1}
* "No. I came to watch you win."  -> fg.mno
* "I came to tell you what Brick is."  -> fg.mtell {if seen:fg.voss}

# fg.myes
marcus: Course he did. Course he did. Because I'm a baby. Because I can't do anything.
marcus: Mom's got mold in the bedroom. Black on the walls. She coughs all night. Four grand gets her a deposit on somewhere with windows that shut. Four grand is one night.
* "And if you're dead, she's got damp AND a dead son."  -> fg.mdead
* "I'll get her the four grand."  -> fg.mmoney {if cash>=400}
* "Then win."  -> fg.mwin

# fg.mno
marcus: Watch me win. Yeah. Yeah, you'll see. Brick's slow. He's big and he's slow. I'm fast.
pulse(5): His heart is going like a sparrow's. He knows. Some part of him knows.
@next fg.myes

# fg.mtell
> You tell him. Vossler. The flask. Lisette's ribbon. What Brick drinks, and what it does to a man's hands.
marcus: You're... what, like a vampire? Is that what you're saying? Is that what Tiny's mixed up in? On the door?
marcus: ...Your eyes are doing a thing. Your eyes are doing a thing right now.
@next fg.myes

# fg.mdead
> He looks at his wrapped hands.
marcus: ...She'd kill me. If I died. She'd actually kill me.
? velvet 9 "Pull out. Let me find another way. I'm good at finding other ways."  -> fg.mout | fg.mstays {id fg_mout} {mod like:tiny}

# fg.mout
marcus: ...Okay. Okay. Okay. I'll tell Vossler. He's going to go mental.
{do flag:marcusPulled=1}
@next fg.pullres2

# fg.mstays
marcus: No. No, I've got to. I've got to. I said I would. Everyone's here.
@next fg.cellar2

# fg.pullres2
> Vossler goes mental. Tiny comes down from the door and stands behind his little brother, and Vossler stops going mental.
{do flag:marcusSafe=1; rel:tiny+3; task:s_fight=done; xp:70:The Fight Card; flag:fightDone=1}
@next fg.after

# fg.mmoney
> You count it out on the boiler. Four hundred. It isn't four grand. It's what you've got.
marcus: ...What's this?
* "A start. For the deposit. Pull out and there'll be more."  -> fg.mmoney2 {do cash-400; lean:mercy+1}

# fg.mmoney2
marcus: Why would you... you don't even know me.
marcus: You're like... Tiny's guardian angel. Except evil. A guardian evil.
> He puts the money in his sock. He pulls out of the fight.
{do flag:marcusPulled=1; flag:marcusMoney=1; rel:tiny+3}
@next fg.pullres2

# fg.mwin
marcus: Yeah. Yeah! Win. That's what I'm gonna do.
@gate flag:fightPlan=blood ? fg.mblood : fg.cellar2

# fg.mblood
> Tiny appears out of the crowd. He's been crying. He looks at you over his brother's head and nods, once. Then he walks away before he can change his mind.
* Open your wrist for Marcus.  -> fg.mbloodgo {blood}
* Don't. Not this. Not to Tiny's brother.  -> fg.cellar2 {do lean:restraint+1}

# fg.mbloodgo
> Marcus drinks from your wrist in a corner by the boiler, gagging, then not gagging. His eyes go wide. His pupils go wide. He laughs, very loud, like a child on a swing.
marcus: Oh. OH. Oh my God. I can hear everyone's hearts.
{do vitae-2; flag:marcusBlooded=1; lean:restraint-1}
@next fg.fight

// --- Brick ---
# fg.b0
> Brick is sitting on an upturned crate by the stairs with a towel over his head. Thirty, maybe. Big, shaven, quiet. His knuckles are the shape of somebody else's face.
@gate flag:brickDry ? fg.bdry : fg.bwet

# fg.bwet
brick: ...What.
pulse(6): His heart's going slow and heavy, like a drum in another room. Lisette's blood. He's had his tonic already.
* "Go easy on the kid."  -> fg.beasy
* "How many people have you killed, Brick?"  -> fg.bkill

# fg.bdry
> He's shaking. Sweat on his scalp. He keeps rubbing his forearms like they itch from inside.
brick: Vossler hasn't... where's Vossler? I need my... I need my medicine. Have you got it? You smell like you've got it.
pedigree(7): Withdrawal. Two removes from the source and it's still got him by the throat.
* "I've got it. And you're not having it."  -> fg.bdry2
* Give him the flask back.  -> fg.bgive {do flag:brickDry=0}

# fg.bdry2
brick: ...Please. Please. I can't go out there on nothing. They'll... the kid's fast. The kid'll knock me down in front of everyone. I've never been knocked down.
brick: Vossler said I was special. He said I was the only one he gave it to. He said if I ever stopped I'd die.
* "You won't die. You'll just be a man. That's worse, for a while."  -> fg.bman {do lean:mercy+1}
* "Then die."  -> fg.cellar2

# fg.bman
> He looks at you from under the towel. He's thirty and he has been drinking from a hip flask since he was twenty-two and he has no idea what he'd be without it.
brick: ...What's it like? Being just a man.
* "Cold. Then you get used to it."  -> fg.bman2

# fg.bman2
brick: ...I'll fight the kid. On nothing. Let him knock me down. Maybe I'll stay down.
{do flag:brickClean=1}
@next fg.cellar2

# fg.bgive
> He drinks it all. All of it. His shaking stops. His eyes go flat as coins.
brick: ...Thank you. Thank you. Tell the kid I'm sorry.
@next fg.cellar2

# fg.beasy
brick: ...Easy. I don't know easy. Vossler says go, I go. When it's over, it's over.
@next fg.cellar2

# fg.bkill
brick: Nobody. Nobody. ...One. In Pittsburgh. Vossler said it wasn't my fault. He said the lad had a heart thing.
pulse(5): His heart doesn't change. He's told himself this enough times that it's become true.
@next fg.cellar2

// --- the fight itself ---
# fg.watch
@gate flag:marcusPulled ? fg.pullres : fg.fight

# fg.fight
> The bell is a frying pan hit with a spanner. Two hundred people roar. Marcus comes out of his corner like a dog off a lead. Brick comes out of his like a wall coming down.
@gate flag:fightFixed ? fg.fixed : fg.fight2

# fg.fight2
@gate flag:marcusBlooded ? fg.fblood : fg.fight3

# fg.fight3
@gate flag:brickDry ? fg.fdry : fg.fwet

# fg.fixed
> Two rounds of Marcus dancing and Brick lumbering. In the third, Brick drops his guard and walks into a right hand that wouldn't have knocked down a fridge, and goes over like a felled tree, and stays there.
> Marcus stands over him with both arms up. He's crying. He thinks he did it.
> In the corner, Vossler catches your eye and taps his nose.
{do flag:marcusWon=1; flag:marcusSafe=1}
@next fg.win

# fg.fblood
> It isn't a fight. It isn't anything. Marcus moves faster than anyone in the room has ever seen a man move. Brick, full of Lisette, hits him once and it's like hitting a lamp post. Marcus hits back.
> It's over in forty seconds. Brick is on the sawdust. He isn't getting up. He isn't getting up for a long time. There's a lot of blood, and some of it is the wrong color.
> The crowd goes silent, and then insane. Marcus stands in the ring with his hands open, staring at them. Staring at what they did.
marcus: ...I didn't mean... I didn't mean to do it that hard. I didn't mean to.
{do flag:marcusWon=1; flag:brickHurt=1; flag:marcusGhoul=1; heat+1; rel:tiny-1}
@next fg.win

# fg.fdry
> Brick, on nothing, is a big slow man who's scared. Marcus is a fast young one who isn't. Six rounds. Both of them bleeding. In the sixth, Brick puts out a hand to the ropes, and misses them, and sits down in the sawdust, and doesn't get up.
> He's not hurt. He's just stopped. He looks up at the bulbs and laughs, and then he cries, and nobody in the room understands why except you.
{do flag:marcusWon=1; flag:marcusSafe=1; flag:brickClean=1}
@next fg.win

# fg.fwet
> It goes the way it was always going to go. Marcus is fast. Brick doesn't need to be. In the second round Brick catches him with one hand on the side of the head and Marcus goes down like his strings were cut.
> Tiny is over the rope before anybody else moves. Marcus is breathing. He's breathing. His eyes won't focus.
* Push through the crowd. Get to him.  -> fg.fwet2
* Let your blood do something. Open your wrist for him now.  -> fg.fwetblood {blood}

# fg.fwet2
> St. Jude's is four minutes away. You carry him. Tiny runs beside you holding his brother's hand. In the ambulance bay a nurse takes one look and shouts for Rostova.
> Fractured skull. Bleed on the brain. They operate at two. He lives. He won't box again. He'll have headaches for the rest of his life.
{do flag:marcusHurt=1; rel:tiny+1; task:s_fight=done; xp:40:The Fight Card; flag:fightDone=1; tick:60}
tiny: ...He's alive. He's alive. That's what matters. That's what matters.
@end

# fg.fwetblood
> You kneel in the sawdust with two hundred people watching and put your wrist to a dying boy's mouth. He drinks without knowing what he's doing. His eyes focus. His skull, under your hand, does something you can feel: a settling. A mending.
> Two hundred people saw that. Two hundred people saw a dying boy drink from somebody's wrist and sit up.
{do vitae-2; flag:marcusGhoul=1; flag:marcusSafe=1; heat+2; breach}
tiny: ...What did you do. What did you DO.
{do task:s_fight=done; xp:50:The Fight Card; flag:fightDone=1}
@end

# fg.mefight
> They take off your coat for you. Somebody gives you a towel. Two hundred people chant something that might be a name, if they knew your name.
> Brick looks at you across the rope. His pupils are huge. He can smell what you are. Every ghoul can. He looks like a dog that's been put in a ring with a wolf and is too well-trained to run.
* Fight him fair. No blood, no tricks.  -> fg.mefair
? apex 9 "Let him see the wolf. Let him run."  -> fg.mewolf | fg.mefair {id fg_wolf}
* Put him down in one. Make a show of it.  -> fg.meshow {do lean:pride+1}

# fg.mefair
> It isn't fair. You can't make it fair. You're dead and he's only borrowing. But you hold back everything you can, and it's still seven rounds, and you let him hit you because it seems right that someone should, this week.
> In the seventh he's out on his feet and you catch him as he falls and lower him into the sawdust like a sleeping child.
{do flag:fightMeWon=1; flag:marcusSafe=1; rel:tiny+2; task:s_fight=done; xp:70:The Fight Card; flag:fightDone=1; give:fightpurse; cash+400}
@next fg.after

# fg.mewolf
> You look at him across the ring and let it out. Not much. A glimpse.
> Brick climbs out through the ropes and walks through two hundred people and up the stairs and out into the rain. He doesn't look back. Somebody says he got on a bus to Leeds.
> Vossler is screaming about refunds.
{do flag:fightMeWon=1; flag:marcusSafe=1; rel:tiny+2; task:s_fight=done; xp:70:The Fight Card; flag:fightDone=1; flag:brickClean=1}
@next fg.after

# fg.meshow
> One punch. You don't even move your feet. Brick goes backwards over the ropes and through a trestle table full of beers and lies in a lake of Bud Light looking at the ceiling.
> Two hundred people scream your name, or what they think is your name. It's the loudest anyone's ever been about you.
parasite(5): And every one of them will remember the face of the thing that did that. Every phone in the room was up.
{do flag:fightMeWon=1; flag:marcusSafe=1; heat+1; task:s_fight=done; xp:60:The Fight Card; flag:fightDone=1; give:fightpurse; cash+400}
@next fg.after

# fg.win
> Afterwards, by the boiler, Marcus sits with the purse on his knee: four thousand, in twenties, in a carrier bag.
@gate flag:marcusGhoul ? fg.wing : fg.winc

# fg.wing
marcus: I can still hear everyone's hearts. When does it stop? It's stopping, right? It stops?
tiny: ...It doesn't stop, Marc. Not unless you never have it again. And you'll want it again.
> Tiny looks at you over his brother's head. Whatever he thought you were, it's changed.
{do task:s_fight=done; xp:50:The Fight Card; flag:fightDone=1; rel:tiny-1}
@end

# fg.winc
marcus: Four grand. Four grand. Mom's getting windows that SHUT.
tiny: You nearly died for windows, you absolute idiot.
marcus: Worth it.
{do task:s_fight=done; xp:70:The Fight Card; flag:fightDone=1; rel:tiny+3}
@next fg.after

# fg.after
> Tiny walks you up the cellar stairs into the rain. At the top he stops.
tiny: I've done this door nine years. I've never once asked any of you lot for anything. And you didn't even make me ask.
@gate flag:betMarcus&flag:marcusWon ? fg.payout : fg.after2

# fg.payout
> Vossler pays out your bet with the face of a man passing a kidney stone.
{do cash+450}
@next fg.after2

# fg.after2
tiny: Friday. Whatever it is you've got on Friday. I'll be there. Me and Marc. Don't argue.
{do flag:tinyFriday=1}
@end

// =====================================================================
// LEO'S MOTHER
// =====================================================================
# lr.0 arc=leo night=3,4 label="\"Leo. Who's the woman on the stairs?\"" if=room:rookery&alive:leo&!flag:leoThrall&!flag:leoForgot&!flag:leoGoneTown prio=2
@focus leo
> On the second-floor landing of the Rookery, sitting on a wheeled suitcase, a woman in her sixties in a raspberry-colored coat. She's eating a Little Debbie and reading a large-print Maeve Binchy.
leo: Oh God. Oh God, no. Oh no. Don't look. Don't make eye contact. It's my mom.
leo: She was supposed to be coming on the SIXTEENTH. Of NOVEMBER. She's come early. She's come early because she *heard* something.
* "Heard what?"  -> lr.heard
* "Why are you hiding from your mother?"  -> lr.hide

# lr.heard
leo: I dunno! Something! She's got a sense. She rang on Tuesday and I sounded "funny". I didn't sound funny. I sounded FINE. I sounded like a man who's FINE.
@next lr.hide

# lr.hide
leo: Because she's going to look at me and know. She always knows. She knew when I failed my driving test four times. She knew when Tash left. She's going to look at me and she's going to know I've got a... friend who doesn't have a pulse.
leo: And she's going to want to meet you. She ALWAYS wants to meet my friends. She'll want to *feed* you.
{do task:s_rosa; note:s_rosa|Leo's mother, Rosa Pruitt, has turned up early on Halloran Street with a suitcase and a sense that something is wrong. She wants to meet Leo's friends.}
* "I'll meet her."  -> lr.meet
* "Send her home, Leo. It isn't safe here this week."  -> lr.send
* "I'll make myself scarce."  -> lr.scarce

# lr.scarce
leo: Yes. Good. Thank you. Go. Go out the fire escape. I'll tell her you're a... I'll tell her you're shy.
{do flag:rosaAvoid=1}
@end

# lr.send
leo: Send her home. To Scranton. On the Greyhound. She's just got off the Greyhound. She's got a SUITCASE.
leo: ...You're right though. You're right. Harrow's people. The vans. I don't want her anywhere near this.
* "I'll talk to her. I'll make her want to go."  -> lr.sendtalk
* "You talk to her. It should be you."  -> lr.sendleo

# lr.sendleo
leo: Me. Talk to my mom. Tell her to go home. She's been on a bus for nine hours.
leo: ...Okay. Okay. I'll do it. Over a cuppa. She can't argue with a cuppa.
> He goes down the stairs. You hear her voice, warm and enormous: "LEONARD." You hear him say "Hi, Mom." You hear the door to 3B close.
> An hour later she's still there. She's unpacked.
leo: (from the landing, hissing) She's not going. She says I look thin. She says I look *haunted*. She's making stew.
{do flag:rosaStays=1}
@next lr.meet

# lr.sendtalk
@next lr.meet

# lr.meet
> She sees you before Leo can do anything about it. She puts down the Maeve Binchy. She stands up, which takes a moment, and puts her hands on her hips.
rosa: Well. You must be the friend.
rosa: Leonard's been talking about a friend for four days on the phone. "My mate this." "My mate that." He's never once said "my mate" about anyone since he was nine. So I thought I'd better come and see.
pulse(5): Her heart is steady, warm, a little fast. She's nervous. She's been nervous for nine hours on a Greyhound. She's not going to show it.
* "Mrs. Pruitt. It's lovely to meet you."  -> lr.lovely
* "He talks about you too."  -> lr.talks
* Say nothing. Let her look.  -> lr.look

# lr.lovely
rosa: Rosa. Mrs. Pruitt's my mother-in-law, God rest her, and she was a horror.
rosa: You're freezing. Your hands are freezing. Leonard, put the heating on, this one's frozen. Have you eaten? You haven't eaten. I can tell. You've the look.
leo: Mom.
rosa: Don't "Mom" me.
@next lr.hub

# lr.talks
rosa: Does he. What does he say?
* "That you always know."  -> lr.know
* "That you make stew."  -> lr.stew

# lr.know
rosa: I do always know. It's a curse. My mother had it. When Leonard's father was ill I knew before the doctors. I knew Tash was leaving before Tash did.
rosa: And I know something's wrong now. I don't know what. Is he in trouble? Money? Drugs? He's not on drugs, is he? He was on drugs for a bit in 2015. Mushrooms. He thought he was a lamp.
leo: MUM.
@next lr.hub

# lr.stew
rosa: I DO make stew. I make it for every crisis. I made it the day the Phillies lost the Series. I made it at Leonard's father's wake. There's a stew on in that flat right now and you're going to have a bowl.
nostalgia(6): A bowl of stew in a stranger's kitchen. You'd forgotten. You'd forgotten what it was to be fed by somebody.
@next lr.hub

# lr.look
> She looks. You let her. A small woman in a raspberry coat looking up at something that isn't human, on a landing that smells of cat.
> Something goes across her face. Not fear. Recognition, maybe. The way you'd recognize weather.
rosa: ...You're not well, are you, love.
* "No. Not really."  -> lr.notwell {do lean:candour+1}
* "I'm fine."  -> lr.fine

# lr.notwell
rosa: No. I didn't think so. You've the look Leonard's father had at the end. Like somebody standing just on the other side of a window.
rosa: Well. Come in out of the stairwell. Whatever it is, it's not catching. Is it? It's not catching?
* "No. It's not catching."  -> lr.hub
* "...It can be. If I'm careless."  -> lr.catching {do lean:candour+1}

# lr.catching
> Leo goes white. Rosa doesn't. She looks at you for a long moment, and then at her son, and then at you again.
rosa: Then don't be careless. That's all anybody can say to anybody.
{do flag:rosaKnowsish=1}
@next lr.hub

# lr.fine
rosa: Course you are. Everyone's fine. Leonard's fine, I'm fine, the Pope's fine.
@next lr.hub

# lr.hub
* Sit down and eat the stew.  -> lr.eat {once}
* "Why did you really come early, Rosa?"  -> lr.why {once}
* "Leo's a good comedian."  -> lr.comic {once}
* "Rosa, you need to go home. Before Friday."  -> lr.go {once} {if night>=3}
? stagecraft 10 "Tell her a story about who you are. A good one. Make it boring and safe."  -> lr.cover | lr.coverno {id lr_cover} {once}
* "I have to go. It was good to meet you."  -> lr.bye

# lr.eat
> You sit at Leo's tiny table with a bowl of beef stew in front of you. Leo is sitting very still. He knows what happens if you eat it.
> Rosa watches you. She's waiting.
* Eat it. All of it. Whatever it costs.  -> lr.eatall
* Eat a spoonful. Smile.  -> lr.eat1
* "I can't. I'm sorry. I'm on a... special diet."  -> lr.eatno

# lr.eatall
> It's like eating wet sand. It's like eating ash. Your body doesn't know what to do with it. Every spoonful is an argument you're losing.
> You finish the bowl. You say it was lovely. Rosa beams like the sun, which is not a comparison you'd make lightly.
> Later, on the fire escape, you're sick for ten minutes. All of it comes back up, unchanged, cold. It's the best meal you've had in a week.
{do vitae-1; comp+4:Rosa's stew; rel:leo+2; flag:ateStew=1; lean:mercy+1}
rosa: (through the window) Was it the stew? It's the stew, isn't it. I put too much pepper.
@next lr.hub

# lr.eat1
> One spoonful. It sits in your mouth like a stone. You swallow. You smile.
rosa: There. Was that so hard? You've a face like a funeral, love. Have some more.
leo: Mom, they're full. They're really, really full.
{do comp+2; rel:leo+1}
@next lr.hub

# lr.eatno
rosa: A special diet. Like the Atkins?
* "Sort of."  -> lr.eatno2

# lr.eatno2
rosa: My sister did the Atkins. Lost three stone, then ate a whole Carvel cake at Christmas and put it all back on. These things never work, love. You need stew.
@next lr.hub

# lr.why
> She glances at Leo, who's pretending to wash a mug.
rosa: (quietly) He rang on Tuesday. Late. Two in the morning. He never rings at two. He didn't say anything was wrong. He said a joke. A new one. About a man who wakes up in a freezer and doesn't know who he is.
rosa: It wasn't funny. Leonard's jokes are never funny, God love him, but this one was the wrong kind of not funny. It was the kind that's not a joke at all.
rosa: So I got the bus.
nostalgia(6): He put you in a joke. On Tuesday. At two in the morning. And called his mom.
{do mem:rosa:joke}
@next lr.hub

# lr.comic
rosa: He's not. He's really not. I've been to his gigs. I sat at the front of a bar in Scranton in 2018 and watched him do twenty minutes about the bus and nobody laughed but me.
rosa: But he keeps getting up. Every Tuesday. Doesn't matter if nobody laughs. That's the bravest thing I know. Braver than his father, and his father fought a bull once.
leo: He didn't fight a bull. He fell into a field with a bull in it.
rosa: He was very brave about it.
@next lr.hub

# lr.go
rosa: Home. Before Friday. What's Friday?
* "Something bad. I can't tell you what."  -> lr.gobad
* Lie: "There's going to be a gas leak. The council's evacuating the street."  -> lr.golie
? velvet 11 "Rosa. If you love him, take him with you."  -> lr.gotake | lr.gotakeno {id lr_take} {mod like:leo}

# lr.gobad
rosa: Something bad. And my son's mixed up in it, and you're mixed up in it, and I'm meant to get on a bus and go home and do my crossword.
rosa: No. I'm sorry, love. No. If something bad's happening on Friday, I'll be here on Friday. Someone's got to make the stew.
{do flag:rosaStays=1}
@next lr.hub

# lr.golie
stagecraft(5): A gas leak. It's even true. Harrow's put out the same story to the papers.
rosa: A gas leak. Oh, for God's sake. Well, I'm not stopping in a gas leak. Leonard, you're coming to the Motel 6.
leo: Mom, I...
rosa: MOTEL SIX, Leonard.
{do flag:rosaInn=1; lean:candour-1}
@next lr.hub

# lr.gotake
> She looks at you for a long time. Then she looks at Leo, who's stopped washing the mug.
rosa: ...You want me to take him away. From you.
rosa: You care about him. I can see you do. And you want me to take him away from you.
rosa: That's love, that. That's the real kind. Most people never manage it.
leo: I'm not going anywhere. I'm thirty-four. I'm not going back to Scranton with my MOM.
rosa: Leonard Pruitt, you'll do as you're told for once in your life.
* "Go with her, Leo. Please."  -> lr.leogo
* "It's your choice, Leo."  -> lr.leochoice

# lr.leogo
leo: ...You're asking me to go. You actually want me to go.
leo: Okay. Okay. Saturday. If there is a Saturday. We'll get the bus Saturday.
leo: No. ...Friday. We'll go Friday. Before dark. If that's what you want.
{do flag:leoCork=1; flag:leoGoneTown=1; rel:leo+1; task:s_rosa=done; xp:60:Leo's Mother}
rosa: Good lad. Now. There's stew for the bus.
@end

# lr.leochoice
leo: My choice. Okay. My choice is I'm staying. Mom can go to the Motel 6 and I'm staying, because somebody has to be on the street on Friday who isn't a vampire or a fed.
rosa: ...He gets that from his father. The bull.
{do flag:rosaInn=1; flag:leoStaysBrave=1; rel:leo+2}
@next lr.hub

# lr.gotakeno
rosa: Take him? He's thirty-four. You can't take a thirty-four-year-old anywhere. You'd need a crane.
@next lr.hub

# lr.cover
> You tell her a story. You're a night-shift nurse at St. Jude's. You've got a condition: porphyria, sunlight sensitivity, poor circulation, that's the cold hands. You met Leo at an open mic. You're the only one who laughed.
> It's very good. It's boring and plausible and full of the kind of detail people only bother to make up if they're telling the truth.
rosa: Porphyria. My cousin Eileen had that. Or psoriasis, one of them. Well, that explains the face. You poor thing.
{do flag:rosaCover=1; xp:20:Night nurse}
@next lr.hub

# lr.coverno
> You tell her a story. You're a... nurse? No, a lawyer. A night lawyer. She looks at you the way she looked at Leo when he said he'd only had two pints.
rosa: Mm-hm.
@next lr.hub

# lr.bye
@gate flag:rosaStays|flag:rosaInn|flag:leoCork ? lr.byedone : lr.byeopen

# lr.byedone
rosa: Mind yourself, love. Come back for more stew. That's not a request.
{do task:s_rosa=done; xp:60:Leo's Mother}
@end

# lr.byeopen
rosa: Off you go. Mind yourself. You'll be back. They always come back for the stew.
@end

// Rosa on Night 5
# lr5.0 arc=leo night=5 label="\"How's your mom, Leo?\"" if=flag:rosaStays|flag:rosaInn prio=3
@focus leo
@gate flag:rosaInn ? lr5.inn : lr5.flat

# lr5.inn
leo: Motel 6 on the beltway. She's watching *Jeopardy!* reruns and eating a gas-station sandwich. She's texted me nine times. Here. Look.
> His phone: *Are you alive.* *Leonard.* *Leonard are you alive.* *Leo answer your mother.* *I've had a tuna sub it was $9.*
leo: I'm going to text her back "alive" every hour till dawn. If I stop, she'll get a taxi here, and God help Harrow.
{do comp+1}
@end

# lr5.flat
leo: She won't leave. She's in the apartment with the stew. She's put a chair against the door and she's got my dad's old Louisville Slugger across her knees.
leo: She said if anyone comes up those stairs who isn't me or you, she'll "take the head off them". I believe her. She's terrifying.
leo: She asked me to tell you there's a bowl kept back. For after.
nostalgia(6): A bowl kept back. For after. As if there's going to be an after.
{do comp+2; flag:rosaBowl=1}
@end
`,'c_sq5');

/* fates for the people from set five */
NL.Act=NL.Act||{};NL.Act.extraFates=NL.Act.extraFates||[];
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.dominicDead)o.push(['Father Dominic','The night chaplain at St. Jude\'s was found between the pews on Wednesday morning. The coroner said his heart. His sister came from Wexford for the funeral and asked, twice, what had happened to his notebook.']);
  else if(f.dominicWexford)o.push(['Father Dominic','Spent the winter in a cottage in Wexford doing crosswords. Came back in March. The chapel was still there. So was the loose step. He said Mass on Easter Sunday for nobody, and then sat in the front pew for an hour in case anybody came.']);
  else if(f.confessed)o.push(['Father Dominic','Was in his chapel on Friday night with the dying, as always. At 4:14 the electric candle went out for no reason. He lit a real one. He kept counting.'+(f.haveDomList?' His notebook is in your coat. Two hundred and nine names. You haven\'t lost any.':'')]);
  if(f.marcusGhoul)o.push(['Marcus','Can still hear everyone\'s hearts. Moved Mom to an apartment with windows that shut. Comes to the Reliquary cellar every Thursday, and stands at the back, and doesn\'t fight, and doesn\'t drink. Tiny stands next to him.']);
  else if(f.marcusHurt)o.push(['Marcus','Has headaches. Has a scar like a zip over his left ear. Got a job at a gym on Kerr Street teaching kids to skip. Tells them never to fight for money. They never listen.']);
  else if(f.marcusSafe)o.push(['Marcus','Got Mom her windows. Didn\'t get his head caved in. Still thinks he\'s fast. Still is.']);
  if(f.brickClean)o.push(['Brick','Got a bus to Pittsburgh. Shook for a month. Got a job on a building site. Sometimes, when it\'s cold, he feels like a man, and it\'s worse, and then it\'s better.']);
  if(f.leoCork)o.push(['Rosa Pruitt','Got the five o\'clock Greyhound on Friday with her son and a Tupperware of stew. Leonard did twenty minutes in a Scranton bar about a friend who was dead. Nobody laughed but her. She said it was the best thing he\'d ever written.']);
  else if(f.rosaStays||f.rosaInn)o.push(['Rosa Pruitt','Sat up all Friday night with a baseball bat across her knees. At dawn her son texted "alive". She cried for the first time since the funeral. Then she put the kettle on.']);
  return o;});
