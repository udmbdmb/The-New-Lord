'use strict';
/* THE NEW LORD — "The Black Car": Magistrate Ambrose receives petitioners the night before the Tribunal, in a 1931 Daimler under the railway viaduct. What you ask him for changes how Friday begins. */
(function(){const S_=NL.Script;
NL.EXTRAS.magistrate=NL.EXTRAS.magistrate||NL.CHARS.magistrate;
NL.TASKS.s_petition={n:'The Black Car',xp:60,cat:'side'};
S_.place({id:'daimler',name:'The Viaduct, Kerr Street',block:'D',sub:'A black 1931 Daimler, engine off, curtains drawn. The Magistrate receives petitioners on the night before a Tribunal.',if:'night:4&time>=90&flag:mapOK&!flag:petitionDone',node:'am.0',min:14});
})();
NL.Script.add(String.raw`
# am.0
> Under the railway viaduct on Kerr Street, where nobody parks because the pigeons are merciless, a long black car with its engine off. Coachwork from before the war. The war before that, possibly. Velvet curtains in the rear windows.
> A ghoul in a chauffeur's cap stands by the rear door with an umbrella, though it isn't raining. He looks at you. He opens the door.
ghoulchauffeur: The Magistrate will see you. Please don't touch the upholstery. It's older than your grandmother.
> Inside: leather, lamplight, the smell of cedar and very old paper. Opposite you, on the rear-facing seat, in a grey suit instead of the red robe, a thin man with white hair and a face like a closed book.
magistrate: Sit. You have until the next train. They run every eleven minutes. It's the only clock I trust.
{do task:s_petition}
@next am.first

# am.first
magistrate: You've come to petition. Everyone does, the night before. The accused, the accusers, people who simply want to be seen in the car.
magistrate: Most of them ask me to be lenient. I never am. Some ask me to be harsh. I never am that either. I am the law, as written, as it was written in Avignon in 1381, and the law is neither.
magistrate: What do you want?
* "A fair trial."  -> am.fair
* "To know the rules. All of them."  -> am.rules
* "To ask you about Absalom Vane."  -> am.vane
* "To make you an offer."  -> am.offer
* "To tell you you'll be on that platform when the lamps come on."  -> am.lamps {if flag:knowLamps|flag:knowCode|seen:hw4.0}

# am.fair
magistrate: Fair. Hm.
magistrate: Do you know, nobody has asked me for that since 1904. A Gilded boy from Lisbon. He'd eaten his sire's ghoul, which is a misdemeanour, and his sire's ghoul's wife, which is not. He asked for a fair trial.
* "Did he get one?"  -> am.fair2

# am.fair2
magistrate: He did. I burned him at dawn. Fairly.
magistrate: Fairness is not mercy. Fairness is the law applied the same way to you as to a Prince. I can promise you that, because I promise it to everyone. Is that all?
* "That's all. Thank you."  -> am.fairthanks {do lean:candour+1}
* "Then let me ask something else."  -> am.hub

# am.fairthanks
> For the first time, something moves in the closed book of his face. Not a smile. A page turning.
magistrate: Hm. Nobody thanks me. Very well. You may have the next train as well, if you want it.
{do flag:magFair=1; rel:magistrate+1}
@next am.hub

# am.rules
magistrate: The rules. Ha. Everyone thinks they know the rules. They've seen a Tribunal or two. They know the chalk circle, the Accuser, the Defence. They don't know the rules.
magistrate: Very well. Three, since you asked, and since nobody does.
magistrate: One: the dead may testify, if they can be made to. Blood memory, a spirit, a ghost in a glass. The Wraiths fought for that in 1611.
magistrate: Two: any Kindred on the platform may stand and speak once for the accused, and once against. Once. If they speak twice, I take their tongue.
magistrate: Three. And this is the one that matters. If the Accuser is shown to have lied in the circle, the case against you is void. Not weakened. *Void.* It has happened four times in six hundred years.
web(7): Séverine is the Accuser. If you can catch her in a lie, in the chalk, in front of him, it's over.
{do flag:magRules=1; xp:30:The rules}
@next am.hub

# am.vane
magistrate: Absalom.
> He looks at the velvet curtain. The train goes over, above, a long iron roar, and the car shivers.
magistrate: I was his second. Corsica, 1790. A duel at dusk with Count Orsini over a woman neither of them liked. Absalom was a dreadful swordsman. He was cut through the left eyebrow in the first pass and fell into a goat pen.
tenant: ...Ambrose. Ambrose, God. He held the handkerchief. He laughed so hard he couldn't hold the handkerchief.
magistrate: He won anyway. Orsini slipped on the goat. It was the stupidest evening of my very long life. I have never once been happier.
* "You loved him."  -> am.vanelove
* "Then why are you trying me for his murder?"  -> am.vanewhy
* "He's in me. He can hear you."  -> am.vanein {if sync>=30|flag:chord}

# am.vanelove
magistrate: I am a Magistrate. I do not love. I adjudicate.
magistrate: ...I was fond of him. For two hundred years. We had dinner every Christmas Eve until he met his mortal and started spending it on a hill in the snow.
{do mem:magistrate:fond}
@next am.hub

# am.vanewhy
magistrate: Because the law does not care that I liked him. Because if I let you go because I liked him, I am not the law any more. I am a man in a car.
magistrate: And I have been the law for six hundred years. I have forgotten how to be a man in a car.
@next am.hub

# am.vanein
> He goes very still. He looks at you, properly, for a long time. His eyes are the color of cold tea.
magistrate: Prove it.
* Let the Tenant speak.  -> am.vaneprove
* "I can't make him. He comes when he comes."  -> am.vanecant

# am.vaneprove
> You let go. Just a little. Just enough.
tenant: Ambrose. You owe me forty francs from the goat.
> The Magistrate of the Marrow Ward does not move for the whole length of a passing train. When it's gone, he takes a handkerchief out of his breast pocket. White linen, very old, with a brown stain in one corner that might once have been blood from a left eyebrow.
magistrate: ...I kept it. Of course I kept it.
magistrate: This changes nothing about the law. You understand. Nothing.
magistrate: But I will be listening on Friday. For him. As well as you.
{do flag:magHeardVane=1; sync+3; rel:magistrate+2; mem:magistrate:goat}
@next am.hub

# am.vanecant
magistrate: No. Of course. The dead are notoriously poor at keeping appointments.
@next am.hub

# am.offer
magistrate: An offer. To a Magistrate. In his car. On the night before.
> His voice doesn't change at all. It doesn't need to. The ghoul outside the window has put his hand inside his coat.
* "Information. About who's really on trial."  -> am.offerinfo {if flag:knowOttilie|flag:knowLantern}
* "Gold."  -> am.offergold {if cash>=300}
* "Never mind."  -> am.hub

# am.offerinfo
magistrate: Information is not a bribe. Information is evidence. Give it to me in the circle, where it belongs.
magistrate: ...But tell me the name, so I'll know where to look.
* "Lady Ottilie Brand."  -> am.ottilie {if flag:knowOttilie}
* "Project LANTERN. A man called Harrow."  -> am.lantern {if flag:knowLantern}

# am.ottilie
magistrate: Ottilie. The accountant. Grey pearls. She sat on my left at the last four Tribunals and took notes for the Prince.
magistrate: ...She took a great many notes.
{do flag:magOttilie=1}
@next am.hub

# am.lantern
magistrate: LANTERN. I know the name. The Prince's ghouls have whispered it for twenty years. I assumed it was a hunters' society. They come and go like weather.
magistrate: You're telling me it's still raining.
{do flag:magLantern=1}
@next am.hub

# am.offergold
> You hold out the money. He doesn't look at it.
magistrate: Put it away before Gregory sees it and has to do something unpleasant.
magistrate: Six hundred years, and every one of them thinks gold is the thing. If gold were the thing, I'd have retired to Biarritz in 1650.
{do lean:candour-1; rel:magistrate-1; flag:magBribe=1}
@next am.hub

# am.lamps
magistrate: The lamps.
> He waits. You tell him. The vault under the grates. The quartz. The switch on Ferrier Lane. One o'clock.
> He listens without moving at all. When you finish, a train goes over. He lets it pass.
magistrate: If you are lying, I will know, and the law will know, and on Friday I will find you guilty of perjury before I even reach the murder.
magistrate: If you are not lying, then someone intends to burn the whole Ward, including me, at my own Tribunal. Which would be a breach of etiquette I've not seen since the Avignon schism.
* "Postpone it."  -> am.postpone
* "Move it."  -> am.move
* "Hold it. With the lamps under you. Let them see you not flinch."  -> am.hold {do lean:pride+1}

# am.postpone
magistrate: A Tribunal, once called, cannot be postponed. That is the first rule, from before Avignon. If I postpone it, I am not the law. And then there is no law, and the Ward goes to war by Monday.
magistrate: No. It will be held. One o'clock. On Platform 0.
magistrate: ...But I will send Gregory to look at this vault. Tonight. Quietly.
{do flag:magVault=1}
@next am.hub

# am.move
magistrate: Move it. Where? The Court will not go to the Syndicate's ground, the Syndicate won't go to the Court's. Platform 0 was chosen because it is nobody's. That's why it's a trap. Clever.
magistrate: No. It stays. But I will send Gregory to look at this vault.
{do flag:magVault=1}
@next am.hub

# am.hold
magistrate: Hold it. With a bomb under my chair.
> And then, for the first time, he laughs. It's an extraordinary noise, like a cupboard that hasn't been opened since the Directoire.
magistrate: Absalom would have said that. Yes. Very well. I shall sit in my chair with the lamps under me, and I shall not flinch, and if anyone presses a switch I shall be extremely put out.
magistrate: Gregory will check the vault. And I will be ready.
{do flag:magVault=1; flag:magReady=1; rel:magistrate+1}
@next am.hub

# am.hub
* "Tell me about the Prince."  -> am.prince {once}
* "What happens to me if I win?"  -> am.win {once}
* "What happens to me if I lose?"  -> am.lose {once}
* "Do you ever get tired, Ambrose?"  -> am.tired {once} {if seen:am.vanein|seen:am.vane}
* "The next train. I'll go."  -> am.bye

# am.prince
magistrate: The Prince is the Prince. She has held the city since 1871. She has not been seen by anyone, myself included, since 1912. She sends her will by letter, left on the hall table, answered by morning.
magistrate: She does not care who wins on Friday. She cares that someone does, and that the Ward is quiet by Monday. Make it quiet, and she'll confirm you by nightfall Saturday without ever seeing your face.
magistrate: Make it loud, and she'll send someone. She has only sent someone twice. The second time, it was me.
@next am.hub

# am.win
magistrate: If you are acquitted, you leave the circle with Absalom's blood and Absalom's coat and Absalom's enemies. The Court will offer you the Sheriff's chair, because it is empty, and because nobody else will sit in it.
magistrate: Take it or don't. Either way, you'll be the most interesting thing in the Ward. I would not recommend it.
@next am.hub

# am.lose
magistrate: You'll be taken to the top of the Switchyard stairs at 6:52 and left there, facing east. The Court will watch through smoked glass. I will stand beside you until it's done. I always do. Nobody should burn alone.
tenant: He does. He did it for the Lisbon boy. He held his hand.
@next am.hub

# am.tired
> He doesn't answer for the length of a whole train.
magistrate: I am the oldest thing in this city that still talks. Older than the Prince by forty years. I have seen nine plagues, four wars, and the invention of the pneumatic tyre.
magistrate: Every night I put on the red robe and I am the law. And every dawn I take it off and I am an old man in a car under a railway bridge with nobody to have Christmas Eve dinner with.
magistrate: Yes. I am tired. Thank you for asking. It's the first time in two hundred years.
{do rel:magistrate+2; mem:magistrate:tired; comp+1}
@next am.hub

# am.bye
> The train comes. The car shakes. When it's passed, the door is open, and Gregory is holding the umbrella.
magistrate: Until one o'clock. Don't be late. Lateness is contempt.
{do flag:petitionDone=1; task:s_petition=done; xp:60:The Black Car}
@end
`,'c_magistrate');

/* consequences in the Tribunal */
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;
NL.EXTRAS.ghoulchauffeur={n:'Gregory',color:'#8a8070',role:'The Magistrate\'s chauffeur',spec:{face:{long:1.1,cheek:1.0,jaw:1.3},skin:[.82,.74,.7],hair:{style:'short',color:[.4,.4,.4]},coat:{color:[.08,.08,.1],length:.8,collar:true},shirt:[.9,.9,.9],hat:{type:'chauffeur'}}};
const st0=ENC.tribunal.start;
ENC.tribunal.start=function(S,G){const r=st0.call(this,S,G);const f=S.flags;
  if(f.magFair)r.threat=Math.max(0,r.threat-1);
  if(f.magHeardVane)r.prog+=1;
  if(f.magBribe)r.threat+=1;
  return r;};
const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);const f=S.flags;
  if(f.magRules&&!f.accuserLied)M.push({t:'"Magistrate. Rule three. The Accuser has lied in the circle."',once:'tb_rule3',ck:{sk:'web',dc:13,id:'tb_rule3',mod:S=>(S.flags.knowSevHarrow?3:0)+(S.flags.sevConfessed?4:0)+(S.flags.ottilieExposed?2:0)},
    ok:(st,S)=>{st.prog+=5;S.flags.accuserLied=1;return [T('You lay it out, piece by piece: what Séverine said, what Séverine knew, what Séverine did on Monday morning and when.'),L('magistrate','...Lady Séverine. Did you, or did you not, speak with the man Harrow before the Sheriff died?'),T('Séverine opens her mouth. Closes it. Three hundred Kindred watch her try to find a sentence that is not a lie.'),L('magistrate','Rule three. Avignon, 1381. The case is void.')];},
    no:st=>{st.threat+=2;return [L('magistrate','A serious charge. Unsupported. I would think very carefully before making it twice.')];}});
  if(f.magVault)M.push({t:'Look to the Magistrate\'s chauffeur at the edge of the platform. Gregory nods once.',once:'tb_greg',ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [T('Gregory steps forward and whispers in the Magistrate\'s ear. The Magistrate\'s face does not move. He glances, very slightly, at the iron grates under the platform.'),L('magistrate','...Proceed. And let it be noted that the Court of the Marrow Ward will not be hurried by anyone, above ground or below it.')];}});
  if(f.magHeardVane&&(f.chord||S.sync>=40))M.push({t:'"Ambrose. The goat."',once:'tb_goat',ok:st=>{st.prog+=2;return [T('Three hundred Kindred have no idea what that means. One of them does.'),T('The Magistrate takes out a white linen handkerchief, very old, with a brown stain in one corner, and holds it in his lap through the rest of the Tribunal.')];}});
  return M;};
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.petitionDone&&f.magHeardVane&&!f.massacre)o.push(['Magistrate Ambrose','Had dinner on Christmas Eve for the first time since 1961, in a black car under a railway bridge, with a Sheriff who was two people. Neither of them ate. They talked about a goat.']);
  else if(f.petitionDone&&f.magReady&&!f.massacre)o.push(['Magistrate Ambrose','Sat in his chair at one o\'clock with the lamps beneath him, and did not flinch, and was extremely put out.']);
  return o;});
})();
