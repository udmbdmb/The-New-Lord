'use strict';
/* THE NEW LORD — dreams, part two: what the day-sleep shows you, depending on who you were and what you've chosen */
NL.Script.add(String.raw`
// NIGHT ONE · the paramedic
# dxP.0 dream=1 if=past:paramedic prio=2
> The back of an ambulance, at night, doors open on a wet street. The blue light going round and round on the ceiling like a slow carousel. On the gurney, under the blanket: the Sheriff, in his greatcoat, with ash where his face should be.
> Your hands are already doing it. Pads on the chest. Two fingers at the throat. Nothing. There's never going to be anything.
tenant: (from the gurney, perfectly calm) You can stop, you know. I've been dead since 1787. You're not going to get a rhythm.
* "Stay with me."  -> dxP.1
* Stop. Sit back. Take off the gloves.  -> dxP.2

# dxP.1
tenant: ...Yes. You said that on Monday too. You say it to everyone. I could tell. I know. I know. It still works on me every time.
> The ash where his face was isn't ash any more. It's a face. Long, thin, with a scar through one eyebrow. He's looking up at the blue light going round.
tenant: Pretty. I never rode in one of these. Not once in two hundred years. Is this what it's like? The blue, and somebody holding your hand?
{do sync+2; comp+1}
@next dxP.end

# dxP.2
> You take the gloves off. You sit back on the bench. He turns his head, very slowly, ash moving like sand, to look at you.
tenant: Good. Good. That's the hardest thing in your job, isn't it. Knowing when to sit back.
tenant: You'll have to do it for me one day. Not yet. But one day. Sit back and let me go. You'll be good at it. You've had practice.
{do sync+1}
@next dxP.end

# dxP.end
> The doors of the ambulance close by themselves. The siren starts, very far away, and doesn't get any closer.
@end

// NIGHT ONE · the litigator
# drLi.0 dream=1 if=past:litigator prio=2
> A courtroom with no ceiling. The jury box full of Kindred in evening dress. The judge's bench empty. You're standing at counsel's table in a dead man's coat, and the man you're defending is sitting next to you, and he's you.
tenant: (from the witness box, in a wig that's much too big) Objection. I'm the victim and nobody's asked me anything.
* "Sustained. Tell the court what happened."  -> drLi.1
* "Overruled. The victim's dead. He doesn't get a say."  -> drLi.2

# drLi.1
tenant: What happened. I went to a freezer to see the sun and a child drank me to stop me seeing it.
tenant: The defence rests. No. Wait. That's your line. I'm sorry. I've always wanted to say it.
> The jury of Kindred applaud, very politely, with gloved hands. The courtroom has no ceiling. Above it, the sky is getting light.
{do sync+2}
@next drLi.end

# drLi.2
tenant: Overruled. Ha. Yes. That's the law, isn't it. The dead don't get a say. That's why we're all so badly behaved.
> He takes off the wig. Underneath, he's bald, which he never was. He looks at it, puzzled.
tenant: That's not mine. That's yours. Your fear, I think. Of being found out. Of being nobody under the wig.
{do sync+1; comp-1}
@next drLi.end

# drLi.end
> The gavel comes down, very far away, with nobody holding it.
@end

// NIGHT ONE · the promoter
# drPr.0 dream=1 if=past:promoter prio=2
> The Velvet Hour, full. Nine hundred people under the disco ball, all of them dancing, all of them with no faces. At the door, holding the clipboard, the Sheriff, in his greatcoat, looking deeply disapproving.
tenant: You're not on the list.
* "It's my club."  -> drPr.1
* "Put me on it."  -> drPr.2

# drPr.1
tenant: Your club. Yes. Of course it is. I can see it in how you're standing. You've stood at this door a thousand nights.
tenant: Go on in, then. Dance. I'll mind the door. I'm terrible at dancing. I'm excellent at doors.
> You go in. You dance. Under the disco ball, the faceless people turn, one by one, and each of them is somebody you knew. Rook. Tiny. Leo, at a back table, with eleven people and a bus joke.
{do comp+2}
@next drPr.end

# drPr.2
tenant: Put you... let me see.
> He looks at the clipboard. He turns the page. He turns another page.
tenant: There's only one name on it. It's mine. Somebody's crossed it out.
tenant: Here. Have my place. I'm not going in anyway.
{do sync+1}
@next drPr.end

# drPr.end
> The last song. Four in the morning. The lights come up and everyone's gone and the floor's covered in glitter and nobody's sweeping it.
@end

// NIGHT ONE · the clerk
# dxC.0 dream=1 if=past:clerk prio=2
> The evidence cage at Precinct 9, but it goes on forever. Shelves of boxes, floor to ceiling, into the dark. Every box is labelled VANE, ABSALOM, with a different year. 1787. 1790. 1849. 1888. 1924. 1926. 1958.
> At the desk, in your chair, signing things in, the Sheriff.
tenant: You'll want these catalogued. I've been very untidy. Two hundred and sixty-three years and nobody ever kept the receipts.
* Open the box marked 1926.  -> dxC.1
* Open the box marked 1958.  -> dxC.2
* "Sign them all in. All of them. I'll take custody."  -> dxC.3

# dxC.1
> Inside: a typist's eraser. A green ribbon. A lock of hair in a twist of Courthouse letterhead. A single sheet of paper with one line typed on it, over and over, the way typists practice: *Agnes Lark, Agnes Lark, Agnes Lark.*
tenant: Close it. Please. Close it.
{do sync+1; comp-1}
@next dxC.end

# dxC.2
> Inside: a man's wedding ring. A child's drawing of a house. A photograph of a family of six at a beach with one face scratched out so hard the paper's torn.
tenant: The Mayor. Yes. I kept it. I kept everything I took out of his head. I don't know why. I thought someone should.
{do sync+1}
@next dxC.end

# dxC.3
tenant: All of them. Chain of custody. On you.
tenant: ...That's a lot of boxes, child.
> He hands you the pen. You start signing. Above the endless shelves, very far up, a strip light flickers on, then another, then a whole row of them, going off into the dark.
{do sync+3; flag:dreamCustody=1}
@next dxC.end

# dxC.end
> The cage door clicks shut. You're on the inside. That seems right.
@end

// NIGHT TWO · Sovereign or Gilded: the court
# drS.0 dream=2 if=clan:sovereign|clan:gilded prio=2
> A ballroom. Candles. Everyone in the Court of Port Vellum in the clothes of 1888, dancing a waltz, and every one of them turns to bow as you come down the stairs. Séverine. Ashby. Lisette, counting your steps. Even the Magistrate.
tenant: (at your shoulder) Don't trust it. This is the dream every Sovereign has on their second night. I had it in Ajaccio. Everyone bows. Nobody means it.
* Bow back. To all of them.  -> drS.1
* Walk down the middle of the floor and don't bow to anyone.  -> drS.2

# drS.1
> You bow. The room goes silent. The music stops. Three hundred Kindred stare at you, bowing to them.
> Then, one by one, they straighten up, and look at each other, and for the first time look like people at a party instead of pieces on a board.
tenant: ...Huh. That isn't how my dream went.
{do lean:pride-1; sync+1}
@next drS.end

# drS.2
> You walk. They part. They keep bowing. Lower, the further you go. By the end of the floor, they're on their knees, foreheads to the parquet.
> It feels wonderful. It feels like warm water. It feels like nothing at all.
tenant: Yes. That's exactly how mine went. You'll have it every night now, until you stop enjoying it. I stopped in about 1950.
{do lean:pride+1}
@next drS.end

# drS.end
> The candles go out one by one, from the far end of the room toward you.
@end

// NIGHT TWO · Rot, Wraith or Stray: the underneath
# drU.0 dream=2 if=clan:rot|clan:wraiths|clan:stray prio=2
> Under the city. Not the cistern, not the Switchyard: somewhere older. Tunnels of brick with water running along the bottom, and on every wall, scratched into the brick, names. Thousands of them. The oldest are in a script you can't read.
tenant: The undercity. Every Kindred who wasn't Court. Every one of them scratched their name here, once, so somebody would know. The Court never comes down. I never came down. Not once.
* Find a sharp stone. Scratch your name.  -> drU.1 {if name}
* Find a sharp stone. Scratch his name.  -> drU.2
* Read the names. As many as you can.  -> drU.3

# drU.1
> You scratch it. CASEY MORROW. Under it, without meaning to, you scratch a number: 8.
tenant: Eight. Yes. That's you. That's what they called you. Now it's here, on the wall, with everyone else who was a number to somebody.
{do comp+1}
@next drU.end

# drU.2
> ABSALOM VANE. It takes a long time. The stone is blunt and the brick is hard.
tenant: You... I'm not supposed to be down here. I was Court. Two hundred years of Court.
tenant: ...Thank you. Nobody would have put me here. I'd never have put myself here. Thank you.
{do sync+3}
@next drU.end

# drU.3
> You read. BROTHER WICK. MATHILDE. ONE-EYED SAL. DANNY BOY. THE GIRL FROM THE GRAIN BOAT. FERRYMAN. MOTHER (crossed out) SOOT. Pages and pages of them, going round the bend of the tunnel and on into the dark.
tenant: Wick. There's Wick. Oh, God. Wick.
{do comp+1; sync+1}
@next drU.end

# drU.end
> The water along the bottom of the tunnel starts to rise, very gently, warm as a bath.
@end

// NIGHT THREE · Glass or Moth: the windows
# drG.0 dream=3 if=clan:glass|clan:moths prio=2
> A corridor of windows, or screens, or both. Behind every one, someone you've met this week, alone, doing the thing they do when nobody's looking. Miller asleep in her car. Tariq writing in his notebook. Leo practising a bit to the bathroom mirror. Séverine, in the crypt, humming four notes.
tenant: You can see all of them. You know that. Whenever you like. That's what you are now.
* Close every window. One by one.  -> drG.1
* Keep looking. Just at one.  -> drG.2

# drG.1
> You close them. Every one. Miller. Tariq. Leo. Séverine. The corridor gets darker each time, until there's only the sound of your footsteps and his.
tenant: Good. Good. Most of your line never close a single one. They go mad from it, in the end. Too many windows.
{do lean:restraint+1; comp+1}
@next drG.end

# drG.2
> You choose one. Behind the glass: a woman on the coast, at a kitchen table, with a phone in front of her, not ringing. Robin. Your sister. Waiting for it to ring. She's been waiting for a year.
tenant: Ah. Yes. That one. Of course that one.
{do comp-1; flag:dreamRobin=1}
@next drG.end

# drG.end
> One by one, the screens go to static. Then to black. Then to your own face, which you haven't seen in a week, and which you don't recognize.
@end

// NIGHT THREE · Butcher or Hound: the body
# drB.0 dream=3 if=clan:butchers|clan:hounds prio=2
> Running. On all fours, through a forest you've never seen, under a moon too big for the sky. Your body is doing it without you. Every muscle, every tendon. You can feel the shape of yourself the way you'd feel a coat.
> Beside you, running too, a heron. A grey heron, long-legged, cross, keeping up somehow.
tenant: (from the heron) This is undignified. This is extremely undignified. I've never run in my life.
* Stop. Wait for him.  -> drB.1
* Run faster. See if he can keep up.  -> drB.2

# drB.1
> You stop. The heron stops. It stands on one leg in the moonlight and glares at you.
tenant: Thank you. Thank you. Two hundred years I've been the one people wait for. It's nice to be waited for because I'm slow, and not because I'm important.
{do sync+2}
@next drB.end

# drB.2
> You run. The forest blurs. Behind you, the heron, and then not behind you, and then very far behind, a grey shape on the moon, and then gone.
> You run alone for a long time. It's glorious. It's lonely. When you stop, you don't know where you are.
{do sync-1; comp+1}
@next drB.end

# drB.end
> The moon goes down behind the trees like a coin into a slot.
@end

// NIGHT THREE · Choir: the hymn
# dxH.0 dream=3 if=clan:choir prio=2
> A cathedral that's all voices. No walls, no stone: the shape of it is made of people singing, hundreds of them, so many that the sound becomes a building you can walk around in. You can see the bass notes holding up the roof.
> Somewhere high in the vaulting, one voice is singing four notes over and over, and it's flat, and it's lonely, and it's Séverine at seventeen.
* Sing the next note.  -> dxH.1
* Just listen.  -> dxH.2

# dxH.1
> You sing it. It comes out of you without your having learned it: the fifth note, the one after her four, the one nobody's sung for two hundred years.
> The four notes stop. Then they start again, and this time there are five, and then six, and the cathedral of voices tilts toward the two of you like a field of wheat in a wind.
{do flag:dreamKyrie=1; comp+2}
@next dxH.end

# dxH.2
> You listen. Four notes. Four notes. Four notes. Very far away, very high up, very much alone.
{do comp+1}
@next dxH.end

# dxH.end
> The voices fall silent all at once, as if somebody in the front row has raised a hand.
@end

// NIGHT FOUR · after the Bidding
# drK.0 dream=4 if=flag:pact prio=3
> The Sheriff's study. Every chair occupied. Séverine in the wing chair. Malakor on the floor, too big for any of the furniture. Miller by the window with her hat on. Mother Soot in the fireplace, which isn't lit. Dutch on a stool. Harrow standing in the doorway, not coming in.
> They're all looking at you. They're all waiting for you to pick one.
tenant: You did. You did pick one. Last night. They don't know yet. In the dream, they never know.
@gate flag:pact=lantern ? drK.lan : drK.1

# drK.1
* Go and stand next to the one you chose.  -> drK.2
* Go and stand in the middle of the room, with all of them.  -> drK.3

# drK.2
> You walk across the study. Everyone watches. You stand next to the one you chose, and they look up at you, and the others, all of them, very slowly, fade, like photographs left in a window.
tenant: That's how it works. That's what choosing is. Everyone else gets a little fainter.
{do comp+1}
@next drK.end

# drK.3
> You stand in the middle. Nobody fades. They all keep looking at you. Nobody says anything. It's very crowded and very warm.
tenant: You can't stand in the middle forever, child. Nobody can. But you can stand there for one night. In a dream. Go on. I'll keep watch.
{do sync+1; comp+1}
@next drK.end

# drK.lan
> You look at Harrow, in the doorway. He looks back. Then he looks at all the others, sitting in the study, and he turns off the light.
> In the dark, you can hear all of them breathing. Even the ones who don't.
tenant: ...
{do comp-2; sync-2}
@next drK.end

# drK.end
> The study clock strikes four. The window gets very slightly grey. Everyone in the room, at once, looks toward it.
@end
`,'c_dreams2');
