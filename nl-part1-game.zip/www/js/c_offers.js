'use strict';
/* THE NEW LORD — "The Bidding": on Thursday every power in the Ward makes the new Sheriff an offer. You can only really take one. */
(function(){const {L,T,C,ENC}=NL.DSL;
NL.TASKS.s_bidding={n:'The Bidding',xp:40,cat:'side'};
if(ENC.tribunal){const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);const f=S.flags,p=f.pact;
  if(p==='court'&&!f.sevDead&&!f.pactFalse)M.push({t:'Look at Séverine. Remind her, with your eyes, what she offered on Thursday.',once:'tb_pcourt',ok:st=>{st.threat=Math.max(0,st.threat-3);return [T('The Accuser\'s next question dies in her mouth. She looks at the Magistrate, at you, at the chalk.'),L('severine','...The Accuser withdraws the charge of theft of station. The Court will consider the station... fairly acquired.'),T('A gasp, along the benches. Somebody from the Syndicate laughs out loud.')];}});
  if(p==='syndicate'&&!f.malakorDead)M.push({t:'"Malakor. You said you\'d speak."',once:'tb_psyn',ok:st=>{st.prog+=2;return [T('Malakor stands up from the Syndicate bench like a building deciding to move.'),L('malakor','I built the lance. Everybody knows it. I built it for money and I\'d build it again. I\'ll tell you who bought it, and I\'ll tell you who didn\'t fire it. The thief in the coat didn\'t fire it. I\'d stake my twelfth face on that.')];}});
  if(p==='mortal'&&!f.millerDead)M.push({t:'"There\'s a mortal detective at the top of the stairs with a banker\'s box of case files. She came because I asked."',once:'tb_pmort',ok:st=>{st.prog+=2;st.threat+=1;return [T('Three hundred Kindred turn to look up the Switchyard stairs. Ines Miller is standing there in her wet hat with a banker\'s box under one arm. She doesn\'t come down. She doesn\'t have to.'),L('magistrate','A mortal. At a Tribunal. Of her own will. Hm.'),L('magistrate','...Case files. Leave them on the step, Detective. And then forget the way here. Please.')];}});
  if(p==='wraiths')M.push({t:'Listen. The pipes are talking. Mother Soot promised.',once:'tb_pwr',ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [T('Every drain on Platform 0 begins, at once, very softly, to speak. Not words. The ghost of words. A man\'s voice in an expensive car: *Friday. Make sure the Magistrate sees the lance.*'),T('On the Court benches, Lord Ashby goes the color of chalk.')];}});
  if(p==='union'&&f.side_union)M.push({t:'"Local 0. Stand up."',once:'tb_puni',ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [T('Sixty-three clanless Kindred stand up at the back of the platform at once, in their least-ripped jeans, with their thermoses. Nobody says anything. They just stand.'),L('magistrate','...Noted. Sit down, all of you. I can see you. Everybody can see you. That was the point, I imagine.')];}});
  if(f.lanternRefused&&!f.harrowDead)M.push({t:'"LANTERN offered me daylight on Thursday, if I gave them the Court. I said no. I\'m standing here instead."',once:'tb_plan',ok:st=>{st.prog+=2;return [T('It goes through the platform like a draught. Some of them didn\'t know there were offers. All of them know what daylight means.'),L('magistrate','Daylight. They offered you daylight. And you came down here to be burned.'),L('magistrate','...That is either the most loyal thing I have heard in two hundred years, or the stupidest. I will think about which.')];}});
  return M;};}
})();
NL.Script.add(String.raw`
# bd.sev arc=severine night=4 label="\"You wanted to see me, my lady. Alone.\"" if=alive:sev&!flag:pact&!flag:bd_sev prio=6
@focus severine
{do flag:bd_sev=1; task:s_bidding}
severine: I did. Sit. No, not there. That chair was Absalom's. Sit in the other one, you'll seem humbler.
severine: Here is my offer. It's the only time I'll make it, so listen with both ears and whatever else you have.
severine: Tomorrow, in the chalk, I can accuse you of murder, diablerie, and theft of station. Or I can accuse you of murder and diablerie, and let the theft go. Without the theft, the Magistrate has to find you a killer who happens to have kept the job. That's not a crime. That's the Court's oldest tradition.
severine: In return, you are my Sheriff. Not the Court's. Mine. When I say a name, you go and find it. When I say stop, you stop. For ten years. Then we'll see.
* "Done. Ten years."  -> bd.sev1
* "No. I'll take my chances in the chalk."  -> bd.sev2
? velvet 12 "Five years. And you never say a name I haven't heard first."  -> bd.sev3 | bd.sev4 {id bd_sev}
* "Done." (You don't mean it.)  -> bd.sev5

# bd.sev1
severine: Ten years. Good. Ten years go very quickly. Absalom used to say that. Then he'd look at me as if I were the reason.
> She offers you her gloved hand. You kiss the air above it, the way the Tenant knows how. She notices. Of course she notices.
{do flag:pact=court; rel:severine+3; lean:loyalty+1; lean:pride+1; xp:40:The Bidding}
tenant: Ten years as Séverine's dog. I did forty as the Prince's. It's a living. Of a sort.
@end

# bd.sev2
severine: Your chances. In the chalk. With three hundred Kindred who've never heard of you and one who has.
severine: Very well. I'll be very fair tomorrow. You'll hate it more than if I weren't.
{do rel:severine-1; flag:refused_court=1}
@end

# bd.sev3
> The fan stops. Starts again. Slower.
severine: Five years. And I give you the names in advance, like a menu, so you can send back anything you don't like the taste of.
severine: ...Absalom never once negotiated with me. Not in a hundred years. He just said no and then did it anyway. Five years. Done.
{do flag:pact=court; flag:pactTerms=1; rel:severine+2; xp:50:The Bidding}
@end

# bd.sev4
severine: Five. Five years. With conditions. Darling, you're four nights old. Ten, or the chalk.
* "Ten, then."  -> bd.sev1
* "The chalk."  -> bd.sev2

# bd.sev5
> You say it. You say it beautifully. She hears every word.
severine: Good. Then we understand each other.
> She doesn't, and she does. You can see her decide to let it be true until Friday.
{do flag:pact=court; flag:pactFalse=1; lean:candour-2; rel:severine+1}
tenant: Oh, child. She knows. She's always known when somebody in that chair is lying. She's letting you. Ask yourself why.
@end

# bd.mal arc=malakor night=4 label="\"You sent for me, Malakor.\"" if=!flag:malakorDead&!flag:pact&!flag:bd_mal prio=6
@focus malakor
{do flag:bd_mal=1; task:s_bidding}
malakor: I sent for the Sheriff. You came. That's a start.
malakor: Here's how it is. Tomorrow I'm going to be in the chalk, one way or another. The lance is mine. Everybody knows. Séverine will try to hang it on me, and Miller's got a theory, and the Magistrate's got eyes.
malakor: I'll stand up and say what happened. That the lance was sold, not fired, by me. That the thief in the coat didn't fire it. That's worth something to you, I think. That's worth your neck.
malakor: In return: the Switchyard is Syndicate. Not the Court's, not the Sheriff's. Ours. You don't come down without knocking. You don't count what goes through. Forever.
* "Done. Forever's a long time, but done."  -> bd.mal1
* "The Switchyard is the Ward's. I can't sell it."  -> bd.mal2
* "Done. And no more weapons for anyone who points them at mortals."  -> bd.mal3

# bd.mal1
malakor: Forever. Ha. Absalom used to say "forever" like it was a weekend. Good. Shake.
> His hand closes around yours like a vice made of meat. It's warm. It shouldn't be.
{do flag:pact=syndicate; rel:malakor+3; lean:pride-1; xp:40:The Bidding}
@end

# bd.mal2
malakor: The Ward's. You sound like Dutch. You sound like a man with a bedsheet.
malakor: ...Fine. Fine. I'll stand up tomorrow anyway, probably. I like a show. But I'll take my time getting up.
{do rel:malakor-1; flag:refused_syn=1}
@end

# bd.mal3
malakor: No weapons for... you're negotiating. In my shop. With my saw on the bench.
? stagecraft 11 "Look at the saw. Then look at me. I'm not the one who's frightened in this room, Malakor."  -> bd.mal4 | bd.mal5 {id bd_mal}

# bd.mal4
> He looks at the saw. He looks at you. Then, slowly, enormously, he laughs.
malakor: Fine! Fine. No more lances for people who want them for mortals. It's bad for business anyway. Gets the Ward noticed. Shake, nephew.
{do flag:pact=syndicate; flag:pactTerms=1; flag:noLances=1; rel:malakor+2; xp:50:The Bidding}
@end

# bd.mal5
malakor: Frightened. Of you. Ha. Don't push it, little thief. The offer was the Switchyard. Take it or leave it.
* "Taken."  -> bd.mal1
* "Left."  -> bd.mal2

# bd.mil arc=miller night=4 label="\"You look like you've decided something, Detective.\"" if=!flag:millerDead&!flag:pact&!flag:bd_mil&rel:miller>=2 prio=6
@focus miller
{do flag:bd_mil=1; task:s_bidding}
miller: I have. You're going to hate it.
miller: I've got enough. The clinic list. A pay stub that says LANTERN RESEARCH LLC. A man who rides the 9 all night and should be dead.
miller: And seven files the Captain signed out and never signed back in. The clerk's copies. {if flag:sevenFilesFound}
miller: That's enough to get a federal judge out of bed. That's enough to blow LANTERN's whole program open, in daylight, with cameras.
miller: But I'm one cop. I need someone who can walk into places I can't. And I need to know, when I blow it open, that the people who live in the Marrow Ward at night don't get blown open with it.
miller: So. Partners. You help me take LANTERN down, the mortal way. I keep your people out of the files. You keep your people off mine. Deal?
* "Deal. Partners."  -> bd.mil1
* "My people won't stay off yours, Miller. I can't promise for them."  -> bd.mil2
* "I can't. If you go public, the whole Ward burns."  -> bd.mil3

# bd.mil1
> She holds out her hand. You take it. She doesn't flinch at the cold. She's been holding cold coffee all week.
miller: Partners. God help me. My mother would light a candle.
{do flag:pact=mortal; rel:miller+3; lean:mercy+1; lean:candour+1; xp:40:The Bidding; promise:millerpact:Keep the Ward's people out of Miller's files.}
@end

# bd.mil2
miller: No. You can't. Nobody can promise for a city. I know that better than anybody.
miller: Then promise for you. Just you. That'll have to do.
* "Just me. I promise."  -> bd.mil1
* "I can't even do that."  -> bd.mil3

# bd.mil3
miller: Burns. The whole Ward. You think I don't know there's something living in the dark down here? I've known since 2011. I'm not stupid. I'm just tired.
miller: Fine. Then I'll do it alone. Slower. Without you.
{do rel:miller-1; flag:refused_mort=1}
@end

# bd.soo arc=soot night=4 label="\"You've been waiting for me, Mother.\"" if=!flag:pact&!flag:bd_soo prio=6
@focus soot
{do flag:bd_soo=1; task:s_bidding}
soot: Waiting. I'm always waiting. That's what a cistern is for.
soot: Every snake in the Ward will offer you something tomorrow and tonight. Séverine offers you her leash. Malakor offers you his stairs. The policewoman offers you her conscience, which is heavier than either.
soot: I offer you my ears. Tomorrow, in the chalk, when you need something said that nobody will say, the pipes will say it. Every drain on Platform 0 is mine.
soot: In return: when I'm gone, the seat. My seat. On the step. With the candles. Not tomorrow. Not for a hundred years. But when it's time, you come down the stairs and you sit, and you listen, and you don't run away. They all run away.
* "When it's time. I'll sit."  -> bd.soo1
* "I can't promise a hundred years from now."  -> bd.soo2

# bd.soo1
soot: You'll sit. Good. Good. I'll hold you to it. I'll be listening, even after.
> She takes a candle from the box and lights it and puts it in your hand. Tallow. It doesn't drip.
soot: Keep that somewhere. When it goes out, I've gone, and you're late.
{do flag:pact=wraiths; flag:sootSeat=1; rel:soot+3; lean:loyalty+1; xp:40:The Bidding}
@end

# bd.soo2
soot: No. Nobody can. I asked anyway. I always ask.
{do rel:soot+1; flag:refused_wr=1}
@end

# bd.dut arc=dutch night=4 label="\"Dutch. The sixty-three want something.\"" if=flag:side_union&!flag:pact&!flag:bd_dut prio=6
@focus dutch
{do flag:bd_dut=1; task:s_bidding}
dutch: They want a seat. That's all. That's always all. One seat, at whatever table the new Sheriff sits at. Not a big one. A stool.
dutch: We'll stand up tomorrow. All of us. In front of the Court. That's sixty-three Kindred the Court's pretended don't exist for a hundred years, standing up for you. That's worth something.
dutch: And afterwards, the stool. Every council, every Tribunal, every meeting where they decide who eats and who doesn't. One of us on a stool. With a napkin.
* "A stool. Done."  -> bd.dut1
* "Not a stool. A chair. Same as anyone."  -> bd.dut2
* "I can't promise them a seat at a table I don't own yet."  -> bd.dut3

# bd.dut1
dutch: A stool. Ha. Little Sal's going to cry. Little Sal cries at everything.
{do flag:pact=union; rel:dutch+3; lean:pride-1; xp:40:The Bidding; promise:stool:Give Local 0 a seat at every table.}
@end

# bd.dut2
> Dutch stares at you. Then he takes off his cap. He's never taken off his cap.
dutch: A chair. Same as anyone.
dutch: ...I'm going to need a minute. Turn round. Don't look at me.
{do flag:pact=union; flag:pactTerms=1; rel:dutch+4; lean:pride-2; xp:50:The Bidding; promise:stool:Give Local 0 a chair at every table.}
@end

# bd.dut3
dutch: No. Course not. You're like all of them, then. Sorry. No. You're not. You're just honest about it. That's almost worse.
{do rel:dutch-1; flag:refused_uni=1}
@end

# bd.har arc=harrow night=4 label="\"Agent Harrow. You've been following me all night.\"" if=!flag:harrowDead&met:harrow&!flag:bd_har prio=6
@focus harrow
{do flag:bd_har=1; task:s_bidding}
harrow: Following. Observing. You're very observable. You glow, a little, in infrared. Did you know that? Like a stove.
harrow: I'll be quick. I'm authorized to make you an offer. Tomorrow night, at the Switchyard, the whole Court will be in one room for the first time in a hundred years. We'd like to know which room. Which entrance. Which time.
harrow: In return: the cure. Not the one that failed on the fourth floor. The one that's working. The next batch. You walk out of that Switchyard before one o'clock and you never come back, and on Saturday morning you stand in the sun on the pier at Bayside and you watch it come up.
harrow: Daylight. That's the offer. Nobody else in this city can make it.
* "No."  -> bd.har1
* "...Tell me more about the cure."  -> bd.har2
* "Yes."  -> bd.har3

# bd.har1
harrow: No. Just no. You didn't even think about it.
harrow: ...You know what, I believe you. That's the worst thing about you people. I keep believing you.
{do flag:lanternRefused=1; lean:loyalty+2; rel:harrow-1}
tenant: (very quietly) Daylight. He offered you daylight. I'd have thought about it. I'd have thought about it for a week.
@end

# bd.har2
harrow: It works. Your cohort stood in it for minutes. Danielle Okafor stood in it for twenty-two. The next batch is better. A Kindred could have twenty years of mornings.
harrow: You'd be the first Sheriff ever to see a sunrise. You'd be the first anything.
* "And everyone in that room burns."  -> bd.har4
* "Give me until midnight."  -> bd.har5

# bd.har4
harrow: Everyone in that room is a predator who's been eating this city for two hundred years. Yes. They burn. That's what the lamps are for.
harrow: You were a person a week ago. Remember that. You were a person, and they made you this.
* "No. I said no."  -> bd.har1
* "...Midnight. I'll call you at midnight."  -> bd.har5

# bd.har5
harrow: Midnight. Call the number on the card. If you don't call, the offer's gone and I'll assume the answer's no and act accordingly.
> He hands you a card. Plain white. A phone number, nothing else.
{do flag:harrowCard=1; flag:lanternWaver=1; lean:loyalty-1}
tenant: Child. Child. Whatever you decide. Decide it before midnight, not at it.
@end

# bd.har3
> He blinks. He wasn't expecting it.
harrow: Yes.
harrow: ...Okay. Okay. Tomorrow. Text me the entrance and the time. Then walk away. Don't look back. People who look back are always the ones who get caught in the light.
{do flag:pact=lantern; flag:lanternYes=1; lean:loyalty-3; lean:candour-1}
tenant: ...
tenant: I'm still here. I'll still be here. I just want you to know I heard you say it.
@end

# bd.harN arc=tenant night=4 label="\"What would you do? Harrow's offer.\"" if=flag:harrowCard&!flag:lanternRefused&!flag:lanternYes prio=7
@focus tenant
tenant: What would I do.
tenant: I'd want it. God, I'd want it. I haven't seen the sun since a hillside in Corsica in 1787. I remember it the way you remember being a child: the shape of it, not the feeling. Warm. It was warm.
tenant: And then I'd think of Pemberton. And Séverine, God help me. And Valko. And Lisette counting the bottles. And Dutch and his stupid bedsheet. All in one room, burning, so I could stand on a pier.
tenant: And I'd say no. Not because I'm good. Because I'd have to live with it in the sunshine. Every single morning. You can't hide from what you did in daylight, child. That's what it's *for*.
* Tear up the card.  -> bd.harN1
* Keep the card. Call him.  -> bd.harN2

# bd.harN1
> It tears very easily. Plain white card. You let the pieces go into the gutter and the rain takes them down the drain toward Soot's cistern, where, presumably, she'll hear them.
{do flag:lanternRefused=1; unflag:lanternWaver; lean:loyalty+2; sync+3}
tenant: Thank you. Thank you. I don't know what for. Thank you.
@end

# bd.harN2
> You take out your phone. You dial. It rings once.
harrow: (on the phone) I knew you'd call. They always call.
{do flag:pact=lantern; flag:lanternYes=1; lean:loyalty-3; sync-5}
tenant: ...
@end

# bd.lyes arc=tenant night=5 label="\"I said yes to Harrow. I can still take it back.\"" if=flag:lanternYes&!flag:lanternBack prio=8
@focus tenant
tenant: Can you. Can you, child? Have you sent him the entrance?
* "Not yet. I'm not going to."  -> bd.lyes1
* "I sent it."  -> bd.lyes2

# bd.lyes1
tenant: Then don't. Don't send it. Let him wait at his van with his phone in his hand until one o'clock, and then let him understand.
{do flag:lanternBack=1; flag:lanternRefused=1; unflag:pact; lean:loyalty+2; sync+3}
tenant: He'll come anyway. You know that. With the lamps. But he'll come blind, and that's something.
@end

# bd.lyes2
tenant: You sent it.
tenant: Then there's still one thing left to do. Go down there. Be in the room. If the light comes, be standing in front of somebody. That's all there is now. That's all there ever is.
{do flag:lanternSent=1; heat+2}
@end
`,'c_offers');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.pact==='court'&&!f.sevDead)o.push(['The Keeper\'s Sheriff',f.pactFalse?'Served Lady Séverine for exactly as long as it suited them, which was eleven months. She was not surprised. She was, she told Ashby, very slightly proud.':f.pactTerms?'Received a list of names from Lady Séverine on the first of every month, in purple ink, and crossed out about a third of them. She never once objected. Five years is not very long.':'Went where Lady Séverine pointed for ten years. Most of the names were people who deserved it. Some were not. The Sheriff kept a list of those, too.']);
  if(f.pact==='syndicate'&&!f.malakorDead)o.push(['The Switchyard','Belongs to the Red Syndicate, by an agreement that was never written down and is never broken. '+(f.noLances?'No more lances have been built there. Malakor complains about it at every opportunity.':'Things go through it. Nobody counts them.')]);
  if(f.pact==='mortal'&&!f.millerDead)o.push(['Detective Miller\'s partner','Is listed, in no official record anywhere, as a "confidential source, night shift". In February a federal grand jury in Philadelphia indicted four people connected to LANTERN RESEARCH LLC. None of them lived in the Marrow Ward.']);
  if(f.pact==='wraiths')o.push(['A tallow candle','Burns, very small, on a shelf in the Sheriff\'s study. It has never dripped. Some nights, if you sit near it, you can hear water.']);
  if(f.pact==='union'&&f.side_union)o.push(['Local 0',f.pactTerms?'Has a chair at every table. An actual chair. Dutch sits in it as if it might be taken away. It never is.':'Has a stool at every table. Dutch brings his own napkin.']);
  if(f.lanternSent)o.push(['A text message, 12:14 a.m., Friday','Sent from a phone that had been in a Sheriff\'s coat pocket. Nobody in the Ward ever found out who sent it. The Sheriff knew. The Sheriff always would.']);
  if(f.lanternRefused)o.push(['A white card with a phone number on it','Went down a drain on Ferrier Lane in pieces on a Thursday night. Agent Harrow waited by his phone until one. Then he understood.']);
  return o;});
