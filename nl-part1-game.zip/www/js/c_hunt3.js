'use strict';
/* THE NEW LORD — more ways to feed, part three: hunts that only some kinds of Kindred would think of */
(function(){const O=NL.Script.opt;
O('hunt.0','* The ER at St. Jude\'s. Your old badge still opens the blood store.  -> hy.medic {if past:paramedic&!flag:hyMedic}',3);
O('hunt.0','* Ferrier Lane. Whistle for the strays, and let them bring you something.  -> hy.dogs {if clan:stray&!flag:hyDogs|clan:hounds&!flag:hyDogs}',3);
O('hunt.0','* The rats. Ask the rats who in the Ward deserves it.  -> hy.rats {if clan:rot&!flag:hyRats}',3);
O('hunt.0','* A man on Kerr Street shouting at a woman in a car. You can hear exactly what he\'s about to do.  -> hy.glass {if clan:glass&!flag:hyGlass|clan:moths&!flag:hyGlass}',3);
O('hunt.0','* The laundromat on Vine. The night-shift sleepers on the bench by the dryers.  -> hy.sleep {if flag:nell=taught&!flag:hySleep|flag:nell=fed&!flag:hySleep}',3);
})();
NL.Script.add(String.raw`
# hy.medic
> Three in the morning. The ambulance bay behind St. Jude's. Your hands know the keypad before you do. Six digits. Your birthday, backwards. The door to the blood store clicks.
> Inside: shelves of bags, labelled, dated, cold. O-negative. A-positive. Somebody's Tuesday donation. Somebody's whole week.
nostalgia: You used to check these. Every shift. Expiry dates. Rotation. You threw out the old ones by hand and felt guilty every time.
* Take the ones expiring tomorrow. Only those.  -> hy.medic1
* Take whatever you need.  -> hy.medic2
* Close the door. You can't.  -> hy.medic3

# hy.medic1
> Three bags with tomorrow's date on them. They'd have gone in the incinerator at six. You drink them in the ambulance bay, sitting on the bumper of Station 4's second rig, where you used to eat your lunch.
> It's cold and it tastes of plastic. It's the most honest meal you've had all week.
{do flag:hyMedic=1; vitae+3; lean:restraint+1; comp+1}
@end

# hy.medic2
> You take what you need. Four bags. Five. Some of them have next month's date.
> On the way out, the door alarm doesn't go off. Your code still works. Nobody ever deleted you. Somewhere in the system you're still on the rota.
{do flag:hyMedic=1; vitae+4; lean:restraint-1; heat+1}
@end

# hy.medic3
> You close it. You stand in the ambulance bay for a while with your hand on the door.
> Somebody, tomorrow, at four in the afternoon, in surgery, will need an A-positive. It'll be there.
{do flag:hyMedic=1; lean:mercy+1; comp+1}
@end

# hy.dogs
> You whistle. Low. The note under the note.
> They come out of the rain one by one: a pit bull with a torn ear, a three-legged mutt, a lurcher, two terriers who are clearly brothers. They sit in a half-circle round you on Ferrier Lane and wait.
* "Find me someone who deserves it."  -> hy.dogs1
* "Find me someone who won't miss it."  -> hy.dogs2
* Change your mind. Scratch the pit bull behind his torn ear.  -> hy.dogs3

# hy.dogs1
> They lead you, at a trot, four blocks, to a car parked behind the Anchor with the engine running. Inside, a man is counting money. A lot of it. In the back seat, tied, a younger man with a bag over his head.
> The dogs sit down in the rain round the car and look at you.
* Feed on the man counting money.  -> hy.dogs4 {blood}
* Open the back door first.  -> hy.dogs5

# hy.dogs4
> He doesn't hear you open the door. He hears you close it.
> Afterwards, he's asleep against the steering wheel, and the money's on the floor, and the younger man in the back seat is making a noise through the bag. You untie him. You don't take the bag off. He runs.
> The dogs escort him to the end of the street, and then they come back for you.
{do flag:hyDogs=1; feed:3:choleric:a man counting money:mortal; comp+1}
@end

# hy.dogs5
> You open the back door. You untie the younger man. You take the bag off. He's twenty, and his eye is swollen shut, and he's looking at you and at the dogs and at the man in the front seat, who's turned round, and who's reaching for something.
> The pit bull gets there first.
> You feed afterwards, on the man in the front seat, who is lying in a puddle with a dog standing on his chest, and who will remember none of it except the dog.
{do flag:hyDogs=1; feed:3:choleric:a man with a gun:mortal; lean:mercy+1; comp+2; heat+1}
@end

# hy.dogs2
> They take you to the bus shelter on Vine, where a man is asleep under a pile of coats with a dog of his own curled on his feet. A grey old collie who looks up, sees the half-circle of strays, and puts her head back down as if to say: him. He won't mind.
> He doesn't. Two mouthfuls. He mutters "thanks, Bess" in his sleep. The collie licks your hand afterwards.
{do flag:hyDogs=1; feed:2:phlegmatic:a man with a collie:mortal}
@end

# hy.dogs3
> He leans into your hand. His whole back leg goes like a motor. The others crowd in, wanting the same.
> You stand on Ferrier Lane in the rain at three in the morning scratching six dogs one at a time and you don't feed and you don't care.
{do flag:hyDogs=1; comp+3}
@end

# hy.rats
> You crouch by the grate on Halloran Street. Under it, a hundred small eyes.
> You ask. They tell you. Not in words. In smells and directions and a sort of rising chitter that means *that one, that one, that one*.
> A landlord on Kerr Street who has turned off the heating in a building full of old women to make them leave. A man in the Heights who poisons the rats in his garden with something that makes them bleed. A cop called Dale.
* The landlord.  -> hy.rats1 {blood}
* The man who poisons them.  -> hy.rats2 {blood}
* Dale.  -> hy.rats3 {blood} {if !flag:daleTalked}

# hy.rats1
> He lives above his office. He sleeps in silk pyjamas. When you're done he's very pale and very tired, and on his bedside table, where he'll see it when he wakes, is a dead rat holding the thermostat dial in its teeth.
> The heating comes on in the building on Kerr Street at 9 a.m. Nobody ever finds out why.
{do flag:hyRats=1; feed:3:choleric:a landlord:mortal; comp+2}
@end

# hy.rats2
> His garden in the Heights is full of little green boxes with skulls on them. The rats won't go in. You do.
> Afterwards you leave every one of the little green boxes on his doorstep, stacked into a neat pyramid, with a single white flower on top that dies in your hand as you set it down.
{do flag:hyRats=1; feed:3:melancholic:a man in the Heights:mortal; comp+1}
@end

# hy.rats3
> Officer Dale is in the Anchor. He comes out at two to smoke. He doesn't come back in until twenty past, and when he does, he's sitting very carefully, and he can't remember why he's afraid of rats now.
{do flag:hyRats=1; feed:3:choleric:Officer Dale:mortal; heat+1}
@end

# hy.glass
> You hear it before you see it. Not the shouting. The thing under the shouting. *She's not leaving. She's not taking the kid. I'll make sure she's not.* Loud and clear, like a radio in your skull.
> A man at a car window on Kerr Street, one hand on the roof, leaning in. A woman in the driver's seat with her hands on the wheel and a child asleep in the back.
* Walk up behind him. Put a hand on his shoulder.  -> hy.glass1
* Let him see your face. Only him.  -> hy.glass2
* Tell the woman, through the glass: "Drive."  -> hy.glass3

# hy.glass1
> He turns round. He sees your eyes. You take him into the alley beside the laundromat, very gently, like an old friend who's had too much.
> In the street, the car pulls away. The woman doesn't look back. The child doesn't wake.
> You drink until his thoughts go quiet. Then a little more, until the loud one, the one about making sure, goes quiet too. You don't know if it'll stay quiet. You hope.
{do flag:hyGlass=1; feed:3:choleric:a man at a car window:mortal; lean:mercy+1}
@end

# hy.glass2
> He looks round. Just him. For half a second you let him see what you are, and what you heard, and what you could do with it.
> He takes his hand off the car roof. He walks away. He doesn't run. He'll walk all the way home with the hair standing up on his neck and he'll never know why he couldn't do it.
> The car pulls away. You don't feed. You weren't hungry for him, anyway. He tasted wrong from across the street.
{do flag:hyGlass=1; lean:restraint+1; comp+1}
@end

# hy.glass3
> She hears you. Through the glass, through the rain, through the man leaning in her window. She doesn't know where it came from. She puts the car in drive.
> He stumbles back. He shouts. She doesn't stop. At the end of Kerr Street her turn signal goes on, left, toward the interstate, toward her sister's, toward anywhere.
> He turns round looking for someone to blame. He finds you. That's fine. You're hungry.
{do flag:hyGlass=1; feed:2:choleric:a man left in the rain:mortal; comp+2}
@end

# hy.sleep
> The laundromat on Vine. Three in the morning. A night porter asleep on the bench by the dryers with his head against the window, exactly where Nell said.
> Nell is there, actually. In the corner, in her too-big coat, with a library book. She looks up and lifts her hand. Like Earl does. {if flag:nell=taught|flag:nell=fed}
> You sit beside him like a friend. Two mouthfuls. From the inside of the wrist. You close it after. When he stirs, you say "you nodded off, you're fine." He says "thanks, love," and goes back to sleep.
{do flag:hySleep=1; feed:2:phlegmatic:a night porter:mortal; lean:restraint+1; comp+1}
@end
`,'c_hunt3');
