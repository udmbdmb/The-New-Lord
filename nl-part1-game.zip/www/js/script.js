'use strict';
/* THE NEW LORD — the dialogue script compiler, reputation, character arcs and dawn dreams.
   Content files call NL.Script.add(String.raw`...`) with a screenplay-like format:

   # node.id  [arc=npc night=2,3 label="..." if=COND prio=N]  [dream=2 if=COND]
   @focus leo           camera on you + leo (enter)
   @do EFFECTS          run on entering the node
   @next other.id       continue to another node after the lines
   @end                 close the conversation after the lines
   @gate COND ? a.id : b.id   branch automatically (next)
   > narration                                {if COND} {do EFFECTS}
   leo: spoken line                           {if COND} {do EFFECTS}
   pulse(4): a voice that only speaks if Pulse-Check >= 4-6
   * "Option text." -> target                 {if COND} {do EFFECTS} {once} {end} {leave} {ab kneel} {blood 1}
   ? velvet 10 "Check option." -> ok | no     {if COND} {do EFFECTS} {red} {id x} {mod TERMS}

   COND  : terms joined by & (and) or | (or), each optionally prefixed with ! :
           flag:x  flag:x=v  flag:x>=2  rel:leo>=1  like:leo>=2  rep:mercy<=-2  has:item  clan:glass  past:paramedic
           night:3  night>=3  time<200  task:s_x=active  done:s_x  seen:node  sync>=50  kills=0  cash>=20  vitae<=2
           heat>=3  alive:leo  met:leo  th:golconda  name  (true when you know your name)  rand<50
   EFFECTS: separated by ;  flag:x=1  flag:x+1  unflag:x  rel:leo+1  lean:mercy+1  xp:30  comp+1  vitae-1  heat+1
           cash-20  give:item  take:item  task:s_x  task:s_x=done  sync+3  fact:leo:key  meet:leo  keep:p  break:p
           promise:p:what  offer:thought  kill  feed:3:choleric:a stranger:mortal  text:From|Body  tick:10  remove:actor
           mem:leo:key (a memory the character keeps)
*/
(function(){
const NL=window.NL,G=NL.G;const {N,L,T,O,C,H}=NL.DSL;

/* =============== reputation =============== */
const AXES={
  mercy:{n:'Mercy',pos:'Merciful',neg:'Ruthless'},
  candour:{n:'Candour',pos:'Honest',neg:'Deceitful'},
  restraint:{n:'Restraint',pos:'Restrained',neg:'Indulgent'},
  pride:{n:'Station',pos:'Courtly',neg:'Street'},
  loyalty:{n:'Faith',pos:'Loyal',neg:'Faithless'}};
// how each person weighs what you've become
const VALUES={
  leo:{mercy:1,candour:1,restraint:.5},miller:{candour:1,mercy:.7,restraint:.7},tariq:{mercy:1,loyalty:1},tiny:{loyalty:1,pride:-.5,mercy:.5},
  gideon:{loyalty:1.2,candour:.4},pemberton:{loyalty:1,pride:.6,mercy:.4},severine:{pride:1.2,candour:-.4,mercy:-.4},malakor:{candour:1,pride:-.6,restraint:-.3},
  soot:{loyalty:.8,candour:-.6,restraint:-.3},valko:{loyalty:1.2,restraint:-.6,pride:.4},rostova:{mercy:1,candour:.8},okafor:{mercy:1,candour:1},
  margo:{mercy:1,loyalty:.5},tenant:{pride:.8,loyalty:.8,restraint:.5},dutch:{pride:-1,loyalty:.8},ottoline:{loyalty:1.5,candour:.5},marek:{candour:1,mercy:.6},
  harrow:{restraint:1,mercy:-.3},kenpruitt:{mercy:.6,candour:.6},ezra:{mercy:1}};
const Rep=NL.Rep={AXES,VALUES};
const st=S=>{S.stance=S.stance||{};return S.stance;};
Rep.raw=(S,k)=>st(S)[k]||0;
Rep.eff=(S,k)=>{let v=Rep.raw(S,k);const f=S.flags||{};
  if(k==='mercy')v-=2*Math.min(S.kills||0,6);
  if(k==='restraint')v-=Math.min(4,(f.breaches||0))+((S.flags.diablerie2)?2:0);
  if(k==='loyalty')v+=Object.values(S.promises||{}).reduce((a,p)=>a+(p.kept===true?1:p.kept===false?-2:0),0);
  return v;};
Rep.like=(S,id)=>{const V=VALUES[id];if(!V)return (S.rel[id]||0);let r=0;for(const k in V)r+=V[k]*Math.max(-4,Math.min(4,Rep.eff(S,k)));return Math.round((r/2)+(S.rel[id]||0));};
Rep.word=(S,k)=>{const v=Rep.eff(S,k),A=AXES[k];if(v>=4)return 'Very '+A.pos.toLowerCase();if(v>=2)return A.pos;if(v<=-4)return 'Very '+A.neg.toLowerCase();if(v<=-2)return A.neg;return 'Undecided';};
G.lean=(k,d)=>{if(!AXES[k])return;const s=st(G.S);s[k]=(s[k]||0)+d;
  const was=G.S.flags['repw_'+k],now=Rep.word(G.S,k);if(now!==was&&now!=='Undecided'){G.S.flags['repw_'+k]=now;setTimeout(()=>G.toast('rel',`The Ward is starting to think of you as <b>${now.toLowerCase()}</b>.`,'Reputation'),900);}};
Rep.html=S=>(NL.Script&&S.flags.woke&&NL.Script.arcFor('tenant',S)?`<section class="attr tenant-talk" style="--c:#9a8cd0"><header><b>The Tenant</b><em>He has something to say.</em></header><button class="bigbtn" id="tenantTalk">Listen to him</button></section>`:'')+`<section class="attr rep" style="--c:#c8a26a"><header><b>Reputation</b><em>What the Marrow Ward thinks you are, from what you've done.</em></header>${Object.keys(AXES).map(k=>{const v=Math.max(-6,Math.min(6,Rep.eff(S,k)));const A=AXES[k];return `<div class="repr"><span>${A.neg}</span><div class="repbar"><i style="left:${50+v/6*50}%"></i></div><span>${A.pos}</span></div>`;}).join('')}</section>`;
// memories: characters remember specific things you did
G.mem=(id,k)=>{const S=G.S;S.mem=S.mem||{};(S.mem[id]=S.mem[id]||[]);if(!S.mem[id].includes(k))S.mem[id].push(k);};
G.remembers=(id,k)=>!!(G.S.mem&&G.S.mem[id]&&G.S.mem[id].includes(k));

/* =============== conditions & effects =============== */
const num=v=>v===''||v==null?NaN:Number(v);
const cmp=(a,op,b)=>{if(op==='=')return a==b||String(a)===String(b);if(op==='!=')return String(a)!==String(b);a=Number(a)||0;b=Number(b);return op==='>='?a>=b:op==='<='?a<=b:op==='>'?a>b:op==='<'?a<b:false;};
function term(S,G,t){t=t.trim();if(!t)return true;let neg=false;if(t[0]==='!'){neg=true;t=t.slice(1);}
  const m=t.match(/^([a-z]+)(?::([^<>=!]+))?(?:(>=|<=|!=|=|<|>)(.+))?$/i);if(!m){console.warn('cond?',t);return false;}
  const [,k,arg,op,val]=m;let v,r;
  if(k==='tier'){v=G.abTier?G.abTier(arg):0;r=op?cmp(v,op,num(val)):v>0;return neg?!r:r;}
  if(k==='used'){v=(S.powerLog||[]).filter(p=>p.ab===arg||p.who===arg).length;r=op?cmp(v,op,num(val)):v>0;return neg?!r:r;}
  switch(k){
    case 'flag':v=S.flags[arg];r=op?cmp(v||0,op,val):!!v;break;
    case 'rel':r=cmp(S.rel[arg]||0,op||'>=',op?val:1);break;
    case 'like':r=cmp(Rep.like(S,arg),op||'>=',op?val:1);break;
    case 'rep':r=cmp(Rep.eff(S,arg),op||'>=',op?val:2);break;
    case 'has':r=G.has(arg);break;
    case 'clan':r=S.clan===arg;break;
    case 'past':r=S.past===arg;break;
    case 'night':r=arg?S.night==arg:cmp(S.night,op,val);break;
    case 'time':r=cmp(S.time,op,val);break;
    case 'task':r=op?cmp(S.tasks[arg]||'none',op,val):!!S.tasks[arg];break;
    case 'done':r=S.tasks[arg]==='done';break;
    case 'seen':r=!!S.seen[arg];break;
    case 'sync':r=cmp(S.sync,op,val);break;
    case 'kills':r=cmp(S.kills||0,op,val);break;
    case 'feeds':r=cmp(S.feeds||0,op,val);break;
    case 'broke':r=Object.values(S.promises||{}).some(p=>p&&p.kept===false);break;
    case 'cash':r=cmp(S.cash||0,op,val);break;
    case 'vitae':r=cmp(S.vitae,op,val);break;
    case 'heat':r=cmp(S.heat,op,val);break;
    case 'comp':r=cmp(S.comp,op,val);break;
    case 'alive':{const AL={pemberton:'pem',pem:'pemberton',severine:'sev',sev:'severine'};r=!S.flags[arg+'Dead']&&!(AL[arg]&&S.flags[AL[arg]+'Dead']);break;}
    case 'met':r=!!S.dos[arg];break;
    case 'th':r=G.thought(arg);break;
    case 'known':r=S.th.known.includes(arg)||G.thought(arg);break;
    case 'name':r=!!S.flags.knowName;break;
    case 'fact':{const [who,key]=arg.split(':');r=!!(S.dos[who]&&S.dos[who].facts.includes(key));break;}
    case 'mem':{const [who,key]=arg.split('.');r=G.remembers(who,key);break;}
    case 'once':r=!S.once[arg];break;
    case 'rand':r=Math.random()*100<Number(val||arg||50);break;
    case 'room':r=S.room===arg;break;
    case 'actor':r=!!G.actor(arg);break;
    case 'leo':r=leoState(S)===arg;break;
    case 'vessel':r=NL.Act.vesselAt?NL.Act.vesselAt(S)===arg:false;break;
    case 'ally':r=NL.Act.allies?NL.Act.allies(S).includes(arg):false;break;
    case 'allies':r=cmp(NL.Act.allies?NL.Act.allies(S).length:0,op,val);break;
    case 'lvl':r=cmp(S.lvl,op,val);break;
    case 'skill':r=cmp(G.skill(arg),op,val);break;
    case 'hav':r=S.hav===arg;break;
    case 'true':r=true;break;
    default:console.warn('cond key?',k);r=false;}
  return neg?!r:r;}
const leoState=S=>S.flags.leoDead?'dead':S.flags.leoGoneTown?'gone':(S.flags.tedState==='thrall'||S.flags.leoGhoul)?'thrall':S.flags.tedState==='forgot'||S.flags.leoFogged?'forgot':'here';
NL.Act.leoState=leoState;
function cond(src){if(!src)return null;const ors=src.split('|').map(o=>o.split('&'));return (S,G)=>ors.some(and=>and.every(t=>term(S,G,t)));}
function effect(S,G,e){e=e.trim();if(!e)return;let m;
  if((m=e.match(/^fx:(\w+)(?::(.*))?$/))){const f=Script.FX&&Script.FX[m[1]];if(f)f(S,G,m[2]);else console.warn('fx?',m[1]);return;}
  if((m=e.match(/^flag:([\w]+)([=+\-])(.*)$/))){const [,k,op,v]=m;if(op==='=')S.flags[k]=isNaN(num(v))?v:num(v);else S.flags[k]=(Number(S.flags[k])||0)+(op==='+'?1:-1)*(num(v)||1);return;}
  if((m=e.match(/^unflag:(\w+)$/))){delete S.flags[m[1]];return;}
  if((m=e.match(/^rel:(\w+)([+\-]\d+)$/))){if(NL.CHARS[m[1]]||NL.EXTRAS[m[1]])G.rel(m[1],Number(m[2]));return;}
  if((m=e.match(/^lean:(\w+)([+\-]\d+)$/))){G.lean(m[1],Number(m[2]));return;}
  if((m=e.match(/^xp:(\d+)(?::(.*))?$/))){G.xp(Number(m[1]),m[2]||'');return;}
  if((m=e.match(/^comp([+\-]\d+)(?::(.*))?$/))){G.comp(Number(m[1]),m[2]);return;}
  if((m=e.match(/^vitae([+\-]\d+)$/))){G.vitae(Number(m[1]));return;}
  if((m=e.match(/^heat([+\-]\d+)$/))){G.heat(Number(m[1]));return;}
  if((m=e.match(/^cash([+\-]\d+)(?::(.*))?$/))){G.cash(Number(m[1]),m[2]);return;}
  if((m=e.match(/^sync([+\-]\d+)(?::(.*))?$/))){G.sync(Number(m[1]),m[2]);return;}
  if((m=e.match(/^give:(\w+)$/))){if(NL.ITEMS[m[1]])G.give(m[1]);else console.warn('item?',m[1]);return;}
  if((m=e.match(/^take:(\w+)$/))){G.take(m[1]);return;}
  if((m=e.match(/^task:(\w+)(?:=(\w+))?$/))){if(!NL.TASKS[m[1]]){console.warn('task?',m[1]);return;}if(m[2]==='done'){if(!S.tasks[m[1]])G.task(m[1]);G.task(m[1],'done');}else G.task(m[1]);return;}
  if((m=e.match(/^note:(\w+)\|(.*)$/))){S.quests['note_'+m[1]]=m[2];return;}
  if((m=e.match(/^fact:(\w+):(\w+)$/))){if(NL.CHARS[m[1]]&&NL.CHARS[m[1]].facts&&NL.CHARS[m[1]].facts[m[2]])G.fact(m[1],m[2]);else if(NL.CHARS[m[1]])G.meet(m[1]);return;}
  if((m=e.match(/^meet:(\w+)$/))){if(NL.CHARS[m[1]])G.meet(m[1]);return;}
  if((m=e.match(/^keep:(\w+)$/))){G.keep(m[1]);return;}
  if((m=e.match(/^break:(\w+)$/))){G.breakPromise(m[1]);return;}
  if((m=e.match(/^promise:(\w+):(.*)$/))){G.promise(m[1],m[2]);return;}
  if((m=e.match(/^offer:(\w+)$/))){if(NL.THOUGHTS[m[1]])G.offer(m[1]);return;}
  if(e==='breach'){G.pendingBreach=true;return;}
  if(e==='kill'){S.kills++;S.lethal[S.night]=(S.lethal[S.night]||0)+1;return;}
  if((m=e.match(/^feed:(\d+):(\w+):([^:]*)(?::(\w+))?$/))){G.feed(Number(m[1]),m[2]==='none'?null:m[2].toLowerCase(),m[3],{kind:m[4]||'mortal'});return;}
  if((m=e.match(/^text:([^|]+)\|(.*)$/))){const f=m[1],b=m[2];setTimeout(()=>G.text(f,b),1200);return;}
  if((m=e.match(/^tick:(\d+)$/))){G.tick(Number(m[1]));return;}
  if((m=e.match(/^remove:(\w+)$/))){const id=m[1];setTimeout(()=>G.removeActor(id),50);return;}
  if((m=e.match(/^mem:(\w+):(\w+)$/))){G.mem(m[1],m[2]);return;}
  if((m=e.match(/^once:(\w+)$/))){S.once[m[1]]=1;return;}
  if((m=e.match(/^shake:([\d.]+)$/))){G.shake&&G.shake(Number(m[1]));return;}
  console.warn('effect?',e);}
function effects(src){if(!src)return null;const list=src.split(';').map(x=>x.trim()).filter(Boolean);return (S,G)=>list.forEach(e=>{try{effect(S,G,e);}catch(err){console.error('effect',e,err);}});}
function mods(src){if(!src)return null;const terms=src.split(',').map(x=>x.trim()).filter(Boolean);
  return (S,G)=>terms.reduce((a,t)=>{let m;if((m=t.match(/^rel:(\w+)$/)))return a+(S.rel[m[1]]||0);if((m=t.match(/^like:(\w+)$/)))return a+Math.max(-3,Math.min(3,Rep.like(S,m[1])));
    if((m=t.match(/^(.+)\?([+\-]?\d+)$/)))return a+(cond(m[1])(S,G)?Number(m[2]):0);return a;},0);}

/* =============== the parser =============== */
const ARCS={};const DREAMS={};const Script=NL.Script={ARCS,DREAMS,count:0,words:0,errors:[]};
function tags(rest){const o={};rest=rest.replace(/\{(\w+)(?:\s+([^}]*))?\}/g,(_,k,v)=>{o[k]=v==null?true:v.trim();return '';});return [rest.trim(),o];}
function attrs(s){const o={};s.replace(/(\w+)=("((?:[^"\\]|\\.)*)"|\S+)/g,(_,k,v,q)=>{o[k]=q!=null?q.replace(/\\(.)/g,'$1'):v;return '';});return o;}
Script.add=function(src,file){let cur=null,id=null,ln=0;
  const close=()=>{if(cur&&id){if(N[id])console.warn('script: overriding node',id);N[id]=cur;Script.count++;}};
  for(let raw of src.split('\n')){ln++;const line=raw.replace(/\s+$/,'');if(!line.trim()||line.trim().startsWith('//'))continue;
    try{
    if(line.startsWith('# ')){close();const m=line.slice(2).match(/^(\S+)\s*(.*)$/);id=m[1];cur={lines:[]};const a=attrs(m[2]||'');
      if(a.arc){(ARCS[a.arc]=ARCS[a.arc]||[]).push({id,nights:a.night?a.night.split(',').map(Number):null,label:a.label||'Talk',if:cond(a.if),prio:Number(a.prio||0)});}
      if(a.street){(Script.STREET=Script.STREET||[]).push({id,nights:a.street.split(',').map(Number),if:cond(a.if),w:Number(a.w||1)});}
      if(a.dream){(DREAMS[a.dream]=DREAMS[a.dream]||[]).push({id,if:cond(a.if),prio:Number(a.prio||0)});}
      continue;}
    if(!cur)continue;const t=line.trim();
    if(t.startsWith('@')){const m=t.match(/^@(\w+)\s*(.*)$/);const k=m[1],v=m[2];
      if(k==='focus'){const ids=v.split(/\s+/);cur.enter=(S,G)=>{const pres=ids.filter(x=>G.actor(x));if(pres.length){G.focus(['you',...pres],.8);G.look(pres[0],'you');G.look('you',pres[0]);}};}
      else if(k==='do'){const f=effects(v);const prev=cur.enter;cur.enter=(S,G)=>{prev&&prev(S,G);f(S,G);};}
      else if(k==='next')cur.next=v;
      else if(k==='end')cur.end=true;
      else if(k==='gate'){const m2=v.match(/^(.+?)\s*\?\s*(\S+)\s*:\s*(\S+)$/);const c=cond(m2[1]);cur.next=(S,G)=>c(S,G)?m2[2]:m2[3];}
      else if(k==='leave'){const who=v.trim();cur.cs=async(G,S)=>{G.dlgHide();const a=G.actor(who);if(a){G.walk(who,a.x+(a.x>5?2.5:-2.5),a.z+1.5);await G.wait(1.4);}G.removeActor(who);};cur.end=true;}
      continue;}
    if(t.startsWith('* ')||t.startsWith('? ')){const isC=t[0]==='?';let [body,o]=tags(t.slice(2));
      const opt={};if(o.if)opt.if=cond(o.if);if(o.do)opt.do=effects(o.do);if(o.once)opt.once=true;if(o.end)opt.end=true;if(o.leave){opt.leave=true;}if(o.ab){const m=String(o.ab).split(/\s+/);opt.ab=m[0];if(m[1]==='2')opt.t2=true;if(m[1]==='3')opt.t3=true;}if(o.blood)opt.blood=Number(o.blood);
      if(isC){const m=body.match(/^(\w+)\s+(\d+)\s+(.+?)\s*->\s*(\S+)\s*\|\s*(\S+)$/);if(!m)throw new Error('bad check');
        const c=C(m[1],Number(m[2]),m[3],m[4],m[5],Object.assign(opt,{id:o.id||('sc_'+id+'_'+m[1]+'_'+m[3].length),red:!!o.red,mod:mods(o.mod)}));if(!NL.SKILLS[m[1]])console.warn('skill?',m[1],id);cur.opts=cur.opts||[];cur.opts.push(c);}
      else{const m=body.match(/^(.+?)\s*->\s*(\S+)$/);let txt=body,go=null;if(m){txt=m[1];go=m[2]==='end'?null:m[2];if(m[2]==='end')opt.end=true;}else opt.end=true;
        cur.opts=cur.opts||[];cur.opts.push(O(txt,go,opt));}
      continue;}
    let [body,o]=tags(t);const opt={};if(o.if)opt.if=cond(o.if);if(o.do)opt.do=effects(o.do);if(o.fx)opt.fx=o.fx.split(',');
    if(!body){if(opt.do)cur.lines.push(opt);continue;}
    if(body.startsWith('> ')){cur.lines.push(T(body.slice(2),opt));Script.words+=body.split(/\s+/).length;continue;}
    const m=body.match(/^(\w+)(?:\((\d+)\))?:\s*(.*)$/);if(m){if(m[2])opt.pass=Number(m[2]);cur.lines.push(L(m[1],m[3],opt));Script.words+=m[3].split(/\s+/).length;continue;}
    throw new Error('unparsed: '+t.slice(0,60));
    }catch(err){Script.errors.push(`${file||'?'}:${ln} ${err.message}`);console.error('script',file,ln,err.message);}}
  close();};

/* =============== arcs: one personal scene per character per night =============== */
function arcFor(npc,S){const list=(ARCS[npc]||[]).filter(a=>!S.flags['arc_'+a.id]&&(!a.nights||a.nights.includes(S.night))&&(!a.if||a.if(S,G)));list.sort((a,b)=>b.prio-a.prio);return list[0]||null;}
Script.arcFor=arcFor;
const wrapped=new Set();
Script.wrapArcs=function(){for(const npc in ARCS){if(wrapped.has(npc))continue;wrapped.add(npc);const prev=H.use[npc];
  N['arcpick.'+npc]={opts:[O('__label__','__arc__',{silent:true}),O('Something else.',null,{end:true,silent:true,do:S=>{S._arcBiz=1;}})]};
  H.use[npc]=async(S,G)=>{const a=arcFor(npc,S);
    if(!a)return prev?prev(S,G):false;
    if(!prev){S.flags['arc_'+a.id]=1;return G.talk(a.id);}
    const pick=N['arcpick.'+npc];pick.opts[0].t=a.label;pick.opts[0].go=a.id;pick.opts[0].do=S=>{S.flags['arc_'+a.id]=1;};
    S._arcBiz=0;const r=await G.talk('arcpick.'+npc);if(S._arcBiz){S._arcBiz=0;return prev(S,G);}return r;};}};

/* =============== dawn dreams =============== */
Script.dreamFor=S=>{const list=(DREAMS[S.night]||[]).filter(d=>!S.flags['dream_'+d.id]&&(!d.if||d.if(S,G)));list.sort((a,b)=>b.prio-a.prio);return list[0]||null;};
Script.dream=async S=>{const d=Script.dreamFor(S);if(!d)return;S.flags['dream_'+d.id]=1;G.blackout&&G.blackout(true);try{await G.talk(d.id);}catch(e){console.error(e);}};


/* =============== helpers for content files =============== */
// place a character: Script.npc({id,room,spec,at:[x,z,ry],pose,label,if:'COND',node:'id' or {first,again}})
Script.npc=function(o){const c=o.if?cond(o.if):null;const {pushPop,pushNpc}=NL.Act;
  pushPop(o.room,(S,G)=>{if((!c||c(S,G))&&!G.actor(o.id))G.addActor(o.id,o.spec||(NL.CHARS[o.id]||NL.EXTRAS[o.id]).spec,{x:o.at[0],z:o.at[1],ry:o.at[2]||0,breathes:true,pose:o.pose||'idle'});});
  pushNpc(o.room,(S,G)=>G.actor(o.id)&&(!c||c(S,G))?{id:o.id,actor:o.id,label:o.label||((NL.CHARS[o.id]||NL.EXTRAS[o.id]||{}).n)}:null);
  if(o.node){const prev=H.use[o.id];H.use[o.id]=async(S,G)=>{if((S.room!==o.room||(c&&!c(S,G)))&&prev)return prev(S,G);const n=typeof o.node==='string'?o.node:(S.seen[o.node.first]?o.node.again:o.node.first);return G.talk(typeof n==='function'?n(S,G):n);};}};
// timed or conditional triggers that fire once: Script.on('id',{if:'night:3&time>=60'},'EFFECTS' or fn)
Script.on=function(id,o,fx){const c=cond(o.if||'true');const f=typeof fx==='function'?fx:effects(fx);
  NL.Camp.tickHooks.push((S,G)=>{if(S.flags['on_'+id])return;if(!c(S,G))return;S.flags['on_'+id]=1;try{f(S,G);}catch(e){console.error('on',id,e);}});};
// an extra option injected into an existing node: Script.opt('node.id','* text -> target {if ...}', where:'start'|'end'|index)
Script.opt=function(nodeId,line,where){const tmp='__tmp_'+Math.random().toString(36).slice(2);Script.add('# '+tmp+'\n'+line,'opt:'+nodeId);const o=(N[tmp].opts||[])[0];delete N[tmp];Script.count--;
  const apply=()=>{const n=N[nodeId];if(!n){console.warn('Script.opt: no node',nodeId);return;}n.opts=n.opts||[];if(where==='start')n.opts.unshift(o);else if(typeof where==='number')n.opts.splice(where,0,o);else{const li=n.opts.findIndex(x=>x.leave||x.end&&!x.go);if(li>=0&&where!=='last')n.opts.splice(li,0,o);else n.opts.push(o);}};
  if(N[nodeId])apply();else document.addEventListener('DOMContentLoaded',apply);};
// an extra line injected into an existing node
Script.line=function(nodeId,line,where){const tmp='__tmp_'+Math.random().toString(36).slice(2);Script.add('# '+tmp+'\n'+line,'line:'+nodeId);const l=N[tmp].lines[0];delete N[tmp];Script.count--;
  const apply=()=>{const n=N[nodeId];if(!n||!Array.isArray(n.lines)){console.warn('Script.line: no node',nodeId);return;}if(where==='start')n.lines.unshift(l);else n.lines.push(l);};
  if(N[nodeId])apply();else document.addEventListener('DOMContentLoaded',apply);};
// a map destination that plays a scene instead of loading a room: Script.place({id,name,block,sub,if,node,min})
Script.place=function(o){const c=o.if?cond(o.if):null;const lk=o.locked?cond(o.locked):null;
  NL.PLACES.push({id:o.id,name:o.name,block:o.block||'B',room:null,sub:o.sub||'',open:S=>!c||c(S,G),locked:S=>lk&&lk(S,G)?(o.lockedText||'Not now.'):null,
    before:async(S,G)=>{NL.Camp.closeMap();G.tick(o.min||14);await G.talk(typeof o.node==='function'?o.node(S,G):o.node);return false;}});};

/* =============== street events: a chance of something happening on the way =============== */
Script.STREET=Script.STREET||[];
Script.street=async function(S,G,to,from){if(!from||from.block===to.block&&Math.random()<0.6)return;if(S.night===5&&S.time>=230)return;
  if((S.flags.streetLast||-99)>S.time-40)return;
  const list=(Script.STREET||[]).filter(e=>!S.flags['st_'+e.id]&&e.nights.includes(S.night)&&(!e.if||e.if(S,G)));
  if(!list.length||Math.random()>0.5)return;
  let tot=list.reduce((a,e)=>a+e.w,0),r=Math.random()*tot,pick=list[0];for(const e of list){r-=e.w;if(r<=0){pick=e;break;}}
  S.flags['st_'+pick.id]=1;S.flags.streetLast=S.time;await G.talk(pick.id);};
document.addEventListener('DOMContentLoaded',()=>{if(NL.Camp&&NL.Camp.onTravel)NL.Camp.onTravel.push(async(S,G,p,here)=>{try{await Script.street(S,G,p,here);}catch(e){console.error(e);}});});
Script.cond=cond;Script.effects=effects;
document.addEventListener('click',e=>{if(!e.target.closest('#tenantTalk'))return;e.stopPropagation();const S=G.S;const a=Script.arcFor('tenant',S);if(!a||G.busy)return;G.closePanel();S.flags['arc_'+a.id]=1;setTimeout(()=>G.talk(a.id),350);},true);
document.addEventListener('DOMContentLoaded',()=>{Script.wrapArcs();if(Script.errors.length)console.error('SCRIPT ERRORS\n'+Script.errors.join('\n'));});
/* character sheet: reputation block */
NL.Rep.inject=html=>html.replace(/<\/div><\/div>$/,Rep.html(G.S)+'</div></div>');
})();
