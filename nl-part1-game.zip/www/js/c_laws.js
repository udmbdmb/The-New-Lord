'use strict';
/* THE NEW LORD — Saturday's three laws, as written by whoever you turned out to be */
(function(){const O=NL.Script.opt;
O('sat.d1','* "Every Kindred accused in this Ward gets rule four. Name the crime first. Then ask."  -> lw.rule4 {if past:litigator}');
O('sat.d1','* "Anyone hurt on the street at night gets carried to St. Jude\'s. By whoever finds them. Kindred included."  -> lw.carry {if past:paramedic}');
O('sat.d1','* "Every missing person in the Ward is reported. By us. To Detective Miller."  -> lw.report {if flag:pact=mortal|flag:millerKnowsClerk}');
O('sat.d1','* "Nobody makes a fledgling without asking them first. Twice. Sober."  -> lw.ask {if flag:newbSafe|clan:stray}');
O('sat.d2','* "No Butcher reshapes anyone who hasn\'t asked. Twice."  -> lw.carve {if clan:butchers}');
O('sat.d2','* "No Kindred reads a mortal\'s phone, or their mind, without leave."  -> lw.read {if clan:moths|clan:glass}');
O('sat.d2','* "No one at Elysium laughs at the Rot. Not at table. Not ever."  -> lw.rot {if clan:rot|flag:wickLit}');
O('sat.d2','* "The Hound walks beside the Sheriff. Never behind."  -> lw.heel {if flag:valkoWalks|flag:valkoStopped}');
O('sat.d3','* "Everyone who disappears in this Ward is written down. Somebody has to know."  -> lw.ledger {if past:clerk}');
O('sat.d3','* "Everybody gets in. Once."  -> lw.door {if past:promoter}');
O('sat.d3','* "Dogs are welcome at Elysium."  -> lw.dogs {if flag:strayDog}');
O('sat.d3','* "Every Kindred who wants one gets a portrait. Painted. So someone remembers the face."  -> lw.face {if clan:wraiths|mem:tenant.described}');
O('sat.d3','* "Anyone who wants to stop, may stop."  -> lw.stop {if flag:valkoStopped|flag:msgTen=stop}');
})();
NL.Script.add(String.raw`
# lw.rule4
tenant: Rule four. My rule four. In your law. Nobody's cited it since 1888 and now it's going to be the first thing every Tribunal hears.
tenant: Harriet Shaw would be proud of you. I'm proud of you. I'm also slightly jealous. It was my best rule and you've made it better by meaning it.
{do flag:law_rule4=1; sync+1}
@next sat.d2

# lw.carry
tenant: Carry them. Kindred. To a hospital. In our arms.
tenant: They'll hate it. They'll do it. And some poor boy with a knife in him on Kerr Street at four in the morning will wake up in a bed at St. Jude's with no idea that a Sovereign carried him there, and Ruth Okoro will be on shift and say "who brought this one in?" and nobody will answer.
{do flag:law_carry=1; lean:mercy+1}
@next sat.d2

# lw.report
tenant: To Miller. By name. In a law of the Court.
tenant: She'll be the first mortal named in a Sheriff's law since... ever. I don't think it's ever happened. She'll be furious. She'll take every call.
{do flag:law_report=1; rel:miller+1}
@next sat.d2

# lw.ask
tenant: Ask. Twice. Sober. Oh, that's going to stop the Gilded parties dead. Good. Good. Nobody asked Priya. Nobody asked you.
{do flag:law_ask=1; lean:mercy+1}
@next sat.d2

# lw.carve
tenant: A Butcher's law. From a Butcher. Malakor will sulk for a month. Then he'll put a sign up in the shop. In Polish. I'd bet on it.
{do flag:law_carve=1; lean:restraint+1}
@next sat.d3

# lw.read
tenant: Without leave. From a Moth, or a Glass. That's like a fox making a law about henhouses. They'll respect it more for that. They'll know what it cost you.
{do flag:law_read=1; lean:restraint+1}
@next sat.d3

# lw.rot
tenant: Not at table. Not ever.
tenant: ...I'll obey it. I'll be the first. I'm sorry, Brother Wick. I'm putting it in writing. That's the most a Sovereign can do. It's very little. It's in writing.
{do flag:law_rot=1; sync+2}
@next sat.d3

# lw.heel
tenant: Beside. Never behind. In law. So that no Sheriff after you can make him walk behind again.
tenant: He'll read it. Pemberton will read it to him. Slowly. I want to be there when he does.
{do flag:law_heel=1; rel:valko+2}
@next sat.d3

# lw.ledger
tenant: Written down. Every one. By whom?
tenant: ...By you. Of course. The clerk. Every name in a ledger, in the study, next to mine. Gideon will want a copy. Soot will want the original.
{do flag:law_ledger=1; sync+1}
@next sat.end

# lw.door
tenant: Everybody. Once.
tenant: That's the Velvet Hour, isn't it. That's what you did every Thursday. Everybody gets one night. After that it's up to them.
tenant: Séverine will hate it so much she'll have to sit down. I'm going to enjoy that very much from in here.
{do flag:law_door=1; lean:pride-1}
@next sat.end

# lw.dogs
> Something in your blood laughs so hard it hurts. It's not the same laugh as the car. It's softer.
tenant: Dogs. At Elysium. Under Séverine's chairs. Oh, child. Write it in red. Write it next to the car.
{do flag:law_dogs=1; sync+2}
@next sat.end

# lw.face
tenant: A portrait. Painted. For every Wraith who wants one, and every Kindred with no reflection, so someone remembers what they looked like.
tenant: Lisette knows a painter. Not Konrad. Konrad's in the Elbe. But somebody who learned from somebody who learned from him. Ask her. She'll count the cost and then pay it herself.
tenant: ...And mine. Will you have mine done? From the description? A heron that's cross with the river?
* "Yours first."  -> lw.face1

# lw.face1
tenant: Mine first. On the wall in the study. Where the mirror used to be.
{do flag:law_face=1; flag:tenantPortrait=1; sync+3}
@next sat.end

# lw.stop
tenant: Anyone who wants to stop, may stop.
tenant: That's mine. I said it to Valko, through you. You've made it law. For everyone. For the Hounds who've been running sixty years and the ghouls who've been driving forty and the old women who've been listening in the pipes since before the war.
tenant: You may stop. In law. Oh, child.
{do flag:law_stop=1; sync+3; comp+1}
@next sat.end
`,'c_laws');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.law_rule4)o.push(['Rule four','Is cited at every Tribunal in the Marrow Ward now, first, before anything else. Twice since Saturday, the Accuser couldn\'t name the crime. Both Accused went home.']);
  if(f.law_carry)o.push(['St. Jude\'s night intake','Lists eleven admissions this winter as "brought in by unknown party". Nurse Ruth Okoro has started leaving a cup of coffee by the ambulance bay door at four. Nobody drinks it. It\'s always gone by five.']);
  if(f.law_report)o.push(['Detective Miller\'s desk phone','Rings at odd hours now. The voices are always polite and always very old and always give an address and a name. Missing Persons, Precinct 9, has the best clearance rate in the state.']);
  if(f.law_ask)o.push(['The Gilded parties','Got much duller. There have been no unsanctioned fledglings in the river since October. Priya has written a pamphlet. It is called ASK TWICE.']);
  if(f.law_dogs)o.push(['Elysium','Has dogs in it now, under the chairs. Lady Séverine pretends not to notice them. She has been seen, once, feeding a lurcher a canapé.']);
  if(f.tenantPortrait)o.push(['A portrait in the Sheriff\'s study','Of a tall thin man with a scar through one eyebrow and one hand behind his back, like a heron that\'s cross with the river. Painted from a description. Everyone who knew him says it\'s exactly right.']);
  if(f.law_stop)o.push(['The Sheriff\'s third law','Anyone who wants to stop, may stop. In the first year, four Kindred and one ghoul took it at its word. Valko was one. Pemberton thought about it for a long time, and kept driving, because he wanted to.']);
  return o;});
