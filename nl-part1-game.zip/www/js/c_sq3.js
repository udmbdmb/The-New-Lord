'use strict';
/* THE NEW LORD — side quests, set three: "The Night Clerk", "Yours, in Daylight" (Agnes's grave), "What Dale Remembers", and the Prophet after his price */
(function(){
const X=NL.EXTRAS,S_=NL.Script;
X.pellow={n:'Arthur Pellow',color:'#d8c8a0',role:'Night clerk, the Courthouse · since 1971',spec:{face:{long:1.1,jaw:0.6,nose:1.3,cheek:0.7,brow:1.2},skin:[.86,.78,.72],hair:{style:'fringe',color:[.92,.92,.9]},glasses:{type:'reading'},shirt:[.85,.82,.75],coat:{color:[.25,.22,.2],length:.45,collar:true},height:.9}};
X.dale={n:'Officer Dale',color:'#a0b0d0',role:'Precinct 9 · off sick',spec:{face:{wide:1.08,jaw:0.4,brow:1.2},skin:[.82,.62,.52],hair:{style:'crop',color:[.4,.3,.2]},shirt:[.45,.42,.38],coat:{color:[.3,.28,.25],length:.4,collar:true},pants:[.2,.2,.24],height:1.05,width:1.15}};
Object.assign(NL.TASKS,{s_clerk:{n:'The Night Clerk',xp:40,cat:'side'},s_agnes:{n:'Yours, in Daylight',xp:80,cat:'side'},s_dale:{n:'What Dale Remembers',xp:40,cat:'side'}});
S_.place({id:'clerk',name:'The Courthouse night desk',block:'B',sub:'Arthur Pellow brings the files down at three.',if:'night>=4&night<=5&flag:studyDone&!flag:clerkDone',node:'cl.0',min:12});
S_.place({id:'grave',name:'Heights Cemetery',block:'C',sub:'Above the Ward. Row J, plot 112.',if:'night>=4&night<=5&flag:knowAgnesGrave&!flag:graveDone',node:'ag.0',min:24});
S_.npc({id:'prophet',room:'switchyard',at:[1.2,5.9,0.5],pose:'sit',label:'The Prophet',if:'flag:prophetDone&night>=3'});
S_.npc({id:'dale',room:'luckymart',at:[4.2,2.4,-1.2],pose:'idle',label:'Officer Dale',if:'night:4&time>=60&time<=250&flag:racketDone=feed&!flag:daleDone',node:'dl.0'});
})();
NL.Script.add(String.raw`
// =====================================================================
// THE NIGHT CLERK · Arthur Pellow, the Courthouse, at three
// =====================================================================
# cl.0
> The Courthouse side door. The night clerk's office: a desk, a lamp, a radio playing a cricket match from the other side of the world. The old man who was asleep when you went up to the study is awake now, and waiting for you, with two cups of tea already poured.
pellow: Ah. There you are. I thought you might come back down. Nobody goes up those stairs and doesn't come back down needing to sit.
pellow: Arthur Pellow. Night clerk. Since 1971. Before me, my father, from 1940. Before him, a man called Mr. Quill, who I'm told had no reflection, which my father thought was a terrible shaving accident.
{do task:s_clerk; note:s_clerk|Arthur Pellow has been the Courthouse night clerk since 1971. He brought the files up to the Sheriff at three every night. He knew him. He may have known Agnes.}
* "You knew him. The Sheriff."  -> cl.knew
* "You don't seem frightened of me."  -> cl.fright
* "Why is there still a night clerk?"  -> cl.why

# cl.knew
pellow: Fifty-three years. Every night at three I'd take the day's files up those stairs, and knock, and he'd say "Come in, Mr. Pellow," and I'd put them on the corner of the desk and he'd say "Thank you, Mr. Pellow," and I'd go back down.
pellow: Fifty-three years. That's all we ever said. "Come in." "Thank you." Then one night in 1999 my wife had died that week and I put the files on the desk and he looked up and said, "Sit down, Arthur." First time he'd used my name. We sat. He didn't say anything. I didn't either. It was two hours. It was the kindest thing anyone did for me that year.
pulse(4): His hands are steady on the teacup. He's been ready for this conversation for a long time.
{do mem:pellow:knew}
@next cl.hub

# cl.fright
pellow: Frightened? Of what? You're wearing his coat and you went up his stairs and came down looking like you'd been to a funeral. I've worked nights in a Courthouse for fifty-three years. I know what a funeral face looks like. I know what the other faces look like too.
pellow: Drink your tea. Or don't. He never did either. I poured it every night anyway.
@next cl.hub

# cl.why
pellow: Because in 1871 a judge wrote a rule that the Courthouse must never be unattended, and nobody's ever repealed it. And because, between you and me, I think the gentleman upstairs paid somebody to make sure nobody ever did.
pellow: A clerk at the desk all night means a light on at the bottom of the stairs. I think he liked coming down at dawn and seeing a light on.
tenant: ...I did. I did like that. I'd forgotten that too.
@next cl.hub

# cl.hub
* "Did he ever have visitors? A woman. 1920s."  -> cl.agnes {once}
* "Did anyone else come up the stairs this week?"  -> cl.week {once}
* "Thank you for the tea, Mr. Pellow."  -> cl.bye

# cl.agnes
pellow: Before my time, the 1920s. But my father kept a book. Every visitor to the night desk, in pencil. He was very thorough. He'd note the weather.
> He brings it out from under the desk: a ledger, cloth-bound, foxed. He turns to 1924 without looking, as if he's done it before.
pellow: *Miss A. Lark, typist, 3rd floor. Brought files down at 3. Stayed talking to Mr. V. in the hall until 4. Raining.* That's every night, 1924 to 1926. Then *Miss Lark married. Mrs. A. Dunmore.* Then she stops coming.
pellow: And then, one entry. 1961. December. *Mr. V. came down at 2. Asked for the address of Heights Cemetery. Said it was for a friend. Said "Row J". Snow.*
web(5): Agnes Lark. Agnes Dunmore. Heights Cemetery, Row J. He never went. Or he went once.
{do flag:knowAgnesGrave=1; task:s_agnes; note:s_agnes|Agnes Lark, later Agnes Dunmore, typist at the Courthouse, died in 1961. She's buried at Heights Cemetery, Row J. The Sheriff asked for the address in December 1961. Pemberton can drive you there.; mem:pellow:agnes}
tenant: ...Row J. Plot 112. I went once. I stood at the gate and didn't go in. I never went in.
@next cl.hub

# cl.week
pellow: This week? A grey man. Tuesday. Sunglasses. Said he was from the Department of Health doing a survey of public buildings. Asked if anyone had been up to the third floor. I said no. He asked if he could go up. I said not without a warrant, sir, it's a Courthouse.
pellow: He laughed. He didn't go up. He didn't have a warrant. Funny, for a government man.
{do mem:pellow:harrow; rel:pellow+1}
@next cl.hub

# cl.bye
pellow: Mind the third step, there's a loose board. There's always a loose board somewhere in this city. I'll keep the light on.
{do flag:clerkDone=1; task:s_clerk=done; xp:40:The Night Clerk}
@end

// =====================================================================
// YOURS, IN DAYLIGHT · Heights Cemetery, Row J, plot 112
// =====================================================================
# ag.0
> Heights Cemetery is above the Ward, above the floodlights, above everything: a hill of Victorian angels and leaning stones with the whole of Port Vellum laid out below it in orange and violet. Pemberton parks at the gate and doesn't get out.
pemberton: I'll wait here, ‹sir›. He never got past the gate. I'd rather not be the one who does. {if !flag:pemDead}
> Row J. The grass is long. Plot 112 is a small grey stone, simple, already leaning. Somebody has put plastic flowers on it, a long time ago, faded white.
> *AGNES MARY DUNMORE · née LARK · 1902–1961 · BELOVED WIFE OF ALBERT · "IN DAYLIGHT"*
tenant: ...
tenant: "In daylight." Albert put that. Her husband. The bus driver. He must have found the letters. He must have known. And he put it on her stone anyway.
nostalgia(5): A grief that isn't yours, so big it has its own weather. You have to sit down on the next grave to hold it.
* Kneel.  -> ag.kneel
* Read her one of her own letters.  -> ag.read {if has:agnesletters}
* Let him speak. Give him your voice.  -> ag.voice
* "Say something to her."  -> ag.say

# ag.kneel
> You kneel in the long wet grass. The angels watch. Below, the floodlights sweep the Ward, slow, humming, and none of them reach up here.
tenant: Sixty-three years. I stood at that gate in the snow in 1961 for an hour. I watched Albert walk away from the grave with his hat in his hands. I didn't go in. I thought I had no right.
tenant: I still don't. But you've brought me anyway.
{do sync+3:Row J}
@next ag.after

# ag.read
> You take the shoebox out of your coat. You choose the last one, from 1961, the handwriting shakier.
> *Dear A. — The doctor says it won't be long now. Albert is very brave about it. He doesn't know about you; or he does, and he's kinder than either of us deserves. I wanted to tell you one more thing about the day. This morning the sun came through the window of the ward and lay across the blanket on my knees, and it was warm, and I thought: this is what I've been trying to tell you for thirty-five years. It's only this. It's only warm. I hope one day you feel it. I hope you're not sad that I could. Yours, in daylight, always. A.*
> When you look up from the letter, the Tenant isn't speaking. The voice in your blood has gone completely still, the way a house goes still after someone has left it.
{do sync+6:Always; comp+3:In daylight; mem:tenant:lastletter; flag:readLastLetter=1}
@next ag.after

# ag.voice
> You stop holding the door, just a little, just for this. Your mouth opens and the voice that comes out of it is his: deep, dry, three hundred years old, shaking.
tenant: Agnes. It's me. I'm late. I'm very sorry. I was always late, wasn't I. You used to say I'd be late to my own funeral and I said I'd never have one. I've had one now. It wasn't much.
tenant: It doesn't hurt. You asked me that once. It doesn't hurt. It's cold. It's always been cold. Thank you for asking. Nobody else ever did.
{do sync+8:His voice, at her grave; mem:tenant:graveVoice}
@next ag.after

# ag.say
tenant: Say what? "Sorry"? She'd laugh at me. She'd say, "A, you sound like a man who's dropped his hat."
tenant: ...Tell her the harbour was the color of a pigeon's neck tonight. Tell her that. It wasn't. It was orange and violet from the lights. But tell her.
* Tell her.  -> ag.tell {do lean:mercy+1}

# ag.tell
> You tell her. The harbour, the pigeon's neck. You lie to a gravestone on behalf of a dead man and it's the most honest thing you've said all week.
{do sync+4:A pigeon's neck}
@next ag.after

# ag.after
tenant: Thank you. Whatever happens tomorrow. Thank you, Casey.
tenant: There's something I've never told anyone. Not Pemberton. Not Valko. In 1926, when I showed her my teeth, and she asked if it hurt, she also asked if I'd ever thought of stopping. Not dying. Stopping. Stopping being the thing that needs.
tenant: I said there's no such thing. She said, "There's always such a thing. You just have to want it more than you want everything else."
tenant: The Golconda. That's what the old ones call it. I always thought it was a fairy story. I'm less sure, kneeling here.
{do task:s_agnes=done; flag:graveDone=1; xp:80:Yours, in Daylight; offer:golconda; mem:tenant:golconda}
* Leave something on the stone.  -> ag.leave
* Go back to the car.  -> ag.end

# ag.leave
* Leave Agnes's letters with her.  -> ag.leaveletters {if has:agnesletters}
* Leave the Sheriff's watch.  -> ag.leavewatch {if has:watch}
* Leave nothing. Just go.  -> ag.end

# ag.leaveletters
> You put the shoebox on the grave under the plastic flowers. It'll rain on them. The ink will run. That seems right.
tenant: Yes. Yes. Give them back. They were always hers.
{do take:agnesletters; flag:lettersReturned=1; sync-3:Letting go; comp+2:Letting go}
@next ag.end

# ag.leavewatch
> The Waltham. *A. from A.* You wind it once and put it on the stone. It ticks, loud in the silence, the only moving thing on the hill.
tenant: She gave it to me in 1925. I pawned it in 1952. Now it's back. It took seventy-two years and a stranger.
{do take:watch; flag:watchReturned=1; sync-2:The watch; comp+2:The watch}
@next ag.end

# ag.end
> Pemberton has the engine running and the heater on. He doesn't ask. He drives you back down into the floodlights very slowly, the long way, by the harbour. {if !flag:pemDead}
@end

// =====================================================================
// WHAT DALE REMEMBERS · Officer Dale, after the walk-in
// =====================================================================
# dl.0
@focus dale
> Officer Dale is standing in the Lucky Mart in a tracksuit, not a uniform, with a scarf wound three times round his neck. Tariq is behind the counter holding the little silver hand so hard it's cutting his palm.
dale: You. You. I know you. I don't know how I know you. Every time I close my eyes there's a fridge, and you're in it, and I'm smiling.
dale: My neck hurts. I've been to the doctor. She says it's a vitamin deficiency. I don't believe her. I've been off sick three days. I keep coming back here. I don't know why I keep coming back here.
{do task:s_dale; note:s_dale|Officer Dale doesn't remember you feeding on him in the Lucky Mart's walk-in, but his body does. He keeps coming back. He's frightening Tariq.}
* "You came back because you're mine now. A little."  -> dl.truth {do lean:candour+1}
* Make him forget properly. All of it.  -> dl.fog {ab fog}
* "Go home, Dale. Don't come back here. Ever."  -> dl.kneel {ab kneel}
* "You should talk to Detective Miller."  -> dl.miller
* "Leave Tariq alone and I'll leave you alone."  -> dl.deal

# dl.truth
dale: Yours. Your what? Your... no. No. That's not.
> He sits down on a stack of newspapers. He holds his head in both hands.
dale: I took money off him for two years. Two hundred a week. Every Wednesday. And now I'm... I can't stop thinking about the fridge. I'm going mad. I'm going mad, aren't I.
* "You're not mad. Just bitten. It'll fade."  -> dl.fade {do lean:mercy+1}
* "You took his money. This is what that costs."  -> dl.cost {do lean:mercy-1}

# dl.fade
dale: Fade. When?
autopsy: A week. Maybe two. The longing goes first. The dreams last longer.
dale: ...Okay. Okay. I'll stay home. I'll... Tariq. Tariq, I'm sorry. About the money. I'll pay it back. I don't know how. I'll pay it back.
tariq: (very quietly) Four thousand eight hundred dollars, Officer Dale. I kept a book.
{do flag:daleDone=sorry; task:s_dale=done; xp:40:What Dale Remembers; rel:tariq+1; mem:tariq:dale}
@end

# dl.cost
dale: Costs. Yeah. Yeah. I knew it'd cost something eventually. My mom said. She said Kenny Pruitt and me'd end up in a ditch.
> He walks out into the floodlit lane in his tracksuit and doesn't look back.
{do flag:daleDone=cost; task:s_dale=done}
@end

# dl.fog
> Grey fog, all the way down. The fridge, the smile, the walk-in, the two years of Wednesdays. All of it. He blinks.
dale: ...Packet of mints. Please. Sorry. Long week.
> He pays for the mints. He leaves. He'll never come back. He'll never know why he can't stand the smell of a fridge.
tariq: (after a long time) Thank you. I think. Thank you.
{do flag:daleDone=fogged; task:s_dale=done; xp:40:What Dale Remembers}
@end

# dl.kneel
> *Go home. Don't come back.* It goes into him like a nail. He turns round and walks out of the shop mid-sentence and down Ferrier Lane in a straight line and doesn't stop at the crossing, where the floodlight catches him, and he doesn't notice.
{do flag:daleDone=kneel; task:s_dale=done; xp:30:What Dale Remembers}
@end

# dl.miller
dale: Miller? Missing Persons Miller? She hates me. Everyone in Precinct 9 hates me. I'm the bloke who takes the envelopes.
dale: ...She'd believe me, though. She believes everything. That's why she's a laughing stock.
* "She's not laughing any more. Tell her about the envelopes. All of them."  -> dl.millerok {do lean:candour+1}

# dl.millerok
dale: All of them. The Captain's envelopes. Harrow's envelopes. The seven files.
dale: ...Yeah. Yeah, why not. I'm off sick anyway. I've got nothing else to do except dream about fridges.
{do flag:daleDone=miller; flag:daleWitness=1; task:s_dale=done; xp:50:What Dale Remembers; rel:miller+1}
@end

# dl.deal
dale: Leave him alone. Yeah. Yeah, okay. I don't even want to come in here. I just. My feet bring me.
{do flag:daleDone=deal; task:s_dale=done}
@end

// =====================================================================
// THE PROPHET · after his price
// =====================================================================
# pr.after arc=prophet night=3,4,5 label="\"What do you see now, old man?\"" if=room:switchyard&flag:prophetDone
@focus prophet
> The Prophet is sitting on the edge of the platform with his feet over the tracks, the way children sit on a pier, waiting for a train that hasn't come since 1977.
prophet: Now? Now I see trains. They're coming back. One day. You'll hear them first in your teeth.
prophet: And you. I see you. You're standing in a lot of places at once. It's very confusing. Stop moving about.
@gate night:5 ? pr.five : pr.plain

# pr.plain
* "What happens on Friday?"  -> pr.friday
* "Who were you, before?"  -> pr.before
* "Where do the trains go?"  -> pr.trains

# pr.friday
prophet: Friday. Ah. Friday's very loud. There's a light, and a chalk circle, and a man in red who's very bored.
@gate vessel:you ? pr.fv : pr.fn

# pr.fv
prophet: And you're holding the sun in your pocket. Somebody's going to ask you to turn the dial. Don't let them choose how far. That's yours.
@end

# pr.fn
prophet: And the sun's in somebody else's pocket. You'll want it back. You might not get it. That's all right. The sun comes up anyway. It's the one thing that does.
@end

# pr.before
prophet: Before? I drove the 11:40 to the coast. 1961 to 1977. Steam, then diesel. I had a whistle. I loved my whistle.
prophet: Then the line closed and they paved the river and a lady in a fur coat found me sleeping on this platform and gave me a drink of something and I never woke up properly again.
nostalgia(4): A Wraith in a fur coat. Winter, in 1977, before she stopped. She made him. She made the Prophet out of a lonely train driver.
{do flag:prophetWinter=1}
@end

# pr.trains
prophet: Everywhere. The coast. The mountains. The old capital. And one train that goes to a station where it's always noon, and the people get off and stand on the platform with their faces turned up, and nobody burns.
prophet: I drove it once. In a dream. I'm saving up for a ticket.
@end

# pr.five
prophet: Tonight. Tonight's the night. I can hear it in my teeth. Not the trains. Something else. Something big turning a dial very slowly.
@gate flag:ratsGrates|flag:mastDead|flag:mastTuned ? pr.safe : pr.danger

# pr.safe
prophet: But it won't turn all the way. Something's chewed through it. Rats or men or a girl on a roof. It'll click and click and nothing will come. Good. Good. I'll be here, waiting for my train.
@end

# pr.danger
prophet: And it'll turn all the way. The grates will sing. Get under the water, little one. The old river remembers how to hide things. Get under the water and hold your breath, even though you don't need it.
{do flag:prophetWarned=1}
@end
`,'c_sq3');
