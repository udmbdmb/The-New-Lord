'use strict';
/* THE NEW LORD — Night Four, part two: Séverine, Malakor, Soot, Miller, Margo, Valko, Lisette, Ashby, Coral, Ken Pruitt, Marek, Harrow at the van, and the fourth (last) dawn dream */
(function(){
NL.Script.npc({id:'harrow',room:'alley',at:[2.0,1.6,0.9],pose:'arms',label:'Agent Harrow',if:'night:4&time>=60&time<300&!flag:harrowDead&!flag:harrow4Done',node:'hw4.0'});
})();
NL.Script.add(String.raw`
// =====================================================================
// SÉVERINE · Night Four · the conversation she was owed
// =====================================================================
# sx4.0 arc=severine night=4 label="\"You wanted honesty, my lady. Here I am.\"" if=room:vip&alive:sev&flag:sevOwedTalk prio=3
@focus severine
severine: Ah. The debtor. Sit. Honestly, this time. What did your comedian see on Monday?
* Tell her the truth: the latch, Margo, "Lock the walk-in, Leonard."  -> sx4o.truth {do lean:candour+1}
* "Nothing. He was on a hook."  -> sx4o.lie {do lean:candour-1}

# sx4o.truth
severine: The latch. Margo. Leonard.
severine: So the boy knows the door was fixed and doesn't know who paid. And you do. And you've told me you know, in my own crypt, as if it were a gift.
severine: ...It is a gift, isn't it. You're telling me you could ruin me on Friday and you haven't decided to.
{do mem:severine:honest4; rel:severine+1; flag:sevKnowsYouKnow=1}
@end

# sx4o.lie
severine: On a hook. How restful for him.
pulse(5): She knows you're lying. She's letting you, which is worse.
{do mem:severine:lied4}
@end

# sx4.p arc=severine night=4 label="Ask for a moment before the counting." if=room:vip&alive:sev&!flag:sevOwedTalk
@focus severine
> The crypt is full. Every Kindred in the Ward, in their best clothes, waiting to be counted by a ghoul with a ledger at a card table. Séverine sits apart, on her sarcophagus, as if none of it has anything to do with her.
severine: A moment. Of course. I have so many tonight. They keep arriving like pigeons.
severine: Look at them. Three hundred years of Kindred in the Marrow Ward and I've had to make a *register*. Do you know what that feels like? It feels like admitting the house has caught fire by counting the furniture.
* "Why the floodlights? Why the curfew?"  -> sx4p.why
* "Whose lights are they, really?"  -> sx4p.whose
* "Are you frightened?"  -> sx4p.afraid

# sx4p.why
severine: Because someone ate the Sheriff, and someone else burned a haven, and someone else stole a brass bottle full of noon, and the Prince on the Heights rang me at sunset to ask if I was "managing". One manages. One puts up lights.
@next sx4p.hub

# sx4p.whose
severine: Mine, officially. The city's, technically. The *federal* government's, actually. Harrow offered them. He had them on a truck within the hour. I should have asked why a man has three hundred ultraviolet floodlights ready on a truck.
severine: I didn't ask. I was grateful. That's the problem with gratitude: it closes the mouth.
web(5): She took LANTERN's lights. Now they're on every crossing and every roof. Harrow's had the Ward wired since Thursday.
{do mem:severine:lights; flag:sevLightsLantern=1}
@next sx4p.hub

# sx4p.afraid
> She looks at you for a long time.
severine: The Choir hear everything, you know. The way the ear hears. I can hear three hundred dead hearts in this room not beating, and under that I can hear the floodlights humming on every roof in the Ward.
severine: They hum at the same note. All of them. As if they were waiting to sing together.
severine: Yes. I'm frightened. Don't tell anyone. They'd never believe you, and I'd have to have you killed for saying it.
{do mem:severine:afraid; rel:severine+1}
@next sx4p.hub

# sx4p.hub
* "If it goes wrong on Friday, my lady, get out early."  -> sx4p.warn {once} {if flag:knowCode|flag:know414}
* "What do you want me to say at the Tribunal?"  -> sx4p.say {once}
* "Thank you, my lady."  -> sx4p.bye

# sx4p.warn
severine: Early? From my own Tribunal? From the Prince's Magistrate?
pulse(5): But she's listening. Her hand has gone to the little pearl at her throat.
{do flag:sevWarned=1; mem:severine:warned; rel:severine+1}
severine: ...I'll keep a car at the north stair. Tell no one.
@next sx4p.hub

# sx4p.say
severine: Whatever is true and won't hang me. You'll find that's a smaller list than you think.
@next sx4p.hub

# sx4p.bye
severine: Go and be counted. Number three hundred and twelve. I'll remember the number.
@end

// =====================================================================
// MALAKOR · Night Four · after the bargaining
// =====================================================================
# mx4.0 arc=malakor night=4 label="\"Show me your first face.\"" if=room:switchyard&alive:malakor&flag:haveMalakorPhoto
@focus malakor
> You put the brown photograph on his workbench. A jug-eared boy in Odessa, squinting at the sun.
> Malakor doesn't touch it. He takes his goggles off. He looks at it the way you'd look at a dog that died when you were small.
malakor: Soot. Of course. That old crow keeps everything.
malakor: Grigori. That was his name. Grigori Malakhov. He wanted to be a doctor. He was very bad at chemistry. He liked a girl who sold herring on the dock. He never spoke to her.
* "He looks kind."  -> mx4.kind {do lean:mercy+1}
* "Take it. It's yours."  -> mx4.take {do lean:loyalty+1}
* "Why do you look so different now?"  -> mx4.different

# mx4.kind
malakor: He was. That's why I got rid of him. Kindness in 1931 got you shot in a cellar. I wasn't ready to be shot in a cellar. I was nineteen and I'd just been made.
{do mem:malakor:grigori; rel:malakor+1}
@next mx4.after

# mx4.take
> He takes it. He puts it in the breast pocket of his apron, behind the pens, over where a heart would be if he used one.
malakor: Thank you. That is the second time this week you've given me something without a price. I'm starting to find it suspicious.
{do mem:malakor:grigori; rel:malakor+2}
@next mx4.after

# mx4.different
malakor: Because every face I've had since has been a lie that works. That one is the truth, and the truth was never a good business model.
@next mx4.after

# mx4.after
malakor: Tomorrow I'll be on Platform 0 in the twelfth face, and I'll bargain, and I'll smile at the Lady, and I'll sell the Syndicate's vote to whoever pays best.
malakor: But I'll have this in my pocket. And I'll know I'm lying. That's something. That's a start.
@end

# mx4b.0 arc=malakor night=4 label="\"What happens to you if the lamps come on?\"" if=room:switchyard&alive:malakor&flag:knowCode
@focus malakor
malakor: The lamps. You know about the lamps. Rostova told you, I imagine, on her roof. She always did talk when she was frightened.
malakor: If the lamps come on, with the whole Court on Platform 0 and the Magistrate in his chair, then three hundred of us become ash in under a minute, and Harrow gets a medal, and the Marrow Ward gets a park.
* "And your generator?"  -> mx4b.gen {if flag:malakorAntidote}
* "Get out early. Bring your people."  -> mx4b.warn
* "Help me stop it."  -> mx4b.help

# mx4b.gen
malakor: Ready. Mostly. If the lamps sing at 4.14, my generator will sing back, louder, out of tune. It might crack them. It might do nothing. It might set fire to the platform. Engineering is very exciting.
{do flag:malakorReady=1}
@next mx4b.help

# mx4b.warn
malakor: Out early. From a Tribunal. Where everyone will be watching who leaves.
malakor: ...I'll keep my guys by the east tunnel. If you hear me whistle, run that way. Don't ask. Just run.
{do flag:malakorWarned=1; mem:malakor:warned}
@end

# mx4b.help
malakor: Stop it. How? Cut the mast? That's done, or it isn't, you'd know. Break every lamp in every grate? There are thirty-one grates. You'd need a hundred hands.
malakor: Or you could tell everyone, in the chalk circle, in front of the Magistrate. Then three hundred Kindred will tear the grates up with their bare hands. That's my favorite plan. It's the loudest.
{do flag:malakorWarned=1; mem:malakor:plan}
@end

// =====================================================================
// MOTHER SOOT · Night Four · the last trade
// =====================================================================
# ux4.0 arc=soot night=4 label="\"Mother. What will you say tomorrow?\"" if=room:shrine&flag:metSoot
@focus soot
soot: Say? Say, say. Tomorrow I'll say what the pipes say. The pipes say a lot. Most of it's about plumbing.
soot: But I've been listening to the grey men. Through their own wires. They talk in numbers. Four. Fourteen. Thirty-one. One. Mm. Mm. Four-fourteen is the song. Thirty-one is the grates. One is the time. One in the morning.
web(6): 4.14 megahertz. Thirty-one lamps under the grates. One A.M., when the Magistrate sits. They're going to do it during the Tribunal.
{do flag:sootLampsCount=1; mem:soot:numbers}
* "Can your rats get to the grates?"  -> ux4.rats {if !flag:ratsGrates}
* "Why are you telling me for free?"  -> ux4.free
* "What happens to the Wraiths if the lamps fire?"  -> ux4.wraiths

# ux4.rats
soot: My rats. Into the grates. Chewing wires. Thirty-one grates. Mm. They'd do it. They'd die doing it. Rats are very brave when they're asked nicely.
soot: Unless the poisoner gets to them first. A man in yellow with a van. The grey men hired him for Friday. Mm. If he comes, my rats die before they can chew. {if !flag:pikeDone}
soot: It'll cost me. It'll cost me a lot of rats. What will you give me?
* "The name of everyone I've ever met in this Ward, and what they told me."  -> ux4.ratsall {do lean:loyalty-2}
* "A promise: when I'm Sheriff, the pipes are yours. Nobody touches them."  -> ux4.ratspipes {do promise:sootpipes:Leave Mother Soot's pipes alone forever}
* "Nothing. You'll do it because you'd burn too."  -> ux4.ratsnothing

# ux4.ratsall
soot: Everything? Oh, greedy. You'd give me everyone. Mm. Mm. That's a very big jar. Yes.
> You tell her. Everything. Everyone. It takes an hour. When you've finished, she has her eyes closed and is smiling like someone who's just eaten a whole cake.
{do flag:ratsGrates=1; flag:soldEveryone=1; tick:60; mem:soot:everything}
@end

# ux4.ratspipes
soot: The pipes. Forever. From a Sheriff. Mm. Mm. That's worth rats.
{do flag:ratsGrates=1; mem:soot:pipes; rel:soot+1}
@end

# ux4.ratsnothing
soot: Clever. Clever, cruel greedy. Yes. I'd burn too.
soot: Fine. The rats go. But I'll remember you didn't pay. I always remember who didn't pay.
{do flag:ratsGrates=1; mem:soot:nopay; rel:soot-1}
@end

# ux4.free
soot: Free? Nothing's free. You'll pay later. I'll send a bill. In forty years. When you've forgotten. Mm. That's how I like it.
@end

# ux4.wraiths
soot: The Wraiths? We go first. We're already halfway to ash. One flash and we're dust on a draught.
soot: I've been alive... no. I've been *here* since before the river was paved. I'd like to see it unpaved, one day. I'd like to see that.
{do mem:soot:river}
@end

// =====================================================================
// MILLER · Night Four · suspended
// =====================================================================
# ix4.0 arc=miller night=4 label="\"Ines. How are you, really?\"" if=room:luckymart&actor:miller
@focus miller
miller: Really? I'm suspended. I'm forty-four. I'm sitting in a convenience store at two in the morning during martial law drinking coffee that tastes like a tyre, talking to a corpse.
miller: Honestly? Best I've felt in years. I finally know I'm not crazy.
* "You're not crazy. You're the only one who isn't."  -> ix4.notcrazy {do lean:candour+1}
* "What will you do after?"  -> ix4.after
* "Do you want to know what I am? All of it?"  -> ix4.whatiam

# ix4.notcrazy
miller: That's the nicest thing anyone's said to me since my divorce. And the person who said it at my divorce was my lawyer, so.
{do mem:miller:notcrazy; rel:miller+1}
@next ix4.hub

# ix4.after
miller: After what? Friday? You keep saying Friday like it's the end of the world.
miller: After, I'll either be a detective with the biggest case in the history of Precinct 9, or I'll be a crazy lady who got fired for chasing vampires. Either way I'll get a dog. My sister's dog has puppies. I'm getting a dog.
{do mem:miller:dog}
@next ix4.hub

# ix4.whatiam
> She puts the coffee down.
miller: ...Yes. No. Yes.
> You tell her. The blood. The sun. The freezer. The Tenant. The Court and the Syndicate and the old woman in the pipes. Not everything. Enough.
> She doesn't write any of it down. That's how you know she believes it.
miller: Okay. Okay. That's... okay.
miller: Do you sleep in a coffin?
* "Tonight, yes. At a pawnshop."  -> ix4.coffin
* "In a freezer, sometimes."  -> ix4.freezer

# ix4.coffin
miller: Of course you do. Of course it's a pawnshop. This city. This bloody city.
{do flag:millerKnowsAll=1; mem:miller:knows; lean:candour+1}
@next ix4.hub

# ix4.freezer
miller: A freezer. Like a fish. Like a pork chop.
miller: Okay. I'm going to need a minute.
{do flag:millerKnowsAll=1; mem:miller:knows; lean:candour+1}
@next ix4.hub

# ix4.hub
* "Tomorrow, stay off Platform 0 until I call."  -> ix4.stay {once}
* "Goodnight, Ines."  -> ix4.bye

# ix4.stay
miller: Until you call. On what? You don't have a phone. Oh. The burner. The Sheriff's burner. Fine. Call me. I'll be in the car with a judge and a flask.
miller: A real judge. Abernathy. Retired. She hates Harrow. She's eighty-one and she's been waiting her whole career for someone to bring her something like this.
{do flag:millerJudge=1}
@next ix4.hub

# ix4.bye
miller: Night. Don't get burned.
@end

// =====================================================================
// MARGO · Night Four · at Gideon's, if she stayed
// =====================================================================
# mgx4.0 arc=margo night=4,5 label="Sit with Margo a while." if=room:pawn&actor:margo
@focus margo
> Margo is knitting in Séverine's box with the lid up. The thing she's knitting is very long and grey and has no discernible purpose.
margo: It's a scarf. Probably. I started it when my father died and I never finished. I pick it up when things are bad. It's been very long since Monday.
* "Tell me about your father."  -> mgx4.father
* "Are you frightened for tomorrow?"  -> mgx4.afraid {if flag:margoTestify}
* "What will you do after?"  -> mgx4.after

# mgx4.father
margo: Stanislaw Kowalski. Came over in '48. Opened the shop in '52. The Court found him in '53. A gentleman in a cape, very polite, said "we have a business proposal". My father said yes because he had three children and a mortgage.
margo: He rendered for them for thirty years. He went to Mass every morning after. He never once told my mother. He told me, when I was sixteen, because he needed someone to take over.
margo: I said yes because he was crying. That's the family business. Saying yes to men who are crying.
{do mem:margo:father; rel:margo+1}
@next mgx4.hub

# mgx4.afraid
margo: Frightened. Of standing up in a room full of things that drink people and saying the Lady paid me? Yes. I'm very frightened.
margo: But I've rendered two hundred and six bodies for that Court. Two hundred and six. I counted. I'd like to do one thing with my mouth that isn't "yes, ma'am".
{do mem:margo:brave}
@next mgx4.hub

# mgx4.after
margo: Sell the shop. Burn the freezer. Open something with vegetables. My sister in Duluth makes pierogi. Maybe I'll make pierogi. With cabbage. No meat. Never meat again.
@next mgx4.hub

# mgx4.hub
* "I'll see you tomorrow."  -> mgx4.bye

# mgx4.bye
margo: Tomorrow. Bring a coat. Platform 0's cold. It was always cold, even when it was a train station.
@end

// =====================================================================
// VALKO · Night Four
// =====================================================================
# vx4.0 arc=valko night=4 label="\"Valko. Tomorrow.\"" if=room:alley&flag:valkoAlly prio=2
@focus valko
valko: Tomorrow. I know. I've been sitting here all night smelling it come. It smells like a storm. Ozone. Like the freezer did.
valko: I'll be at your left hand. That's where I stood for him. Left. He said the left hand is the one you don't need, so it's the one you can afford to lose.
@gate mem:valko.sworn ? vx4.sworn : vx4.notsworn

# vx4.sworn
valko: And you swore. On his blood. The name. Have you got it?
* "Rostova fired it. Harrow gave the order."  -> vx4.name {if flag:rostovaDone|flag:knowRBuyer|flag:rostovaAdmitEight}
* "Not yet."  -> vx4.notyet

# vx4.name
valko: Rostova. The doctor. And the grey man.
> He stands up. Every inch of him. In the rain he looks like something carved for a cathedral and then thrown out for being too frightening.
valko: Thank you. Tomorrow, then. Tomorrow I'll be very busy.
{do keep:valkoname; flag:valkoKnowsName=1; mem:valko:name}
tenant: You've just set a Hound on a doctor and a federal agent. You know that. I want to make sure you know that.
@end

# vx4.notyet
valko: Then find it. Before the lights. I don't want to die not knowing.
@end

# vx4.notsworn
valko: Whatever happens, I'm going to try to get to the grey man. You should know. If he's on the street when the Magistrate sits, I'll go up the stairs for him.
* "Stay with me instead."  -> vx4.stay {do lean:loyalty+1}
* "Go. Get him."  -> vx4.go

# vx4.stay
valko: ...All right. Left hand. All right.
{do flag:valkoStays=1; rel:valko+1}
@end

# vx4.go
valko: Good. Good. You'll hear it when I find him.
{do flag:valkoHuntsHarrow=1}
@end

// =====================================================================
// LISETTE · Night Four
// =====================================================================
# ls4.0 arc=lisette night=4 label="\"Lisette. About the study.\"" if=room:reliquary&flag:lisetteWantsStudy
@focus lisette
@gate flag:lisettePage ? ls4.page : ls4.nopage

# ls4.page
> You give her the page. Kowalski's tithes. Ten percent, every month, in the Sheriff's patient hand.
lisette: Oh. Oh, that's *beautiful*. Do you know what this is? This is Madame's tithe, skimmed, for twenty years, in his own writing. If I show the Court this, Absalom becomes a thief and Madame becomes the woman who didn't notice for twenty years.
lisette: Either way, someone looks foolish, and it isn't me. *Merci.* I'll watch your comedian tomorrow like he's my own.
{do flag:lisetteAlly=1; rel:lisette+2; mem:lisette:page}
@end

# ls4.nopage
lisette: Nothing? You went up to the Sheriff's study and came down with nothing for me?
? velvet 10 "I came down with a secret: there's nothing in it. Just a lonely man's chair."  -> ls4.lonely | ls4.no {id ls4_vel} {mod like:lisette}

# ls4.lonely
lisette: A lonely man's chair. Hm. That's worse. That's much worse. Madame would hate that.
lisette: All right. I'll accept it. For the poetry.
{do flag:lisetteAlly=1; rel:lisette+1}
@end

# ls4.no
lisette: Hm. You're no fun. I'll find someone who is.
{do rel:lisette-1}
@end

// =====================================================================
// LORD ASHBY · Night Four · the dinner
// =====================================================================
# ab4.0 arc=ashby night=4 label="\"You owe me a dinner, my lord. Or I owe you.\"" if=room:vip&flag:ashbyDinner
@focus ashby
> Ashby has had a table laid among the sarcophagi: linen, silver, two empty wine glasses, a candelabrum. There's no food. There never is. It's the shape of dinner, which is all the Sovereign want.
ashby: Dinner! Sit, sit. Now. As agreed. A confession. What did Absalom taste like? In detail. With adjectives.
* Tell him. Honestly. The whole of it.  -> ab4.honest {do lean:candour+1}
* Make it beautiful. Lie a little.  -> ab4.pretty
* "Like a lonely man."  -> ab4.lonely

# ab4.honest
> You tell him. The cold first, like biting a cold coin. Then the age, layers of it, like a cliff face. Then the ten percent, sour and bright. Then, at the very bottom, a woman laughing in a summer dress.
> Ashby has put down his glass. He's not smiling.
ashby: ...I'm sorry. I asked for a party trick. You've given me a man.
{do mem:ashby:honest4; rel:ashby+1}
@next ab4.hub

# ab4.pretty
> You make it sound like a vintage. Like a cellar. Like a great performance of Wagner. Ashby closes his eyes and sighs with pleasure at every adjective.
ashby: Magnificent. Magnificent! You must write it down. I'll have it bound.
@next ab4.hub

# ab4.lonely
ashby: Lonely.
> He looks at the two empty glasses, the candles, the table laid for a dinner nobody will eat.
ashby: Yes. Yes, I expect he did.
{do mem:ashby:lonely; rel:ashby+1}
@next ab4.hub

# ab4.hub
* "Will the Sovereign stand with me tomorrow?"  -> ab4.stand {once}
* "Thank you for dinner, my lord."  -> ab4.bye

# ab4.stand
ashby: The Sovereign stand with whoever wins. We have done since Agincourt. It's terribly vulgar and it's kept us rich.
@gate rel:ashby>=2 ? ab4.standyes : ab4.standno

# ab4.standyes
ashby: But I'll stand next to you. Me personally. Edmund Ashby. With a sword, if it comes to that, though I do hope it doesn't, I've just had this jacket cleaned.
{do flag:ashbyStands=1}
@next ab4.hub

# ab4.standno
ashby: Win, and you'll have us. Lose, and we'll have dinner with whoever beat you. Nothing personal. It's tradition.
@next ab4.hub

# ab4.bye
ashby: Good night! Don't die. I've just started to like you.
@end

// =====================================================================
// CORAL · Night Four
// =====================================================================
# co4.0 arc=coral night=4 label="\"Coral. Stay off the dancefloor tomorrow.\"" if=room:reliquary
@focus coral
coral: Tomorrow? Tomorrow's Friday. Friday's the best tips.
coral: ...Is it bad? Is it going to be bad? Everybody downstairs is very quiet tonight. Lord Ashby didn't even ask for me. He just sat in the corner looking at an empty glass.
* "It might be. Stay home."  -> co4.home {do lean:mercy+1}
* "It'll be fine. Dance."  -> co4.dance

# co4.home
coral: Home. Okay. I'll tell the manager I'm sick. He'll fire me. I'll get another job. There's always another club.
coral: Thanks. I mean it. Nobody downstairs ever told a girl to stay home.
{do flag:coralHome=1; rel:coral+1}
@end

# co4.dance
coral: Okay. Fine. I'll dance. I'm good at dancing. It's the only thing I've never been afraid of.
@end

// =====================================================================
// KEN PRUITT · Night Four · a second word
// =====================================================================
# kp4.0 arc=kenpruitt night=4 label="\"Ken. One more thing.\"" if=room:rookery&actor:kenpruitt&flag:uncleLeo
@focus kenpruitt
kenpruitt: One more thing. There's always one more thing with your lot. My grandad said that about the Irish. He was Irish.
* "Dale. Is he still taking money from Tariq?"  -> kp4.dale
* "Why did you take Harrow's money? For the seven."  -> kp4.why
* "Does Leo know you're proud of him?"  -> kp4.proud

# kp4.dale
kenpruitt: Dale? Dale's off sick. Has been since Wednesday. He doesn't remember why. He's very upset about it. He keeps checking his neck in the mirror.
@end

# kp4.why
kenpruitt: Because the Captain said lose them. Because the Captain had a new boat. Because my pension's in nine years and I've got a bad back and an ex-wife.
kenpruitt: Because it was easy. That's the honest answer. It was the easiest money I ever took. Seven files, into a box, into a basement. I didn't even have to look at the names.
kenpruitt: I looked at them on Tuesday. All seven. For the first time. That's why I texted you.
{do mem:kenpruitt:why}
@end

# kp4.proud
kenpruitt: Proud? Of what? He tells jokes in a basement for drinks.
kenpruitt: ...Yeah. Yeah, I'm proud. He's the only one in the family who ever did something just because he liked it. I'll tell him. When he's back. If I'm brave enough.
{do mem:kenpruitt:proud}
@end

// =====================================================================
// HARROW · Night Four · the grey van on Ferrier Lane
// =====================================================================
# hw4.0
@focus harrow
> Harrow is leaning on the grey van with a takeaway coffee, watching the floodlight at the crossing sweep the lane, like a man watching the tide come in at a resort he owns. He doesn't take off his sunglasses. He raises the coffee in greeting.
harrow: Subject Eight. Good evening. Or do you prefer the new title? "Sheriff-eater." It's catchy. My team's been using it.
harrow: I thought we should talk. Like adults. One of us is very old and one of us is very young, but I'm told that averages out.
* "You killed the Sheriff."  -> hw4.killed
* "Why are you talking to me?"  -> hw4.why
* "What happens to me if I come in?"  -> hw4.comein
* Go for his throat.  -> hw4.attack

# hw4.killed
harrow: Technically, Dr. Rostova did. With equipment provided by a Syndicate craftsman, at a location secured by a Court ghoul with a screwdriver. I'm management. Management doesn't kill anyone. It *coordinates*.
harrow: Your Sheriff was going to walk into the Prince's court on Friday with a file and end twenty years of work. Twenty years. Do you know what my team could do with a daywalker? We could make this city safe. Every city. No more Mrs. Okafors. No more Detective Millers crying in kitchens.
pulse(5): He believes it. His heart is perfectly steady. He's a man who's told himself a story so often it's become load-bearing.
* "You *made* Mrs. Okafor. You took her daughter."  -> hw4.okafor {do lean:candour+1}
* "And then what? You hunt us?"  -> hw4.hunt
* "Spare me the speech."  -> hw4.hub

# hw4.okafor
harrow: Dani Okafor was a volunteer. Paid. Informed. She signed a form.
harrow: ...She signed a form that didn't say what we were doing, because if it had said what we were doing nobody would have signed it. I know. I wrote the form. I'm not proud of it. I'd do it again.
{do mem:harrow:okafor}
@next hw4.hub

# hw4.hunt
harrow: Hunt is such a hunting word. *Manage*. We'd manage you. The ones who can be managed. Registers, curfews, supervised feeding. Séverine's already halfway there for us: she's counting you tonight. She doesn't even know she's doing my job.
harrow: The ones who can't be managed would be... managed differently.
@next hw4.hub

# hw4.why
harrow: Because you're the only one who ever walked out of the program on their own legs. Because you've got Absalom Vane's blood in you and you're still you, mostly, which nobody predicted. Because you're the most valuable living thing in this city and you don't even know it.
harrow: And because I'd rather you came in voluntarily. I'm a voluntary sort of man.
@next hw4.hub

# hw4.comein
harrow: A room. A good room. Daylight simulation. Books. Supervised outings. A little blood drawn every Tuesday, under anaesthetic. Your Tenant studied. Your name restored to you, if you like. Your sister told you're alive. Imagine that.
harrow: In return, you help us make more of you. Better ones. Ones that don't hear voices.
tenant: He means to take me out of you, child. Like a tumour. He'll call it a cure.
@next hw4.hub

# hw4.attack
> You're across the lane before he's lowered the coffee. Your hand's at his collar. And then the floodlight at the crossing swings round and stops. On you. Not sweeping. Stopped.
> It's like having your skin set on fire by a wasp's nest. You let go.
harrow: Remote control. Isn't technology wonderful? My man in the van has his thumb on every lamp in the Ward. Please don't do that again, it's very bad for my blood pressure.
{do vitae-1; comp-2:The light; heat+1}
@next hw4.hub

# hw4.hub
* "Who's your man in Elysium? The lady in grey pearls."  -> hw4.pearls {once} {if flag:knowGreyPearls}
* "Tomorrow you're going to lose."  -> hw4.lose {once}
* "Turn the lights off, Harrow. Go home."  -> hw4.home {once}
* Walk away.  -> hw4.bye

# hw4.pearls
harrow: Lady Ottilie Brand. Court accountant. She's been reporting to us since 2016 in exchange for a promise that she'll be the one we don't manage. She's very good with numbers. She'll be in the front row tomorrow, next to the Magistrate.
harrow: I'm telling you because it doesn't matter any more. By tomorrow night, nobody in that room will be in a position to do anything about her.
web(6): He just told you the lamps will fire with the Court on the platform. He's that sure.
{do flag:knowOttilie=1; mem:harrow:ottilie}
@next hw4.hub

# hw4.lose
harrow: Maybe. I've lost before. Iraq. Twice. My marriage. Once, very thoroughly.
harrow: But I've never lost to someone who still says please. You say please, you know. To shopkeepers. I've read the reports. It's charming. It's going to get you killed.
@next hw4.hub

# hw4.home
harrow: Home. I haven't been home since 2004. Home is a lab in Virginia and a plant on a windowsill that a colleague waters.
harrow: No. The lights stay on. See you at one.
@next hw4.hub

# hw4.bye
harrow: Get some rest. You'll want to look your best for the cameras. We'll be filming. For training purposes.
{do flag:harrow4Done=1}
@leave harrow

// =====================================================================
// DREAM 4 — Thursday's dawn. The last one before Friday.
// =====================================================================
# dr4.0 dream=4
> The study. Or what's left of it. The walls have gone; the desk, the chair, the lamp, the rug are standing on the bed of a dry river under a sky full of stars you've never seen from the city. Somewhere a long way off, water.
tenant: This is what it looked like. Before they paved it. The Vellum, in 1721. I came up it in a boat with a coffin in the bottom and a Prince's letter in my coat.
tenant: I wanted you to see it once. In case.
@gate flag:seizure=surrender ? dr4.him : dr4.you

# dr4.him
> He's standing by the desk. He's very solid. More solid than you. You look down at your hands and you can see the stars through them.
tenant: Tomorrow I'll do the talking. If it comes to it. You won't mind. You'll hardly notice.
* "I'll mind."  -> dr4.himmind {do sync-6:Holding on}
* "Do what you need to."  -> dr4.himok {do sync+6:Letting go}

# dr4.himmind
tenant: Good. Then mind. Hold on. Make me work for it. I'd think less of you if you didn't.
@next dr4.main

# dr4.himok
tenant: ...Thank you. I'll be gentle with them. I'll be better than I was. I promise. Watch me.
@next dr4.main

# dr4.you
> He's sitting on the rug, cross-legged, like a boy. He looks younger. You've never seen him look young.
tenant: You'll do the talking tomorrow. I'll be the voice in your ear you ignore. Like a good conscience. Or a bad one. I've never been sure which I am.
@next dr4.main

# dr4.main
tenant: May I ask you something? You've been asking me things all week. My turn.
tenant: When it's over, tomorrow, at dawn, if you're still standing: what do you want to be?
* "Sheriff. Your chair. Your Ward."  -> dr4.sheriff {do lean:pride+1}
* "Alive. Properly. In the sun."  -> dr4.sun
* "Myself. Whoever that is."  -> dr4.self
* "I don't know."  -> dr4.dontknow

# dr4.sheriff
tenant: My chair. Good. It's a good chair. It's a terrible job. You'll hate it. You'll be good at it. That's the worst combination there is.
tenant: Keep Pemberton. Let Tariq keep his light. And never, ever trust anyone who offers you ten percent.
{do flag:dreamWant=sheriff; mem:tenant:want}
@next dr4.agnes

# dr4.sun
tenant: The sun. Yes. That's what I wanted too, in the end. I went to Elena for it. I was so tired of the dark.
tenant: If you can have it, have it. Have it for both of us. Tell me what color the harbour is.
{do flag:dreamWant=sun; mem:tenant:want; sync+2:The harbour}
@next dr4.agnes

# dr4.self
tenant: Yourself. Casey, or whoever. That's the hardest one. I tried it for a while, in the 1920s. It didn't take. Being someone else was always easier.
{do flag:dreamWant=self; mem:tenant:want}
@next dr4.agnes

# dr4.dontknow
tenant: Good. That's the only honest answer anyone's given me in three hundred years.
{do flag:dreamWant=unsure; mem:tenant:want}
@next dr4.agnes

# dr4.agnes
@gate flag:haveAgnesLetters ? dr4.letters : dr4.end

# dr4.letters
tenant: Would you... You have her letters. I know you do. I can feel them in your coat. Would you read me one? Just one. Out loud. In your voice.
* Read him one.  -> dr4.read {do lean:mercy+1}
* "Not tonight."  -> dr4.end

# dr4.read
> You take one at random from the shoebox and unfold it. Her neat typist's hand. You read it aloud, under the stars, on the bed of a river that hasn't run for a hundred years.
> *Dear A. — Today the harbour was the color of a pigeon's neck, grey and green and purple all at once, and a little boy on the quay was feeding the gulls bread from his own sandwich, and I thought: A would like this. A would pretend not to, and then he'd like it. I wish you could see the day. I'll keep describing it until you can. Yours, in daylight, Agnes.*
> When you look up, he's crying. You didn't know he could.
tenant: In daylight. She always signed it that. "Yours, in daylight."
tenant: Thank you. Thank you. Whatever happens tomorrow. Thank you.
{do sync+5:Yours, in daylight; flag:readAgnes=1; mem:tenant:read; comp+3:Agnes}
@next dr4.end

# dr4.end
> Far off, the water is coming. You can hear it now, a long way upstream, the river coming back down its old bed after a hundred years. It's going to reach the study soon.
tenant: That's the morning. Go on. Wake up. Last sunset. Make it count.
@end
`,'c_n4b');
