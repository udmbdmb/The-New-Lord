'use strict';
/* THE NEW LORD — callbacks: people remember specific things you did, and bring them up when you least expect it */
NL.Script.add(String.raw`
# cbk.leojoke arc=leo night=4,5 label="\"Leo. You're grinning.\"" if=flag:leoJokeTested&alive:leo&!flag:leoThrall prio=2
@focus leo
leo: I did the bit. The one you laughed at. "The only British vampire in America." At the Lantern Room on Tuesday. Well, I did it in the parking lot first, to a fox. Then I did it at the Lantern Room.
leo: It KILLED. Nine people. Nine people laughed. One of them was the barman and he never laughs, he's got a condition.
leo: I want to give you a writing credit.
* "Put my name on it."  -> cbk.lj1 {if name}
* "Put 'the Tenant' on it."  -> cbk.lj2
* "It's yours, Leo. All yours."  -> cbk.lj3

# cbk.lj1
leo: "Additional material by Casey Morrow." That's going on the flyer. I'm getting flyers. I've never had flyers.
{do rel:leo+1; comp+1}
@end

# cbk.lj2
tenant: (delighted) Oh, yes. Yes. Do it.
leo: "Additional material: the Tenant." Like a band. Like a mysterious band.
{do rel:leo+1; sync+1}
@end

# cbk.lj3
leo: All mine. Okay. Okay, but I'm buying you a... I can't buy you a drink. I'm buying you a drink anyway. I'll drink it for you.
{do rel:leo+1}
@end

# cbk.gidbox arc=gideon night=4,5 label="\"Gideon. You remember Monday?\"" if=alive:gideon&rel:gideon>=3 prio=-1
@focus gideon
gideon: Monday. When you came in out of the rain with a dead man's coat on and blood on your collar and asked if I had "somewhere quiet".
gideon: You said please. Covered in blood, five hours dead, and you said "please, if it's not too much trouble". I almost fell off my stool.
gideon: I decided then. Whatever you were. I'd keep the box.
{do rel:gideon+1; comp+1}
@end

# cbk.malname arc=malakor night=5 label="\"Mikołaj.\"" if=mem:malakor.name&alive:malakor prio=1
@focus malakor
malakor: Shh. Not here. Not on the platform. Not in front of all of them.
malakor: ...Say it again, though. Quietly.
* Say it again. Quietly.  -> cbk.mn1
* "After. If there's an after."  -> cbk.mn2

# cbk.mn1
> You say it. He closes his eyes. For a second, on the edge of Platform 0 with three hundred Kindred behind him, a butcher's boy from Kraków stands very still and listens to his own name.
malakor: Thank you. Now go and win. I've bet a great deal of money on you. Well. A great deal of other people's money.
{do rel:malakor+1}
@end

# cbk.mn2
malakor: After. Yes. I'll hold you to it. I'll invoice you if you're late.
@end

# cbk.sootjar arc=soot night=5 label="\"Mother. Is my jar safe?\"" if=flag:sootJar&alive:soot prio=2
@focus soot
soot: Safe. Safe, safe. Mm. On the high shelf. Next to Mathilde. I put them together so they'd have company.
@gate flag:sootJar=empty ? cbk.sj2 : cbk.sj1

# cbk.sj1
soot: If you go in the light tonight, I'll open it. Once a year. On Fridays. And listen. Mm. That's what jars are for.
{do comp+1}
@end

# cbk.sj2
soot: The empty one. Still empty. Still open. I didn't cork it. Mm. You said let you go. I'm letting. It's very hard. I've never let anyone.
{do comp+1; rel:soot+1}
@end

# cbk.valask arc=valko night=5 label="\"Valko.\"" if=mem:valko.asked&flag:valkoAlly&!flag:valkoDead prio=1
@focus valko
valko: Ask me again. Like on the cobbles. Before we go down.
* "What's wrong, Valko?"  -> cbk.va1

# cbk.va1
> He thinks about it properly. Hounds don't lie and they don't rush.
valko: Nothing's wrong. That's what's wrong. Everything is right, and we might all be ash by morning, and for the first time in forty-seven years I'm not alone. It's terrifying. I like it.
valko: Your turn. What's wrong?
* Tell him the truth.  -> cbk.va2

# cbk.va2
> You tell him. You're scared. You're five days old. You're carrying a dead man and a city and you said please to a Magistrate and you don't know what you're doing.
valko: Good. That's the right answer. Hounds who aren't scared don't come home.
{do rel:valko+1; comp+2}
@end

# cbk.okacup arc=okafor night=5 label="\"Mrs. Okafor. The second cup.\"" if=rel:okafor>=3&!flag:okaforDead prio=1
@focus okafor
okafor: I'm putting it out tonight. The second cup. And a third. For whoever comes back.
okafor: If nobody comes back, I'll drink them all myself, and I'll be up all night, and I'll be furious.
okafor: Come back. That's all. I'm not asking much. Dani never did, either. Just come back.
* "I'll come back."  -> cbk.oc1 {do promise:okaforcup:Come back to Mrs. Okafor's kitchen}
* "I'll try."  -> cbk.oc2

# cbk.oc1
okafor: Good. I'm holding you to it. I've held better people to worse.
{do rel:okafor+1}
@end

# cbk.oc2
okafor: Try. Dani said she'd try. Try's not enough. Come back.
@end

# cbk.tarcal arc=tariq night=5 label="\"Tariq. The calendar.\"" if=flag:racketDone=calendar&alive:tariq prio=2
@focus tariq
tariq: Dale came in yesterday. On his own. Not for money. He bought a Mars bar. He paid for it.
tariq: He stood there and ate it at the counter and didn't say anything. Then he said, "your old man was all right," and left.
tariq: Patience. My father would say: see? Patience.
{do rel:tariq+1; comp+1}
@end

# cbk.sevwrist arc=severine night=5 label="\"My lady.\"" if=flag:sevBond&alive:sev prio=6
@focus severine
> She's waiting on the stairs down to Platform 0, in black, with her gloves on. She looks at you the way you'd look at a cup of something you'd been sipping.
severine: Darling. You've been thinking about me. Don't deny it. I can feel it, a little, at the back of my teeth. It's very flattering.
severine: Tonight I vouch for you. Tomorrow... tomorrow you could come back to the crypt. Just for a taste. The second taste is so much sweeter than the first.
tenant: Child. Don't. Don't even answer.
* "No. Thank you, my lady. Once was enough."  -> cbk.sw1 {do lean:restraint+1}
* "Tomorrow."  -> cbk.sw2 {do lean:restraint-1}
* Say nothing. Walk past her down the stairs.  -> cbk.sw3

# cbk.sw1
severine: Once. Yes. That's what Absalom said in 1888. He lasted nine years.
> She smiles. She lets you go past.
@end

# cbk.sw2
severine: Tomorrow. Good. I'll have the crypt aired.
tenant: ...God help us. God help us both.
{do flag:sevBond2=1}
@end

# cbk.sw3
> You walk past her. You feel her look on the back of your neck all the way down the stairs, like a hand.
@end

# cbk.rosaleo arc=leo night=5 label="\"Leo. Your mom's with Ken.\"" if=flag:kenRosa|flag:kenConfessRosa prio=4
@focus leo
leo: Uncle Ken. In my flat. With Mom. Eating stew. They haven't spoken since 2019 and now they're in my kitchen arguing about Grandma's will like it's Christmas.
leo: Did you do this? You did this. I can tell you did this. You've got your face on.
* "I might have."  -> cbk.rl1

# cbk.rl1
leo: It's the worst thing anyone's ever done for me. It's the best. They threw a gravy boat. It didn't break.
leo: Thank you. I hate you. Thank you.
{do rel:leo+2; comp+1}
@end
`,'c_callbacks');
