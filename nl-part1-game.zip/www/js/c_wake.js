'use strict';
/* THE NEW LORD — "The Ash Rite": on Tuesday night, the Court says goodbye to Absalom Vane. By the oldest law, the one who carries him is expected to speak last. */
(function(){const S_=NL.Script;
NL.TASKS.s_wake={n:'The Ash Rite',xp:70,cat:'side'};
S_.place({id:'ashrite',name:'The Ash Rite, the Ossuary',block:'B',sub:'Tonight at three, under the Reliquary, the Court says goodbye to the Sheriff. A card under your door says only: "You are expected."',if:'night:2&time>=150&time<300&flag:mapOK&!flag:wakeDone',node:'wk.0',min:6});
})();
NL.Script.add(String.raw`
# wk.0
> The Capuchin ossuary under Club Reliquary, at three in the morning. Every candle lit. The skulls on the walls, row on row, catching the light like a congregation. Forty Kindred in black, standing, silent. The Gilded Court, the Syndicate, a scatter of Wraiths in the arches. No music.
> On a stone plinth in the center: a black lacquered box, the size of a hatbox. Inside it, everything that was left in Kowalski's freezer on Monday morning that wasn't you.
pemberton: (at your shoulder, very quietly, from nowhere) ‹Sir›. Thank you for coming. It isn't required by law. It's required by something older.
pemberton: Each of them will speak. Then the box goes into the river. And at the end, by custom, the one who carries him speaks last. Nobody has done that in this city since 1888. You may decline. Nobody will stop you. They will remember.
{do task:s_wake; note:s_wake|The Court's farewell for Absalom Vane. By old custom, the one who carries the dead speaks last.}
* Stand at the back.  -> wk.back
* Stand at the front, by the box.  -> wk.front {do lean:pride+1}

# wk.back
tenant: (very quietly) The back. Of course. I'd have stood at the back of my own rite. You learn so quickly.
@next wk.speeches

# wk.front
> You walk to the front, past forty Kindred who step aside for you the way you'd step aside for a hearse. You stand beside the box. Nobody says anything. Somebody in the Gilded rows makes a small sound like a held breath.
tenant: (very quietly) ...The front. At my own rite. Child, you've no idea how much they hate you for that, and how much they're impressed.
@next wk.speeches

# wk.speeches
> Séverine speaks first. She speaks in French, then English, then French again. She says he was the most infuriating man she ever knew. She says he kept the Ward for eighty years "with the grace of a man folding a napkin". She doesn't look at you once. {if alive:sev}
> Malakor speaks second. He says Absalom owed him money. He says it's the first debt he's ever been glad to write off. He says he built the weapon that killed him and he would like it noted that it worked perfectly, and then he stops, and doesn't say anything else for a while, and then he sits down. {if alive:malakor}
> Mother Soot doesn't come up to the box. From the back, in the dark, one long word that isn't a word: a sound like water in a pipe. The Wraiths in the arches repeat it, softly, all of them. Then silence. {if alive:soot}
> Pemberton speaks last of the household. He says: "He was a difficult man to drive. He always wanted the window down." And then he can't say anything else, and Lisette, of all people, takes his elbow and walks him back to his place.
> And then they're all looking at you.
@next wk.you

# wk.you
> Forty faces, in candlelight, under the skulls. Waiting for the thief to speak over the thing it stole.
* Tell them the truth. The freezer. The light. Why you drank.  -> wk.truth {do lean:candour+1}
* Tell them who he was to you: a stranger, then a voice, then company.  -> wk.voice
* Let him speak. Through you. His own farewell.  -> wk.him {if sync>=25}
* Say his name, and nothing else.  -> wk.name
* Say nothing. Bow to the box. Step back.  -> wk.bow
* "I'm not sorry. He'd have burned. I didn't."  -> wk.defiant {do lean:pride+1}

# wk.truth
> You tell them. Not all of it; you don't know all of it yet. But what you know: the freezer, the light coming through the door at 4:14, an old man kneeling and burning, the smell of it, and your mouth on his throat because there was nowhere else for him to go.
> "I didn't steal him," you say. "I caught him."
> The ossuary is very quiet. Somewhere at the back, a Wraith makes a sound that might be a sob.
pulse(6): Séverine's heart, the one that doesn't beat, has done something. Her hand has gone very still on her fan.
{do flag:wakeSpoke=truth; rel:severine+0; rel:pemberton+2; sync+2; xp:30:The Ash Rite}
@next wk.box

# wk.voice
> "I didn't know him," you say. "On Monday he was a stranger in a freezer. On Tuesday he was a voice that wouldn't shut up. Tonight he's... company. I've never had anyone in my head who argued with me about rugs."
> Somebody laughs. Not cruelly. Surprised. Then Malakor does, loud, and claps once.
malakor: (from his seat) He DID love that rug.
{do flag:wakeSpoke=voice; rel:malakor+1; rel:pemberton+1; comp+2; xp:30:The Ash Rite}
@next wk.box

# wk.him
> You let go. Just a little.
tenant: (out loud, through you, in his own voice, which every Kindred in the room has heard for a hundred years) Thank you for coming. Most of you didn't like me. That's quite all right. I didn't like most of you. Ambrose, if you're listening through the walls: forty francs.
tenant: I'm not in the box. I'm here. I'm in the child. Be kind to the child. The child is kinder than I was, and braver, and better at being polite to Pemberton.
> Forty Kindred go absolutely white. Pemberton makes a sound. Séverine's fan snaps in half in her hand.
{do flag:wakeSpoke=him; sync+5; rel:pemberton+3; rel:severine-1; flag:courtKnowsVaneLives=1; xp:40:The Ash Rite}
@next wk.box

# wk.name
> "Absalom Vane," you say. Just that.
> It goes round the ossuary like a coin being passed hand to hand. Nobody says it back. Everybody hears it.
{do flag:wakeSpoke=name; comp+1; xp:20:The Ash Rite}
@next wk.box

# wk.bow
> You bow. Low. From the waist. The way he'd have done it, though you don't know how you know that.
> When you straighten, three of the oldest Kindred in the room have bowed too. To the box, or to you, you can't tell.
{do flag:wakeSpoke=bow; rel:pemberton+1; xp:20:The Ash Rite}
@next wk.box

# wk.defiant
> The ossuary goes cold.
> "I'm not sorry," you say. "He'd have burned. I didn't. If you want someone to blame, look for the person who turned the light on."
> Forty Kindred look at you with an expression you've only seen on the faces of people watching a car crash in slow motion. Then, very slowly, some of them start to look at each other.
{do flag:wakeSpoke=defiant; rel:severine-2; rel:malakor+1; xp:30:The Ash Rite}
@next wk.box

# wk.box
> Then it's done. Pemberton picks up the black box in both hands, the way you'd carry a sleeping cat. The Court files out after him in silence, up through the club, out onto Reliquary Row, down to the river.
> At the Vellum Steps, at the bottom, there's a boat waiting, and a figure in a wide-brimmed hat with the oars across his knees.
ferryman: This one's already across. I know. I'll take what's left anyway. It's only polite.
> Pemberton hands down the box. The boat pushes off without a ripple and the river takes it, the way the river takes everything.
* Watch until it's gone.  -> wk.watch
* Turn away before it's gone.  -> wk.turn

# wk.watch
> You watch until there's nothing to watch. When you turn round, most of the Court has gone. Pemberton is still there. And, at the top of the steps, very small, with her rats: Mother Soot.
soot: Mm. Good. Somebody stayed. Somebody always should.
{do flag:wakeDone=1; task:s_wake=done; comp+2; rel:soot+1}
@end

# wk.turn
tenant: (very quietly) Good. Don't watch. I never watched any of them go. Not one, in two hundred years. It's the only habit of mine I'd like you to keep.
{do flag:wakeDone=1; task:s_wake=done; comp+1}
@end
`,'c_wake');
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);const w=S.flags.wakeSpoke;
  if(w==='truth'||w==='him')M.push({t:'"Ask the forty who were at his Ash Rite on Tuesday what I said over the box."',once:'tb_wake',ok:st=>{st.prog+=1;return [T('A murmur. Forty of the three hundred were there. Some of them nod. One of the oldest, a Wraith in the arches, says one word, very clearly, into the silence: "Caught."')];}});
  return M;};})();
