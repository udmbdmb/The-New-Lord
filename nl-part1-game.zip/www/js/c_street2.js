'use strict';
/* THE NEW LORD — street events, part two: the stranger things */
(function(){const X=NL.EXTRAS;const P=(n,role,skin,hair,shirt,coat,o)=>Object.assign({n,role,color:'#b8c0c8',spec:Object.assign({skin,hair:{style:hair[0],color:hair[1]},shirt,coat:coat?{color:coat,length:.5,collar:true}:null},o||{})});
Object.assign(X,{
  drainwraith:P('A voice in a drain','Under Ferrier Lane',[.6,.62,.66],['long',[.3,.3,.32]],[.2,.2,.22],null,{eyes:[.8,.85,.95]}),
  cougher:P('A coughing man','Rot-sick',[.8,.74,.62],['crop',[.3,.25,.2]],[.4,.45,.35],[.3,.32,.28]),
  alch:P('A man with a fountain pen','An Alchemist, passing through',[.9,.8,.74],['slick',[.2,.12,.08]],[.9,.9,.88],[.1,.12,.1],{eyes:[.35,.85,.55],eyeGlow:[.2,.6,.3]}),
  strays:P('A clanless girl','Local 0',[.7,.56,.46],['curly',[.6,.1,.5]],[.2,.2,.2],[.25,.2,.15],{eyeGlow:[.4,.25,.05]}),
  homeless:P('A man in a sleeping bag','Under the flyover',[.8,.66,.6],['long',[.4,.35,.3]],[.3,.3,.25],[.25,.25,.2]),
  singer:P('A voice from a window','Halloran Street, fourth floor',[.9,.82,.78],['bun',[.2,.15,.1]],[.9,.88,.85],null)
});})();
NL.Script.add(String.raw`
// =====================================================================
// A VOICE IN THE DRAIN
// =====================================================================
# ev.drain street=2,3,4
> Ferrier Lane. As you pass the storm drain by the bins, something in it says, very politely:
drainwraith: Excuse me. Excuse me. Have you got a mirror? A little one. A compact. I've lost my face and I'd like to check if it's come back.
echo(4): Down in the drain, six feet below the grate, standing in black water: a Wraith. Young. Grey. Very thin. Holding a candle in a jam jar.
* "I don't have a mirror. But you look fine."  -> ev.dw1 {do lean:mercy+1}
* "What happened to your face?"  -> ev.dw2
* "Go and see Mother Soot."  -> ev.dw3
* Hold your hand over the grate so she can see her reflection in your eyes.  -> ev.dw4 {if clan:glass}

# ev.dw1
drainwraith: Fine. FINE. Really? You're not just saying?
pulse(3): She looks like a corpse that's been in a river for a month. But she wants to hear it so badly.
drainwraith: ...Thank you. Nobody's said fine to me since 2009.
{do xp:5}
@end

# ev.dw2
drainwraith: The blood ate it. Slowly. Like the tide takes a sandcastle. Every night a bit more. I used to be pretty. I had a boyfriend who said I looked like Audrey Hepburn.
drainwraith: Now I live in a drain and ask strangers for compacts. Life. Death. Whatever this is.
@end

# ev.dw3
drainwraith: Mother. Yes. Mother says we have to learn to love our real faces. Mother has a face like a burnt candle and she's very happy. I'm not ready.
@end

# ev.dw4
> You crouch. You let the light do the thing your blood does: your eyes become still water. She looks up into them from the drain and sees herself, not as she is, but as she was the night before it started, smiling, with lipstick on.
drainwraith: ...Oh. Oh, there I am. There I am.
> When you stand up, she's crying, and laughing, in the drain, with her candle.
{do xp:15; lean:mercy+1}
@end

// =====================================================================
// SOOT'S POSTMAN
// =====================================================================
# ev.rat street=2,3,4,5 if=flag:metSoot
> A rat sits up on the curb in front of you and won't move. It has something tied to its back with a red thread: a curl of paper. When you take it, the rat says "mm" and runs into the drain.
@gate night:2 ? ev.rat2 : ev.ratn

# ev.rat2
> *Greedy. The Lady has a man watching your haven. Grey hair, brown coat, smokes menthols. He's been there since sunset. Mm. — S.*
{do flag:sootTipHaven=1}
@end

# ev.ratn
@gate night:5 ? ev.rat5 : ev.rat34

# ev.rat34
> *The grey men are counting the grates again. They've counted to thirty-one four times. They don't trust their own numbers. Neither do I. Mm. — S.*
@end

# ev.rat5
> *Tonight. One o'clock. Bring a candle for me. I can't carry one up all those stairs and hold the rail. Mm. — S.*
@end

// =====================================================================
// THE COUGHING MAN
// =====================================================================
# ev.cough street=2,3,4
> On the steps of St. Jude's, a man in a green anorak is coughing so hard he's bent double. Between coughs he laughs. His breath smells of roses and mildew.
cougher: Sorry. Sorry. Can't stop. Can't stop laughing either. It's the best I've ever felt. I feel *amazing*. I've coughed up something green and I feel amazing.
autopsy(5): Rot. The blood-mould from Ward 4. It's spreading. He's euphoric because it's eating him, and it wants him to enjoy it.
@gate done:c_rot ? ev.co_done : ev.co_open

# ev.co_done
> The cough stops while you watch. He blinks. He looks around at the steps and the hospital and his own hands as if he's waking up.
cougher: ...Oh. Oh, I feel terrible. I feel really terrible. What was I laughing about?
web(4): The cure from Ward 4 is working. Whatever you did there, it's reaching people on the steps.
{do xp:10}
@end

# ev.co_open
* Get him inside. Into triage.  -> ev.co1 {do lean:mercy+1}
* Drink from him. The Rot blood would feed you well.  -> ev.co2 {if clan:rot}
* Leave him. He's happy.  -> ev.co3

# ev.co1
> You get him through the doors with his arm over your shoulder, laughing. Rostova, or a nurse, or someone, takes him. He waves at you from the trolley like a man waving from a train.
{do xp:10}
@end

# ev.co2
> Rot-sick blood is rich for you: dense and sweet and full of the thing that's killing him. You take a little. When you let go, he's stopped laughing, and the green has gone out of his lips.
cougher: ...I feel worse. Why do I feel worse? What did you do?
{do feed:3:phlegmatic:a coughing man:mortal; xp:10}
@end

# ev.co3
> You leave him. Behind you, laughing and coughing, coughing and laughing, all the way down the steps.
@end

// =====================================================================
// A FACE IN A BIN
// =====================================================================
# ev.face street=2,3,4
> Behind Platform 0, in a skip outside Malakor's back door: a face. Not a head. A face, peeled off neat as a glove, folded once, lying on top of the rubbish bags. A man's face, about forty, with a moustache.
abattoir(4): Beautiful work. Clean edges, no tearing. That's a discarded commission. Someone paid Malakor for a new face and he threw the old one away.
gutter(5): Someone in this Ward is walking around tonight in a brand-new face. And somewhere, somebody's missing a husband with a moustache.
* Take it to Malakor and ask whose it was.  -> ev.fa1 {if alive:malakor}
* Leave it.  -> end
* Burn it with your lighter.  -> ev.fa3 {if has:lighter}

# ev.fa1
malakor: That? That's a Mr. Henshaw. Insurance fraud. Now he's a Mr. Patel, from Leicester, with a lovely nose. Very satisfied customer.
malakor: Don't look at me like that. He wasn't dead. He wanted to be someone else. Half this city does. I just do it properly.
{do rel:malakor+0}
@end

# ev.fa3
> It goes up with a smell like a pork crackling and a sound like a sigh. You stand there till it's ash.
@end

// =====================================================================
// THE ALCHEMIST'S NAPKIN
// =====================================================================
# ev.contract street=2,3,4
> A late café on Reliquary Row. A man in a white suit at a window table beckons you in with a fountain pen. On the table, a paper napkin, closely written in green ink.
alch: You look like someone who's about to need a favour. I'm passing through. I sell favours. Small ones. Contract-blood. Sign here and I'll do one thing for you, any time before Saturday. In return, you'll do one thing for me. Some time. After.
pedigree(5): An Alchemist's contract. Binding, in the blood. If you break it, you'll burn. If he breaks it, he will.
* Sign. "What's the favour?"  -> ev.ct1 {do lean:loyalty+1}
* "What would you want from me?"  -> ev.ct2
* "No thank you."  -> ev.ct3

# ev.ct1
alch: You'll find out. That's the delightful part.
> You sign. The green ink drinks a drop of your blood from the pen nib. Something in your wrist goes tight, like a string being tuned.
alch: There. Now: my favour to you. One question, answered truthfully. Anything. Go.
* "Who sired me?"  -> ev.ct1a
* "Will I survive Friday?"  -> ev.ct1b
* "Where is the Sun-Vessel right now?"  -> ev.ct1c

# ev.ct1a
alch: Nobody. Your sire is the man you drank. You were mortal on Sunday. The blood you have is his, entirely. That's the most unusual thing I've ever been asked to confirm.
{do promise:alchfavour:Owe a passing Alchemist one favour, some day}
@end

# ev.ct1b
alch: The blood says: maybe. It depends on how many people you've been kind to and how many you've lied to. It's counting. It's always counting.
{do promise:alchfavour:Owe a passing Alchemist one favour, some day}
@end

# ev.ct1c
alch: Ah. That's a good one.
@gate vessel:you ? ev.ct1cy : ev.ct1cn

# ev.ct1cy
alch: In your left inside pocket. You're touching it now. You didn't know you were touching it. You've been touching it all night.
{do promise:alchfavour:Owe a passing Alchemist one favour, some day}
@end

# ev.ct1cn
alch: Not with you. Somewhere dark. Somewhere that hums. That's all the blood will say.
{do promise:alchfavour:Owe a passing Alchemist one favour, some day}
@end

# ev.ct2
alch: Oh, something small. Carry a letter. Open a door. Forget a face. I collect small favours from a great many people and spend them, very carefully, a long time later.
@end

# ev.ct3
alch: Very wise. Very dull. Here's my card.
> It's blank.
@end

// =====================================================================
// THE PUDDLE
// =====================================================================
# ev.puddle street=2,3,4 if=clan:glass
> A puddle on Halloran Street, perfectly still. In it, you, but not now. Twenty minutes from now: standing somewhere with three hundred faces turned toward you, and a light under your feet.
> No. Not twenty minutes. Friday.
* Look closer.  -> ev.pu1
* Step in it. Break the picture.  -> ev.pu2

# ev.pu1
> You look closer. In the puddle, on Friday, you're holding something up to the Magistrate. You can't see what. Your mouth is moving. Whatever you're saying, three hundred faces are listening.
> Then a car goes past and the puddle shivers and shows you only the streetlight.
{do flag:mirror_puddle=1; xp:10}
@end

# ev.pu2
> Splash. The picture breaks into a hundred pieces of orange light.
tenant: Very wise. The future is like a cat. Look at it too long and it walks off.
@end

// =====================================================================
// THE SONG FROM THE WINDOW
// =====================================================================
# ev.song street=2,3,4
> Halloran Street, three in the morning. From an open window on the fourth floor of a block of flats, a woman singing. Not a radio. A real voice, unaccompanied, an old hymn, the kind they sing at funerals by the sea.
singer: *...and the night shall be no more; and they need no candle, neither light of the sun...*
@gate clan:choir ? ev.sg1 : ev.sg2

# ev.sg1
> Your blood answers. You can't help it. Under the window you open your mouth and sing the harmony, and the dead hear it as a chord and the living hear it as a draught, and the woman in the window stops and looks down into the dark street and can't see anyone.
singer: Hello? ...Hello? Is someone there?
> Then she sings the verse again, louder, as if she'd heard you after all.
{do comp+2:A hymn; xp:10}
@end

# ev.sg2
> You stand under the window until she's finished. Then she closes it. It's the most beautiful thing you've heard all week.
nostalgia(4): A funeral by the sea. Rain. Somebody's grandmother. You were small, holding a hand.
{do comp+1:A hymn}
@end

// =====================================================================
// THE STRAYS AND THE COURT GHOUL
// =====================================================================
# ev.stray street=3,4
> Under the railway arch on Dock Road: three clanless kids in hoodies have a Court ghoul up against the wall. He's big, in a good suit, with a briefcase. They're taking turns slapping his face. Not hard. Humiliating.
strays: Count THIS, you lackey. Count us. Go on. Put us on your register.
> The ghoul's nose is bleeding. The kids are getting excited by the blood. One of them has started to show her teeth.
pulse(4): The ghoul's heart is racing. The girl's eyes have gone amber at the edges. In about thirty seconds this stops being a prank.
* "Enough. Let him go."  -> ev.sy1
* Walk on. The Court had it coming.  -> ev.sy2 {do lean:pride-1}
* Join in.  -> ev.sy3 {do lean:restraint-1}

# ev.sy1
@gate flag:side_union|clan:stray|flag:local0Done ? ev.sy1a : ev.sy1b

# ev.sy1a
strays: Oh, it's the Sheriff-eater. Dutch says you're all right. Fine. FINE.
> They let him go. He runs, briefcase over his head.
strays: Tell him to put that on his register.
{do xp:10}
@end

# ev.sy1b
strays: Or what? You're Court too. Look at that coat.
? apex 10 "Or you meet me, instead of him."  -> ev.sy1c | ev.sy1d {id ev_stray}

# ev.sy1c
> They look at you. They look at each other. They let him go.
{do xp:10}
@end

# ev.sy1d
> They laugh at you. But the ghoul's already slipped out during the argument and is sprinting toward the Reliquary with his tie over his shoulder.
@end

# ev.sy2
> You walk on. Behind you, the slapping stops, and something else starts, and then a scream that cuts off.
{do heat+1}
@end

# ev.sy3
> You take a turn. Just one. The ghoul looks at you with real fear: not of the kids, of *you*, in that coat, with that face.
strays: YESSS. Sheriff-eater's one of us!
{do rel:dutch+1; heat+1}
@end

// =====================================================================
// THE GREY VAN
// =====================================================================
# ev.van street=3,4,5
> Under the Halloran flyover, a grey van with no markings, doors open. Two men in grey are lifting a man in a sleeping bag into the back. He's not resisting. He's asleep, or drugged. A third man with a clipboard is ticking a box.
lanterntech: Department of Health. Welfare check. Move along, please.
web(6): LANTERN, collecting. Under the curfew. A man nobody would miss. The way they collected the seven.
* "Put him down."  -> ev.va1 {do lean:mercy+1}
* Follow the van.  -> ev.va2
* Move along.  -> ev.va3 {do lean:mercy-1}

# ev.va1
lanterntech: Excuse me?
* Show them what you are.  -> ev.va1a {do heat+1}
? stagecraft 10 "I'm his social worker. He's got a hospital appointment at nine. You'll need my signature."  -> ev.va1b | ev.va1c {id ev_van}

# ev.va1a
> You let them see. The clipboard man drops the clipboard. The two lifting the sleeping bag drop the sleeping bag. They're in the van and gone in eight seconds.
> The man in the sleeping bag wakes up on the sidewalk and looks at you.
homeless: ...Is it morning?
{do xp:20}
@end

# ev.va1b
> The clipboard man frowns, checks his sheet, says something about "procedure", and they put the man down very carefully on his cardboard and leave.
{do xp:20}
@end

# ev.va1c
lanterntech: Nice try. Get in the van or get out of the way.
> They drive off with him. You'll never know his name.
{do comp-1:The van}
@end

# ev.va2
> You follow the van on foot, through the floodlit streets, keeping to the shadows between sweeps. It goes to St. Jude's. To the back. To the loading bay where the Kowalski van used to park.
> Two men carry the sleeping bag in through a door marked B1 · NO ENTRY.
{do flag:knowVanRoute=1; tick:20}
@end

# ev.va3
> You move along.
@end

// =====================================================================
// MILLER, ASLEEP IN HER CAR
// =====================================================================
# ev.miller street=3,4 if=met:miller
> On Ferrier Lane, a dented blue Honda with its engine running and the windows fogged. Inside, Detective Miller, asleep, her head against the window, a file open on her lap, a cold coffee in the cup-holder.
pulse(4): Deep sleep. The first in days. She's been sitting here watching the Lucky Mart and her body just stopped.
* Leave her. She needs it.  -> ev.mi1 {do lean:mercy+1}
* Turn off her engine. Fumes.  -> ev.mi2
* Read the file on her lap.  -> ev.mi3 {do lean:candour-1}

# ev.mi1
> You leave her. You stand at the end of the lane for an hour, in the dark, keeping an eye on the car. Nobody comes near it. When she wakes at four and drives off, she'll never know.
{do tick:20; rel:miller+0; xp:10}
@end

# ev.mi2
> You open the door, very quietly, and turn the key. The engine dies. She doesn't wake. You put the file on the passenger seat and her coat over her knees and close the door.
autopsy(4): Exhaust leak. Another hour and she'd have been very ill. Or worse.
{do flag:millerSaved=1; xp:15}
@end

# ev.mi3
> The file on her lap: MISSING PERSONS · OKAFOR, D. Under that, a sticky note in her handwriting: *Talk to the pale one. They know. Don't scare them off.*
@end

// =====================================================================
// FRIDAY · the city holding its breath
// =====================================================================
# ev.friday street=5
> Friday night, the streets of the Marrow Ward are empty in a way they've never been. Every shop on the Strip has its shutters down except one. Every window has its curtains drawn except the ones where somebody's standing, watching the street.
> Under the floodlights, a cat crosses the road very slowly, and stops in the middle, and looks at you, and goes on.
tenant: They know. Not what. Just that tonight is the night. Cities always know.
@end
`,'c_street2');
