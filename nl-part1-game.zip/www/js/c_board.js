'use strict';
/* THE NEW LORD — "The Case": sit down somewhere quiet and lay out what you know about Monday morning. Get it right and the Tribunal will hear a story that holds. */
(function(){NL.TASKS.s_case={n:'The Case',xp:60,cat:'side'};})();
NL.Script.add(String.raw`
# cq.0 arc=tenant night=3,4,5 label="Lay out the case. Everything you know about Monday." if=flag:maskedBuyer|flag:knowSevHarrow|flag:knowLantern prio=1
@focus tenant
> You find somewhere quiet. You close your eyes. In the dark behind them, the voices gather round a table that isn't there, like detectives round a desk at four in the morning.
web: Right. From the top. Somebody killed the Sheriff of the Marrow Ward at 4:14 on Monday morning in the walk-in freezer at Kowalski's. We know what. We know when. We don't know the whole of who, or any of why. Let's fix that.
{do task:s_case; note:s_case|Laying out the case in your head. Each thing you work out correctly can be said, with confidence, in the chalk on Friday.}
@next cq.hub

# cq.hub
* The weapon.  -> cq.lance {once} {if flag:maskedBuyer}
* The buyer in the mask.  -> cq.buyer {once} {if flag:maskedBuyer}
* Why Absalom was there at all.  -> cq.why {once} {if seen:cq.buyer}
* The Lady and the federal man.  -> cq.sev {once} {if flag:knowSevHarrow}
* The man with the peppermints.  -> cq.harrow {once} {if flag:knowLantern|seen:hw3.0|flag:hcN2}
* The seven.  -> cq.seven {once} {if flag:knowSeven|task:s_seven}
* The grey pearls.  -> cq.ott {once} {if flag:knowOttilie}
* Why it was you.  -> cq.you {once} {if seen:cq.why}
* Put it all together.  -> cq.theory {if seen:cq.lance&seen:cq.buyer}
* Open your eyes.  -> cq.out

# cq.out
web: We'll pick this up later. The table's not going anywhere. It's not real.
@end

// --- the weapon ---
# cq.lance
autopsy: The ash in the freezer. He was kneeling. Facing the door. Burned from the front, in a line, chest height.
web: Not sunlight from a door. A beam. Narrow. Aimed.
* "A lance. A surgical UV lance. Malakor built it."  -> cq.lanceok
* "A mirror. Someone reflected dawn through the door."  -> cq.lanceno

# cq.lanceok
web: Malakor built it. Sold it on Sunday at eleven, paid in full. Buyer: R. He's a craftsman. He'll say so in the chalk if you ask him nicely, because he can't stand people thinking his work was a mirror.
{do flag:dcLance=1; xp:10:The weapon}
@next cq.hub

# cq.lanceno
autopsy: A mirror at 4:14 in the morning, in October, in a basement. There's no dawn to reflect for another two hours.
web: Try again.
* "A lance. A surgical UV lance. Malakor built it."  -> cq.lanceok

// --- the buyer ---
# cq.buyer
web: A woman in a surgeon's mask. White gloves. Never spoke. Walked into the Butcher's yard on Sunday night with Absalom Vane on one side of her and you on the other.
pulse: Absalom brought her. He brought his own killer to buy the weapon.
* "Rostova. R is Rostova. The doctor."  -> cq.buyerok
* "Séverine, in disguise."  -> cq.buyerno1
* "Ottilie. The accountant."  -> cq.buyerno2 {if flag:knowOttilie}

# cq.buyerok
web: Rostova. A surgeon's mask because she *is* a surgeon. Gloves because she always wears gloves round your kind. Silent because her accent would have given her away.
autopsy: And R. She signed with her own initial, because she's a scientist, and scientists write things down even when they're committing murder.
{do flag:dcBuyer=1; xp:10:The buyer}
@next cq.hub

# cq.buyerno1
pedigree: Séverine doesn't walk into the Switchyard. Ever. And she would never, under any circumstances, stand next to a neonate in public.
@next cq.buyer

# cq.buyerno2
web: Ottilie counts money. She doesn't hold lances. And she was at Elysium all Sunday night; Lisette counted her.
@next cq.buyer

// --- why ---
# cq.why
tenant: (quietly) Ask me. Ask me why I brought her.
* "Why did you bring her to the Butcher, Absalom?"  -> cq.why1

# cq.why1
tenant: Because she told me it was a cure. Not for us. For the sun. A lance, she said, tuned to a frequency that would teach my blood to bear it. One dose. In a controlled room. With the door locked.
tenant: I went to a mortal doctor because I was tired of the dark. I took a child from her study with me because she said she'd need a second subject, a fresh one, to compare. I bought the weapon myself. With my own money. I carried it to the freezer.
web: He walked into his own execution because he wanted to see the sun.
* "That's not murder. That's a trap."  -> cq.whyok
* "Then he did it to himself."  -> cq.whyno

# cq.whyok
web: A trap. Baited with the one thing he wanted. Somebody knew exactly what Absalom Vane wanted, and sold it to him.
{do flag:dcWhy=1; xp:10:The bait}
@next cq.hub

# cq.whyno
tenant: ...Yes. In a way. In every way that matters to the law, no. But in the way that matters to me, yes.
web: The law will want to know who set it. Not who walked in.
@next cq.hub

// --- the Lady ---
# cq.sev
echo: "The doctor did her part. Let Valko do his." In her booth. To the federal man. On Monday night.
web: The doctor did her part. Past tense. Séverine knew about Rostova before the freezer. She knew it would happen. She set the Hound on you to make sure nobody asked who fired.
* "Séverine planned it with Harrow."  -> cq.sevno
* "Séverine didn't plan it. She *let* it. And then covered it."  -> cq.sevok
* "Séverine is innocent. It was a figure of speech."  -> cq.sevno2

# cq.sevno
pedigree: Planned it? The Keeper of Elysium, conspiring with a mortal to kill a Sovereign? She'd burn for that. She's too clever and too frightened.
web: Look again at what she said. "Did her part." She's describing something she watched, not something she built.
@next cq.sev

# cq.sevok
web: She knew. Harrow told her it would happen and she didn't warn him. Absalom was in her way for eighty years. She let the sun take him, and then she tried to make sure the neonate burned for it so nobody would look any further.
web: That's not murder. In the chalk, it's worse. It's a lying Accuser.
{do flag:dcSev=1; xp:20:The Lady's part}
@next cq.hub

# cq.sevno2
web: Nobody says "let Valko do his" as a figure of speech.
@next cq.sev

// --- Harrow ---
# cq.harrow
web: Thomas Harrow. Project LANTERN. Department of Health on the card, something else under it. He funded the study. He wrote the consent form. He was in the freezer doorway at 4:14, apologizing.
* "He ordered it. He's the hand behind the hand."  -> cq.harrowok
* "He was only there to watch."  -> cq.harrowno

# cq.harrowok
web: He ordered it. He didn't fire, because management doesn't fire. He coordinated. Rostova's lance, Malakor's craft, Séverine's silence, Ottilie's notes. He built a machine out of other people's weaknesses and pressed one button.
{do flag:dcHarrow=1; xp:10:The hand}
@next cq.hub

# cq.harrowno
nostalgia: Watch. He said sorry. You remember. People who are only watching don't say sorry.
@next cq.harrow

// --- the seven ---
# cq.seven
web: Seven volunteers. A free-clinic register. Four hundred a session. Seven missing persons reports that went nowhere.
autopsy: Warm after death. Two hours. {if flag:sevenWarm}
* "They were the first trial. Vane's blood, from a donation. They died making him a daywalker."  -> cq.sevenok
* "They were victims of a Kindred. Freddie, or someone like him."  -> cq.sevenno

# cq.sevenok
web: Vane's blood. A donation he made in good faith in August. Seven mortals in Cohort A given a stolen piece of a Sovereign and put in the light; none of them came home. Then Cohort B, at a lower dose. Dani Okafor stood in it for twenty-two minutes. Then they needed more blood, and a fresher subject. Then they needed all of him.
tenant: ...August. I gave her a pint in August. For her research. I signed the form. I thought it was a cure for leukaemia.
{do flag:dcSeven=1; xp:20:The seven}
@next cq.hub

# cq.sevenno
web: A Kindred doesn't keep a register. A Kindred doesn't pay four hundred dollars. This was an institution.
@next cq.seven

// --- Ottilie ---
# cq.ott
web: Lady Ottilie Brand. The Court's accountant. Grey pearls. Reporting to Harrow since 2016.
* "She's how Harrow knew when Absalom would go to Malakor's."  -> cq.ottok
* "She's the one who set the trap."  -> cq.ottno

# cq.ottok
web: Of course. She does the Court's calendar. She knew Vane's Sunday. She knew the Switchyard rota. She sold Harrow a timetable, and Harrow built a murder round it.
{do flag:dcOtt=1; xp:10:The calendar}
@next cq.hub

# cq.ottno
web: Ottilie doesn't set traps. Ottilie sells information to people who do. It's a very important difference to Ottilie.
@next cq.ott

// --- you ---
# cq.you
web: And you. Why you? Of everyone on that ward, why were you the one she took to the freezer?
* "Because I was the healthiest. The best subject."  -> cq.you1
* "Because nobody would miss me."  -> cq.you2
* "Because I'd been there longest and I trusted her."  -> cq.you3

# cq.you1
autopsy: The fittest of the twelve. Nineteen months clean. A good heart. A fresh body to compare with an old one. She chose you like you'd choose a good apple.
@next cq.youend

# cq.you2
pulse: Somebody would. Somebody rang the police nine times. Rostova didn't know that. Harrow did.
@next cq.youend

# cq.you3
nostalgia: She was kind to you. She brought toast. She asked about the book. You'd have followed her anywhere. You did.
@next cq.youend

# cq.youend
tenant: And then she put you in a freezer with me, and pointed a lance at both of us, and you did the one thing nobody in the plan had imagined. You saved me.
tenant: That's the part they can't account for, child. That's the part that'll break their story. You.
{do flag:dcYou=1}
@next cq.hub

// --- the theory ---
# cq.theory
> The table in your head. The voices round it, quiet now. Waiting for you to say it.
@gate flag:dcLance&flag:dcBuyer&flag:dcWhy&flag:dcHarrow ? cq.full : cq.part

# cq.part
web: Not yet. There are holes. The story's got a weapon and a hand that held it, but not the reason, or the man who paid. Keep looking.
@next cq.hub

# cq.full
web: Say it. All of it. Out loud, to yourself, so you'll be able to say it in the chalk.
> You say it.
> *A federal program called LANTERN wanted a daywalker. They took a pint of Absalom Vane's blood in August under a false form and killed seven mortals with it. When that wasn't enough, they used a doctor who wanted a cure, a Butcher who wanted gold,*
> *an accountant who sold the Sheriff's calendar,* {if flag:dcOtt}
> *and a Keeper who let it happen because she wanted him gone,* {if flag:dcSev}
> *to bait a trap with the one thing Absalom Vane wanted more than his life: to see the sun. He walked into it himself, with a lance he'd paid for, and a subject from the study at his side. At 4:14 on Monday morning, Dr. Elena Rostova fired. Thomas Harrow watched from the doorway and said sorry.*
> *And the subject, who was supposed to be a control, drank the Sheriff to keep him out of the light.*
> *That's what happened. I didn't steal him. I'm the only one in that freezer who tried to save him.*
tenant: ...Yes. Yes. That's it. That's the whole of it. Say it like that on Friday and Ambrose will hear every word.
{do flag:dcTheory=1; task:s_case=done; xp:60:The Case; comp+2}
@end
`,'c_board');

(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);const f=S.flags;
  if(f.dcTheory)M.push({t:'Step into the center of the chalk. Tell them the whole thing, from August to 4:14, the way you laid it out in your head.',once:'tb_theory',ok:st=>{let p=3;if(f.dcSev)p+=1;if(f.dcOtt)p+=1;if(f.dcSeven)p+=1;st.prog+=p;st.threat=Math.max(0,st.threat-1);return [T('It takes eleven minutes. Nobody interrupts. Not Séverine. Not the Syndicate. Not the Court, three hundred of them on the tracks, very still, listening to a five-day-old Kindred tell them how the oldest of them was killed by wanting something.'),L('magistrate','...That is the first account I have heard this week that holds together from one end to the other.'),L('magistrate','It does not make you innocent. It makes you a witness.')];}});
  return M;};})();
