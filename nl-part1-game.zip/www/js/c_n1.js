'use strict';
/* THE NEW LORD — Night One personal arcs: first impressions of Tariq, Tiny, Gideon, Séverine, Rostova and Pemberton */
NL.Script.add(String.raw`
// =====================================================================
// TARIQ · Night One
// =====================================================================
# tx1.0 arc=tariq night=1 label="\"What's this street like, really?\"" if=room:luckymart&flag:tariqMet
@focus tariq
tariq: This street? The Abattoir Strip. Officially Ferrier Lane and the four blocks around it. Unofficially, the place where the city keeps everything it doesn't want to look at.
tariq: Two butchers, one of which is now closed because of a murder. A launderette that's open twenty-four hours and never has any clothes in it. A church that's a nightclub. A pawnshop that sells coffins. Me.
gutter(3): He's giving you the tour. People only give tours to people they think are staying.
* "And who keeps the peace?"  -> tx1.peace
* "What's the church-nightclub?"  -> tx1.club
* "Why do you stay?"  -> tx1.stay

# tx1.peace
tariq: Peace? Ha. There's a tall man in a good coat who walks the street at three in the morning. Everyone gives him room. When he walks past, the fights stop. When he doesn't walk past, the fights don't stop.
tariq: He hasn't walked past in two nights. Not last night. Not tonight.
> He looks at your coat. He looks at it for a long time. Then he looks away.
tenant: He knows. He doesn't know he knows. That's the best kind of knowing in this city.
{do mem:tariq:coat}
@next tx1.hub

# tx1.club
tariq: The Reliquary. Saint Agatha's, before. They sold the church in 1998 and a woman in a red dress bought it. Now it's a club with a door that a very big man stands at, and a downstairs that nobody who goes down talks about when they come up.
tariq: The girls who dance there come in here at one for energy drinks. They have little marks on their arms. They laugh about it. The laughing is the bad part.
@next tx1.hub

# tx1.stay
tariq: Stay? It's my shop. A quarter of it. My father's three-quarters is my mother's now and she thinks the shop is a curse. She's right. But it's my curse.
tariq: And I like the night. In the day, everybody's pretending. At night they come in here and buy cat food for cats they don't have and tell me the truth.
{do mem:tariq:night}
@next tx1.hub

# tx1.hub
* "What do I owe you for the chat?"  -> tx1.owe {once}
* "Goodnight, Tariq."  -> tx1.bye

# tx1.owe
tariq: Owe? Nothing. A chat is free. Coffee is two dollars. Cigarettes are illegal to sell to someone who looks like they're about to cry, which you do, so: nothing.
@next tx1.hub

# tx1.bye
tariq: Come back. People who look like that always come back.
@end

// =====================================================================
// TINY · Night One · first look
// =====================================================================
# kx1.0 arc=tiny night=1 label="\"How long have you worked the door?\"" if=room:reliquary
@focus tiny
tiny: Nine years. Since the place opened under this name. Before that I worked the door at a strip club on the Heights. Before that I was a forward for Port Vellum Rovers for a season and a half until my knee went.
tiny: The door's better. Nobody kicks you in the knee on a door. They try other things.
pulse(4): His color's wrong. Grey under the brown. He's tired in a way that sleep doesn't fix.
* "You look unwell."  -> kx1.unwell
* "What's downstairs?"  -> kx1.down
* "Who decides who goes down?"  -> kx1.decides

# kx1.unwell
tiny: I'm six foot six. I always look unwell. Shirts don't fit right.
tiny: Mind your own business, new face. It's the first rule of my door. The second rule is the stairs. The third rule is there's no third rule, I just like saying it.
{do mem:tiny:unwell}
@end

# kx1.down
tiny: Elysium. That's what they call it. It means "nobody kills anybody down there". It's a rule. They're very big on rules downstairs. It's the only place in the city where they're big on rules.
tiny: Up here, I'm the rules. Down there, she is.
@end

# kx1.decides
tiny: Lists. The Lady's list. My list. And sometimes, a face comes up those stairs that I've never seen and I just know: no. I don't know how I know. I just do. Nine years, I've never been wrong.
tiny: You're not on my no list. Yet. You're not on my yes list either. You're on "watch".
@end

// =====================================================================
// GIDEON · Night One · first look
// =====================================================================
# gx1.0 arc=gideon night=1 label="Look around the shop while he works." if=room:pawn&flag:gideonMet
@focus gideon
> Pocket watches in glass cases, all stopped at different times. A stuffed fox wearing a monocle. Wedding rings in a bowl, priced by weight. At the back, through a bead curtain, rows of coffins on trestles, polished, numbered, with velvet linings in seven colors.
gideon: Browsing. Good. Browsing's free. Touching's a dollar. Breaking's whatever I say it is.
gideon: The fox is called Wellington. He's not for sale. He was my father's. My father wasn't for sale either.
* "Why do the watches all show different times?"  -> gx1.watches
* "Who buys wedding rings by weight?"  -> gx1.rings
* "The coffins. Who sleeps in them?"  -> gx1.coffins

# gx1.watches
gideon: Because they're all stopped at the moment their owners pawned them and never came back. Each one's a little grave. I keep them wound once a week so they don't seize. But I set them back to their own times after.
gideon: Seems right. It's their time, not mine.
nostalgia(4): A shop full of moments that stopped. You know how that feels. You're one of them.
@end

# gx1.rings
gideon: Widows, mostly. Divorcees. One man brought in eleven. He wouldn't say. I didn't ask.
gideon: Gold's gold. Love's not a metal. I can't weigh that part, so I don't charge for it.
@end

# gx1.coffins
gideon: Tonight? Four of your sort, one Wraith, and a gentleman from the Court who says he's "between residences" and has been between them since 1997.
gideon: Thirty a night. Lid sticks on three. Velvet's cleaned weekly. Sunrise guaranteed. That's all you need to know, and more than most of them ask.
@end

// =====================================================================
// SÉVERINE · Night One · after the Keeper's encounter
// =====================================================================
# sx1.0 arc=severine night=1 label="\"A question, my lady, before I go.\"" if=room:vip&flag:keeperDone&alive:sev&!flag:sevGoneN1
@focus severine
severine: One question. I'm in a generous mood. I've just watched a neonate survive me, which happens perhaps once a decade. Ask.
* "What was he like? The Sheriff."  -> sx1.vane
* "What do you call what I did?"  -> sx1.did
* "Why let me live?"  -> sx1.live

# sx1.vane
severine: Absalom? Punctual. Tidy. Greedy. Funny, once a decade, at the worst possible moment. He had beautiful handwriting and terrible taste in hats.
severine: He kept the peace in the Marrow Ward the way a man keeps bees: carefully, with smoke, and expecting to be stung.
tenant: Terrible taste in *hats*. I'll have you know my hats were the envy of three Princes.
{do mem:severine:hats}
@end

# sx1.did
severine: Diablerie. The Amaranth. Drinking the soul. The oldest crime there is. The Magistrate will call it murder of the blood. The old ones call it *eating up*.
severine: In my day we said it the French way: *la petite mort de l'autre*. The other's little death. It's prettier. It doesn't help.
@end

# sx1.live
severine: Because you'd be more useful alive for a week than dead tonight. Because the Magistrate will want someone to blame on Friday and I'd like it to be someone I've met. And because you said *thank you* to Tiny on the way down, and nobody has thanked Tiny on those stairs since 2016.
pedigree(5): She notices everything. Everything is a ledger to her.
{do mem:severine:thankedtiny}
@end

// =====================================================================
// DR. ROSTOVA · Night One
// =====================================================================
# rx1.0 arc=rostova night=1 label="\"You don't seem surprised to see me.\"" if=room:stjude&flag:metRostova
@focus rostova
rostova: Surprised? You walked into a night clinic at midnight looking like you'd been through a cremation. I'm surprised at nothing. I've had a man come in with a fork in his eye who wanted a sandwich.
rostova: What do you want? Expired O-negative is forty a bag. Gauze is free. Advice costs more than you've got.
pulse(5): Her hands are shaking. Very slightly. She's had too much coffee, or not enough sleep, or she's afraid of you specifically.
* "Advice. What do I need to know about the blood?"  -> rx1.advice
* "Have we met before?"  -> rx1.met
* "Why do you sell to us?"  -> rx1.sell

# rx1.advice
rostova: Don't drink from anyone who's been drinking. Don't drink from anyone sick. The O-negative in my fridge is expired, which means it's safe for you and useless for anyone else. Don't let anybody tell you that you need to kill. You don't. You never do. Some of you just like it.
rostova: And stay off the roof at dawn. Somebody always tries the roof.
{do mem:rostova:advice}
@end

# rx1.met
> The pen stops. Then it starts again.
rostova: I see a lot of faces. Most of them are bleeding.
nostalgia(5): A white coat. A clipboard. "This'll sting." The same voice. You're sure. You're not sure.
{do mem:rostova:met; flag:rostovaFamiliar=1}
@end

# rx1.sell
rostova: Because if I don't, you hunt. And the people you hunt end up here, on my table, with holes in them. Forty dollars a bag is cheaper than a funeral.
rostova: Also the clinic needs a new X-ray machine. The city won't pay. You will.
@end

// =====================================================================
// PEMBERTON · Night One · the first drive
// =====================================================================
# px1.0 arc=pemberton night=1 label="\"Who are you, exactly?\"" if=flag:mapOK&!flag:pemDead
@focus pemberton
pemberton: Pemberton, ‹sir›. Driver. Valet. Keeper of the calendar. The Sheriff's ghoul, in your parlance. The help, in everyone else's.
pemberton: I've been told to take you wherever you'd like to go tonight, and to keep you alive until dawn, and to be discreet about both. I'm told this by an envelope. The envelope was very clear.
* "Who wrote the envelope?"  -> px1.envelope
* "Are you safe? With me?"  -> px1.safe
* "Do you know what I did?"  -> px1.did

# px1.envelope
pemberton: The Sheriff, ‹sir›. On Sunday. "If I'm late on Monday, look after whoever's wearing the coat." I said, ‹sir›, the coat doesn't leave your back. He said: "Pemberton, everything leaves everyone's back eventually."
pemberton: He was in a mood on Sunday. I put it down to the weather.
{do mem:pemberton:envelope}
@end

# px1.safe
pemberton: Safe? I've been driving a vampire for forty-one years, ‹sir›. Safety left the vehicle in 1983.
pemberton: You're not going to bite me. You've had several opportunities. You keep looking at my neck and then looking out of the window. I find it touching.
@end

# px1.did
> He looks at you in the rear-view mirror, where you aren't.
pemberton: I know what's in the freezer, ‹sir›. And what isn't. And whose coat you're wearing.
pemberton: I'd rather not talk about it until I've decided how I feel. I'm told it takes me some time. My second wife said I took nine years to decide I liked her. I did, in the end.
{do mem:pemberton:knows}
@end
`,'c_n1');
