'use strict';
/* THE NEW LORD — side quests, set four: "The Jars" (voices of the dead in Soot's shrine), "The Thirteenth Face" (a commission at Malakor's: somebody wants to wear the Sheriff) */
(function(){
Object.assign(NL.TASKS,{s_jars:{n:'The Jars',xp:60,cat:'side'},s_face13:{n:'The Thirteenth Face',xp:80,cat:'side'}});
Object.assign(NL.ITEMS,{
  rayjar:{n:'A Jar Marked "R.D. 12/3/19"',type:'read',d:'A jam jar with a cork and a scrap of paper inside. Hold it to your ear and you can hear, very faintly, a man\'s voice on a phone by a river.'},
  facemould:{n:'A Plaster Face-Mould',type:'tool',d:'A death mask in white plaster: a long grave handsome face, older than its lines. Absalom Vane, taken by somebody on Monday morning before the ash was cold.'}
});
})();
NL.Script.add(String.raw`
// =====================================================================
// THE JARS · voices of the dead
// =====================================================================
# jr.0 arc=soot night=3,4,5 label="\"Mother. Let me listen to the jars.\"" if=room:shrine&flag:metSoot&mem:soot.namejar|room:shrine&flag:metSoot&mem:soot.told prio=1
@focus soot
soot: Listen. Listen, listen. Everybody wants to talk. Nobody wants to listen. You want to listen. Mm. That's why I like you, greedy.
> She takes down jars from the high shelves one at a time and sets them on the floor in a circle around you, like candles. Each one has a scrap of paper inside with a date.
soot: Every voice the pipes ever carried that mattered. A word, a breath. I keep them for when there's nobody left to remember.
{do task:s_jars; note:s_jars|Mother Soot keeps the voices of the dead in jars. Some of them might matter to the living.}
@next jr.hub

# jr.hub
* The jar marked "A.V. 31/10".  -> jr.vane {once}
* The jar marked "R.D. 12/3/19".  -> jr.ray {once} {if task:s_cold|met:miller}
* The jar marked "D.O. 28/8".  -> jr.dani {once} {if flag:met404}
* The jar marked "M.M. 2011".  -> jr.mateo {once} {if task:s_mateo|flag:knowMateo}
* The jar marked "RASK 77".  -> jr.rask {once} {if flag:valkoAlly|done:s_rask}
* The jar marked "A. 1961".  -> jr.agnes {once} {if mem:tenant.agnesstory|flag:haveAgnesLetters|flag:knowAgnesGrave}
* Put the jars back.  -> jr.end

# jr.vane
> You hold it to your ear. Crackle. Rain on a car roof. And his voice, alive, the night before:
> *"...Pemberton, if anything happens tomorrow, the letter's in your coat. Don't argue. Yes, I know you've never lost a letter. That's why it's in your coat."*
> And then, quieter, as if to himself: *"Agnes would know what to do. Agnes always knew what to do."*
tenant: ...Sunday. Sunday night. In the car. I didn't know anyone was listening.
soot: Somebody's always listening, Sheriff. Mm. That was always your mistake.
{do sync+2:Sunday night}
@next jr.hub

# jr.ray
> A man's voice, Irish-flat, out of breath, standing somewhere with water nearby:
> *"Ines, it's me. I'm at the river, by the old pumphouse. I've found it. The shipping thing. Kowalski's and the doctor and a fella in sunglasses with a federal ID. It's weird. It's a weird one. I'll tell you tomorrow. Bring the good cookies."*
> Then a car door. Footsteps on gravel. A second voice, pleasant, reasonable: *"Detective Dunleavy? Could I have a word?"*
> Then the river.
web(6): The second voice. You've heard it. Pleasant, reasonable, faintly apologetic. Harrow.
soot: The pipes run under the pumphouse. Mm. I heard it go into the water. I kept it. I didn't know who to give it to. Nobody asks Soot for the police.
* "Can I take it? For Miller?"  -> jr.raytake
* "Not yet. Keep it safe."  -> jr.raykeep

# jr.raytake
soot: Take it. For the detective. She's the only one who'd want it. Mm. Mm. It's the last thing he ever said. Be careful with it.
{do give:rayjar; flag:haveRayJar=1; mem:soot:rayjar}
@next jr.hub

# jr.raykeep
soot: Safe. It's always safe here. Nothing ever leaves the jars unless somebody asks.
@next jr.hub

# jr.dani
> A girl's voice, laughing, on a phone in a hospital corridor at four in the morning:
> *"Mom, I'm fine. I'm FINE. They give us toast. The doctor's intense but she's okay. There's someone here who reads Russian books and lends them out. I'm reading one now, it's so sad. No, I won't tell you the ending. I don't know the ending. Love you. Feed the fish."*
nostalgia(4): *Dani says DON'T tell me the ending.* Pencil, on the inside cover of *The Idiot*.
soot: The fish died in October. Mm. Mrs. Okafor forgot to feed it. She cried more about the fish than anything else. That's how grief goes.
* "Mrs. Okafor should hear this."  -> jr.danitake
* Put it back on the shelf.  -> jr.hub

# jr.danitake
soot: Then take it to her. Mm. One jar. Just one. I'll miss it. I liked her laugh.
{do flag:haveDaniJar=1; mem:soot:danijar}
@next jr.hub

# jr.mateo
> A boy's voice, nineteen, at a kiosk counter, in 2011:
> *"Twenty Marlboro Lights and a Twix. Cheers. ...Yeah, my sister's a cop, she'd kill me. Don't tell her."*
> Footsteps. Rain. A girl's voice in an alley, starving, crying: *"I'm sorry. I'm sorry. I'm so sorry."*
soot: Rina. Mm. She was so sorry. She was always sorry. Even when she walked into the sun, she said sorry to the sun.
@next jr.hub

# jr.rask
> A huge laugh, a bark of it, in a container yard in 1977. And then, very quietly, a man's voice that sounds like Valko's but deeper:
> *"Why does nobody ask, Mister? Seventy years. Why does nobody ever ask what's wrong."*
> Then a long howl, and the sea.
tenant: He said that. To me. On the pier. Before I... before. I'd forgotten. I'd made myself forget.
@gate flag:valkoAlly ? jr.raskv : jr.hub

# jr.raskv
* "Valko should hear this."  -> jr.raskvalko
* "Valko never needs to hear this."  -> jr.hub

# jr.raskvalko
soot: The dog. The grey dog. Mm. Take it, then. He'll cry. Hounds cry like children. It's good for them.
{do flag:haveRaskJar=1}
@next jr.hub

# jr.agnes
> An old woman's voice, faint, in a nursing home on the Heights in December 1961, to someone sitting by her bed:
> *"Albert, love. If a tall man in dark glasses comes to the funeral and stands at the back, don't send him away. He's an old friend. He has a condition. Sunlight. Tell him... tell him it didn't hurt. Tell him I said: it's only warm."*
> A long silence in your blood. Longer than any silence there has been all week.
tenant: ...He didn't tell me. Albert. He didn't tell me. I stood at the back in the snow and he walked past me with his hat in his hands and he didn't...
tenant: No. He couldn't have known it was me. I was at the gate. I never went in.
{do sync+6:It's only warm; comp+2; mem:tenant:agnesjar; flag:heardAgnesJar=1}
@next jr.hub

# jr.end
soot: Back on the shelf. Back in the dark. Mm. They're all very patient. They've got nowhere else to be.
{do task:s_jars=done; xp:60:The Jars}
@end

// Miller and Ray's jar
# ixR.0 arc=miller night=3,4,5 label="\"Ines. I have something of Ray's.\"" if=has:rayjar prio=7
@focus miller
> You give her the jar. She looks at it. A jam jar with a cork.
miller: What is this? Is this a joke?
* Tell her to hold it to her ear.  -> ixR.listen

# ixR.listen
> She holds it to her ear, feeling stupid, looking at you like she's going to arrest you for wasting police time. Then her face changes.
> You watch her hear Ray. *Bring the good cookies.* You watch her hear the car door, and the gravel, and the pleasant reasonable voice, and the river.
> She doesn't drop it. She holds it in both hands against her chest like Margo holding her handbag on Platform 0.
miller: That's Harrow. That's Harrow's voice. That's... he was there. He was there when Ray went in the river.
miller: Five years. Five years I've been told it was a mugging. A drunk. An accident. He was THERE.
{do take:rayjar; flag:millerRayJar=1; task:s_cold=done; rel:miller+3; lean:candour+1; xp:60:Ray Dunleavy}
miller: Where did you... no. Don't tell me. I don't care. I don't care where it came from. Thank you. Thank you.
@end

// Mrs. Okafor and Dani's voice
# oxJ.0 arc=okafor night=3,4,5 label="\"There's something you should hear.\"" if=room:apt&flag:haveDaniJar prio=8
@focus okafor
> She holds the jar to her ear for a long time. She doesn't cry. She listens to it four times. On the fourth time she laughs at "feed the fish", out loud, the way Dani would have.
okafor: The fish. The bloody fish. She was always on at me about the fish.
okafor: I'm going to keep this by my bed. Is that all right? I'm going to listen to it every night. Like a radio.
{do flag:haveDaniJar=0; flag:okaforJar=1; rel:okafor+2; comp+2:Feed the fish}
@end

// Valko and Rask's voice
# vxR.0 arc=valko night=3,4,5 label="\"Valko. This is Rask.\"" if=flag:haveRaskJar&flag:valkoAlly prio=8
@focus valko
> He holds the jar to his ear with both enormous hands. You watch him hear the laugh first. You watch his whole face open like a door.
> Then you watch him hear the question. *Why does nobody ever ask what's wrong.*
> He puts the jar down on the cobbles very carefully. He crouches over it. He doesn't make a sound for a long time.
valko: I didn't ask. I sat in the car with my hands over my ears.
* "You can ask now. Ask me."  -> vxR.ask {do lean:mercy+1}
* Sit with him.  -> vxR.sit

# vxR.ask
valko: Ask you. What's wrong.
> He looks up at you. Amber eyes, very wet.
valko: ...What's wrong? Is anything wrong? Are you all right?
> Nobody has asked you that all week. Not once. It's a Hound who finally does.
{do flag:haveRaskJar=0; rel:valko+3; comp+3:Somebody asked; mem:valko:asked}
@end

# vxR.sit
> You sit on the wet cobbles beside him at the end of Ferrier Lane. He holds the jar in his lap like a pup. After an hour he says "thank you" very quietly and puts it inside his coat.
{do flag:haveRaskJar=0; rel:valko+2; tick:30}
@end

// =====================================================================
// THE THIRTEENTH FACE · a commission at Malakor's
// =====================================================================
# fc.0 arc=malakor night=3,4 label="\"Who's the face on the bench, Malakor?\"" if=room:switchyard&alive:malakor prio=0
@focus malakor
> On Malakor's workbench, under a cloth, something face-shaped. He sees you looking and doesn't cover it.
malakor: Ah. You noticed. Of course you noticed. Candour, then.
> He takes the cloth off. A plaster cast of a face. A long, grave, handsome face, older than its lines.
tenant: ...That's me.
malakor: A death mask. Taken on Monday morning, from what was left in the freezer, before the ash was cold. Somebody brought it to me on Tuesday with a commission and a great deal of gold.
malakor: They want me to make them a face from it. *His* face. Perfect. To wear on Friday.
{do task:s_face13; note:s_face13|Someone brought Malakor a death mask of Absalom Vane taken in the freezer on Monday, and paid him to make a face from it, to wear at the Tribunal on Friday.}
* "Who?"  -> fc.who
* "Why would anyone want to wear him?"  -> fc.why
* "Are you going to do it?"  -> fc.do

# fc.who
malakor: Ah. That I can't tell you. Butcher's confidence. It's the only thing in my shop I don't sell.
? velvet 11 "You've told me the truth all week, Malakor. Don't stop on the most important one."  -> fc.whotell | fc.whono {id fc_vel} {mod like:malakor}
* Offer to buy the name.  -> fc.whobuy {if cash>=200}

# fc.whotell
> He looks at the mask for a long time.
malakor: ...Lady Ottilie Brand. The Court's accountant. Grey pearls. She wants to stand up at the Tribunal as Absalom, in Absalom's face, and say whatever her masters need him to say. "The neonate murdered me." Who could argue with the victim?
web(6): LANTERN's informant in the Court, wearing the dead Sheriff's face, testifying against you. Harrow's doing. A forgery with a pulse.
{do flag:faceOttilie=1; flag:knowOttilie=1; mem:malakor:ottilie}
@next fc.choice

# fc.whono
malakor: No. Some things a Butcher keeps. Even from you.
@next fc.choice

# fc.whobuy
malakor: Two hundred. For the name. That's a very cheap name. I'll take it because I don't like her.
> You pay.
malakor: Lady Ottilie Brand. The Court's accountant. Grey pearls. She wants to stand up at the Tribunal as Absalom and say the neonate murdered him.
{do cash-200; flag:faceOttilie=1; flag:knowOttilie=1}
@next fc.choice

# fc.why
malakor: Because the dead are excellent witnesses. Nobody argues with a ghost. If Absalom himself stands up in the chalk circle and says "this child murdered me", you burn at dawn and nobody asks a single question.
malakor: Except, of course, Absalom isn't dead. He's in you. Which makes it a very interesting commission.
@next fc.who

# fc.do
malakor: I've taken the gold. I've started the work. It's the finest piece I've ever been asked for. A Sheriff's face. Can you imagine?
malakor: But I haven't finished. A face isn't finished until the last stitch. I could... slip. I could make it almost right. Wrong in one place only somebody who'd been inside him would notice.
@next fc.choice

# fc.choice
* "Finish it wrong. Make it a tell."  -> fc.wrong {do lean:candour-1}
* "Don't finish it at all. Give her the gold back."  -> fc.refuse
* "Give me the mask."  -> fc.take
* "Finish it. Perfectly. I want to see her try."  -> fc.perfect {do lean:pride+1}

# fc.wrong
malakor: A tell. Yes. The left eyebrow. Absalom had a scar through it from a duel in 1790. Nobody alive remembers which side. I'll put it on the right.
malakor: She'll stand up on Friday in a perfect face with one tiny lie in it. And you'll know.
{do flag:face13=wrong; task:s_face13=done; xp:80:The Thirteenth Face; rel:malakor+1}
tenant: The left. It was always the left. Corsica, 1790. He was a terrible swordsman. I'd forgotten I ever had a scar.
@end

# fc.refuse
malakor: Give the gold back. A Butcher, refunding. My reputation.
malakor: ...For you. Fine. I'll tell her I dropped it. She'll find someone else, of course. Someone worse. There's always someone worse.
{do flag:face13=refused; task:s_face13=done; xp:50:The Thirteenth Face; rel:malakor+1}
@end

# fc.take
malakor: The mask. The original. Without it, nobody can make the face. Not me, not anyone.
malakor: It costs the gold I've taken. I'll have to pay her back from my own pocket. You'll owe me.
* "I'll owe you."  -> fc.takeok {do promise:malakorface:Repay Malakor for the Sheriff's death mask}

# fc.takeok
> He wraps the plaster face in the cloth and hands it to you. It's heavy. It's warm, somehow.
tenant: Don't look at it. Please. Put it somewhere I can't see.
{do give:facemould; flag:face13=taken; task:s_face13=done; xp:80:The Thirteenth Face; rel:malakor+1}
@end

# fc.perfect
malakor: Perfect. You want her to stand up in a perfect Absalom and *lie*. In front of you. With him in your blood.
malakor: ...You're terrifying. I approve. I'll do my very best work.
{do flag:face13=perfect; task:s_face13=done; xp:60:The Thirteenth Face}
@end
`,'c_sq4');

/* the false Sheriff stands up at the Tribunal, unless the face was refused or taken */
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;
const rd=ENC.tribunal.round;
ENC.tribunal.round=function(st,S,G){const r=rd.call(this,st,S,G);
  if(st.round===1&&S.flags.faceOttilie&&(S.flags.face13==='wrong'||S.flags.face13==='perfect')&&!S.flags.ottilieExposed&&!S.flags.falseVaneDone){S.flags.falseVaneDone=1;
    const extra=[T('Then, from the front row, a figure in a long coat stands up. Tall. Grave. A long handsome face, older than its lines. Three hundred Kindred gasp at once.'),
      L('magistrate','...Absalom?'),
      T('"Ambrose," it says, in a voice that is nearly right. "The child murdered me. In the freezer. I saw its face."'),
      L('tenant','That is NOT me. That is not my VOICE. Child, look at the eyebrow. LOOK AT IT.')];
    return {lines:extra.concat(r?r.lines||[]:[]),threat:(r&&r.threat||0)+2,prog:r&&r.prog||0};}
  return r;};
const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
  if(S.flags.falseVaneDone&&!S.flags.falseVaneUnmasked){
    if(S.flags.face13==='wrong')M.push({t:'"Magistrate. His scar. Corsica, 1790. It was through the LEFT eyebrow."',once:'tb_scar',ok:(st,S)=>{st.prog+=4;st.threat=Math.max(0,st.threat-2);S.flags.falseVaneUnmasked=1;S.flags.ottilieExposed=1;return [T('The Magistrate looks. Everyone looks. The scar is on the right.'),L('magistrate','...Absalom fought Count Orsini at dusk in 1790 and was cut through the *left* brow. I was his second. I held the handkerchief.'),T('The false Sheriff turns to run. Two Court ghouls are already there. Under the face, when it comes off, is a woman in grey pearls, screaming.')];}});
    else M.push(C_('web',12,'"That\'s a Butcher\'s face. Malakor\'s work. Ask him who paid."',S));
  }
  if(G.has('facemould'))M.push({t:'Unwrap the plaster death mask. "Someone took this from the freezer on Monday, to make a forgery of him."',once:'tb_mask',ok:st=>{st.prog+=1;return [L('magistrate','A death mask. Of a Sheriff. Taken before the ash was cold. Who would dare.'),L('malakor','Someone with a great deal of gold and no taste, Magistrate.',{if:S=>!S.flags.malakorDead})];}});
  return M;};
function C_(sk,dc,t,S){return {t,ck:{sk,dc,id:'tb_fake',mod:S=>(S.flags.malakorDead?0:2)+(S.flags.side_syndicate?2:0)},once:'tb_fake',ok:(st,S)=>{st.prog+=3;st.threat=Math.max(0,st.threat-1);S.flags.falseVaneUnmasked=1;S.flags.ottilieExposed=1;return [L('malakor','...Yes. My work. Paid for by Lady Ottilie Brand. I am a craftsman, not a liar. Take it off her.',{if:S=>!S.flags.malakorDead}),T('Under the face: grey pearls, and a woman screaming.')];},no:st=>{st.threat+=2;return [L('magistrate','The victim stands before me and accuses you. Your theories about butchers do not move me.')];}};}
})();
