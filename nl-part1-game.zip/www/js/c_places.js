'use strict';
/* THE NEW LORD — new places, each a scene: the Ever-Open Launderette, Pier Nine, the bell tower of St. Agatha's, and the gate of the Prince's house on the Heights */
(function(){
const S_=NL.Script;
Object.assign(NL.TASKS,{s_shroud:{n:'Seven Shrouds',xp:60,cat:'side'},s_rask:{n:'Pier Nine',xp:60,cat:'side'},s_bell:{n:'The Bell of St. Agatha',xp:50,cat:'side'},s_heights:{n:'The House With No Windows',xp:50,cat:'side'}});
Object.assign(NL.ITEMS,{
  shroud:{n:'A Folded Shroud',type:'read',d:'Hospital linen, laundered seven times, folded into a square. A laundry tag: ST. JUDE\'S · B1 · 6. Somebody has sewn a little blue door in the corner in cotton thread.'},
  raskcollar:{n:'Rask\'s Tag',type:'tool',d:'A brass dog-tag on a broken chain. RASK · PROPERTY OF THE MARROW WARD · 1951. Valko\'s twin, in another life.'},
  bellrope:{n:'A Length of Bell-Rope',type:'tool',d:'Old hemp, frayed at one end, from the tower of St. Agatha\'s. It still hums when you hold it near your ear.'},
  magcard:{n:'The Magistrate\'s Card',type:'read',d:'Thick cream card, black-edged. One word in a very old hand: "Speak." On the back: "— Q."'}
});
S_.place({id:'laundry',name:'The Ever-Open Launderette',block:'A',sub:'Halloran Street. Twenty-four hours. Never any clothes in it.',if:'night>=2&night<=5&flag:mapOK',node:'ln.0',min:8});
S_.place({id:'pier9',name:'Pier Nine',block:'D',sub:'The container docks. Cranes like herons. Somewhere Valko won\'t go alone.',if:'night>=3&night<=4&flag:mapOK&!flag:pierDone',node:'p9.0',min:20});
S_.place({id:'belltower',name:'The Bell Tower of St. Agatha\'s',block:'B',sub:'Above Club Reliquary. The door is never locked.',if:'night>=2&night<=5&flag:mapOK&!flag:bellDone',node:'bt.0',min:10});
S_.place({id:'heights',name:'The Heights',block:'C',sub:'The Prince\'s house. It has no windows.',if:'night>=4&night<=5&flag:mapOK&!flag:heightsDone',node:'hg.0',min:28});
})();
NL.Script.add(String.raw`
// =====================================================================
// THE EVER-OPEN LAUNDERETTE · Seven Shrouds
// =====================================================================
# ln.0
> Halloran Street. A launderette with twelve machines and twelve plastic chairs and a strip light that buzzes like a trapped wasp. The sign says EVER-OPEN. It has been, since 1958. There are never any clothes in it. Tonight, machine seven is turning, slowly, with something white inside.
> A woman in a headscarf and a grey housecoat is folding a sheet on the counter. She's very thin. When she turns, her face is a Wraith's face: grey, tight, the skull showing through like a photograph left in the sun.
@gate seen:ln.0b ? ln.again : ln.0b

# ln.0b
sallow: Don't stand in the door, love, you'll let the steam out. Sit. Machine four's got a broken door, don't sit by machine four, it eats sleeves.
sallow: Mrs. Sallow. I run the Ever-Open. I've run it since it opened. Before that I was a washerwoman at the Infirmary. Before that I don't remember. You get so you don't.
{do flag:metSallow=1}
* "What are you washing?"  -> ln.what
* "There are never any clothes in here."  -> ln.clothes
* "Are you one of Soot's?"  -> ln.soot

# ln.what
sallow: Shrouds, love. What else would I wash at four in the morning? The hospital sends them. The morgue sends them. People who die on the Strip don't always have anyone to wash them, so I do. It's a small thing. Somebody should.
@next ln.hub

# ln.clothes
sallow: Not living clothes, no. The living have their own machines now. Nobody needs a launderette at three in the morning except the dead and the people who look after them.
@next ln.hub

# ln.soot
sallow: One of Mother's? I was. A long time ago. Now I'm my own. Mother doesn't mind. Wraiths drift. We go where the work is. My work's here.
@next ln.hub

# ln.again
sallow: Back again. Sit, love. Not by four.
@next ln.hub

# ln.hub
* "Machine seven. What's in it?"  -> ln.seven {once} {if !task:s_shroud}
* Help her fold.  -> ln.fold {once}
* "Back to the seven shrouds."  -> ln.shrouds {if task:s_shroud=active}
* Leave.  -> end

# ln.seven
sallow: Seven? Ah. Seven's special. Seven came in August. Seven shrouds from St. Jude's basement, very good linen, with little tags. B1, one through seven. Sent to be burned, not washed. The Kowalski van brought them.
sallow: I don't burn shrouds. I wash them. So I've been washing them. One a night. Every night since August. Seven nights round, then start again. I don't know why. It felt like somebody ought to.
> She opens machine seven. A white sheet, very clean. A tag: ST. JUDE'S · B1 · 4.
web(6): The seven. Their shrouds came here instead of the incinerator. Kowalski's sent them out with the bodies' laundry. Nobody checked.
sallow: They're for people with no graves, love. Nobody's buried them. Nobody's said anything over them. I've been waiting for somebody to come and collect.
{do task:s_shroud; note:s_shroud|Mrs. Sallow at the Ever-Open Launderette has been washing seven shrouds from St. Jude's basement every night since August. The seven have no graves. Someone should collect them.}
@next ln.hub

# ln.fold
> You fold sheets with her for half an hour. Corner to corner, edge to edge, the way she shows you. It's very quiet. The strip light buzzes. Machine seven turns.
sallow: You've got good hands for it. Patient. Most of your lot are in such a hurry. They've got forever and they're always in a hurry.
{do tick:30; comp+2:Folding; rel:sallow+1}
@next ln.hub

# ln.shrouds
sallow: The seven. What will you do with them, love?
* Take them to Mrs. Okafor. For a funeral.  -> ln.okafor {if flag:met404}
* Take them to Miller. Evidence.  -> ln.miller {if met:miller}
* Take one to Luis Ferreira's mother. He's alive.  -> ln.luis {if flag:luisHome|flag:luisWitness}
* "Keep washing them, Mrs. Sallow."  -> ln.keep

# ln.okafor
> Seven folded shrouds in a carrier bag from the Lucky Mart. Mrs. Okafor opens the door of 404 and sees what you're holding and doesn't need to be told.
okafor: Seven. One of these is hers.
okafor: We'll do it properly. On Sunday. At the church on Halloran, the real one, not the club. I'll ring the families. The ones I can find. Mrs. Sallow is coming. She doesn't go out in the day. She says she'll make an exception.
{do give:shroud; task:s_shroud=done; flag:shroudFuneral=1; xp:60:Seven Shrouds; rel:okafor+2; lean:mercy+1}
@end

# ln.miller
miller: Shrouds. From St. Jude's. Tagged B1, one to seven. That were supposed to be incinerated. And weren't, because a woman with no face has been washing them for three months.
miller: This city. This bloody city. Give them here. Every one of those tags is a chain of custody.
{do give:shroud; task:s_shroud=done; flag:shroudEvidence=1; xp:60:Seven Shrouds; rel:miller+1}
@end

# ln.luis
> Number six. Luis's. You take it to the house on Pinewood Terrace with the blue door, and his mother takes it from you on the step without understanding, and then understands.
> In the corner of the linen, in blue cotton thread, Mrs. Sallow has sewn a tiny door.
{do give:shroud; task:s_shroud=done; xp:60:Seven Shrouds; comp+2:The blue door}
@end

# ln.keep
sallow: Keep washing. Yes. Somebody has to. I'll keep them clean till somebody's ready.
@end

// =====================================================================
// PIER NINE · the container yard, 1977
// =====================================================================
# p9.0
> Pier Nine. Containers stacked six high, rust-red and blue, with alleys between them like a city for giants. The cranes stand over the black water. A single sodium lamp at the end of the pier, and gulls asleep on every container ridge.
@gate flag:valkoAlly ? p9.valko : p9.alone

# p9.valko
> Valko gets out of the car and stands at the edge of the container yard and doesn't come any further.
valko: He brought me here. In '77. To watch. I wouldn't go in. I sat in the car with my hands over my ears like a child.
valko: Rask was my... we were in the pit together. In the forties. He was the only one who ever shared his water. Then the Sheriff bought me and left Rask there, and two years later Rask was on the docks, and the Sheriff gave him a job too, and it was all right for twenty-five years. And then it wasn't.
* "Show me where."  -> p9.where
* "We can go."  -> p9.go

# p9.alone
> Somewhere in here, in 1977, a Hound called Rask opened Pemberton from shoulder to hip and the Sheriff put Rask down. Nobody's been back since. Pemberton won't drive you any further than the gate.
pemberton: I'll be here, ‹sir›. I'll leave the engine running. Don't go to the end. The end's where it happened. {if !flag:pemDead}
* Go to the end of the pier.  -> p9.end
* Go back.  -> end

# p9.go
valko: ...No. No, I'll go in. You're here. I'll go in.
@next p9.where

# p9.where
> He walks you to the end of the pier. Between two containers, a patch of concrete that's darker than the rest. Somebody has put a little cairn of stones on it. A collar, rusted. A bowl.
valko: I did that. Every year. The first of August. I come at four and put a stone on and go before anyone sees. Seventy... no. Forty-seven stones. Forty-seven years.
* Put a stone on the cairn.  -> p9.stone {do lean:mercy+1}
* "Tell me about him. Rask."  -> p9.rask
* Pick up the collar.  -> p9.collar

# p9.end
> At the end of the pier, between two containers, a patch of darker concrete. A cairn of stones. A rusted collar. A bowl.
osmosis: Old blood under the concrete. Very old. A Hound's. And on top of it, fresh: another Hound, many times, the same one, always alone.
> Somebody comes here. Every year.
@next p9.where2

# p9.where2
* Put a stone on the cairn.  -> p9.stonealone {do lean:mercy+1}
* Pick up the collar.  -> p9.collar
* Leave it be.  -> end

# p9.stonealone
> You add a stone. You don't know why. It seems like the thing.
{do flag:pierDone=1; flag:pierStone=1}
@end

# p9.stone
> You pick a stone off the pier, flat and grey, and put it on the top of the cairn. Valko watches you do it and doesn't move.
valko: Forty-eight.
valko: ...He'd have liked you. Rask. He liked anyone who shared their water.
{do task:s_rask; task:s_rask=done; flag:pierDone=1; xp:60:Pier Nine; rel:valko+3; mem:valko:cairn}
@end

# p9.rask
valko: He was bigger than me. Uglier. He laughed at everything, even in the pit. When they set the dogs on us he'd laugh at the dogs. When he got bitten he'd laugh at the bite.
valko: Then in '77 he stopped laughing. I don't know why. I never asked. That's the worst thing. I didn't ask, and the Sheriff didn't ask, and nobody asked, and then the dockers were dead and he had to be put down.
valko: I keep thinking: if somebody had asked. Just once. "Rask, what's wrong."
tenant: I should have asked. I was his Sheriff. I knew the signs. I didn't want to know.
@next p9.where

# p9.collar
> Rust, cracked leather, and a brass tag on a broken chain: RASK · PROPERTY OF THE MARROW WARD · 1951.
@gate flag:valkoAlly ? p9.collarv : p9.collara

# p9.collarv
valko: Property. The Sheriff had them made for both of us. I threw mine in the harbour in '78. Rask never took his off.
valko: Keep it. No. Give it here. No. Keep it. I don't know. Keep it.
{do give:raskcollar; task:s_rask; task:s_rask=done; flag:pierDone=1; xp:40:Pier Nine; rel:valko+1}
@end

# p9.collara
{do give:raskcollar; flag:pierDone=1}
@end

// =====================================================================
// THE BELL OF ST. AGATHA · above the Reliquary
// =====================================================================
# bt.0
> A side door off Reliquary Row, behind the bins, into the old tower of St. Agatha's. A spiral stair. Pigeons. Up and up, past the noise of the club through the stone like a heartbeat, to the bell chamber at the top.
> The bell is still there. Nobody took it when they sold the church. It's huge and green and silent, and there's no clapper in it. Somebody has taken the clapper out.
> In the corner, on a camping stool, a woman in black with a cello between her knees. Not playing. Listening.
@gate flag:metMina|clan:choir ? bt.mina2 : bt.mina

# bt.mina
mina: Oh. Hello. I come up here to practice. Downstairs it's all bass. Up here you can hear the city.
mina: Mina. Mina Sorel. I play for the Lady sometimes, downstairs. I'm told I'm very good. It's hard to know when your audience doesn't breathe.
{do flag:metMina=1}
@next bt.hub

# bt.mina2
mina: You again. Or you, for the first time, and I've just heard about you. Sit. Mind the pigeons.
@next bt.hub

# bt.hub
* "Why is there no clapper?"  -> bt.clapper {once}
* "What do you hear from up here?"  -> bt.hear {once}
* "Play something."  -> bt.play {once}
* Leave.  -> bt.bye

# bt.clapper
mina: Ah. That's the story. The Bell of St. Agatha rang for the dead. Every time someone in the parish died, the sexton rang it once for each year of their life. Some nights it rang for an hour.
mina: When the Court bought the church in 1998, the Lady had the clapper removed. She said the Ward was too full of the dead for anyone to sleep. People said she meant it as a kindness. People who know her said she meant she couldn't bear to hear how old some of us are.
mina: The clapper's somewhere in the crypt. Under Brother Anselm, people say.
{do task:s_bell; note:s_bell|The Bell of St. Agatha rang once for every year of a dead parishioner's life, until Séverine had the clapper removed. It's said to be hidden in the crypt under Brother Anselm. Somebody could ring it for the seven.}
@next bt.hub

# bt.hear
mina: Everything. The harbour. The trains that don't come. A man on Halloran Street calling cats. The hum. Do you hear the hum? Since Thursday there's a hum under everything, very faint, one note, like someone holding a tuning fork against the city.
mina: Four point one four. I checked it against my A. It's a terrible note. It doesn't resolve.
{do flag:know414=1}
@next bt.hub

# bt.play
> She plays. The Bach suite, the first one, the one everyone knows. Up here, among the pigeons, under the silent bell, it sounds like the end of a long war.
{do tick:12; comp+2:Bach, in the tower; rel:mina+1}
@next bt.hub

# bt.bye
mina: Come back. Bring the clapper, if you find it. I'd like to hear her ring once before I'm too old to climb the stairs.
@end

# bt2.0 arc=severine night=3,4,5 label="\"Where is the clapper of St. Agatha's bell, my lady?\"" if=room:vip&alive:sev&task:s_bell=active&!flag:haveClapper
@focus severine
severine: The clapper. Who told you. Mina. That girl hears everything.
severine: Under Anselm. Yes. In his ossuary, with his bones on top of it, so it couldn't be moved without disturbing a saint.
severine: Why do you want it?
* "To ring the bell for the seven."  -> bt2.seven {do lean:mercy+1}
* "To ring it for the Sheriff."  -> bt2.vane
* "To ring it for you. For your mother."  -> bt2.mother {if flag:sevLetterRead|flag:sevBoxSecret}

# bt2.seven
severine: Seven mortals. Twenty-two years, nineteen, thirty-one... you'd ring for an hour.
severine: ...Take it. Carefully. Anselm doesn't like to be moved. If the bell rings tomorrow at dawn I'll pretend not to hear it. I'm very good at that.
{do flag:haveClapper=1; rel:severine+1}
@end

# bt2.vane
severine: Absalom. Three hundred and forty-one years. You'd be ringing until Sunday.
severine: No. I won't have it. I won't have the whole Ward woken for him.
{do rel:severine-1}
@end

# bt2.mother
> For a long time she doesn't say anything at all.
severine: Seventy-eight years. Josette Maréchal. Seamstress. Lyon. Seventy-eight.
severine: Take it. Take it and ring it seventy-eight times and don't tell me when, I don't want to be listening. I'll be listening.
{do flag:haveClapper=1; flag:bellForJosette=1; rel:severine+3}
@end

# bt3.0
> Up the tower, the clapper in a sack on your back: iron, two hundredweight, the weight of a small man. You hang it back on its chain with Mina's help. She says nothing. She has tears on her face before you've finished.
mina: Who's it for?
* For the seven.  -> bt3.seven {if !flag:bellForJosette}
* For Josette Maréchal, seventy-eight.  -> bt3.josette {if flag:bellForJosette}

# bt3.seven
> You ring it. Twenty-two for Dani. Thirty-one for Pete. Nineteen for Grace. The numbers of the seven, one after the other, until your arms ache even though they don't, until the whole Ward below has woken and is standing at its windows listening.
> On Ferrier Lane, Tariq comes out of the Lucky Mart and stands in the road with his face turned up. In 404, Mrs. Okafor counts. In the crypt, three hundred Kindred stop talking.
{do task:s_bell=done; flag:bellDone=seven; xp:50:The Bell of St. Agatha; tick:30; comp+3:The bell; heat+1}
@end

# bt3.josette
> Seventy-eight. Slowly. The bell is very loud and very old and it goes out over the Marrow Ward like a flood.
> Below, in the crypt under the club, a woman sitting alone on a sarcophagus with a letter in her lap counts every one.
{do task:s_bell=done; flag:bellDone=josette; xp:50:The Bell of St. Agatha; tick:20; rel:severine+2}
@end

// =====================================================================
// THE HEIGHTS · the house with no windows
// =====================================================================
# hg.0
> The Heights. Big Victorian houses with gravel drives and cedars and dogs that don't bark at you, they just watch. At the top, behind a wall, a house that's been built round its own darkness: three storeys of brick and not a single window. The gate is iron and open.
> A man is raking the gravel in the drive. At night. Very slowly. In a tailcoat.
quill: Good evening. You've come up from the Ward. I can always tell. The Ward's on your shoes.
quill: Quill. I keep the door. I have done since 1840. I'd offer you tea but nobody here drinks tea.
{do task:s_heights; note:s_heights|A man called Quill keeps the door of the Prince's house on the Heights. He was the Courthouse night clerk in 1871. He knows the Magistrate.}
* "Quill. You were the night clerk. At the Courthouse. Before the Pellows."  -> hg.clerk {if flag:clerkDone|mem:pellow.knew}
* "I'd like to see the Prince."  -> hg.prince
* "Tell me about the Magistrate."  -> hg.mag

# hg.clerk
quill: ...Pellow told you. The young one. Arthur. Seventy-something. Lovely boy.
quill: Yes. I kept the night desk from 1871 to 1940. I took the files up to the gentleman on the third floor. Then the Prince asked for me and I came up the hill and I've been raking this gravel ever since.
quill: I knew Absalom when he was new. When he wore a hat with a feather. He was very proud of the feather.
tenant: It was a magnificent feather.
{do rel:quill+1}
@next hg.hub

# hg.prince
quill: Nobody sees the Prince. Not since 1912. Not even me. I leave her letters on the hall table and in the morning they've been answered.
quill: But she knows you're here. She knows everyone who comes through the gate. She'll have heard you on the gravel.
@next hg.hub

# hg.mag
quill: Lord Ambrose. The Magistrate. Her mouth. He's older than the city. He came with her on the first ship. He doesn't like noise, or lies, or being kept waiting, or being bored. Of the four, being bored is the dangerous one.
quill: He likes evidence. Real evidence, in paper. He likes a witness who doesn't flinch. And he likes, very occasionally, to be surprised. Nobody has surprised him since the Armistice.
web(5): Paper. Unflinching witnesses. Surprise. That's how you win a Tribunal.
{do flag:knowMagistrate=1}
@next hg.hub

# hg.hub
* "Will you give him a message from me?"  -> hg.msg {once}
* "Why do you rake the gravel at night?"  -> hg.gravel {once}
* Leave.  -> hg.bye

# hg.msg
quill: A message. For Lord Ambrose. From the accused, the night before the Tribunal. That's highly irregular.
quill: What is it?
* "Tell him the lamps under Platform 0 are federal. He'll be sitting on them."  -> hg.lamps {if flag:knowCode|flag:sootLampsCount}
* "Tell him I'll bring the truth, and it'll surprise him."  -> hg.truth
* "Tell him Absalom says hello."  -> hg.hello {if sync>=40}

# hg.lamps
quill: ...Federal lamps. Under the Magistrate. During a Tribunal of the Prince.
quill: I'll tell him now. He won't believe it. But he'll look. He always looks. That's why he's lasted.
> He goes into the dark house. When he comes back he's carrying a card, cream, black-edged, with one word on it in a very old hand.
quill: He says to give you this. He says if you have something to say tomorrow that's true and frightening, show it to him first.
{do give:magcard; flag:magistrateWarned=1; task:s_heights=done; xp:50:The House With No Windows}
@end

# hg.truth
quill: The truth, and it'll surprise him. Bold. Very bold. He'll either love you or have you staked. Possibly both, in that order.
quill: I'll tell him.
{do flag:magistrateIntrigued=1; task:s_heights=done; xp:40:The House With No Windows}
@end

# hg.hello
> You don't decide to say it. It comes out of you in a voice that isn't yours, dry and old and amused.
tenant: Quill. Tell Ambrose that Absalom says hello, and that he still owes me forty guineas from the Waterloo bet.
> Quill drops the rake.
quill: ...My Lord Sheriff.
quill: I'll tell him. Good God. I'll tell him.
{do flag:magistrateKnowsVane=1; task:s_heights=done; xp:50:The House With No Windows; sync+4:Forty guineas}
@end

# hg.gravel
quill: Because the Prince likes the sound. When it's raked, it's quiet. When someone walks on it, she hears. Every footstep in the drive, for a hundred and eighty years.
quill: Yours, tonight. She'll have listened to every one.
@next hg.hub

# hg.bye
quill: Mind the gravel. She's listening.
{do flag:heightsDone=1}
@end
`,'c_places');

(function(){const X=NL.EXTRAS;
X.sallow={n:'Mrs. Sallow',color:'#c8c8d8',role:'The Ever-Open Launderette',spec:{face:{long:1.08,cheek:1.7,jaw:1.3},skin:[.6,.62,.66],hair:{style:'bun',color:[.5,.5,.52]},shirt:[.5,.5,.52],coat:{color:[.45,.45,.48],length:.6,collar:false},height:.9,eyes:[.8,.85,.95]}};
X.quill={n:'Quill',color:'#e0d8c0',role:'Doorkeeper, the Prince\'s house',spec:{face:{long:1.12,cheek:1.4,jaw:1.1,nose:1.3},skin:[.84,.8,.78],hair:{style:'slick',color:[.85,.85,.82]},shirt:[.9,.9,.88],coat:{color:[.08,.08,.1],length:.6,collar:true},eyeGlow:[.2,.18,.12]}};
// the clapper goes back on its chain
NL.PLACES.forEach(p=>{if(p.id==='belltower'){const b=p.before;p.before=async(S,G)=>{if(S.flags.haveClapper&&!S.flags.bellDone){NL.Camp.closeMap();G.tick(14);await G.talk('bt3.0');return false;}return b(S,G);};}});
// Tribunal: the Magistrate's card, and the bell
const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;
const st0=ENC.tribunal.start;ENC.tribunal.start=function(S,G){const r=st0.call(this,S,G);if(S.flags.magistrateWarned)r.prog+=1;if(S.flags.magistrateKnowsVane)r.threat=Math.max(0,r.threat-1);return r;};
const mv=ENC.tribunal.moves;ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
  if(G.has('magcard'))M.push({t:'Hold up the black-edged card. "Speak."',once:'tb_card',ok:st=>{st.prog+=2;return [L('magistrate','...Ah. Quill\'s messenger. You told me there were lamps. I looked. There are lamps.'),T('He doesn\'t say anything else. He doesn\'t need to. The whole Court has seen him look down at the grate under his own chair.')];}});
  if(S.flags.bellDone==='seven')M.push({t:'"You heard the bell, Magistrate. Before dawn yesterday. That was for them. The seven."',once:'tb_bell',ok:st=>{st.prog+=1;return [L('magistrate','I heard it. I counted. Twenty-two. Thirty-one. I wondered who would ring for mortals.')];}});
  return M;};
})();
