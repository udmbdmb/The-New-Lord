'use strict';
/* THE NEW LORD — blood tells, part one: what the people of the Ward make of the clan you woke up as (Sovereign, Glass, Butchers, Rot, Wraiths) */
NL.Script.add(String.raw`
# bl.sov arc=tenant night=2,3,4,5 label="Ask him why the blood came out Sovereign." if=clan:sovereign prio=1
@focus tenant
tenant: Because it was mine. Because the thing in the freezer that drank me was hungry enough to take all of it, the crown and the debts and the bad habits.
tenant: The Sovereign line is old, child. Older than the city. It came over on a ship in the hold with the wine and the cholera, and every one of us since has believed, privately, that the ship was ours.
tenant: You'll feel it tonight. A man will bump into you on the Strip and not say sorry, and something in your mouth will want him on his knees. That's not you. That's eleven generations of very bad manners.
* "How do I stop it?"  -> bl.sov1
* "Maybe I want him on his knees."  -> bl.sov2
* "You had two hundred years. Did you ever stop it?"  -> bl.sov3

# bl.sov1
tenant: You don't stop it. You notice it. You say, "Ah. There it is." And then you choose to let the man walk on with his rudeness intact.
tenant: I managed it about one time in three. Agnes said that made me the most restrained Sovereign she'd ever heard of. She'd only heard of me. It was a joke. It's still the nicest thing anyone's said to me.
{do lean:restraint+1; sync+1; mem:tenant:sovstop}
@end

# bl.sov2
tenant: Of course you do. So did I. So did my sire. So did his.
tenant: Do it, then. Once. Make a man kneel on wet concrete because he didn't apologize. Then watch his face when he gets up. Then tell me whether you want to do it twice.
{do lean:pride+1; lean:restraint-1}
@end

# bl.sov3
tenant: ...
tenant: No. I collected debts. I sat in a study and made the Ward kneel by post. It's the same thing with better stationery.
tenant: You're a cruel child sometimes. You're right, too. That's the worst combination.
{do lean:candour+1; sync-1}
@end

# bl.sovp arc=pemberton night=2,3,4,5 label="\"Pemberton. Does it feel different, serving me? This blood?\"" if=clan:sovereign prio=1
@focus pemberton
pemberton: Different. No, ‹sir›. Exactly the same. That's what frightens me.
pemberton: When the Sheriff spoke, my hands did things before I'd decided to do them. Forty years of that. On Monday night, in the car, you said "left here" and my hands turned the wheel left before I'd heard the word.
pemberton: Sovereign blood doesn't ask. It never has. I've only ever been asked by one of you, once. In 1999. He asked me whether I was happy. I didn't know what to say.
* "Are you? Happy?"  -> bl.sovp1
* "Then I'll ask. Every time. Even when I don't have to."  -> bl.sovp2
* "The blood decides. You said it yourself."  -> bl.sovp3

# bl.sovp1
pemberton: ...I am content, ‹sir›. Content is a smaller word. It's a more honest one. I like the car. I like the city at four in the morning. I don't like that I'll never know whether I'd have liked them anyway.
{do rel:pemberton+1; lean:candour+1}
@end

# bl.sovp2
> He looks at you in the rear-view mirror for a long moment. There's nothing in it, of course. He's looking at the space where you should be.
pemberton: That would be... very tiring for you, ‹sir›. It would also be the kindest thing that's happened in this car since it was built.
{do rel:pemberton+2; lean:mercy+1; flag:pembAsked=1; promise:pembask:Ask Pemberton, never command him.}
@end

# bl.sovp3
pemberton: I did. I did say that. I'm glad you were listening, ‹sir›.
> He says it in exactly the voice he'd use to say the car needs gas.
{do lean:pride+1; rel:pemberton-1}
@end

# bl.sovs arc=severine night=3,4,5 label="\"My lady. You've been staring at my hands all night.\"" if=clan:sovereign prio=1
@focus severine
severine: Have I. How rude of me. I was counting rings. Sovereigns wear them in the old style: one for each debt still owed to them. Absalom wore nine.
severine: You wear the signet and nothing else. Either you don't know the custom, or you've forgiven everyone. Both are equally dangerous in a Sovereign. The Court doesn't know how to bargain with somebody who doesn't keep a tally.
* "I don't know the custom."  -> bl.sovs1
* "I've forgiven everyone. Including you."  -> bl.sovs2
? pedigree 11 "I know the custom. I keep my debts somewhere you can't count them."  -> bl.sovs3 | bl.sovs4 {id bl_sovs}

# bl.sovs1
severine: Honest. How unusual. I'll teach you, if you like. It will take about forty years and you'll hate every one of them.
{do rel:severine+1; lean:candour+1}
@end

# bl.sovs2
severine: Including me. How very generous. Do you know, I don't think anyone has forgiven me for anything since 1793.
> The fan closes. Opens again. She's quite still behind it.
severine: Don't do it again. I haven't the faintest idea what to do with it.
{do rel:severine+2; lean:mercy+1; flag:sevForgiven=1}
@end

# bl.sovs3
severine: ...Oh, very good. In the head. Like a Prince.
severine: He used to do that, you know. Absalom. Sit there with nine rings and a perfectly bare memory and let us all wonder which one was ours.
{do rel:severine+1; lean:pride+1; xp:20:Old Custom}
@end

# bl.sovs4
severine: Somewhere I can't count them. Darling, I can count the debts on a man's soul through two inches of wool. You have exactly none. It's charming. Don't pretend otherwise.
@end

# bl.gls arc=tenant night=2,3,4,5 label="Ask him why you can hear him so clearly." if=clan:glass prio=1
@focus tenant
tenant: Because you came out Glass, child. Of all the bloodlines. I was Sovereign for two hundred years and the thing that ate me turned me into a window.
tenant: The Glass hear what people are loudest about not saying. I'm in here not saying a great deal. You can hear all of it, can't you? The dull roar of it.
* "Yes. It's like living next to a freeway."  -> bl.gls1
* "No. I hear one thing. Agnes. Over and over."  -> bl.gls2 {if mem:tenant.agnesstory|flag:readAgnes|seen:tnS.1946}
* "I hear that you're frightened."  -> bl.gls3

# bl.gls1
tenant: A freeway. How insulting. How accurate.
tenant: I'll try to be quieter. I've never tried to be quieter in my life. I may be very bad at it.
{do sync+1}
@end

# bl.gls2
tenant: ...
tenant: Yes. That would be it. That's the one I'm loudest about.
tenant: I'm sorry. It must be like hearing someone else's song through a wall every night. I'll stop. I can't stop. I'm sorry.
{do sync+2; comp-1}
@end

# bl.gls3
tenant: Frightened. Yes.
tenant: Of the sun, which is reasonable. Of Friday, which is reasonable. Of disappearing into you a little more every night until there's nothing left of Absalom Vane but a fondness for good stationery. Which is, I'm told, also reasonable.
tenant: Thank you for not pretending you couldn't hear it.
{do sync+1; lean:candour+1}
@end

# bl.glm arc=miller night=2,3,4 label="Listen to what Miller isn't saying." if=clan:glass prio=1
@focus miller
> She's talking about the case. Dates, addresses, a bus timetable. Under it, like a radio left on in another room, the thing she's loudest about not saying.
> *Mateo was nineteen. He was wearing my jacket. I lent it to him because it was raining and I never got it back and I never got him back and I still check every jacket in every evidence bag.*
* Say nothing. Let her keep it.  -> bl.glm1
* "Miller. What was he wearing? The night he went missing."  -> bl.glm2 {if !fact:miller:brother}
* "Miller. Was it your jacket? The one he was wearing?"  -> bl.glm3 {if fact:miller:brother}

# bl.glm1
> You let her talk about bus timetables. She never knows what you heard. That's the gift, you think: that it's yours to keep or give back, and you can keep it.
{do lean:restraint+1; mem:miller:glassheard}
@end

# bl.glm2
miller: What was... who?
miller: Who told you about my brother.
> She doesn't wait for an answer. She reaches into her inside pocket for a cigarette she gave up in 2012, finds nothing, and keeps her hand there.
miller: My jacket. Navy. With the precinct softball patch on the sleeve. Nobody knows that. It wasn't in the file. I didn't put it in the file.
{do rel:miller-1; fact:miller:brother; mem:miller:glassheard}
@end

# bl.glm3
> She goes completely still.
miller: I never told anyone that.
miller: ...It was raining. He was nineteen. I said bring it back Sunday.
> She doesn't ask how you knew. She looks at you for a long time like you're a door she's about to kick in, and then, very slowly, like she's decided not to.
miller: If you ever find a navy jacket with a softball patch on it. In a bag. In a freezer. Anywhere. You call me first. Before Missing Persons. Before anybody.
* "I promise."  -> bl.glm4

# bl.glm4
miller: Okay. Okay. Don't make me regret telling a stranger about my jacket.
{do rel:miller+2; lean:candour+1; promise:jacket:Call Miller first if you ever find Mateo's jacket.; mem:miller:glassheard}
@end

# bl.glsl arc=lisette night=3,4,5 label="\"Why do you keep your back to the mirrors?\"" if=clan:glass prio=1
@focus lisette
lisette: Because you came in. Glass. I can tell. All the mirrors in the Reliquary went quiet at ten past one, like a room full of people who've just seen someone come in who can hear them.
lisette: I count things. You know that. I count the bottles and the till and the faces at the rope. And when the Glass come in, the mirrors start counting me. I don't like it.
* "I'm not listening to you, Lisette."  -> bl.glsl1
? pulse 10 "I am listening. You're counting to stop yourself thinking about Hamburg."  -> bl.glsl2 | bl.glsl3 {id bl_glsl}

# bl.glsl1
lisette: You are. You can't help it. That's all right. Just... don't tell me what you hear. I'd rather not know what I'm loudest about. I've had a hundred years of not knowing and I've got very good at it.
{do rel:lisette+1; lean:restraint+1}
@end

# bl.glsl2
lisette: ...Four hundred and twelve. Four hundred and thirteen.
lisette: Yes. Yes, I am. Thank you. Now I've lost count. Now I'll have to start again.
> She starts again. But she's smiling a little, the almost-smile, and every mirror behind the bar cracks, very softly, at once, like ice on a pond in March.
{do rel:lisette+2; mem:lisette:glass; xp:20}
@end

# bl.glsl3
lisette: Wrong. I'm counting because I like counting. Some of us are simple.
> She isn't. But she's better at not being heard than you're good at hearing.
@end

# bl.bch arc=malakor night=2,3,4,5 label="\"You keep looking at my face, Malakor.\"" if=clan:butchers prio=1
@focus malakor
malakor: Because it's a terrible face. No offence. It's the face you were born with. Nobody in my family keeps the face they were born with past the first year. It's like wearing your christening gown to work.
malakor: You're one of us now. You know that, little diablerist? The blood came out Butcher. I could smell it on Monday. I thought: there's a waste. All that Sovereign pedigree and it's come out as us. Then I thought: no. There's a nephew.
* "I'm not your nephew."  -> bl.bch1
* "What would you do to my face?"  -> bl.bch2
* "Teach me. The Carving."  -> bl.bch3

# bl.bch1
malakor: No. You're not. You're a stray who fell into the good china. But blood's blood, and I'm sentimental. Ask anyone. I cried at a wedding in 1974. Somebody else's.
{do rel:malakor-1; lean:pride-1}
@end

# bl.bch2
malakor: Nothing. Leave it. It's yours. You'll want it later, when you've changed it six times and can't remember which one your mother would recognize.
malakor: That's the trick nobody tells you, nephew. Keep the first face somewhere. In a photograph. In a drawer. I didn't. I've no idea what I looked like in 1821. I used to think that was freedom.
{do rel:malakor+1; mem:malakor:firstface}
@end

# bl.bch3
malakor: Ha! Good. Give me your hand.
> He takes your hand in his enormous one and turns it palm up and, with a thumbnail, without asking, opens a line across it from the heel to the base of your little finger. It doesn't hurt. It should.
malakor: Close it. Not with blood. With *intention*. Think of the skin as wet clay that's forgotten what shape it was.
? abattoir 10 "Close it."  -> bl.bch4 | bl.bch5 {id bl_bch}

# bl.bch4
> The edges of the cut find each other, like two people in a crowded room, and knit. There's no scar. There's a faint warmth in the palm that wasn't there before.
malakor: There. There. You see? Now you can lie with your hands. Now everyone in the Ward is a little afraid of you, and they don't know why.
{do rel:malakor+2; xp:30:The Carving; flag:carveLesson=1}
@end

# bl.bch5
> The cut closes, but crooked, a raised pink seam across your lifeline like a road on a map.
malakor: Hah. Well. You've got a scar now. First one you've ever made yourself. Keep it. We all keep the first one.
{do rel:malakor+1; flag:carveScar=1}
@end

# bl.bct arc=tiny night=3,4,5 label="\"Tiny. Your kidneys. I'm a Butcher now. I could look.\"" if=clan:butchers&fact:tiny:kidney prio=2
@focus tiny
tiny: ...You could look.
tiny: Mr. Obi, the doctor at St. Jude's says. Mr. Obi, they're at eleven per cent. Mr. Obi, you need a transplant and you're number four hundred and something on the list. And a vampire on the rope says: I could look.
* "I could do more than look."  -> bl.bct1
* "Forget I said it."  -> bl.bct2

# bl.bct1
tiny: Do more. Like what. Like the Butchers do. Reach in and make them new.
tiny: And then what am I? I've watched that door nine years. I know what the Syndicate's people look like after the Butchers have been at them. They don't look *wrong*. They look *finished*. Like somebody else decided what they were for.
? velvet 10 "You'd still be you. You'd just be you without the machine three mornings a week."  -> bl.bct3 | bl.bct4 {id bl_bct}
* "Then don't. But the offer stands."  -> bl.bct5

# bl.bct2
tiny: Forgotten. Already forgotten. Rope's that way.
> He doesn't forget. You can see him not forget for the rest of the night.
@end

# bl.bct3
> He looks out at the street for a long time. A taxi goes by. A girl in silver shoes laughs at something on her phone.
tiny: Three mornings a week. Four hours a time. I read the whole of the Patrick O'Brian books in that chair. Twenty books.
tiny: ...Do it. Do it on Saturday. If there's a Saturday. If you're here on Saturday and I'm here on Saturday, do it. Before I change my mind.
{do rel:tiny+2; flag:tinyCarve=1; promise:tinycarve:On Saturday, fix Tiny's kidneys.}
@end

# bl.bct4
tiny: You don't know that. You don't know that. You've been a Butcher for four days.
tiny: Ask me again when you've been one for four years.
{do rel:tiny+1}
@end

# bl.bct5
tiny: The offer stands. Okay. Okay. I'll... think about it in the chair. I'll have four hours.
{do rel:tiny+1; lean:restraint+1}
@end

# bl.bcr arc=rostova night=3,4,5 label="\"Doctor. If a Butcher could fix a man's kidneys with his thumbs. Would you let him?\"" if=clan:butchers&flag:tinyCarve prio=2
@focus rostova
rostova: Let him. I'd have him arrested. Then I'd ask him to show me how.
rostova: That's the problem with you. You understand? Not the blood. Not the teeth. *That.* You can do in a minute with your thumb what takes me six hours and a donor and a family in Ohio crying in a corridor.
rostova: And you do it for gangsters and nightclub owners and pretty boys who want new chins.
* "I'm doing it for the man on the door. On Saturday. Will you be there?"  -> bl.bcr1
* "You'd rather he waited for a family in Ohio."  -> bl.bcr2

# bl.bcr1
rostova: Be there. In case you kill him. Yes. Yes, I'll be there.
rostova: With a crash cart. And a notebook. God forgive me. With a notebook.
{do rel:rostova+1; flag:rostovaCarve=1}
@end

# bl.bcr2
rostova: I'd rather the world was built so nobody had to choose between a family in Ohio and a Butcher's thumb.
rostova: It isn't. Go and do it. Don't tell me about it.
{do rel:rostova-1}
@end

# bl.rot arc=tenant night=2,3,4,5 label="\"Say it. You hate the blood I came out with.\"" if=clan:rot prio=1
@focus tenant
tenant: Hate is a strong word.
tenant: ...I find it difficult. I'm a snob, child. I was born a snob in Ajaccio and I died one in a meat locker. I spent two hundred years being told the Rot were the vermin of the Ward and I said it at dinner parties and people laughed.
tenant: And now I'm *in* one. Grey skin. Rats looking up when we pass. Flowers dying in our hands. I can feel it in your fingers when you touch a railing. The rust wants to hear about your day.
* "Then get used to it."  -> bl.rot1
* "Tell me who you said it to. At those dinner parties."  -> bl.rot2
* "The rats like me. That's more than the Court ever managed."  -> bl.rot3

# bl.rot1
tenant: Yes. Yes. That's the correct response. Sovereigns are always being told to get used to things by people who've had to get used to much worse.
{do lean:pride-1; sync-1}
@end

# bl.rot2
tenant: To Séverine, mostly. To the Prince, before 1912. To a Rot called Brother Wick, once, to his face, at the Elysium, in 1951. He laughed too. He was being polite. I knew he was being polite.
tenant: He died in the Switchyard fire of 1962 carrying four mortals out of the ticket hall on his back. I didn't go to the Ash Rite. It wasn't done, for a Sovereign. I've thought about that more this week than I have in sixty years.
* "There's a shrine in the cistern. Soot keeps candles. You could light one."  -> bl.rot4
* "Nobody's going to remember what you said at dinner parties."  -> bl.rot5

# bl.rot3
tenant: ...Ha. Ha. Yes. The rats have better manners than the Court and turn up on time. Agnes would have liked them. She fed the pigeons on the Courthouse steps every lunchtime for thirty years.
{do sync+1; comp+1}
@end

# bl.rot4
tenant: A candle. For Brother Wick. Lit by a Rot. With my hands, which are your hands.
tenant: Yes. Yes, I think I'd like that. If we're passing. If you'd... yes.
{do sync+2; flag:wickCandle=1; mem:tenant:wick}
@end

# bl.rot5
tenant: I will. That's the whole trouble with being dead in somebody else's head. You remember everything you said at dinner.
@end

# bl.rotc arc=soot night=2,3,4,5 label="Light a candle for Brother Wick." if=flag:wickCandle&!flag:wickLit prio=3
@focus soot
soot: Wick. Brother Wick. Who asked you for that name?
> You tell her. She listens with her whole body, the way she listens to the pipes.
soot: The Sheriff. Sorry. Seventy years late and inside somebody else. That's about right for a Sovereign.
> She gives you a candle from the box. Tallow. It smells of the old Switchyard, coal and bread. You light it on one of her hundred flames and set it on the water and it drifts, very slowly, against the current, toward the far wall where the old ticket hall used to be.
soot: It doesn't do that for everyone. Huh. Wick accepts.
{do flag:wickLit=1; sync+2; rel:soot+1; xp:25:Brother Wick}
tenant: (very quietly) Thank you.
@end

# bl.roto arc=okafor night=3,4,5 label="Help Mrs. Okafor with the flowers on the windowsill." if=clan:rot prio=1
@focus okafor
okafor: Leave those. Don't touch the geraniums, love, I know what you are. My mother had a lodger in Lagos, 1961, grey as a pigeon, every plant in the house went black in a week. Lovely man. Paid on time.
okafor: Dani planted those. Before. They're the last thing in the flat she planted. I water them every morning and talk to them like an old fool.
* Keep your hands in your pockets.  -> bl.roto1
? rigor 11 "Let me try. Carefully. Wither works both ways, if you're careful enough."  -> bl.roto2 | bl.roto3 {id bl_roto}

# bl.roto1
okafor: Thank you. That's manners. You'd be surprised how many people don't have those, dead or alive.
{do rel:okafor+1; lean:restraint+1}
@end

# bl.roto2
> You hold one finger very close to the brown edge of a leaf, and you think about time. Not forward. Back. Not a hundred years. A week.
> The brown edge goes green. Only the edge. Only one leaf. Then your finger starts to ache like a rotten tooth and you have to stop.
okafor: ...
okafor: Dani would have screamed. Dani would have put it on the internet.
> She touches the leaf. She doesn't say anything else. She doesn't need to.
{do rel:okafor+2; comp-1; xp:30:Green Edge; flag:okaforLeaf=1}
@end

# bl.roto3
> The leaf goes black. All of it. Then the one next to it.
okafor: Ah. Ah, well. Ah, well. They were dying anyway, love. That's why I talk to them.
> She says it kindly. That's much worse.
{do comp-1}
@end

# bl.wr arc=tenant night=2,3,4,5 label="Ask him what it's like, being inside a Wraith." if=clan:wraiths prio=1
@focus tenant
tenant: Like living in a house with no windows. I keep going to look out and there's a wall.
tenant: We passed a shop window on Kerr Street tonight and I looked for us. Out of habit. Two hundred years I'd look in shop windows to see if my tie was straight. I looked tonight and there was a mannequin and a sign saying FINAL REDUCTIONS and nobody wearing my coat.
tenant: I was frightened. Not of anything. Just of the window. Isn't that absurd.
* "I'm frightened of it too."  -> bl.wr1
* "You'll get used to it."  -> bl.wr2
* "Describe yourself to me. What you looked like. So someone remembers."  -> bl.wr3

# bl.wr1
tenant: Are you. Good. No, not good. But good that I'm not the only one.
tenant: We'll look in windows together, then. Two people with no reflection, looking. It's a kind of company.
{do sync+1; comp+1}
@end

# bl.wr2
tenant: Yes. Everyone says that. Everyone who's never had to.
{do sync-1}
@end

# bl.wr3
tenant: Describe...
tenant: Tall. Thin. A face that portrait painters gave up on. The left eyebrow has a scar in it, from Corsica, from a man called Orsini and a goat. Dark hair. Grey at the temples since 1787, because I was made at twenty-six and I'd already started going grey from worry.
tenant: I had a way of standing with one hand behind my back that Agnes said made me look like a heron that was cross with the river.
tenant: Thank you. Nobody's ever asked me that. Now someone knows.
{do sync+2; mem:tenant:described; xp:15}
@end

# bl.wrs arc=soot night=2,3,4,5 label="\"Mother. You said I smell of the cistern.\"" if=clan:wraiths prio=1
@focus soot
soot: Because you do, child. Because you're mine. The blood came out Wraith. I heard it on Monday through the drains at Kowalski's. A new voice going quiet.
soot: Do you know what that means? It means the Court can't see you in a camera, Miller can't keep your face in her head past the end of the street, and every echo of every death in this Ward can see you perfectly. You're more real to the dead than to the living now.
* "I don't want to be more real to the dead."  -> bl.wrs1
* "Then teach me to listen."  -> bl.wrs2
* "What do you want from me, Mother? Kin always want something."  -> bl.wrs3

# bl.wrs1
soot: Nobody wants it. That's the joke. Nobody chooses to be a Wraith. We happen. Like damp.
soot: You'll want it in a hundred years. When everyone you knew is an echo and you're the only one who can still hear them say good morning.
{do rel:soot+1; comp-1}
@end

# bl.wrs2
> She puts one of her bone-microphones against your ear. It's warm. It shouldn't be.
> Through it, very faint, the whole Ward: a tap running in the Rookery. Miller's car idling. Somebody in the Reliquary toilets crying with the hand-dryer on to cover it. Pemberton humming the same four bars of something in the Continental. And under all of it, the dead. A man on Ferrier Lane saying *I only went out for cigarettes*. A girl at the Switchyard saying *which way is home* over and over.
soot: That's what I hear. Every night. Forever. Now you have one microphone's worth of it. Keep it. Don't listen too often.
{do rel:soot+2; xp:30:The Pipes; flag:sootEar=1}
@end

# bl.wrs3
soot: Ha. Clever little ghost.
soot: When I go, someone has to sit here. With the candles and the pipes. I've been looking for a hundred years. They all run away.
soot: I'm not asking. I'm telling you the seat exists. That's the price of knowing.
{do rel:soot+1; mem:soot:seat}
@end

# bl.wrl arc=leo night=2,3,4,5 label="\"Leo. Look at me. What color are my eyes?\"" if=clan:wraiths&alive:leo prio=1
@focus leo
leo: Your eyes are... they're...
leo: Okay this is going to sound insane. I've been looking at you all night. And every time I look away I can't remember your face. I remember the coat. I remember your voice. I've got a whole joke about your voice. But if somebody asked me to describe you to a sketch artist I'd go "uh, sort of... person shaped?"
leo: Is that a vampire thing? Is that a you thing? Did I do something wrong?
* "It's a Wraith thing. People forget us. It's not you."  -> bl.wrl1
* "Draw me. Right now. On a napkin. Then you'll have it."  -> bl.wrl2

# bl.wrl1
leo: People forget you. That's the saddest superpower I've ever heard of. That's the superpower of a guy at a wedding nobody invited.
leo: ...I'm going to write it down. Your face. Every night. In the notebook. Then I'll have it in the morning.
{do rel:leo+1; flag:leoWritesFace=1}
@end

# bl.wrl2
> He draws you on a Lucky Mart napkin with a biro. It's terrible. The eyes are too big and the coat is too square. He keeps looking up at you and down at the napkin with his tongue between his teeth like a kid doing homework.
leo: There. That's you. That's... okay that's a frog in a coat. But it's YOUR frog in a coat.
> He folds it into his wallet behind his library card. An hour later, you see him take it out and look at it, and look surprised, and look relieved.
{do rel:leo+2; flag:leoNapkin=1; comp+1; mem:leo:napkin}
@end
`,'c_blood1');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.wickLit)o.push(['A candle in the cistern','Drifts against the current toward the old ticket hall every night, though nobody lights it any more. Mother Soot says Brother Wick is very patient, for a Rot, and the Sheriff was very late, for a Sovereign.']);
  if(f.leoNapkin&&!f.leoDead)o.push(['A napkin in a wallet','Behind a library card: a frog in a coat, in biro. Leo takes it out sometimes, on the bus, and can\'t quite remember who it is, and keeps it anyway.']);
  if(f.okaforLeaf)o.push(['A windowsill in 404','One geranium leaf stays green all winter. Only the edge. Mrs. Okafor tells the others about it in a whisper, like a secret, or a prayer.']);
  return o;});
