'use strict';
/* THE NEW LORD — street events, part seven: the Ward at four in the morning, and what it asks of whoever's walking through it */
NL.Script.add(String.raw`
# ev.ambo street=2,3,4,5 w=2
> Halloran Street. A car on the sidewalk with its hazards going, the front crumpled against a lamppost. The driver's door open. A man of fifty in a suit sitting on the curb beside it with his hands over his face. And on the asphalt, under the streetlight, a cyclist. Not moving. A lot of blood, black under the sodium light.
frenzy: Blood. Fresh. On the road. Nobody would know.
* Kneel by the cyclist. Check her airway.  -> ev.am1
* Keep your distance. Call 911 from the payphone on the corner.  -> ev.am2
* Walk away. Quickly. Before the hunger decides for you.  -> ev.am3

# ev.am1
> You kneel. The smell hits you like a wall. Your teeth ache. Your hands, somehow, are steady.
autopsy: Breathing. Shallow. Femoral bleed, left thigh. She's got minutes.
* Tourniquet. Your belt. Now.  -> ev.am4
? abattoir 10 "Close the wound with your thumb. Butcher's way."  -> ev.am5 | ev.am4 {id ev_am} {if clan:butchers}

# ev.am4
> Your belt, round her thigh, high. You pull it tight. Tighter. She screams, which is good. Screaming is breathing.
> You talk to her the whole time. You don't know what you say. Something about the weather. Something about the Phillies. *Stay with me.* {if past:paramedic}
> The man in the suit has stopped crying. He's holding her hand. He's saying "I'm sorry, I'm sorry, I didn't see you" over and over.
> Sirens. You're gone before the ambulance comes round the corner. On the asphalt, a belt with a brass buckle that nobody will ever trace.
{do comp+3; lean:mercy+1; lean:restraint+1; xp:20}
@end

# ev.am5
> You press your thumb to the wound and think about clay. The bleeding stops. Not slows. Stops. The edges knit under your thumb like a zipper.
> She opens her eyes and looks at you. Grey face. Glowing eyes. Thumb in her thigh. She doesn't scream. She says, very calmly, "Am I dead?"
* "No. Not tonight."  -> ev.am6

# ev.am6
> The sirens come. You go. Later, in the ER at St. Jude's, a surgeon will look at a closed femoral wound with no stitches and no scar and write "?? spontaneous" on the chart and go and have a long sit-down.
{do comp+3; lean:mercy+1; heat+1; xp:25}
@end

# ev.am2
> The payphone on the corner works. They always work on Halloran Street; nobody has ever bothered to steal them. You give the address. You give the details. You hang up when they ask your name.
> From the corner, you watch the ambulance come. You watch them lift her. You don't go closer. It was the right distance. You hate that you know it was the right distance.
{do comp+1; lean:restraint+1}
@end

# ev.am3
> You walk. Fast. Then faster. Two blocks away, you stop and lean on a wall with your eyes shut until your teeth stop aching.
> Behind you, very faint, sirens. Somebody called. Somebody always calls, on Halloran Street.
{do lean:restraint+1; comp-1}
@end

# ev.chess street=3,4,5 w=1
> The all-night laundromat on Vine. An old man in a cardigan at the folding table with a chessboard set up, playing both sides, waiting for his dryer. He looks up as you come in out of the rain.
> "You play?" he says. "Nobody plays. Sit. White or black."
* Sit. Play white.  -> ev.chs1
* Sit. Play black.  -> ev.chs2
* "I don't play."  -> ev.chs3

# ev.chs1
> You play. You're bad. Then you're less bad. Then, about move twenty, someone else's hands start moving your pieces, and you let them.
tenant: (moving a knight with your fingers) Ruy López. Exchange variation. I played this against a Prussian count in 1802 for a castle. I lost. He kept the castle. I kept the knight.
> The old man stares at the board. "Where'd you learn that?" he says. "Nobody plays that any more."
{do sync+2; comp+1}
@end

# ev.chs2
> You play black. He opens with the king's pawn. You answer. He smiles, the way people smile when somebody finally speaks their language.
> You lose in thirty-one moves. He shakes your hand. He doesn't flinch at the cold. "Same time Thursday," he says. "I'm here every Thursday. My wife used to do the laundry. Now I do the laundry."
{do comp+2}
@end

# ev.chs3
> "Nobody does," he says, and goes back to playing both sides. "That's all right. I've got a good opponent." He taps his own temple. "Never lets me win."
@end

# ev.window street=2,3,4,5 w=1 if=clan:gilded|clan:glass
> A shop window on Kerr Street. A bridal boutique, closed, lit from inside. One dress on a mannequin, white, enormous, covered in crystals, and so ugly that your teeth hurt. {if clan:gilded}
> A shop window on Kerr Street. A bridal boutique, closed. Your reflection isn't in it, but the cracks are: a fine spiderweb running across the glass, spreading as you stand there, as if the window can hear something you're thinking. {if clan:glass}
> Inside, at the back, a seamstress is still working at two in the morning, under a lamp, sewing beads onto a hem by hand. She's crying. Not loudly.
* Knock on the glass.  -> ev.wnd1
* Walk on.  -> ev.wnd2

# ev.wnd1
> She comes to the door with a pin in her mouth. "We're closed," she says around it. Then she looks at you properly. "You're not here for a dress, are you."
> She tells you anyway. The wedding's tomorrow. The bride changed her mind about the hem. Three times. This is the fourth hem. The bride is her sister.
* "Leave the hem. Your sister will marry in whatever hem she's got."  -> ev.wnd3
? stagecraft 9 "Make the next one the last one. Tell her it's the fashion in Paris."  -> ev.wnd4 | ev.wnd3 {id ev_wnd}

# ev.wnd3
> She laughs. The pin falls out of her mouth. She picks it up. "Whatever hem she's got. Yeah." She turns off the lamp. "She'll hate it. She'll be married. She'll forget about it by the cake."
{do comp+1}
@end

# ev.wnd4
> "The fashion in Paris," she says. "Paris. Oh, she'll love that. She'll tell everyone." She's already reaching for her phone. "It's three in the morning. She's awake. She's always awake before a wedding."
> Through the glass, as you go, you see her on the phone, laughing, saying "Paris, Mari, *Paris*."
{do comp+2}
@end

# ev.wnd2
> You walk on. Behind you, the lamp in the back of the shop stays on.
@end

# ev.pigeon street=2,3,4,5 w=1 if=clan:rot
> Under the railway bridge on Kerr Street, a pigeon with a broken wing, flapping in a circle on the wet concrete. The rats have seen it. Four of them, at the edge of the light, waiting. They've seen you too. They're waiting to see what you'll say.
* "Leave it."  -> ev.pg1
* "Go on, then."  -> ev.pg2
* Pick the pigeon up.  -> ev.pg3

# ev.pg1
> The rats look at each other. Then they go, back into the dark under the bridge, one by one, the last one looking back at you as if to say: fine, this once.
> The pigeon stops flapping. It looks at you with one orange eye.
{do comp+1}
@end

# ev.pg2
> They go in. It's quick. Rats are efficient. You walk on, and you try not to feel proud of them, and you don't quite manage it.
{do lean:mercy-1}
@end

# ev.pg3
> You pick it up. It's very light. Its heart is going like a sewing machine. It doesn't peck you.
> In your cupped hands, under the Rot's touch, the broken wing does something. Not heals. Settles. The bone goes quiet. You feel the flowers-dying feeling run backwards for one second, and then forwards again, and it's over.
> You put it on a ledge under the bridge. In the morning it will fly, badly, to the Courthouse steps, where a lot of pigeons have been fed every lunchtime for thirty years by a woman who's been dead since 1961.
tenant: Agnes's pigeons. Some of them must still be the great-grandchildren. Oh, child.
{do comp+2; sync+1; xp:15}
@end

# ev.recital street=3,4 w=1 if=flag:harrowDaughter|flag:harrowShaken
> A flyer on a lamppost on Vine Street, half torn off: PORT VELLUM CONSERVATORY · STUDENT RECITAL · THURSDAY 7 PM · ADMISSION FREE. Under the list of names, one circled in biro, by someone who'd pressed hard: *HARROW, C. (cello).*
* Take the flyer. Leave it on the windshield of a grey van.  -> ev.rc1
* Leave it.  -> ev.rc2

# ev.rc1
> You find the van on Vine Street, engine off. You tuck the flyer under the wiper. You walk away before anyone sees.
> Later, much later, Thomas Harrow will find it and stand in the rain reading it for a long time. Thursday. Seven. He'll check his phone. He'll check the Tribunal timings. He'll do the arithmetic.
{do flag:recitalFlyer=1; rel:harrow+1}
@end

# ev.rc2
> You leave it. The rain will take the rest of it by morning.
@end
`,'c_street7');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.recitalFlyer&&!f.harrowDead)o.push(['A student recital, Port Vellum Conservatory','On Thursday at seven, in the back row, a man in a grey suit with no sunglasses, holding a peppermint he never unwrapped. The cellist in the second piece saw him, and missed a note, and played the rest of it better than she ever had.']);
  return o;});
