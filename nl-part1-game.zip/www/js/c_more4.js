'use strict';
/* THE NEW LORD — more of the people on the edges: Halloran and the cats, Coral after the Court, Lisette's teeth, Ashby's horse, Dutch's vote, and the people in between */
NL.Script.add(String.raw`
// =====================================================================
// HALLORAN · the cats
// =====================================================================
# hlX.0 arc=halloran night=2,3 label="\"Still thirty-one, Mr. Halloran?\"" if=room:rookery&!flag:halloranGone prio=0
@focus halloran
halloran: Thirty-one. Thirty-two last night. A new one. Black, with a white sock. I'm not naming it. You know my rule.
> He's on the landing in his cardigan with a carrier bag of cat food, waiting for eleven o'clock, when he goes down to the yard.
halloran: She's on at me again. Upstairs. "You love those cats more than me." I said, they don't threaten to go to your sister's every Tuesday.
* "Do you love them more than her?"  -> hlX.love
* "Do the cats know what I am?"  -> hlX.know
* "Can I come down with you, at eleven?"  -> hlX.feed

# hlX.love
halloran: Love. Fifty-one years. You don't love after fifty-one years. You... you know where the other one is. All the time. Like your own hand.
halloran: The cats I don't love. The cats I just feed. That's safer.
{do mem:halloran:hand}
@next hlX.hub

# hlX.know
halloran: Course they do. They came up the fire escape the night you first came in, all of them, and sat on the railing in a row like a jury. I've never seen anything like it.
halloran: Then they went back down. I think they decided you were all right. The one that isn't called Charlie abstained.
@next hlX.hub

# hlX.feed
> At eleven you go down with him to the yard behind the bins. He rattles the bag. They come: from under the cars, from the top of the wall, from places in the dark there shouldn't be room for cats. Thirty-two. They eat round your shoes and don't mind you at all.
> The new one, black with a white sock, sniffs your cold fingers for a long time. Then it bites you, quite hard, and walks off with its tail up.
halloran: That means it likes you. Don't name it.
{do rel:halloran+2; comp+1; tick:10; flag:sockBit=1}
@next hlX.hub

# hlX.hub
* "Goodnight, Mr. Halloran."  -> hlX.bye

# hlX.bye
halloran: Night. Watch the third stair, it goes.
@end

# hlY.0 arc=halloran night=4 label="\"Mr. Halloran, you and your wife need to be out of the Ward on Friday.\"" if=room:rookery&!flag:halloranGone&rel:halloran>=1 prio=2
@focus halloran
halloran: Out of the Ward. On a Friday. With her hip.
halloran: What's happening on Friday?
* "A gas leak. The whole street."  -> hlY.gas {do lean:candour-1}
* "Something bad. I can't tell you."  -> hlY.bad
* "Go to her sister's. She's been threatening it every Tuesday. Let her win, for once."  -> hlY.sister

# hlY.gas
halloran: A gas leak. Like in 1988. The whole of Halloran Street was in the school gym for two nights on camp beds. She made friends with a woman from 4C who turned out to be a shoplifter. They still send Christmas cards.
halloran: All right. The cats'll look after themselves. They always have.
{do flag:halloranGas=1}
@end

# hlY.bad
halloran: Something bad. ‹Son|Love›, I'm eighty-one. Something bad's been happening to me since 1953.
halloran: We'll stay in. Windows shut. Radio on. If it's bad, it's bad.
{do flag:halloranStays=1}
@end

# hlY.sister
> He stares at you. Then he laughs so hard he has to hold the banister.
halloran: Let her WIN. Oh, God. Oh, she'll be unbearable. She'll be unbearable till Easter.
halloran: ...All right. All right. Her sister's in Bayside. We'll go Friday. I'll tell her it was my idea. She'll know it wasn't. She'll be so pleased.
{do flag:halloranSister=1; rel:halloran+1}
@end

// =====================================================================
// CORAL · after the Court
// =====================================================================
# coX.0 arc=coral night=3,4 label="\"Coral. You're not dancing.\"" if=room:reliquary&flag:metCoral|room:reliquary&task:s_coral prio=0
@focus coral
> She's sitting on the steps by the cloakroom in her dancer's costume with a hoodie over it, reading the jobs page of the *Courier* with a highlighter.
coral: No. Night off. Well, not off. I'm on the rota. I just haven't gone on.
coral: Do you know what a dental receptionist earns? Neither did I. It's not a lot. It's more than this, though, if you count your blood as income.
* "You're leaving the Reliquary?"  -> coX.leave
* "What are you highlighting?"  -> coX.jobs
* "You could do better than a dental receptionist."  -> coX.better

# coX.leave
coral: Thinking about it. Since the thing with Ashby. Since you, I suppose. You looked at me like I was a person and I realized nobody else in this building does.
coral: My sister's in her second year. Nursing. She doesn't know what I do. She thinks I work in a bar. I do work in a bar. It's just I'm also on the menu.
@next coX.hub

# coX.jobs
coral: Dental receptionist. Florist's assistant, Bayside. Night porter at St. Jude's. Night shift at the Lucky Mart, which is funny, because I thought Tariq did every shift himself forever.
@next coX.hub

# coX.better
coral: Could I? Doing what? I've got no qualifications. I've got very good posture and I can dance in heels on a wet floor. I can tell from someone's walk whether they're going to tip. I can smile while someone drinks from my elbow.
coral: Those aren't skills. Those are scars.
* "Those are skills. You read people. You keep your balance. You stay calm when you're scared."  -> coX.skills
* "Then start somewhere small."  -> coX.hub

# coX.skills
> She looks at you. Then she laughs, a real laugh, surprised.
coral: When you put it like that I sound like a hostage negotiator.
coral: ...Hostage negotiator. Ha. Can you imagine.
{do rel:coral+1; comp+1}
@next coX.hub

# coX.hub
* "Go. Tonight. Don't go back on."  -> coX.go {once}
* "Stay till Friday. Then go. It'll be safer after."  -> coX.stay {once}
* "Good luck, Coral."  -> coX.bye

# coX.go
coral: Tonight. Just... walk out. Past Tiny. In a hoodie.
coral: Lisette will be furious. She'll say I owe for the costume.
? velvet 9 "Leave the costume. Walk out. Tiny will hold the door."  -> coX.goyes | coX.gono {id coX_go} {mod like:coral}

# coX.goyes
> She stands up. She takes off the heels and puts them in the bin by the cloakroom. She walks out barefoot past Tiny, who opens the rope for her and says "night, Coral," and doesn't ask, and she goes up the Row in the rain with the jobs page under her arm.
{do flag:coralFree=1; rel:coral+2; lean:mercy+1}
@end

# coX.gono
coral: No. Not tonight. I can't. I've got rent Friday. After Friday.
@next coX.hub

# coX.stay
coral: Friday. Yeah. After Friday. Everything's after Friday this week, isn't it.
{do flag:coralAfter=1}
@next coX.hub

# coX.bye
coral: You too. Whatever you are. Don't let them make you one of them.
@end

// =====================================================================
// LISETTE · the teeth
// =====================================================================
# lsX.0 arc=lisette night=3,4 label="\"Lisette. Do you count your teeth?\"" if=room:reliquary&!flag:lisetteGone&mem:severine.cries prio=3
@focus lisette
> She stops in the middle of counting the room. Her hand goes to her mouth before she can stop it.
lisette: Who told you that.
* "Séverine."  -> lsX.sev
* "Nobody. I guessed."  -> lsX.guess

# lsX.sev
lisette: Séverine. Of course. She tells everyone's secrets in the crypt at dawn, like bedtime stories. She thinks nobody's awake.
@next lsX.why

# lsX.guess
lisette: Liar. You've been in the crypt.
@next lsX.why

# lsX.why
lisette: Thirty-two. Every night. Before I sleep. One, two, three...
lisette: In 1921 a Hound pulled four of them out with pliers. In a cellar in Hamburg. He was asking where my sire was. I didn't know. He didn't believe me. They grew back. It took a year.
lisette: I count them because I'm afraid I'll wake up and they'll be gone again. Is that pathetic? You can say it's pathetic.
* "It's not pathetic. It's sensible."  -> lsX.sens
* "The Hound. Is he still alive?"  -> lsX.hound

# lsX.sens
lisette: Sensible. Ha. Nobody's ever called me sensible. They call me "Séverine's knife". They call me "the hostess". They call me "the one with the teeth", behind my back, because they think I don't know.
lisette: Thank you. I won't forget. That's not a compliment, darling; I never forget anything.
{do rel:lisette+2}
@end

# lsX.hound
lisette: No. I found him in 1957, in Lisbon. He was very old and very sorry. I took all his teeth. All of them. With his own pliers. It took a long time.
lisette: I still count mine.
{do rel:lisette+1; mem:lisette:hamburg}
@end

// =====================================================================
// ASHBY · Bramble
// =====================================================================
# abX.0 arc=ashby night=3,4 label="\"Lord Ashby. Who's Bramble?\"" if=room:vip&mem:severine.cries&!flag:ashbyDead&!flag:ashbyGone prio=3
@focus ashby
ashby: Bramble.
> The glass stops halfway to his lips.
ashby: Who's been... no. Séverine. Of course. She listens at coffins.
ashby: Bramble was a horse. A grey hunter, sixteen hands, the worst-tempered animal in Hampshire. Mine. In 1896 I rode him to hounds every Saturday and he threw me every Saturday and I loved him more than anything that's ever lived.
ashby: When I was Embraced I couldn't ride in daylight any more. I went to see him in the stable at night. He smelled what I was and he screamed. He screamed and screamed. My father had him shot the next morning because he wouldn't stop.
* "And you dream about him."  -> abX.dream
* "I'm sorry, Edmund."  -> abX.sorry

# abX.dream
ashby: Every dawn. Riding. In the light. He doesn't throw me. That's how I know it's a dream.
{do rel:ashby+1; mem:ashby:bramble}
@end

# abX.sorry
> He looks at you. Nobody's called him Edmund in this room for a century.
ashby: ...Thank you. It was a long time ago. He was only a horse.
ashby: He was not only a horse.
{do rel:ashby+2; mem:ashby:bramble}
@end

# abY.0 arc=ashby night=4 label="\"Lord Ashby. Stand with me on Friday.\"" if=room:vip&!flag:ashbyDead&!flag:ashbyGone&rel:ashby>=3 prio=4
@focus ashby
ashby: Stand. With you. In the chalk.
ashby: I'm a fencing master and a drunk and a baronet of nothing. I've no faction, no ghouls, no money worth mentioning. The Court keeps me around because I'm amusing at parties.
ashby: What on earth would you want me for?
* "Because you're the only one in that room who'll say what everyone's thinking."  -> abY.vulgar
* "Because you made amends to Coral. And to Winter. You're the only one who ever has."  -> abY.amends {if flag:ashbyCoral=promised|flag:winterDone}
* "Forget it."  -> abY.no

# abY.vulgar
ashby: Ha! Yes. I'm famously vulgar. It's my only distinction.
ashby: Very well. I'll stand up on Friday and be vulgar for you. I'll say: "Absalom Vane went to a mortal doctor for a cure and a child saved him from the light, and anyone who calls that murder is either a fool or on Harrow's payroll." And I'll look at Ottilie while I say it.
{do flag:ashbyStands=1; rel:ashby+1}
@end

# abY.amends
> He doesn't answer for a long time.
ashby: Two. In a hundred and thirty years. Two people I said sorry to. You noticed both.
ashby: Friday. I'll be there. I'll wear my good sword. I won't draw it. Probably.
{do flag:ashbyStands=1; rel:ashby+2}
@end

# abY.no
ashby: Quite right. Quite right. I'd only embarrass you.
@end

// =====================================================================
// DUTCH · the vote
// =====================================================================
# duX.0 arc=dutch night=3,4 label="\"Dutch. What does Local 0 actually want?\"" if=room:switchyard&!flag:local0Done prio=1
@focus dutch
dutch: Want? Brother, sister, whatever. Nobody's ever asked. Hang on, let me get the minutes.
> He takes out an exercise book with LOCAL 0 — MINUTES on the front in marker. He licks his thumb and turns to a page dated 1987.
dutch: "Item one. A place to sleep that isn't a drain. Item two. Not being hunted by Hounds for sport on Saturdays. Item three. A seat at Elysium, with a napkin." That's it. Hasn't changed in thirty-eight years.
* "That's not much to ask."  -> duX.much
* "Why the napkin?"  -> duX.napkin
* "What would you give for it?"  -> duX.give

# duX.much
dutch: It's not. It's not much at all. That's the thing that makes you angry, if you let it. That it's so small and they still won't.
@next duX.hub

# duX.napkin
dutch: Because Big Sal, God rest him, went to Elysium in 1986 to petition the Prince, and they let him in, and they let him speak, and when the Court ate after, they gave everyone a napkin except him. Folded. Linen. Everyone but him.
dutch: He walked out. He walked into the sun two weeks later. He left a note. It said "napkin". Just that.
{do mem:dutch:napkin}
@next duX.hub

# duX.give
dutch: Give? Everything. Every pair of hands. Every screwdriver. The Union's got sixty-three members and every one of them's been told they're nothing. You tell them they're something, they'll walk into fire for you.
@next duX.hub

# duX.hub
* "If I'm Sheriff, you get all three. Starting with the napkin."  -> duX.promise {do promise:local0:Give Local 0 its three items}
* "I can't promise anything. But I'll ask."  -> duX.ask
* "Goodnight, Dutch."  -> duX.bye

# duX.promise
dutch: All three. You heard that? Somebody write that down. Somebody write that DOWN.
> A girl in a ripped denim jacket writes it down in the minutes.
dutch: Item four, then: "The Sheriff-eater said all three." Underlined.
{do rel:dutch+2; flag:local0Promised=1}
@end

# duX.ask
dutch: Ask. That's more than anyone's done. Fine.
{do rel:dutch+1}
@end

# duX.bye
dutch: Solidarity.
@end

`,'c_more4');
