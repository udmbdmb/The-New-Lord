'use strict';
/* THE NEW LORD — more arcs: Harrow on Night Two and Three; Rostova and Margo on Friday; Ken Pruitt on the cordon; Luis, Winter, Teo, Coral and Lisette before the Tribunal */
(function(){
const S_=NL.Script;
S_.npc({id:'harrow',room:'stjude',at:[7.4,4.4,-2.2],pose:'idle',label:'A man in sunglasses, reading',if:'night:3&time>=40&time<240&!flag:harrow3Done&!flag:harrowDead',node:'hw3.0'});
S_.npc({id:'rostova',room:'switchyard',at:[9.4,3.6,-1.4],pose:'arms',label:'Dr. Rostova',if:'night:5&flag:rostovaTestify&!flag:rostovaDead&!flag:tribunalDone&time<240'});
S_.npc({id:'kenpruitt',room:'alley',at:[1.4,2.8,0.8],pose:'arms',label:'Ken Pruitt, in uniform',if:'night:5&flag:pruittInside&!flag:pruittDead&time<235'});
S_.npc({id:'margo',room:'switchyard',at:[3.0,5.6,0.6],pose:'idle',label:'Margo',if:'night:5&flag:margoTestify&!flag:margoDead&time<240'});
S_.npc({id:'teo',room:'switchyard',at:[10.6,5.6,-2.4],pose:'lean',label:'Teo',if:'night:5&task:s_mateo&!flag:teoGone&time<240'});
S_.npc({id:'lisette',room:'switchyard',at:[4.6,4.8,0.2],pose:'arms',label:'Lisette',if:'night:5&!flag:lisetteGone&time<240'});
})();
NL.Script.add(String.raw`
// =====================================================================
// HARROW · Night Two · on Ferrier Lane
// =====================================================================
# hw2.arc arc=harrow night=2 label="\"Nice sunglasses, Agent Harrow.\"" if=room:alley
@focus harrow
harrow: Thank you. They're prescription. I have a condition. Photophobia. Bright lights give me headaches.
harrow: Ironic, given the line of work. Do you have a condition, by any chance? You look a little peaky. There's a lot of it about. I'm actually doing a survey.
pulse(5): Steady heart. Pupils hidden. Sweat on the upper lip, very slight, in November. He's nervous and enjoying it.
* "What kind of survey?"  -> hw2.survey
* "You know exactly what I am."  -> hw2.know
* "I don't talk to the government."  -> hw2.govt

# hw2.survey
harrow: Community blood health. We're seeing some unusual readings in the Marrow Ward. Anaemia. Photosensitivity. People who don't show up in CCTV as clearly as they should. Odd clusters.
harrow: It's all voluntary. Five hundred dollars for a pint and a questionnaire. Here's my card.
> He holds out a card. US DEPARTMENT OF HEALTH · COMMUNITY BLOOD SURVEY. It's the same card that'll be under Leo's door tomorrow morning.
* Take the card.  -> hw2.card {if !has:harrowcard}
* "Five hundred dollars. That's what the seven got."  -> hw2.seven {if flag:knowTrial}
* "No thank you."  -> hw2.no

# hw2.card
{do give:harrowcard}
harrow: Call any time. I keep odd hours.
@end

# hw2.seven
> For half a second, his smile doesn't move at all, which is how you know it's working very hard.
harrow: I'm sorry. Seven what? I'm not sure I follow.
harrow: ...You've been talking to Mrs. Okafor. That poor woman. Grief does terrible things to the imagination. I'd be careful who you listen to in this neighborhood.
{do mem:harrow:seven; flag:harrowKnowsYouKnow=1}
@end

# hw2.no
harrow: Of course. Of course. The offer stands.
@end

# hw2.know
harrow: Do I? I know you were at a crime scene on Monday morning, which makes you a witness, or a suspect, or a ghost. I know you're wearing a coat that belongs to a dead man.
harrow: Beyond that, I'm a simple public servant. I'm here to help.
tenant: He means it, child. That's the dreadful part. Men like him always mean it.
@end

# hw2.govt
harrow: Everyone talks to the government. You just don't always know you're doing it. We're very good listeners.
@end

// =====================================================================
// HARROW · Night Three · in the waiting room at St. Jude's
// =====================================================================
# hw3.0
@focus harrow
> In the waiting room of St. Jude's, under the flickering strip light, between a drunk with a nosebleed and a woman with a baby asleep on her chest, Special Agent Harrow is reading a two-year-old copy of *Country Life* with every appearance of enjoyment.
harrow: Oh, hello. Fancy meeting you here. I'm waiting for the doctor. She's very busy. She's always very busy. It's one of the things I admire about her.
harrow: Sit. Sit. Nobody will notice. Nobody ever looks at anyone in a waiting room. It's the most private place in the world.
* Sit.  -> hw3.sit
* "Leave her alone, Harrow."  -> hw3.leave
* "I know about the basement."  -> hw3.basement {if seen:tr.0}

# hw3.sit
> You sit next to him. He turns a page. A photograph of a Cotswold manor house.
harrow: I grew up in a house like this. Well, the servants' wing. My mother was a cook. In Virginia, but they'd copied the English style. I used to look at the big rooms through the keyhole.
harrow: Then I went to war, twice, and came home and found out the world was much worse than I'd been told. You find that out too, don't you. In your line of work.
* "What did you find out?"  -> hw3.war
* "Why are you telling me this?"  -> hw3.why

# hw3.war
harrow: Fallujah, 2004. A building we cleared. In the basement, eleven civilians. Drained. Two little holes in each. The marines said dogs. The marines were very young.
harrow: Then a man came out of the dark at the back of the basement. Tall. Smiling. He walked through a squad of marines like a draught through a curtain. I emptied a magazine into him. He thanked me. He said it tickled.
harrow: I've been building a better magazine ever since.
pulse(5): Steady heart. Steady voice. But his hand on the magazine page has gone white at the knuckles.
{do mem:harrow:fallujah; flag:knowHarrowWar=1}
@next hw3.hub

# hw3.why
harrow: Because you'll understand. You were mortal on Sunday. You know what it's like to be the thing that gets eaten.
harrow: Join us. Not as a subject. As a consultant. Help us find the ones that should be found. The ones who drain eleven people in a basement. We'd never touch you.
@next hw3.hub

# hw3.leave
harrow: Leave her alone? She's my colleague. She's the most important scientist in this hemisphere and she's working in a free clinic for drunks because nobody else would fund her. I'm the only person in this city who's ever believed in Elena.
harrow: Ask her if she wants to be left alone. She'll say no. She hasn't got anywhere else to go.
@next hw3.hub

# hw3.basement
harrow: Do you? Then you know we're trying to save lives. Not end them. Every one of those volunteers was paid, fed, cared for. Some of them hadn't had a bed in years.
harrow: And seven of them died. Yes. I know their names. I know them better than you do. I read their files every night.
harrow: You know what else I know? Twenty-two minutes. Dani Okafor stood in the sun for twenty-two minutes. Nobody in human history had done that with your blood in their veins. Twenty-two minutes. That's not a tragedy. That's a beginning.
* "It's a tragedy and a beginning. That's the problem."  -> hw3.both {do lean:candour+1}
* "You're a murderer, Harrow."  -> hw3.murder

# hw3.both
harrow: ...That's very perceptive. That's more than Elena will admit.
{do mem:harrow:both}
@next hw3.hub

# hw3.murder
harrow: And you're a diablerist. We've both done terrible things for good reasons. You for your life. Me for everyone else's.
@next hw3.hub

# hw3.hub
* Get up and walk away.  -> hw3.bye

# hw3.bye
harrow: Do think about it. The consultancy. There's a pension.
{do flag:harrow3Done=1}
@leave harrow

// =====================================================================
// DR. ROSTOVA · Friday, on Platform 0, waiting to testify
// =====================================================================
# rx5.0 arc=rostova night=5 label="\"Doctor. Are you ready?\"" if=room:switchyard&actor:rostova
@focus rostova
> Rostova is standing at the edge of Platform 0 in her white coat, as far from the Court as she can get, with her hands in her pockets. Three hundred Kindred are pretending not to look at her. She knows exactly how many.
rostova: Ready. To stand in a chalk circle in front of everything I've spent six years trying to understand, and say I killed the man who came to me for help. Yes. Never been readier.
rostova: I keep thinking about Pasha. Nineteen. Leukaemia. I knew everything and none of it worked. And now I've finally found something that would have worked and I've used it to kill seven people and a Sheriff.
* "Pasha would want you to say it."  -> rx5.pasha
* "After tonight, whatever happens, you're free."  -> rx5.free
* "Do you want me to stand next to you?"  -> rx5.stand {do lean:mercy+1}

# rx5.pasha
rostova: Pasha would want me to have been a dermatologist. He'd want me to have married the boy from my lab and had three children and a dog. He'd want me to sleep.
rostova: But yes. He'd want me to say it.
@end

# rx5.free
rostova: Free. To do what? I'll never practice again. I'll never publish. They'll eat me afterwards, or Harrow will make me disappear, or the police will.
rostova: ...Free, though. That's a word. I haven't heard it applied to me since medical school.
@end

# rx5.stand
rostova: Next to me. In the circle.
> She looks at you. She looks at your hands. She's remembering something: a cot, a drip, a Russian novel.
rostova: You. Number eight. You'd stand next to me.
rostova: ...Yes. Please. Don't let go of my arm.
{do flag:rostovaArm=1; rel:rostova+2}
@end

// =====================================================================
// KEN PRUITT · Friday, on the cordon
// =====================================================================
# kp5.0 arc=kenpruitt night=5 label="\"Ken. How's the cordon?\"" if=room:alley&actor:kenpruitt
@focus kenpruitt
kenpruitt: Cold. Boring. Three grey vans, two squad cars, me and a radio and a thermos and a lot of men in sunglasses who won't tell me what we're guarding.
kenpruitt: There's something under the platform. Isn't there. Something they don't want anyone to get out of.
* "Your radio. When the lamps come on, tell me where it's dark."  -> kp5.radio
* "Go home, Ken. Tonight's not for you."  -> kp5.home
* "Leo's safe. Whatever happens."  -> kp5.leo {if leo:gone|flag:leoReturned}

# kp5.radio
kenpruitt: Grate nine. That's the one they haven't wired yet. I heard them arguing about it at ten. A cable's short. They're waiting for a spare from Virginia that didn't come.
kenpruitt: If it goes wrong, I'll say "nine". On channel four. Just "nine".
{do flag:kenNine=1}
@end

# kp5.home
kenpruitt: Home. I've got a flat with a cat that hates me and a TV that only gets the shopping channel.
kenpruitt: No. I'll stay. First time in twenty years I'm on a cordon for something that matters. Even if I don't know what.
@end

# kp5.leo
kenpruitt: Safe. Good. Good.
kenpruitt: He texted me. First time since Christmas 2019. He said: "uncle ken. thanks. also you were right about the act, it WAS a cry for help, but it's funnier now". I've read it forty times.
@end

// =====================================================================
// MARGO · Friday, on Platform 0
// =====================================================================
# mg5.0 arc=margo night=5 label="\"Margo. You came.\"" if=room:switchyard&actor:margo
@focus margo
> Margo is standing by a pillar in her best coat, which is navy and too tight, with her handbag clutched in front of her like a shield. She's brought the knitting. She isn't knitting.
margo: I came. I said I would. I'm sixty-three and I've never broken a promise to anyone except my father, and that was the other way round, he made me keep one.
margo: Look at them. All of them. In their good clothes. I've rendered for half of their families. I've signed for their dead. And not one of them knows my name.
* "After tonight, they'll know it."  -> mg5.know
* "You don't have to do this."  -> mg5.donthave
* "Thank you, Margo."  -> mg5.thanks

# mg5.know
margo: After tonight they'll want to put me in my own walk-in.
margo: ...But yes. They'll know it. Marguerite Kowalski. My father's name was on the shop for seventy years. Mine'll be on something, at least.
@end

# mg5.donthave
margo: I know. That's the point. My whole life I've done things because I had to. This one I'm doing because I want to. It's terrifying. It's the best I've felt since 1982.
@end

# mg5.thanks
margo: Don't thank me. Thank me after. If there's an after. I'll make you pierogi. You won't eat them. I'll make them anyway.
@end

// =====================================================================
// TEO · Friday, at the edge of the platform
// =====================================================================
# teo5.0 arc=teo night=5 label="\"Teo. You're here.\"" if=room:switchyard&actor:teo
@focus teo
teo: The whole union's here. Dutch made us wear our least ripped jeans. We're standing at the back where the Court can pretend we're furniture.
@gate flag:millerMetMateo ? teo5.met : teo5.notmet

# teo5.met
teo: She came. Ines. To the shop. Thursday. I stood in the door. I said sorry about the cigarettes. Then the light came round and I ran like an idiot.
teo: She texted Tariq's shop phone at six this morning. Tariq brought it to me on the platform. It said: "Sunday. Midnight. My flat. I'm cooking. Don't argue." I've never been so scared of anything.
@end

# teo5.notmet
teo: I keep thinking I'll go up the stairs afterwards and across the road to the Lucky Mart. Every night I think it. Every night I don't.
* "Tonight's the night to do things you're scared of."  -> teo5.go
* "There's time. She's not going anywhere."  -> teo5.time

# teo5.go
teo: ...Yeah. Yeah. If we're alive at dawn. I'll go. I'll actually cross the road.
{do flag:teoWillGo=1}
@end

# teo5.time
teo: Thirteen years and she hasn't gone anywhere. Yeah. I know. That's the scary part.
@end

// =====================================================================
// LISETTE · Friday, on the platform
// =====================================================================
# ls5.0 arc=lisette night=5 label="\"Lisette. Which way will you jump?\"" if=room:switchyard&actor:lisette
@focus lisette
lisette: Jump? Me? *Mon chou*, I never jump. I step. Very gracefully. Usually onto someone.
lisette: Tonight I'll stand behind Madame's chair, as always. If Madame falls, I'll be standing behind an empty chair. That's a very good place to stand.
@gate flag:lisetteAlly ? ls5.ally : ls5.not

# ls5.ally
lisette: But I'll be watching you. If you need a door opened, or a voice in the Court to say "yes, quite right", look for the red dress. I owe you a page. I always pay my pages.
@end

# ls5.not
lisette: We'll see who's left standing. I've seen a lot of these. They always end the same way: with fewer people.
@end

// =====================================================================
// CORAL · Friday
// =====================================================================
# co5.0 arc=coral night=5 label="\"Coral. You stayed home?\"" if=room:reliquary&!flag:coralHome
@focus coral
coral: No. I'm dancing. On my own. The floor's empty. Everyone's gone down to the platform. The DJ's playing to nobody. I'm dancing to nobody.
coral: It's the best night I've had here in three years. Nobody's looking at my elbows.
@end

// =====================================================================
// LUIS · after the bus
// =====================================================================
# lu4.0 arc=tariq night=4,5 label="\"Tariq, is that note for me?\"" if=flag:luisHome&room:luckymart prio=1
> You can't visit Pinewood Terrace from here; but Tariq has a message pinned by the till, in a woman's careful hand, addressed to "the pale one who brought my son home".
> *Luis sleeps all day and wakes at dusk. He eats my soup. He says the light from the windows hurts and so we have put up blankets. He says to tell you he found the door. He says to tell you it's blue. — Maria Ferreira.*
{do comp+2:The blue door}
@end

// =====================================================================
// WINTER · after waking
// =====================================================================
# wi4.0 arc=gideon night=4,5 label="\"Has Winter been in?\"" if=room:pawn&flag:winterAwake prio=4
@focus gideon
gideon: Been in? No. The first frost isn't for three weeks. She's a Wraith; she keeps to the calendar.
gideon: But there was a note. Under the door. This morning. In pencil on the back of a page torn from a star chart.
> *The lid on twelve sticks. Fix it. — W.*
gideon: Forty years and the first thing she says is a complaint about the lid. God, I've missed her.
{do rel:gideon+1}
@end
`,'c_more2');
