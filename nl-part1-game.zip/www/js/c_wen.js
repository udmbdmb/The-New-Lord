'use strict';
/* THE NEW LORD — "The Wall Behind the Golden Dragon": a very old man who drinks duck blood from a takeaway carton, and knows what it is to carry two people in one body */
(function(){const X=NL.EXTRAS,S_=NL.Script;
X.wen={n:'Old Wen',color:'#d8c8a0',role:'On the wall behind the Golden Dragon',spec:{face:{long:1.05,cheek:1.4,jaw:1.0},skin:[.8,.72,.58],hair:{style:'long',color:[.92,.92,.9]},coat:{color:[.2,.22,.25],length:.95,collar:true},shirt:[.75,.7,.6],eyes:[.5,.4,.3],eyeGlow:[.25,.2,.1],height:.9}};
NL.TASKS.s_wen={n:'Two in One Bowl',xp:70,cat:'side'};
NL.ITEMS.jadebead={n:'A Jade Bead on a Red Thread',slot:'pocket',mods:{rigor:1,echo:1},d:'Green, cloudy, very old, worn smooth by a thumb. Old Wen says it was carved in Hangzhou in the year the Mongols came. He says it\'s for holding when the other one in you is too loud.'};
S_.place({id:'dragonwall',name:'The Wall Behind the Golden Dragon',block:'A',sub:'The cook said an old man sits there. Tonight, for once, he is.',if:'night>=3&night<=5&flag:mapOK&flag:knowDuckMan&!flag:wenDone',node:'wn.0',min:6});
})();
NL.Script.add(String.raw`
# wn.0
> The alley behind the Golden Dragon. Steam from the kitchen vent. Bins. A low brick wall, and on it, sitting very straight with his hands on his knees, an old man in a long grey coat with white hair to his shoulders. On the wall beside him, a takeaway carton with a plastic lid and a straw.
> He's the oldest thing you have ever stood near. Older than the Magistrate. Older than the Ward. You feel it the way you'd feel a mountain behind you in the dark.
wen: Ah. The one with two in one bowl. Sit. Sit. The wall is wide and I am narrow.
* Sit on the wall.  -> wn.sit
* "Two in one bowl?"  -> wn.bowl
* Bow.  -> wn.bow

# wn.bow
> You bow. You don't know why. Your body knows something you don't.
wen: Ha. The Sovereign in you bows. He knows a bow is owed. You didn't, but he did. Sit, both of you.
tenant: (very quietly) ...I've heard of him. Everyone has. Nobody's met him. I thought he was a story they told neonates about the Song emperors.
@next wn.sit

# wn.bowl
wen: Two in one bowl. You, and the one you drank. Like two fish in a small bowl, swimming round and round, bumping. I can hear you both from here. Very noisy. Very sad.
@next wn.sit

# wn.sit
> You sit on the cold wall. He offers you the carton. You take it. Duck blood, cold, thin, from the morning delivery. It tastes like a photograph of food.
wen: The cook gives it to me. He is a kind man. He thinks I am a poor old fellow from the old country who likes a strange soup. I am a poor old fellow from the old country who likes a strange soup.
{do task:s_wen; note:s_wen|An old Kindred called Wen sits on the wall behind the Golden Dragon. He says he can hear you and the Tenant "like two fish in a small bowl".}
@next wn.hub

# wn.hub
* "How old are you?"  -> wn.old {once}
* "You said two fish in a bowl. Is there a way to live like this?"  -> wn.two {once}
* "Do you know the Prince?"  -> wn.prince {once}
* "What do you see when you look at me?"  -> wn.see {once}
* "Why are you here tonight? The cook said Sundays."  -> wn.why {once}
* Leave him to his soup.  -> wn.bye

# wn.old
wen: Old. When I was made, the Mongols had not yet come to Hangzhou. When they came, I walked out of the city in the night with nine others. Now there is one.
wen: I stopped counting the years when they stopped meaning anything. Now I count soups.
@next wn.hub

# wn.why
wen: Because on Friday something will happen under the platform, and I would like to be near, and not too near. Like watching a fire from across a river.
wen: And because I heard the two fish. I came to see if they would drown each other.
@next wn.hub

# wn.prince
wen: The lady on the hill. Yes. She came on a ship in 1871 with a tall thin man who never smiled. I was already here, washing shirts on Kerr Street for a laundry that did not ask questions.
wen: She came to see me once. In 1880. She asked if I wanted the city. I said no. She asked why. I said: because then I would have to look at it.
wen: She did not understand. I think now, after so long in the dark, she does.
{do mem:wen:prince}
@next wn.hub

# wn.see
> He looks at you for a long time. His eyes are very dark and very calm, like water at the bottom of a well.
wen: I see a young one, afraid, who is braver than it knows. I see an old one, proud, who is more afraid than it says.
wen: I see that you are each other's cage. And each other's door.
@next wn.hub

# wn.two
wen: A way. Hm.
wen: There are three ways to live with two in one bowl. Only three. I have seen all of them, in seven hundred years.
wen: The first: one fish eats the other. That is quick. It is the way of your Sovereigns. The strong one is left, and the bowl is quiet, and the strong one is lonely forever.
wen: The second: you build a wall down the middle of the bowl. Each fish on its side. That is the way of the careful ones. It works for a while. Then the wall breaks.
wen: The third.
> He takes a sip from the straw. He waits. He's enjoying himself.
* "What's the third?"  -> wn.third

# wn.third
wen: The third: you stop being two fish. You become the water.
wen: Not one fish. Not two. The water both fish swim in. Then there is nothing to fight about. Then the bowl is very large.
tenant: ...That's nonsense. That's a fortune cookie.
wen: (smiling, to the voice in your blood) Yes, Sheriff. It is also true. Most true things fit in a fortune cookie. That is why nobody believes them.
* "Teach me."  -> wn.teach
* "I don't want to be the water. I want to be me."  -> wn.me
* "He's right. It's nonsense."  -> wn.nonsense

# wn.teach
wen: Teach. Ha. I cannot teach you. I can show you. Once. Then it is yours to do, or not.
wen: Close your eyes. Both of you. No, Sheriff, you too, I can see you peeking.
> You close your eyes. On the cold wall, in the steam from the kitchen, with bins and rain and an old man's breathing.
@next wn.show

# wn.show
wen: Now. Do not listen to him. Do not listen to yourself. Listen to what you are both listening to.
> At first, nothing. The two of you, bumping, the way you always do. His fear, your fear, his pride, your hunger.
> And then, underneath it: the rain on the bins. The kitchen fan. Someone laughing two streets away. A train on the viaduct. The river. The whole Ward, breathing, all at once, the way it was breathing before either of you was born and will be breathing after.
> For one moment, you aren't you, and he isn't him. You're just the thing that hears it.
? echo 10 "Stay in it. Stay in the listening."  -> wn.water | wn.lost {id wn_echo}

# wn.water
> You stay. One breath. Two. Ten. You don't know how long. When you open your eyes, the old man is smiling, and the voice in your blood is very quiet, not gone, just quiet, the way someone is quiet when they're watching a sunset with you.
tenant: ...Oh. Oh. I see. I see what he means. I'd never... in two hundred years I never once just *listened*.
wen: There. The water. You will lose it in a minute. That is fine. Now you know where it is. You can go back.
> He takes a bead from his pocket, green jade on a red thread, and presses it into your palm.
wen: For holding. When the fish are loud. Hangzhou, before the Mongols. Do not lose it, I only have three.
{do give:jadebead; flag:wenWater=1; comp+4:The water; task:s_wen=done; xp:70:Two in One Bowl; flag:wenDone=1}
@end

# wn.lost
> You try. You lose it almost at once. His fear comes up, and yours, and the two of you are bumping again, round and round.
wen: Ha. Yes. Nobody does it the first time. I took three hundred years.
wen: Come back. Any night. I am on the wall more often than the cook thinks.
{do comp+1}
@next wn.hub

# wn.me
wen: You. Hm. And which one is "you"? The one who woke in the freezer? The one who was a mortal before? The one who will be Sheriff, or ash, by Saturday?
wen: All of them are you. And he is in all of them now. That is not a disaster. That is just Tuesday, for people like us.
@next wn.hub

# wn.nonsense
wen: (laughing, delighted) Yes! Good! Doubt is very healthy. Doubt is how you know you still have a mind. When you stop doubting, come and see me again, and I will be worried.
@next wn.hub

# wn.bye
wen: Go well. Both of you. Try not to drown each other before Friday. It would be a great waste of a bowl.
{do flag:wenMet=1}
@end
`,'c_wen');
