'use strict';
/* THE NEW LORD — Act II · Night Two (Tuesday): "Shadows in Elysium" — main story */
(function(){
const NL=window.NL,G=NL.G,A=NL.Audio;const {N,ENC,L,T,O,C,H,STORY}=NL.DSL;const {pushPop,pushNpc,pushEnter}=NL.Act;
const Wd=()=>G.Wd;
const leoAlive=S=>!S.flags.leoDead;
const tape=S=>S.night>=2&&(S.flags.leoDead||['attack','shot','found','lose'].includes(S.flags.calloOutcome)||S.heat>=2);
NL.Act.tape=tape;

NL.EXTRAS.thug={n:'Syndicate man',color:'#e08070',role:'Red Syndicate',spec:{face:{wide:1.06,jaw:0.5,brow:1.3},skin:[.72,.56,.48],hair:{style:'shaved',color:[.1,.08,.08]},shirt:[.15,.12,.12],pants:[.1,.1,.1],coat:{color:[.18,.1,.08],length:.3,collar:true},height:1.04,width:1.15}};
NL.EXTRAS.prophet={n:'The Prophet',color:'#d8d0a0',role:'Platform 0',spec:{face:{long:1.08,jaw:0.9,nose:1.3,brow:1.4},skin:[.7,.55,.45],hair:{style:'long',color:[.7,.68,.62]},mustache:[.7,.68,.62],shirt:[.3,.26,.2],coat:{color:[.28,.24,.18],length:.8,collar:false},pants:[.2,.18,.15]}};

/* ---------- map ---------- */
NL.PLACES.push(
  {id:'rookery',name:'The Rookery',block:'C',room:'rookery',rooms:['apt'],spawn:{x:1.5,z:5.0,ry:0.6},sub:'A tenement on Halloran Street. Leo lives on three. There\'s a roof.'},
  {id:'yard',name:'Platform 0',block:'D',room:'switchyard',rooms:['shrine'],spawn:{x:6.5,z:1.4,ry:2.6},sub:'The Sunken Switchyard. Red Syndicate territory.',open:S=>S.night>=2,locked:S=>null},
  {id:'lantern',name:'The Lantern Room',block:'B',room:null,sub:'Tuesday open mic, 10 PM. Leo\'s set.',open:S=>S.night===2&&leoAlive(S)&&!S.flags.lanternDone&&!S.flags.leoGoneTown,locked:S=>S.time<45?'Doors open at 10 PM.':S.time>180?'It\'s over. Everyone\'s gone home.':null,before:async(S,G)=>{NL.Camp.closeMap();G.tick(14);await G.talk('lan.0');return false;}}
);

/* ---------- the night ---------- */
NL.NIGHTS[2]={title:'Act II · Shadows in Elysium',sub:'The Marrow Ward',
  heatAdd:S=>0,
  canSleep:S=>S.time>=300||((S.tasks.malakor==='done')&&(S.tasks.soot==='done')&&S.time>=180),
  endTitle:'The mark on the threshold',
  endLine:S=>`Somebody painted a sign across your door in blood while you were out. ${S.flags.readMark?'"HE IS COMING." And under it, a little drawing of a dog.':'You can\'t read it. You know it\'s for you.'}`,
  async start(G,S,hav){const h=NL.Camp.havenRoom(hav);
    if(tape(S))S.flags.tape=1;
    await G.enterRoom(h.room,h.spawn,{instant:true,noEnter:true});
    G.cine(true);A.music('night');await G.wait(.6);
    const wake={freezer:[T('You wake in the walk-in with frost in your eyelashes and the sound of voices outside the steel door. Men\'s voices. A camera shutter.'),L('stagecraft','Police. Don\'t move. Don\'t breathe. You\'re good at not breathing.',{if:S=>S.flags.tape}),T('Then nothing. They go. A strip of yellow tape flutters across the back door when you finally push it open.',{if:S=>S.flags.tape})],
      pawn:[T('Two knocks on the lid. Then Gideon\'s voice, muffled: "Sunset was eight minutes ago. Your box, your business. Rent\'s due again by four."'),L('nostalgia','Somebody woke you up. When did somebody last wake you up?')],
      crypt:[T('You wake on red silk. On the coffin\'s inner lid, someone has pinned a card in violet ink: *Wear this tonight. Be seen. The Ward must believe the Sheriff is merely busy. — S.* Beneath it, a porcelain half-mask with a gold seam.',{do:(S,G)=>{if(!G.has('porcelain'))G.give('porcelain');}})],
      rookery:[T('Pigeons. Rain on tarpaulin. The sniper nest smells of wet concrete and old gun oil, and the city below is coming on light by light.'),L('sundial','Up. Up. The sun is gone. You have eight hours. Fewer than yesterday.')]};
    await G.say((wake[hav]||[T('You wake.')]).concat([
      L('tenant','Fourteen. Drawer fourteen. I had a key to it. I gave the key to someone who listens to everything. The old woman. Soot. Under the Switchyard.',{if:S=>S.flags.code0414||S.flags.drawer14,do:(S,G)=>{G.task('soot');S.quests.note_soot='Mother Soot, under Platform 0, has the key to drawer 14. You gave it to her Monday morning, under a blood contract.';G.meet('soot');G.fact('soot','key');}}),
      L('sundial','Tuesday. Three nights to the Tribunal.')]));
    G.cine(false);
    setTimeout(()=>G.text('M.','The Sheriff\'s little helper. Come down to Platform 0 tonight. We should talk about what you left in the freezer. Come alone. — M.'),5000);
    S.flags.mText=1;G.task('malakor');S.quests.note_malakor='"M." wants to talk on Platform 0, under the Sunken Switchyard.';
    if(S.flags.tape){G.task('crimescene');S.quests.note_crimescene='Police tape on Kowalski\'s back door. Detective Miller is working the scene on Ferrier Lane.';}
    else setTimeout(()=>{G.task('crimescene');S.quests.note_crimescene='Detective Miller buys coffee at the Lucky Mart around 2 AM.';},9000);
    if(S.flags.sevAlly)setTimeout(()=>G.text('S.','Tonight, little hound: be seen. Wear the mask. And find me the package.'),22000);
    G.autosave();},
  async cliff(G,S,hav){
    await G.say([T('You come back to your haven in the last grey hour before dawn, and stop at the threshold.'),
      T('Across it, painted in blood, still tacky: a shape like an eye with a line through it, and under it, a hasty little drawing of a dog.'),
      L('pedigree','An Unseen Mark. Wraith script. It is not a threat. It is a *warning*, from someone who listens to the pipes.',{pass:7}),
      L('tenant','A dog. She means Valko. My Valko. Oh, Séverine, you didn\'t.',{do:(S,G)=>{S.flags.readMark=1;S.flags.valkoComing=1;G.meet('valko');G.fact('valko','loyal');}}),
      T('You read it without trying: HE IS COMING. SHE TOLD HIM WHO WEARS HIS MASTER.',{if:S=>S.clan==='wraiths'}),
      L('web','Séverine told Vane\'s Hound that Vane is dead, and who drank him. Tomorrow, something with a very good nose comes looking for you.',{if:S=>S.flags.sevKnows||S.flags.sevEnemy}),
      L('web','Séverine summoned Vane\'s Hound. She doesn\'t know who you are yet. He will.',{if:S=>!(S.flags.sevKnows||S.flags.sevEnemy)}),
      L('sundial','Sleep. Tomorrow you\'ll need to be fast.')]);}
};

/* =====================================================================
   SCENE 2.1 · Miller's crime scene (Ferrier Lane) or the Lucky Mart at 2 AM
   ===================================================================== */
const millerLane=S=>S.night===2&&S.flags.tape&&S.time<200&&!S.flags.m2done;
const millerMart=S=>S.night===2&&S.time>=200&&S.time<330&&!S.flags.m2done;
pushPop('alley',(S,G)=>{if(millerLane(S)){G.addActor('miller',NL.CHARS.miller.spec,{x:3.0,z:1.6,ry:0.7,breathes:true,pose:'hold'});G.addActor('harrow',NL.CHARS.harrow.spec,{x:3.9,z:1.4,ry:-0.9,breathes:true,pose:'arms'});}});
pushPop('luckymart',(S,G)=>{if(millerMart(S)){G.addActor('miller',NL.CHARS.miller.spec,{x:2.7,z:4.0,ry:-1.6,breathes:true,pose:'hold'});}});
pushNpc('alley',(S,G)=>[G.actor('miller')?{id:'miller',actor:'miller',label:()=>S.dos.miller?'Det. Miller':'Detective'}:null,G.actor('harrow')?{id:'harrow',actor:'harrow',label:()=>S.dos.harrow?'Agent Harrow':'Man in sunglasses'}:null].filter(Boolean));
pushNpc('luckymart',(S,G)=>G.actor('miller')?{id:'miller',actor:'miller',label:()=>S.dos.miller?'Det. Miller':'Detective'}:null);
const alB=NL.ROOMS.alley.build;NL.ROOMS.alley.build=function(rb,S){alB.call(this,rb,S);if(S.flags.tape&&S.night>=2&&S.night<4){const m=NL.mats();const Y=NL.M([.95,.8,.1],{spec:.3,mottle:.1});
  rb.box([1.9,1.0,0.12],[3.1,1.06,0.14],Y,{noDepth:true});rb.part(NL.Geo.box(1.4,0.06,0.02),NL.M4.trs([2.5,1.4,0.15],[0,0,0.25]),Y,{noDepth:true});}};
NL.ROOMS.alley.inter.push({id:'eavesdrop',label:'Shadow by the dumpster',at:[5.0,1.0,1.4],box:[4.4,0,1.2,5.8,1.3,1.6],stand:[5.6,1.8],face:[4,1.5],if:S=>millerLane(S)&&!S.flags.overheard});
H.use.eavesdrop=async(S,G)=>G.talk('m2.spy');
N['m2.spy']={lines:[T('The shadow of the dumpster is deep and wet and smells of offcuts. From here you can hear them over the rain.')],
  opts:[C('echo',9,'Listen. Just listen.','m2.spyOk','m2.spyNo',{id:'m2_spy'}),O('Veil of Dust: go still and vanish.','m2.spyOk',{ab:'veil'}),O('Panopticon: let the pipes carry their voices.','m2.spyOk',{ab:'mark',t2:true}),O('Step out.',null,{end:true,leave:true})]};
N['m2.spyOk']={lines:[L('harrow','—the butcher shop is a dead end, Detective. Literally. Wrap it up. Missing kid turned up. Mother\'s happy. Write "runaway".'),
  L('miller','Seven, Harrow. Seven people from four blocks. All of them on the free-clinic list at St. Jude\'s. That\'s not runaways, that\'s a *list*.'),
  L('harrow','That\'s a coincidence, and the task force would appreciate it if you stopped saying "list". The task force would appreciate a lot of things.'),
  L('miller','What task force? You still haven\'t told me what LANTERN stands for.'),
  L('harrow','Light. It stands for light. Go home, Ines.'),
  L('web','LANTERN. The free clinic. Seven names on a list. Harrow wants the case dead, and Miller won\'t let it die.',{pass:5,do:(S,G)=>{S.flags.overheard=1;G.fact('miller','handler');G.meet('harrow');G.fact('harrow','name');S.flags.knowsLantern=1;S.flags.clinicList=1;G.xp(25,'Eavesdropping');}}),
  L('sundial','He said "light" like a man who has a lot of it in his car.')],end:true};
N['m2.spyNo']={lines:[T('You catch "task force", and "St. Jude\'s", and then the rain gets heavier and their voices go.'),L('echo','Get closer, or come back.')],end:true};
H.use.harrow=async(S,G)=>G.talk('h2.0');
N['h2.0']={enter:(S,G)=>{G.focus(['you','harrow'],.8);G.look('harrow','you');},lines:[
  T('A man in a grey suit and sunglasses, at night, in the rain, smiling slightly at nothing. He has a long flashlight clipped to his belt like a baton.'),
  L('harrow','Can I help you, friend? This is a police matter.'),
  L('sundial','That flashlight. That flashlight is not a flashlight. It has a lens like a jeweller\'s eye and a battery pack the size of a brick.',{pass:6}),
  L('pulse','He isn\'t looking at your face. He\'s looking at your *eyes*, and he\'s smiling more.',{pass:9}),
  L('harrow','Special Agent Harrow. Federal liaison to the Ninth. And you are?',{do:(S,G)=>{G.meet('harrow');G.fact('harrow','name');}})],
  opts:[C('stagecraft',11,'"Night manager at the Lucky Mart. Just being nosy."','h2.okay','h2.knows',{id:'h2_stg',mod:(S,G)=>G.equipped('aviators')?1:0}),
    O('Listen to the thing he\'s loudest about not saying.','h2.cold',{ab:'coldread',once:true}),
    O('Taste the air near him.','h2.taste',{ab:'vintage',once:true}),
    O('"Nobody. Goodnight."',null,{end:true,leave:true})]};
N['h2.okay']={lines:[L('harrow','Of course you are. Run along, then.'),L('pulse','He doesn\'t believe you. He just isn\'t ready yet.')],end:true};
N['h2.knows']={lines:[L('harrow','No you\'re not.'),T('He says it pleasantly. He doesn\'t take the flashlight off his belt. He touches it, though, the way some men touch a wedding ring.'),L('harrow','I\'ll see you around, friend.',{do:(S,G)=>{S.flags.harrowMarked=1;G.heat(1);}})],end:true};
N['h2.cold']={lines:[T('His loudest silence is very simple: a list of names on a clipboard, and a column headed CURED and a column headed ASH, and the second column is much longer.'),L('web','He kills vampires. For a living. With a budget.',{do:(S,G)=>{G.fact('harrow','lantern');S.flags.knowsLantern=1;}})],next:'h2.0'};
N['h2.taste']={lines:[T('Gun oil. Hospital disinfectant. Ozone, sharp as a struck match. And on his cuff, a single fleck of dried blood that is old and black and *not his*: vampire. Recent.'),L('autopsy','He was close to a vampire when it died. Very close. Within the week.',{do:S=>S.flags.harrowVitae=1})],next:'h2.0'};

H.use.miller=async(S,G)=>G.talk(S.flags.m2met?'m2.hub':'m2.0');
N['m2.0']={enter:(S,G)=>{G.focus(['you','miller'],.8);G.look('miller','you');G.look('you','miller');},lines:[
  L('miller',S=>S.flags.calloOutcome==='win'||S.flags.calloOutcome==='leo'?'Well, well. The night shift.':S.flags.calloOutcome?'You.':'Can I help you?'),
  L('miller','You were in the butcher\'s last night. Don\'t say you weren\'t; I remember faces. It\'s most of my job.',{if:S=>S.flags.calloOutcome&&!['unseen','dominated'].includes(S.flags.calloOutcome)}),
  L('miller','...Have we met? I\'ve got the weirdest feeling I\'ve already asked you something.',{if:S=>['unseen','dominated'].includes(S.flags.calloOutcome)}),
  L('miller','Wait. *Wait.* The evidence cage. Thursdays. You took your coffee black with one sugar and you never once said thank you. They told me you died.',{if:S=>S.past==='clerk',do:(S,G)=>{G.fact('miller','clerk');G.rel('miller',1);}}),
  T(null,{do:(S,G)=>{S.flags.m2met=1;G.meet('miller');G.fact('miller','name');}})],next:'m2.hub'};
N['m2.hub']={opts:[
  O('"What happened here?"','m2.what',{once:true,if:S=>S.flags.tape&&S.room==='alley'}),
  O('"Find anyone yet? Any of the seven?"','m2.seven',{once:true}),
  O('"Who\'s the man in the sunglasses?"','m2.harrow',{once:true,if:S=>S.room==='alley'}),
  C('gutter',10,'Steer her: "Kids on the Strip say it\'s the Rookery Boys. Organ thefts. Look at them."','m2.gang','m2.steerNo',{id:'m2_gang',once:'m2_steer'}),
  C('web',10,'Steer her: "A chop-shop under the Switchyard builds custom weapons. The Red Syndicate. Start there."','m2.syn','m2.steerNo',{id:'m2_syn',once:'m2_steer',mod:(S,G)=>G.has('invoice')?3:0}),
  O('"You were close to finding them, before. Ray Dunleavy."','m2.ray',{once:true,if:S=>S.dos.miller&&S.dos.miller.facts.includes('partner')}),
  C('gutter',11,'While she talks, lift the case file from her coat pocket.','m2.lift','m2.liftNo',{id:'m2_lift',if:(S,G)=>!G.has('casefile')&&S.flags.sootHeists,once:'m2_lift'}),
  O('Bone-Key: fold your fingers thin and slip the file out of her pocket.','m2.lift',{ab:'bonekey',if:(S,G)=>!G.has('casefile')&&S.flags.sootHeists,once:'m2_lift2'}),
  O('Bad Luck Charm: make her drop everything.','m2.lift',{ab:'badluck',if:(S,G)=>!G.has('casefile')&&S.flags.sootHeists,once:'m2_lift3'}),
  O('"Goodnight, Detective."','m2.bye')]};
N['m2.what']={lines:[L('miller','Somebody called in screaming from the Kowalski\'s walk-in at six this morning. By the time we got here: nobody. A lot of grey dust in the freezer that the lab says is "consistent with cremated remains". And a meat hook with handcuff marks on it.'),
  L('miller','And blood. Somebody young.',{if:S=>S.flags.leoDead}),
  L('pulse','She looks at you when she says "somebody young". She looks at your mouth.',{if:S=>S.flags.leoDead,pass:7}),
  L('miller','Margo Kowalski\'s gone. Shop shut, flat empty, car gone. Sixty-three years old and she runs like a teenager.',{do:(S,G)=>{S.flags.margoGone=1;G.meet('margo');}})],next:'m2.hub'};
N['m2.seven']={lines:[L('miller','No. But I found the thing they had in common. All seven were on the free-clinic register at St. Jude\'s. Every one. Dr. Rostova\'s list.',{do:(S,G)=>{G.fact('miller','seven');S.flags.clinicList=1;G.fact('rostova','why');}}),
  L('miller','So now I\'ve got a federal babysitter telling me to write "runaway", and a doctor who won\'t give me her patient files, and a missing butcher. And I\'ve got you.'),
  L('web','The seven missing went through Rostova\'s clinic. She sells blood to vampires. She drives a white Volvo. She was outside Kowalski\'s at ten past four.',{if:S=>S.flags.volvo||S.flags.volvoHers,pass:5})],next:'m2.hub'};
N['m2.harrow']={lines:[L('miller','Harrow. "Federal liaison." Turned up the day after the third disappearance with a letter from a deputy commissioner and a flashlight he never turns on.'),L('miller','He keeps asking me if I\'ve noticed anyone who "doesn\'t blink". What kind of question is that?',{do:(S,G)=>G.fact('miller','handler')}),L('stagecraft','Blink. Blink now. Twice.')],next:'m2.hub'};
N['m2.gang']={lines:[L('miller','The Rookery Boys? They\'re teenagers who steal catalytic converters.'),L('miller','...Although. Organ thefts. Huh. I could lean on them. It\'d get Harrow off my back for a day.'),L('web','You just sent a decent cop after the wrong kids. She\'ll be busy for days. That might keep her alive.',{do:(S,G)=>{S.flags.millerTheory='gang';G.rel('miller',-1);G.xp(15,'Misdirection');}})],next:'m2.hub'};
N['m2.syn']={lines:[L('miller','The Switchyard? That\'s Syndicate ground. Nobody goes down there without a SWAT team and a priest.'),L('miller','Custom weapons. For who?'),L('you','"For whoever paid for what was used in that freezer."'),
  L('miller','...Okay. Okay. I\'ll pull the files on the Switchyard. Quietly.',{do:(S,G)=>{S.flags.millerTheory='syndicate';G.rel('miller',1);G.xp(15,'A lead');}}),L('tenant','You have just aimed a detective at Malakor. He will take that personally.')],next:'m2.hub'};
N['m2.steerNo']={lines:[L('miller','Uh-huh. And how would a night clerk know that?'),L('pulse','Too much, too fast. She\'s writing it down. Not the lead. *You.*',{do:(S,G)=>{G.heat(1);G.rel('miller',-1);}})],next:'m2.hub'};
N['m2.ray']={lines:[L('miller','...How do you know about Ray?'),L('miller','He found something in 2019. He wouldn\'t tell me what. He said "it\'s bigger than the Ninth, Ines". Two days later, a mugging. Three stab wounds and his wallet still in his pocket.'),
  L('miller','Nobody mugs a cop and leaves the wallet.',{do:(S,G)=>{G.task('s_cold');S.quests.note_s_cold='Ray Dunleavy, Miller\'s partner, was killed in 2019 after he "found something". Find what he found and get it to her without breaking the Masquerade.';}}),
  L('web','"Bigger than the Ninth." Federal. LANTERN. Harrow.',{if:S=>S.flags.knowsLantern})],next:'m2.hub'};
N['m2.lift']={lines:[T('A manila folder, coffee-ringed, slides out of her coat and into yours. She doesn\'t notice. She\'s busy being tired.',{do:(S,G)=>{G.give('casefile');S.flags.heist_file=1;G.xp(20,'Sleight of hand');}}),L('pulse','She\'ll miss it at four in the morning and think she left it on the bus. She\'ll cry a little. Then she\'ll start again from memory.')],next:'m2.hub'};
N['m2.liftNo']={lines:[L('miller','Are you — are you trying to pick my pocket? Seriously? I\'m a cop.'),L('gutter','Too slow. She caught your wrist. She let it go, which is worse.',{do:(S,G)=>{G.heat(1);G.rel('miller',-2);}})],next:'m2.hub'};
N['m2.bye']={lines:[L('miller','Stay out of trouble. Or at least stay out of mine.',{do:(S,G)=>{S.flags.m2done=1;G.task('crimescene','done');}})],cs:async(G,S)=>{G.dlgHide();if(S.room==='alley'){const w=G.walk('miller',9.6,3);G.walk('harrow',9.6,3.4);await w;G.removeActor('miller');G.removeActor('harrow');}},end:true};

/* =====================================================================
   SCENE 2.2 · Platform 0: Malakor
   ===================================================================== */
pushPop('switchyard',(S,G)=>{
  if(!S.flags.malakorDead&&!(S.night>=4&&S.flags.malakorGone))G.addActor('malakor',NL.CHARS.malakor.spec,{x:8.6,z:3.1,ry:-0.6,breathes:true,pose:'arms'});
  if(!S.flags.genDead||S.night<3){G.addActor('thug1',NL.EXTRAS.thug.spec,{x:6.4,z:2.0,ry:-1.2,breathes:true,pose:'arms'});G.addActor('thug2',Object.assign({},NL.EXTRAS.thug.spec,{skin:[.45,.32,.26],hair:{style:'crop',color:[.06,.05,.05]}}),{x:10.2,z:4.6,ry:-2.5,breathes:true,pose:'lean'});}
  if(!S.flags.prophetDone)G.addActor('prophet',NL.EXTRAS.prophet.spec,{x:1.6,z:2.3,ry:1.4,breathes:true,pose:'sit'});});
pushNpc('switchyard',(S,G)=>[G.actor('malakor')?{id:'malakor',actor:'malakor',label:()=>S.dos.malakor?'Malakor':'The Butcher'}:null,G.actor('prophet')?{id:'prophet',actor:'prophet',label:'The Prophet'}:null].filter(Boolean));
pushEnter('switchyard',async(S,G)=>{A.music('dread');if(!S.flags.enteredYard){S.flags.enteredYard=1;
  await G.say([T('Platform 0 was built in 1911 for a line that never opened. Malakor\'s people opened it anyway. A car hangs on a hydraulic lift like a carcass. Somebody is welding. The generator thuds like a second heart.'),
    L('osmosis','Old blood in the drains. Vampire blood. A lot of it, over a lot of years.',{pass:7}),
    L('abattoir','Bone saws. Rib spreaders. A surgical table under a work light. This is a body shop, and the cars are a hobby.',{pass:6}),
    L('tenant','Malakor. Red Syndicate. I have arrested him twice and paid him four times. Mind your fingers.')]);}});
H.barks.switchyard=[{id:'sy_lift',s:'frenzy',at:[8.8,1.5,1.6],r:2,t:'Drop the car on someone. Go on. Any one.'},{id:'sy_tracks',s:'sundial',at:[6,0,5.4],r:2,t:'The tunnels run under the whole Ward. Somewhere down there, a grate looks up at the sky.'}];
H.use.malakor=async(S,G)=>G.talk(S.flags.malakorTalked?'mk.hub':'mk.0');
N['mk.0']={enter:(S,G)=>{G.focus(['you','malakor'],.8);G.look('malakor','you');G.look('you','malakor');},lines:[
  T('He is very big and very still, in a leather apron black with old oil and older blood. His face is handsome in a way that looks deliberate, like a sculpture that went to art school. The seams are almost invisible. Almost.'),
  L('malakor','There it is. The little diablerist. You *reek* of him. You know that? Everyone in the Ward can smell Absalom Vane walking around in borrowed shoes.'),
  L('pedigree','Malakor. A Butcher. Boss of the Red Syndicate. He has rebuilt his own face eleven times and kept the twelfth.',{pass:6,do:(S,G)=>{G.meet('malakor');G.fact('malakor','name');S.flags.malakorTalked=1;}}),
  L('malakor','Sit. Or don\'t. Let\'s talk about what you owe me.')],next:'mk.start'};
N['mk.start']={enc:'butcher',win:'mk.win',lose:'mk.lose'};
ENC.butcher={title:'THE BUTCHER',sub:'Malakor · the Red Syndicate',music:'dread',after:'dread',
  prog:{name:'Leverage',max:6,color:'#e2c27e'},threat:{name:'His patience',max:7,color:'#e06050'},
  focus:G=>G.focus(['you','malakor'],.7),
  start(S,G){let t=1;if(S.flags.millerTheory==='syndicate')t+=1;if(S.flags.genDead)t+=2;if(S.clan==='butchers')t-=1;return {prog:0,threat:Math.max(0,t)};},
  intro:[L('malakor','Absalom came to me Sunday night with you on his heels like a puppy. He collected a package that came in off a boat. Then he went and got himself killed in a meat locker. And now you\'re here. So.')],
  round(st,S,G){const Q=[
    ()=>({lines:[L('malakor','Why should I talk to you at all? You\'re nobody. Literally. Nobody knows your name, not even you.')],threat:1}),
    ()=>({lines:[L('malakor','People think I killed him. People are very stupid. If I wanted Absalom dead I would have done it in 1990, and better.')]}),
    ()=>({lines:[T('He picks up a bone saw from the bench and turns it over in his hands, admiring it.'),L('malakor','Careful how you accuse me, neonate. Men who accuse me become *inventory*.')],threat:1}),
    ()=>({lines:[L('malakor','Last chance. Give me a reason.')]})];return st.round<Q.length?Q[st.round]():null;},
  moves(st,S,G){const r=st.round,M=[];
    M.push(C('autopsy',10,'"He died kneeling, facing the door. Burned in a line from the front. That\'s not fire. That\'s a lance. A surgical UV lance. Who builds those in this Ward?"',null,null,{id:'mk_aut',once:'mk_aut',mod:S=>S.flags.ashSearched?2:0,ok:(st,S,G)=>{st.prog+=3;st.lance=true;return [T('The bone saw stops turning.'),L('malakor','...You looked at the ash. Good. Nobody looks at the ash.')];},no:st=>{st.threat+=1;return [L('malakor','A guess. Bad one.')];}}));
    M.push(C('web',10,'"A long black case out of the clinic. A long case into his car. You built one of them."',null,null,{id:'mk_web',once:'mk_web',mod:S=>S.flags.rifleBag?2:0,ok:st=>{st.prog+=2;st.lance=true;return [L('malakor','Two cases. You\'ve been listening to drunks.')];},no:st=>{st.threat+=1;return [L('malakor','You\'re making shapes in the clouds.')];}}));
    M.push(C('gutter',9,'Talk shop. "Nice lift. Hydraulics from the old ferry terminal?"',null,null,{id:'mk_gut'+r,ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [L('malakor','...Ferry terminal. Yes. You have an eye.')];},no:st=>{st.threat+=1;return [L('malakor','Don\'t flatter my machinery. It knows when you\'re lying.')];}}));
    M.push(C('apex',11,'"I have his blood, Butcher. All of it. Mind your tone."',null,null,{id:'mk_apex'+r,mod:(S,G)=>G.equipped('signet')?2:0,ok:st=>{st.prog+=2;st.threat+=1;return [T('Somewhere behind you, one of his men steps back without meaning to.'),L('malakor','...Ha. There he is.')];},no:st=>{st.threat+=2;return [L('malakor','No. You have his *smell*. That is not the same thing.')];}}));
    if(r>=1)M.push(C('rigor',10,'Let him threaten. Don\'t move a muscle.',null,null,{id:'mk_rig'+r,ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [L('malakor','Still as a corpse. Fine. I like a customer who doesn\'t fidget.')];},no:st=>{st.threat+=1;return [L('malakor','You flinched.')];}}));
    if(S.clan==='butchers')M.push({t:'"We\'re the same blood, you and I. Cut the theatre."',once:'mk_kin',ok:st=>{st.prog+=2;return [L('malakor','Kin. Of course. You walk like one of us. You hold your hands like you know where the joints are.')];}});
    const ab=(id,t,fn,extra)=>M.push(Object.assign({t,ab:id,ok:fn},extra||{}));
    if(!st.cold)ab('coldread','Hear the thing he\'s loudest about not saying.',(st,S,G)=>{st.cold=true;st.prog+=2;st.lance=true;return [T('His loudest silence is a woman\'s hands in white gloves taking a long case from his, and his own voice saying *what\'s it for, doctor?* and her not answering.')];});
    if(!st.blue)ab('blueblood','Feel who owes him.',(st,S,G)=>{st.blue=true;st.prog+=2;S.flags.sevOwesMalakor=1;return [T('Debts hang off him like meat on a rail. The heaviest, sweetest, newest one runs straight up to the VIP crypt under Club Reliquary.'),L('web','Séverine owes him. For something expensive. Paid for Sunday.')];});
    ab('splinter','Splinter: plant a fear of his own mirror.',(st)=>{st.prog+=2;st.threat+=1;return [T('You slip a sliver into him: his face, in the mirror, coming apart at the seams. He touches his jaw before he can stop himself.'),L('malakor','...Don\'t do that again.')];},{once:'mk_spl'});
    ab('boil','Boil the Vein: warm his blood until he sweats.',(st)=>{st.prog+=2;st.threat+=2;return [T('Butcher blood doesn\'t boil easily. It simmers. He grins through it.'),L('malakor','Ooh. Spicy.')];},{once:'mk_boil'});
    ab('siren','Siren\'s Pitch: "Did you kill Absalom Vane?"',(st)=>{st.prog+=2;st.lance=true;return [L('malakor','No. I *built* what killed him. There is a difference and I would like it on my headstone.')];},{once:'mk_siren'});
    if(G.has('polaroids'))M.push({t:'Lay one of the 1978 Polaroids on his bench.',once:'mk_pol',ok:(st,S,G)=>{st.prog+=3;return [T('He looks at it for a long time. Then he laughs, a big, delighted, horrible laugh.'),L('malakor','Oh, Séverine. Oh, you careless *girl*.')];}});
    M.push(C('frenzy',12,'Put him through the car.',null,null,{id:'mk_fr',red:true,ok:(st,S,G)=>{st.prog+=3;st.threat+=3;return [T('You hit him so hard the lift shudders and the car swings on its arms. He gets up laughing, jaw at the wrong angle, and pushes it back into place with his palm.'),L('malakor','*There* he is!')];},no:st=>{st.threat+=4;return [T('He catches your fist in his hand like a ball. His fingers are stronger than bone has any right to be.')];}}));
    return M;},
  decide(st){return (st.prog>=4)?'win':'lose';},
  outro(r,st,S,G){S.flags.malakorOut=r;return [];}
};
N['mk.win']={lines:[L('malakor','Fine. FINE. You want the truth? Here\'s the truth, and it\'s worse than the one you came for.'),
  L('malakor','Yes, I built it. A surgical UV lance. Quartz tube, capacitor bank, a beam you could cut a man in half with at three metres. Commissioned, paid in full. Collected Sunday night, eleven o\'clock.'),
  L('malakor','By a buyer in a mask. White, surgical. Gloves. Never said a word. And do you know who walked in with her? *Absalom.* And *you*.'),
  L('tenant','...No. No, I would remember that. I would —'),
  L('web','Vane walked his own killer into the shop that built the weapon. He trusted her. She was *with* you.',{pass:4,do:(S,G)=>{G.fact('malakor','lance');G.fact('malakor','buyer');S.flags.maskedBuyer=1;G.give('invoice');G.sync(4);}}),
  L('malakor','And one more thing, for free, because I like you, and I like watching your face do that. The boy on the hook at Kowalski\'s? The one with the curls?'),
  L('malakor','*You* chained him there. Four o\'clock Monday morning. My man was outside, watching. You hung him up like a side of pork and the Sheriff stood there and *watched* you do it.',{do:(S,G)=>{G.fact('malakor','leo');G.fact('leo','chained');S.flags.knowChained=1;G.comp(-1,'You did that to Leo');}}),
  L('tenant','"So he wouldn\'t run into Malakor\'s gunmen." That\'s what I said. I said, "Don\'t waste him." God forgive me, I said that.'),
  L('malakor','Now. What I want. The package Absalom collected came in on my boat, through my yard, and I was paid a *pittance* to look the other way. It\'s worth more than this whole Ward. Bring it to me, and the Syndicate will remember you as a friend.',{do:(S,G)=>{S.flags.malakorWantsVessel=1;G.promise('malakorVessel','Bring Malakor the package');G.task('malakor','done');G.xp(40,'You walked out of Platform 0');G.offer('guillotine');}})],end:true};
N['mk.lose']={lines:[T('He puts the bone saw down very gently. That is the frightening part.'),
  L('malakor','No. You\'re boring me. Here is what you get for free, and then you get out of my yard.'),
  L('malakor','I didn\'t kill him. I built the thing that killed him, and I sold it to a woman in a surgeon\'s mask, and she walked in here on Sunday with Absalom and *you*. Go and ask her. If you can find her face.',{do:(S,G)=>{G.fact('malakor','lance');G.fact('malakor','buyer');S.flags.maskedBuyer=1;G.task('malakor','done');G.rel('malakor',-1);}}),
  L('malakor','Next time you come down here without a reason, I\'ll keep your hands.')],end:true};
N['mk.hub']={lines:[L('malakor',S=>S.flags.genDead?'My generator is DEAD. If I find out who, I will make a lamp out of them.':'Back again. Customers or trouble?')],
  opts:[O('"Who is the doctor in the mask?"','mk.who',{once:true,if:S=>S.flags.maskedBuyer}),O('"What\'s in the package?"','mk.pkg',{once:true}),
    O('"I need work. The Syndicate pays?"','mk.work',{once:true}),O('Leave.',null,{end:true,leave:true})]};
N['mk.who']={lines:[L('malakor','If I knew her name I\'d have charged her more. Steady hands. Smelled of hospital. A little of *us*, too, which is strange: a mortal who smells of vitae is either a ghoul or a customer.'),L('web','A mortal who takes vampire blood a drop at a time. Steady hands. Hospital smell.',{if:S=>S.flags.rostovaVitae})],next:'mk.hub'};
N['mk.pkg']={lines:[L('malakor','A brass bottle the length of your arm, sealed in lead in the hold of a ship that sank in 1911 and was raised last month. The manifest called it "medical apparatus".'),L('malakor','The old women in the sewers call it the Sun-Vessel. Noon in a bottle. Enough daylight to cure one vampire, or kill four blocks of them, depending on which way you turn the dial.',{do:S=>S.flags.knowsVessel=1}),L('sundial','Noon in a bottle. Noon in a BOTTLE.')],next:'mk.hub'};
N['mk.work']={lines:[L('malakor','The Syndicate always needs hands. Come back tomorrow and I\'ll find you something that pays and doesn\'t kill you. Much.',{do:S=>S.flags.malakorWork=1})],next:'mk.hub'};
// the workbench and the generator (heist three)
H.use.workbench=async(S,G)=>G.talk('wb.0');
N['wb.0']={lines:[T('A long bench under a work light: quartz tubes in cotton wool, capacitors the size of soup cans, a jeweller\'s lens on an arm. And a second lens housing, cracked, exactly like the shards you saw in the ash.'),
  L('autopsy','The lens in the freezer came from this bench. Or from its twin.',{pass:7}),
  L('gutter','Ledger in the drawer. Invoices. If you wanted one, nobody\'s looking right now.',{if:(S,G)=>!G.has('invoice'),pass:6})],
  opts:[C('gutter',10,'Lift the invoice from the drawer.','wb.take','wb.caught',{id:'wb_take',if:(S,G)=>!G.has('invoice')}),O('Bone-Key: the drawer lock is nothing.','wb.take',{ab:'bonekey',if:(S,G)=>!G.has('invoice')}),O('Leave it.',null,{end:true,leave:true})]};
N['wb.take']={lines:[T('Red Syndicate letterhead: *One (1) surgical UV lance, custom. Paid in full. Collected Sunday 11 PM.* The buyer\'s line reads only: **R.**',{do:(S,G)=>{G.give('invoice');S.flags.maskedBuyer=1;}}),L('web','R.')],end:true};
N['wb.caught']={lines:[L('malakor','Hands. Out of. My drawer.'),T('One of his men puts a crowbar against the back of your knee, gently, as a suggestion.',{do:(S,G)=>{G.rel('malakor',-1);}})],end:true};
H.use.generator=async(S,G)=>G.talk(S.flags.genDead?'gen.dead':'gen.0');
N['gen.dead']={lines:[T('Black, cold, smelling of burnt wiring. The whole platform runs on work lights from a car battery now.')],end:true};
N['gen.0']={lines:[T('A yellow diesel generator the size of a small car, thudding, sweating oil. Every light on the platform, every lift and saw and freezer, runs off this one machine.'),
  L('web','Mother Soot wants this dead. So does anyone who wants Malakor blind for a night.',{if:S=>S.flags.sootHeists}),
  L('echo','His men are watching the stairs, not the generator. You have about ninety seconds.',{pass:7})],
  opts:[C('abattoir',9,'Cut the fuel line where it bends. Neatly. Like an artery.','gen.kill','gen.caught',{id:'gen_ab',once:'gen_try1'}),
    C('frenzy',10,'Rip the alternator out with your bare hands.','gen.loud','gen.caught',{id:'gen_fr',once:'gen_try2'}),
    O('Spark-Jump: pour your own current into it until it chokes.','gen.kill',{ab:'spark'}),
    O('Snuff: put the whole platform out.','gen.kill',{ab:'snuff'}),
    O('Plague Cloud: let it rust from the inside.','gen.kill',{ab:'miasma',t2:true}),
    O('Pull the main breaker with the lineman gloves on.','gen.kill',{if:(S,G)=>G.equipped('lineman')}),
    O('Leave it.',null,{end:true,leave:true})]};
N['gen.kill']={lines:[T('A cough. A shudder. A long, dying groan, like a ship going down. Every light on Platform 0 goes out at once.',{fx:['shake:.6','sfx:metal'],do:(S,G)=>{S.flags.genDead=1;S.flags.heist_gen=1;G.rebuildRoom();G.xp(25,'Lights out');}}),
  L('malakor','WHAT. *Who.* WHO DID THAT.'),L('echo','In the dark, nobody saw a thing. Walk. Don\'t run.')],end:true};
N['gen.loud']={lines:[T('It comes out in a shower of sparks and a scream of metal. The platform goes black. So does every face turned toward you.',{fx:['shake:1.2','sfx:crash'],do:(S,G)=>{S.flags.genDead=1;S.flags.heist_gen=1;S.flags.malakorKnowsGen=1;G.rebuildRoom();G.rel('malakor',-2);}}),
  L('malakor','*YOU.*'),L('sundial','Run. RUN.')],cs:async(G,S)=>{G.dlgHide();await G.enterRoom('shrine',{x:6.6,z:1.4,ry:-2.4});},end:true};
N['gen.caught']={lines:[L('malakor','Step. Away. From my machine.'),T('He doesn\'t raise his voice. He doesn\'t have to.',{do:(S,G)=>G.rel('malakor',-1)})],end:true};
H.use.firebarrel=async(S,G)=>G.say([T('An oil drum with a fire in it. Three of Malakor\'s men warming their hands and not looking at you.'),L('sundial','FIRE. Fire. Stay back. Stay back from the — fine. Fine. It\'s a barrel. It\'s fine.'),L('nostalgia','Somebody used to roast chestnuts on a fire like this, on a corner, in December.')]);

// the Third Rail Prophet (side quest)
H.use.prophet=async(S,G)=>G.talk('pr.0');H.use.subwaycar=async(S,G)=>G.talk(S.clan==='hollow'&&S.night===2?'hol.car':'pr.car');
N['pr.car']={lines:[T('An old subway car, bricked up at one end, its windows painted black from the inside. Somebody lives at the near end: a mattress, a candle in a jar, a shrine to a saint made of bottle caps.')],end:true};
N['pr.0']={enter:(S,G)=>{G.focus(['you','prophet'],.8);G.look('prophet','you');},lines:[
  T('An old man in a blanket coat sits on a milk crate outside the subway car, talking quietly to the third rail as if it were a dog that might bite.'),
  L('prophet','The live rail knows. It knows everyone who walks on it. Do you know you are walking on it? You are. Six hundred volts. You don\'t even tingle.'),
  L('prophet','I know *you*. You came out of the butcher\'s on Monday with the sun behind you like a cape. No. Wait. That was later. That was going to be later.',{do:(S,G)=>{G.task('s_prophet');S.quests.note_s_prophet='The old man on Platform 0 saw who carried you into Kowalski\'s on Monday morning. He wants something warm.';}})],
  opts:[O('"What did you see on Monday?"','pr.see',{once:true}),O('Give him the Lucky Mart coffee.','pr.coffee',{if:(S,G)=>G.has('coffee')}),O('Leave him to the rail.',null,{end:true,leave:true})]};
N['pr.see']={lines:[L('prophet','I see a lot. I need something warm to see it properly. My hands are cold, you see. You wouldn\'t know.'),L('nostalgia','Coffee. He wants a coffee. A real one, warm, in a cup.')],next:'pr.0'};
N['pr.coffee']={lines:[T('He holds it in both hands under his chin and breathes it in like a man coming up from deep water.',{do:(S,G)=>{G.take('coffee');}}),
  L('prophet','Monday. A quarter to five. The rail sang, so I went up the stairs to look.'),
  L('prophet','The old car, the long black one, at the back of the butcher\'s. You, lying on the cobbles with your eyes open. And two of them carrying you in through the gate: the chauffeur with the white moustache, and the butcher lady in her apron. Gentle as anything. Like you were a bride.'),
  L('prophet','Then the lady locked the freezer door with you inside it, and stood there with her hand on it, and cried. And the chauffeur said, "He told me to keep this one alive." And the sun came up.'),
  L('web','Pemberton lied. He wasn\'t asleep until eleven. He carried you in. And Margo Kowalski locked you in to keep the sun off you.',{pass:3,do:(S,G)=>{S.flags.prophetDone=1;S.flags.pemLied=1;G.task('s_prophet','done');G.fact('pemberton','knew');G.fact('margo','lock');}}),
  L('tenant','Pemberton. You old liar. You good old liar.')],end:true};

/* =====================================================================
   SCENE 2.3 · Mother Soot's shrine
   ===================================================================== */
H.exit.toShrine=async(it,S,G)=>{if(S.flags.knowsWay)return true;S.cancelShrine=false;await G.talk('sw.0');if(S.cancelShrine)return false;return true;};
N['sw.0']={lines:[T('The stairs go down into water. Below Platform 0 the old storm tunnels branch like veins, flooded to the knee, black as coffee, and every one of them looks the same.'),
  L('sundial','There are forty miles of this. Some of it opens onto daylight grates. Choose well.')],
  opts:[C('echo',9,'Listen to the water. Follow the echo that sounds like candles.','sw.ok','sw.lost',{id:'sw_echo'}),
    O('Eye of the Pack: see in the dark. The traps light up.','sw.ok',{ab:'pack'}),
    O('Carrion Whisper: ask the rats.','sw.rats',{ab:'carrion'}),
    O('Grave Liquefaction: go down the drain like water.','sw.ok',{ab:'stillheart',t2:true}),
    O('Follow the bone-wire stapled along the wall.','sw.ok',{if:S=>S.flags.sawBug}),
    O('Wade in and hope.','sw.lost'),O('Turn back.','sw.back')]};
N['sw.ok']={lines:[T('Left, left, right at the shrine of a plaster Madonna with no face, under a waterfall from a broken main, and then a light: hundreds of candles, reflected in black water.',{do:S=>{S.flags.knowsWay=1;}})],end:true};
N['sw.rats']={lines:[T('You ask. A rat on a pipe answers, which is to say it turns and runs, and you follow. Rats know Mother Soot. Everyone down here knows Mother Soot.',{do:S=>{S.flags.knowsWay=1;}})],end:true};
N['sw.lost']={lines:[T('An hour. More. Tunnels that loop, a grate with grey light leaking through it that makes your skin fizz, a dead dog, a live one. When you finally see candles, your shoes are full of something that is not water.',{do:(S,G)=>{G.tick(45);G.comp(-1,'Lost in the tunnels');S.flags.knowsWay=1;}})],end:true};
N['sw.back']={lines:[T('You turn back to the stairs.',{do:S=>{S.cancelShrine=true;}})],end:true};

pushPop('shrine',(S,G)=>{G.addActor('soot',NL.CHARS.soot.spec,{x:3.9,z:0.85,ry:0.1,breathes:false,pose:'sit'});});
pushNpc('shrine',(S,G)=>({id:'soot',actor:'soot',label:()=>S.dos.soot&&S.flags.metSoot?'Mother Soot':'Old woman',stand:[3.9,2.6],face:[3.9,0.9]}));
pushEnter('shrine',async(S,G)=>{A.music('grief');if(!S.flags.metSoot){G.cine(true);G.focus(['you','soot'],1);await G.wait(.6);G.cine(false);await G.talk('so.0');}});
H.use.soot=async(S,G)=>G.talk(S.flags.metSoot?'so.hub':'so.0');
N['so.0']={enter:(S,G)=>{G.focus(['you','soot'],.75);G.look('soot','you');G.look('you','soot');},lines:[
  T('She sits on a throne of rusted pipe among a thousand candles, a tiny grey woman with hair to her waist and eyes like the inside of an oyster. Wires run from the walls to her ears, dozens of them, each ending in a carved white bead of bone. She is listening to the whole Ward at once.'),
  L('soot','You came back. You said you would. You said it crying, which I have always found makes a promise more binding, not less.'),
  L('pedigree','Mother Soot. Eldest of the Wraiths. The Whisper Broker. Older than the city. Possibly older than the river.',{pass:5,do:(S,G)=>{S.flags.metSoot=1;G.meet('soot');G.fact('soot','name');}}),
  L('soot','You gave me a key on Monday morning at twenty-two minutes to five. You put it in my hand and closed my fingers over it, and you said:'),
  L('soot','"Do not give this back to me until I know which of the three snakes I serve."',{do:(S,G)=>{G.fact('soot','contract');}}),
  L('soot','So. Do you know yet, little lamb? Which snake? The Lady in red? The Butcher? Or the mortals with their badges and their *light*?'),
  L('tenant','Three snakes. Séverine, Malakor, and whoever holds the lance. I said that? I must have been very close to dead. I was rarely so poetic.')],next:'so.hub'};
N['so.hub']={opts:[
  O('"What\'s in the drawer?"','so.drawer',{once:true}),
  O('"I don\'t know which snake yet. What would it take?"','so.price',{once:true}),
  O('"I serve the Court. Séverine."','so.choose',{if:S=>S.flags.sootHeists&&!S.flags.sootChose,do:S=>{S.flags.serve='court';}}),
  O('"I serve the Syndicate. Malakor."','so.choose',{if:S=>S.flags.sootHeists&&!S.flags.sootChose,do:S=>{S.flags.serve='syndicate';}}),
  O('"I serve the living. Miller, and the mortals."','so.choose',{if:S=>S.flags.sootHeists&&!S.flags.sootChose,do:S=>{S.flags.serve='mortal';}}),
  O('"I serve no snake. I\'ll eat all three."','so.choose',{if:S=>S.flags.sootHeists&&!S.flags.sootChose,do:S=>{S.flags.serve='none';}}),
  O('Pay her with what you\'ve learned.','so.pay',{if:S=>S.flags.sootHeists&&(S.flags.heist_bug||S.flags.heist_file||S.flags.heist_gen)&&!S.flags.sootPaid}),
  O('"What do you hear, Mother?"','so.hear',{once:true}),
  O('"Can I rest here before dawn?"','so.rest',{if:S=>S.flags.sootPaid}),
  O('Leave her to her listening.',null,{end:true,leave:true})]};
N['so.drawer']={lines:[L('soot','I don\'t know, and I didn\'t ask. Something warm. You were carrying it against your chest like a baby when you went up the stairs to St. Jude\'s, and when you came back down, your arms were empty and you couldn\'t stop shaking.'),
  L('soot','Drawer fourteen, row B. Inside a dead man. You sewed him shut yourself. You were a nurse once, or something like one; your stitches were very neat.',{if:S=>S.past==='paramedic'}),
  L('soot','Drawer fourteen, row B. Inside a dead man. You sewed him shut yourself. Your stitches were terrible.',{if:S=>S.past!=='paramedic',do:(S,G)=>{S.flags.drawer14=1;G.task('locker');S.quests.note_locker='Morgue drawer B-14, St. Jude\'s basement. Something is sewn inside a John Doe. You need the key, and the code 0414.';}})],next:'so.hub'};
N['so.price']={lines:[L('soot','Everything costs. Down here we pay in whispers. Bring me one of three things, and I will give you back your key, and something to think about on top.'),
  L('soot','One. The Lady\'s booth in the crypt. I have ears in the organ upstairs, but not in the booth. Put this in it.',{do:(S,G)=>{if(!G.has('bug'))G.give('bug');}}),
  L('soot','Two. The detective\'s case file. The one in her coat that she reads on the bus.'),
  L('soot','Three. Malakor\'s generator. He thinks in the dark I cannot hear him. He is wrong, but I like him to think it. Kill it for one night and his men will talk.'),
  L('soot','Or break into the morgue by force and take your thing without the key. Many will hear. Not only me.',{do:(S,G)=>{S.flags.sootHeists=1;G.fact('soot','heists');G.task('s_choir');S.quests.note_soot='Bring Mother Soot one of three things: a bone-microphone in Séverine\'s booth, Miller\'s case file, or Malakor\'s generator dead. Then tell her which snake you serve.';S.quests.note_s_choir='Plant Mother Soot\'s bone-microphone in Lady Séverine\'s booth, in the VIP crypt.';}})],next:'so.hub'};
N['so.pay']={lines:[T('You tell her. She listens with her eyes closed and her head on one side, like a bird.'),
  L('soot','...The Lady and the federal man, talking in her booth about the Hound. *"The doctor did her part. Let Valko do his."* Mm. Mm.',{if:S=>S.flags.heist_bug,do:(S,G)=>{S.flags.knowSevHarrow=1;G.fact('severine','funded');}}),
  L('soot','...Seven names, all from the doctor\'s free clinic. And a note in the detective\'s hand: *Rostova\'s basement. Tuesdays. What is she DOING down there?* Mm.',{if:S=>S.flags.heist_file,do:(S,G)=>{S.flags.knowSeven=1;G.fact('rostova','why');}}),
  L('soot','...In the dark, the Butcher\'s men say: *the boss has a buyer for the sun-bottle. The federal man. A million, cash.* Mm. Mm. Mm.',{if:S=>S.flags.heist_gen,do:(S,G)=>{S.flags.knowMalakorHarrow=1;}}),
  L('soot','Good. Now. Which snake?')],next:S=>S.flags.sootChose?'so.give':'so.hub',cs:async(G,S)=>{S.flags.sootPaid=1;}};
N['so.choose']={lines:[L('soot',S=>({court:'The Lady. Masks and manners and murder in the good china. Very well.',syndicate:'The Butcher. Honest, at least, about the knives. Very well.',mortal:'The living? Oh, lamb. They will burn you for it. But very well.',none:'All three? Ha! Like me, then. Like me. Very well.'})[S.flags.serve]),
  T(null,{do:(S,G)=>{S.flags.sootChose=1;if(S.flags.serve==='none'){G.offer('autarkis');G.rel('soot',1);}if(S.flags.serve==='mortal')G.offer('shepherd');if(S.flags.serve==='court')G.offer('leash');if(S.flags.serve==='syndicate')G.offer('guillotine');}})],next:S=>S.flags.sootPaid?'so.give':'so.hub'};
N['so.give']={lines:[T('She opens her hand. On her palm, on a twist of red string, a flat brass key sticky with blood-wax.'),
  L('soot','Your key. You were very insistent. "Locker fourteen," you said. "Four-fourteen," you said. You were a little delirious.'),
  L('soot','Take it. And come back when you\'ve opened it, and tell me what was inside. I do so hate not knowing.',{do:(S,G)=>{G.give('lockerkey');G.task('soot','done');G.task('locker');S.flags.drawer14=1;S.quests.note_locker='Morgue drawer B-14, St. Jude\'s basement. You have the key. The code is 0414.';G.xp(50,'The key');G.rel('soot',1);G.sync(3);}}),
  L('sundial','The morgue is sealed tonight. Tomorrow. Tomorrow night.')],end:true};
N['so.hear']={lines:[L('soot','Everything. The Prince\'s tower, the precinct, the dance floor, the drains. Do you want to know what Séverine says when she\'s alone? She hums. The same four notes. A lullaby from Naples, 1690.'),
  L('soot','Do you want to know what *you* said, on Monday, when you thought nobody was listening? You said: "I don\'t want to be this. I don\'t want to be this. I don\'t want —"'),L('pulse','...'),L('soot','Ah. You did want to know. Too late.',{do:(S,G)=>G.offer('golconda')})],next:'so.hub'};
N['so.rest']={lines:[L('soot','There is an alcove behind the candles. The rats will keep you company. They are very good company. They never interrupt.')],
  opts:[O('Sleep here until tomorrow night.',null,{if:S=>NL.Camp.canSleep(S),end:true,do:()=>setTimeout(()=>NL.Camp.sleep('shrine'),300)}),O('Not yet.','so.hub')]};
H.use.switchboard=async(S,G)=>G.say([T('A board of carved bone beads on brass hooks, each labelled in tiny careful script: PRECINCT · STAIRWELL B. RELIQUARY · ORGAN. ST. JUDE\'S · BASEMENT. PRINCE · ??? One hook is empty and labelled CRYPT · BOOTH.'),L('echo','St. Jude\'s basement. She can hear the morgue.')]);
H.use.water=async(S,G)=>{S.flags.mirror_cistern=S.flags.mirror_cistern||0;return G.say([T('Black water, perfectly still, reflecting a thousand candle flames and a ceiling of bricks.'),T(NL.CLANS[S.clan]&&NL.CLANS[S.clan].ghost?'Not you, of course.':'And a face that might be yours, if you were a stranger.')]);};

// planting the bug in the VIP booth (heist one)
NL.ROOMS.vip.inter.push({id:'booth',label:'Séverine\'s booth',at:[3.6,1.0,0.6],box:[1.6,0,0.2,5.6,1.5,1.2],stand:[2.2,2.6],face:[2.6,1.0],if:(S,G)=>G.has('bug')&&!S.flags.heist_bug});
H.use.booth=async(S,G)=>G.talk('bug.0');
N['bug.0']={lines:[T('The velvet booth where the Keeper sits every night. The bone microphone is the size of a fingernail. It needs to go somewhere she will talk near and never look.'),
  L('severine','Is there something you want, little hound? You\'re hovering.',{if:(S,G)=>G.actor('severine')})],
  opts:[C('stagecraft',10,'Sit down beside her, perfectly at ease, and press it into the seam of the velvet.','bug.ok','bug.no',{id:'bug_stg',mod:(S,G)=>G.equipped('dinnerjacket')||G.equipped('porcelain')?2:0}),
    O('Encore: freeze her for five seconds and do it in front of her.','bug.ok',{ab:'encore'}),O('Veil of Dust: let her forget you\'re there.','bug.ok',{ab:'veil'}),O('Puppet Strings: pin her shadow and work fast.','bug.ok',{ab:'strings'}),O('Not now.',null,{end:true,leave:true})]};
N['bug.ok']={lines:[T('It slides into the seam where the velvet meets the wood and is gone. Somewhere far below, a hook marked CRYPT · BOOTH begins to listen.',{do:(S,G)=>{G.take('bug');S.flags.heist_bug=1;G.task('s_choir','done');G.xp(25,'Ears in Elysium');}})],end:true};
N['bug.no']={lines:[L('severine','What are you doing with my cushions?'),T('You take your hand out of the seam with the bug still in it.'),L('severine','Don\'t make me ask twice. I hate asking once.',{do:(S,G)=>G.rel('severine',-1)})],end:true};

/* =====================================================================
   The Lantern Room: Leo's set (a vignette)
   ===================================================================== */
N['lan.0']={lines:[T('The Lantern Room is a basement bar with twelve tables, a brick wall, and a microphone stand that leans to the left. You stand at the back where the light doesn\'t reach.'),
  T(S=>({forgot:'Leo is third on the list. He doesn\'t see you. He doesn\'t know you. He does five minutes about a nightmare he had in a walk-in freezer and it kills, it absolutely kills.',ally:'Leo is third on the list. He sees you at the back and nearly drops the mic, and then he grins, and then he does five minutes about the night shift.',thrall:'Leo is third on the list. He spots you at the back and his whole face lights up like a dog\'s, and he does his whole set to you, and nobody else in the room exists.',paid:'Leo is third on the list. He sees you at the back and freezes for a full second. Then he does five minutes about not seeing things. It\'s nervy and strange and very funny.'})[S.flags.tedState]||'Leo is third on the list. He\'s shaky. He\'s good.'),
  L('leo','—so I said, what do you call a vampire who works in a butcher\'s? And she goes, "Leonard, that\'s not a joke, that\'s a cry for help." And I go, MOM, it\'s *both*.'),
  L('leo','...The night shift.',{if:S=>S.flags.tedState==='ally'||S.flags.tedState==='thrall'||S.seen['tedf.muse']}),
  T('The room laughs. Not politely. Really laughs. Somebody at the front table snorts beer out of their nose.'),
  L('nostalgia','This. This is what you were trying to save, on Monday, when you were crying in the lane. Not him exactly. *This.*'),
  T(null,{do:(S,G)=>{S.flags.lanternDone=1;G.comp(2,'Leo\'s set');G.rel('leo',1);G.xp(20,'You stayed for the set');G.offer('shepherd');}})],end:true};
})();
