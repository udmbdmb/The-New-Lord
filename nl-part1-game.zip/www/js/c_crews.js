'use strict';
/* THE NEW LORD — "The Night Crew": on Thursday, LANTERN's technicians are in the tunnels under the Ward, wiring the lamps. You could find them. What you do then is up to you. */
(function(){const X=NL.EXTRAS,S_=NL.Script;
X.danny={n:'Danny Reyes',color:'#a8b8c8',role:'LANTERN · lamp technician',spec:{face:{long:1.0,cheek:1.1,jaw:1.1},skin:[.66,.5,.4],hair:{style:'crop',color:[.08,.06,.05]},shirt:[.4,.42,.4],coat:{color:[.35,.38,.35],length:.5,collar:false},glasses:{type:'round'}}};
X.tech2=X.tech2||{n:'A technician',color:'#a0a8a0',role:'LANTERN',spec:{face:{long:1.05},skin:[.86,.74,.68],hair:{style:'shaved',color:[.4,.3,.2]},shirt:[.4,.42,.4],coat:{color:[.35,.38,.35],length:.5,collar:false}}};
NL.TASKS.s_crew={n:'The Night Crew',xp:80,cat:'side'};
S_.place({id:'cbasement',name:'The Courthouse Basement',block:'C',sub:'Under the records room. The third lamp cable.',if:'night:4&flag:mapOK&flag:knowCable&!flag:cable3',node:'nc3.gate',min:10});
S_.place({id:'servicetunnel',name:'The Service Tunnel, Ferrier Lane',block:'D',sub:'A manhole with a federal padlock and fresh cable running down into it. Somebody is working down there tonight.',if:'night:4&flag:mapOK&flag:knowCode&!flag:crewDone&!flag:harrowDeadEarly',node:'nc.0',min:10});
})();
NL.Script.add(String.raw`
# nc.0
> The manhole on Ferrier Lane has a new padlock, federal grey, and two thick cables running out of it into a junction box on the wall. You can hear voices down there. A radio. Somebody laughing.
? rigor 8 "Wait for the floodlight to sweep past. Then go down."  -> nc.down | nc.seen {id nc_rig}
* Rip the padlock off and go down fast.  -> nc.down2

# nc.seen
> You wait too long, or not long enough. The floodlight catches you on the ladder. Below, the radio goes off.
tech2: Who's there? Danny, someone's on the ladder.
@next nc.meet

# nc.down
> You go down in the dark between sweeps. Nobody hears. The tunnel is Victorian brick, wet, lit with work lamps on stands. It runs under Ferrier Lane toward the Switchyard. Along one wall, every twenty feet, a quartz cylinder the size of a fire extinguisher, wired into a cable as thick as your wrist.
> At the far end, two men in grey overalls, sitting on cable drums, eating sandwiches. One young and round-faced with round glasses. One older, shaved, with a thermos.
@next nc.meet

# nc.down2
> The padlock comes off in your hand like a ring-pull. You drop down the ladder without touching the rungs. When you land the whole tunnel hears it.
@next nc.meet

# nc.meet
> They see you. The older one drops his thermos. The young one doesn't move at all. He just stares at your face in the work lights, with a sandwich halfway to his mouth.
danny: Oh. Oh, no. Oh, you're... you're Subject Eight.
tech2: Danny. Danny, the radio. Get on the radio.
pulse(6): The older one's heart is going like a drill. The young one's is strangely slow. He's not afraid. He's fascinated.
* "Nobody touches the radio."  -> nc.radio
* "Danny Reyes. Third floor, Langley. You water Tom Harrow's plant."  -> nc.plant {if flag:hcPlantTask|mem:harrow.plant}
* Go for the older one. He's reaching.  -> nc.grab

# nc.radio
> The older one's hand stops an inch from the handset. He looks at you. He takes his hand back very slowly.
@next nc.talk

# nc.grab
> You're across the tunnel before his fingers close. The radio goes into the wet. He goes against the brick. He doesn't scream. He just slides down and sits there, shaking.
{do lean:restraint-1}
@next nc.talk

# nc.plant
> Danny goes white. Then red.
danny: How do you... did Tom tell you that? Tom TOLD you that? He doesn't tell anyone anything. He doesn't tell ME anything.
danny: It's a spider plant. It's very healthy. He'd kill it in a week if I didn't.
{do rel:danny+2}
@next nc.talk

# nc.talk
danny: What... what do you want? We're just the crew. We wire them. We don't fire them. Nobody down here fires anything.
* "How do they work? The lamps."  -> nc.how
* "What happens if this cable gets cut?"  -> nc.cable
* "Do you know what these do to people? To us?"  -> nc.know

# nc.how
danny: Quartz. High-intensity UV-B, tuned to the... to the frequency of your... of the thing in your blood that the sun hurts. Six-second pulse. Every grate on Platform 0 has one. Thirty-one. They fire together on one signal, 4.14 megahertz, from the mast on the Courthouse.
danny: I designed the housing. I'm quite proud of the housing.
@next nc.talk2

# nc.cable
tech2: Don't tell it that, Danny.
danny: ...If this cable's cut, nothing happens. The mast sends the signal, the lamps don't get it. You'd have to cut it in three places, though. There's redundancy. There's always redundancy. It's the government.
web(7): Three places. Here, under the Switchyard junction, and at the Courthouse feed. One night. Three cuts.
{do flag:knowCable=1}
@next nc.talk2

# nc.know
danny: I know what they do. I've seen the footage. From the... from the first trial. On Pier Nine.
danny: I watched it four times. I threw up three of them. Then I went back to work on Monday because I've got a student loan the size of a house.
> He puts the sandwich down very carefully on the cable drum.
danny: I don't know why I'm telling you that.
@next nc.talk2

# nc.talk2
* "Help me cut the cable. Three places. Tonight."  -> nc.recruit
* "Go home, both of you. Leave the tunnel. I'll do the rest."  -> nc.home
* Cut it yourself. Right here. In front of them.  -> nc.cut
* Feed on the older one. Make Danny watch. Make him understand what he's building for.  -> nc.feed {blood}
* "Finish your sandwiches. I was never here."  -> nc.leave

# nc.recruit
danny: Help you. Cut LANTERN's... I'd go to prison. I'd go to federal prison for the rest of my life.
? velvet 11 "You threw up three times out of four. That's the part of you that's right. Listen to it once."  -> nc.recok | nc.recno {id nc_vel} {mod like:danny}

# nc.recok
> He takes his glasses off. He cleans them on his overalls. He puts them back on.
danny: ...The Switchyard junction is behind a grate on Platform 0, east tunnel. The Courthouse feed is in the basement, under the records room. This one's here.
danny: I'll do this one. Now. You do the other two. If anyone asks, it was rats.
> He takes a pair of bolt cutters out of his kit bag. The older one is staring at him.
tech2: Danny. Danny, what are you...
danny: Go home, Mike. Go home and see your kids. I'll say you left before I did it.
> The cable parts with a crack and a smell of hot rubber. Every quartz cylinder in the tunnel ticks, once, as it cools.
{do flag:cable1=1; flag:dannyTurned=1; flag:knowCable=1; task:s_crew; note:s_crew|Danny Reyes cut the first lamp cable under Ferrier Lane. Two more: the Switchyard junction behind the east-tunnel grate on Platform 0, and the Courthouse feed under the records room.; rel:danny+2; xp:40:Danny}
@end

# nc.recno
danny: No. No, I can't. I'm sorry. I'm sorry. Please don't... please just go.
@next nc.talk2

# nc.home
tech2: Home. You're letting us go home.
danny: ...Why?
* "Because you didn't fire anything. Yet."  -> nc.home2

# nc.home2
> They go up the ladder, the older one first, very fast, the younger one slowly, looking back at you all the way up. At the top he stops.
danny: The Switchyard junction. East tunnel, behind the grate. And the Courthouse basement. Under records. Three cuts. That's all I'm saying.
> Then he's gone.
{do flag:knowCable=1; flag:crewHome=1; task:s_crew; note:s_crew|The lamp cable runs in three places: under Ferrier Lane, at the Switchyard junction behind the east-tunnel grate, and under the Courthouse records room. Cut all three.; lean:mercy+1}
@next nc.cut

# nc.cut
> You take the cable in both hands. It's thick, armoured, humming. You pull. It doesn't want to. You pull harder, and something in your shoulders tears and mends at the same time, and the cable comes apart in a shower of sparks that lights the whole tunnel blue.
{do flag:cable1=1; vitae-1; task:s_crew; note:s_crew|One cable cut under Ferrier Lane. Two more: the Switchyard junction behind the east-tunnel grate on Platform 0, and the Courthouse feed under the records room.}
@gate flag:crewHome ? nc.after : nc.cutwitness

# nc.cutwitness
danny: ...You just tore federal infrastructure in half with your hands.
tech2: We're dead. We're so dead.
> They run. You let them.
@next nc.after

# nc.after
> The tunnel's quiet. The work lights buzz. Two more cuts.
@end

# nc.feed
> You take the older one by the overalls. Danny says "no, no, no" and doesn't move. You drink from a man named Mike who has two kids and a thermos, until his heart slows, and then you stop, and you turn round with his blood on your mouth and look at Danny Reyes in the work light.
> He doesn't throw up. He just looks at you. Then he picks up the bolt cutters, and cuts the cable, and sits down on the drum and puts his face in his hands.
danny: There. There. That's what it's for. That's what all of it is for. I get it. I GET it.
{do feed:3:Phlegmatic:a LANTERN technician:mortal; flag:cable1=1; flag:knowCable=1; flag:dannyTurned=1; task:s_crew; lean:mercy-1; heat+1; note:s_crew|One cable cut. Two more: the Switchyard junction behind the east-tunnel grate on Platform 0, and the Courthouse feed under the records room.}
@end

# nc.leave
danny: You were never here. Okay. Okay.
> You go up the ladder. Behind you, nobody eats their sandwich.
{do flag:crewDone=1}
@end

// --- the other two cuts ---
# nc2.0 arc=malakor night=4 label="\"Malakor. The east tunnel. There's a cable behind the grate.\"" if=flag:knowCable&!flag:cable2&alive:malakor prio=7
@focus malakor
malakor: A cable. In MY tunnel. Behind MY grate.
> He goes and looks. When he comes back his face, the current one, is very calm, which is worse than angry.
malakor: Federal armour, copper core, three hundred amps. It runs straight under my platform to the lamps. I could have it out by midnight.
* "Out. All of it."  -> nc2.out
* "Cut it, but leave it looking whole. Let them think it works."  -> nc2.fake

# nc2.out
malakor: Out. My boys love a demolition. We'll sell the copper.
{do flag:cable2=1}
@end

# nc2.fake
malakor: Oh, that's nasty. I like that. A cut you can't see. They'll test it at midnight and get a green light from the mast and a dead line at the lamps. They'll think it's fine right up until it isn't.
{do flag:cable2=1; flag:cableFake=1; rel:malakor+1}
@end

# nc2s.0 arc=soot night=4 label="\"Mother. A cable behind the east-tunnel grate.\"" if=flag:knowCable&!flag:cable2&alive:soot&!alive:malakor prio=7
@focus soot
soot: A cable. Copper. Mm. Rats love copper. Rats love it. By midnight.
{do flag:cable2=1}
@end

# nc3.gate
@gate seen:cl.0 ? nc3.0 : nc3p.0

# nc3.0
pellow: The basement. Under records. There's been men in grey down there all week. Very polite. They signed in. Nobody signs in any more.
pellow: I can let you in. I have the key. I've had the key since 1977. Nobody's ever asked for it.
* "Let me in."  -> nc3.in

# nc3.in
> The Courthouse basement. Filing cabinets from the 1950s. Dust. A federal junction box, new, bolted to the wall, with a cable running up through the ceiling toward the mast on the roof.
> You cut it. It's easier this time. You know how now.
pellow: Is that... was that important?
* "It might be the most important thing anyone's done in this building."  -> nc3.done

# nc3.done
pellow: Goodness. Goodness. I'll write it in the log.
{do flag:cable3=1; rel:pellow+1}
@end

# nc3p.0
tenant: The Courthouse. I know that basement. I filed things there in 1926 that I shouldn't have. There's a coal chute from the yard on Assize Street. Nobody's used it since the war.
> You go in through the coal chute. It's black, and tight, and very old. In the basement, the federal box. You cut it.
{do flag:cable3=1; vitae-1}
@end
`,'c_crews');

/* three cuts and the lamps don't fire */
(function(){const {L,T}=NL.DSL;const N=NL.DSL.N;
NL.Script.on('crewdone',{if:'flag:cable1&flag:cable2&flag:cable3'},S=>{S.flags.crewDone=1;S.flags.cablesCut=1;NL.G.task('s_crew','done');NL.G.xp(80,'The Night Crew');NL.G.toast('level','All three lamp cables are cut.','The Night Crew');});
document.addEventListener('DOMContentLoaded',()=>{const n=N['lamps.0'];if(!n||!n.lines)return;
  if(n.lines[2]){const f0=n.lines[2].if;n.lines[2].if=S=>!S.flags.cablesCut&&(!f0||f0(S));}
  n.lines.push(T(S=>S.flags.cableFake?'Under every grate, a green light flickers on, federal and confident. And then off. Then on. Then off. Somewhere up on the street a technician says "but it tested GREEN" in a voice going up an octave.':'Under every grate, nothing. Not a whine, not a click. Three cut cables, under three buildings, in the dark. Up on the street, a man with a megaphone says "Danny? Danny, what\'s going on?" and nobody answers.',{if:S=>S.flags.cablesCut&&!S.flags.harrowWalked&&!S.flags.harrowDeadEarly}));
  const nx=n.next;n.next=S=>S.flags.cablesCut?'lamps.dead':(typeof nx==='function'?nx(S):nx);});
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.dannyTurned)o.push(['Danny Reyes',f.cablesCut?'Was arrested in December for "sabotage of federal infrastructure" and released in January for "lack of evidence", after a rat was found in the Ferrier Lane junction box. He waters a spider plant in an apartment in Baltimore. He\'s retraining as a nurse.':'Cut one cable. It wasn\'t enough. He still thinks about the other two.']);
  return o;});
})();
