'use strict';
/* THE NEW LORD — Act I · Night One: "The Thaw & the Cover-Up" (after the freezer) */
(function(){
const NL=window.NL,G=NL.G,A=NL.Audio;const {N,ENC,L,T,O,C,H,STORY}=NL.DSL;const {pushPop,pushNpc,pushEnter}=NL.Act;
const Wd=()=>G.Wd;const F=S=>S.flags;
const leoAlive=S=>!S.flags.leoDead;
const night=n=>S=>S.night===n;

/* =====================================================================
   PROLOGUE CHANGES
   ===================================================================== */
// Leo: the fourth way out of the freezer — drain him
N['tedf.hub'].opts.splice(N['tedf.hub'].opts.length-2,0,O('Finish what the hook started.','n1.drain',{if:S=>!['forgot','ally','thrall','paid','dead'].includes(S.flags.tedState)}));
N['n1.drain']={lines:[L('pulse','No. No. Look at his face. LOOK at —'),L('frenzy','Shut up.'),
  T('He sees it in your eyes a second before you move, and he doesn\'t scream. He just says "oh," very softly, like someone who has finally got the punchline.'),
  T('It takes a long time. Longer than you thought. When it is finished, the back room is very quiet, and you are very, very full.',{fx:['flash','sfx:drink'],do:(S,G)=>{G.feed(6,'melancholic','Leo, all of him',{kind:'mortal',kill:true});S.flags.leoDead=1;S.flags.tedState='dead';G.comp(-3,'You killed him');G.task('leo','done');G.offer('darwin');G.sync(5);}}),
  L('tenant','...Well. That is one way to keep a secret.'),
  L('nostalgia','His niece turned nine on Monday. She drew him a crown.'),
  L('abattoir','There\'s a band saw and a grinder eight feet away. Somebody will have to be practical about this. It may as well be you.')],
  cs:async(G,S)=>{G.dlgHide();const a=G.actor('leo');if(a){G.pose('leo','slump',2);await G.wait(1.2);}await G.say([T('You are practical about it. Afterwards you wash your hands for a long time, and the water keeps coming out pink, and then it doesn\'t.')]);G.removeActor('leo');S.flags.tedGone=1;S.flags.leoBody=1;G.rebuildInter();},end:true};
// the ash: scoop a vial
N['ash.hub'].opts.splice(N['ash.hub'].opts.length-1,0,O('Scoop some of him into the spice jar from your coat.','n1.vial',{once:'n1_vial',if:(S,G)=>!G.has('ashvial')}));
N['n1.vial']={lines:[T('There is an empty spice jar in the greatcoat\'s pocket, as if he planned it. Maybe he did. You fill it with the finest of the ash, the grey of very old snow, and screw the lid down.'),
  L('tenant','A souvenir. How *touching*. Keep me warm.',{do:(S,G)=>{G.give('ashvial');G.sync(5,'He is in your pocket now');}}),
  L('osmosis','It is warm. It should not be warm.',{pass:8})],next:'ash.hub'};
// Pemberton no longer ends the game: he becomes your driver
N['pem.end']={lines:[L('pemberton','Very good.'),
  T('He does not open the door. He reaches into his coat instead and holds out an envelope: cream laid paper, sealed with a crane on one leg.'),
  L('pemberton','The Sheriff gave me this on Sunday night. "If anybody other than me walks out of that shop, Pemberton, give them this, and then do as they say." I asked him what he meant. He told me to go and sit in the car.'),
  T('One line, in a hand you have never seen and somehow know: *IF NOT ME — ST. JUDE\'S. ASK THE NIGHT DOCTOR WHAT SHE SAW. TRUST NO ONE IN A MASK. — A.V.*',{do:(S,G)=>{G.task('clinic');G.fact('pemberton','knew');S.flags.envelope=1;}}),
  L('tenant','I don\'t remember writing that. I remember *meaning* to.'),
  L('web','"Trust no one in a mask." The Court wears masks. So does a surgeon.',{pass:8}),
  L('pemberton','Lady Séverine has telephoned the car twice. She expects the Sheriff\'s report at Club Reliquary tonight, and she does not like to wait. Where would you like to go first?'),
  L('pedigree','He is asking *you*. The ghoul of a Sheriff is asking you where to drive.')],
  cs:async(G,S)=>{G.dlgHide();await NL.Act.titleDrop(G,S);},end:true};

NL.Act.titleDrop=async function(G,S){
  G.cine(true);A.music('end');await G.wait(.6);
  await G.card('The New Lord','Act I · The Thaw & the Cover-Up',{cls:'title',hold:4.2});
  S.chapter='night1';S.flags.mapOK=1;S.flags.carOK=1;G.task('leave','done');G.task('reliquary');G.task('haven');
  A.music('night');G.cine(false);G.rebuildInter();G.autosave();
  await G.wait(.8);G.toast('task','Tap the map button, or talk to Pemberton, to travel between blocks. Each trip costs time.','The Marrow Ward');
  setTimeout(()=>{if(!S.flags.sevTexted){S.flags.sevTexted=1;G.text('S.','Absalom. You are four hours late. Report. Reliquary. Tonight. Do not make me send someone.');}},16000);
};
G.TitleDrop=NL.Act.titleDrop;

// Pemberton, after the prologue: driver and confidant
const pemLane=S=>S.flags.mapOK&&!S.flags.carGone&&!S.flags.pemDead&&!S.flags.pembertonGone;
pushPop('alley',(S,G)=>{if(pemLane(S)&&!G.actor('pemberton'))G.addActor('pemberton',NL.CHARS.pemberton.spec,{x:5.2,z:2.75,ry:-2.2,breathes:true,pose:'umbrella'});});
H.use.pemberton=async(S,G)=>{if(!S.flags.mapOK)return false;return G.talk('pem.drive');};
N['pem.drive']={lines:[L('pemberton',S=>(['Sir.','Ma\'am.','My lord.'])[S.night%3]+' The engine is warm.')],opts:[
  O('"Drive."',null,{end:true,do:()=>setTimeout(()=>NL.Camp.openMap(),400)}),
  O('"What did he have you do on Sunday night?"','pem.sunday',{once:true}),
  O('"How long have you known about me?"','pem.knew',{once:true,if:S=>S.flags.envelope}),
  O('"Is there anywhere safe to sleep?"','pem.haven',{once:true}),
  O('"Nothing. Wait here."',null,{end:true,leave:true})]};
N['pem.sunday']={lines:[L('pemberton','He had me drive him to the Switchyard at ten. He came back carrying a case like a cello\'s, but heavier, and would not let me put it in the boot.'),
  L('pemberton','Then the clinic. Then here, at ten to four. He told me to sleep until eleven, as I always do. I did not sleep.'),
  L('web','A case. The Switchyard. The clinic. Here. He was moving something. He was *hiding* something.',{pass:6,do:(S,G)=>{S.flags.knowsCase=1;G.fact('tenant','vessel');}}),
  L('tenant','The case. I remember the weight of the case. Nothing else. Infuriating.')],next:'pem.drive'};
N['pem.knew']={lines:[L('pemberton','A year, give or take. He took you on off the books. "The Ward needs someone the Court doesn\'t know about, Pemberton." I drove you twice, with the partition up. You never once said thank you. I liked that about you.'),
  L('pulse','He\'s telling the truth, and it costs him something to tell it.',{pass:8,do:(S,G)=>{G.fact('tenant','chose');G.rel('pemberton',1);}})],next:'pem.drive'};
N['pem.haven']={lines:[L('pemberton','The Sheriff kept no haven he would tell me about. Habit of three centuries.'),
  L('pemberton','Kowalski\'s walk-in is cold and has a lock, though I would not trust the police to stay away. Gideon at the Pawn & Coffin rents boxes for a hundred dollars, sunrise guaranteed. And the Keeper keeps guest coffins under the Reliquary, for those she favours.'),
  L('sundial','Dawn at nine past five. Get underground by half past four, or start praying to a god who likes you.')],next:'pem.drive'};

/* =====================================================================
   THE TURN OF THE NIGHT
   ===================================================================== */
NL.NIGHTS[1]={title:'Act I · The Thaw & the Cover-Up',sub:'The Marrow Ward',
  canSleep:S=>S.time>=300||(S.tasks.reliquary==='done'&&S.tasks.clinic==='done'&&S.time>=150),
  endTitle:'0 · 4 · 1 · 4',
  endLine:S=>`The sun comes up over the Marrow Ward without you. You slept ${(n=>(/couch|seat/i.test(n)?'on ':'in ')+n.replace(/^(A|The) /,m=>m.toLowerCase()))(NL.Camp.havenRoom(S.hav).n)}. Somewhere in the Ward, a key you don't remember giving away is waiting for you.`,
  async cliff(G,S,hav){
    await G.say([T('You pull the lid down, or the door shut, or the dark around yourself like a blanket. The day comes on outside like a slow fire. Your eyes are closing on their own.'),
      L('tenant',S.th.done.includes('amnesiac')?'...Listen. Even if you won\'t. Listen.':'Not yet. Not quite yet. Lend me your hand.'),
      T(S.th.done.includes('amnesiac')?'You dream of a hand that is yours and is not, writing in frost on the inside of a door: four digits, over and over, until the frost is gone.':'Your right hand lifts without you. It drifts to the wall beside your head, and your fingernail goes into the plaster like a chisel, and it writes.'),
      T('**0 · 4 · 1 · 4**',{fx:['shake:.6','sfx:sting']}),
      L('tenant','Four-fourteen. The minute they shot me. And a door with that number on it, somewhere cold. I gave someone the key. I gave someone *you*.',{do:(S,G)=>{S.flags.code0414=1;G.sync(8,'He moved your hand');G.fact('tenant','order');}}),
      L('web','A time and a door. Fourteen. A locker. A drawer. A room. Something with a number on it.',{pass:6}),
      L('sundial','Sleep. SLEEP. It\'s coming up the street.')]);},
  heatAdd:S=>((S.flags.calloOutcome==='attack'||S.flags.calloOutcome==='shot'||S.flags.calloOutcome==='found')?1:0)+(S.flags.leoDead?2:0)
};
NL.NIGHTS[2]=NL.NIGHTS[2]||{title:'Act II · Shadows in Elysium',sub:'The Marrow Ward',start:async(G,S,hav)=>{const h=NL.Camp.havenRoom(hav);await G.enterRoom(h.room,h.spawn,{instant:true});
  await G.say([T('Night Two is still being written. Your save will carry over when it arrives.'),L('tenant','Patience. We have until Friday.')]);}};

// haven spots
const freezerInter={id:'sleepspot',label:'Lie down in the walk-in',at:[3.1,0.4,3.2],box:[2.6,0,2.7,3.6,0.5,3.7],stand:[3.4,2.6],face:[3.1,3.2],if:S=>S.flags.mapOK};
NL.ROOMS.freezer.inter.push(freezerInter);
H.use.sleepspot=async(S,G)=>G.talk('haven.freezer');
N['haven.freezer']={lines:[T('The walk-in. Steel, frost, the smell of pig and Absalom Vane. It has a lock on the inside, now that you fixed the door. It is the closest thing to a grave you own.'),
  L('rigor','Cold. Still. Dark. Every part of you says yes.',{pass:6}),
  L('web','Every part of you except the part that remembers a detective standing at the front glass.',{if:S=>['lose','found','shot','attack'].includes(S.flags.calloOutcome)})],
  opts:[O('Sleep here until tomorrow night.',null,{if:S=>NL.Camp.canSleep(S),end:true,do:()=>setTimeout(()=>NL.Camp.sleep('freezer'),300)}),
    O('It\'s too early to sleep. (Dawn is a while off yet.)',null,{if:S=>!NL.Camp.canSleep(S),end:true,leave:true}),O('Not here.',null,{end:true,leave:true})]};

/* =====================================================================
   FERRIER LANE
   ===================================================================== */
H.barks.alley=[{id:'al_mart',s:'nostalgia',at:[8.2,1,0.6],r:1.6,t:'Fluorescent light and burnt coffee. A church for the sleepless.',if:S=>S.flags.mapOK},
  {id:'al_phone',s:'gutter',at:[0.5,1.5,5.5],r:1.4,t:'A payphone that still works. In this decade. Someone keeps it alive on purpose.',if:S=>S.flags.mapOK}];
H.use.payphone=async(S,G)=>G.talk('phone.0');
N['phone.0']={lines:[T('A steel payphone bolted to the brick, its cord wrapped in electrical tape. A sticker: CALLS 50¢. Someone has scratched a phone number into the paint and someone else has scratched it out.')],
  opts:[O('Call the number on the MISSING poster.','phone.tip',{once:true}),
    O('Call Leo\'s mother.','phone.mom',{once:true,if:S=>leoAlive(S)&&S.dos.leo&&S.dos.leo.facts.includes('mom')}),
    O('Call "S." back.','sev.reply',{if:S=>S.flags.sevTexted&&!S.flags.sevReplied}),
    O('Dial 000-0414.','phone.gehenna',{if:S=>S.flags.code0414}),
    O('Hang up.',null,{end:true,leave:true})]};
N['phone.tip']={lines:[T('Two rings. A recorded voice, tired, female, trying very hard to sound like a recording: *You\'ve reached the Precinct 9 Missing Persons tip line. Leave your name and number, or don\'t. Just tell me what you saw.*'),
  L('pulse','That isn\'t a recording. That\'s Miller, recorded. She did it herself, on her own phone.',{pass:8,do:(S,G)=>G.meet('miller')}),
  ],opts:[O('Say nothing and hang up.','phone.0'),
    C('stagecraft',8,'Disguise your voice: "Check the clinic. The back entrance. Tuesday nights."','phone.tipOk','phone.tipNo',{id:'tip_jude'}),
    O('"Leo Pruitt is alive. He\'s safe."','phone.tipLeo',{if:S=>leoAlive(S)&&S.flags.tedFreed,once:true})]};
N['phone.tipOk']={lines:[T('You give it a smoker\'s rasp and a stranger\'s rhythm. It goes onto the tape like it belongs to someone else.'),L('web','You just pointed a detective at Kowalski\'s blood supply. That is either very clever or very stupid. Ask again on Friday.',{do:(S,G)=>{S.flags.tipJude=1;}})],next:'phone.0'};
N['phone.tipNo']={lines:[T('Your voice comes out flat and cold and nothing like a person. You hang up before the tape can keep it.'),L('stagecraft','She\'ll play that back at three in the morning and not sleep.',{do:(S,G)=>G.heat(0)})],next:'phone.0'};
N['phone.tipLeo']={lines:[T('You say it once and hang up. It is the truest thing you have said tonight.'),L('nostalgia','Somebody\'s mother will hear about that by morning. Let them have it.',{do:(S,G)=>{G.rel('miller',1);S.flags.tipLeo=1;}})],next:'phone.0'};
N['phone.mom']={lines:[T('You remember the number from his phone, which you were not supposed to look at. It rings once.'),
  T('*Leonard? Leonard, is that you? Leonard, I have called the police nine times, nine times, do you know what you put me through?*'),
  L('nostalgia','Say something. Anything. She doesn\'t care what. She only wants a voice.')],
  opts:[C('stagecraft',10,'Be Leo, for ten seconds: "Mom. I\'m okay. I\'m sorry. I\'ll call you tomorrow."','phone.momOk','phone.momNo',{id:'mom_leo',mod:S=>S.clan==='butchers'&&S.flags.borrowedLeo?3:0}),
    O('"Ma\'am, this is a friend of Leo\'s. He\'s safe. He\'s with the police."','phone.momFriend',{if:S=>S.flags.tedGone}),
    O('Hang up without a word.','phone.momHang')]};
N['phone.momOk']={lines:[T('There is a silence, and then she is crying, and then she is shouting at you for crying, and you say "I know, Mom, I know" until she hangs up on you, satisfied.'),L('pulse','You gave a stranger her son back for ten seconds. That was a good thing. Hold on to it.',{do:(S,G)=>{G.comp(1,'A good deed');G.offer('shepherd');}})],next:'phone.0'};
N['phone.momNo']={lines:[T('*...Who is this? Who IS this?*'),T('You hang up. The phone is warm where you held it, which is to say it is not warm at all.'),L('pulse','Worse than nothing. You made it worse.',{do:(S,G)=>G.comp(-1,'You frightened his mother')})],next:'phone.0'};
N['phone.momFriend']={lines:[T('*With the police? Oh God. Oh thank God. Is he hurt?*'),L('you','"He\'s fine. Tired. He\'ll call you."'),T('She thanks you eleven times. You count.',{do:(S,G)=>{G.comp(1,'A small mercy');G.offer('shepherd');}})],next:'phone.0'};
N['phone.mom'].lines.push();
N['phone.momHang']={lines:[T('You put the receiver back very gently, as if it might bruise.')],next:'phone.0'};
N['phone.gehenna']={lines:[T('Zero, zero, zero. Zero, four, one, four. The line clicks, and clicks again, and then there is a sound like a very large room with nobody in it.'),
  T('Nobody answers. Not yet.',{if:S=>!(S.time>=360&&S.time<370&&G.has('ashvial')&&G.thought('firstmurder'))}),
  L('tenant','Put it down. Put it DOWN. I don\'t know who that is and I don\'t want to.')],next:'phone.0'};
H.use.flyer=async(S,G)=>G.say([T('A photocopied flyer, rain-soft: TUESDAY · OPEN MIC · THE LANTERN ROOM · 10PM · FIVE MINUTES, NO HECKLING (TRY IT). Someone has written "LEO P. — CLOSER?" in the corner in biro.'),L('nostalgia','He was going to do a set tomorrow. He still might.',{if:leoAlive}),L('nostalgia','He was going to do a set tomorrow.',{if:S=>!leoAlive(S)})]);

// Séverine's check-in: by text or by phone
N['sev.reply']={lines:[T('The burner\'s keys are tiny and greasy. Somewhere a woman who has waited for Absalom Vane for a century is waiting again.'),
  L('pedigree','The Court has codes. A Sheriff checking in uses three words and a time, nothing more. Vane would never write a full sentence to her.',{pass:7}),
  L('velvet','Or write like him. Clipped, bored, faintly insulting. She\'s used to it.',{pass:7})],
  opts:[C('velvet',9,'Mimic his cadence: "Delayed. Matter in hand. Do not fuss."','sev.replyOk','sev.replyNo',{id:'sev_txt_v'}),
    C('pedigree',8,'Use the Court form: "VESPERS · ONE · AWAITING."','sev.replyCode','sev.replyNo',{id:'sev_txt_p'}),
    O('Don\'t answer. Let her wonder.','sev.replySilent')]};
N['sev.replyOk']={lines:[T('Thirty seconds. Then: *Do not "do not fuss" me, Absalom. One o\'clock. Come yourself. — S.*'),L('web','"Come yourself." She doesn\'t know he\'s gone. Or she wants you to think she doesn\'t.',{pass:8,do:(S,G)=>{S.flags.sevReplied=1;S.flags.sevCalm=1;}})],end:true};
N['sev.replyCode']={lines:[T('A minute. Then: *VESPERS acknowledged. One o\'clock, below. Send your hound if you must. — S.*'),L('pedigree','"Your hound." She thinks you\'re the Sheriff\'s creature, not the Sheriff. Good. That\'s a role you can play.',{do:(S,G)=>{S.flags.sevReplied=1;S.flags.sevCalm=1;S.flags.sevHound=1;}})],end:true};
N['sev.replyNo']={lines:[T('You send it before you can stop yourself. It is wrong: too long, too polite, punctuated like a stranger.'),T('Nothing comes back for a long time. Then one word: *Who?*'),L('sundial','She knows something is wrong. She will be ready for you.',{do:(S,G)=>{S.flags.sevReplied=1;S.flags.sevWary=1;}})],end:true};
N['sev.replySilent']={lines:[T('You put the phone away. It buzzes once more, angrily, and then is quiet.'),L('pedigree','Silence from a Sheriff is a statement. She\'ll be reading it all night.',{do:(S,G)=>{S.flags.sevReplied=1;}})],end:true};

/* ---------- the drifter (Choleric blood) ---------- */
const drifterHere=S=>S.night===1&&S.flags.tariqMet&&!S.flags.drifterDone&&S.time>=60&&S.time<300;
pushPop('alley',(S,G)=>{if(drifterHere(S))G.addActor('drifter',NL.EXTRAS.drifter.spec,{x:4.6,z:1.75,ry:2.6,breathes:true,pose:'lean'});});
pushNpc('alley',(S,G)=>G.actor('drifter')?{id:'drifter',actor:'drifter',label:'Drunk man'}:null);
H.use.drifter=async(S,G)=>G.talk('drift.0');
N['drift.0']={enter:(S,G)=>{G.focus(['you','drifter'],.8);G.look('drifter','you');},lines:[
  T('A big man in a wet army coat is kicking the dumpster in a slow, thorough rhythm, like a man doing a job. His knuckles are split. There is blood on the lid that matches them.'),
  L('drifter','The hell are YOU looking at?'),
  L('parasite','Choleric. Pure rage, fermented in cheap vodka. It would go down like a lit match.',{pass:6}),
  L('gutter','That\'s the guy who\'s been robbing Tariq\'s till with his fists. Everyone on the Strip knows him.',{pass:8,if:S=>S.flags.tariqDrifter})],
  opts:[O('Feed. Just a sip.','drift.sip',{if:S=>S.clan!=='sovereign'}),
    O('Feed. All of it.','drift.drain',{if:S=>S.clan!=='sovereign'}),
    O('Feed. (Rarefied Palate: gutter blood will come back up.)','drift.sovereign',{if:S=>S.clan==='sovereign'}),
    C('apex',8,'Look at him until he remembers he\'s prey.','drift.scare','drift.scareNo',{id:'drift_apex'}),
    C('gutter',8,'"Rough night, soldier? Mine too. Tell me about it."','drift.talk','drift.talkNo',{id:'drift_gut'}),
    O('Kneel: "Go home."','drift.kneel',{ab:'kneel'}),
    O('Walk away.',null,{end:true,leave:true})]};
N['drift.sip']={lines:[T('He swings at you. You let him miss, then you are behind him, and your hand is over his mouth, and the alley goes quiet.'),
  T('It burns. It\'s like drinking a bar fight.',{fx:['flash','sfx:drink'],do:(S,G)=>{G.feed(3,'choleric','a drunk\'s rage',{kind:'mortal'});if(!G.thought('meat'))G.comp(-1,'You fed on a stranger');S.flags.drifterDone='sip';}})],
  opts:[C('pulse',9,'Stop. Now.','drift.stopOk','drift.stopNo',{id:'drift_stop'})]};
N['drift.stopOk']={lines:[T('You let go. He slides down the dumpster and sits there, blinking, two neat holes under his ear that will itch for a week.'),L('frenzy','Coward.'),L('pulse','Person. He\'s a person. He\'ll wake up with a headache and fewer opinions.',{do:(S,G)=>{G.xp(10,'Restraint');G.offer('vegan');}})],cs:async(G,S)=>{G.dlgHide();G.pose('drifter','slump',2);},end:true};
N['drift.stopNo']={lines:[T('You meant to stop. You meant to. When you lift your head he is very heavy and very still.'),
  L('autopsy','Exsanguination. Approximately four minutes. He wouldn\'t have felt the last two.',{do:(S,G)=>{G.feed(2,'choleric','the rest of him',{kind:'mortal',kill:true});G.comp(-2,'You killed a man');G.heat(1);S.flags.drifterDone='dead';G.offer('darwin');}}),
  L('abattoir','The dumpster. Under the cardboard. Kowalski\'s grinder runs at six.')],cs:async(G,S)=>{G.dlgHide();G.pose('drifter','slump',2);await G.wait(1);G.removeActor('drifter');},end:true};
N['drift.drain']={lines:[L('pulse','You don\'t have to —'),T('You do, though. All of it. It burns like a lit fuse all the way down.',{fx:['flash','sfx:drink','shake:.5'],do:(S,G)=>{G.feed(6,'choleric','a drunk\'s rage',{kind:'mortal',kill:true});G.comp(-2,'You killed a man');G.heat(1);S.flags.drifterDone='dead';G.offer('darwin');}}),
  L('frenzy','MORE. Where\'s the next one.')],cs:async(G,S)=>{G.dlgHide();G.pose('drifter','slump',2);await G.wait(1.2);G.removeActor('drifter');},end:true};
N['drift.sovereign']={lines:[T('You get two swallows down. Cheap vodka, old sweat, a liver like a wet sponge. Your stomach turns over like a dog that\'s been kicked.'),
  T('It comes back up onto the cobbles, black and steaming.',{fx:['shake:.6'],do:(S,G)=>{G.feed(3,'choleric','gutter blood',{kind:'gutter'});S.flags.drifterDone='sick';}}),
  L('pedigree','Rarefied Palate. Sovereign blood refuses to be fed from the gutter. It would rather starve.'),L('drifter','...The hell is wrong with you, man?')],cs:async(G,S)=>{G.dlgHide();G.walk('drifter',9.6,3);await G.wait(2);G.removeActor('drifter');},end:true};
N['drift.scare']={lines:[T('You don\'t move. You just stop pretending, for one second, to be the same species as him.'),L('drifter','...Okay. Okay, man. Okay.'),T('He backs off down the lane, hands up, and then runs.',{do:(S,G)=>{S.flags.drifterDone='scared';S.flags.tariqSafe=1;G.xp(10,'Apex');}})],cs:async(G,S)=>{G.dlgHide();await G.walk('drifter',9.6,3.0);G.removeActor('drifter');},end:true};
N['drift.scareNo']={lines:[L('drifter','You want some? You want SOME?'),T('He swings. It connects, mostly with your cheekbone, which does not care.',{fx:['shake:.8'],do:(S,G)=>G.comp(-1,'Punched in the face')}),L('rigor','That should have hurt. It didn\'t. Note that.')],next:'drift.0'};
N['drift.talk']={lines:[L('drifter','...Rough? Rough. Three tours, and they won\'t even give me a bed at St. Jude\'s. Lady doctor says no beds. I seen her though. Sunday night. Out the back of the clinic.'),
  L('drifter','Carrying one of them long black bags, like a rifle bag. Getting into a car with no lights on. Who the hell carries a rifle into a hospital?'),
  L('web','A long black bag on Sunday night, out of the clinic. A long case into the Sheriff\'s car the same night. Two long cases.',{pass:6,do:(S,G)=>{S.flags.rifleBag=1;S.flags.drifterDone='talked';G.xp(15,'Gutter-Sense');}}),
  L('drifter','Don\'t tell nobody I said. That doctor\'s the only one who gives me sandwiches.')],end:true};
N['drift.talkNo']={lines:[L('drifter','Soldier? You ain\'t no soldier. You ain\'t even breathing right.'),L('stagecraft','Breathe. In through the nose. You keep forgetting.')],next:'drift.0'};
N['drift.kneel']={lines:[T('One word, low, certain. His feet obey before the rest of him does.'),L('drifter','...I should go home.'),T('He walks off down the lane like a man carrying a full glass.',{do:(S,G)=>{S.flags.drifterDone='kneel';S.flags.tariqSafe=1;}})],cs:async(G,S)=>{G.dlgHide();await G.walk('drifter',9.6,3.0);G.removeActor('drifter');},end:true};

/* =====================================================================
   THE MIDNIGHT LUCKY MART · Tariq
   ===================================================================== */
pushPop('luckymart',(S,G)=>{G.addActor('tariq',NL.CHARS.tariq.spec,{x:0.7,z:2.8,ry:Math.PI/2,breathes:true,pose:S.night%2?'lean':'idle'});});
pushNpc('luckymart',(S,G)=>({id:'tariq',actor:'tariq',label:()=>S.dos.tariq?'Tariq':'Clerk',stand:[2.6,2.8],face:[0.7,2.8]}));
H.names.tariq='Clerk';H.names.tiny='Bouncer';H.names.gideon='Old man';H.names.rostova='Doctor';H.names.malakor='Butcher';H.names.soot='Old woman';H.names.valko='Hunter';H.names.harrow='Man in sunglasses';
H.use.tariq=async(S,G)=>G.talk(S.flags.tariqMet?'tq.hub':'tq.0');
H.barks.luckymart=[{id:'lm_light',s:'sundial',at:[4,1,3],r:2.5,t:'Fluorescent. Not UV. Probably not UV. Check the tubes.'},{id:'lm_fr',s:'nostalgia',at:[5.4,1,0.8],r:1.4,t:'Root beer. You used to drink root beer.'}];
N['tq.0']={enter:(S,G)=>{G.focus(['you','tariq'],.8);G.look('tariq','you');G.look('you','tariq');},lines:[
  T('A thin man behind the counter, mid-thirties, with the specific eyes of someone who has not slept properly since a particular year. A notebook open in front of him. A cup of coffee older than the notebook.'),
  L('tariq','Evening. Or morning. Whatever it is. Coffee\'s fresh, if by fresh you mean "made today".'),
  L('pulse','He looked at you, and then he looked at your hands, and then he looked at your mouth. He\'s seen your kind before. He isn\'t afraid. He\'s *tired*.',{pass:8}),
  L('tariq','You were in here Monday. No — you weren\'t. You were *outside*. Four in the morning. Huh.',{do:(S,G)=>{S.flags.tariqMet=1;G.meet('tariq');G.fact('tariq','name');}})],next:'tq.hub'};
N['tq.hub']={opts:[
  O('"What did you see on Monday morning?"','tq.monday',{once:true}),
  O('"You don\'t seem very scared of me."','tq.scared',{once:true}),
  O('"What\'s the notebook?"','tq.notebook',{once:true}),
  O('Buy a coffee you can\'t drink. ($2)','tq.coffee',{if:S=>(S.cash||0)>=2}),
  O('"Anyone been giving you trouble?"','tq.trouble',{once:true}),
  O('"Who collects on Wednesdays?"','tq.racket',{once:true,if:S=>S.flags.tariqRacket}),
  O('Listen to the thing he\'s loudest about not saying.','tq.cold',{ab:'coldread',once:true}),
  O('Siren\'s Pitch: "What are you afraid of, Tariq?"','tq.cold',{ab:'siren',once:true}),
  O('"See you around."',null,{end:true,leave:true})]};
N['tq.monday']={lines:[L('tariq','I see everything after midnight. Nobody else is awake to.'),
  L('tariq','Ten to four, the old black car pulls up. Tall guy in a long coat gets out, and somebody else, and they go in the back of Kowalski\'s. Then at ten past four, a doctor\'s car, no lights. Then nothing, then at twenty past, *you* come out the back, alone, carrying something long, and you run.'),
  L('tariq','You came back at quarter to five. You were — I\'m sorry, man — you were crying. Then the old lady from the shop locked the back gate. Then nothing.'),
  L('web','Ten to four: Vane and you arrive. Ten past: a doctor\'s car, no lights. Twenty past: you run, carrying something long. Quarter to five: you come back. And Margo Kowalski locks the gate behind you.',{pass:6,do:(S,G)=>{G.fact('tariq','monday');G.fact('margo','lock');S.flags.tariqTimeline=1;G.xp(20,'A witness');}}),
  L('tenant','Crying. I had forgotten that you can.'),
  C('web',10,'"A doctor\'s car. What kind of car?"','tq.carOk','tq.carNo',{id:'tq_car'})],next:'tq.hub'};
N['tq.carOk']={lines:[L('tariq','White Volvo. Parking sticker on the windscreen. St. Jude\'s, staff lot.'),L('web','Remember that. A staff sticker from the clinic Vane told you to visit.',{do:S=>S.flags.volvo=1})],next:'tq.hub'};
N['tq.carNo']={lines:[L('tariq','Dunno, man. A car. Pale. It was four in the morning.')],next:'tq.hub'};
N['tq.scared']={lines:[L('tariq','I\'ve been doing nights on the Strip for six years. You think you\'re the first one who comes in here, doesn\'t breathe, and buys coffee he doesn\'t drink? There\'s a woman who buys a newspaper every night and holds it upside down.'),
  L('tariq','You people tip. The cops don\'t. I\'ve done the maths.'),
  L('gutter','He\'s not scared because he\'s been paid in sanity for years. Every night clerk on the Strip has an arrangement.',{pass:8})],next:'tq.hub'};
N['tq.notebook']={lines:[T('He turns it round so you can see: dates, times, licence plates, a column headed WHO and a column headed WHY. Neat, obsessive, six years deep.'),
  L('tariq','I can\'t sleep. So I watch. Doctor says it\'s a coping mechanism. I say it\'s a hobby.',{do:(S,G)=>G.fact('tariq','sees')}),
  L('web','Six years of the Strip, written down. That is worth more than anything in this shop.',{pass:6})],next:'tq.hub'};
N['tq.coffee']={lines:[T('He pours it without asking how you take it. You hold it. It is the warmest thing in your hands since Sunday.',{do:(S,G)=>{G.cash(-2,'Coffee');G.give('coffee');}}),
  L('tariq','You don\'t have to drink it. Most of you just like holding it.'),
  L('nostalgia','Burnt. Bitter. Two in the morning on a ward somewhere, before. You remember. You *remember*.',{pass:6})],next:'tq.hub'};
N['tq.trouble']={lines:[L('tariq','Big guy, army coat, been coming in and taking the till. Hits me if I\'m slow. Cops won\'t come for that.',{do:(S,G)=>{S.flags.tariqDrifter=1;}}),
  L('tariq','And on Wednesdays two of them *do* come. Not to help. To collect. "Protection." From what? From them.',{do:(S,G)=>{S.flags.tariqRacket=1;G.fact('tariq','racket');G.task('s_tariq');S.quests.note_s_tariq='Two Precinct 9 cops collect from Tariq every Wednesday at 3 AM.';}}),
  L('pulse','He told you as if it were the weather. He\'s been carrying it alone for a long time.',{pass:8})],next:'tq.hub'};
N['tq.racket']={lines:[L('tariq','Wednesday, three a.m., unmarked Crown Vic. Officer Dale and Officer Pruitt — no relation to the kid, I asked. Two hundred a week or the health inspector finds rats.'),
  L('tariq','There are rats. That\'s not the point.'),
  L('web','Wednesday is Night Three. Three in the morning. Be here.',{do:(S,G)=>{S.quests.note_s_tariq='Wednesday (Night 3), 3 AM: Officers Dale and Pruitt come to collect. Be at the Lucky Mart.';}})],next:'tq.hub'};
N['tq.cold']={lines:[T('His loudest silence is a hospital corridor in 2019, and a woman\'s voice saying "go home, sleep, we\'ll call you", and the call coming at 4:12 a.m., and him asleep.'),
  L('pulse','He hasn\'t slept since because the last time he slept, his wife died without him. That\'s the whole thing. That\'s all of him.',{do:(S,G)=>{G.rel('tariq',1);S.flags.tariqWife=1;}})],next:'tq.hub'};
H.use.coffee=async(S,G)=>G.say([T('The coffee machine gurgles and sighs like an old man. A handwritten sign: PAY TARIQ. HE KNOWS.')]);
H.use.aisle=async(S,G)=>G.say([T('Crisps, motor oil, birthday candles, condoms, holy candles with saints on them, chewing gum. The full span of human need, at a mark-up.'),L('nostalgia','Birthday candles. Leo\'s niece. Nine.',{pass:8,if:S=>S.dos.leo&&S.dos.leo.facts.includes('sister')})]);
H.use.fridges=async(S,G)=>{const ghost=NL.CLANS[S.clan]&&NL.CLANS[S.clan].ghost;return G.say([T(ghost?'The fridge doors reflect the shelves, the counter, Tariq\'s back. Not you. Never you.':'Your reflection in the fridge door is pale and green and looks like it has been dead for about two days. Fair.'),L('sundial','Cold glass. Nice. Stand here a minute.')]);};
H.use.martmirror=async(S,G)=>G.talk('mirror.mart');
N['mirror.mart']={lines:[T('A tiny washroom: a sink, a hand dryer, a mirror with a crack running corner to corner and a sticker that says YOU LOOK GREAT in someone else\'s optimism.'),
  T(S=>NL.CLANS[S.clan]&&NL.CLANS[S.clan].ghost?'The mirror shows the washroom, and the door, and nothing in between.':'You look exactly as dead as you feel.',{do:S=>{S.flags.mirror_mart=1;}}),
  L('tenant','I used to have a face, you know. Everyone said it was my best feature.')],
  opts:[O('Wash your hands until the water runs clear.','mirror.wash',{if:S=>S.flags.dirty&&!S.flags.washed}),O('Leave.',null,{end:true,leave:true})]};
N['mirror.wash']={lines:[T('Ash, then blood, then nothing. The water stays cold no matter which tap you turn.',{do:S=>{S.flags.washed=1;}})],end:true};

/* =====================================================================
   CLUB RELIQUARY · Tiny, the floor, and the VIP Crypt
   ===================================================================== */
pushPop('reliquary',(S,G)=>{
  if(!S.flags.tinyGone)G.addActor('tiny',S.flags.tinyBetrayed?{face:{jaw:1.3,nose:1.2,brow:1.2},skin:[.78,.62,.52],hair:{style:'crop',color:[.3,.22,.15]},shirt:[.08,.08,.09],pants:[.06,.06,.07],coat:{color:[.1,.1,.12],length:.25,collar:true},beard:'stubble',noVary:false}:NL.CHARS.tiny.spec,{x:10.05,z:1.75,ry:Math.PI*0.82,breathes:true,pose:'arms'});
  G.addActor('bartender',NL.EXTRAS.bartender.spec,{x:0.5,z:5.6,ry:Math.PI/2,breathes:true,pose:'wipe'});
  [[4.4,3.3,.4],[5.9,3.0,2.2],[6.6,4.4,-2],[4.9,4.7,3],[3.8,4.2,1.2]].forEach((p,i)=>{const sp=Object.assign({},NL.EXTRAS.dancer.spec,{shirt:[[.6,.1,.4],[.1,.4,.6],[.08,.08,.1],[.5,.4,.1],[.3,.1,.5]][i],hair:{style:['long','crop','curly','bun','slick'][i],color:[[.1,.08,.1],[.5,.32,.15],[.06,.05,.05],[.75,.6,.35],[.55,.12,.1]][i]},skin:[[.8,.62,.52],[.62,.45,.34],[.4,.28,.22],[.93,.84,.78],[.84,.68,.56]][i]});
    const a=G.addActor('dancer'+i,sp,{x:p[0],z:p[1],ry:p[2],breathes:true,pose:'dance'});a.solid=true;});});
pushNpc('reliquary',(S,G)=>[...(G.actor('tiny')?[{id:'tiny',actor:'tiny',label:()=>S.flags.tinyBetrayed?'New bouncer':S.dos.tiny?'Tiny':'Bouncer',stand:[9.6,2.6],face:[10.05,1.75]}]:[]),{id:'bartender',actor:'bartender',label:'Bartender',stand:[2.2,5.6],face:[0.5,5.6]}]);
pushEnter('reliquary',async(S,G)=>{A.music('club');if(!S.flags.enteredClub){S.flags.enteredClub=1;
  await G.say([T('Club Reliquary used to be the Church of St. Sebastian. It kept the stained glass, the organ pipes and the acoustics, and replaced God with a sound system the size of a car.'),
    L('osmosis','Two hundred heartbeats, all in time with the kick drum. It\'s like standing inside one enormous animal.',{pass:6}),
    L('pedigree','Elysium is below: neutral ground. No feeding, no violence, no exceptions. Up here is merely a nightclub, which is to say: anything goes.',{pass:7}),
    L('tenant','I hate this place. Séverine adores it. That should tell you everything.'),
    L('nostalgia','You came here, before. On a Thursday. You know where the coat check is.',{if:S=>S.past==='promoter'}),
    T('Every voice in your head goes a little soft at the edges. The glass, the light, the music: it pulls at you like a hand on your sleeve.',{if:S=>S.clan==='choir'}),
    L('sundial','Choir blood. Aesthetic Rapture. Nocturne −2 until you stop and look at something beautiful. Pick something.',{if:S=>S.clan==='choir'})]);}});
H.barks.reliquary=[{id:'rq_dance',s:'parasite',at:[5.4,1,3.9],r:2,t:'Sweat, MDMA, cheap vodka, someone\'s insulin. A buffet.'},{id:'rq_organ',s:'echo',at:[0.4,2,2.6],r:1.6,t:'One of the organ pipes isn\'t a pipe. Something is listening through it.',pass:8}];
H.use.window=async(S,G)=>{S.flags.admired_reliquary=1;G.refresh();return G.say([T('You stop in the middle of the dance floor and look up. St. Sebastian, in red and gold glass, shot full of arrows, looking up at a God who isn\'t answering. The bass makes the arrows tremble.'),L('nostalgia','It\'s beautiful. It\'s so stupidly beautiful.'),L('sundial','There. The pull lets go. Nocturne\'s back.')]);};
H.use.stage=async(S,G)=>G.say([T('The DJ is a girl of about nineteen with a shaved head and a laptop covered in stickers. She doesn\'t look up. Behind her, the saint\'s glass eyes are fixed on the ceiling.'),L('web','There\'s a ventilation grate behind the booth, big enough to crawl into. It runs toward the back of the building. Toward the stairs.',{pass:9,do:S=>S.flags.knowsVent=1})]);
H.use.organ=async(S,G)=>G.say([T('Brass pipes, thirty feet of them, rising into the dark. Most are dummies now. The real organ was sold in 1974.'),L('echo','One pipe on the left has a tiny hole bored into it, at ear height. Something is in there. Bone, wired up.',{pass:9,do:S=>S.flags.sawBug=1}),L('tenant','Mother Soot\'s little ears. She hears everything said in this room. She has for forty years.',{if:S=>S.flags.sawBug})]);
H.use.bar=async(S,G)=>G.talk('bar.0');H.use.bartender=async(S,G)=>G.talk('bar.0');
N['bar.0']={lines:[L('bartender','What\'ll it be? We do a Bloody Mary that\'s, you know. Ironic.'),L('parasite','The house red in the brown bottle is not wine. It\'s O-negative, cut with grenadine. For the downstairs crowd.',{pass:8})],
  opts:[O('"Who\'s holding court downstairs?"','bar.court',{once:true}),O('"The brown bottle. ($20)"','bar.blood',{if:S=>(S.cash||0)>=20&&!S.flags.barBlood}),O('"Nothing. Thanks."',null,{end:true,leave:true})]};
N['bar.court']={lines:[L('bartender','The Keeper. Lady S. Every night from eleven, in the crypt. Tiny decides who goes down. Nobody else.'),L('bartender','Tip: he hates being called Tiny by people he doesn\'t know.')],next:'bar.0'};
N['bar.blood']={lines:[T('She pours it into a wine glass with a wink. It\'s cold and sweet and full of somebody\'s Saturday night.',{do:(S,G)=>{G.cash(-20,'House red');S.flags.barBlood=1;G.feed(2,'sanguine','house red',{kind:'bag'});}}),L('bartender','Don\'t tell the Keeper. It\'s supposed to be downstairs only.')],next:'bar.0'};

// Tiny: the velvet rope
H.use.tiny=async(S,G)=>G.talk(S.flags.vipOK?'tiny.ok':'tiny.0');
N['tiny.0']={enter:(S,G)=>{G.focus(['you','tiny'],.8);G.look('tiny','you');},lines:[
  T('Six foot six of black suit, folded arms, a velvet rope and a face like a closed bank. A tiny earpiece. A tiny pair of reading glasses in his breast pocket.'),
  L('tiny','Private.'),
  L('pulse','He\'s grey under the eyes. Swollen ankles. He\'s ill, and he\'s hiding it.',{pass:10}),
  L('tiny','I know you.',{if:S=>S.past==='promoter',do:(S,G)=>G.fact('tiny','faces')}),
  L('tiny','Huh. You\'ve been here before. Not like this.',{if:S=>S.past!=='promoter'&&S.flags.tinySeen})],
  opts:[O('"I\'m the Sheriff\'s. Lady Séverine is expecting me."','tiny.sheriff'),
    O('"Desmond. It\'s me. You put me on the list every Thursday for three years."','tiny.promoter',{if:S=>S.past==='promoter'}),
    C('stagecraft',9,'Act like you\'re bored and expected. Wave vaguely at the stairs.','tiny.bluffOk','tiny.bluffNo',{id:'tiny_bluff',mod:(S,G)=>G.equipped('dinnerjacket')?2:0}),
    C('pulse',10,'"How long since your last dialysis?"','tiny.kidney','tiny.kidneyNo',{id:'tiny_kid',once:'tiny_kid'}),
    O('Slip him fifty dollars.','tiny.bribe',{if:S=>(S.cash||0)>=50,once:'tiny_bribe'}),
    O('Kneel: "Let me pass."','tiny.kneel',{ab:'kneel'}),
    O('Veil of Dust: stand still in the shadow by the arch until he looks away.','tiny.veil',{ab:'veil'}),
    O('Shadow-Step past the rope.','tiny.veil',{ab:'shadowstep'}),
    O('Find another way down.','tiny.other',{if:S=>S.flags.knowsVent}),
    O('Leave him be.',null,{end:true,leave:true})]};
N['tiny.sheriff']={lines:[L('tiny','The Sheriff comes himself. The Sheriff does not send people.'),L('tiny','Unless.',{if:(S,G)=>G.equipped('greatcoat')||G.has('signet')}),
  L('tiny','That\'s his coat. And his ring. ...Go on, then. And whoever you are: she\'s in a mood.',{if:(S,G)=>G.equipped('greatcoat')&&G.equipped('signet'),do:S=>S.flags.vipOK=1})],
  next:S=>S.flags.vipOK?'tiny.open':'tiny.0'};
N['tiny.promoter']={lines:[T('Something moves behind the bank-vault face. He takes the reading glasses out of his pocket, puts them on, and looks at you properly.'),
  L('tiny','...You. They said you OD\'d. They said you were in a drawer at St. Jude\'s.'),L('tiny','You look like it. Go on down. I never saw you.',{do:(S,G)=>{S.flags.vipOK=1;G.meet('tiny');G.fact('tiny','name');G.fact('tiny','faces');G.rel('tiny',1);}})],next:'tiny.open'};
N['tiny.bluffOk']={lines:[L('tiny','...Mm.'),T('He unhooks the rope without looking at you, the way you\'d hold a door for a draught.',{do:S=>S.flags.vipOK=1})],next:'tiny.open'};
N['tiny.bluffNo']={lines:[L('tiny','No.'),L('stagecraft','You overdid the wave.')],next:'tiny.0'};
N['tiny.kidney']={lines:[T('He looks at you for a long moment. The bank-vault face cracks along a fault line you didn\'t know was there.'),
  L('tiny','...Eleven days. I can\'t do three sessions a week and work this door. Insurance won\'t touch it. They\'ll put me on a list.'),
  L('tiny','You tell anyone, I\'ll break you in half. ...Go down. Five minutes. If she asks, you came down the vent.',{do:(S,G)=>{S.flags.vipOK=1;G.meet('tiny');G.fact('tiny','name');G.fact('tiny','kidney');G.rel('tiny',1);G.task('s_tiny');S.quests.note_s_tiny='Tiny is missing dialysis to keep his job. St. Jude\'s has the supplies, or your blood could keep him going.';}})],next:'tiny.open'};
N['tiny.kidneyNo']={lines:[L('tiny','Excuse me?'),L('pulse','Wrong door. You knocked too hard.',{do:(S,G)=>G.rel('tiny',-1)})],next:'tiny.0'};
N['tiny.bribe']={lines:[T('He looks at the fifty. He looks at you. He takes it, folds it into his breast pocket next to the glasses, and doesn\'t move.'),L('tiny','That\'s for not throwing you out. Getting in costs more.',{do:(S,G)=>G.cash(-50,'Tiny')}),L('gutter','He\'s not for sale. You just paid him to tell you so.')],next:'tiny.0'};
N['tiny.kneel']={lines:[T('You say it softly. His hand unhooks the rope. His eyes don\'t follow it; they stay on you, puzzled, like a man watching his own hand from across a room.',{do:S=>S.flags.vipOK=1}),L('tiny','...Go on, then.')],next:'tiny.open'};
N['tiny.veil']={lines:[T('You go still in the black under the arch. He scans the floor, the bar, the stairs. His gaze goes through you like a draught. When he turns to hush a girl crying by the coat check, you are already on the stairs.',{do:S=>S.flags.vipOK=1})],next:'tiny.open'};
N['tiny.other']={lines:[T('The grate behind the DJ booth comes away with two fingers. The vent is tight and dusty and smells of a hundred years of incense. You come out of a grille in the crypt wall with cobwebs in your hair.',{do:S=>{S.flags.vipOK=1;S.flags.ventEntry=1;}})],cs:async(G,S)=>{G.dlgHide();await G.enterRoom('vip',{x:1.2,z:5.4,ry:0.6});},end:true};
N['tiny.open']={lines:[L('tiny','Stairs are steep. Mind your head. And don\'t feed down there. She\'ll know.')],end:true};
N['tiny.ok']={lines:[L('tiny','Still here. Still private. Go on, if you\'re going.')],end:true};
H.exit.toVip=async(it,S,G)=>{if(!S.flags.vipOK){await G.say([L('tiny','Private.'),T('A hand the size of a dinner plate settles on your chest. Very gently.')]);return false;}};

// the VIP crypt: Lady Séverine
pushPop('vip',(S,G)=>{if(!S.flags.sevGoneN1||S.night>1){const a=G.addActor('severine',NL.CHARS.severine.spec,{x:3.6,z:0.78,ry:0.15,breathes:false,pose:'sit'});a.solid=true;}});
pushNpc('vip',(S,G)=>G.actor('severine')?{id:'severine',actor:'severine',label:()=>S.flags.metSeverine?'Lady Séverine':'Woman in red',stand:[3.6,2.9],face:[3.6,0.8]}:null);
pushEnter('vip',async(S,G)=>{A.music('mirror');if(S.night===1&&!S.flags.metSeverine){G.cine(true);G.focus(['you','severine'],1);await G.wait(.6);G.cine(false);await G.talk('sev.0');}});
H.use.severine=async(S,G)=>G.talk(S.flags.keeperDone?'sev.after':'sev.0');
H.use.portraits=async(S,G)=>G.say([T('Two portraits in heavy gilt. On the left, a woman in red, painted in 1890-something, looking exactly as she does tonight. On the right, a man with a crane on his signet ring, looking bored.'),L('tenant','She had mine hung opposite hers so she could look down on me all night. That is what passes for affection in the Gilded Court.')]);
H.use.vipmirror=async(S,G)=>{S.flags.mirror_vip=1;const ghost=NL.CLANS[S.clan]&&NL.CLANS[S.clan].ghost;return G.say([T(ghost?'An antique mirror. It shows the booth, the candles, Lady Séverine. Not you.':'An antique mirror, the silver going brown at the edges like an old photograph. You, and behind you, a woman in red watching you look.'),L('pedigree','Elysium keeps mirrors so the Hollow know they\'re not welcome. Old manners.',{if:S=>S.clan==='hollow'})]);};
H.use.coffins=async(S,G)=>G.talk('haven.crypt');
N['haven.crypt']={lines:[T('Three guest coffins in the wall niches, rosewood, brass-handled, lined with red silk. A card in a holder on each: RESERVED.'),
  L('pedigree','Guest coffins of Elysium. Sleeping here is a privilege, and a debt.')],
  opts:[O('Sleep here until tomorrow night.',null,{if:S=>S.flags.sevAlly&&NL.Camp.canSleep(S),end:true,do:()=>setTimeout(()=>NL.Camp.sleep('crypt'),300)}),
    O('They\'re reserved. Not for you. Not yet.',null,{if:S=>!S.flags.sevAlly,end:true,leave:true}),
    O('Too early to sleep.',null,{if:S=>S.flags.sevAlly&&!NL.Camp.canSleep(S),end:true,leave:true}),O('Leave them.',null,{end:true,leave:true})]};

N['sev.0']={enter:(S,G)=>{G.focus(['you','severine'],.75);G.look('severine','you');G.look('you','severine');},lines:[
  T('Candlelight, red velvet, a woman alone in a booth built for twelve. Black hair, a dress the color of the inside of a cherry, and stillness of a kind no living thing can manage. She does not look up until you are close enough to touch.'),
  L('severine',S=>S.flags.ventEntry?'Through the *vent*. How very rustic. Absalom never used the stairs either; he thought them beneath him.':'You are not Absalom Vane.'),
  L('severine','You are wearing his coat, which is a crime, and his smell, which is worse. Sit. No. Stand. I want to see all of you.'),
  L('pedigree','Lady Séverine Marchetti. Keeper of Elysium, voice of the Gilded Court in the Ward. Choir blood. Do not lie to a Choir. They can *hear* the lie in your throat.',{pass:6,do:(S,G)=>{S.flags.metSeverine=1;G.meet('severine');G.fact('severine','feud');}}),
  L('tenant','Hello, Séverine. You look tired. She can\'t hear me. She looks tired.'),
  L('severine','Where is he?')],next:'sev.start'};
N['sev.start']={enc:'keeper',win:'sev.win',lose:S=>S.flags.keeperOut==='truth'?'sev.truth':'sev.lose'};
ENC.keeper={title:'THE KEEPER',sub:'Lady Séverine · the Gilded Court',music:'tense',after:'mirror',
  prog:{name:'Credibility',max:6,color:'#e2c27e'},threat:{name:'Suspicion',max:8,color:'#ff6a8a'},
  focus:G=>G.focus(['you','severine'],.7),
  start(S,G){let t=2;if(S.flags.sevWary)t+=2;if(S.flags.sevCalm)t-=1;if(S.flags.ventEntry)t+=1;if(G.equipped('greatcoat'))t+=1;return {prog:S.flags.sevHound?1:0,threat:Math.max(0,t)};},
  intro:[L('severine','I asked you a question. Absalom has missed three appointments in a row. In a hundred and twelve years he has never missed one. Where is he?')],
  round(st,S,G){const Q=[
    ()=>({lines:[L('severine','He collected a *package* on Sunday night. Something that came in by boat. Did he give it to you?')],threat:1}),
    ()=>({lines:[L('severine','Who else knows you\'re working for him? The detective? The Syndicate? The old woman in the sewers?')]}),
    ()=>({lines:[T('She turns her wine glass a quarter-turn on the table. Then another.'),L('severine','There was a... disturbance at the butcher\'s on Monday morning. People heard things. What did *you* hear?')],threat:1}),
    ()=>({lines:[L('severine','Give me your hand. I want to taste whose blood is in it.')],threat:1}),
    ()=>({lines:[L('severine','Last chance, little hound. Convince me.')]})];return st.round<Q.length?Q[st.round]():null;},
  moves(st,S,G){const r=st.round,M=[];
    M.push(C('pedigree',10,'Answer in the forms of the Court: "The Sheriff\'s business is his own until he reports to the Prince."',null,null,{id:'k_ped'+r,mod:(S,G)=>G.equipped('porcelain')?2:0,ok:st=>{st.prog+=2;return [L('severine','...Correct. Infuriatingly correct. He trained you well.')];},no:st=>{st.threat+=2;return [L('severine','You said "the Prince" as if you\'d never met him. You haven\'t, have you.')];}}));
    M.push(C('stagecraft',9,'Play the hound: bored, loyal, faintly contemptuous of her.',null,null,{id:'k_stg'+r,ok:st=>{st.prog+=2;return [L('severine','Oh, you\'re *his*, all right. He always did like them rude.')];},no:st=>{st.threat+=2;return [L('severine','You\'re trying very hard. His people never try.')];}}));
    M.push(C('velvet',10,'Flatter her. Gently. The way he never did.',null,null,{id:'k_vel'+r,ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [L('severine','Careful. I might start to like you, and then where would we be.')];},no:st=>{st.threat+=2;return [L('severine','Don\'t. I can hear the lie in your throat. It\'s off-key.')];}}));
    if(r===0)M.push(C('web',10,'"Package? He doesn\'t tell me about packages. Who told *you* about it?"',null,null,{id:'k_web',ok:(st,S,G)=>{st.prog+=2;S.flags.sevPackage=1;return [L('severine','...Nobody. A rumour. A boat.'),L('web','She knows exactly what it is. She knows exactly who brought it in. She paid someone to find out.')];},no:st=>{st.threat+=1;return [L('severine','Answer my question with a question once more and I will have you thrown into the street.')];}}));
    if(r===2)M.push(C('rigor',9,'Say nothing. Let the silence do the work.',null,null,{id:'k_rig',ok:st=>{st.prog+=2;return [T('You stand perfectly still. The candles gutter. She looks away first.'),L('severine','...You are very like him. I hate that.')];},no:st=>{st.threat+=1;return [L('severine','Statues are for gardens.')];}}));
    if(r===3&&G.equipped('signet'))M.push({t:'Give her your hand. The one with his ring on it.',ok:(st,S,G)=>{st.prog+=3;st.threat+=1;return [T('She takes your hand. She looks at the ring for a long time. Then she puts her mouth to the inside of your wrist, not quite a bite, and goes very still.'),L('severine','...His. All the way down. What *did* he do to you?')];}});
    if(r===3)M.push(C('stagecraft',11,'"Elysium forbids feeding, Keeper. Even a taste."',null,null,{id:'k_eli',ok:st=>{st.prog+=2;return [L('severine','Ha! Quoting my own rules at me. In my own crypt.'),L('severine','Fine. Keep your blood.')];},no:st=>{st.threat+=2;return [L('severine','The rules are for guests. You are not a guest. You are a delivery.')];}}));
    if(r===4)M.push(C('velvet',11,'"He\'ll come himself on Friday. He told me to tell you he\'s bringing the Prince a culprit."',null,null,{id:'k_fri',ok:(st,S,G)=>{st.prog+=3;S.flags.sevFriday=1;return [T('Something flickers in her face and is put away again, fast, like a knife into a sleeve.'),L('severine','...Is he. How very like him.')];},no:st=>{st.threat+=3;return [L('severine','He would never send that message through you. He would never send it at all.')];}}));
    // abilities that work on vampires
    const ab=(id,t,fn,extra)=>M.push(Object.assign({t,ab:id,ok:fn},extra||{}));
    if(!st.cold)ab('coldread','Hear the thing she\'s loudest about not saying.',(st,S,G)=>{st.cold=true;st.prog+=2;G.fact('severine','lance');S.flags.sevLance=1;return [T('Her silence is a single bright image, held so hard it shakes: a long white tube on a velvet cloth. *A surgical lance.* And under it: *does it know? does it KNOW?*'),L('web','She\'s terrified you know about the lance. Remember that. That is the knife you hold.')];});
    if(!st.blue)ab('blueblood','Feel who she owes, and how much.',(st,S,G)=>{st.blue=true;st.prog+=1;S.flags.sevDebt=1;return [T('The room\'s debts come to you like a smell of old money: she owes the Prince a favour, and someone underground a great deal of cash, and the old woman in the sewers a secret.'),L('pedigree','She\'s in debt to the Syndicate. The Court\'s Keeper owes a chop-shop. That is not a small thing.')];});
    ab('siren','Siren\'s Pitch: "Did you kill Absalom Vane?"',(st,S,G)=>{st.prog+=1;st.threat+=2;S.flags.sevSiren=1;return [L('severine','Not with my own hands.'),T('She hears herself say it. Her eyes go wide and then very, very narrow.'),L('severine','...Clever. Choir against Choir. Do it again and I will have your tongue on a plate.')];},{once:'k_siren'});
    ab('splinter','Splinter: put the lance in her head and leave it there.',(st,S,G)=>{st.prog+=3;S.flags.sevSplinter=1;return [T('You give her a sliver of it: white light in a long tube, the hiss, the smell. She flinches back against the velvet as if burned.'),L('severine','Get *out* of my head.')];},{once:'k_spl'});
    ab('encore','Encore: let her hear herself ask "Where is he?" five more times.',(st)=>{st.prog+=1;st.threat=Math.max(0,st.threat-2);return [T('She asks it again. And again. On the fourth time her voice cracks, and on the fifth she stops, and puts her glass down, and for a second looks like what she is: very old and very frightened.')];},{once:'k_enc'});
    ab('dejavu','Live her next question, then rewind.',(st)=>{st.threat=Math.max(0,st.threat-2);st.prog+=1;return [T('You hear her ask about the freezer. You hear yourself stumble. You are back, and you already have the answer.')];},{once:'k_dv'});
    M.push({t:'Tell her the truth. "He\'s dead. He made me drink him."',ok:(st,S,G)=>{st.result='lose';S.flags.keeperOut='truth';return [T('The candles stop moving.')];}});
    M.push(C('apex',12,'Stare her down. You have his blood. Use it.',null,null,{id:'k_apex'+r,mod:(S,G)=>G.equipped('signet')?2:0,ok:st=>{st.prog+=2;st.threat+=1;return [T('For a second there are two Sheriffs in the room, and one of them is you.'),L('severine','...Don\'t.')];},no:st=>{st.threat+=3;return [L('severine','Oh, *please*.')];}}));
    return M;},
  decide(st){return st.prog>=5||st.threat<5?'win':'lose';},
  outro(r,st,S,G){S.flags.keeperDone=1;S.flags.keeperOut=S.flags.keeperOut||r;return [];}
};
N['sev.win']={lines:[L('severine','Very well. You are his hound, and he is *busy*, and I am to wait like a debutante. I don\'t believe a word of it, but I believe *you* believe it, and that is almost as useful.'),
  L('severine','The Tribunal sits on Friday, at Platform 0, because the Prince likes theatre. Seven mortals are missing from this Ward and the Prince wants someone to burn for it. Absalom promised me a name.'),
  L('severine','Bring me the package he collected on Sunday, and I will make sure the name is not yours.',{do:(S,G)=>{G.fact('severine','friday');S.flags.sevAlly=1;S.flags.sevWantsVessel=1;G.promise('sevVessel','Bring Séverine the Sheriff\'s package by Friday');G.offer('leash');}}),
  L('pedigree','She has just offered you a deal and a threat in one sentence. That is how the Court says hello.'),
  L('severine','There are guest coffins in the wall if you need them. Don\'t snore.',{do:(S,G)=>{G.cash(200,'"Expenses," says the Keeper');G.task('reliquary','done');G.xp(30,'You survived the Keeper');}})],end:true};
N['sev.lose']={lines:[L('severine','No. No, I don\'t think so.'),
  T('She stands. It is like watching a knife being drawn.'),
  L('severine','He\'s dead, isn\'t he. And you\'re the one wearing him.'),
  L('severine','Get out of my Elysium. Come back on Friday, to the Tribunal, and we\'ll see whose name the Prince reads out. I know which one I\'d bet on.',{do:(S,G)=>{S.flags.sevKnows=1;S.flags.sevEnemy=1;G.task('reliquary','done');G.rel('severine',-2);}}),
  L('sundial','She\'ll send someone. Not tonight. But soon. Somebody with a nose.')],cs:async(G,S)=>{G.dlgHide();S.flags.sevGoneN1=1;await G.enterRoom('reliquary',{x:9.8,z:2.4,ry:-2.6});},end:true};
N['sev.truth']={lines:[L('severine','...'),
  L('severine','Say it again.'),
  L('you','"He\'s dead. He ordered me to drink him. I don\'t remember why."'),
  T('She laughs. It is not a nice laugh, and then it is not a laugh at all, and she puts the back of her wrist against her mouth and holds it there.'),
  L('pulse','Grief. Real. And underneath it something else: relief. And under that: fear. Of you.',{pass:8}),
  L('severine','A hundred years I wanted him gone, and he goes like *that*, into some nobody in a freezer.'),
  L('severine','Listen to me, nobody. Everyone in this Ward wants what he carried. If they learn you drank him, they will want what\'s *in* you. Keep your mouth shut. Bring me his package before Friday, and I will stand beside you at the Tribunal. Fail me, and I will light the pyre myself.',{do:(S,G)=>{S.flags.sevKnows=1;S.flags.sevAlly=1;S.flags.sevWantsVessel=1;S.flags.sevTruth=1;G.fact('severine','friday');G.promise('sevVessel','Bring Séverine the Sheriff\'s package by Friday');G.task('reliquary','done');G.xp(30,'The truth, for once');G.rel('severine',1);}}),
  L('tenant','She is lying about the pyre. She would hire someone to light it.')],end:true};
N['sev.after']={lines:[L('severine',S=>S.flags.sevEnemy?'You\'re still here. That\'s brave, or stupid. In this city they\'re the same thing.':'Is there something else, little hound? I have a Ward to keep.')],
  opts:[O('"What was in the package?"','sev.package',{once:true,if:S=>S.flags.sevAlly}),O('"What happens at the Tribunal?"','sev.tribunal',{once:true}),O('Leave her.',null,{end:true,leave:true})]};
N['sev.package']={lines:[L('severine','Something old. Something that should have stayed at the bottom of the sea, in a ship that sank in 1911. Absalom thought it would save him.'),L('severine','It won\'t save anyone. It will only decide who rules this Ward. Bring it to me and that will be *us*.'),L('web','"Save him." Save him from what? He was the Sheriff.',{pass:8})],next:'sev.after'};
N['sev.tribunal']={lines:[L('severine','Friday, after midnight, Platform 0, under the Switchyard. The Prince sends a Magistrate. Every faction in the Ward stands around a hole in the ground and accuses each other until someone breaks. Then that someone burns at dawn, through the skylight grate.'),L('sundial','Through the skylight. At dawn. That is a sentence with only one ending.')],next:'sev.after'};

/* =====================================================================
   THE PAWN & COFFIN · Gideon
   ===================================================================== */
pushPop('pawn',(S,G)=>{G.addActor('gideon',NL.CHARS.gideon.spec,{x:2.7,z:1.05,ry:0.05,breathes:true,pose:'lean'});});
pushNpc('pawn',(S,G)=>({id:'gideon',actor:'gideon',label:()=>S.dos.gideon?'Gideon':'Old man',stand:[2.7,2.9],face:[2.7,1.1]}));
H.use.gideon=async(S,G)=>G.talk(S.flags.gideonMet?'gd.hub':'gd.0');H.use.counter=H.use.gideon;
N['gd.0']={enter:(S,G)=>{G.focus(['you','gideon'],.8);G.look('gideon','you');},lines:[
  T('An old man in a cardigan behind a glass case of other people\'s wedding rings. A jeweller\'s loupe pushed up on his forehead like a third eye. On the wall behind him, eleven clocks, all stopped at different times.'),
  L('gideon','We close at sunrise. Which, for most of my customers, is when they open. What can I do for you?'),
  L('pulse','Mortal. Seventy-something. Not afraid of you at all. Fascinated, if anything.',{pass:8}),
  L('gideon','Ah. You\'re wearing Absalom\'s coat. He owed me forty dollars.',{if:(S,G)=>G.equipped('greatcoat'),do:(S,G)=>{S.flags.gideonDebt=1;}}),
  T(null,{do:(S,G)=>{S.flags.gideonMet=1;G.meet('gideon');G.fact('gideon','name');}})],next:'gd.hub'};
N['gd.hub']={opts:[
  O('"I need somewhere to sleep through the day."','gd.coffin',{if:S=>!S.flags.coffinPaid||S.flags.coffinPaid<S.night}),
  O('"Show me what you\'ve got for sale."','gd.shop'),
  O('"What\'s the safe in the corner?"','gd.safe',{once:true}),
  O('Ask about the cracked wristwatch in the window.','gd.watch',{if:S=>!S.flags.gotWatch}),
  O('"What would you give me for his ring?"','gd.ring',{if:(S,G)=>G.has('signet')&&!S.flags.ringOffer,once:true}),
  O('Pay Absalom\'s forty dollars.','gd.debt',{if:S=>S.flags.gideonDebt&&!S.flags.gideonPaid&&(S.cash||0)>=40}),
  O('"Goodnight, Gideon."',null,{end:true,leave:true})]};
N['gd.coffin']={lines:[L('gideon','Box rental: one hundred dollars a day, cash. Lead-lined, light-tight, alarm on the lid, sunrise guaranteed or your next day free, which is a joke I make every night and nobody laughs at.'),L('gideon','Or a favour. I take favours. I keep a ledger.')],
  opts:[O('Pay $100.','gd.coffinPaid',{if:S=>(S.cash||0)>=100}),
    O('"I\'ll owe you a favour."','gd.coffinFavor',{if:S=>!S.flags.gideonFavor}),
    C('velvet',10,'"Absalom always said your boxes were the best in the city. He\'d want me to have a discount."','gd.coffinCheap','gd.coffinNo',{id:'gd_cheap'}),
    O('"Not tonight."','gd.hub')]};
N['gd.coffinPaid']={lines:[T('He counts the money twice, licks his thumb, counts it again.',{do:(S,G)=>{G.cash(-100,'Coffin-box');S.flags.coffinPaid=S.night;}}),L('gideon','Third box from the bottom. Knock twice if you need me. I\'ll ignore it, but it\'s good to have hobbies.')],next:'gd.hub'};
N['gd.coffinFavor']={lines:[L('gideon','A favour it is. I\'ll write it down.'),T('He writes it down: a date, your face in three adjectives, and the word FAVOUR underlined twice.',{do:(S,G)=>{S.flags.gideonFavor=1;S.flags.coffinPaid=S.night;G.promise('gideonFavor','Owe Gideon one favour, no questions');}}),L('web','An open-ended favour, to a man who keeps a ledger. That will come due at the worst possible moment.')],next:'gd.hub'};
N['gd.coffinCheap']={lines:[L('gideon','Did he. Absalom never said a kind word about anyone in his life. ...Fifty. Because you lied so nicely.')],opts:[O('Pay $50.','gd.coffinFifty',{if:S=>(S.cash||0)>=50}),O('"Never mind."','gd.hub')]};
N['gd.coffinFifty']={lines:[T('Fifty dollars, counted three times.',{do:(S,G)=>{G.cash(-50,'Coffin-box');S.flags.coffinPaid=S.night;}})],next:'gd.hub'};
N['gd.coffinNo']={lines:[L('gideon','Absalom thought my boxes were "cheap and depressing". He said it every time.')],next:'gd.coffin'};
H.use.coffinbox=async(S,G)=>G.talk('haven.pawn');
N['haven.pawn']={lines:[T('Three coffin-boxes stacked like shipping crates, brass-cornered, each with a little green light on the lid. Inside the third: grey foam, a pillow, and a handwritten card: PLEASE DO NOT DIE IN THE BOX. — MGMT.')],
  opts:[O('Climb in and sleep until tomorrow night.',null,{if:S=>S.flags.coffinPaid===S.night&&NL.Camp.canSleep(S),end:true,do:()=>setTimeout(()=>NL.Camp.sleep('pawn'),300)}),
    O('Too early to sleep.',null,{if:S=>S.flags.coffinPaid===S.night&&!NL.Camp.canSleep(S),end:true,leave:true}),
    O('You haven\'t paid. Talk to Gideon.',null,{if:S=>S.flags.coffinPaid!==S.night,end:true,leave:true})]};
N['gd.shop']={lines:[L('gideon','Everything has a price and most of it is cursed. Take your pick.')],
  opts:[O('Tinted designer aviators. ($60)','gd.buy',{if:(S,G)=>!G.has('aviators')&&(S.cash||0)>=60,do:(S,G)=>{G.cash(-60,'Aviators');G.give('aviators');}}),
    O('A velvet dinner jacket that smells of 1981. ($150)','gd.buy',{if:(S,G)=>!G.has('dinnerjacket')&&(S.cash||0)>=150,do:(S,G)=>{G.cash(-150,'Dinner jacket');G.give('dinnerjacket');}}),
    O('A box of latex gloves from a funeral home. ($10)','gd.buy',{if:(S,G)=>!G.has('latex')&&(S.cash||0)>=10,do:(S,G)=>{G.cash(-10,'Gloves');G.give('latex');}}),
    O('A cassette Walkman with a tape labelled 89 BPM. ($30)','gd.buy',{if:(S,G)=>!G.has('walkman')&&(S.cash||0)>=30&&S.night>=2,do:(S,G)=>{G.cash(-30,'Walkman');G.give('walkman');}}),
    O('"Just looking."','gd.hub')]};
N['gd.buy']={lines:[L('gideon','Pleasure. No refunds. No exchanges. No ghosts, guaranteed, or your money back. That one\'s also a joke.')],next:'gd.shop'};
N['gd.safe']={lines:[L('gideon','Fished it out of the river by the Switchyard on Saturday. Somebody threw it off the old rail bridge, which tells you whatever\'s in it was worth more sunk than kept.'),
  L('gideon','Can\'t open it. Combination dial, and a lock I\'ve never seen. I\'ll split whatever\'s inside, fifty-fifty, with whoever can.',{do:(S,G)=>{G.fact('gideon','safe');G.task('s_safe');S.quests.note_s_safe='Gideon\'s river safe: a combination dial and an odd lock. He\'ll split the contents with whoever opens it.';}}),
  L('abattoir','Fingers in the tumblers. If your fingers bent the wrong way, you could feel every one.',{if:S=>S.clan==='butchers'})],next:'gd.hub'};
H.use.safe=async(S,G)=>G.talk('safe.0');
N['safe.0']={lines:[T('A squat green safe, river-mud still in its hinges, a combination dial and a keyhole shaped like a little crown.')],
  opts:[O('Bone-Key: dislocate a finger and feel the tumblers.','safe.open',{ab:'bonekey',if:S=>!S.flags.safeOpen}),
    O('Iron Claws: tear the door off.','safe.open',{ab:'claws',if:S=>!S.flags.safeOpen}),
    C('abattoir',12,'Listen to the tumblers with your fingertips.','safe.open','safe.no',{id:'safe_ab',if:S=>!S.flags.safeOpen}),
    O('Try the number from the drowned man\'s nerves: 19-78-06.','safe.open',{if:S=>S.flags.safeCode&&!S.flags.safeOpen}),
    O('Leave it.',null,{end:true,leave:true})]};
N['safe.no']={lines:[T('Click. Click. Nothing. The safe has been at the bottom of a river; it has had more patience than you for longer.')],end:true};
N['safe.open']={lines:[T('The door swings open with a gasp of river air. Inside: a water-stained envelope, and in it, six Polaroids, fused at one corner.',{do:(S,G)=>{S.flags.safeOpen=1;G.give('polaroids');G.task('s_safe','done');G.fact('severine','polaroids');}}),
  T('Lady Séverine, 1978, in a room panelled in black marble that is not supposed to exist, doing something to a man in a chair that the Court has a word for, and the word is *treason*.'),
  L('gideon','Well. Fifty-fifty, I said. You keep the pictures. I\'ll keep the fact that I never saw them, which is worth more.'),
  L('web','Blackmail. Real, old, Court-ending blackmail. Whoever threw this in the river wanted it found eventually, or wanted to be the only one who knew where it was.')],end:true};
N['gd.watch']={lines:[T('In the window, between a ukulele and a glass eye: a cheap steel wristwatch with a cracked face. Gideon takes it out for you without being asked.'),
  L('gideon','Came in Monday morning, early. A young man, very pale, sold it for twenty dollars and didn\'t haggle. Said he wouldn\'t be needing the time any more.'),
  T('He turns it over. Engraved on the back, in a jeweller\'s script: a name. It is yours. You have no idea what it means.'),
  L('tenant','Ah. I wondered when you\'d trip over yourself.',{if:S=>!S.th.done.includes('amnesiac')})],
  opts:[O('Buy it back. ($40)','gd.watchBuy',{if:S=>(S.cash||0)>=40}),O('"Keep it. I don\'t want it."','gd.hub')]};
N['gd.watchBuy']={lines:[T('It doesn\'t tick. It was never going to.',{do:(S,G)=>{G.cash(-40,'Your own watch');G.give('wristwatch');S.flags.gotWatch=1;S.flags.frag_watch=1;G.task('x_name');S.quests.note_x_name='Fragments of who you were: a watch. There will be others: a chart, a mailbox, a reflection.';}}),
  L('nostalgia','Someone gave you this. For a birthday. You can almost see their hands.')],next:'gd.hub'};
N['gd.ring']={lines:[L('gideon','For the Signet of House Vane? Five hundred dollars and I\'d still be robbing you. It would be worth five thousand to the right Elder, and a stake through the heart to the wrong one.'),L('tenant','Sell my ring to a pawnbroker. Go on. I dare you.')],
  opts:[O('Sell it. ($500)','gd.ringSell'),O('"No. It stays with me."','gd.hub')]};
N['gd.ringSell']={lines:[T('He weighs it on a little brass scale, looks at it through the loupe for a long time, and puts it in a drawer that locks.',{do:(S,G)=>{G.take('signet');G.cash(500,'The Sheriff\'s ring');S.flags.ringSold=1;G.sync(-8,'You sold his ring');}}),L('tenant','...Well. Now I *am* dead.'),L('web','A Hound can smell that ring. It\'s in a drawer now, not on your hand. That might matter.')],next:'gd.hub'};
N['gd.debt']={lines:[T('You count out forty dollars. He looks at it as though you have handed him a live bird.',{do:(S,G)=>{G.cash(-40,'Absalom\'s debt');S.flags.gideonPaid=1;G.rel('gideon',2);}}),L('gideon','In thirty years he never once paid me back. You\'re a very strange kind of vampire.'),L('gideon','For that: the drowned man who came out of the river with my safe is in St. Jude\'s morgue. If you were the kind who could ask the dead things, he might have an opinion about the combination.',{do:S=>S.flags.safeHint=1})],next:'gd.hub'};
H.use.window=async(S,G)=>S.room==='pawn'?G.talk('gd.watch'):G.say([T('Stained glass.')]);
// the choir's window in the club shares the id; route by room
const winUse=H.use.window;H.use.window=async(S,G)=>{if(S.room==='pawn')return G.talk('gd.watch');S.flags.admired_reliquary=1;G.refresh();return G.say([T('You stop in the middle of the dance floor and look up. St. Sebastian, in red and gold glass, shot full of arrows, looking up at a God who isn\'t answering. The bass makes the arrows tremble.'),L('nostalgia','It\'s beautiful. It\'s so stupidly beautiful.'),L('sundial','There. The pull lets go. Nocturne\'s back.')]);};

/* =====================================================================
   ST. JUDE'S NIGHT CLINIC · Dr. Elena Rostova
   ===================================================================== */
pushPop('stjude',(S,G)=>{if((S.night<4||S.flags.rostovaClinic)&&!S.flags.rostovaDead)G.addActor('rostova',NL.CHARS.rostova.spec,{x:4.3,z:0.75,ry:0.25,breathes:true,pose:'idle'});
  G.addActor('nurse',NL.EXTRAS.nurse.spec,{x:7.9,z:2.4,ry:-2.6,breathes:true,pose:'wipe'});});
pushNpc('stjude',(S,G)=>[G.actor('rostova')?{id:'rostova',actor:'rostova',label:()=>S.dos.rostova?'Dr. Rostova':'Doctor',stand:[4.3,2.6],face:[4.3,0.8]}:null,{id:'nurse',actor:'nurse',label:'Night nurse',stand:[7.2,3.0],face:[7.9,2.4]}].filter(Boolean));
pushEnter('stjude',async(S,G)=>{if(!S.flags.enteredJude){S.flags.enteredJude=1;
  await G.say([T('St. Jude\'s Night Clinic: patron saint of lost causes, open nine till six. Three people in the waiting chairs, none of them in a hurry. Fluorescent light that makes everyone look like you.'),
    L('sundial','Bright. Too bright. Hospitals have UV sterilisers in the ceilings. Check the vents. Check them.',{pass:6}),
    L('nostalgia','You know this place. You know where they hide the good coffee. Second drawer, nurses\' station, behind the gauze.',{if:S=>S.past==='paramedic'}),
    T('The bright light finds the grey in your face and holds it up for everyone to see. A woman in the waiting chairs pulls her child closer.',{if:S=>S.clan==='wraiths'&&!(S.eq.face&&NL.ITEMS[S.eq.face].cover)}),
    L('stagecraft','Walking Cadaver. Under these lights you look exactly like what you are. Cover your face.',{if:S=>S.clan==='wraiths'&&!(S.eq.face&&NL.ITEMS[S.eq.face].cover)})]);}});
H.barks.stjude=[{id:'sj_fridge',s:'parasite',at:[0.4,1.3,2.75],r:1.6,t:'O-negative. Sixteen bags. Two are past their date. Nobody will miss those.'},{id:'sj_elev',s:'echo',at:[0.2,1.3,4.8],r:1.5,t:'Staff elevator. Basement only. There\'s a camera above it that isn\'t plugged in.',pass:7}];
H.use.nurse=async(S,G)=>G.say([L('nurse','If you\'re not bleeding, take a number. If you are bleeding, take two.'),L('nostalgia','Marisol. Her name is Marisol. She used to call you "baby" at four in the morning.',{if:S=>S.past==='paramedic'})]);
H.use.rostova=async(S,G)=>G.talk(S.flags.metRostova?'ro.hub':'ro.0');
N['ro.0']={enter:(S,G)=>{G.focus(['you','rostova'],.8);G.look('rostova','you');G.look('you','rostova');},lines:[
  T('A doctor behind the reception desk, writing up a chart standing. White coat, scrubs, hair pinned with a biro. She looks up and her pen stops.'),
  L('rostova','...You.'),
  L('pulse','Her pupils went wide. Her pulse went from seventy to a hundred and ten. She knows your face, and she did not expect to see it again.',{pass:7}),
  L('rostova','Sorry. You look like someone. I\'m Dr. Rostova. What can I do for you?',{do:(S,G)=>{S.flags.metRostova=1;G.meet('rostova');G.fact('rostova','name');}}),
  L('rostova',S=>S.past==='paramedic'?'...God. You *are* someone. You worked the ambulance out of here. They said you were dead. They said — Monday morning — no. Never mind.':'You\'re one of the ones who comes in for the fridge, aren\'t you. I can always tell. You don\'t blink enough.')],next:'ro.hub'};
N['ro.hub']={opts:[
  O('"The Sheriff sent me. He said to ask you what you saw."','ro.saw',{once:true,if:S=>S.flags.envelope}),
  O('"Who did you think I was?"','ro.who',{once:true}),
  O('"I need blood. I can pay."','ro.bags'),
  O('"Who came in on Monday morning?"','ro.monday',{once:true}),
  O('"What\'s in the basement?"','ro.basement',{once:true}),
  O('"Do you drive a white Volvo?"','ro.volvo',{once:true,if:S=>S.flags.volvo}),
  O('Listen to the thing she\'s loudest about not saying.','ro.cold',{ab:'coldread',once:true}),
  O('Taste the speck of blood on her cuff.','ro.vintage',{ab:'vintage',once:true}),
  O('Siren\'s Pitch: "What did you do on Monday morning?"','ro.siren',{ab:'siren',once:true}),
  O('"Thank you, Doctor."',null,{end:true,leave:true})]};
N['ro.saw']={lines:[L('rostova','...The Sheriff.'),T('She puts the pen down, very carefully, parallel to the edge of the chart.'),
  L('rostova','I saw ‹a man|a woman› in a long coat come in at half past four on Monday morning carrying a man over ‹his|her› shoulder. ‹He|She› signed him in as a John Doe, asked for a drawer in the morgue, and left. That\'s all. That\'s all I saw.'),
  L('pulse','Every word true. Every word chosen. She\'s describing *you*, and she\'s leaving something out.',{pass:9}),
  L('web','"‹A man|A woman› in a long coat." She didn\'t say the Sheriff. She said ‹a man|a woman›. She\'s describing you to your face and pretending she isn\'t.',{pass:8,do:(S,G)=>{G.fact('rostova','log');}})],next:'ro.hub'};
N['ro.who']={lines:[L('rostova','Someone who came in on Monday. Tall, pale, a long coat. In a hurry. Upset. You have the same... posture.'),L('rostova','People look alike at four in the morning. Everybody looks like a ghost.')],next:'ro.hub'};
N['ro.bags']={lines:[L('rostova','Forty a bag. Expired O-neg, two days past. It\'s for the free clinic. Don\'t look at me like that; the free clinic doesn\'t fund itself and the city certainly doesn\'t.',{do:(S,G)=>G.fact('rostova','bags')}),
  L('pedigree','A mortal who sells to Kindred and knows exactly what she\'s selling to. That is either a saint or a predator.',{pass:8})],
  opts:[O('Buy one bag. ($40)','ro.buy',{if:S=>(S.cash||0)>=40}),O('Buy three bags. ($120)','ro.buy3',{if:S=>(S.cash||0)>=120}),O('"Not now."','ro.hub')]};
N['ro.buy']={lines:[T('She goes to the fridge, comes back with a bag wrapped in a paper towel like a sandwich, and doesn\'t touch your fingers when she hands it over.',{do:(S,G)=>{G.cash(-40,'Blood bag');G.give('bloodbag');}})],next:'ro.hub'};
N['ro.buy3']={lines:[T('Three bags in a paper carrier from a sandwich shop. Very discreet.',{do:(S,G)=>{G.cash(-120,'Blood bags');G.give('bloodbag',3);}})],next:'ro.hub'};
N['ro.monday']={lines:[L('rostova','It\'s in the log. I can\'t show you the log.'),L('rostova','...The morgue camera\'s been broken since Monday. Somebody wiped the hard drive. The police are being very boring about it.',{do:(S,G)=>G.fact('rostova','drive')})],next:'ro.hub'};
N['ro.basement']={lines:[L('rostova','The morgue. It\'s closed until the police finish with it. Staff only. You\'re not staff.'),L('rostova','Unless you are.',{if:S=>S.past==='paramedic'}),L('echo','The elevator wants a staff badge with basement clearance. Your old keycard only opens the side door.',{pass:6,if:S=>G.has('keycard')})],next:'ro.hub'};
N['ro.volvo']={lines:[L('rostova','Lots of people drive white Volvos. It\'s the official car of the exhausted.'),L('pulse','Her hand went to her car keys in her pocket. She didn\'t know she did it.',{pass:8,do:S=>S.flags.volvoHers=1}),L('web','A white Volvo outside Kowalski\'s at ten past four. A doctor\'s car. Her car.',{if:S=>S.flags.volvoHers})],next:'ro.hub'};
N['ro.cold']={lines:[T('Her loudest silence is not a word. It is a sound: a high electrical whine, building, and then a white light so bright it has edges. And a man in a fedora, turning toward it, surprised.'),
  L('tenant','...Oh. Oh, *you*.',{do:(S,G)=>{S.flags.rostovaFlash=1;G.sync(4);}}),
  L('web','She has seen the inside of the freezer. She has seen it at four-fourteen in the morning. Don\'t say anything. Don\'t say anything yet.',{pass:6})],next:'ro.hub'};
N['ro.vintage']={lines:[T('A speck on her cuff: hers, from a paper cut. Coffee, temazepam, a long-term iron supplement. And under it, faint but certain, something that does not belong in a mortal\'s blood at all: *vitae*. Old. A week old. Someone\'s been feeding her a drop at a time.'),
  L('web','She\'s been taking vampire blood. Small doses. Enough to make her fast, and strong, and steady-handed. Who\'s been giving it to her?',{do:S=>S.flags.rostovaVitae=1})],next:'ro.hub'};
N['ro.siren']={lines:[L('rostova','I drove to a butcher\'s shop and I —'),T('She stops. She presses her lips together so hard they go white. Her eyes are wet and furious.'),L('rostova','Get out of my clinic.',{do:(S,G)=>{S.flags.rostovaSiren=1;S.flags.rostovaCold=1;G.rel('rostova',-2);}}),L('pulse','She\'ll remember that. She\'ll remember that you made her say it.')],end:true};
H.use.entrylog=async(S,G)=>G.talk('log.0');
N['log.0']={lines:[T('A clipboard on the desk, the sign-in sheet for Monday, already half buried under Tuesday\'s.')],
  opts:[C('stagecraft',8,'Read it upside down while nobody\'s looking.','log.read','log.caught',{id:'log_read',mod:(S,G)=>G.equipped('triagemask')?2:0}),
    O('Use your old staff login on the desk terminal.','log.read',{if:S=>S.past==='paramedic'}),
    O('Leave it.',null,{end:true,leave:true})]};
N['log.read']={lines:[T('Monday, 04:31 — ADMIT: JOHN DOE, DOA. BROUGHT BY: (illegible) "friend". DRAWER: B-14. SIGNED: a scrawl that looks like your handwriting looks when your hands are shaking.'),
  T('Below it, in a different pen: Monday, 04:29 — STAFF IN: E. ROSTOVA (returning from break).'),
  L('web','Drawer B-14. Fourteen. Your hand wrote fourteen. And Dr. Rostova "returned from break" two minutes before you walked in.',{pass:5,do:(S,G)=>{S.flags.drawer14=1;S.flags.logRead=1;G.fact('rostova','log');G.task('clinic','done');G.xp(30,'The entry log');}}),
  L('tenant','Fourteen. Yes. Yes. Something in a drawer.',{if:S=>S.flags.code0414}),
  L('sundial','Where was she from four to four-twenty-nine? Ask nobody. Remember everything.')],end:true};
N['log.caught']={lines:[L('rostova','Can I help you?'),T('She pulls the clipboard toward herself and puts her coffee on it.'),L('stagecraft','Too obvious. Come back when she\'s busy, or find another way in.')],end:true};
H.use.bagfridge=async(S,G)=>G.talk('fridge.0');
N['fridge.0']={lines:[T('A tall white fridge with a red cross and a padlock. Through the glass: rows of O-negative, frosted, labelled in Dr. Rostova\'s neat hand.'),L('parasite','Two of them are past their date. Nobody counts the expired ones.',{pass:6})],
  opts:[O('Iron Claws: snap the padlock.','fridge.steal',{ab:'claws',once:'fr_steal'}),O('Bone-Key: pick it.','fridge.steal',{ab:'bonekey',once:'fr_steal'}),O('Spark-Jump: the fridge has an electronic lock too.','fridge.steal',{ab:'spark',once:'fr_steal'}),
    C('gutter',11,'Slip it while the nurse is busy.','fridge.steal','fridge.no',{id:'fr_gut',once:'fr_steal'}),O('Leave it.',null,{end:true,leave:true})]};
N['fridge.steal']={lines:[T('Two expired bags, under your coat. The fridge door closes with a little sigh, like it disapproves.',{do:(S,G)=>{G.give('bloodbag',2);S.flags.stoleBags=1;if(!G.equipped('latex'))S.flags.prints=1;}}),L('autopsy','Fingerprints on the glass. Unless you were wearing gloves.',{if:(S,G)=>!G.equipped('latex')})],end:true};
N['fridge.no']={lines:[L('nurse','Hey. HEY. That\'s not a vending machine.'),L('gutter','Too slow. She\'s watching now.',{do:(S,G)=>G.heat(1)})],end:true};
H.use.elevator=async(S,G)=>G.say([T('A steel staff elevator. A badge reader with a red light. A laminated sign: BASEMENT · MORGUE · CLOSED BY ORDER OF PRECINCT 9.'),L('echo','The reader wants basement clearance. Your old keycard won\'t do it.',{if:S=>G.has('keycard')}),L('tenant','Down there. Something of mine is down there. I can feel it like a tooth.',{if:S=>S.flags.code0414||S.flags.drawer14}),L('sundial','Not tonight. The police seal is fresh. Come back when they\'ve gone.')]);
H.use.judemirror=async(S,G)=>{S.flags.mirror_jude=1;const ghost=NL.CLANS[S.clan]&&NL.CLANS[S.clan].ghost;return G.say([T('A staff restroom: a sink, a sharps bin, a steel mirror screwed to the wall.'),T(ghost?'The steel mirror shows the room. Not you. A nurse comes in behind you, glances at the mirror, glances at you, and goes very pale.':'You. Grey under the fluorescent light, like a patient who didn\'t make it.'),
  T('She leaves without washing her hands.',{if:S=>ghost,do:(S,G)=>{if(S.clan==='hollow'){G.comp(-2,'Zero Reflection: she saw you not there');G.heat(1);}}})]);};
H.use.cubicle=async(S,G)=>G.say([T('Behind the curtain: an old man asleep with his mouth open, a drip in his arm, a heartbeat monitor counting him out loud.'),L('parasite','Diabetic. Sweet. Sleeping. He\'d never know.'),L('pulse','He\'d never know. You would.')]);

/* ---------- Leo at the start of the night (if he's still in the back room) ---------- */
pushEnter('backroom',async(S,G)=>{if(S.flags.mapOK&&S.night===1&&G.actor('leo')&&!S.flags.leoSentHome&&!S.flags.tedGone&&S.time>30){}});

/* ---------- small things ---------- */
H.equip.push((id,S,G)=>{if(id==='signet'&&G.once('signet_on'))G.toast('rel','The Tenant speaks more often while you wear his ring.','Signet of House Vane');});
})();
