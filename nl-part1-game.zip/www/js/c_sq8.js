'use strict';
/* THE NEW LORD — side quests, set eight: "6C" (a tenor in the bath), "The Un-Wedding" (the bride from Kerr Street throws a party), "Dale" (the other cop) */
(function(){const X=NL.EXTRAS,S_=NL.Script;
X.bellini={n:'Mr. Bellini',color:'#e0c8a0',role:'Flat 6C, the Rookery · retired tenor',spec:{face:{long:1.05,cheek:1.5,jaw:1.2},skin:[.84,.72,.62],hair:{style:'fringe',color:[.92,.92,.9]},shirt:[.85,.8,.75],coat:{color:[.5,.2,.2],length:.7,collar:true},height:.94,bulk:1.15}};
Object.assign(NL.TASKS,{s_6c:{n:'6C',xp:60,cat:'side'},s_unwed:{n:'The Un-Wedding',xp:40,cat:'side'}});
S_.place({id:'six_c',name:'Flat 6C, the Rookery',block:'C',sub:'Someone on the sixth floor sings in the bath every night at one. Opera. Very well.',if:'night>=2&night<=4&flag:mapOK&!flag:sixcDone',node:'sx.0',min:6});
S_.place({id:'grand',name:'The Grand, Kerr Street',block:'A',sub:'An invitation, pushed under the Lucky Mart door, addressed to "the friend of the night": "UN-WEDDING PARTY. THE GRAND. THURSDAY. FREE BAR (CAKE)."',if:'night:4&flag:mapOK&seen:ev.bride7&!flag:unwedDone',node:'uw.0',min:8});
})();
NL.Script.add(String.raw`
// =====================================================================
// 6C
// =====================================================================
# sx.0
> The sixth floor of the Rookery. Through the door of 6C, steam, and a voice. A tenor, old but enormous, filling the stairwell like water filling a bath, singing *Una furtiva lagrima*.
> The same aria. Séverine's record. Exactly the same, and not at all: slower, wider, with a crack in it where an old man's breath runs out and he keeps going anyway.
* Knock.  -> sx.knock
* Sit on the stairs and listen.  -> sx.listen

# sx.listen
> You sit on the top stair in the dark and listen to the whole thing. When he gets to the end he holds the last note far longer than any recording, and then the bath gurgles, and he says "bravo, Antonio" to himself, quite seriously.
{do comp+2}
@next sx.knock

# sx.knock
> A long pause. A splash. The door opens on the chain. An old man in a red velvet dressing gown with a towel round his neck, eighty-eight if he's a day, with a face like a Roman emperor gone to seed.
bellini: Yes? Is it the noise? It's always the noise. I've told the association. I sing at one. It's in my lease. Clause nine.
{do task:s_6c}
* "It's not the noise. It was beautiful."  -> sx.beautiful
* "You sing Caruso."  -> sx.caruso

# sx.beautiful
bellini: Beautiful. Ha! Nobody has said that to me since 1974. The neighbors say "Antonio, for the love of God". You may come in. Mind the cat. It isn't mine.
@next sx.in

# sx.caruso
bellini: I sing *Donizetti*. Caruso sang Donizetti. Everybody forgets the composer. Come in, come in, you have the face of someone who knows the difference.
@next sx.in

# sx.in
> A flat stacked with records and programmes and signed photographs. Milan. Vienna. Buenos Aires. A poster from 1962: ANTONIO BELLINI — A PRIVATE RECITAL — THE RELIQUARY CLUB.
bellini: That one. Ha. The strangest night of my life. A private recital, in a cellar, for a society of very pale people in evening dress. Nobody clapped. They just looked at me. One lady in front, in grey silk, wept the whole time.
bellini: Afterwards they paid me in gold sovereigns. I've still got them. I've never spent one. I always felt... I always felt they'd want them back.
pedigree(7): A Gilded Court recital. 1962. The lady in grey silk was Séverine. She's been playing his aria on a gramophone for sixty years and she doesn't know it's him.
* "That record she plays. It's not Caruso. It's you."  -> sx.record {if alive:sev}
* "Would you sing for her again?"  -> sx.again
* "Keep the sovereigns. Never go back to that cellar."  -> sx.warn

# sx.record
bellini: A record. Of me? There's no record. They wouldn't let anyone record. No cameras, no microphones, nothing.
bellini: ...Unless someone did. Unless someone did. Oh. Oh, that's... somebody has been listening to me for sixty years?
{do flag:sixcRecord=1}
@next sx.again

# sx.again
bellini: Sing. Again. For the lady in grey silk.
bellini: I'm eighty-eight. My top C went in 1990. I can do a B-flat on a good night, in the bath.
bellini: ...Yes. Yes. Of course I would. Bring her. Bring her here, or take me there, I don't care. I'd like to sing to someone who cries.
* "I'll bring her here. To 6C."  -> sx.bring {if alive:sev}
* "Not to the cellar. It isn't safe."  -> sx.warn

# sx.bring
> It takes some doing. Séverine does not, as a rule, climb six flights of stairs in a tenement on Halloran Street at two in the morning. But when you tell her who's on the sixth floor, she puts down her glass and doesn't say anything for a long time, and then asks for her coat.
> 6C. Séverine on a kitchen chair, very straight, gloves on, with a cat on her lap that isn't anybody's. Mr. Bellini in his red dressing gown, standing by the window with his hand on the radiator for balance.
> He sings. The crack in his voice. The breath running out and him going on anyway. The B-flat, just, on a good night.
> She doesn't cry. Not at first. Then she does, silently, without moving her face, the way she does at dawn.
> At the end there's a silence. Then she stands up, and takes off one glove, and holds out her bare hand to him, and he kisses it the way they did in Milan in 1955.
severine: Sixty years. I thought you were dead. I thought you were Caruso. I've been playing you every night and calling you by someone else's name.
bellini: Madame. Everybody does. I'm used to it.
{do flag:sixcDone=1; flag:sixcSev=1; task:s_6c=done; xp:60:6C; rel:severine+3; comp+2}
tenant: (very quietly) She wept in 1962. I was there. I was in the back row. I didn't know why she wept. I never asked.
@end

# sx.warn
bellini: Never go back. Hm. They weren't... they weren't quite right, were they. The pale ones. I always thought it was the lighting.
bellini: All right. I'll stay in my bath. It's where the acoustics are best anyway.
{do flag:sixcDone=1; task:s_6c=done; xp:40:6C}
@end

// =====================================================================
// THE UN-WEDDING
// =====================================================================
# uw.0
> The ballroom of the Grand, Kerr Street. The same room where a wedding reception went on without the groom on Monday. Now: the same balloons, a little deflated, the same cake, a little eaten, and two hundred people in their Thursday clothes, dancing to *Come On Eileen*.
> On a chair in the middle of the dance floor, in her wedding dress with the sleeves cut off and a pair of sneakers on, the bride. She's holding a microphone. She sees you and points.
bride: THAT ONE. That one in the coat. That's the one who told me to make a speech. Everyone, that is the friend of the night.
> Two hundred people turn and cheer. You've never been cheered by two hundred living people. It's terrifying.
{do task:s_unwed}
* Raise a hand. Wave.  -> uw.wave
* Back out of the door.  -> uw.back

# uw.back
> Too late. She's off the chair and across the floor in her sneakers and she has you by the arm.
@next uw.dance

# uw.wave
> They cheer again. Somebody's uncle whistles.
@next uw.dance

# uw.dance
bride: You have to dance. It's the rule. I've made it the rule. You're the guest of honour at my un-wedding.
* Dance.  -> uw.d1
* "I can't stay long."  -> uw.d2

# uw.d1
> You dance. Badly, then not badly. *Come On Eileen*, then *Dancing Queen*, then something with a lot of trumpets. Two hundred living people, warm and loud and drunk and happy, and you in the middle of them, not hungry, for once. Not hungry at all.
bride: I quit my job! I'm going to Portugal! I've booked a ticket! With the honeymoon money! On my own!
{do comp+3:The un-wedding; flag:unwedDanced=1}
@next uw.end

# uw.d2
bride: Can't stay long. Nobody can. That's why you dance fast.
> She drags you round once anyway, very fast, laughing, and lets you go.
{do comp+1}
@next uw.end

# uw.end
> At the door, she gives you a slice of cake in a napkin. You can't eat it.
bride: For later. Thank you. You don't know what you did. You said "you're relieved" on the steps of City Hall and you were right and I've never been so relieved in my life.
{do flag:unwedDone=1; task:s_unwed=done; xp:40:The Un-Wedding}
@end
`,'c_sq8');
(function(){
NL.Script.place({id:'anchor',name:'The Anchor, Ferrier Lane',block:'A',sub:'A pub with sawdust on the floor. Officer Dale drinks here when he\'s off duty.',if:'night>=4&night<=5&flag:mapOK&!flag:daleTalked&flag:racketDone=calendar|night>=4&night<=5&flag:mapOK&!flag:daleTalked&flag:racketDone=wait|night>=4&night<=5&flag:mapOK&!flag:daleTalked&flag:racketDone=nephew',node:'dx.0',min:6});
NL.Script.add(String.raw`
# dx.0
> The Anchor, closing time. Officer Dale, off duty, alone at the end of the bar with a pint he isn't drinking.
dale: Oh. You. Great. Brilliant. The statue.
@gate flag:racketDone=calendar ? dx.cal : dx.other

# dx.cal
dale: I went back. To the shop. On my own. Bought a Mars bar. Paid for it.
dale: His old man gave me a Mars bar every Wednesday for nine years. I was taking his money and he was giving me chocolate. Who does that?
* "A man with patience."  -> dx.cal1
* "Somebody who could see you were twelve inside."  -> dx.cal2

# dx.cal1
dale: Patience. Yeah. That's what the calendar said. In Urdu. Tariq told me. "Sabr."
dale: I'm trying it. It's harder than it looks.
{do rel:tariq+1; flag:daleTalked=1}
@end

# dx.cal2
dale: Twelve. Ha. My wife says that. She says I'm twelve inside and forty-nine outside and neither of them's any use.
> He laughs. It's not a bad laugh.
{do flag:daleTalked=1}
@end

# dx.other
dale: Ken's not talking to me. He's going to Internal Affairs. He says he's going to tell them about the shop. He says his sister made him.
dale: I've got two years till my pension. Two years.
* "Then go with him. Tell them first."  -> dx.go
* "That's your problem, Dale."  -> dx.prob

# dx.go
dale: Go WITH him. And lose my... and...
> He looks at the floor for a long time.
dale: ...My daughter's applying to the academy. Did you know that? She wants to be a cop. Like her dad. Like her stupid dad.
dale: Yeah. Yeah, okay. I'll go with him. She can't find out from somebody else.
{do flag:daleConfess=1; flag:daleTalked=1}
@end

# dx.prob
dale: Yeah. Yeah, it is. Thanks for nothing, statue.
{do flag:daleTalked=1}
@end
`,'c_sq8b');
})();
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.sixcSev)o.push(['Mr. Antonio Bellini, 6C','Sings every night at one, in the bath, clause nine of his lease. Every Sunday, at two, a lady in grey silk climbs six flights of stairs and sits on a kitchen chair and weeps. He has started taking requests.']);
  if(f.unwedDanced)o.push(['The bride from Kerr Street','Is in Portugal, on her own, on the honeymoon money. She sent a postcard to the Lucky Mart, addressed to "the friend of the night". Tariq has pinned it behind the till.']);
  if(f.daleConfess)o.push(['Officers Dale and Pruitt','Walked into Internal Affairs together on a Monday morning with a shoebox of receipts. Pruitt kept his job. Dale took early retirement. His daughter starts at the academy in September.']);
  return o;});
