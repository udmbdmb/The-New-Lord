'use strict';
/* THE NEW LORD — "Saturday, in daylight": if you walked out into the sun, there is one day to spend in it */
(function(){
document.addEventListener('DOMContentLoaded',()=>{const N=NL.STORY.nodes;const n=N['end.show.daywalker'];if(!n)return;const cs=n.cs;
  n.cs=async(G,S)=>{if(!S.flags.dayDone){S.flags.dayDone=1;try{await G.talk('sd.0');}catch(e){console.error('saturday day',e);}}return cs(G,S);};});
})();
NL.Script.add(String.raw`
# sd.0
> You don't sleep. You can't. Every time you close your eyes the light comes through your eyelids, red, and you open them again in case it's gone.
> It's Saturday. It's ten in the morning. You have never been awake at ten in the morning. You've been awake at ten in the morning your whole life.
tenant: (very quiet, very far away) ...I can see it. Through you. I can see it. It's so much brighter than she said.
> One day. Maybe more. Maybe it lasts. Maybe it doesn't. Nobody knows, least of all Rostova. You'd better spend it.
@next sd.hub

# sd.hub
> The day is long. Not that long. Three places, before the light goes.
* The Rookery. Leo, in daylight.  -> sd.leo {once} {if alive:leo&!flag:leoGoneTown&!flag:sdN3}
* The train to the coast. Robin.  -> sd.robin {once} {if name&!flag:sdN3}
* The Pawn & Coffin. Gideon has never seen one of you in the sun.  -> sd.gideon {once} {if alive:gideon&!flag:sdN3}
* St. Jude's. Dr. Rostova.  -> sd.ros {once} {if alive:rostova&!flag:sdN3}
* The Lucky Mart, again. For a second coffee.  -> sd.tariq {once} {if alive:tariq&!flag:sdN3}
* Platform 0, from above. Look down through the grate at the ones who can't come up.  -> sd.grate {once} {if !flag:massacre&!flag:sdN3}
* Lie down in the grass in Halloran Park and do nothing at all.  -> sd.park {once} {if !flag:sdN3}
* Go back. Let the evening come.  -> sd.end

# sd.n
@gate flag:sdN2 ? sd.n3 : sd.n2b

# sd.n2b
@gate flag:sdN1 ? sd.n2 : sd.n1

# sd.n1
{do flag:sdN1=1}
@next sd.hub

# sd.n2
{do flag:sdN2=1}
@next sd.hub

# sd.n3
{do flag:sdN3=1}
> The shadows are getting long. Longer than you've ever noticed shadows getting. You'd forgotten they move.
@next sd.end

# sd.leo
> You knock on 3B at eleven in the morning. He opens the door in his pyjamas with a toothbrush in his mouth and sees you standing on the landing in a square of sunlight from the stairwell window.
leo: ...Mmmff. MMMFF.
> He takes the toothbrush out.
leo: You're in the SUN. You're standing in the SUN. Is that... are you... is this a dream? Am I dead? Did you kill me? Is this heaven? Heaven's very brown.
* "It's me, Leo. In the daytime."  -> sd.leo1

# sd.leo1
> He hugs you. Toothpaste on your coat. He's crying. He's laughing.
leo: You're WARM. You're warm. Oh my God. Oh my God, you're warm.
leo: Breakfast. We have to have breakfast. Can you have breakfast? Have you HAD breakfast? There's a diner on Kerr Street that does pancakes the size of a hubcap.
* Go to the diner.  -> sd.leo2

# sd.leo2
> The diner on Kerr Street. A booth by the window. The sun on the table. A stack of pancakes the size of a hubcap, with butter melting on top and syrup going everywhere.
> You eat them. All of them. It's like eating for the first time. It's like being born with teeth.
> Leo watches you eat with his chin on his hands like you're the greatest show on earth.
leo: This is going in the act. All of it. "My mate was a vampire for five days and then he ate eleven pancakes." That's the whole bit. That's the whole set. I don't even need a punchline.
{do rel:leo+2; comp+3}
@next sd.n

# sd.robin
> The 11:40 from Central to the coast. A window seat. Fields going past, green, gold, wet, in the light. You've never seen fields in daylight. You've seen them a thousand times. A child across the aisle stares at you because you keep touching the window.
> Saltmarsh. A seafront. Gulls. Harbour Row. A fish on a mailbox, faded, in marker pen.
> You knock. She opens the door with a pencil behind her ear and a stack of spelling tests in her arm.
> The spelling tests go everywhere.
* Say her name.  -> sd.rob1
* Say nothing. Just stand there.  -> sd.rob2

# sd.rob1
robin: Casey. Casey. CASEY.
> She doesn't let go for a long time. When she does, she holds you at arm's length and looks at you in the daylight.
robin: You look terrible. You look AMAZING. You look like you haven't slept in a week.
* "I haven't. Not like this."  -> sd.rob3

# sd.rob2
> She looks at you on her doorstep in the sun. She doesn't say anything either. Then she reaches out and touches your face, very gently, the way you'd touch a photograph you thought you'd lost.
robin: ...You're real.
@next sd.rob3

# sd.rob3
> Leek soup at the kitchen table. Spelling tests with a red pen. Later, in the yard, with a Sharpie, the two of you repaint the fish on the mailbox. It comes out wonky. It's perfect.
robin: Are you staying? You don't have to tell me now. You can tell me at dinner. Or tomorrow. Or next year.
{do flag:sdRobin=1; comp+4; flag:satRobinHome=1}
@next sd.n

# sd.gideon
> The bell over the door of the Pawn & Coffin. Gideon looks up from the counter, where he is reading the *Times* in the sun from the front window for the first time in fifty years, because none of his customers are awake to mind.
> He sees you in the doorway, with the light on your face. He takes off his glasses. He puts them back on.
gideon: ...Well. Well. Fifty years. Fifty years of boxes, and I've never once seen one of you standing in my door at noon.
gideon: Come in. Come in. Close the door, you're letting the warm out. Listen to me. Letting the warm out. To you.
* "I came to give you box three back."  -> sd.gid1

# sd.gid1
gideon: Box three. Yes. Yes.
> He opens the ledger. He turns to your page. In red ink, very neatly, he draws a line under your column, and under the line he writes: *Woke.*
gideon: First time I've ever used red for something good.
{do rel:gideon+2; comp+2}
@next sd.n

# sd.ros
> Fourth floor. Her office. She's asleep on the floor under her desk with her white coat over her like a blanket. You wake her by opening the blinds.
> She sits up into a square of sunlight with you standing in it. She stares.
rostova: ...How long? How long have you been in the light?
* "Since five past five."  -> sd.ros1

# sd.ros1
rostova: Seven hours. Seven hours. Dani managed twenty-two minutes.
> She gets up. She takes your pulse. She takes your temperature. She looks in your eyes with a light. Her hands are shaking. She's crying, and doesn't seem to notice.
rostova: It works. It works. It works, and it cost seven people and a Sheriff, and it works.
* "Then make sure it never costs anyone again."  -> sd.ros2
* "Destroy it. All of it. Your notes. Everything."  -> sd.ros3

# sd.ros2
rostova: Never again. With consent, and the door open, and a name on every vial. Yes. If I'm allowed to work again. If anyone lets me.
{do flag:sdRosWork=1; rel:rostova+2}
@next sd.n

# sd.ros3
> She looks at her notebooks. Six years. A cabinet of them. The answer to the oldest question in the dark.
rostova: ...Yes. Yes, all right. Some answers shouldn't exist.
> You burn them together in the incinerator in the basement. It takes an hour. She doesn't look away once.
{do flag:sdRosBurn=1; rel:rostova+1}
@next sd.n

# sd.tariq
> The bell over the door. Second time today. Tariq doesn't look up.
tariq: Coffee. On the counter. It's still hot. I put it there when I saw you crossing the road.
> You drink it. It's still terrible.
tariq: I've been thinking. All morning. My father always said the night shift was for people with nowhere else to be. And now you have somewhere else to be. In the day.
tariq: Will you still come in at five? In the morning? Even if you don't need the dark?
* "Every morning."  -> sd.tar1

# sd.tar1
tariq: Good. Good. I'll keep the coffee on. Forty-two cups. Forty-three.
{do rel:tariq+2; comp+2}
@next sd.n

# sd.grate
> The iron grate over Platform 0, set into the sidewalk on Ferrier Lane. Noon. You kneel on it in the sun and look down through the bars into the dark.
> Down there, three hundred Kindred are asleep in their coffins and their crates and their nests of old coats. Somebody isn't. A face, at the bottom of the shaft, very pale, looking up at you through a grate full of sunlight.
@gate alive:sev ? sd.grSev : sd.grSoot

# sd.grSev
> Séverine. In her evening dress, at noon, at the bottom of a pit, looking up at you with her hand shading her eyes from a light she can't stand to be anywhere near.
> She doesn't say anything. She raises one gloved hand, very slowly. Not a wave. Something older. The salute you give across a duelling ground when the other man has won.
> Then she goes back into the dark.
{do comp+2}
@next sd.n

# sd.grSoot
> Mother Soot. With a jar in her hands, held up toward the grate, open, as if she's trying to catch the light in it.
soot: (from very far below) Mm. Mm. Hold still. Hold still. I've never had one of these.
{do comp+2}
@next sd.n

# sd.park
> Halloran Park. A patch of wet grass behind the Rookery with a broken swing and a bench with a plaque on it nobody reads. You lie down in the grass in your coat in the middle of the day and look at the sky.
> It's blue. It's so blue. There are clouds going over, white, slow, like ships. A plane, very high, leaving a line. A dog barks. Somebody's radio. Children shouting in the playground. A bus.
> You lie there for two hours and do nothing at all, and it is the best thing you have ever done.
tenant: (from very far away, fading, the way voices fade at the end of a long call) ...Thank you. Thank you, child. That's what she meant. That's exactly what she meant.
{do comp+5; sync-5:The sky}
@next sd.n

# sd.end
> The sun goes down over the Marrow Ward at 4:51 PM. You watch it go. You don't hide. You don't burn. You just watch it go down, red and orange and then gone, the way it did when you were a child, and you didn't know that it was a miracle.
> Then the streetlights come on, and the Ward wakes up, and somewhere under your feet three hundred Kindred are opening their eyes in the dark. And you're standing on the sidewalk in between, belonging to both, or neither, or something nobody has a word for yet.
@end
`,'c_saturday2');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];if(!f.dayDone)return o;
  if(f.sdRosWork)o.push(['The Daywalker Protocol','Restarted, in March, at St. Jude\'s, with consent forms that say exactly what it is, and the door open, and a name on every vial. Twelve applicants in the first week. All of them Kindred.']);
  if(f.sdRosBurn)o.push(['The Daywalker Protocol','Burned, in the basement incinerator at St. Jude\'s, on a Saturday afternoon. Six years. One answer. Some answers shouldn\'t exist.']);
  return o;});
