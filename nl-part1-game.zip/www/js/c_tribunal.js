'use strict';
/* THE NEW LORD — the Magistrate's cross-examination before the Tribunal proper. Your answers, and what the Ward already thinks of you, set the scales. */
NL.Script.add(String.raw`
# tx.0
> Before the accusations, the Magistrate does something nobody on Platform 0 expected. He leans forward in the high-backed chair and looks at you, only you, and speaks quietly, as if the three hundred others had left.
magistrate: Before anyone else speaks again, I will ask you some questions myself. It is an old privilege. I have not used it since 1904. Answer them truthfully, or answer them well. I will know which.
@gate rep:candour>=3 ? tx.hon : tx.next0

# tx.next0
@gate rep:candour<=-3 ? tx.liar : tx.q1

# tx.hon
magistrate: They tell me you are honest. Tiresomely so. That shopkeepers and detectives and pawnbrokers trust you. Let us see.
{do flag:crossProg+1}
@next tx.q1

# tx.liar
magistrate: They tell me you lie. Prettily, sometimes. To the Keeper, to the Butcher, to the old woman in the pipes. Let us see whether you lie to me.
{do flag:crossThreat+1}
@next tx.q1

// ---------- the first question: who are you ----------
# tx.q1
magistrate: Who are you?
* "Casey Morrow."  -> tx.q1name {if name}
* "I don't know. I'm finding out."  -> tx.q1unknown
* "The one who wears the Sheriff's coat."  -> tx.q1coat
* Let the Tenant answer.  -> tx.q1vane {if sync>=50|flag:chord}

# tx.q1name
magistrate: Casey Morrow. A mortal's name. You keep it, after all this. Why?
* "Because it's the only thing in me that's only mine."  -> tx.q1namea {do flag:crossProg+1}
* "Because a Wraith kept it in a jar for me."  -> tx.q1nameb

# tx.q1namea
magistrate: ...Yes. That is a good answer. I had a name, once, before Ambrose. I gave it up on a ship in 1640. I have occasionally regretted it.
@next tx.q2

# tx.q1nameb
soot: (from the edge of the platform) Mm. Mm. I did. I did.
magistrate: Then you owe her. Everyone in this city owes Soot something. Continue.
@next tx.q2

# tx.q1unknown
magistrate: An honest answer, from a neonate. Rare. Most of your age claim to know exactly who they are, and are wrong.
{do flag:crossProg+1}
@next tx.q2

# tx.q1coat
magistrate: A coat is not a person. Absalom was not his coat, though he would have liked to be. Continue.
{do flag:crossThreat+1}
@next tx.q2

# tx.q1vane
> Your mouth opens, and it isn't you.
tenant: Ambrose. It's me. Or most of me. The rest of me is a young person called Casey, and they've been remarkably patient with the arrangement.
> A long silence on Platform 0. The Magistrate's face does something it hasn't done in a century. It smiles.
magistrate: Absalom. Of course. You never could let anyone else speak first.
{do flag:crossProg+2; flag:crossThreat+1; sync+3:Ambrose}
@next tx.q2

// ---------- the second question: did you enjoy it ----------
# tx.q2
magistrate: When you drank him. Absalom Vane, two hundred and sixty-three years old, in a freezer, with the light coming. Did you enjoy it?
* "Yes."  -> tx.q2yes
* "No. I was trying to save us both."  -> tx.q2no
* "I don't remember enjoying it. I remember the light."  -> tx.q2light

# tx.q2yes
@gate rep:candour>=1 ? tx.q2yesok : tx.q2yesbad

# tx.q2yesok
magistrate: Yes. Of course you did. Everyone does. Nobody admits it, in this court. You have. I note it.
{do flag:crossProg+1}
@next tx.q3

# tx.q2yesbad
magistrate: Yes. You say it as if it might impress me. It doesn't. Continue.
{do flag:crossThreat+1}
@next tx.q3

# tx.q2no
@gate rep:candour>=1|flag:sawAmbush ? tx.q2nook : tx.q2nobad

# tx.q2nook
magistrate: Saving. I've heard the word "salvage" used for less. Continue.
{do flag:crossProg+1}
@next tx.q3

# tx.q2nobad
magistrate: Saving. Everyone who drinks an Elder says that. I've heard it in four languages.
@next tx.q3

# tx.q2light
magistrate: The light. Yes. We will come to the light.
{do flag:crossProg+1}
@next tx.q3

// ---------- the third question: what you've done since ----------
# tx.q3
magistrate: Four nights you have walked his Ward in his coat. Tell me one thing you did with it that he would not have done.
* "I let a shop off its tithe because it keeps a light on."  -> tx.q3light {if flag:tariqLamp|mem:tariq.salt}
* "I gave a Hound something to love that wasn't a master."  -> tx.q3valko {if flag:valkoAlly}
* "I found the families of seven mortals and said their names."  -> tx.q3seven {if done:s_seven}
* "I woke a Wraith who'd been standing in the river for forty years."  -> tx.q3winter {if flag:winterAwake}
* "I brought a lost boy home on the night bus."  -> tx.q3luis {if flag:luisHome}
* "I let a ghoul go free."  -> tx.q3pem {if flag:leoFreed|flag:leoGoneTown}
* "I killed. More than once."  -> tx.q3kill {if kills>=2}
* "Nothing. I've been surviving."  -> tx.q3none

# tx.q3light
magistrate: Absalom did that too. The Lucky Mart. Exempt. He mentioned it in every report for thirty years. "He keeps a light on." I thought he was going soft.
magistrate: So. Not something he would not have done. Something he *did*. You're more like him than you think.
{do flag:crossProg+1; sync+2}
@next tx.q4

# tx.q3valko
valko: (from your left hand, very low) Yes.
magistrate: The Hound speaks for you without being asked. Absalom spent seventy years teaching him to wait for permission. Interesting.
{do flag:crossProg+2}
@next tx.q4

# tx.q3seven
magistrate: Mortals. You learned the names of mortals. Seven of them. Kindred don't learn mortal names, as a rule. It makes the feeding harder.
magistrate: ...I find I would like to know them too. You will tell me, later.
{do flag:crossProg+2}
@next tx.q4

# tx.q3winter
soot: (from the edge of the platform) My little Winter. Mm. Mm.
magistrate: Absalom never looked for her. He knew she'd gone into the water. He walked past the grate every night for forty years. You went down.
{do flag:crossProg+2}
@next tx.q4

# tx.q3luis
magistrate: A survivor. Of the program. Brought home to his mother, on a bus. Not to a laboratory, or a court, or a cell. Home.
{do flag:crossProg+2}
@next tx.q4

# tx.q3pem
magistrate: Let a mortal go. Absalom never let anything go in his life. He kept Pemberton for forty-one years because he couldn't imagine the car without him.
{do flag:crossProg+1}
@next tx.q4

# tx.q3kill
magistrate: Yes. So did he. Four hundred and eleven times, I'm told. You're catching up.
{do flag:crossThreat+2}
@next tx.q4

# tx.q3none
magistrate: Surviving. That is what neonates do. It is not a crime. It is not a virtue either.
@next tx.q4

// ---------- the last question: the Ward ----------
# tx.q4
magistrate: Last question. If this court lets you live, what will you do with the Marrow Ward?
* "Keep it. The way he did. Better."  -> tx.q4keep {do lean:pride+1}
* "Give it back to the people who live in it."  -> tx.q4give
* "Leave it. I never wanted it."  -> tx.q4leave {do lean:pride-1}
* "Whatever the Prince wills."  -> tx.q4prince

# tx.q4keep
@gate allies>=2 ? tx.q4keepok : tx.q4keepbad

# tx.q4keepok
magistrate: Better. Everyone says better. But you have friends on this platform, which Absalom did not. That is already different.
{do flag:crossProg+1}
@next tx.end

# tx.q4keepbad
magistrate: Keep it. With whom? I count very few people on this platform who would stand with you. A Sheriff without a Ward is a man in a coat.
{do flag:crossThreat+1}
@next tx.end

# tx.q4give
magistrate: Give it back. To mortals, and the clanless, and old women in pipes. That is either the wisest thing anyone has said to me this century or the stupidest.
@gate flag:side_union|rep:mercy>=3 ? tx.q4giveok : tx.end

# tx.q4giveok
dutch: (from the back) WISEST!
magistrate: Thank you, whoever you are. Continue.
{do flag:crossProg+1}
@next tx.end

# tx.q4leave
magistrate: Leave. Honest. Useless, but honest. The Prince does not need another Kindred who wants nothing. She has six hundred of those.
@next tx.end

# tx.q4prince
@gate rep:pride>=2 ? tx.q4princeok : tx.q4princebad

# tx.q4princeok
magistrate: The correct answer. You've been in the Court long enough to learn it. Absalom never managed to say it without sneering.
{do flag:crossProg+1}
@next tx.end

# tx.q4princebad
magistrate: The correct answer, said by someone who has never once bowed in this city. I note the effort.
@next tx.end

# tx.end
magistrate: Thank you. I have heard enough to know what you are. I have not yet heard enough to know what you did. The Keeper's accusation stands. Let us hear the rest.
@next tb.enc
`,'c_tribunal');

(function(){const N=NL.STORY.nodes,{ENC}=NL.DSL;
// tb.0 → the cross-examination → the encounter
const hook=()=>{if(N['tb.0']&&N['tb.0'].next==='tb.enc')N['tb.0'].next='tx.0';};hook();document.addEventListener('DOMContentLoaded',hook);
if(ENC.tribunal){const st0=ENC.tribunal.start;ENC.tribunal.start=function(S,G){const r=st0.call(this,S,G);r.prog=Math.max(0,r.prog+(S.flags.crossProg||0));r.threat=Math.max(0,r.threat+(S.flags.crossThreat||0));return r;};}
})();
