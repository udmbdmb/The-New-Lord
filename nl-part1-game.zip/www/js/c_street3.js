'use strict';
/* THE NEW LORD — street events, part three: more things that happen on the way */
(function(){const X=NL.EXTRAS;const P=(n,role,skin,hair,shirt,coat,o)=>Object.assign({n,role,color:'#c8c0b0',spec:Object.assign({skin,hair:{style:hair[0],color:hair[1]},shirt,coat:coat?{color:coat,length:.5,collar:true}:null},o||{})});
Object.assign(X,{
  bride:P('A woman in a wedding dress','Kerr Street, 1 AM',[.88,.76,.7],['bun',[.4,.25,.12]],[.95,.94,.92],null),
  cabbie:P('A cab driver','Ferrier Lane rank',[.62,.46,.36],['crop',[.12,.1,.08]],[.3,.3,.32],[.2,.2,.22]),
  neonate:P('A frightened young woman','Embraced last month',[.8,.7,.68],['long',[.1,.08,.06]],[.3,.2,.3],[.2,.15,.2],{eyeGlow:[.3,.05,.05]}),
  boyfriend:P('A young man on the bridge','The Vellum footbridge',[.84,.7,.62],['curly',[.25,.15,.08]],[.6,.6,.62],[.25,.25,.3]),
  hunter2:P('A man with a crossbow','Self-appointed',[.86,.72,.64],['shaved',[.4,.3,.2]],[.25,.3,.2],[.2,.25,.15]),
  kid:P('A boy in a football shirt','Up past his bedtime',[.7,.55,.45],['crop',[.1,.08,.06]],[.8,.1,.1],null,{height:.72}),
  chef:P('A cook on his break','The Golden Dragon',[.86,.72,.56],['crop',[.08,.06,.05]],[.95,.95,.95],null),
  oldkin:P('An old Kindred in a deckchair','Older than the street',[.7,.66,.64],['long',[.8,.8,.8]],[.3,.28,.25],[.4,.35,.3],{eyeGlow:[.3,.2,.1]}),
  ghoulgirl:P('A girl with a Court ribbon','Somebody\'s ghoul',[.88,.8,.76],['fringe',[.8,.6,.3]],[.6,.05,.1],null),
  postman:P('A postman','Night sorting office',[.84,.7,.62],['crop',[.5,.4,.3]],[.2,.3,.6],[.15,.2,.45])
});})();
NL.Script.add(String.raw`
// =====================================================================
// THE BRIDE
// =====================================================================
# ev.bride street=2,3,4 w=2
> On the steps of City Hall annex on Kerr Street, at one in the morning, a woman in a wedding dress is sitting with her shoes in her lap and her mascara down to her chin. There's confetti on the sidewalk. Wet. Hours old.
bride: Don't. Don't ask. I know how it looks.
* "How does it look?"  -> ev.bride1
* Sit down next to her.  -> ev.bride2
* Walk on.  -> ev.bride3

# ev.bride1
bride: It looks like I got stood up. Which I did. Which is fine. Which is FINE. Eight years. Eight years and he texted. From the airport. "Can't do it, Jen, sorry." Sorry with a lowercase s.
@next ev.bride2

# ev.bride2
> You sit. The step is cold. She doesn't notice that you don't make it any warmer.
bride: My mom spent eleven thousand dollars. There's a cake in the Grand with a little plastic us on top. Everyone's still at the reception. Getting drunk on his dad's credit card. I came out to get some air four hours ago.
pulse(4): Her heart is going slow and heavy. Not panic. Grief. And underneath it, faintly, relief, which is making her feel worse.
* "Do you want to know a secret? You're relieved."  -> ev.bride4 {do lean:candour+1}
* "He doesn't deserve you."  -> ev.bride5
* Give her your coat.  -> ev.bride6 {do lean:mercy+1}
? stagecraft 9 "Go back in. Make a speech. Make it the best night of their lives without him."  -> ev.bride7 | ev.bride5 {id ev_bride}

# ev.bride3
> Behind you, she starts laughing. Or crying. On Kerr Street at one in the morning, there isn't much difference.
@end

# ev.bride4
> She stares at you. Then she laughs, a horrible honking laugh, and puts her face in her hands.
bride: Oh my God. Oh my God, I am. I'm SO relieved. I didn't want to marry him. I didn't want to marry him since 2019. I just didn't know how to stop.
bride: Who ARE you?
* "Nobody. A friend of the night."  -> ev.bride8

# ev.bride5
bride: Everyone's going to say that. My mom's going to say that. It doesn't help. It doesn't help that he doesn't deserve me if I don't get him.
> She puts her shoes back on. They're the wrong size. They've been the wrong size all day.
@end

# ev.bride6
> You put your coat round her shoulders. She doesn't ask why it's cold inside, too.
bride: Thanks. Thank you. You're the first person all day who hasn't wanted something from me. Hairdresser. Photographer. Him.
{do comp+1}
@end

# ev.bride7
> She looks at you. She looks at the Grand, across the road, its windows lit, the sound of a DJ playing *Come On Eileen* to a room full of people pretending.
bride: ...A speech.
> She stands up. She hitches up the dress. She walks across Kerr Street in the rain like a woman going to war.
> Ten minutes later, through the window of the Grand, you see her standing on a chair with a microphone. You can't hear what she says. You see two hundred people stand up and cheer.
{do comp+2; xp:15:A speech}
@end

# ev.bride8
bride: A friend of the night. That's the most romantic thing anyone's said to me all day. You're not hitting on me, are you? No. You're not. You look like you've got bigger problems.
{do comp+1}
@end

// =====================================================================
// THE TAXI
// =====================================================================
# ev.cab street=2,3,4,5
> A gypsy cab pulls up beside you on Ferrier Lane without you hailing it. The window comes down. A man in his fifties with a rosary hanging from the mirror and a cigarette he's not allowed to smoke.
cabbie: You. I know you. I drove you early Monday morning. Four-something. From the Strip. You were covered in... you said it was ketchup.
cabbie: You left something in my cab.
* "What did I leave?"  -> ev.cab1
* "You've got the wrong person."  -> ev.cab2

# ev.cab1
> He hands it through the window. A wallet. Cheap brown leather, rain-swollen. Inside: twenty dollars, a library card with the name rubbed off, a photo of two kids on a beach, one of them laughing at a dog.
nostalgia(5): The beach. The dog. You know the dog. You know the dog's name. It's on the tip of... gone.
cabbie: I kept it. I thought: someone'll want this. Nobody came. Then I saw you tonight and I thought: there they are.
{do flag:gotWallet=1; sync-1:A photograph}
* "Thank you. What do I owe you?"  -> ev.cab3
* "Did I say anything? In the cab?"  -> ev.cab4

# ev.cab2
cabbie: No, I've got the right person. I never forget a fare. Thirty-one years. You don't forget the ones who don't breathe.
@next ev.cab1

# ev.cab3
cabbie: Nothing. Nothing. Just... whatever you are, don't get in my cab again. Please. My wife's got a bad heart and I need my nerves.
@end

# ev.cab4
cabbie: You said one thing. Over and over, in the back. "It's 4:14. It's 4:14." Like you were trying to remember to tell someone.
cabbie: Then you said: "Tell my sister I'm sorry." And you gave me an address out on the coast. Eighty miles. I said I don't go that far. And then you said "no, don't" and got out at the lights.
{do flag:cabSister=1; mem:cabbie:sister}
* "Do you remember the address?"  -> ev.cab5

# ev.cab5
? nostalgia 10 "Make him say it. Make yourself hear it."  -> ev.cab6 | ev.cab7 {id ev_cab}

# ev.cab6
cabbie: Fourteen... fourteen Harbour Row. Saltmarsh. "The one with the fish on the mailbox." You said it twice.
nostalgia(8): Fourteen Harbour Row. A fish doodled on a mailbox in marker. A woman in a cardigan correcting spelling tests at a kitchen table. Your sister. *Your sister.*
{do flag:knowSisterAddr=1; xp:25:Fourteen Harbour Row}
@end

# ev.cab7
cabbie: Something Road. I'm sorry. It was Monday. I've had two hundred fares since Monday.
@end

// =====================================================================
// THE NEW ONE
// =====================================================================
# ev.newb street=3,4 w=2
> Behind the Golden Dragon, by the dumpsters, a young woman is crouched over a cat. It's dead. She's crying. Her mouth is red to the nose.
neonate: Don't. Don't look at me. I'm not... I didn't mean to. It was just there. It was just THERE and I was so...
pedigree(6): Embraced a month ago, maybe less. No sire with her. No ribbon, no clan mark. Somebody made her and left her. It happens. It happened to you.
* "I know. I know. It's all right."  -> ev.newb1 {do lean:mercy+1}
* "Who made you?"  -> ev.newb2
* "Get off the street before someone sees you."  -> ev.newb3

# ev.newb1
> She looks up. Your eyes. Her eyes. Same color.
neonate: You're... you're one too. Oh God. Oh God, there's more of us. I thought it was just me. I thought I was going mad.
neonate: I don't know anything. I don't know what I am. I've been sleeping in a storage unit on Kerr Street in a sleeping bag. I wake up and I'm so hungry I can't see.
* "Come with me. I'll find you somewhere."  -> ev.newb4
* Give her the rules. Everything you've learned.  -> ev.newb5
* Give her blood. Some of yours.  -> ev.newb6 {blood}

# ev.newb2
neonate: A man. At a party. In September. He said I was beautiful. He bit me in the toilets and I woke up in the river and he was gone.
neonate: He had a ring. A silver ring with a bird on it.
web(6): The Gilded Court's sigil is a hummingbird. Somebody at Séverine's parties is making childer and throwing them in the Vellum.
{do flag:knowNewbSire=1}
@next ev.newb1

# ev.newb3
neonate: Off the... where? WHERE? I don't have anywhere. Nobody tells you anything. Nobody!
> She runs. Into the dark, over the wall, faster than she knows she can go. She'll be dead or found by Sunday.
{do lean:mercy-1}
@end

# ev.newb4
* Take her to Gideon. He has boxes.  -> ev.newbg {if alive:gideon}
* Take her to Mother Soot. Nobody looks in the pipes.  -> ev.newbs {if alive:soot}
* Take her to Margo.  -> ev.newbm {if !flag:margoDead&flag:metMargo}
* Tell her what you can, and let her go.  -> ev.newb5

# ev.newbg
> Gideon looks at her over his half-moon glasses for a long time. Then he takes a key from the board.
gideon: Box nine. It's the good one. Rule one: we don't eat cats. Rule two: we pay in cash or kindness. Rule three: you come and see me every night so I know you're not dead.
{do flag:newbSafe=gideon; xp:20:Box nine; tick:20}
@end

# ev.newbs
soot: A lost one. A lost one, lost one. Mm. Down here. Down here with the jars. The rats will teach her. The rats teach everyone.
{do flag:newbSafe=soot; xp:20:A lost one; tick:20}
@end

# ev.newbm
margo: Oh, look at you. Oh, you poor thing. Sit down. Sit down here. Have you got a coat? You haven't got a coat. Here.
{do flag:newbSafe=margo; xp:20:Margo's coat; tick:20}
@end

# ev.newb5
> You sit behind the Golden Dragon on a crate and tell her everything. The sun. The hunger. The Masquerade. The Court. Feed from the sleeping, the drunk, the willing. Never the same one twice in a week. Never a child. Never to the end.
> She listens like a student cramming the night before an exam.
neonate: Never to the end. Okay. Okay. I can do that. I think I can do that.
{do comp+1; flag:newbTaught=1; tick:30}
@end

# ev.newb6
> You open your wrist. She drinks like a baby, with her eyes closed.
> When she's done, the red has gone out of her eyes. She can think. She looks at you like you're the first person who's ever been kind to her, which you might be.
neonate: Thank you. Thank you. My name's Priya. What's yours?
* Tell her.  -> ev.newb7 {if flag:knowName}
* "I don't know yet."  -> ev.newb8

# ev.newb7
neonate: Casey. Okay. I'll remember. I'll always remember.
{do vitae-2; flag:newbSafe=self; flag:priya=1; rel:priya+3}
@next ev.newb4

# ev.newb8
neonate: You don't know your NAME? Oh my God. Oh my God, is that going to happen to me?
{do vitae-2; flag:priya=1}
@next ev.newb4

// =====================================================================
// THE FOOTBRIDGE
// =====================================================================
# ev.bridge street=3,4,5
> On the Vellum footbridge, the one with the padlocks, a young man is standing on the wrong side of the railing. His hands are behind him, holding on. He's looking at the water. He hasn't seen you.
pulse(5): Very fast. Very shallow. He's been standing there a long time, waiting for his hands to let go.
* Walk up slowly. Talk.  -> ev.br1
* Grab him. Now. You're faster than anything.  -> ev.br2
? velvet 10 "Lean on the rail next to him. Say nothing for a while."  -> ev.br3 | ev.br1 {id ev_br}

# ev.br1
boyfriend: Don't. Don't come any closer. I'm not... I'm just looking.
* "It's a good view."  -> ev.br4
* "Tell me what happened."  -> ev.br5

# ev.br2
> You're across the bridge and you've got him by the collar before his body has time to know it's falling. You haul him back over the rail like a sack. He lands on the boards and stares at you.
boyfriend: How did you... nobody moves like that. Nobody MOVES like that.
> Then he starts crying. Then he doesn't stop for a long time. You sit with him. A man walking a dog goes past and pretends not to see.
{do comp+1; heat+0; lean:mercy+1}
@next ev.br6

# ev.br3
> You lean on the rail beside him. You look at the water. You don't say anything. The padlocks clink. Somewhere downstream a tug hoots.
> After about ten minutes he says, to the water:
boyfriend: She left. Two years. She left on my birthday. I lost the apartment. I lost my job because I couldn't get up. I'm twenty-six. I've been sleeping in my car.
@next ev.br5

# ev.br4
boyfriend: Is it? I can't tell any more. Everything looks the same. Grey.
@next ev.br5

# ev.br5
boyfriend: I'm just so tired. Do you know what I mean? Not sleepy. Just tired of being... of being here.
tenant: Child. Be careful what you say to him. You're the last thing he'll ever hear, or the first thing after this.
* "I know exactly what you mean. I'm tired too. I'm still here."  -> ev.br7 {do lean:candour+1}
* "The water's freezing. It doesn't take you quickly. I know."  -> ev.br8
* "There's someone who'd want you to come back over."  -> ev.br9

# ev.br7
> He turns his head. He looks at you properly. Your face, your hands, the rain on you that doesn't steam.
boyfriend: ...You do look tired. You look like death.
* "I've been told."  -> ev.br10

# ev.br8
boyfriend: How do you know?
* "I was in it on Monday. I came out."  -> ev.br10

# ev.br9
boyfriend: Who? Who'd want that?
* "Me. I don't even know your name and I'd want that."  -> ev.br10
* "Your mom."  -> ev.br10

# ev.br10
> He laughs. Wet, awful, real. Then he climbs back over. His legs don't work properly. You catch him.
@next ev.br6

# ev.br6
> You walk him off the bridge. At the end of it there's a phone box with a sign: CRISIS LINE. FREE. 24 HOURS.
boyfriend: I'm Ollie. Sorry. I don't know why I'm telling you that.
* Walk him to St. Jude's. Make sure someone sees him.  -> ev.br11 {do tick:30}
* Give him the number. Let him choose.  -> ev.br12

# ev.br11
> Rostova's nurses take him in through the ER doors. One of them, a woman with a Glasgow accent, puts a blanket round him and doesn't let go of his arm. At the doors, he looks back for you. You've already gone. It's better that way.
{do flag:ollieSafe=1; comp+2:Ollie; xp:25:The footbridge}
@end

# ev.br12
> He stands in the phone box for a long time with the receiver in his hand. Then he dials. You hear him say "hello" in a voice like a child's. You walk away before you can hear anything else.
{do flag:ollieSafe=1; comp+2:Ollie; xp:20:The footbridge}
@end

// =====================================================================
// THE CROSSBOW
// =====================================================================
# ev.xbow street=3,4,5
> A click behind you, on Kerr Street. You know the sound now. You've heard it in films. A bolt being seated.
hunter2: Don't turn round. Don't. I've got silver tips and holy water and a picture of your face on my phone.
hunter2: You did Danny. Danny Kowalski's cousin. Two weeks ago. In the parking garage.
pulse(5): Shaking hands. Shaking voice. He's never done this before. He's been watching videos on the internet.
* "I didn't. I've been like this five days."  -> ev.xb1 {do lean:candour+1}
* Turn round. Slowly.  -> ev.xb2
* Move. Faster than the bolt.  -> ev.xb3

# ev.xb1
hunter2: You're... five days? You're lying. You'd say anything.
? velvet 10 "Look at me. Look at my face. Do I look like I know what I'm doing?"  -> ev.xb4 | ev.xb5 {id ev_xb}

# ev.xb2
> You turn. A man in his thirties in a camouflage jacket from an army surplus shop. A crossbow from a sports shop. A wooden cross duct-taped to the stock.
> He's crying. He doesn't know he's crying.
@next ev.xb1

# ev.xb3
> The bolt goes where you were. You're beside him. The crossbow's in your hand. He's on the sidewalk. He's never been this frightened in his life.
hunter2: Please. Please. I've got a kid.
* Snap the crossbow and give it back.  -> ev.xb6
* "Who told you to come after us?"  -> ev.xb7
* Drink. He came here to kill you.  -> ev.xb8 {blood}

# ev.xb4
> He looks. He sees a frightened person in a coat that doesn't fit, soaked, five days dead, who looks exactly as lost as he does.
hunter2: ...Oh God. Oh God, you're a kid. You're just... what happened to you?
> He lowers the crossbow.
@next ev.xb7

# ev.xb5
hunter2: No. No, I'm not falling for it. They said you'd do this. They said you'd get in my head.
> He fires. It goes through your shoulder. Silver. It burns like a cigarette put out on your soul. He runs.
{do vitae-1; comp-2:Silver; heat+1}
@end

# ev.xb6
> The crossbow snaps like a breadstick. You hand him the pieces.
hunter2: ...That was two hundred bucks.
* "Go home to your kid."  -> ev.xb9

# ev.xb7
hunter2: Nobody told me. There's a forum. People post. Photos, locations. Someone posted the parking garage. Someone posted you. On Tuesday. Someone called "Daybreak".
web(7): Daybreak. As in: the thing that kills us. Somebody with a sense of humour, or a grudge. And a man with a crossbow who listens to them.
{do flag:knowDaybreak=1; mem:hunter2:forum}
@next ev.xb9

# ev.xb8
> You drink. He came here to kill you. He came here because someone on the internet told him to, and his cousin is dead, and he's got a kid.
> You stop when his heart stutters. You leave him on the sidewalk in the rain with a broken crossbow and two holes in his neck that will make him the most famous man on the forum.
{do feed:3:Choleric:a hunter:mortal; lean:mercy-1; heat+1}
@end

# ev.xb9
hunter2: Go home. Yeah. Yeah. ...Sorry. About... sorry.
> He walks off holding the pieces. At the corner he stops and calls back:
hunter2: Danny wasn't even nice! He owed everyone money!
@end

// =====================================================================
// THE FOOTBALL SHIRT
// =====================================================================
# ev.kid street=2,3,4
> A boy of nine in an oversized Sixers jersey is sitting on the curb on Halloran Street at half past midnight, eating a bag of chips. No coat. No adult.
kid: You're out late.
* "So are you."  -> ev.kid1
* "Where's your mom?"  -> ev.kid2

# ev.kid1
kid: My mom's at work. She does nights at the Safeway. My grandma's meant to have me but she's asleep in front of the TV and I got bored.
kid: You look weird. Are you a goth?
* "Sort of."  -> ev.kid3
* "I'm a vampire."  -> ev.kid4 {do lean:candour+1}

# ev.kid2
@next ev.kid1

# ev.kid3
kid: My cousin's a goth. He's got a skull ring. He's sixteen. He's well hard.
@next ev.kid5

# ev.kid4
kid: No you're not. Vampires aren't real.
kid: ...Are you though? Prove it.
* Show him your teeth. Just a flash.  -> ev.kid6
* "No, I'm joking. I'm a goth."  -> ev.kid3

# ev.kid5
> He offers you a chip. Flamin' Hot.
* Take one.  -> ev.kid7
* "No thanks."  -> ev.kid8

# ev.kid6
> You show him. Just for a second.
> He drops the chips. Then he laughs, delighted, the way only a nine-year-old can be delighted by a monster.
kid: WICKED. That's so wicked. Can you fly? Can you turn into a bat? Do you know Dracula?
> He doesn't believe you. He thinks it's the best costume he's ever seen. He's going to tell his whole class on Monday.
{do lean:candour+0}
@next ev.kid8

# ev.kid7
> You eat a Flamin' Hot chip on a curb on Halloran Street at half past midnight with a nine-year-old. It tastes like ash and salt. He watches to see if you like it.
kid: Good, right?
@next ev.kid8

# ev.kid8
kid: I'd better go in. Grandma'll lose it if she wakes up.
* Walk him to his door.  -> ev.kid9 {do lean:mercy+1}
* "Go on, then."  -> ev.kid10

# ev.kid9
> You walk him to number forty. He has a key on a shoelace round his neck. At the door he turns round.
kid: Night, vampire.
> The door closes. You hear the TV through it, and an old woman's voice: "Kyle? Kyle, is that you?" and the boy saying "Grandma, I met a VAMPIRE."
{do comp+1}
@end

# ev.kid10
> He runs up the street. At the corner he turns and waves.
@end

// =====================================================================
// THE COOK
// =====================================================================
# ev.cook street=2,3,4,5
> Out the back of the Golden Dragon, a cook in whites is having a cigarette on an upturned bucket. He nods at you. You nod back. He offers you the packet.
chef: You're the one who's always walking past at two. Every night this week. I see you.
chef: You never eat. My wife says you're a ghost. I said ghosts don't have such bad coats.
* Take a cigarette. Hold it. Don't smoke.  -> ev.ck1
* "Your wife's closer than you'd think."  -> ev.ck2 {do lean:candour+1}
* Keep walking.  -> ev.ck3

# ev.ck1
> You hold it. He lights it for you. You let it burn down between your fingers. He doesn't comment.
chef: Twenty-two years I've been doing this. Out here at two, one cigarette. You see everything. The drunks, the lovers, the police. The ones who don't breathe.
chef: There's more of you than people think. I don't mind. You never cause trouble out here. You're very polite. Politer than the drunks.
* "Do you ever feed them? The ones who don't breathe?"  -> ev.ck4
* "Thank you."  -> ev.ck3

# ev.ck2
chef: Ha! I knew it. I told her. I said: that one doesn't eat. She said: maybe they're on a diet.
@next ev.ck1

# ev.ck3
chef: Night.
@end

# ev.ck4
chef: Feed them? With what? Crispy duck?
> He thinks about it.
chef: ...There's an old man. Comes every Sunday. Sits on that wall. Very old, very tired, smells like a church. I give him the duck blood from the kitchen, from the morning delivery, in a takeaway carton. He says it's like drinking a photograph of food. He says thank you in Mandarin. Not modern Mandarin. Old.
{do flag:knowDuckMan=1}
@next ev.ck3

// =====================================================================
// THE DECKCHAIR
// =====================================================================
# ev.chair street=3,4,5
> On the roof of a bus shelter on Vine Street, in a striped deckchair, wrapped in a tartan blanket: an old Kindred. Very old. You feel it the way you'd feel an old building lean over you.
oldkin: Ah. The Sheriff's child. Come up. Come up, if you like. There's a second deckchair. There's always a second deckchair. Nobody ever uses it.
* Climb up.  -> ev.ch1
* "Who are you?"  -> ev.ch2

# ev.ch1
> You climb up. The second deckchair is wet. You sit in it anyway. From the roof of the bus shelter you can see right down Vine Street to the river, and the lights on the water, and the floodlight on Ferrier Lane sweeping, sweeping.
oldkin: I come up here every night. Since 1888. There was no bus shelter then. There was a gallows. It was a better view.
@next ev.ch2

# ev.ch2
oldkin: Nobody. Nobody now. I was a Prince once. In another city. A long time ago. Now I sit in a deckchair and watch the buses.
oldkin: You'll be a Sheriff, I hear. Or you'll be ash. Either way, you'll be something. I envy that. I've been nothing for a hundred and thirty years, and it's very restful, and I'd give anything to be something again.
* "Why did you stop?"  -> ev.ch3
* "Can you tell me anything? About Friday?"  -> ev.ch4

# ev.ch3
oldkin: I won. Everything. Every war, every Elder, every Prince who came for me. I sat on a throne of bone in a city of a million souls.
oldkin: And one night I realized there was nobody left who'd known me before. Not one. Everyone who'd ever loved me as a person was ash. I was a crown on a chair. So I got up and walked away and nobody noticed for a week.
tenant: ...I know him. I know who he is. He was the Prince of Lyon in 1793. They said he walked into the sun. He didn't. He walked to a bus shelter.
{do mem:oldkin:lyon}
* "Don't let that happen to me."  -> ev.ch5

# ev.ch4
oldkin: Friday. Hm. Let me see.
oldkin: Ambrose will be fair, which is worse than cruel. Séverine will lie, which she can't help. The Syndicate man will sell you to whoever pays best, then regret it. And someone will try to kill everyone, because someone always does.
oldkin: Keep somebody alive who knew you before. That's all I've got. That's the only thing worth anything.
@next ev.ch5

# ev.ch5
oldkin: I can't stop it happening. Nobody can. You can only choose who you keep.
oldkin: Go on. Go down. The bus is coming, and it doesn't like company on its roof.
{do comp+1; xp:15:The deckchair}
@end

// =====================================================================
// THE RIBBON
// =====================================================================
# ev.ribbon street=3,4 w=1
> A girl in her twenties with a little red ribbon on her wrist is waiting for you outside the launderette. Court ghoul. Her pupils are huge.
ghoulgirl: Message from the Gilded Court. From someone in the Gilded Court. They didn't say who. They said you'd know.
> She hands you an envelope. Thick cream paper. Wax seal: a hummingbird.
* Open it.  -> ev.rb1
* "Who sent you?"  -> ev.rb2

# ev.rb1
> One line, in purple ink, in a beautiful old hand: *"Friday, the third bench from the left. Look under it. — A friend who cannot afford to be one."*
web(6): A friend in the Court. Someone who can't be seen to help you. Not Séverine, she'd never be so subtle. Lisette? Coral? Someone older?
{do flag:benchNote=1}
@next ev.rb2

# ev.rb2
ghoulgirl: I'm not allowed to say. I don't know anyway. They tell me things and I forget them. It's nice. Forgetting.
pulse(5): Her heart is slow. She's been fed on tonight, and fed, and fed on. She's somebody's tea set.
* "Do you want to get out? Away from them?"  -> ev.rb3 {do lean:mercy+1}
* "Thank them for me."  -> ev.rb4

# ev.rb3
ghoulgirl: Out? Out of what? This is my life. I'm very lucky. Everyone says I'm very lucky.
> She laughs. It goes on a bit too long.
ghoulgirl: ...Do you know what time the night bus goes to the coast? Just asking. Just in case.
* "Half three, from Vine Street. The number 9. It goes all the way to the coast."  -> ev.rb5
* Say nothing.  -> ev.rb4

# ev.rb4
ghoulgirl: I'll forget. Sorry. I'll try.
@end

# ev.rb5
> She writes it on her hand in biro. *3.30. VINE. THE 9.* She looks at it like it's a map.
{do flag:ribbonBus=1}
@end

// =====================================================================
// THE POSTMAN
// =====================================================================
# ev.post street=4,5
> A postman on a bicycle, at three in the morning, with a sack. He stops beside you and checks a letter against your face.
postman: You'll be... you. Yes. There's no address on it. It just says "the one in the Sheriff's coat, Ferrier Lane, after midnight". The sorting office has been passing it round since Tuesday. Nobody knew what to do. I said I'd try.
> He gives you the letter. A small cream envelope, yellowed. A four-cent stamp from 1961, never franked. On the back, in a man's careful hand: *Mrs. A. Dunmore. To be delivered when it's safe. — A.D.*
* Open it.  -> ev.ps1

# ev.ps1
> Inside, a single page in faded blue ink. A woman's handwriting, firm, slanting, impatient.
> *"Absalom. If you are reading this, I have died, and you have finally stopped standing at the back of things. Albert promised to get this to you when it was safe. God knows when that will be. Probably never. Albert is a dear but he couldn't post a parcel to save his life. Anyway. I want you to know I wasn't afraid. I want you to know it's only warm. And I want you to stop wearing those ridiculous glasses indoors. — A."*
tenant: ...
> Nothing. For a long time, nothing at all, from the voice in your blood. And then something you've never felt from him before: a sound like a man laughing and crying at the same time, very quietly, in the dark.
tenant: She made him post it. Sixty years. Albert. You useless, wonderful man.
{do sync+4:It's only warm; comp+3; flag:agnesPost=1; mem:tenant:agnespost}
postman: Was it important? It looked important.
* "Yes. It was the most important letter in the world."  -> ev.ps2

# ev.ps2
postman: Good. Good. I like it when they're important. Most of it's pizza leaflets.
> He cycles off into the rain, ringing his bell at nobody.
@end
`,'c_street3');

(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
  if(S.flags.benchNote)M.push({t:'Step to the third bench from the left. Reach underneath.',once:'tb_bench',ok:(st,S)=>{st.prog+=2;S.flags.benchFound=1;return [T('Taped under the bench: a single ledger page in Lady Ottilie\'s neat accountant\'s hand. A column of dates and a column of sums. The heading: *T.H. — services.*'),L('magistrate','...Whose hand is this?'),T('Along the front row, a woman in grey pearls has gone the color of chalk.')];}});
  return M;};})();
