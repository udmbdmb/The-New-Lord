'use strict';
/* THE NEW LORD — Night Two personal arcs, part two: Séverine, Malakor, Mother Soot, Dr. Rostova, Miller, and the second dawn dream */
NL.Script.add(String.raw`
// =====================================================================
// LADY SÉVERINE · Night Two · the VIP crypt
// =====================================================================
# sx2.0 arc=severine night=2 label="Ask for a private audience." if=room:vip&alive:sev&flag:metSeverine prio=1
@focus severine
> She receives you in the little side chapel off the crypt, where the bones of seventeenth-century monks have been arranged into a chandelier. Somebody has put real candles in it. Somebody has put a Persian rug over the grave slabs and a gramophone on a coffin lid.
severine: A private audience. How bold. The last man who asked me for one was Lord Ashby, in 1931, the week after I beat him with a sabre, and he wanted to know if I would marry him.
severine: I said no. He's been trying to forgive me ever since. Sit. Not there. That's Brother Anselm. He's sensitive.
pedigree(5): She's playing a record. Caruso, 1907, a scratched pressing. She was alive when this was recorded. She might have been in the room.
* "I wanted to thank you for Monday."  -> sx2.thank {if flag:sevAlly}
* "You set the Hound on me."  -> sx2.hound {if flag:sevEnemy}
* "Who were you, before?"  -> sx2.before
* "What do you want from me, my lady?"  -> sx2.want
* Kneel, unasked.  -> sx2.kneel

# sx2.thank
severine: For Monday. For not having you destroyed on the spot, you mean. One shouldn't thank people for the absence of a cruelty. It makes them think cruelty was the default.
severine: ...Though it was. You're quite right. Thank you for noticing.
{do lean:pride+1; mem:severine:thanked}
@next sx2.hub

# sx2.hound
severine: Set? I don't *set* Valko. Valko is a weather system. I merely told him where it was raining.
severine: You ate his master. He would have found you by Wednesday whether I spoke or not. I simply arranged for him to find you at a time and place of my choosing, rather than his.
web(5): That's not a denial. It's a confession with better posture.
* "That was generous of you."  -> sx2.houndsarc {do lean:candour-1}
* "If I survive him, I'll remember this."  -> sx2.houndthreat {do lean:pride+1}
* "Call him off."  -> sx2.houndoff

# sx2.houndsarc
severine: Sarcasm. Good. Sarcasm is the first thing a courtier learns and the last thing they lose. You'll go far, or nowhere. There's no middle distance in this city.
{do mem:severine:sarcasm}
@next sx2.hub

# sx2.houndthreat
severine: I would be disappointed if you didn't. A threat is a promise with its hair down. I collect them.
{do mem:severine:threatened; rel:severine-1}
@next sx2.hub

# sx2.houndoff
severine: Off. As if he were a lamp. No. But I will tell you something about him, for free, which is the rarest price I charge.
severine: Valko loved Absalom the way a dog loves the hand that beats it: completely and without understanding. If you want to live, don't fight him. Give him something to love instead.
{do mem:severine:valkotip; flag:knowValkoLove=1}
@next sx2.hub

# sx2.before
> She lifts the needle off the record. The silence is enormous.
severine: Before. You mean when I was warm.
severine: Lyon, 1889. A seamstress's daughter with a voice like a knife, singing for coins outside the Opéra. Then inside it. Then on its stage, for one season, as Lakmé, while the critics said I sounded like a bell being struck by God.
severine: A gentleman in the third box came every night. On the last night of the season he came to my dressing room and offered me the one thing a soprano wants more than applause.
* "Eternity."  -> sx2.eternity
* "Your voice, forever."  -> sx2.voice
* "Revenge."  -> sx2.revenge

# sx2.eternity
severine: How dull you must think me. No.
@next sx2.voice

# sx2.voice
severine: My voice, unchanged, forever. A soprano has fifteen good years. He offered me five hundred.
severine: What he did not say is that the Choir can sing, but not be heard. Mortals hear us as a draught, a shiver, a song they half remember. I have not sung to a living audience in a hundred and thirty years. I sing to the dead. To Brother Anselm.
nostalgia(5): She says it lightly. A hundred and thirty years of singing to bones.
pulse(6): No heartbeat to read, but her fingers have gone still on the gramophone arm, the way living fingers go still before they shake.
* "I'd like to hear you sing."  -> sx2.sing {do lean:mercy+1}
* "That's the saddest thing I've ever heard."  -> sx2.sad
* "So you hated Vane because he could still be heard?"  -> sx2.vane

# sx2.revenge
severine: Revenge is what one wants *after*. You're getting ahead of the story.
@next sx2.voice

# sx2.sing
> She looks at you for a long moment. Then she sings, very quietly, four bars of the Bell Song, and you hear it the way the dead hear it: perfectly, every overtone, a sound like someone drawing a wire through your spine.
> When she stops, the candles in the bone chandelier are all leaning toward her.
severine: There. Now you're the first person in thirty years to hear me. Don't make me regret it.
{do mem:severine:heard; rel:severine+1; flag:sevSang=1}
@next sx2.hub

# sx2.sad
severine: Is it? You've only been dead three days. Wait.
{do mem:severine:sad}
@next sx2.hub

# sx2.vane
severine: Clever. No. I hated Vane because he was a *policeman*. A policeman with a three-piece suit and a ledger, who looked at Elysium and saw a protection racket. Which it is. But one doesn't *say* so.
tenant: She's lying, child. She hated me because I knew who sired her and why. Ask her about the third box.
{do mem:severine:vane}
@next sx2.hub

# sx2.want
severine: From you? A great deal and very little. I want the Sun-Vessel. You know where it is, or you will, because it was Absalom's and Absalom is in you, the poor thing.
severine: I want to know whether you are going to be a problem or a tool. And I would very much like to know who in this Ward pointed a lance at a Sheriff. Not because I mourn him. Because it might be pointed at me next.
web(5): She wants the Vessel. She's afraid. And she still hasn't said she didn't know about the ambush.
* "A tool. Yours. For now."  -> sx2.tool {do lean:pride+1; lean:loyalty+1}
* "Neither. A free agent."  -> sx2.free {do lean:pride-1}
* "Did you know about the lance?"  -> sx2.lance
? stagecraft 11 "Tell her you'll bring her the Vessel. Mean none of it."  -> sx2.lie | sx2.liefail {id sx2_lie}

# sx2.tool
severine: For now. Yes. That's the only honest length of time anyone serves anyone.
severine: Then here is your first task, tool. Malakor is building something on Platform 0. I want to know what. Bring me a word, a drawing, a smell. I am not particular.
{do flag:sevTaskMalakor=1; mem:severine:tool; rel:severine+1}
@next sx2.hub

# sx2.free
severine: There are no free agents in Port Vellum, only agents who haven't been invoiced yet.
{do mem:severine:free}
@next sx2.hub

# sx2.lance
> A long pause. She turns the gramophone handle three times, slowly.
severine: I knew someone wanted Absalom gone. Everyone wanted Absalom gone. I knew there would be... an attempt. I didn't know what, or when.
severine: That is the truth, as far as it goes. It does not go very far. Nothing does, down here.
web(6): A partial truth, with the edges filed off. She knew more than "an attempt". She paid someone to fix a door.
{do mem:severine:lance; flag:sevAdmitAttempt=1}
@next sx2.hub

# sx2.lie
severine: Good. Bring it to me before Friday and I will make you a knight of the Court. Ha. Not really. But something with a ribbon.
pedigree(4): She believed you. Or she enjoyed being lied to well, which in this room amounts to the same.
{do flag:sevPromisedVessel=1; lean:candour-1; mem:severine:promisedvessel}
@next sx2.hub

# sx2.liefail
severine: Oh, child. You lie like a chorus girl. All the right notes and no one believing a word. Try again when you're older. Try again in fifty years.
{do rel:severine-1; comp-1:Caught}
@next sx2.hub

# sx2.kneel
> You go down on one knee on the Persian rug, in the candlelight, among the monks.
severine: Oh. Oh, how *lovely*.
severine: Up, up. Kneeling is for Princes and for proposals, and I've had quite enough of both. But I'll remember you did it. One remembers.
{do lean:pride+2; mem:severine:knelt; rel:severine+1}
@next sx2.hub

# sx2.hub
* "Who sired you? The man in the third box."  -> sx2.sire {once} {if mem:severine.vane}
* "What do you read in Gideon's box, every Christmas?"  -> sx2.box {once} {if flag:knowSevBox}
* "Tell me about Lord Ashby."  -> sx2.ashby {once}
* "Thank you for your time, my lady."  -> sx2.bye

# sx2.sire
severine: ...Absalom told you that. No. Absalom is *in* you. Of course he did.
severine: The man in the third box was the Prince of Lyon's favorite, and he made me because he was bored, and he left me in Port Vellum in 1893 because he was bored again. He is ash now. A Sheriff did it. In 1920. Guess which.
tenant: I did. On the Prince's orders. She thanked me. Then she never spoke to me civilly again. She'd wanted to do it herself.
pedigree(6): Vane destroyed her sire. Took her revenge out of her hands. A century of hatred over a stolen murder.
{do mem:severine:sire; flag:knowSevSire=1; sync+1:Old crimes}
@next sx2.hub

# sx2.box
> For the first time, she looks genuinely surprised. It takes ten years off her, which on her is a hundred.
severine: Gideon. That old crow.
severine: Letters. From my mother. Twenty-six of them, Lyon to Port Vellum, 1893 to 1919, in a seamstress's hand, asking when I'm coming home. I never wrote back. I couldn't explain why I'd stopped aging. I read them once a year. On the night she died.
* "I won't tell anyone."  -> sx2.boxsecret {do lean:loyalty+1; rel:severine+1}
* "That's useful to know."  -> sx2.boxuse {do lean:loyalty-1}

# sx2.boxsecret
severine: You'd better not. I'm told I'm very frightening when I'm embarrassed.
{do mem:severine:boxkept; flag:sevBoxSecret=1}
@next sx2.hub

# sx2.boxuse
severine: Useful. Yes. Everything is, down here. Get out.
{do mem:severine:boxthreat; rel:severine-2; flag:sevEnemyHint=1}
@end

# sx2.ashby
severine: Ashby. A Sovereign. A charming idiot with a fortune and a tontine. He'll ask you to dinner. Don't go. He'll ask you to duel. Do go, and lose gracefully; he's terribly good and very sensitive about it.
severine: He's been in love with me for ninety years. It's the only constant thing in my life apart from the Prince and the rent.
{do mem:severine:ashby; flag:knowAshby=1}
@next sx2.hub

# sx2.bye
severine: You may go. Do try to survive the week. You're the most interesting thing that's happened to the Marrow Ward since the Blitz, and I was in London for that.
@end

// =====================================================================
// MALAKOR · Night Two · the chop-shop under Platform 0
// =====================================================================
# mx2.0 arc=malakor night=2 label="\"Show me the workshop.\"" if=room:switchyard&flag:malakorTalked&alive:malakor
@focus malakor
> Behind the steel curtain: a surgery that is also a garage that is also a church to something. Car engines on chains. A dentist's chair with straps. Shelves of jars, labelled in a neat engineer's hand: CARTILAGE, LEFT. DONOR TEETH, ASSORTED. HOPE.
malakor: You want to see. Good. Most of my visitors want to not see very hard, and it makes them clumsy. Mind the drain.
abattoir(4): The drain runs red, then clear, then red. He's cleaning as he goes. A tidy butcher is a dangerous butcher.
* "What's in the jar marked HOPE?"  -> mx2.hope
* "Eleven faces. Why keep the twelfth?"  -> mx2.face
* "Who are your customers?"  -> mx2.customers
* "Teach me something."  -> mx2.teach

# mx2.hope
> He takes it down. Inside, in clear fluid, a small brown thing like a walnut.
malakor: A pineal gland. A mortal's. The little third eye that tells you when it's day. The old ones thought it was where the soul sat.
malakor: I take it out of every face I make. For myself. So that I remember that I can't feel the morning any more. I call it hope. It's a joke. Butchers have terrible senses of humour.
autopsy(5): He's not lying. There are forty jars like it, behind the first. Forty faces.
{do mem:malakor:hope}
@next mx2.hub

# mx2.face
malakor: Candour. You'll like me. Fine.
malakor: The first face was my own, born in Odessa in 1902. The second I made in 1931 when the Bolsheviks wanted the first. The third through ninth were for jobs. The tenth was for a woman who said she could not look at the ninth. The eleventh was the one I made after she was dead.
malakor: The twelfth is the one I wear. It's the first one I made for no reason at all. I simply wanted to see what I would look like if I had never been hurt.
pulse(5): It's a mild face. A schoolteacher's face. That's the most frightening thing about it.
* "Does it work? Looking like you've never been hurt?"  -> mx2.facework
* "I'd like to see the first one."  -> mx2.facefirst
* "You could make me a new face."  -> mx2.myface

# mx2.facework
malakor: On other people. Never in the mirror. That's the trick with faces: they're for other people. Yours is too.
{do mem:malakor:facework; rel:malakor+1}
@next mx2.hub

# mx2.facefirst
malakor: Nobody has seen the first one since 1931. Not even me. I kept it in a jar for a while. Then I fed it to the river.
malakor: There is a photograph. In Soot's collection. She charges a great deal for it.
{do flag:knowMalakorPhoto=1}
@next mx2.hub

# mx2.myface
malakor: I could. You'd have to want to be someone else. Do you?
* "Yes. I don't even know who I was."  -> mx2.facewant {do flag:faceInterest=1}
* "No. I'm finding out who I am."  -> mx2.facekeep {do lean:candour+1}

# mx2.facewant
malakor: Then don't change your face. Find out first. You can't sell what you haven't got. Come back when you know your name, and if you still want to be someone else, I'll give you a good price.
{do mem:malakor:facewant}
@next mx2.hub

# mx2.facekeep
malakor: Good. Most people who come here want to stop being someone. You want to *start*. That's rarer. It's more expensive, too, but not in money.
{do mem:malakor:facekeep; rel:malakor+1}
@next mx2.hub

# mx2.customers
malakor: Kindred who want to be someone else. Kindred who want someone else to stop. Mortals who want kidneys and don't ask where from. Ghouls who want to look younger. Once, a priest, who wanted me to remove the part of the brain that believes in God. I said there was no such part. He said, find it. I didn't. He paid anyway.
malakor: And the federal government. Once. They wanted a light that could be pointed.
web(6): He's telling you. He's practically drawing you a map. He built the lance for LANTERN's people.
* "You built the thing that killed Vane."  -> mx2.lance
* "Who in the government?"  -> mx2.govt

# mx2.lance
malakor: I built a thing. A thing is not a killing. A knife is not a murder.
malakor: But yes. I built it. Six weeks of work, the finest thing I've made in a century. Quartz and mercury and a cooling coil from a Soviet satellite. The buyer signed "R." and paid in gold. I didn't ask who R. was pointing at.
malakor: That's a lie. I asked. I was told "a tumour". I chose to find that funny.
{do mem:malakor:lanceadmit; flag:malakorAdmitLance=1; lean:candour+0}
@next mx2.hub

# mx2.govt
malakor: Men in grey. They never give names. They gave me a number. 4.14. A frequency. They wanted the light to sing at that frequency. I asked why. They said "so it'll talk to the others."
malakor: I have been thinking about "the others" ever since. I think it means there's more than one lamp.
{do flag:know414=1; mem:malakor:frequency}
@next mx2.hub

# mx2.teach
malakor: Teach. Ha. All right. Lesson one.
> He takes a pig's heart from a cold box and puts it on the table, and then a scalpel in your hand, and stands behind you like a piano teacher.
malakor: Everything that lives is mostly water and habit. Cut along the habit. Not the water. There. Feel that? The give? That's where it wants to come apart. Everything has a place where it wants to come apart. Even people. *Especially* people.
* Make the cut. Clean.  -> mx2.cutclean
* Make the cut. Enjoy it.  -> mx2.cutenjoy {do lean:restraint-1}
* Put the scalpel down.  -> mx2.cutno {do lean:restraint+1}

# mx2.cutclean
> It opens like a book. Malakor makes a small, pleased noise.
malakor: Steady hands. Good. You've cut before. Paramedic? Surgeon? A murderer, perhaps. Doesn't matter. The hands remember even when the head doesn't.
nostalgia(4): A scalpel in gloved fingers. A white room. Someone saying "clamp". It was you.
{do mem:malakor:hands; rel:malakor+1; flag:steadyHands=1}
@next mx2.hub

# mx2.cutenjoy
> It opens. It's warm still. Something in you purrs.
malakor: Ah. There. You see? There's a Butcher in every one of us. Most people spend their eternity pretending otherwise. I find it restful not to.
frenzy: MORE OF THESE. Bigger ones.
{do mem:malakor:enjoyed; rel:malakor+1}
@next mx2.hub

# mx2.cutno
malakor: No? Fine. Not everyone wants to know where they come apart. That's a lesson too.
{do mem:malakor:refused}
@next mx2.hub

# mx2.hub
* "Séverine wants to know what you're building."  -> mx2.sev {once} {if flag:sevTaskMalakor}
* "Why tell me any of this?"  -> mx2.why {once}
* "I'll come back."  -> mx2.bye

# mx2.sev
malakor: Of course she does. Tell her I'm building a better Séverine. Out of spare parts. It's coming along beautifully, it already sneers.
malakor: Or tell her the truth: a generator. For the lights down here. And for something else that is none of her business. She'll like the second answer better. It has a secret in it. She can't resist a secret.
{do flag:malakorGenerator=1; mem:malakor:sevmsg}
@next mx2.hub

# mx2.why
malakor: Because you asked. Nobody asks. They come in, they want a face, a gun, a kidney. Nobody wants to know how the drain works.
malakor: And because if you live to Friday, you will remember who told you the truth on Tuesday. I am investing. Butchers are very practical.
@next mx2.hub

# mx2.bye
malakor: Mind the drain.
@end

// =====================================================================
// MOTHER SOOT · Night Two · the shrine
// =====================================================================
# ux2.0 arc=soot night=2 label="\"Trade with me, Mother.\"" if=room:shrine&flag:metSoot
@focus soot
> Mother Soot is listening to a pipe. Literally: her ear pressed to a copper pipe that comes out of the wall and goes back into it, with her eyes shut and her lips moving, counting. Around her, two hundred candles and a thousand jars, each with a scrap of paper in it.
soot: Shh. Shh. Mrs. Halloran in the Rookery is telling her husband she's leaving him. She's said it eleven times this year. Mm. Mm. He's feeding the cats. He always feeds the cats when she says it.
soot: Trade. Yes. The little ones always want to trade. What have you got, greedy child? What have you got that I haven't heard through a wall?
* Offer her a secret about yourself.  -> ux2.self
* Offer her a secret about someone else.  -> ux2.other
* "What do you charge for a secret?"  -> ux2.price
* "What's in the jars?"  -> ux2.jars

# ux2.self
soot: About *you*. Oh. Yes. Oh, I'd like that. A new one's secrets are so fresh. Like milk.
* "I don't know my own name."  -> ux2.noname {do lean:candour+1}
* "The Tenant talks to me. In my sleep."  -> ux2.tenant {do lean:candour+1; sync-1}
* "I enjoyed it. Drinking him."  -> ux2.enjoyed {do lean:candour+1; lean:restraint-1}
* Lie. "I'm not alone. Someone sent me."  -> ux2.lie {do lean:candour-1}

# ux2.noname
soot: Oh, I know that one. Everybody knows that one. That's not a secret, that's a *rumour*. Rumours I get for free. Mm. Mm.
soot: But you *said* it. Out loud. To me. That's worth something. Trust is worth something.
{do mem:soot:noname}
@next ux2.give

# ux2.tenant
soot: Ahhh.
> She puts the pipe down. That's how you know you've given her something good.
soot: Diablerists hear the dead. Not all. Some. The strong ones hear the one they ate. The very strong ones hear everyone *he* ate. How many is he? How many is your Tenant carrying?
tenant: Don't tell her. Don't. She'll know what to sell.
* "Just him."  -> ux2.tenantone
* "I don't know. Sometimes there's more than one voice."  -> ux2.tenantmany {do sync+2:The chorus}

# ux2.tenantone
soot: Just him. Mm. For now.
{do mem:soot:tenant}
@next ux2.give

# ux2.tenantmany
soot: Oh. Oh, greedy child. You're a *house*. You're a whole house of people.
{do mem:soot:many; flag:sootKnowsMany=1}
@next ux2.give

# ux2.enjoyed
soot: Everyone does. Nobody says. You've said. That's the secret: not that you liked it. That you'd *say*.
{do mem:soot:enjoyed}
@next ux2.give

# ux2.lie
> She listens to you the way she listens to the pipes. Head tilted. Eyes shut.
soot: ...No. No, that's a lie. Lies have a hum. Like a fridge. You're humming.
soot: I don't trade for lies. I collect them separately. In a smaller jar.
{do mem:soot:lied; rel:soot-1}
@next ux2.hub

# ux2.other
soot: Someone else's. Mm. Whose?
* "Pemberton carried me into the freezer."  -> ux2.pem {if flag:pemConfessed|flag:prophetDone}
* "Leo Pruitt saw the Sheriff with a ledger before I came."  -> ux2.leo {if fact:leo:saw}
* "Tiny's kidneys are failing."  -> ux2.tiny {if fact:tiny:kidney}
* "Lady Séverine reads her dead mother's letters."  -> ux2.sev {if flag:sevBoxSecret|flag:knowSevBox}
* "Never mind."  -> ux2.hub

# ux2.pem
soot: Old news. The rats saw it Monday. But you giving it to me, that's new. You'd give up the old man. Mm.
{do mem:soot:gavepem; lean:loyalty-1}
@next ux2.give

# ux2.leo
soot: The boy. The boy with the jokes. Mm. Ledgers are worth knowing about.
{do mem:soot:gaveleo; lean:loyalty-1}
@next ux2.give

# ux2.tiny
soot: The big one on the door. Oh. Oh, the Lady would like that. The Lady doesn't keep broken things.
{do mem:soot:gavetiny; lean:loyalty-2; flag:tinySold=1}
@next ux2.give

# ux2.sev
> For a moment, even Soot is silent.
soot: ...Oh, that's a good one. That's a very good one. That's worth a big jar.
{do mem:soot:gavesev; lean:loyalty-2; flag:sevSecretSold=1}
@next ux2.give

# ux2.give
soot: Now. Fair is fair. What do you want to hear?
* "Who fixed the freezer door?"  -> ux2.door {once}
* "Where is Margo Kowalski?"  -> ux2.margo {once}
* "What's LANTERN?"  -> ux2.lantern {once}
* "Who sired me?"  -> ux2.sire {once}

# ux2.door
soot: Margo did. With a screwdriver. On Wednesday last. Somebody posted her an envelope in copperplate. The rats saw the stamp. Mm. Mm. Fancy stamp. Gilded.
{do flag:knowMargoDoor=1; mem:soot:told}
@next ux2.hub

# ux2.margo
soot: On the number 9 bus, Tuesday, six in the morning, with a carrier bag. Then off at Reliquary Row. Then in the back door of a shop that sells coffins. She's sleeping in one. Mm. Mm. With the lid open. She snores.
{do flag:knowMargoPawn=1; mem:soot:told}
@next ux2.hub

# ux2.lantern
soot: A word in grey mouths. A list in a grey van. A light that talks to other lights. Men who listen to me through my own pipes. Did you know that? They've put things in my pipes.
soot: I've put things in theirs, too.
{do flag:knowLanternBugs=1; mem:soot:told}
@next ux2.hub

# ux2.sire
soot: Oh, greedy, greedy. You don't have a sire, child. You have a *meal*. The blood that made you is the blood you drank.
soot: Before that, you were warm, and stupid, and on a list in a grey van. Number eight. Mm. Mm. That's all the pipes know.
{do mem:soot:told; flag:knowNumberEight=1}
@next ux2.hub

# ux2.price
soot: A secret for a secret. A drop for a drop. Sometimes a favour. Sometimes a finger. Not your finger. Somebody's.
soot: The Lady pays in favours. The butcher pays in parts. The grey men pay in nothing, because they don't know they're paying. Mm.
@next ux2.hub

# ux2.jars
soot: Voices. A word, a breath, a sigh through a pipe. I keep them. When people die, I still have their voices. I play them back sometimes, for company.
soot: I've got the Sheriff's. Lots of him. Do you want to hear him say your name? He said it once, on Sunday night, on the telephone. Your real one.
* "Yes. Play it."  -> ux2.namejar {if cash>=0}
* "Not yet."  -> ux2.hub

# ux2.namejar
soot: Not for free. Never for free. A big secret for that. Or a big favour. Or on Friday, when you're worth more. Mm. Mm. I'll keep it warm.
{do flag:sootHasName=1; mem:soot:namejar}
@next ux2.hub

# ux2.hub
* "Goodbye, Mother."  -> ux2.bye

# ux2.bye
soot: Bye bye, greedy. The pipes will tell me when you're in trouble. They always do.
@end

// =====================================================================
// DR. ROSTOVA · Night Two · St. Jude's
// =====================================================================
# rx2.0 arc=rostova night=2 label="\"Can I talk to you? Off the record.\"" if=room:stjude&flag:metRostova&alive:rostova
@focus rostova
> Rostova is suturing a drunk's forehead in a cubicle with the curtain half open. She doesn't look up. Her hands are perfect. The rest of her looks like it's been left out in the rain.
rostova: Off the record. Everything here is off the record. The records are a fiction for the insurance company.
rostova: Sit. Not on the bed. On the chair. You look like you need a check-up, which is funny, because you don't have a pulse.
autopsy(4): Neat sutures, nine of them, perfectly spaced. She could do this asleep. She might be.
* "You know what I am."  -> rx2.know
* "What do you remember about Monday morning?"  -> rx2.monday
* "You look like you haven't slept in weeks."  -> rx2.sleep
* "Check me over. I've never had a doctor look at me. Not like this."  -> rx2.exam

# rx2.know
rostova: I know what you aren't. You aren't alive, in any sense my textbooks would recognize. You aren't dead in any sense the coroner would. You buy expired O-negative from my fridge at three times the market rate.
rostova: I've treated your kind for six years. You come in with gunshot wounds that close while I watch. I pretend I don't see. You pretend I'm stupid. It's a very stable relationship.
{do mem:rostova:know}
@next rx2.hub

# rx2.monday
> The needle stops for half a second. Then it goes on.
rostova: I was here. All night. Ask the nurse. Ask the drunks. Monday's always busy.
pulse(6): No pulse to read in you; plenty in her. A hundred and four, and her pupils just jumped. She's lying, and she's frightened of being bad at it.
* "You drive a Volvo, don't you, doctor?"  -> rx2.volvo {if flag:knowVolvo}
* "All right. All night."  -> rx2.monok {do lean:mercy+1}
? autopsy 10 "You've got a burn on your right hand. Ozone burn. Fresh."  -> rx2.burn | rx2.burnno {id rx2_burn}

# rx2.volvo
> She finishes the suture. Ties it off. Cuts it. Puts the scissors down very carefully on the tray, the way you'd put down something that might go off.
rostova: Yes. A 1989 240 estate. It's the only thing my father left me.
rostova: Is that a question?
* "It was outside Kowalski's at four on Monday."  -> rx2.volvopush {do lean:candour+1}
* "Not tonight."  -> rx2.volvowait {do lean:mercy+1}

# rx2.volvopush
rostova: Then someone stole it, and put it back, and filled it with gas. Very considerate thieves.
rostova: Get out. No. Wait. Don't. I'm sorry. I'm very tired.
> She sits down on the edge of the bed. The drunk, half-asleep, pats her knee.
rostova: Not here. Not tonight. There are things I'd tell you, if I thought you could stop them. I don't think anyone can stop them.
{do mem:rostova:pushed; flag:rostovaCracked=1}
@next rx2.hub

# rx2.volvowait
rostova: ...Thank you.
{do mem:rostova:waited; rel:rostova+1}
@next rx2.hub

# rx2.burn
> You take her hand and turn it over. A pink weal across the back of it, the kind you get from a welding arc, the kind you get from standing too close to something very bright.
rostova: Kitchen. I'm a terrible cook.
autopsy: That's not a kitchen burn. That's ultraviolet. Hard UV. You'd have to be within two feet of the source. Facing it.
rostova: Let go of my hand, please.
{do mem:rostova:burn; flag:rostovaBurn=1}
@next rx2.hub

# rx2.burnno
rostova: Don't look at my hands. Doctors hate that. Look at my eyes, like a normal patient.
@next rx2.hub

# rx2.monok
rostova: ...Good.
@next rx2.hub

# rx2.sleep
rostova: Weeks. Months. I sleep on the bed in cubicle four between two and four if nobody's bleeding. I take a pill that's illegal in Canada.
rostova: I had a brother, Pasha. Leukaemia, at nineteen. I was twenty-two. Third year of medicine. I knew everything about leukaemia and nothing I knew did anything at all. Since then I don't really sleep. I just stop for a while.
pulse(5): She's never told anyone this at work. She's telling you because you're not a person to her. Not quite.
* "And you think our blood could have saved him."  -> rx2.cure
* "I'm sorry about Pasha."  -> rx2.pasha {do lean:mercy+1}

# rx2.cure
> She looks at you like you've opened her chest.
rostova: Your blood closes bullet wounds in four minutes. It stops the aging clock. It kills every pathogen I've ever put in a dish with it. And the only people who have it use it to stay pretty and eat people.
rostova: Yes. I think it could have saved him. I think it could save everyone. Do you know what I'd do for that?
web(6): The Tuesday room. The seven. That's what she'd do.
{do mem:rostova:cure; flag:knowRostovaMotive=1}
@next rx2.hub

# rx2.pasha
rostova: Don't be. Be useful. Sorry is what you say when you've stopped trying.
{do mem:rostova:pasha}
@next rx2.hub

# rx2.exam
rostova: You want an exam. All right. Up on the bed. Shirt.
> She does it properly: stethoscope (nothing), blood pressure (nothing), reflexes (excellent), pupils (they don't react to her penlight; they react to her pulse).
rostova: Core temperature twenty-one degrees. No respiratory rate unless you're speaking. Your eyes are tracking the vein in my neck. Please stop that.
rostova: And you've got scarring. Here. On the left forearm, inside. Old. Track marks? No. Blood draws. Dozens. Months of them, a year ago. You were someone's research subject.
nostalgia(6): A cot. A drip. Someone in a white coat saying "this'll sting". The same voice. The same exact voice.
* "Were they yours?"  -> rx2.examyours
* "Thank you, doctor."  -> rx2.hub

# rx2.examyours
> She doesn't answer. She puts the stethoscope back around her neck very slowly.
rostova: I see a lot of patients.
{do mem:rostova:exam; flag:rostovaRecognised=1}
@next rx2.hub

# rx2.hub
* "Where do you get the O-negative?"  -> rx2.blood {once}
* "Goodnight, doctor."  -> rx2.bye

# rx2.blood
rostova: Expired stock from the hospital network. And donations. People donate here because I pay twenty dollars and a cookie. It's not illegal. It's barely legal. I'm very good at barely.
{do mem:rostova:blood}
@next rx2.hub

# rx2.bye
rostova: Go away and be undead somewhere else. I've got a drunk to discharge and a conscience to ignore.
@end

// =====================================================================
// DETECTIVE MILLER · Night Two · coffee
// =====================================================================
# ix2.0 arc=miller night=2 label="\"Buy you a coffee, detective?\"" if=flag:m2met&room:luckymart|flag:m2met&room:alley
@focus miller
> Miller takes the coffee you buy her without thanking you, the way people take things from vending machines. She drinks half of it while it's still hot enough to hurt.
miller: You're buying me coffee. Suspects don't buy me coffee. Witnesses don't buy me coffee. Reporters buy me coffee, and they're the worst of the three.
miller: So which are you?
* "A witness."  -> ix2.witness
* "A suspect, probably."  -> ix2.suspect {do lean:candour+1}
* "Someone who wants the same thing you do."  -> ix2.same

# ix2.witness
miller: To what?
pulse(4): She's not asking about Monday. She's asking what you'll admit to.
* "To the seven disappearances. I know where they went."  -> ix2.seven {if flag:knowTrial|flag:knowSeven}
* "To Monday. I was there."  -> ix2.monday {do lean:candour+1}
* "To nothing. Yet."  -> ix2.nothing

# ix2.suspect
miller: Probably. Honest. That's new. You know what I do with honest suspects?
miller: I buy them the second coffee.
{do mem:miller:honest; rel:miller+1}
@next ix2.hub

# ix2.same
miller: You want seven people to come home? You want my captain to stop taking golf lessons with a federal agent? You want to sleep?
miller: Because if you want what I want, you want three impossible things before breakfast. Good luck.
{do mem:miller:same}
@next ix2.hub

# ix2.seven
miller: ...Go on.
web(4): You don't have proof. You have a mother's story about a paid trial in a basement. Say too much, and she'll want to know how you know.
* Tell her about the paid trial at St. Jude's.  -> ix2.trial {do lean:candour+1}
* "Not yet. When I have proof."  -> ix2.proof

# ix2.trial
miller: St. Jude's. Rostova. A paid trial. *Healthy volunteers.*
> She writes it on the inside of her wrist in biro because her notebook is full.
miller: My captain took me off this the day I asked St. Jude's for their volunteer records. The day. I thought it was coincidence. I don't think so any more.
{do mem:miller:trial; flag:millerTrial=1; rel:miller+1}
@next ix2.hub

# ix2.proof
miller: Everybody says that. "When I have proof." Then they get scared or dead.
{do mem:miller:proof}
@next ix2.hub

# ix2.monday
miller: You were there. In the butcher's. When the Sheriff, the "prominent local businessman", died.
miller: You understand you just put yourself at the scene of a death I can't classify. The ME says it's a burn. No accelerant. No fuel. Just a man-sized pile of ash and a coat-shaped space where something wasn't burnt.
miller: The coat you're wearing is the right size for that space, by the way.
* "It's mine now."  -> ix2.coat
* "He was killed by a light. I couldn't stop it."  -> ix2.light {do lean:candour+1}

# ix2.coat
miller: Is it. All right. Keep the coat. I'm not Lost Property.
{do mem:miller:coat}
@next ix2.hub

# ix2.light
miller: A light.
> She doesn't laugh. That's the worst part. She writes it down.
miller: The federal man, Harrow. He asked me on Monday if anyone reported "unusual lighting". I thought it was the dumbest question I'd ever heard. Now you say "a light".
{do mem:miller:light; flag:millerLight=1}
@next ix2.hub

# ix2.nothing
miller: Then you're a man... a person... who buys detectives coffee at two in the morning for no reason. That's either sweet or terrifying.
@next ix2.hub

# ix2.hub
* "Tell me about Ray."  -> ix2.ray {once} {if fact:miller:brother|task:s_cold}
* "Why do you keep going? Everyone's told you to stop."  -> ix2.why {once}
* "You don't sleep either, do you."  -> ix2.sleep {once}
* "Goodnight, detective."  -> ix2.bye

# ix2.ray
miller: Ray Dunleavy. My partner nine years. He drank too much and he sang badly and he knew the name of every dog on every beat. In 2019 he said he'd "found something" and on the twelfth of March he was in the river with his wallet still in his pocket.
miller: Nobody mugs a cop and leaves the wallet.
miller: The last thing he said to me was "I'll tell you tomorrow, it's a weird one." Weird. That was his word for everything he couldn't explain. He said it about my divorce.
nostalgia(3): Weird. A detective's word for the edge of the map.
{do mem:miller:ray; rel:miller+1}
@next ix2.hub

# ix2.why
miller: Because Mrs. Okafor makes me tea. Because Ray. Because I'm forty-four and my sister has a dog and a husband and a mortgage and I have seven files and a coffee habit.
miller: Because if I stop, nobody's looking. Somebody should be looking. That's the whole job, in the end. Looking.
{do mem:miller:why}
@next ix2.hub

# ix2.sleep
miller: Two hours a night. Four on Sundays. I lie in bed and the files open themselves in the dark like flowers.
miller: You don't sleep either. You don't blink, either. You're doing it right now, not blinking. It's very off-putting. Blink.
* Blink. Slowly.  -> ix2.blink
* "I sleep fine. In the day."  -> ix2.day {do lean:candour+1}

# ix2.blink
miller: Thank you. Christ. That was worse.
@next ix2.hub

# ix2.day
miller: In the day. Right. Like an owl. Or a nurse. Or a... no. I'm not saying it. I've been awake too long to say it.
{do mem:miller:day; flag:millerSuspects=1}
@next ix2.hub

# ix2.bye
miller: Thanks for the coffee. You didn't drink yours. I noticed. I notice everything. It's a curse.
@end

// =====================================================================
// DREAM 2 — Tuesday's dawn. Agnes, and the chorus.
// =====================================================================
# dr2.0 dream=2
> The study again. The lamp is lower. The curtains have moved an inch, as if someone opened them in the night and thought better of it.
tenant: You're back. Of course you're back. You have nowhere else to go when the sun is up. Neither do I.
tenant: You've had a busy night. I watched. It's like the cinema, only I can't leave and the usher is me.
@gate kills>=1 ? dr2.kill : dr2.nokill

# dr2.kill
tenant: You killed someone tonight. Or last night. It's hard to tell, in here, the nights run together like wet paint.
tenant: I won't lecture. I've killed four hundred and eleven people. I counted, for a while, and then I stopped counting because the number started to feel like a score.
tenant: But you should know: they don't leave. Not the ones you drain all the way. They come in here. I can hear one of them now, in the hallway. Can you?
> You can. Footsteps, outside the study door. Someone trying the handle. Not hard. Politely.
* "Who is it?"  -> dr2.who
* "Make it stop."  -> dr2.stop
* Open the door.  -> dr2.open

# dr2.who
tenant: Someone who was having a perfectly ordinary night until you. They'll go quiet in time. Most of mine have. Most.
{do sync+2:The hallway}
@next dr2.agnes

# dr2.stop
tenant: I can't. You can. Don't do it again. That's the only lock that works.
{do lean:restraint+1}
@next dr2.agnes

# dr2.open
> You open the door. The hallway is very long and full of doors, and behind every door a voice is saying a name you don't know.
> In the nearest doorway, someone you killed is standing in the clothes they died in, looking at you with no expression at all.
> You close the door.
tenant: Yes. Well. Now you know where the corridor goes.
{do comp-1:The corridor; sync+3:The corridor}
@next dr2.agnes

# dr2.nokill
tenant: Nobody new in the hallway tonight. Good. You're squeamish. Or kind. I can never tell the difference in the young.
@next dr2.agnes

# dr2.agnes
@gate mem:tenant.agnes ? dr2.agnes2 : dr2.other

# dr2.agnes2
tenant: You looked at her photograph. Agnes. I said I'd tell you about her when I knew you better.
tenant: I don't know you better. But I'm tired, and you're the only one here.
tenant: 1924. She was a typist at the Courthouse and I was the night clerk who brought the files down at three. She told me my handwriting was the most beautiful she'd ever seen. Nobody had complimented anything about me in sixty years.
tenant: I courted her for two years without once touching her. I told her I had a condition. Sunlight. She thought it was romantic. She used to bring me letters from the daytime: what the sky had looked like, what color the harbour was. I kept them all.
* "What happened to her?"  -> dr2.agnes3
* "Did you ever tell her what you were?"  -> dr2.told

# dr2.agnes3
tenant: She got old. That's all. Nothing dramatic. No hunters, no torches. She got old, and I didn't, and in 1961 she died in a home on the Heights with my letters in a shoebox and her husband holding her hand. A good man. A bus driver. I went to the funeral and stood at the back in dark glasses.
nostalgia(4): A shoebox of letters about the color of the harbour. Your chest aches with somebody else's grief.
{do sync+3:Agnes; mem:tenant:agnesstory}
@next dr2.end

# dr2.told
tenant: Once. 1926. I showed her. My teeth, my eyes. I expected her to scream.
tenant: She asked if it hurt. That's all. "Does it hurt?" Nobody had ever asked. I didn't know. I still don't.
{do sync+3:Agnes; mem:tenant:agnestold}
@next dr2.end

# dr2.other
tenant: Let me tell you something about your new city, since you seem determined to live in it.
tenant: Port Vellum has three powers that matter. The Court, which wears velvet and pretends to rule. The Syndicate, which wears leather and actually does. And the dead, which wear nothing at all and know everything. Séverine, Malakor, Soot.
tenant: I kept them balanced. Like plates on poles. Now there is no one at the poles and the plates are wobbling.
* "Who should I trust?"  -> dr2.trust
* "Maybe the plates should fall."  -> dr2.fall {do lean:pride-1}

# dr2.trust
tenant: Nobody. But if you must: trust Soot to sell you, Malakor to tell you he's selling you, and Séverine to have already sold you before you thought to ask.
tenant: And trust Pemberton. Pemberton is the only honest man left in the Marrow Ward, and he's barely a man.
{do mem:tenant:trust}
@next dr2.end

# dr2.fall
tenant: Then you'll be standing under them when they do.
{do mem:tenant:fall}
@next dr2.end

# dr2.end
> The study goes soft at the edges. Somewhere far above, a bus drives over your coffin.
tenant: Sleep. Tomorrow is Wednesday. On Wednesdays, things find you.
@end
`,'c_n2b');
