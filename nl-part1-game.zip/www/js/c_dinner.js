'use strict';
/* THE NEW LORD — "Sunday Dinner on a Wednesday": Mrs. Okafor cooks for everyone in the building who's still awake, and sets a place for you */
(function(){const S_=NL.Script;NL.TASKS.s_dinner={n:'Dinner at 404',xp:50,cat:'side'};
S_.place({id:'dinner',name:'Dinner at 404',block:'C',sub:'Mrs. Okafor has slid a note under every door in the Rookery: "Jollof. 2 AM. Bring a chair."',if:'night>=3&night<=4&flag:mapOK&flag:met404&rel:okafor>=2&!flag:okaforDead&!flag:dinnerDone',node:'dn2.0',min:8});})();
NL.Script.add(String.raw`
# dn2.0
> Flat 404, two in the morning. Every chair in the Rookery has been carried up the stairs: kitchen chairs, a deckchair, a piano stool, an upturned crate. The table is two tables pushed together under a tablecloth with a Christmas pattern. The window is open, because Dani always liked it open.
> In the middle of the table, a pot of jollof rice the size of a car tire. Plantain. Stew. Bread from the Lucky Mart. Two cups at the end of the table, as always.
okafor: You came. Sit. There. At the end. Next to the second cup. Nobody else is allowed to sit there.
{do task:s_dinner}
> Around the table:
> Leo, with a plate already piled to the ceiling, talking with his mouth full. {if alive:leo&!flag:leoGoneTown}
> Mr. Halloran, in his cardigan, with a cat on his knee that he insists isn't his. {if !flag:halloranGone}
> Ezra, in the corner on the floor with his blanket, not eating, watching everyone with his enormous eyes. {if flag:ezraFree}
> Tariq, who has brought root beer and is pretending he can't stay long. {if alive:tariq&rel:tariq>=2}
> Doreen Finch from the tenants' association, with her clipboard, taking minutes of a dinner party. {if seen:pt.finch}
> And three people from the fifth floor you've never met, who look at you, and then at each other, and then decide to say nothing, and pass the plantain.
@next dn2.table

# dn2.table
okafor: Eat. No, I know you can't. Hold a plate. Everyone at my table holds a plate. It's the rule.
> She puts a plate in front of you. Jollof, plantain, stew. It smells like the best thing in the world and you can't have any of it.
* Eat a spoonful. For her. Whatever it costs.  -> dn2.eat
* Hold the plate. Just hold it.  -> dn2.hold
* "Mrs. Okafor, I can't. You know I can't."  -> dn2.cant

# dn2.eat
> A spoonful of jollof. It's wonderful. You can tell it's wonderful even though it turns to cold sand in your mouth and your body doesn't know what to do with it. You swallow. You smile. You put the spoon down.
okafor: There. Was that so hard?
leo: (under his breath) Yes. Yes, it was. Look at their face. They're going to be sick on the fire escape later. {if alive:leo&!flag:leoGoneTown}
{do comp+3:Jollof; rel:okafor+2; vitae-1}
@next dn2.talk

# dn2.hold
> You hold the plate. It's warm. Steam rises off it into your face. You hold it like a hot water bottle.
okafor: Good. That's good. That's what the second cup is for, too. Holding.
{do comp+2; rel:okafor+1}
@next dn2.talk

# dn2.cant
okafor: I know you can't. Hold the plate anyway. I'm not cooking for your stomach.
@next dn2.hold

# dn2.talk
> The dinner goes on around you. People talk. Leo tells a story about a fox in the Lantern Room parking lot that may or may not have happened. Halloran tells everyone what the rent was in 1972. Somebody from the fifth floor asks you what you do for a living and the whole table goes very quiet.
* "I work nights."  -> dn2.nights
* "I'm between jobs."  -> dn2.between
* "I'm a vampire."  -> dn2.vamp {do lean:candour+1}
* Look at Mrs. Okafor. Let her answer.  -> dn2.okafor

# dn2.nights
> The fifth floor nods. Everyone works nights in the Rookery. It's that kind of building.
fifth: Same. Warehouse. You get used to it. You never get used to it.
@next dn2.toast

# dn2.between
fifth: Aren't we all, mate. Aren't we all.
@next dn2.toast

# dn2.vamp
> The table goes absolutely silent. Leo chokes on his plantain. {if alive:leo&!flag:leoGoneTown}
> And then the woman from the fifth floor laughs, a big laugh, and slaps the table.
fifth: Ha! Course you are, love. And I'm the Queen of Sheba. Pass the stew.
> Everybody laughs. The moment's gone. Mrs. Okafor looks at you across the table and doesn't laugh at all. She raises her glass of water, very slightly, just to you.
{do comp+1}
@next dn2.toast

# dn2.okafor
okafor: They're Dani's friend. That's what they do. They're Dani's friend.
> Nobody asks anything after that. Somebody passes you more plantain you won't eat.
{do rel:okafor+1}
@next dn2.toast

# dn2.toast
> At three o'clock, Mrs. Okafor stands up at the head of the table. She taps her glass with a fork. It takes a while for everyone to stop talking.
okafor: I want to say something. I'm not good at saying things. Dani was the one who said things.
okafor: In August my daughter went into a hospital to make some money and didn't come out. For two months nobody in this building said her name, because they didn't know what to say. That's all right. I didn't know either.
okafor: Then this one came. And asked. And came back. And now there's a table. I don't know what that means. I think it means I'm not on my own.
okafor: To Dani.
* Raise your plate. "To Dani."  -> dn2.dani
* Raise the second cup. "To Dani. Feed the fish."  -> dn2.fish {if flag:okaforJar|flag:haveDaniJar}
* Say nothing. Let the table say it.  -> dn2.silent

# dn2.dani
> Around the table, people who never met her raise their glasses and their plates and their cans of root beer. "To Dani." Ezra, in the corner, whispers it last.
{do comp+2; rel:okafor+1}
@next dn2.end

# dn2.fish
> Mrs. Okafor looks at you. She laughs, out loud, and then she can't stop, and then she's crying and laughing, and the fifth floor doesn't understand and joins in anyway.
okafor: Feed the fish. Yes. Feed the bloody fish.
{do comp+3; rel:okafor+2}
@next dn2.end

# dn2.silent
> You let the table say it. "To Dani." Twelve voices, ragged, out of time. It's better than any speech.
{do comp+2}
@next dn2.end

# dn2.end
> At four, people start carrying their chairs back down the stairs. Leo takes three plates of leftovers in foil. Halloran takes the cat that isn't his. Doreen Finch writes something in her minutes and underlines it.
> At the door, Mrs. Okafor gives you a foil parcel you can't eat.
okafor: For tomorrow. Hold it. That's all. Hold it.
{do flag:dinnerDone=1; task:s_dinner=done; xp:50:Dinner at 404; tick:60}
@end
`,'c_dinner');
NL.EXTRAS.fifth=NL.EXTRAS.fifth||{n:'A neighbor from the fifth floor',color:'#c0b0a0',role:'The Rookery',spec:{face:{long:1.0,cheek:1.3},skin:[.6,.44,.36],hair:{style:'bun',color:[.1,.08,.06]},shirt:[.7,.3,.4],coat:null}};
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];if(f.dinnerDone)o.push(['Flat 404','Has dinner every Wednesday at two in the morning now. Everyone brings a chair. There\'s always a place at the end, next to the second cup, with a plate on it that nobody eats.']);return o;});
