'use strict';
/* THE NEW LORD — side quests, set two: "Junie" (Leo's sister), "The Ghoul Market", "Local 0" (the clanless vote) */
(function(){
const X=NL.EXTRAS,S_=NL.Script;
X.junie={n:'Junie Pruitt',color:'#f0a8b8',role:'Leo\'s sister · night nurse',spec:{face:{long:1.0,cheek:1.0,nose:1.1},skin:[.9,.76,.68],hair:{style:'long',color:[.45,.28,.16]},shirt:[.3,.55,.6],pants:[.2,.25,.35],coat:{color:[.55,.2,.2],length:.45,collar:true},height:.96}};
X.vend={n:'Mother Hask',color:'#c0a060',role:'Ghoul Market · vials',spec:{face:{wide:1.05,jaw:0.8,cheek:1.0},skin:[.82,.72,.62],hair:{style:'bun',color:[.45,.42,.4]},shirt:[.35,.25,.2],coat:{color:[.3,.22,.18],length:.8,collar:true},height:.9}};
Object.assign(NL.TASKS,{s_junie:{n:'Junie',xp:50,cat:'side'},s_market:{n:'The Ghoul Market',xp:60,cat:'side'},s_local0:{n:'Local 0',xp:60,cat:'side'}});
Object.assign(NL.ITEMS,{
  vitaevial:{n:'Vial of Kindred Vitae',type:'tool',d:'A cut-glass perfume bottle, stoppered with wax. Somebody\'s blood, sold by the drop on Platform 0. A ghoul could live a month on it.'},
  ledgerhask:{n:'Mother Hask\'s Book',type:'read',d:'Buyers and sellers, two years of Platform 0\'s ghoul trade. One buyer appears every Thursday: "Lady O.B. — bulk, all types, for export."'}
});
S_.npc({id:'junie',room:'rookery',at:[1.6,2.0,0.4],pose:'arms',label:'A woman with a holdall',if:'night:5&time<230&!flag:junieDone&!leo:dead',node:'jn.0'});
S_.npc({id:'vend',room:'switchyard',at:[2.0,5.8,0.8],pose:'idle',label:'A ghoul with a tray of vials',if:'night>=3&night<=4&!flag:marketShut',node:{first:'gm.0',again:'gm.hub'}});
S_.npc({id:'dutch',room:'switchyard',at:[11.0,4.4,-2.0],pose:'arms',label:'Dutch',if:'night>=3&night<=4&!flag:local0Done',node:{first:'l0.0',again:'l0.hub'}});
// Junie arrives early: Leo's text on Friday
NL.Script.on('junieText',{if:'night:5&time>=10&flag:junieSaturday&!leo:dead&!leo:gone'},'text:Leo|so. junie came up a day early. she\'s in the rookery. she\'s got a crucifix and a holdall and she wants to meet "whoever you\'ve been hanging around with". please come. please come before she calls the police or the church');
NL.Script.on('junieText2',{if:'night:5&time>=10&!flag:junieSaturday&!leo:dead&!leo:gone&flag:leoJunie=truth'},'text:Leo|i told junie. everything. she drove up. she\'s in the rookery hallway with a cross from a cereal box. come. please');
})();
NL.Script.add(String.raw`
// =====================================================================
// JUNIE · Friday, in the Rookery hallway
// =====================================================================
# jn.0
@focus junie
> A woman in a red winter coat is sitting on the Rookery stairs with a holdall at her feet, holding a plastic crucifix in one hand and a can of energy drink in the other. She has Leo's nose and none of his patience.
junie: You. You're the one. He said you'd be pale. You're not pale. You're *grey*. You're the color of a hospital corridor at four in the morning.
junie: I'm Junie. I'm a nurse. Nights, Bayside General, eleven years. I have seen a man walk into the ER with a harpoon through his thigh. I want you to know that before you say anything, so you understand how hard it's going to be to surprise me.
{do task:s_junie; meet:junie}
* "He told you."  -> jn.told {if flag:leoJunie=truth}
* "What has Leo told you?"  -> jn.what
* "You should take him home."  -> jn.home

# jn.told
junie: He told me. On the phone. On Tuesday. He told me vampires were real, that he'd been bitten at work by one, that the one who bit him was "actually really nice", that there was a detective, a federal agent, a nightclub with a basement, and a cactus.
junie: I believed the cactus. The rest I came to see for myself.
@next jn.hub

# jn.what
junie: Nothing. That's what. He's been lying to me all week. He lies like Dad. He makes jokes about it. I can hear when he's lying, he goes up at the end, like a question.
junie: So I drove four hours, and I'm sitting in his hallway with a crucifix from a box of Cheerios, and you're going to tell me what's going on.
@next jn.hub

# jn.home
junie: Take him home. Oh, I'm going to. Whether he wants to or not. I just need to know whether I'm taking him away from a cult, a gang, or something I don't have a word for.
@next jn.hub

# jn.hub
* Tell her the truth. All of it.  -> jn.truth {once} {do lean:candour+1}
* "He got mixed up in something. It's over after tonight."  -> jn.half {once}
* "Your brother saved my life on Monday. Without knowing it."  -> jn.saved {once}
* Make her forget she came.  -> jn.fog {ab fog}
* Show her your teeth.  -> jn.teeth {once}
* "Can I see him with you? Upstairs?"  -> jn.up

# jn.truth
> You tell her. The freezer. The Sheriff. Your teeth in her brother's neck. The Court. Friday. You don't make it kind.
> She listens like a nurse taking a history: still, face neutral, eyes never leaving yours, making notes in her head. When you've finished she drinks the rest of the energy drink in one go and crushes the can.
junie: Okay.
junie: Okay. That's... a lot. I'm going to need a minute. And then I'm going to need you to answer some questions about blood-borne transmission.
* Answer her questions.  -> jn.medical

# jn.medical
junie: Is it infectious? The bite. Does he have something? Is he going to... turn?
autopsy(4): A bite doesn't turn anyone. Only a full draining and a gift of blood does that. Leo's carrying traces of yours. They'll fade in a week. Unless you feed him more.
@gate flag:leoGhoul ? jn.ghoul : jn.clean

# jn.ghoul
> You tell her about the blood you gave him. About what a ghoul is. About the leash.
junie: You gave my brother your blood. To drink. And now he... needs it.
junie: That's dependency. That's a dependency you created, in a vulnerable patient, without informed consent.
* "He asked."  -> jn.asked
* "I'm sorry. I'll stop. It'll wear off."  -> jn.stop {do lean:mercy+1}

# jn.asked
junie: He asked. He asks for chips at three in the morning too. He asks for everything. That's why somebody needs to say no.
{do rel:junie-2}
@next jn.decide

# jn.stop
junie: How long?
autopsy: A month, maybe. Withdrawal. Tremors, insomnia, a terrible longing. Then he'll be himself again.
junie: A month. I've done worse. I've nursed a heroin withdrawal on a sofa bed. Fine. Fine. A month.
{do flag:leoWeaning=1; rel:junie+1}
@next jn.decide

# jn.clean
junie: Fades in a week. Okay. Okay. Good. So he's just... a guy with a weird scar and a weird week.
{do rel:junie+1}
@next jn.decide

# jn.half
junie: Mixed up in something. That's what people say on the phone at three in the morning when they don't want to tell me their son's been stabbed.
junie: Fine. Keep your secrets. I'm taking him home.
@next jn.decide

# jn.saved
junie: He saved your life. Leo. My brother Leo. Who once called an ambulance for a pigeon.
junie: ...Yeah. Yeah, that sounds like him actually. How?
* "By being kind to me when I was the worst thing in the room."  -> jn.kind
* "That's his story to tell."  -> jn.story

# jn.kind
junie: That's him. That's Leo. He's kind to the worst thing in every room. It's going to get him killed one day. I've been telling him since he was six.
{do rel:junie+1}
@next jn.hub

# jn.story
junie: His story. Okay. I'll get it out of him. I always do. He cracks after two beers and a cheese toastie.
@next jn.hub

# jn.fog
> Grey fog. She blinks. She looks at the crucifix in her hand as if wondering where it came from.
junie: ...Sorry. I think I'm on the wrong floor. I'm looking for my brother. Leo Pruitt? Third floor? Oh. This is the third floor.
> She doesn't remember you. She'll still go up and take him home, probably. You'll never know what she'd have said.
tenant: You keep doing that, child. Taking the hard conversation out of people's heads before they can have it. It's very efficient. I did it for three hundred years. I don't recommend it.
{do flag:junieDone=fogged; task:s_junie=done; lean:candour-1}
@end

# jn.teeth
> You let her see. Eyes, fangs, the face under the face.
> She doesn't scream. She doesn't even step back. She holds up the plastic Cheerios crucifix, very steadily, at arm's length, the way she'd hold a syringe.
junie: Does this work?
* "No."  -> jn.teethno
* Flinch, theatrically.  -> jn.teethyes

# jn.teethno
junie: Didn't think so. Worth a try. You'd be amazed what works in the ER.
{do rel:junie+1}
@next jn.hub

# jn.teethyes
> You hiss and stagger back against the radiator. For one second she looks triumphant. Then she sees your face and realizes.
junie: You absolute *bastard*.
> And she laughs. She laughs exactly like Leo, high and helpless.
{do rel:junie+2}
@next jn.hub

# jn.up
> Upstairs, 3B. Leo opens the door, sees the two of you together, and visibly considers fainting.
leo: Oh no. Oh no, you've met. This is my nightmare. This is my actual recurring nightmare. Two worlds colliding. Like Seinfeld.
junie: Pack a bag, Leonard.
leo: Don't Leonard me —
junie: Pack. A. Bag.
@next jn.decide

# jn.decide
junie: Here's what happens. Tonight, after whatever you're doing tonight, I'm putting him in the car and driving him to Bayside. He'll stay with me for a month. He'll go to the pier on Fridays. He'll do comedy for drunk tourists and he'll be safe.
junie: And you. You don't follow. You don't call. You don't send whatever you send. Unless he calls you. If he calls you, that's his choice. That's the only way this works.
* "Agreed."  -> jn.agree {do lean:loyalty+1}
* "He's not going anywhere."  -> jn.refuse {do lean:mercy-1}
* "Ask him. It's his choice."  -> jn.ask

# jn.agree
junie: Good. Thank you.
> She holds out her hand. You take it. She doesn't flinch at how cold it is. Nurses don't.
junie: You're the weirdest person he's ever brought home. And he once brought home a mime.
{do flag:junieDone=agreed; flag:leoGoneTown=1; flag:leoToBayside=1; task:s_junie=done; xp:50:Junie; rel:junie+1; mem:leo:junie}
@end

# jn.refuse
junie: Not going anywhere. With you. Who bit him.
junie: I'm going to call the police, then. And the federal man whose card was in Leo's kitchen bin. And the church. And my mother. In that order. Try me.
* "...Fine. Take him."  -> jn.agree
? apex 11 "You don't want to make an enemy of me, nurse."  -> jn.threatok | jn.threatno {id jn_apex} {red}

# jn.threatok
> She goes very white. She sits down on the stairs.
junie: ...Fine. Fine. He stays. If anything happens to him I will find a way to put a stake through your heart, and I'll use a hospital-grade one, sterile, with a receipt.
{do flag:junieDone=threatened; task:s_junie=done; rel:junie-3; mem:leo:junieleft}
@end

# jn.threatno
junie: Do your worst. I've been threatened by better. A surgeon. With a bone saw. On Christmas.
@next jn.agree

# jn.ask
leo: Me? You're asking me? Nobody asks me. People just put me in cars.
leo: ...I want to go to the pier. I want to do comedy for drunk tourists. I want to sleep. And I want to be able to call.
junie: Then call. That's allowed.
{do flag:junieDone=asked; flag:leoGoneTown=1; flag:leoToBayside=1; task:s_junie=done; xp:50:Junie; rel:leo+1; rel:junie+1; mem:leo:junie}
@end

// =====================================================================
// THE GHOUL MARKET · Platform 0
// =====================================================================
# gm.0
@focus vend
> At the far end of Platform 0, behind the fire barrels, an old woman sits on an upturned crate with a jeweller's tray on her knees. Cut-glass perfume bottles, two dozen, each stoppered with red wax. A handwritten card: VITAE · ALL CLANS · BY THE DROP. Three ghouls in good coats are waiting their turn like customers at a chemist's.
vend: Mother Hask. Ghoul to the Danforths for sixty years until they went to Florida and forgot me. Now I sell. You're not a ghoul. You're the other sort. You're not my customer.
vend: Unless you're selling. Do you want to sell? Good prices for young blood. Better for old. You've got old blood in you, haven't you. I can smell it from here. Sheriff's blood.
* "Where does it come from? The vitae."  -> gm.where
* "Who buys?"  -> gm.who
* "How much for a vial?"  -> gm.price
* "Selling. How much?"  -> gm.sell

# gm.where
vend: Kindred who need money. More of them than you'd think. The Stray, mostly. The ones with no Court to feed them. A drop of your blood is worth a week's rent to a ghoul who's been abandoned.
vend: And the dead. When one of you meets the sun, whoever gets there first with a jar gets what's left. Not much. Ash and a little red. But it sells.
{do task:s_market; note:s_market|An old ghoul called Mother Hask sells Kindred vitae by the vial on Platform 0. Abandoned ghouls buy it to survive. Someone is buying in bulk.}
@next gm.hub

# gm.who
vend: Ghouls whose masters died. Ghouls whose masters got bored. Ghouls whose masters went to Florida. Without blood, we age. All at once. You've seen it?
vend: And one big buyer. Thursdays. A lady from the Court, grey pearls, very polite. Buys everything I've got. Every type. "For export," she says. She pays in new notes. Very new. Sequential.
web(6): A Court lady buying every type of Kindred vitae, for export, in sequential federal notes. Lady Ottilie Brand. LANTERN's accountant. They're building a library of blood.
{do task:s_market; flag:knowOttilieBlood=1; note:s_market|Mother Hask sells Kindred vitae on Platform 0. Every Thursday a Court lady in grey pearls buys her whole stock "for export", in new sequential notes. LANTERN is collecting samples of every clan's blood.}
@next gm.hub

# gm.price
vend: Fifty. A vial keeps a ghoul a month. Keeps an old one young. Keeps a dying one alive till the next.
@next gm.hub

# gm.sell
vend: From you? Sheriff's blood, second-hand? Two hundred a vial. Two hundred. I'd sell it for a thousand.
* Sell her a vial.  -> gm.sold {blood 1}
* "No."  -> gm.hub

# gm.sold
> She uncorks an empty bottle and holds it under your wrist with the reverence of a priest. It fills. Red, dark, almost black.
vend: Oh, that's old. That's very old. That's three hundred years in a bottle.
{do cash+200:Your blood, by the vial; flag:soldVitae=1; lean:restraint-1}
tenant: You've sold *me*, child. A drop of me is now on a jeweller's tray on Platform 0 next to some Stray's rent. I find I'm not even angry. I'm impressed.
@next gm.hub

# gm.hub
* Buy a vial for Pemberton.  -> gm.buypem {if cash>=50&!flag:pemFed&!flag:pemDead}
* Buy a vial.  -> gm.buy {if cash>=50}
* "Show me your book. Your buyers."  -> gm.book {if task:s_market&!has:ledgerhask}
* Shut her down.  -> gm.shut {if task:s_market}
* "I'll come back."  -> gm.bye

# gm.buypem
> You buy one. The cut glass is cold. You can feel the blood in it, someone else's, a Stray's maybe, thin and frightened.
{do cash-50; give:vitaevial; flag:vialForPem=1}
autopsy(4): Enough for a month. Enough to stop the tremor. Not his master's blood, but blood. It'll do.
@next gm.hub

# gm.buy
{do cash-50; give:vitaevial}
@next gm.hub

# gm.book
vend: My book? My book is my livelihood. My book is sixty years of knowing who needs what.
? gutter 10 "Ghoul to ghoul, Mother: the lady in pearls is selling you to the federal government. When they've got every sample, they won't need you."  -> gm.bookok | gm.bookno {id gm_gut}
* Offer her a hundred for it.  -> gm.bookbuy {if cash>=100}

# gm.bookok
> She looks at the tray. At the three ghouls waiting. At you.
vend: ...Federal. The new notes. Sequential. I thought it was the Court printing money again. They did that in '78.
vend: Take it. Take the book. If you're right, I want her to choke on it.
{do give:ledgerhask; flag:marketBook=1; rel:vend+1}
@next gm.hub

# gm.bookno
vend: Ghoul to ghoul. You're not a ghoul, love. Don't pretend.
@next gm.hub

# gm.bookbuy
vend: A hundred. Fine. I've got it memorized anyway.
{do cash-100; give:ledgerhask; flag:marketBook=1}
@next gm.hub

# gm.shut
vend: Shut me down? And then what? Those three in the queue go home and get old in a week. Mr. Pell there is a hundred and nine. Without a vial on Thursday, he's dust by Sunday.
* "Then sell only to them. Nobody else. No bulk."  -> gm.rule {do lean:mercy+1}
* Knock the tray over.  -> gm.smash {do lean:mercy-2}
* "Never mind."  -> gm.hub

# gm.rule
vend: Only to the needy. No pearls. No bulk. No export.
vend: ...That's what I did for forty years before the pearls came. That's fine. That's fine. Less money. Better sleep.
{do flag:marketShut=rule; task:s_market=done; xp:60:The Ghoul Market; rel:vend+2; mem:vend:rule}
@end

# gm.smash
> The tray goes over. Two dozen cut-glass bottles break on the platform and the blood runs into the gaps between the stones. The three ghouls in the queue fall on their knees and lick it off the concrete.
> Mother Hask doesn't say anything. She picks up the broken tray and the one bottle that didn't break and holds it against her chest like a baby.
{do flag:marketShut=smashed; task:s_market=done; heat+1; comp-2:The ghoul market; mem:vend:smashed}
@end

# gm.bye
vend: I'm always here. Thursdays are busy.
@end

// Pemberton and the vial
# px4v.0 arc=pemberton night=3,4,5 label="Give Pemberton the vial." if=has:vitaevial&flag:vialForPem&!flag:pemFed&!flag:pemDead prio=7
@focus pemberton
> You hold out the cut-glass bottle. He looks at it and then at you.
pemberton: ‹Sir›. That's from the market. On Platform 0. That's... someone else's.
pemberton: I couldn't possibly. I've only ever had his. It would be like... like drinking another man's tea from his cup.
* "Drink it. Please. You're shaking."  -> px4v.drink
* "Then have mine instead."  -> px4v.mine {blood 1}

# px4v.drink
> He drinks it the way people take medicine in old films: all at once, with a face, and then a long breath. The tremor in his left hand stops.
pemberton: ...Thank you, ‹sir›. It tastes of someone very young and very frightened. I'll say a prayer for them.
{do take:vitaevial; flag:pemVial=1; rel:pemberton+1; mem:pemberton:vial}
@end

# px4v.mine
> You open your wrist instead. He drinks. When he sits back the tremor's gone and he's looking at you the way he looked at the Sheriff in the photographs: with something like ownership, going both ways.
{do flag:pemFed=1; flag:pemBound=1; rel:pemberton+2; mem:pemberton:fed}
@end

// =====================================================================
// LOCAL 0 · the clanless vote
// =====================================================================
# l0.0
@focus dutch
> At the edge of Platform 0, where the fire barrels give up, a knot of young Kindred in jackets and hoodies are arguing in loud whispers around a crate with a ballot box on it. A shoebox with a slot cut in the lid. A curly-haired man with amber eyes and a donkey jacket is standing on another crate, conducting.
dutch: Order! Order! Brother Teo has the floor. No, he doesn't, sit down, Teo. I have the floor. I'm always going to have the floor, I'm the chair.
dutch: New face! Sheriff-eater! Oh, this is perfect. We're voting. On Friday. On whether Local 0 goes to the Tribunal or stays home and watches the Court burn itself down on the radio.
@gate clan:stray ? l0.stray : l0.other

# l0.stray
dutch: You're one of us. Clanless. I can smell it. No Court ring, no lineage, no table to sit at. Welcome, brother, sister, whatever. You get a vote.
@next l0.hub

# l0.other
dutch: You're not one of us. You've got a clan. But you ate a Sheriff, which nobody with a clan has ever had the guts to do, so I'm giving you an honorary card. You get to speak. You don't get to vote. Democracy's fiddly.
@next l0.hub

# l0.hub
* "What does Local 0 want?"  -> l0.want {once}
* "Why would you stay home?"  -> l0.home {once}
? velvet 10 Make a speech. "Come on Friday. Stand with me. Get a seat at the table."  -> l0.speech | l0.speechbad {id l0_vel} {if !flag:local0Done} {mod clan:stray?2,flag:rookerySafe?2,like:dutch}
? gutter 9 Make a different speech. "Come on Friday. Not for me. For the rats on the platform: there's going to be a fire."  -> l0.warn | l0.warnbad {id l0_gut} {if flag:knowCode&!flag:local0Done}
* "Who's Teo?"  -> l0.teo {once} {if !task:s_mateo}
* "Good luck with the vote."  -> l0.bye

# l0.want
dutch: Want? What every union wants. Recognition. A share. The right to feed without asking the Court for a licence. Our own havens. A vote on who's Sheriff.
dutch: For three hundred years the clanless have been the rats of the Marrow Ward. Fine. We're good at being rats. Rats run the sewers, and the sewers run under everything.
{do task:s_local0; note:s_local0|Dutch and Local 0, the Marrow Ward's clanless Kindred, are voting on whether to come to the Tribunal. Their votes could matter.}
@next l0.hub

# l0.home
dutch: Because every time the clanless go to a Court event, someone ends up staked "by accident". Because the last Tribunal, in 1977, the Magistrate had two of us burned for "lack of standing". Because Teo's scared and so am I.
@next l0.hub

# l0.speech
> You stand on the crate. You don't know what you're going to say until you say it.
> You tell them about the freezer, and the light, and the federal men in grey, and a Court that counts its own like cattle. You tell them that on Friday, whoever wears the Sheriff's coat is going to need people who know the sewers. You tell them you'll owe them.
> They vote. Twenty-three to four. The shoebox is very full.
dutch: Brothers and sisters: Local 0 goes to the Tribunal. With screwdrivers. And with the Sheriff-eater.
{do flag:side_union=1; flag:local0Done=speech; task:s_local0=done; xp:60:Local 0; rel:dutch+2; promise:local0:Give Local 0 a voice if you take the Ward}
@end

# l0.speechbad
> You stand on the crate and say some things about unity and standing together and the room goes quiet in the wrong way. Somebody coughs. Someone at the back says "Court talk".
dutch: Thank you, honorary member. We'll take that under advisement.
@next l0.hub

# l0.warn
> You don't make a speech. You tell them what the lamps are. Where they are. When.
> Silence. Then Teo, at the back, very quietly: "The rats live in those grates. Our rats. The ones we feed."
dutch: Right. Right. Change of agenda. We're not going to the Tribunal to sit at the table. We're going to the Tribunal to pull up the floor.
dutch: Thirty-one grates. Thirty of us. We'll take one each and Teo can take two, he's quick.
{do flag:side_union=1; flag:local0Done=grates; flag:unionGrates=1; task:s_local0=done; xp:60:Local 0; rel:dutch+2}
@end

# l0.warnbad
dutch: Lamps. Under the platform. That talk to each other. Mate, I've heard better from the Prophet, and the Prophet thinks the trains are coming back.
@next l0.hub

# l0.teo
dutch: Teo? Our youngest. Well, oldest in the union, actually, thirteen years. But nineteen forever. He's got a sister on the outside who's a cop. He doesn't talk about it. He watches her through the window of the Lucky Mart. We all know. We don't say.
{do flag:knowTeo=1}
@next l0.hub

# l0.bye
dutch: Solidarity, brother, sister, whatever. Mind the third rail. It's not live. Probably.
@end
`,'c_sq2');

/* the union pulling up the grates makes the lamps fail, unless Pike's gas got there first */
NL.Camp.tickHooks.push((S,G)=>{if(S.night===5&&S.flags.unionGrates&&!S.flags.unionGratesDone&&S.time>=200){S.flags.unionGratesDone=1;if(S.flags.pikeGassed&&!S.flags.pikeDone){setTimeout(()=>G.text('Dutch','the gas got two of us under grate 9. we pulled the rest. 29 lamps out. 2 still in. sorry. so sorry.'),1500);}else{S.flags.ratsGrates=1;setTimeout(()=>G.text('Dutch','31 GRATES. 31 LAMPS. ALL IN THE CISTERN. LOCAL 0 OUT.'),1500);}}});
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
  ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
    if(G.has('ledgerhask'))M.push({t:'"Mother Hask\'s book. Every Thursday, a Court lady bought every type of Kindred vitae for \'export\'. In federal notes."',once:'tb_hask',ok:st=>{st.prog+=1;return [L('magistrate','A library of our blood. In Virginia. For their light to learn from.')];}});
    if(S.flags.local0Done==='speech')M.push({t:'"Local 0. Brother Dutch."',once:'tb_l0',ok:st=>{st.prog+=1;return [L('dutch','The clanless of the Marrow Ward have no standing in this court, Magistrate. We know. We\'re here anyway. Twenty-three of us. We vote for the accused. We know we don\'t get a vote. We\'re voting anyway.'),T('Somebody in the Court laughs. The Magistrate doesn\'t.')];}});
    return M;};})();
