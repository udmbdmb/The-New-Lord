'use strict';
/* THE NEW LORD — world renderer: painterly bake, depth-matched 3D layer, camera, particles, nav */
(function(){
const NL=window.NL;const {M4,V3,Geo,GLX,SH}=NL;

class World{
  constructor(canvas){
    this.canvas=canvas;this.glx=new GLX(canvas,{antialias:true});this.gl=this.glx.gl;
    this.actors=[];this.parts=[];this.def=null;this.env=null;this.bakes=[null,null];this.cur=0;this.mix=1;
    this.fr=null;this.target=null;this.shake=0;this.hunger=0;this.dawn=0;this.hurt=0;this.fade=1;this.fadeTarget=0;this.t=0;
    this.visRect=()=>({x:0,y:0,w:this.cw,h:this.ch});this.focus=null;this.zoomCap=1.5;
    const gl=this.gl;
    this.blob=this.glx.mesh(Geo.floorQuad(1,1));
    this.pvao=gl.createVertexArray();this.pbuf=gl.createBuffer();gl.bindVertexArray(this.pvao);gl.bindBuffer(gl.ARRAY_BUFFER,this.pbuf);
    gl.bufferData(gl.ARRAY_BUFFER,4*8*600,gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,32,0);gl.enableVertexAttribArray(1);gl.vertexAttribPointer(1,4,gl.FLOAT,false,32,12);gl.enableVertexAttribArray(2);gl.vertexAttribPointer(2,1,gl.FLOAT,false,32,28);
    gl.bindVertexArray(null);this.pdata=new Float32Array(8*600);
    this.texCache={};this.resize(true);
  }
  resize(force){
    const r=this.canvas.getBoundingClientRect(),d=Math.min(2,window.devicePixelRatio||1)*(NL.renderScale||1);
    const cw=Math.max(1,r.width),ch=Math.max(1,r.height),w=Math.round(cw*d),h=Math.round(ch*d);
    if(!force&&w===this.canvas.width&&h===this.canvas.height) return false;
    this.cw=cw;this.ch=ch;this.dpr=d;this.canvas.width=w;this.canvas.height=h;
    if(this.def){this.setupView();this.bake(true);}
    return true;
  }
  tex(key){if(!this.texCache[key])this.texCache[key]=this.glx.tex(NL.Tex.get(key));return this.texCache[key];}
  /* ---------- room ---------- */
  load(def,S){this.def=def;this.S=S;this.parts=[];this.buildEnv();this.setupView();this.bake(true);this.buildNav();this.spawnParticles();this.fr=null;this.focus=null;}
  rebuild(S){this.S=S;this.buildEnv();this.bake(false);this.buildNav();}
  buildEnv(){
    const glx=this.glx;
    if(this.env){[...this.env.groups,...this.env.decals,...this.env.trans].forEach(g=>glx.freeMesh(g.mesh));glx.freeMesh(this.env.depthMesh);}
    const rb=new NL.RB();this.def.build(rb,this.S);const r=rb.result();
    const up=list=>list.map(x=>({mat:x.mat,mesh:glx.mesh(x.g)}));
    this.env={groups:up(r.groups),decals:up(r.decals),trans:up(r.trans),depthMesh:glx.mesh(r.depth),blocks:r.blocks};
    this.lights=this.def.lights(this.S);
  }
  setupView(){
    const d=this.def,c=[d.W/2,0.5,d.D/2];this.dir=V3.norm([1,1.08,1]);this.eye=V3.add(c,V3.mul(this.dir,40));
    this.V=M4.lookAt(this.eye,c,[0,1,0]);this.invV=M4.invert(this.V);
    const pts=[];for(const x of [-0.2,d.W])for(const y of [-0.32,d.H])for(const z of [-0.2,d.D])pts.push([x,y,z]);
    let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9,z0=1e9,z1=-1e9;
    for(const p of pts){const v=M4.xf(this.V,p);x0=Math.min(x0,v[0]);x1=Math.max(x1,v[0]);y0=Math.min(y0,v[1]);y1=Math.max(y1,v[1]);z0=Math.min(z0,v[2]);z1=Math.max(z1,v[2]);}
    this.vb={x0,x1,y0,y1};this.near=-z1-6;this.far=-z0+6;
    const full=this.frameBox(this.vb,{x:0,y:0,w:this.cw,h:this.ch},1.0);
    const cx=(full.L+full.R)/2,cy=(full.B+full.T)/2,hw=(full.R-full.L)/2*1.3,hh=(full.T-full.B)/2*1.3;
    this.bf={L:cx-hw,R:cx+hw,B:cy-hh,T:cy+hh};
    this.baseS=(full.R-full.L)/this.cw;
  }
  frameBox(b,vr,margin){
    const bw=(b.x1-b.x0)*margin,bh=(b.y1-b.y0)*margin;
    let s=Math.max(bw/Math.max(40,vr.w),bh/Math.max(40,vr.h));
    if(this.baseS) s=Math.max(s,this.baseS/this.zoomCap);
    const cx=(b.x0+b.x1)/2,cy=(b.y0+b.y1)/2;const L=cx-(vr.x+vr.w/2)*s,T=cy+(vr.y+vr.h/2)*s;
    return {L,R:L+this.cw*s,T,B:T-this.ch*s};
  }
  targetFrame(){
    const vr=this.visRect();
    if(this.focus){const pts=this.focus.pts;let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;
      for(const p of pts){const v=M4.xf(this.V,p);x0=Math.min(x0,v[0]);x1=Math.max(x1,v[0]);y0=Math.min(y0,v[1]);y1=Math.max(y1,v[1]);}
      const pad=this.focus.pad||0.9;return this.frameBox({x0:x0-pad,x1:x1+pad,y0:y0-pad*0.6,y1:y1+pad*0.6},vr,1);}
    return this.frameBox(this.vb,vr,1.04);
  }
  /* ---------- bake ---------- */
  bake(instant){
    const gl=this.gl,glx=this.glx,d=this.def,bf=this.bf;
    const W=this.canvas.width,H=this.canvas.height;const scale=Math.min(1.05,2300/Math.max(W,H));
    const bw=Math.max(64,Math.round(W*scale)),bh=Math.max(64,Math.round(H*scale));
    if(!this.rtA||this.rtA.w!==bw||this.rtA.h!==bh){[this.rtA,this.rtB,this.bakes[0],this.bakes[1]].forEach(t=>glx.freeTarget(t));
      this.rtA=glx.target(bw,bh,true);this.rtB=glx.target(bw,bh,false);this.bakes=[glx.target(bw,bh,false),glx.target(bw,bh,false)];instant=true;}
    if(!this.shTarget) this.shTarget=glx.target(1024,1024,true);
    const BP=M4.ortho(bf.L,bf.R,bf.B,bf.T,this.near,this.far),BVP=M4.mul(BP,this.V);
    // shadow pass
    let shVP=M4.ident();const sh=d.shadow;
    if(sh){const up=Math.abs(sh.target[0]-sh.pos[0])+Math.abs(sh.target[2]-sh.pos[2])<0.01?[0,0,1]:[0,1,0];
      shVP=M4.mul(M4.persp(sh.fov,1,0.1,sh.far),M4.lookAt(sh.pos,sh.target,up));
      gl.bindFramebuffer(gl.FRAMEBUFFER,this.shTarget.fb);gl.viewport(0,0,1024,1024);gl.clearColor(1,1,1,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.disable(gl.CULL_FACE);gl.colorMask(false,false,false,false);
      const P=glx.prog('depth',SH.DEPTH_VS,SH.DEPTH_FS);gl.useProgram(P.p);gl.uniformMatrix4fv(P.u.uVP,false,shVP);
      for(const g of this.env.groups){if(g.mat.noShadow)continue;gl.bindVertexArray(g.mesh.vao);gl.drawElements(gl.TRIANGLES,g.mesh.count,gl.UNSIGNED_INT,0);}
      gl.colorMask(true,true,true,true);}
    // env pass
    gl.bindFramebuffer(gl.FRAMEBUFFER,this.rtA.fb);gl.viewport(0,0,bw,bh);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.enable(gl.CULL_FACE);gl.cullFace(gl.BACK);
    const P=glx.prog('env',SH.ENV_VS,SH.ENV_FS);gl.useProgram(P.p);
    gl.uniformMatrix4fv(P.u.uVP,false,BVP);gl.uniformMatrix4fv(P.u.uShVP,false,shVP);
    gl.uniform3fv(P.u.uSky,d.sky);gl.uniform3fv(P.u.uGround,d.ground);gl.uniform3fv(P.u.uCamDir,this.dir);
    glx.setLights(P,this.lights,1);
    gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,this.shTarget.depth);gl.uniform1i(P.u.uShadow,1);
    gl.uniform1f(P.u.uShOn,sh?1:0);gl.uniform1i(P.u.uShIdx,sh?sh.idx:-1);gl.uniform1f(P.u.uShTexel,1/1024);
    gl.uniform1i(P.u.uTex,0);gl.activeTexture(gl.TEXTURE0);
    const drawG=(g)=>{const m=g.mat;gl.uniform3fv(P.u.uColor,m.color);gl.uniform3fv(P.u.uEmis,m.emis);gl.uniform1f(P.u.uEmisK,m.emisK);gl.uniform1f(P.u.uSpec,m.spec);gl.uniform1f(P.u.uMottle,m.mottle);
      gl.uniform1f(P.u.uAlpha,m.alpha);gl.uniform1f(P.u.uDecal,m.decal?1:0);gl.uniform1f(P.u.uTexScale,m.texScale);
      if(m.tex){gl.bindTexture(gl.TEXTURE_2D,this.tex(m.tex));gl.uniform1f(P.u.uHasTex,1);}else gl.uniform1f(P.u.uHasTex,0);
      gl.bindVertexArray(g.mesh.vao);gl.drawElements(gl.TRIANGLES,g.mesh.count,gl.UNSIGNED_INT,0);};
    gl.disable(gl.BLEND);this.env.groups.forEach(drawG);
    gl.enable(gl.BLEND);gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);
    gl.depthMask(false);gl.enable(gl.POLYGON_OFFSET_FILL);gl.polygonOffset(-1,-2);gl.disable(gl.CULL_FACE);
    this.env.decals.forEach(drawG);gl.disable(gl.POLYGON_OFFSET_FILL);
    this.env.trans.forEach(drawG);gl.depthMask(true);gl.disable(gl.BLEND);gl.enable(gl.CULL_FACE);
    // kuwahara
    gl.disable(gl.DEPTH_TEST);gl.bindVertexArray(glx.emptyVao);
    const K=glx.prog('kuwa',SH.FS_VS,SH.KUWA_FS);gl.bindFramebuffer(gl.FRAMEBUFFER,this.rtB.fb);gl.useProgram(K.p);
    gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.rtA.color);gl.uniform1i(K.u.uSrc,0);gl.uniform2f(K.u.uTexel,1/bw,1/bh);
    gl.uniform1i(K.u.uR,Math.max(3,Math.min(6,Math.round(Math.min(bw,bh)/170))));gl.drawArrays(gl.TRIANGLES,0,3);
    // paint
    const next=instant?this.cur:1-this.cur,tgt=this.bakes[next];
    const Pp=glx.prog('paint',SH.FS_VS,SH.PAINT_FS);gl.bindFramebuffer(gl.FRAMEBUFFER,tgt.fb);gl.useProgram(Pp.p);
    gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.rtB.color);gl.uniform1i(Pp.u.uK,0);
    gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,this.rtA.color);gl.uniform1i(Pp.u.uC,1);
    gl.activeTexture(gl.TEXTURE2);gl.bindTexture(gl.TEXTURE_2D,this.rtA.depth);gl.uniform1i(Pp.u.uD,2);
    gl.uniform2f(Pp.u.uTexel,1/bw,1/bh);gl.uniform2f(Pp.u.uRes,bw,bh);const gr=d.grade;
    gl.uniform3fv(Pp.u.uShTint,gr.sh);gl.uniform3fv(Pp.u.uHiTint,gr.hi);gl.uniform3fv(Pp.u.uInk,gr.ink);gl.uniform1f(Pp.u.uSat,gr.sat);gl.uniform1f(Pp.u.uSeed,(d.id.length*7.3)%10);
    gl.drawArrays(gl.TRIANGLES,0,3);
    gl.activeTexture(gl.TEXTURE0);gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.bindVertexArray(null);
    if(instant){this.mix=1;}else{this.cur=next;this.mix=0;}
    this.bakeVP=BVP;
  }
  /* ---------- nav ---------- */
  buildNav(){
    const d=this.def,cs=0.2,gw=Math.ceil(d.W/cs),gh=Math.ceil(d.D/cs),g=new Uint8Array(gw*gh);
    const pad=0.17;
    for(let j=0;j<gh;j++)for(let i=0;i<gw;i++){const x=(i+0.5)*cs,z=(j+0.5)*cs;let b=x<0.28||z<0.28||x>d.W-0.25||z>d.D-0.25;
      if(!b)for(const r of this.env.blocks){if(x>r[0]-pad&&x<r[2]+pad&&z>r[1]-pad&&z<r[3]+pad){b=true;break;}}g[j*gw+i]=b?1:0;}
    this.nav={cs,gw,gh,g};
  }
  blockedAt(x,z,ignore){const n=this.nav,i=Math.floor(x/n.cs),j=Math.floor(z/n.cs);if(i<0||j<0||i>=n.gw||j>=n.gh)return true;if(n.g[j*n.gw+i])return true;
    for(const a of this.actors){if(a===ignore||!a.solid||!a.visible)continue;if(Math.hypot(a.x-x,a.z-z)<0.42)return true;}return false;}
  findPath(sx,sz,tx,tz,ignore){
    const n=this.nav,cs=n.cs,ci=(x)=>Math.max(0,Math.min(n.gw-1,Math.floor(x/cs))),cj=(z)=>Math.max(0,Math.min(n.gh-1,Math.floor(z/cs)));
    const free=(i,j)=>i>=0&&j>=0&&i<n.gw&&j<n.gh&&!this.blockedAt((i+.5)*cs,(j+.5)*cs,ignore);
    let ti=ci(tx),tj=cj(tz);
    if(!free(ti,tj)){let best=null,bd=1e9;for(let r=1;r<12&&!best;r++)for(let dj=-r;dj<=r;dj++)for(let di=-r;di<=r;di++){if(Math.max(Math.abs(di),Math.abs(dj))!==r)continue;if(free(ti+di,tj+dj)){const dd=di*di+dj*dj;if(dd<bd){bd=dd;best=[ti+di,tj+dj];}}}
      if(!best)return null;[ti,tj]=best;tx=(ti+.5)*cs;tz=(tj+.5)*cs;}
    let si=ci(sx),sj=cj(sz);
    const N=n.gw*n.gh,gS=new Float32Array(N).fill(1e9),came=new Int32Array(N).fill(-1),closed=new Uint8Array(N);
    const open=[];const k=(i,j)=>j*n.gw+i;const h=(i,j)=>{const dx=Math.abs(i-ti),dy=Math.abs(j-tj);return dx+dy+(1.414-2)*Math.min(dx,dy);};
    gS[k(si,sj)]=0;open.push([h(si,sj),si,sj]);let found=false,iter=0;
    while(open.length&&iter++<6000){let bi=0;for(let q=1;q<open.length;q++)if(open[q][0]<open[bi][0])bi=q;const [,i,j]=open.splice(bi,1)[0];const kk=k(i,j);if(closed[kk])continue;closed[kk]=1;
      if(i===ti&&j===tj){found=true;break;}
      for(let dj=-1;dj<=1;dj++)for(let di=-1;di<=1;di++){if(!di&&!dj)continue;const ni=i+di,nj=j+dj;if(!free(ni,nj))continue;if(di&&dj&&(!free(i+di,j)||!free(i,j+dj)))continue;
        const nk=k(ni,nj);const ng=gS[kk]+(di&&dj?1.414:1);if(ng<gS[nk]){gS[nk]=ng;came[nk]=kk;open.push([ng+h(ni,nj),ni,nj]);}}}
    if(!found) return null;
    const cells=[];let c=k(ti,tj);while(c!==-1&&c!==k(si,sj)){cells.push([(c%n.gw+.5)*cs,(Math.floor(c/n.gw)+.5)*cs]);c=came[c];}cells.reverse();
    if(cells.length)cells[cells.length-1]=[tx,tz];else cells.push([tx,tz]);
    // smooth
    const out=[];let cur=[sx,sz],idx=0;
    while(idx<cells.length){let far=idx;for(let q=cells.length-1;q>idx;q--){if(this.los(cur,cells[q],ignore)){far=q;break;}}out.push(cells[far]);cur=cells[far];idx=far+1;}
    return out;
  }
  los(a,b,ignore){const d=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.ceil(d/0.08);for(let i=1;i<n;i++){const t=i/n;if(this.blockedAt(a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,ignore))return false;}return true;}
  /* ---------- particles ---------- */
  spawnParticles(){this.parts=[];(this.def.particles||[]).forEach(e=>{for(let i=0;i<e.n;i++)this.parts.push(this.newPart(e,true));});}
  newPart(e,init){const R=Math.random;
    if(e.type==='mist'){const a=e.area;return {e,p:[a[0]+R()*(a[1]-a[0]),e.y[0]+R()*(e.y[1]-e.y[0]),a[2]+R()*(a[3]-a[2])],v:[(R()-.5)*.05,0,(R()-.5)*.05],life:init?R()*14:0,max:10+R()*8,size:1.2+R()*1.3,col:[.75,.86,.95],a:.07};}
    if(e.type==='motes'){const a=e.area;return {e,p:[a[0]+R()*(a[1]-a[0]),e.y[0]+R()*(e.y[1]-e.y[0]),a[2]+R()*(a[3]-a[2])],v:[(R()-.5)*.04,(R()-.4)*.03,(R()-.5)*.04],life:init?R()*9:0,max:6+R()*6,size:.018+R()*.02,col:e.col,a:.75};}
    if(e.type==='rain'){const a=e.area;return {e,p:[a[0]+R()*(a[1]-a[0]),init?e.y[0]+R()*(e.y[1]-e.y[0]):e.y[1],a[2]+R()*(a[3]-a[2])],v:[-.3,-7-R()*2,.1],life:0,max:.7,size:.012,col:e.col,a:.4};}
    if(e.type==='ash'){const c=e.center,ang=R()*7,r=R()*e.r;return {e,p:[c[0]+Math.cos(ang)*r,c[1],c[2]+Math.sin(ang)*r],v:[(R()-.5)*.05,.06+R()*.08,(R()-.5)*.05],life:init?R()*6:0,max:4+R()*4,size:.02+R()*.025,col:[.25,.24,.24],a:.85,swirl:R()*6};}
    if(e.type==='exhaust'){const c=e.center;return {e,p:[c[0],c[1],c[2]],v:[-.25-R()*.15,.12+R()*.1,(R()-.5)*.08],life:init?R()*3:0,max:2.5+R()*1.5,size:.12,grow:.35,col:[.62,.63,.68],a:.22};}
    if(e.type==='breath'){const a=e.actor,f=a.facePos(),ry=a.ry;return {e,p:[f[0],f[1]-0.03,f[2]],v:[Math.sin(ry)*.22+(R()-.5)*.05,.05,Math.cos(ry)*.22+(R()-.5)*.05],life:0,max:1.4+R()*.5,size:.05,grow:.22,col:[.9,.95,1],a:.32};}
    if(e.type==='spark'){const c=e.center;return {e,p:[c[0],c[1],c[2]],v:[(R()-.5)*1.4,R()*1.6,(R()-.5)*1.4],life:0,max:.6+R()*.5,size:.03,col:e.col||[1,.4,.2],a:1,grav:3,once:true};}
    return null;}
  burst(center,n,col){for(let i=0;i<n;i++)this.parts.push(this.newPart({type:'spark',center,col},false));}
  updateParticles(dt){
    // breath emitters
    if(this.def.cold||this.def.rain){for(const a of this.actors){if(!a.breathes||!a.visible)continue;a._bt=(a._bt||0)-dt;if(a._bt<=0){a._bt=(a.panic?1.1:2.6);for(let i=0;i<4;i++){const p=this.newPart({type:'breath',actor:a});p.life=-i*0.05;this.parts.push(p);}}}}
    const out=[];
    for(const p of this.parts){p.life+=dt;if(p.life<0){out.push(p);continue;}
      if(p.life>p.max){if(p.once||p.e.type==='breath')continue;const np=this.newPart(p.e,false);out.push(np);continue;}
      if(p.swirl!=null){p.v[0]+=Math.cos(p.life*2+p.swirl)*.02*dt;p.v[2]+=Math.sin(p.life*2+p.swirl)*.02*dt;}
      if(p.grav)p.v[1]-=p.grav*dt;
      p.p[0]+=p.v[0]*dt;p.p[1]+=p.v[1]*dt;p.p[2]+=p.v[2]*dt;if(p.grow)p.size+=p.grow*dt;out.push(p);}
    this.parts=out.slice(-600);
  }
  /* ---------- frame ---------- */
  frame(dt){
    this.t+=dt;const gl=this.gl,glx=this.glx,d=this.def;if(!d) return;
    // camera
    const tf=this.targetFrame();
    if(!this.fr) this.fr=Object.assign({},tf);
    const k=1-Math.exp(-dt*(this.camSpeed||3.2));for(const key of ['L','R','B','T']) this.fr[key]+=(tf[key]-this.fr[key])*k;
    let {L,R,B,T}=this.fr;
    if(this.shake>0){const s=this.shake*(R-L)*0.012;const ox=(Math.random()-.5)*s,oy=(Math.random()-.5)*s;L+=ox;R+=ox;B+=oy;T+=oy;this.shake=Math.max(0,this.shake-dt*2.2);}
    this.vf={L,R,B,T};
    this.VP=M4.mul(M4.ortho(L,R,B,T,this.near,this.far),this.V);
    if(this.mix<1) this.mix=Math.min(1,this.mix+dt*2.2);
    this.fade+=(this.fadeTarget-this.fade)*Math.min(1,dt*(this.fadeSpeed||4));
    const bright=d.flicker?d.flicker(this.t):1;
    for(const a of this.actors) a.update(dt,this.t);
    this.updateParticles(dt);
    if(NL.noDraw)return;
    // draw
    const W=this.canvas.width,H=this.canvas.height;
    gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,W,H);gl.clearColor(0,0,0,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    // backdrop
    gl.disable(gl.DEPTH_TEST);gl.depthMask(false);gl.disable(gl.BLEND);gl.bindVertexArray(glx.emptyVao);
    const P=glx.prog('back',SH.FS_VS,SH.BACK_FS);gl.useProgram(P.p);const bf=this.bf;
    gl.uniform4f(P.u.uXf,(R-L)/(bf.R-bf.L),(T-B)/(bf.T-bf.B),(L-bf.L)/(bf.R-bf.L),(B-bf.B)/(bf.T-bf.B));
    gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.bakes[this.cur].color);gl.uniform1i(P.u.uBake,0);
    gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,this.bakes[1-this.cur].color);gl.uniform1i(P.u.uBake2,1);gl.uniform1f(P.u.uMix,this.mix);
    gl.uniform1f(P.u.uT,this.t);gl.uniform1f(P.u.uBright,bright);gl.uniform1f(P.u.uHunger,this.hunger);gl.uniform1f(P.u.uDawn,this.dawn);gl.uniform1f(P.u.uHurt,this.hurt);
    gl.uniform3fv(P.u.uWash1,d.grade.wash1);gl.uniform3fv(P.u.uWash2,d.grade.wash2);gl.uniform2f(P.u.uRes,W,H);gl.uniform1f(P.u.uAspect,(bf.R-bf.L)/(bf.T-bf.B));gl.uniform1f(P.u.uFade,Math.min(1,Math.max(0,this.fade)));
    gl.drawArrays(gl.TRIANGLES,0,3);gl.activeTexture(gl.TEXTURE0);
    if(this.hurt>0)this.hurt=Math.max(0,this.hurt-dt*1.2);
    // depth-only env
    gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.colorMask(false,false,false,false);gl.disable(gl.CULL_FACE);
    const D=glx.prog('depth',SH.DEPTH_VS,SH.DEPTH_FS);gl.useProgram(D.p);gl.uniformMatrix4fv(D.u.uVP,false,this.VP);
    gl.bindVertexArray(this.env.depthMesh.vao);gl.drawElements(gl.TRIANGLES,this.env.depthMesh.count,gl.UNSIGNED_INT,0);
    gl.colorMask(true,true,true,true);
    if(this.fade>0.98){gl.bindVertexArray(null);return;}
    // blob shadows
    const Bp=glx.prog('blob',SH.BLOB_VS,SH.BLOB_FS);gl.useProgram(Bp.p);gl.uniformMatrix4fv(Bp.u.uVP,false,this.VP);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);
    gl.bindVertexArray(this.blob.vao);
    for(const a of this.actors){if(!a.visible||!a.shadow)continue;const lying=a.pose==='lie';
      gl.uniformMatrix4fv(Bp.u.uM,false,M4.trs([a.x-(lying?Math.sin(a.ry)*0.8:0),0.012,a.z-(lying?Math.cos(a.ry)*0.8:0)],[0,a.ry,0],lying?[0.75,1,2.0]:[0.62,1,0.5]));
      gl.uniform1f(Bp.u.uA,0.55*a.alpha*(1-this.fade));gl.drawElements(gl.TRIANGLES,this.blob.count,gl.UNSIGNED_INT,0);}
    gl.depthMask(true);gl.disable(gl.BLEND);
    // actors
    const lights=this.lights;let key=[0.3,1,0.5];if(lights.length){key=V3.norm(V3.sub(lights[0].pos,[d.W/2,0.9,d.D/2]));}
    const _drawA=()=>NL.drawActors(glx,this.actors,this.VP,{dir:this.dir,sky:d.sky,ground:d.ground,lights,bright:bright*(1-this.fade),rim:d.rim||[d.grade.hi[0]*.35,d.grade.hi[1]*.32,d.grade.hi[2]*.4],ink:[d.grade.ink[0]*0.6,d.grade.ink[1]*0.5,d.grade.ink[2]*0.6],outline:0.0062,shT:d.grade.sh.map(v=>0.72+v*0.28),hiT:d.grade.hi.map(v=>0.5+v*0.5),sat:Math.min(.95,(d.grade.sat||.85)+.08),keyDir:key,keyCol:[0.14,0.13,0.14]});
    // painted figures: draw the people into their own layer, then brush it with a small Kuwahara filter so they sit in the painting
    const paintA=NL.paintActors!==false&&(NL.renderScale||1)>0.6&&this.actors.some(a=>a.visible);
    if(paintA){
      if(!this.rtAct||this.rtAct.w!==W||this.rtAct.h!==H){this.rtAct=glx.target(W,H,true);this.rtAct.w=W;this.rtAct.h=H;}
      // screen box around everyone, so the filter only runs where people are
      let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
      for(const a of this.actors){if(!a.visible)continue;for(const p of [[a.x-.45,0,a.z-.45],[a.x+.45,2.05,a.z+.45],[a.x-.45,2.05,a.z+.45],[a.x+.45,0,a.z-.45]]){const q=M4.xf(this.VP,p);const px=(q[0]*.5+.5)*W,py=(q[1]*.5+.5)*H;x0=Math.min(x0,px);x1=Math.max(x1,px);y0=Math.min(y0,py);y1=Math.max(y1,py);}}
      const pad=8;x0=Math.max(0,Math.floor(x0-pad));y0=Math.max(0,Math.floor(y0-pad));x1=Math.min(W,Math.ceil(x1+pad));y1=Math.min(H,Math.ceil(y1+pad));
      if(x1>x0&&y1>y0){
        gl.bindFramebuffer(gl.FRAMEBUFFER,this.rtAct.fb);gl.viewport(0,0,W,H);gl.enable(gl.SCISSOR_TEST);gl.scissor(x0,y0,x1-x0,y1-y0);
        gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
        gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.colorMask(false,false,false,false);gl.disable(gl.CULL_FACE);
        gl.useProgram(D.p);gl.uniformMatrix4fv(D.u.uVP,false,this.VP);gl.bindVertexArray(this.env.depthMesh.vao);gl.drawElements(gl.TRIANGLES,this.env.depthMesh.count,gl.UNSIGNED_INT,0);
        gl.colorMask(true,true,true,true);
        _drawA();
        gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,W,H);gl.disable(gl.DEPTH_TEST);gl.bindVertexArray(glx.emptyVao);
        const Kp=glx.prog('kuwa',SH.FS_VS,SH.KUWA_FS);gl.useProgram(Kp.p);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.rtAct.color);gl.uniform1i(Kp.u.uSrc,0);
        gl.uniform2f(Kp.u.uTexel,1/W,1/H);{let hp=0,n=0;for(const a of this.actors){if(!a.visible)continue;const q0=M4.xf(this.VP,[a.x,0,a.z]),q1=M4.xf(this.VP,[a.x,1.8,a.z]);hp+=Math.abs(q1[1]-q0[1])*.5*H;n++;}hp/=Math.max(1,n);gl.uniform1i(Kp.u.uR,hp<150?1:hp<280?2:3);}
        gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);gl.drawArrays(gl.TRIANGLES,0,3);gl.disable(gl.BLEND);
        gl.disable(gl.SCISSOR_TEST);gl.enable(gl.DEPTH_TEST);gl.bindVertexArray(null);}
    } else _drawA();
    // particles
    let n=0;const pd=this.pdata;for(const p of this.parts){if(p.life<0||n>=600)continue;const lf=p.life/p.max,fa=Math.sin(Math.min(1,lf)*Math.PI);const o=n*8;
      pd[o]=p.p[0];pd[o+1]=p.p[1];pd[o+2]=p.p[2];pd[o+3]=p.col[0];pd[o+4]=p.col[1];pd[o+5]=p.col[2];pd[o+6]=p.a*fa*(1-this.fade);pd[o+7]=p.size;n++;}
    if(n){const Pp=glx.prog('part',SH.PART_VS,SH.PART_FS);gl.useProgram(Pp.p);gl.uniformMatrix4fv(Pp.u.uVP,false,this.VP);gl.uniform1f(Pp.u.uPx,H/(T-B));
      gl.bindVertexArray(this.pvao);gl.bindBuffer(gl.ARRAY_BUFFER,this.pbuf);gl.bufferSubData(gl.ARRAY_BUFFER,0,pd.subarray(0,n*8));
      gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);gl.drawArrays(gl.POINTS,0,n);gl.depthMask(true);gl.disable(gl.BLEND);}
    gl.bindVertexArray(null);
  }
  /* ---------- coords ---------- */
  project(p){if(!this.vf)return null;const v=M4.xf(this.V,p),f=this.vf;return [(v[0]-f.L)/(f.R-f.L)*this.cw,(f.T-v[1])/(f.T-f.B)*this.ch,-v[2]];}
  floorAt(px,py){const f=this.vf;if(!f)return null;const x=f.L+px/this.cw*(f.R-f.L),y=f.T-py/this.ch*(f.T-f.B);
    const o=M4.xf(this.invV,[x,y,0]),dd=M4.xfDir(this.invV,[0,0,-1]);if(Math.abs(dd[1])<1e-5)return null;const t=-o[1]/dd[1];return [o[0]+dd[0]*t,o[2]+dd[2]*t];}
  pick(px,py,list){let best=null,bd=1e9;
    for(const it of list){const b=it.box;let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9,dep=0;
      for(const x of [b[0],b[3]])for(const y of [b[1],b[4]])for(const z of [b[2],b[5]]){const s=this.project([x,y,z]);x0=Math.min(x0,s[0]);x1=Math.max(x1,s[0]);y0=Math.min(y0,s[1]);y1=Math.max(y1,s[1]);dep+=s[2];}
      const pad=10;if(px>=x0-pad&&px<=x1+pad&&py>=y0-pad&&py<=y1+pad){const area=(x1-x0)*(y1-y0);const score=dep/8+area*0.00002;if(score<bd){bd=score;best=it;}}}
    return best;}
}
NL.World=World;
})();
