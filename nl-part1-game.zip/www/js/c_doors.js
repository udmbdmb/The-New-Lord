'use strict';
/* THE NEW LORD — "Knock Knock": Friday night, before one o'clock, the Rookery has to empty. Somebody has to knock on the doors. */
(function(){const S_=NL.Script;NL.TASKS.s_doors={n:'Knock Knock',xp:50,cat:'side'};
S_.place({id:'doors',name:'The Rookery, Door to Door',block:'C',sub:'Forty-two flats. A gas leak that isn\'t a gas leak. One hour.',if:'night:5&time<225&flag:mapOK&!flag:doorsDone',node:'kd.0',min:6});})();
NL.Script.add(String.raw`
# kd.0
> The Rookery stairwell at midnight. Six floors. Forty-two doors. Somewhere above you, a radio playing a song about Galway. Somewhere below, a baby crying.
> If the lamps fire under Platform 0, three streets away, the light won't reach here. Probably. But if the Court comes up the Switchyard stairs to eat LANTERN alive, or LANTERN's vans come down Halloran Street, or something worse, the Rookery is the first building in the way.
leo: (with a clipboard he's borrowed from Doreen Finch) Okay. Okay. Gas leak. We're saying gas leak. Everyone believes gas leak. {if alive:leo&!flag:leoGoneTown}
{do task:s_doors; note:s_doors|Getting the Rookery out before one o'clock, door by door.}
@next kd.hub

# kd.hub
> Which doors?
* 6C. Mr. Bellini, who won't leave his bath.  -> kd.6c {once} {if flag:sixcDone|seen:sx.0}
* 302. Mr. Halloran and Maureen, and thirty-one cats.  -> kd.302 {once} {if !flag:halloranGone&!flag:halloranSister}
* 5B. The family from the fifth floor with the new baby.  -> kd.5b {once}
* 40, at the bottom. Kyle's grandma, asleep in front of the TV.  -> kd.grandma {once} {if seen:ev.kid9}
* 4A. Doreen Finch, who is already wearing a coat and holding a list.  -> kd.finch {once}
* "That's everyone I can reach."  -> kd.end

# kd.6c
> Steam under the door. *Una furtiva lagrima*, enormous, cracked, glorious.
bellini: (through the door) It's one o'clock. Clause nine. I'm entitled.
* "Mr. Bellini, there's a gas leak."  -> kd.6c1
? velvet 9 "Mr. Bellini. The lady in grey silk has asked for you to sing for her tonight. Somewhere else."  -> kd.6c2 | kd.6c1 {id kd_6c} {if flag:sixcSev}

# kd.6c1
bellini: A gas leak. In 1988 there was a gas leak and I sang through it and nothing happened. I'll take my chances. Clause nine.
* Break the chain. Carry him out, dressing gown and all.  -> kd.6c3
* Leave him singing.  -> kd.hub

# kd.6c2
> The singing stops. A splash. A long pause.
bellini: ...For her. Tonight. Where?
> Ten minutes later he comes down the stairs in a three-piece suit from 1962, with a carnation, smelling of bath salts.
{do flag:door6c=1}
@next kd.hub

# kd.6c3
> You break the chain with two fingers. You carry an eighty-eight-year-old tenor down six flights of stairs in a red velvet dressing gown while he sings *Nessun dorma* at you in fury. By the second floor he's laughing. By the ground floor he's asking if you've ever considered opera.
{do flag:door6c=1; heat+0}
@next kd.hub

# kd.302
> Mr. Halloran opens the door in his cardigan. Behind him, Maureen, on the couch, with a packed bag by her feet that's been there since Tuesday.
halloran: Gas leak, is it. Course it is. Like 1988.
halloran: I'm not leaving the cats.
* "Bring the cats."  -> kd.302a
? velvet 10 "Maureen. Your bag's packed. Let's use it."  -> kd.302b | kd.302c {id kd_302}

# kd.302a
halloran: Bring them. Thirty-one cats. Down six... down three flights. In what?
leo: (from behind you) I've got a laundry basket! I've got three laundry baskets! {if alive:leo&!flag:leoGoneTown}
> It takes twenty minutes. It's the most chaotic thing you've done all week, including the freezer. At the end, thirty-one cats in three laundry baskets and a suitcase are on the sidewalk of Halloran Street, and the one that isn't called Charlie is sitting on Maureen's lap, purring.
{do flag:door302=1; comp+2}
@next kd.hub

# kd.302b
> Maureen looks at the bag. She looks at her husband. She stands up.
maureen: Desmond. Get your coat. We're going to my sister's. I've been packed since Tuesday. I was waiting for a reason.
halloran: The cats...
maureen: The cats have survived six years without you knowing their names. They'll survive one night.
{do flag:door302=1}
@next kd.hub

# kd.302c
maureen: Use it? I'm not going anywhere. I've been threatening to leave for thirty years. If I leave on a Friday because of a gas leak, it doesn't count.
@next kd.hub

# kd.5b
> A young man in a vest opens the door with a baby on his shoulder. Behind him, a woman asleep on the sofa in her work uniform.
fifth: Gas leak? Oh my God. Oh my God. Kay. KAY. Wake up. Gas leak.
> They're out in four minutes, with the baby, a diaper bag, a phone charger and a framed wedding photograph, which is how you know what matters to them.
{do flag:door5b=1; comp+1}
@next kd.hub

# kd.grandma
> Number 40. Kyle answers the door in pyjamas. Behind him, his grandma is asleep in front of the TV with her mouth open.
kid: It's YOU. Are you here to bite Grandma? Don't bite Grandma.
* "There's a gas leak, Kyle. Wake her up. Go to your mom's work."  -> kd.nan1
* "I'm here to look after you both. Get your coat."  -> kd.nan2

# kd.nan1
kid: Mom's at the Safeway. Grandma! GRANDMA! The vampire says there's a gas leak!
> His grandma wakes up, sees you, says "oh, hello, love," and puts her coat on over her nightie without another word, as if vampires knocked every Friday.
{do flag:doorNan=1; comp+1}
@next kd.hub

# kd.nan2
kid: Look after us. Like a bodyguard. Like a VAMPIRE bodyguard.
> You walk them both to the Safeway on Kerr Street, where his mother is stacking shelves on the night shift. She looks at you, and at her son, and at her mother in a nightie, and doesn't ask a single question.
{do flag:doorNan=1; comp+2; tick:15}
@next kd.hub

# kd.finch
mrsfinch: Ah. There you are. I've done the fourth and the second floors. I've got everyone on a list. I've got a minibus coming from the church at half twelve. I've told them it's a gas leak.
mrsfinch: I don't think it's a gas leak.
* "It's not a gas leak, Doreen."  -> kd.finch1
* "It's a gas leak."  -> kd.finch2

# kd.finch1
mrsfinch: No. I thought not. I won't ask. The tall gentleman never told me either.
mrsfinch: Minutes, item nine: "the building evacuated, all residents accounted for." That's all I'll write. That's all anyone needs to know.
{do flag:doorFinch=1; rel:mrsfinch+1}
@next kd.hub

# kd.finch2
mrsfinch: Gas leak. Right. Item nine. Gas leak.
{do flag:doorFinch=1}
@next kd.hub

# kd.end
> By half past twelve the Rookery is dark. On the sidewalk of Halloran Street, in coats over pyjamas, forty-odd people stand in the rain, and a church minibus idles at the corner, and somebody's handing out tea from a thermos.
> They're looking up at their building, wondering what's going to happen to it. Nothing, you hope. Nothing at all.
{do flag:doorsDone=1; task:s_doors=done; xp:50:Knock Knock; tick:30}
@end
`,'c_doors');
NL.EXTRAS.maureen=NL.EXTRAS.maureen||{n:'Maureen Halloran',color:'#d0b0b8',role:'Room 302 · the Rookery',spec:{face:{long:1.0,cheek:1.2,jaw:.9},skin:[.86,.76,.72],hair:{style:'bun',color:[.85,.82,.8]},shirt:[.6,.4,.5],coat:{color:[.4,.3,.35],length:.6,collar:true},height:.9}};
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];if(!f.doorsDone)return o;const n=['door6c','door302','door5b','doorNan','doorFinch'].filter(k=>f[k]).length;
  o.push(['The Rookery, Friday night',n>=4?'Forty-two flats, empty by half past twelve. Thirty-one cats in laundry baskets, a tenor in a carnation, a baby, a grandma in a nightie. They stood on Halloran Street in the rain and watched their building do nothing at all, and at dawn they went back in, and the Tenants\' Association has been insufferable about it ever since.':'Mostly empty by one. A few stayed. Nothing happened to them. Probably.']);return o;});
