'use strict';
/* THE NEW LORD — Act III · Night Three (Wednesday): "The Hound's Pursuit" — Valko, Locker #14, the Seizure, Tariq's 3 AM, the strike */
(function(){
const NL=window.NL,G=NL.G,A=NL.Audio;const {N,ENC,L,T,O,C,H,STORY}=NL.DSL;const {pushPop,pushNpc,pushEnter}=NL.Act;
const X=NL.EXTRAS;
Object.assign(X,{
  dale:{n:'Officer Dale',color:'#a0b0d0',role:'Precinct 9',spec:{face:{wide:1.08,jaw:0.4,brow:1.2},skin:[.82,.62,.52],hair:{style:'crop',color:[.4,.3,.2]},shirt:[.12,.16,.28],pants:[.1,.12,.2],coat:{color:[.1,.12,.2],length:.35,collar:true},height:1.05,width:1.15}},
  pruitt:{n:'Officer Pruitt',color:'#90a0c0',role:'Precinct 9',spec:{face:{long:1.06,jaw:0.8,nose:1.2},skin:[.9,.76,.68],hair:{style:'shaved',color:[.6,.5,.4]},shirt:[.12,.16,.28],pants:[.1,.12,.2],coat:{color:[.1,.12,.2],length:.35,collar:true}}},
  ghoulmen:{n:'Court enforcer',color:'#c090a0',role:'The Gilded Court',spec:{face:{long:1.04,jaw:0.6},skin:[.85,.75,.7],hair:{style:'slick',color:[.08,.06,.06]},shirt:[.1,.08,.1],coat:{color:[.06,.05,.07],length:.7,collar:true},height:1.06,width:1.1}},
  lanternman:{n:'LANTERN operator',color:'#b0b8c0',role:'Federal',spec:{face:{wide:1.04,jaw:0.5},skin:[.7,.58,.5],hair:{style:'shaved',color:[.2,.18,.15]},shirt:[.2,.22,.2],pants:[.18,.2,.18],coat:{color:[.16,.18,.16],length:.4,collar:true},glasses:{type:'aviator'},height:1.05,width:1.1}}
});
NL.ITEMS.lanternfile={n:'The Tuesday files',type:'read',d:'Seven patient folders from Rostova\'s basement: PROJECT LANTERN · DAYWALKER TRIAL. Dosage charts, temperature logs, seven death certificates she never filed. Counter-signed T.H.',sp:'Evidence.'};
NL.ITEMS.rayfile={n:'Ray Dunleavy\'s notebook',type:'read',d:'A detective\'s notebook, 2019, in a dead man\'s handwriting: "St. J free clinic → Fed van → Kowalski\'s back door. WHO SIGNS?" The last page: "Rostova. Ask Ines."',sp:'For Miller.'};
NL.ITEMS.basementbadge={n:'Basement badge',type:'tool',d:'A St. Jude\'s staff lanyard: E. ROSTOVA, M.D. · CLEARANCE B1.',sp:'Opens the morgue elevator.'};

/* ---------- the night ---------- */
NL.NIGHTS[3]={title:'Act III · The Hound\'s Pursuit',sub:'Wednesday',
  heatAdd:S=>S.flags.morgueAlarm?1:0,
  canSleep:S=>S.time>=300||(S.tasks.locker==='done'&&S.time>=200),
  endTitle:'The strike',
  endLine:S=>({court:'Séverine\'s people came for you before dawn.',syndicate:'Malakor\'s people came for you before dawn.',lantern:'The men with the light came for you before dawn.'})[S.flags.striker]||'Somebody came for you before dawn.',
  async start(G,S,hav){const h=NL.Camp.havenRoom(hav);
    await G.enterRoom(h.room,h.spawn,{instant:true,noEnter:true});
    G.cine(true);A.music('dread');await G.wait(.5);
    await G.say([T('You wake already listening. Something is outside. Something has been outside for an hour, waiting for the sun to go, breathing slow through its nose.'),
      L('parasite','Wet dog. Old blood. Cedar and gun oil. It knows you\'re in here. It has known since noon.',{pass:3}),
      L('tenant','Valko. Oh, my boy. He\'s found me.'),
      L('sundial','Wednesday. Two nights to the Tribunal. And a Hound at the door.')]);
    G.task('valko');S.quests.note_valko='Valko, Vane\'s Hound, has your scent. Séverine set him on you. Survive him, or make him yours.';
    G.task('locker');S.quests.note_locker=S.flags.drawer14?'Morgue drawer B-14, St. Jude\'s basement. '+((NL.G.has('lockerkey'))?'You have the key.':'Mother Soot has the key.'):'Something of Vane\'s waits in the St. Jude\'s morgue.';
    await G.talk('vk.0');
    G.cine(false);
    if(S.tasks.s_tariq==='active')setTimeout(()=>G.text('Tariq (Lucky Mart)','tonight is wednesday. you said maybe. they come at 3. i made coffee. you dont drink coffee. i made it anyway'),14000);
    if(S.dos.miller&&S.rel.miller>=1)setTimeout(()=>G.text('Unknown','It\'s Miller. Harrow pulled the Kowalski file. Federal jurisdiction. I\'m off the case as of noon. I\'m not off the case. Call me.'),26000);
    G.autosave();},
  async cliff(G,S,hav){
    const striker=S.flags.serve==='court'?'syndicate':S.flags.serve==='syndicate'?'court':S.flags.serve==='mortal'?'court':'lantern';
    S.flags.striker=striker;
    const who={court:'Three of Séverine\'s enforcers in long coats, and between them, a woman with a gas can.',syndicate:'Four of Malakor\'s men with bolt cutters and a road flare.',lantern:'Two men in grey with a light on a pole, and a third with a clipboard.'}[striker];
    await G.say([T('Twenty minutes before dawn. You are almost home when you hear it: glass breaking, ahead of you, where you sleep.'),
      T(who),
      L('web',S.flags.vesselHeld?'They\'re not here for you. They\'re here for what\'s in your coat. Somebody talked.':'They don\'t know where the Vessel is. They\'re here to make sure you don\'t either.'),
      L('pemberton','Get in the car. GET IN THE CAR.',{if:S=>!S.flags.pemDead})],
      );
    let saved=false;
    if(S.flags.valkoAlly){await G.say([T('A shape comes out of the alley behind them like a thrown knife. Valko. You hear one of them scream and then you hear nothing.'),L('valko','Go. I\'ll catch up. I always catch up.')]);saved=true;}
    else if(S.flags.ottolineOwes&&!S.flags.ottolineUsed){await G.say([T('A pop, a hiss, and every one of them is suddenly coughing on the ground, eyes streaming. A copper-haired woman in a bathrobe waves at you from a fire escape.'),L('ottoline','Contract-owe! Paid in full! Don\'t call me again!')]);S.flags.ottolineUsed=1;saved=true;}
    else if(S.flags.wightPet){await G.say([T('You let the Wight off its leash. You don\'t watch. You hear it, though. You will hear it for a long time.')]);saved=true;S.flags.wightUsed=1;G.comp(-1,'The Wight');}
    else if(S.flags.rookerySafe&&hav==='rookery'){await G.say([T('The Rookery lights go violet. There is a lot of screaming on the stairs and then the clatter of people running away.'),L('dutch','LOCAL ZERO! LOCAL ZERO!')]);saved=true;}
    if(!saved){
      await G.say([T('You don\'t fight. There\'s no time and too many of them. Pemberton drives with the lights off down Ferrier Lane while your haven burns behind you.',{if:S=>!S.flags.pemDead}),
        T('You run. Your haven burns behind you.',{if:S=>S.flags.pemDead})]);
      S.flags.havenLost=hav;
      if(S.flags.vesselHeld){
        if(S.flags.vesselHidden){await G.say([L('nostalgia','You didn\'t keep it on you. Of course you didn\'t. It\'s still where you left it.')]);}
        else{S.flags.vesselHeld=0;S.flags.vesselLost=striker;G.take('vessel');await G.say([T('Somebody grabs your coat as you go through the door. It tears. When you get to the car the weight in the pocket is gone.'),L('sundial','They have the sun. Whoever they are, they have the sun.')]);}
      }
      if(!S.flags.pemDead&&!S.flags.valkoAlly){S.flags.pemHurt=1;await G.say([T('At the end of the lane Pemberton pulls over, quite calmly, and puts a hand to his side, and it comes away dark.'),L('pemberton','Just a graze, ‹sir›. Just a graze. I\'ll drive you to the crypt. Then I think I\'ll sit for a while.')]);}
    }
    await G.say([T('You sleep where you can: the backseat of the car, the trunk, a drain. The sun comes up over the Marrow Ward and finds you only by inches.'),
      L('tenant','Thursday. Martial law tomorrow, if I know her. She\'ll call the Blood Hunt by midnight.'),
      L('sundial','One night to set the board. Then Friday.')]);
    S.hav=S.flags.havenLost?'car':hav;}
};
NL.Camp.HAVENS.car={room:'alley',spawn:{x:5.6,z:2.6,ry:0.4},n:'The back seat of the Sheriff\'s car'};

/* =====================================================================
   SCENE 3.1 · Valko
   ===================================================================== */
N['vk.0']={cs:async(G,S)=>{const h=G.actor('you');G.addActor('valko',NL.CHARS.valko.spec,{x:(h?h.x:3)+1.6,z:(h?h.z:3)+0.4,ry:-1.6,breathes:true,pose:'crouch'});G.focus(['you','valko'],.7);G.look('valko','you');G.look('you','valko');A.sfx('sting');await G.wait(.6);},
  lines:[T('He comes in low and silent, through a door you thought was locked: a lean man in a waxed coat with a face like a hatchet and eyes like two lamps behind dirty glass. He doesn\'t attack. He *sniffs*.'),
    L('valko','...He\'s in you. I can smell him in your sweat. Absalom. My Absalom.'),
    L('valko','Séverine says you\'re a thief who ate the Sheriff on a butcher\'s floor. Séverine says I may have you, in pieces, for the Tribunal. Give me one reason to leave you in one piece.'),
    L('pedigree','Valko Drăgan. A Hound. Vane\'s for seventy years. Loyal the way a dog is: entirely, and only to one man.',{pass:5})],
  next:'vk.enc'};
N['vk.enc']={enc:'hound',win:'vk.win',lose:'vk.lose',kill:'vk.kill',flee:'vk.flee'};
ENC.hound={title:'THE HOUND',sub:'Valko Drăgan · seventy years at heel',music:'dread',after:'night',
  prog:{name:'Recognition',max:6,color:'#e2c27e'},threat:{name:'His teeth',max:6,color:'#e06050'},
  focus:G=>G.focus(['you','valko'],.7),
  start(S,G){let t=1;if(S.flags.sevKnows||S.flags.sevEnemy)t+=1;if(S.clan==='hounds')t-=1;let p=0;if(S.sync>=30)p+=1;return {prog:p,threat:Math.max(0,t)};},
  intro:[L('valko','Speak, thief. Quickly.')],
  round(st,S,G){const Q=[
    ()=>({lines:[T('He circles, close enough to touch, sniffing at your collar, your hands, your mouth.')]}),
    ()=>({lines:[L('valko','He would never have let a neonate *drink* him. Never. He was a Sovereign. He would have died first.'),L('tenant','I did die first, Valko. That was rather the problem.')],threat:1}),
    ()=>({lines:[T('His lips come back from his teeth. They are not quite human teeth any more.')],threat:1}),
    ()=>({lines:[L('valko','Last chance. Tell me something only he would know.')]})];return st.round<Q.length?Q[st.round]():null;},
  moves(st,S,G){const r=st.round,M=[];
    M.push(C('pedigree',10,'Let the Tenant speak. "Valko. Heel."',null,null,{id:'vk_ped'+r,mod:S=>Math.floor(S.sync/20),ok:(st,S,G)=>{st.prog+=2;G.sync(3,'Vane speaks through you');return [T('It comes out of your mouth in a voice that isn\'t yours: dry, old, amused, used to being obeyed.'),T('Valko stops circling. His knees bend before he can stop them.')];},no:st=>{st.threat+=1;return [L('valko','You sound like a child doing an impression.')];}}));
    M.push(C('nostalgia',10,'"He kept a photograph of you in his watch. 1955, Bucharest. You were laughing."',null,null,{id:'vk_nos',once:'vk_nos',mod:(S,G)=>G.has('pocketwatch')||G.has('wristwatch')?2:0,ok:st=>{st.prog+=3;return [L('valko','...He told nobody about that photograph. Nobody.'),T('Something in his face goes very young for a second.')];},no:st=>{st.threat+=1;return [L('valko','Everybody knows about Bucharest.')];}}));
    M.push(C('pulse',9,'"You loved him. I can hear it. I\'m sorry."',null,null,{id:'vk_pulse'+r,ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [L('valko','Don\'t you dare. Don\'t you DARE be sorry. You *ate* him.')];},no:st=>{st.threat+=1;return [L('valko','I don\'t want your pity, thief.')];}}));
    M.push(C('web',10,'"Séverine set you on me so you wouldn\'t ask who set the trap. Ask me who. I know."',null,null,{id:'vk_web',once:'vk_web',mod:S=>S.flags.maskedBuyer?2:0,ok:(st,S,G)=>{st.prog+=2;return [L('valko','...Who?'),L('you',S.flags.maskedBuyer?'"A woman in a surgical mask. She bought a UV lance from Malakor on Sunday. Vane walked her in himself."':'"Somebody he trusted. Somebody who brought a weapon to a meeting he thought was a cure."'),L('valko','A cure. He went to her for the *cure*. I told him. I TOLD him.')];},no:st=>{st.threat+=1;return [L('valko','Séverine said you\'d try to talk.')];}}));
    if(G.has('signet'))M.push({t:'Show him the signet ring.',once:'vk_ring',ok:st=>{st.prog+=2;return [T('He takes your hand and holds the ring to his nose and breathes it in with his eyes closed.'),L('valko','...His. Still warm with him.')];}});
    if(S.clan==='hounds')M.push({t:'Drop to a crouch. Bare your throat. Pack to pack.',once:'vk_pack',ok:st=>{st.prog+=2;st.threat=Math.max(0,st.threat-1);return [L('valko','...You have the blood. You were made right. He made you right.')];}});
    const ab=(id,t,fn,extra)=>M.push(Object.assign({t,ab:id,ok:fn},extra||{}));
    ab('scent','Blood-Scent: smell what he\'s been doing since Monday.',(st,S,G)=>{st.prog+=1;S.flags.valkoSmell=1;return [T('Séverine\'s perfume on his sleeve. Grief, a great deal of it, gone sour. And Rostova: hospital soap and the faint copper of vitae. He\'s been to the clinic. He sat outside it all Monday night.'),L('web','He went to the clinic first. He suspected her too.')];},{once:'vk_scent'});
    ab('dejavu','Déjà Vu: see where he lunges, before he does.',st=>{st.threat=Math.max(0,st.threat-2);return [T('Left, high, at the throat. You\'re already not there when he arrives.')];},{once:'vk_dv'});
    ab('kneel','Kneel: "Sit."',(st)=>{st.prog+=1;st.threat+=1;return [T('He sits. He hates it. He\'ll remember it.')];},{once:'vk_kneel'});
    ab('shadowstep','Shadow-Step past him and out the door.',(st)=>{st.result='flee';return [T('Darkness folds you up and puts you down three streets away. Behind you, a howl of pure frustration.')];});
    M.push(C('frenzy',13,'Kill him. Right now. Before he kills you.',null,null,{id:'vk_fr',red:true,ok:(st)=>{st.result='kill';return [];},no:st=>{st.threat+=3;return [T('He is seventy years faster than you. He opens your face to the cheekbone and steps back to let you bleed.')];}}));
    return M;},
  decide(st){return st.prog>=4?'win':'lose';},
  outro(r,st,S,G){S.flags.valkoOut=r;return [];}
};
N['vk.win']={lines:[T('Valko sits back on his heels on the floor of your haven. He looks very tired, suddenly, and very old.'),
  L('valko','It\'s really him. A piece of him. In a *neonate*. God has a sense of humour.'),
  L('valko','I sat outside the clinic all Monday night. I saw the Volvo come back at half four. The doctor, alone, sitting in the car, holding the steering wheel, shaking.'),
  L('valko','I didn\'t go in. He told me to stay with the car. Seventy years, I always did what he told me.'),
  L('tenant','Tell him I\'m sorry, would you? No. Tell him "good dog." He\'ll understand.')],
  opts:[O('"He says: good dog."','vk.good'),O('"Séverine sent you to kill me. What do you tell her?"','vk.sev'),O('"Help me take the Ward. For him."','vk.help')]};
N['vk.good']={lines:[T('He laughs, or sobs. With Hounds it\'s the same sound.'),L('valko','Seventy years. "Good dog." Yes. That\'s him.',{do:(S,G)=>{S.flags.valkoAlly=1;G.task('valko','done');G.rel('valko',3);G.xp(40,'The Hound');G.comp(1,'Good dog');}}),
  L('valko','I\'ll tell the Lady I lost your scent in the river. She\'ll be furious. She\'s pretty when she\'s furious.')],next:'vk.after'};
N['vk.sev']={lines:[L('valko','I tell her I lost you in the river. I\'ve never lied to her before. It feels... good. Is that terrible?',{do:(S,G)=>{S.flags.valkoAlly=1;G.task('valko','done');G.rel('valko',2);G.xp(40,'The Hound');}})],next:'vk.after'};
N['vk.help']={lines:[L('valko','For him. Yes. For him, I\'ll do anything. Even serve a thief.',{do:(S,G)=>{S.flags.valkoAlly=1;S.flags.valkoSworn=1;G.task('valko','done');G.rel('valko',3);G.xp(40,'The Hound');G.offer('leash');}})],next:'vk.after'};
N['vk.after']={lines:[L('valko','Whatever he left in that morgue, get it tonight. Everyone in this Ward can smell that he hid something. Everyone is coming for it.'),
  L('valko','Call me. Whistle. I\'ll hear.')],cs:async(G,S)=>{G.dlgHide();G.walk('valko',(G.actor('you')||{x:3}).x+4,0.2);await G.wait(1.4);G.removeActor('valko');},end:true};
N['vk.lose']={lines:[T('He hits you once, in the sternum, with the heel of his hand, and you feel ribs go. Then he\'s on top of you with his teeth an inch from your throat.',{fx:['shake:1.4','hurt:1.2'],do:(S,G)=>{G.vitae(-2);}}),
  L('valko','No. Not here. Not like a dog in a box. He\'d want it done in front of the Court.'),
  L('valko','Friday. Platform 0. I\'ll bring you myself. Run if you like. It\'s been years since anything made me run.',{do:(S,G)=>{S.flags.valkoHunt=1;G.task('valko','done');G.heat(1);}})],cs:async(G,S)=>{G.dlgHide();G.removeActor('valko');},end:true};
N['vk.flee']={lines:[L('sundial','He\'ll find you again. Every time you stop moving, he\'ll find you again.',{do:(S,G)=>{S.flags.valkoHunt=1;G.task('valko','done');}})],cs:async(G,S)=>{G.removeActor('valko');},end:true};
N['vk.kill']={lines:[T('You go for him with everything the Frenzy has, and for one second he is surprised, and that second is all you get, and all you need.'),
  T('Seventy years of loyalty is very sweet. It goes down like a hymn.',{fx:['flash','shake:1.6','sfx:drink'],do:(S,G)=>{S.flags.valkoDead=1;S.kills++;G.feed(4,'sanguine','Valko, his heart',{kind:'kindred',kill:true});G.sync(10,'Two Kindred now, in one skull');G.comp(-3,'You drank the Hound');G.task('valko','done');S.flags.diablerie2=1;G.offer('darwin');}}),
  L('tenant','...Valko. Oh, my boy. You have no idea what you\'ve done.'),L('frenzy','We are STRONGER. We are so much STRONGER.')],cs:async(G,S)=>{G.dlgHide();G.pose('valko','slump',2);await G.wait(1.2);G.removeActor('valko');},end:true};

/* =====================================================================
   SCENE 3.2 · Getting into the morgue
   ===================================================================== */
(function(){const sj=NL.ROOMS.stjude;const e=sj.inter.find(i=>i.id==='elevator');if(e)e.if=S=>!S.flags.morgueOK;})();
const elevB=H.use.elevator;
H.use.elevator=async(S,G)=>{if(S.night>=3&&!S.flags.morgueOK)return G.talk('el.0');return elevB?elevB(S,G):false;};
N['el.0']={lines:[T('The staff elevator. BASEMENT · MORGUE · CLOSED BY ORDER OF PRECINCT 9. The badge reader glows red.'),
  L('echo','Night nurse at the desk. Two orderlies on a smoke break. The camera above the door still isn\'t plugged in.',{pass:6})],
  opts:[O('Swipe Rostova\'s basement badge.','el.in',{if:(S,G)=>G.has('basementbadge')}),
    O('Spark-Jump: feed the reader a little of yourself.','el.in',{ab:'spark'}),
    C('stagecraft',10,'Push a trolley in with a sheet over it. "Delivery for B1."','el.in','el.no',{id:'el_stg',mod:(S,G)=>(G.equipped('smock')?2:0)+(G.equipped('triagemask')?1:0)+(S.past==='paramedic'?2:0)}),
    C('velvet',11,'Ask the night nurse to buzz you down.','el.in','el.no',{id:'el_vel',if:S=>!S.flags.vtNurseMad,mod:S=>S.flags.tinyLoyal?1:0}),
    O('Call Miller. "I can get you into Rostova\'s basement."','el.miller',{if:S=>S.dos.miller&&S.rel.miller>=1}),
    O('Leave it.',null,{end:true,leave:true})]};
N['el.in']={lines:[T('Green light. A ding like a microwave. The doors open on a steel box that smells of bleach and cold.',{do:S=>S.flags.morgueOK=1}),L('sundial','Down.')],cs:async(G,S)=>{G.dlgHide();await G.enterRoom('morgue',{x:0.95,z:4.8,ry:1.6});},end:true};
N['el.no']={lines:[L('nurse','Uh-uh. Nobody goes down there without Dr. R. Police orders.',{do:S=>S.flags.vtNurseMad=1})],end:true};
N['el.miller']={lines:[T('She answers on the first ring. She\'s there in nine minutes, in a parka over pyjamas, holding a warrant she has printed out herself at home.'),
  L('miller','This is extremely illegal. Lead the way.',{do:(S,G)=>{S.flags.morgueOK=1;S.flags.millerMorgue=1;G.rel('miller',1);}})],cs:async(G,S)=>{G.dlgHide();await G.enterRoom('morgue',{x:0.95,z:4.8,ry:1.6});},end:true};
pushPop('morgue',(S,G)=>{if(S.flags.millerMorgue&&S.night===3&&!S.flags.millerLeftMorgue)G.addActor('miller',NL.CHARS.miller.spec,{x:1.8,z:3.6,ry:1.2,breathes:true,pose:'arms'});});
pushNpc('morgue',(S,G)=>G.actor('miller')?{id:'miller',actor:'miller',label:'Miller'}:null);
pushEnter('morgue',async(S,G)=>{A.music('dread');if(G.once('morgue1'))await G.say([T('The morgue. Green tile, steel drawers, a drain in the floor. The air conditioning is set to "mausoleum".'),
  L('tenant','I was here on Sunday night. I lay on that table and let her draw four pints. "For the cure," she said. "For the formula." Fool. *Fool.*'),
  L('autopsy','Through the plastic curtain on the right: cots. Seven of them have been slept in. None recently.',{pass:5})]);});

/* =====================================================================
   SCENE 3.3 · Drawer B-14 and the Sun-Vessel
   ===================================================================== */
H.use.drawer14=async(S,G)=>{if(S.flags.vesselTaken)return G.say([T(S.flags.vesselHidden?'B-14. The John Doe, sewn back up, with the sun inside him again.':'B-14. The John Doe, opened, empty, very patient.')]);return G.talk('d14.0');};
N['d14.0']={lines:[T('B-14. A paper tag on the handle in your own handwriting, though you don\'t remember writing it: JOHN DOE · HOLD FOR S.'),
  L('nostalgia','Your hand knows the lock. It\'s been here before. Monday morning, five a.m., with the sun coming and the Sheriff\'s blood still in your teeth.',{pass:5})],
  opts:[O('Use the key from Mother Soot.','d14.open',{if:(S,G)=>G.has('lockerkey')}),
    C('frenzy',11,'Rip the drawer out of the wall.','d14.force','d14.forceNo',{id:'d14_fr'}),
    O('Boil the Vein: heat the lock until it gives.','d14.force',{ab:'boil'}),
    O('Leave it shut.',null,{end:true,leave:true})]};
N['d14.force']={lines:[T('Metal screams. The lock goes. Somewhere upstairs, an alarm begins, polite and electronic, and somewhere under the city an old woman sits up in her candlelight and says *ah*.',{fx:['shake:1','sfx:metal'],do:(S,G)=>{S.flags.morgueAlarm=1;G.heat(1);G.rel('soot',-2);S.flags.sootCrossed=1;G.breakPromise('soot');}})],next:'d14.open'};
N['d14.forceNo']={lines:[T('The drawer holds. Your shoulder doesn\'t.',{fx:['shake:.6'],do:(S,G)=>G.vitae(-1)})],next:'d14.0'};
N['d14.open']={cs:async(G,S)=>{S.flags.drawerOpen=1;G.rebuildRoom&&G.rebuildRoom();A.sfx('metal');},
  lines:[T('The drawer rolls out on its runners with a sound like a long exhale. A body bag. Inside the bag, a man nobody claimed: fifties, thin, a tattoo of an anchor. Sewn shut from sternum to navel with big ugly surgical stitches.'),
  L('autopsy','You did this. Those are your knots. You put something inside a dead man and sewed him up and wrote HOLD on the tag, and you were crying.',{pass:3}),
  L('tenant','Do it. Open him. It\'s mine. It was always mine.')],
  opts:[O('Cut the stitches.','d14.cut'),O('Close the drawer. Not yet.',null,{end:true,leave:true})]};
N['d14.cut']={lines:[T('You cut. Inside, nested where the stomach should be, wrapped in a hospital gown: brass. Warm. Humming very faintly, like a fridge in another room.'),
  T('The Sun-Vessel. A brass bottle the length of your forearm, lead-sealed, with a dial at the neck marked in a script you don\'t know, and a single word stamped in English: NOON.'),
  L('sundial','Don\'t touch the dial. Don\'t touch the DIAL.'),
  T('You lift it out. Your hands are on the brass where his hands were on Sunday night, and his blood in you *recognizes* it.',{fx:['flash'],do:(S,G)=>{S.flags.vesselTaken=1;G.task('locker','done');G.xp(60,'Locker #14');}})],
  next:'sz.0'};

/* =====================================================================
   SCENE 3.4 · The Diablerie Seizure
   ===================================================================== */
N['sz.0']={cs:async(G,S)=>{A.music('grief');G.shake&&G.shake(1.2);},lines:[
  T('The morgue goes away.'),
  T('SUNDAY · 10:40 PM. You are Absalom Vane, and you are walking up the stairs at Platform 0 with a brass bottle in a velvet bag, and you are *happy*, for the first time in a hundred years.'),
  L('tenant','(memory) She says she can do it. She says she can make the sun safe. One bottle. One dose. One vampire who can stand in the morning and feel it on his face.'),
  T('Beside you, carrying the case, a young night-shift orderly from St. Jude\'s with bitten nails and a nervous laugh. You found them on Rostova\'s free-clinic list, a week ago, and you thought: *this one. This one doesn\'t have anyone. This one will do.*'),
  L('nostalgia','That\'s you. That\'s *you*, a week ago, alive.'),
  T('SUNDAY · 11:00 PM. A woman in a surgical mask meets you at Malakor\'s bench and takes a long black case and doesn\'t say a word. You think: *how careful she is. How professional.*'),
  T('MONDAY · 3:50 AM. Kowalski\'s back room. You told the recruit to chain the dishwasher in the freezer so he wouldn\'t run into Malakor\'s men. The recruit cried. You said, "Don\'t waste him."'),
  T('MONDAY · 4:14 AM. You kneel on the freezer floor, because she asked you to, "for the transfusion." The recruit holds your coat. Rostova lifts the lance. Behind her, in the doorway, a man in a grey suit: *Harrow*.'),
  T('White. White with edges.'),
  T('And then the recruit, screaming, puts their mouth on your throat and drinks you before the light can take all of you. Rostova drops the lance and runs. Harrow is already gone.'),
  L('tenant','(memory) You saved me. You little fool. You drank me to *save* me.'),
  T('The morgue comes back. You are on your knees on the tile with the Vessel in your arms, and there are two of you in here, and both of you are trying to stand up at once.',{do:(S,G)=>{S.flags.sawAmbush=1;G.fact('rostova','lance');G.fact('harrow','ambush');S.flags.knowRecruit=1;}})],
  next:'sz.choice'};
N['sz.choice']={lines:[L('tenant','Let me have the hands. Only for a while. I know this city. I know where the knives are. You don\'t even know your own *name*.'),
  L('pulse','If you let him in now, all the way, you will never get the door shut again.'),
  T('THE DIABLERIE SEIZURE. Choose who rules your skull.')],
  opts:[O('SUPPRESS. "Get back in your box, Absalom."','sz.sup'),O('HARMONIZE. "Neither of us drives. We share the wheel."','sz.har'),O('SURRENDER. "Take the hands. Save us."','sz.sur')]};
N['sz.sup']={lines:[T('You push. He pushes back. It\'s like holding a door against a man who has been holding doors for three hundred years.'),
  T('And then he lets go, quite suddenly, with something like a laugh, and sinks.',{fx:['shake:1'],do:(S,G)=>{S.flags.seizure='suppress';G.sync(-25,'Suppressed');S.sync=Math.max(0,S.sync);G.comp(2,'You are yourself');G.task('seizure','done');G.offer('golconda');}}),
  L('tenant','...Very well. Very well. I\'ll be here. I\'m always here. Call if you need a Sheriff.'),
  L('pulse','Your own hands. Your own shaking hands. Hold onto that.')],next:'sz.after'};
N['sz.har']={lines:[T('You don\'t push. You don\'t give way. You sit down, inside, next to him, the way you\'d sit down next to someone crying at a bus stop.'),
  L('tenant','...What are you doing?'),L('you','"Sharing."'),
  T('Something settles. Two voices in one throat, in tune for the first time. When you speak next it comes out in a chord.',{do:(S,G)=>{S.flags.seizure='harmonize';S.sync=50;G.toast('rel','Diablerie Sync 50%','Harmonized');G.task('seizure','done');G.offer('firstmurder');S.flags.chord=1;G.toast('level','Pedigree checks gain +1 while Harmonized. The Tenant\'s voice is an ally now.','The Chord');}}),
  L('tenant','Well. This is novel. I think I like you.')],next:'sz.after'};
N['sz.sur']={lines:[T('You let go. He takes the hands like a man taking the wheel of a car he has driven for a century. Your spine straightens. Your chin comes up. You know, suddenly, the name of every Elder in the Ward and what each of them is afraid of.'),
  L('tenant','Thank you. Truly. Now be quiet, there\'s a good child.',{do:(S,G)=>{S.flags.seizure='surrender';G.sync(35,'He has the hands');G.comp(-2,'You let him in');G.task('seizure','done');S.flags.vaneRising=1;G.offer('absolutist');}}),
  L('nostalgia','...Hello? Is anyone still — ')],next:'sz.after'};
N['sz.after']={lines:[L('sundial','The Vessel. Decide where it sleeps tonight. Everyone in the Ward is going to know by morning that the drawer is open.')],
  opts:[O('Keep it on you. Never let it out of your hands.','sz.keep'),O('Sew it back inside John Doe. Nobody will look twice.','sz.hide',{if:S=>!S.flags.morgueAlarm}),O('Give it to Miller to hold.','sz.miller',{if:(S,G)=>G.actor('miller')})]};
N['sz.keep']={lines:[T('It goes in the inside pocket of your coat. It\'s heavier than it looks, and warm against your ribs, like a sleeping animal.',{do:(S,G)=>{G.give('vessel');S.flags.vesselHeld=1;}})],end:true};
N['sz.hide']={lines:[T('You sew him back up. Your stitches are much better this time.',{do:(S,G)=>{S.flags.vesselHeld=1;S.flags.vesselHidden='morgue';S.flags.drawerOpen=0;G.rebuildRoom&&G.rebuildRoom();}}),L('autopsy','Better knots. You\'re getting good at this. That should frighten you.')],end:true};
N['sz.miller']={lines:[L('miller','What is it? No. Don\'t tell me. If I don\'t know, they can\'t make me say.'),T('She wraps it in her parka and holds it like a baby that might go off.',{do:(S,G)=>{S.flags.vesselHeld=1;S.flags.vesselHidden='miller';G.rel('miller',1);}}),L('miller','I\'ll keep it at my sister\'s. She has a dog.')],end:true};

/* =====================================================================
   SCENE 3.5 · The Tuesday room: the seven, and Ray Dunleavy
   ===================================================================== */
H.use.cots=async(S,G)=>G.talk('tr.0');
N['tr.0']={lines:[T('Seven cots behind the plastic curtain. Restraint straps, padded. IV stands. On each pillow, a laminated card with a first name: DANI. PETE. MARGUERITE. JOSÉ. KWAME. LIBBY. HOLLIS.'),
  L('autopsy','Burns on the straps. Fine, symmetric, like a sunburn on the inside of the wrist. They were given vampire blood and then exposed to UV. Over and over.',{pass:4}),
  L('web','She wasn\'t trying to cure vampires. She was trying to make *mortals* who could take the light and still have the blood. Daywalkers. Soldiers. LANTERN\'s weapon.',{pass:6,do:S=>S.flags.knowDaywalker=1}),
  L('nostalgia','DANI. Mrs. Okafor\'s Dani. Nineteen. Asthma.',{if:S=>S.flags.met404,do:(S,G)=>{S.flags.daniFound=1;}})],
  opts:[O('Take Dani\'s name card for her grandmother.','tr.card',{if:S=>S.flags.met404&&!S.flags.daniCard}),O('Step back.',null,{end:true,leave:true})]};
N['tr.card']={lines:[T('Laminated, a little bent. Someone drew a heart on it in biro, a long time ago.',{do:(S,G)=>{S.flags.daniCard=1;G.give('danicard');}})],end:true};
NL.ITEMS.danicard={n:'"DANI"',type:'tool',d:'A laminated name card from a cot in Rostova\'s basement. Someone drew a heart on it.',sp:'For Mrs. Okafor.'};
H.use.labdesk=async(S,G)=>G.talk('ld.0');
N['ld.0']={lines:[T('Rostova\'s basement desk: a laptop with a dead battery, a coffee mug that says WORLD\'S OKAYEST DOCTOR, a locked drawer and an unlocked one.')],
  opts:[O('Read the patient folders.','ld.files',{if:(S,G)=>!G.has('lanternfile')}),
    C('gutter',9,'Jimmy the locked drawer.','ld.locked','ld.no',{id:'ld_gut',if:S=>!S.flags.ldLocked}),
    O('Search under the blotter.','ld.badge',{if:(S,G)=>!G.has('basementbadge')&&!S.flags.ldBadge}),
    O('Leave.',null,{end:true,leave:true})]};
N['ld.files']={lines:[T('PROJECT LANTERN · DAYWALKER TRIAL · PHASE II. Seven folders. Dosage charts (vitae, millilitres, source: "V."). Temperature logs. Seven death certificates, filled in and never filed. Every page counter-signed T.H.'),
  L('web','"Source: V." Vane\'s blood. The four pints on Sunday. He was paying for his own cure with the blood she used to make his killers.',{do:(S,G)=>{G.give('lanternfile');S.flags.knowLantern2=1;G.fact('harrow','lantern');G.fact('rostova','trial');G.xp(30,'The Tuesday files');}}),
  T('An eighth folder, thinner, at the bottom. A name you almost recognize. A photograph of someone with bitten nails and a nervous laugh. Status: WITHDRAWN · RECRUITED BY SUBJECT V.',{do:(S,G)=>{S.flags.frag_chart=1;G.task('x_name');S.quests.note_x_name='Fragments of who you were: '+['watch','letter','chart'].filter(k=>S.flags['frag_'+k]).join(', ')+'. One more waits in still water.';}}),
  L('nostalgia','You were number eight. He found you on her list and took you before she could.')],next:'ld.0'};
N['ld.locked']={lines:[T('Inside: a detective\'s notebook in a plastic evidence bag, 2019, the cover stained. R. DUNLEAVY.',{do:(S,G)=>{S.flags.ldLocked=1;G.give('rayfile');S.quests.note_s_cold='You found Ray Dunleavy\'s notebook in Rostova\'s desk. Get it to Miller.';}}),
  L('web','Ray found the clinic-to-Kowalski\'s pipeline in 2019. And then Ray was "mugged". And his notebook ended up in her drawer.')],next:'ld.0'};
N['ld.no']={lines:[T('The drawer is better made than the desk.')],next:'ld.0'};
N['ld.badge']={lines:[T('A spare lanyard, taped under the blotter where only a tired person would think to keep it. E. ROSTOVA · CLEARANCE B1.',{do:(S,G)=>{S.flags.ldBadge=1;G.give('basementbadge');}})],next:'ld.0'};
H.use.slab=async(S,G)=>G.say([T('The autopsy table. A drain at the foot. A paper towel dispenser. Somebody has scrubbed it very, very hard.'),L('tenant','Four pints. I lay here and watched the bags fill. She held my hand.',{if:S=>S.flags.sawAmbush})]);

// Miller in the morgue
H.use.miller=(function(prev){return async(S,G)=>{if(S.room==='morgue')return G.talk('mm.0');return prev?prev(S,G):false;};})(H.use.miller);
N['mm.0']={lines:[L('miller','Talk to me. What am I looking at?')],opts:[
  O('Show her the Tuesday files.','mm.files',{if:(S,G)=>G.has('lanternfile')&&!S.flags.millerFiles}),
  O('Give her Ray\'s notebook.','mm.ray',{if:(S,G)=>G.has('rayfile')}),
  O('"Go home, Ines. You were never here."','mm.bye')]};
N['mm.files']={lines:[T('She reads standing up, very fast, turning pages with the corner of her badge so she doesn\'t touch them.'),L('miller','"T.H." Thomas Harrow. Federal. He\'s been signing death certificates for a doctor running human trials in a hospital basement, and the bodies go out the back of a butcher\'s.'),
  L('miller','I need a judge. A real one. Not one of the ones who play golf with Harrow.',{do:(S,G)=>{S.flags.millerFiles=1;G.rel('miller',1);S.flags.millerTheory='lantern';}})],next:'mm.0'};
N['mm.ray']={lines:[T('She takes the evidence bag and doesn\'t open it. She just holds it, with both hands, looking at the handwriting through the plastic.'),
  L('miller','...That\'s Ray\'s writing. That\'s Ray\'s stupid writing. "Ask Ines." He was going to ask me. He never got to ask me.'),
  L('miller','I owe you. Whatever you are. I owe you.',{do:(S,G)=>{G.take('rayfile');G.task('s_cold','done');G.rel('miller',3);S.flags.millerAlly=1;G.xp(50,'Ray Dunleavy');G.comp(2,'For Ray');}})],next:'mm.0'};
N['mm.bye']={lines:[L('miller','Never was. Call me.')],cs:async(G,S)=>{S.flags.millerLeftMorgue=1;G.dlgHide();G.walk('miller',0.95,4.8);await G.wait(1.5);G.removeActor('miller');},end:true};

/* =====================================================================
   SCENE 3.6 · 3 AM at the Lucky Mart: Officers Dale and Pruitt
   ===================================================================== */
const racketOn=S=>S.night===3&&S.tasks.s_tariq==='active'&&S.time>=330&&S.time<420&&!S.flags.racketDone;
pushPop('luckymart',(S,G)=>{if(racketOn(S)){G.addActor('dale',X.dale.spec,{x:3.4,z:2.0,ry:-0.6,breathes:true,pose:'arms'});G.addActor('pruitt',X.pruitt.spec,{x:4.3,z:2.6,ry:-1.4,breathes:true,pose:'lean'});}});
pushNpc('luckymart',(S,G)=>G.actor('dale')?[{id:'dale',actor:'dale',label:'Officer Dale'},{id:'pruitt',actor:'pruitt',label:'Officer Pruitt'}]:null);
pushEnter('luckymart',async(S,G)=>{if(racketOn(S)&&G.once('racket'))await G.talk('rk.0');});
H.use.dale=async(S,G)=>G.talk('rk.hub');H.use.pruitt=H.use.dale;
N['rk.0']={enter:(S,G)=>{G.focus(['you','dale','pruitt'],.8);},lines:[T('Two uniforms at the counter. Dale, big, leaning on the till with both elbows. Pruitt by the coffee machine, filling a cup he isn\'t going to pay for.'),
  L('dale','Usual, Tariq. Plus twenty for the inconvenience of the murder down the road. Lot of extra patrols. Lot of overtime.'),
  L('tariq','I do not have it. I do not have it this week. My cousin —'),L('pruitt','Your cousin\'s not our problem, Tariq.'),
  L('web','Two cops shaking down a shopkeeper at three in the morning, with a murder scene a hundred yards away. They\'re not worried about anyone seeing.',{pass:5})],next:'rk.hub'};
N['rk.hub']={opts:[
  C('apex',10,'"Get out. Don\'t come back. Ever."','rk.scare','rk.fail',{id:'rk_apex'}),
  O('Kneel: "You will never come back here."','rk.kneel',{ab:'kneel'}),
  O('Crown of Fog: they never knew this shop existed.','rk.fog',{ab:'fog'}),
  C('gutter',9,'"I\'ll pay it. Today and every Wednesday."','rk.pay','rk.fail',{id:'rk_gut',if:S=>(S.cash||0)>=60}),
  O('Feed on Dale in the walk-in. Let Pruitt watch.','rk.feed',{blood:1}),
  O('Film it and send it to Miller.','rk.film',{if:S=>S.dos.miller}),
  O('Leave Tariq to it.','rk.leave')]};
N['rk.scare']={lines:[T('You let them see a little. Just the eyes. Dale\'s coffee goes on the floor.'),L('dale','...We\'re going. We\'re going.',{do:(S,G)=>{S.flags.racketDone='scare';G.task('s_tariq','done');G.rel('tariq',2);G.heat(1);G.xp(30,'Wednesday');}})],next:'rk.end'};
N['rk.kneel']={lines:[T('Your voice goes into them like a key into a lock. They put the money back in the till. They say sorry to Tariq. They leave and walk in step all the way to the corner.',{do:(S,G)=>{S.flags.racketDone='kneel';G.task('s_tariq','done');G.rel('tariq',2);G.xp(30,'Wednesday');}})],next:'rk.end'};
N['rk.fog']={lines:[T('Two blank faces. Dale looks at the coffee in his hand as if it were a fish. They wander out, confused, and turn the wrong way up Ferrier Lane.',{do:(S,G)=>{S.flags.racketDone='fog';G.task('s_tariq','done');G.rel('tariq',2);G.xp(30,'Wednesday');}})],next:'rk.end'};
N['rk.pay']={lines:[T('You count it out on the counter. Dale grins and pockets it.'),L('dale','Pleasure doing business. See you next week, friend.',{do:(S,G)=>{G.cash(-60,'Protection');S.flags.racketDone='pay';G.task('s_tariq','done');G.rel('tariq',1);G.offer('capitalism');}}),L('tariq','You should not have done that. But thank you. Thank you.')],next:'rk.end'};
N['rk.feed']={lines:[T('You walk Dale into the walk-in fridge with a hand on his shoulder, friendly, like a colleague. Pruitt follows, because cops follow. You drink. Pruitt watches through the glass with his mouth open.',{fx:['flash','sfx:drink'],do:(S,G)=>{G.feed(3,'choleric','Officer Dale',{kind:'mortal'});S.flags.racketDone='feed';G.task('s_tariq','done');G.heat(2);G.rel('tariq',1);G.comp(-1,'In front of a witness');}}),
  L('pruitt','...I didn\'t see anything. I didn\'t see anything. I didn\'t see anything.'),L('pedigree','You broke the Masquerade in front of a policeman. He\'ll tell someone. Eventually. They always do.')],next:'rk.end'};
N['rk.film']={lines:[T('Burner phone, low, by the magazine rack. Dale\'s face. Pruitt\'s face. The money. The till. Send.',{do:(S,G)=>{S.flags.racketDone='film';G.task('s_tariq','done');G.rel('miller',1);G.rel('tariq',2);G.xp(30,'Wednesday');}}),
  T('Four minutes later both their radios go off at once. They look at each other. They leave very fast.')],next:'rk.end'};
N['rk.fail']={lines:[L('dale','Who the hell are you? Move along.'),T('Pruitt\'s hand drifts to his belt. Not to the gun. To the flashlight.')],next:'rk.hub'};
N['rk.leave']={lines:[L('tariq','...It\'s okay. It\'s okay. You have bigger things. I can see it.',{do:(S,G)=>{S.flags.racketDone='left';G.task('s_tariq','done');G.rel('tariq',-1);}})],end:true};
N['rk.end']={lines:[L('tariq','Coffee. On the house. Forever. You don\'t drink it, I know. Forever anyway.',{if:S=>S.flags.racketDone!=='left'})],cs:async(G,S)=>{G.dlgHide();G.removeActor('dale');G.removeActor('pruitt');},end:true};

/* =====================================================================
   Night Three around the district
   ===================================================================== */
// Mrs. Okafor: the promise
H.use.okafor=(function(prev){return async(S,G)=>{if(S.night>=3&&(S.flags.daniFound||S.flags.ledgerDone)&&S.flags.met404&&!S.flags.daniTold)return G.talk('dn.0');return prev?prev(S,G):false;};})(H.use.okafor);
N['dn.0']={lines:[L('okafor','You came back. People don\'t come back.')],opts:[
  O('Tell her the truth. All of it.','dn.truth'),O('Give her Dani\'s name card. Say nothing.','dn.card',{if:(S,G)=>G.has('danicard')}),O('"Nothing yet. I\'m still looking."','dn.lie')]};
N['dn.truth']={lines:[T('You sit on the arm of the chair and tell her: the clinic, the basement, the cots, the back door of the butcher\'s. You leave out the word *vampire*. You don\'t need it.'),
  L('okafor','...Thank you. I knew. I knew a long time ago. It\'s a different thing to be told.',{do:(S,G)=>{S.flags.daniTold='truth';G.keep('dani');G.comp(1,'You told her');G.xp(30,'Dani');}}),L('okafor','Make them stop. Whoever they are. Make them stop.')],end:true};
N['dn.card']={lines:[T('She looks at the heart in biro for a long time.'),L('okafor','I drew that. When she was nine. She had her tonsils out at St. Jude\'s and I drew it on her name card so the nurses would know she was loved.',{do:(S,G)=>{G.take('danicard');S.flags.daniTold='card';G.keep('dani');G.comp(1,'For Dani');G.xp(30,'Dani');}})],end:true};
N['dn.lie']={lines:[L('okafor','...Of course.',{do:S=>S.flags.daniLie=1})],end:true};

// The cistern: reachable from Platform 0 from Night Three
NL.ROOMS.switchyard.inter.push({id:'grate',label:'Iron grate',at:[8.6,0.1,5.8],box:[8.1,0,5.4,9.1,0.2,6.2],stand:[8.6,5.0],face:[8.6,5.8],if:S=>S.night>=3});
H.use.grate=async(S,G)=>G.talk('gr.0');
N['gr.0']={lines:[T('A rusted iron grate in the platform floor, older than the tracks. Below it, a ladder, and black water, and candlelight.'),L('tenant','The old Vellum. They paved the river over in 1911 and it went on lying there underneath, being still. Soot\'s people keep candles burning on it for the drowned.',{if:S=>!S.seen['gr.0']})],
  opts:[O('Climb down.','gr.down'),O('Leave it.',null,{end:true,leave:true})]};
N['gr.down']={cs:async(G,S)=>{G.dlgHide();await G.enterRoom('cistern',{x:9.0,z:1.0,ry:-2.6});},end:true};
H.use.cwater=async(S,G)=>{S.flags.mirror_cistern=1;return G.talk('cw2.0');};
N['cw2.0']={lines:[T('Black water, perfectly still, reflecting a thousand candles. It hasn\'t moved since 1911. Things that fall in here stay exactly where they land.'),
  T(S=>NL.CLANS[S.clan]&&NL.CLANS[S.clan].ghost?'No reflection. A thousand candles and a space between them shaped like you.':'Your reflection, upside down among the candles, looking up at you as if it knows something.')],
  opts:[O('Reach into the water where something glints.','cw2.reach',{if:S=>!S.flags.frag_water&&S.flags.frag_chart}),O('Leave the water be.',null,{end:true,leave:true})]};
N['cw2.reach']={lines:[T('Cold to the elbow. Your fingers find a lanyard, and on it a plastic card: ST. JUDE\'S NIGHT CLINIC · ORDERLY. The photo is gone to white. The name is still there.'),
  L('nostalgia','You threw it in here. Monday morning, before Soot took the key. You thought: *if I don\'t have a name, nobody can find me*. You were right.'),
  T('CASEY MORROW.',{fx:['flash'],do:(S,G)=>{S.flags.frag_water=1;S.flags.knowName=1;S.name='Casey Morrow';G.task('x_name','done');G.xp(80,'The 18th Voice');G.comp(3,'Your name');G.give('badge');G.toast('level','A new voice joins the chorus: your own.','The 18th Voice');}}),
  L('you','"...Casey. I\'m Casey."'),L('tenant','Casey. Hm. I suppose that will do.')],end:true};
NL.ITEMS.badge={n:'Orderly\'s badge',slot:'pocket',mods:{nostalgia:1,pulse:1},d:'ST. JUDE\'S NIGHT CLINIC · ORDERLY · CASEY MORROW. The photograph has washed away.',sp:'Your name.'};
H.use.dais=async(S,G)=>G.say([T('A sluice gate from 1911, its wheel welded shut, made into an altar: a brass socket at the top, empty, exactly the size and shape of a bottle the length of your forearm.'),
  L('sundial','That\'s where it goes. That\'s where it was always going to go.',{if:(S,G)=>G.has('vessel')}),
  L('pedigree','On Friday, the Tribunal convenes on the platform above. Whatever is set in this socket shines up through every grate in Platform 0.',{pass:6})]);

// Gideon: a passport for Leo; Pemberton's car
const gidB=H.use.gideon;
H.use.gideon=async(S,G)=>{if(S.flags.passportAsk&&!S.flags.passportMade&&!S.flags.passportOffer){S.flags.passportOffer=1;return G.talk('gp.0');}return gidB?gidB(S,G):false;};
N['gp.0']={lines:[L('gideon','A passport for the curly one? I can do that. A hundred and fifty. Or a favour, and my favours have teeth.')],opts:[
  O('Pay $150.','gp.pay',{if:S=>(S.cash||0)>=150}),O('"A favour, then."','gp.fav'),O('"Later."',null,{end:true,leave:true,do:S=>S.flags.passportOffer=0})]};
N['gp.pay']={lines:[T('He takes a photo of Leo off your burner and is back in twenty minutes with a little maroon book still warm from the laminator.',{do:(S,G)=>{G.cash(-150,'A passport');G.give('passport');S.flags.passportMade=1;G.tick(20);}})],end:true};
N['gp.fav']={lines:[L('gideon','On Friday, when the Court and the Syndicate and whoever else start dividing the Ward, you remember who gave you a coffin when you had nothing. That\'s the favour.'),T('Twenty minutes. A little maroon book.',{do:(S,G)=>{G.give('passport');S.flags.passportMade=1;S.flags.gideonFavour=1;G.tick(20);}})],end:true};
NL.ITEMS.passport=NL.ITEMS.passport||{n:'Forged passport',slot:'pocket',d:'LEON PRUETTE. Maroon, warm from the laminator.',sp:'For Leo.'};
})();
