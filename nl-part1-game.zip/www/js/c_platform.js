'use strict';
/* THE NEW LORD — "Before One": Platform 0 filling up for the Tribunal, and everyone who is anyone in the Marrow Ward waiting to see you burn, or not */
(function(){const S_=NL.Script;
S_.place({id:'pf',name:'Platform 0, Filling Up',block:'D',sub:'The Tribunal is at one. They\'re already arriving. Go down early and see who came.',if:'night:5&time>=150&time<230&flag:mapOK&!flag:pfDone',node:'pf.0',min:6});
})();
NL.Script.add(String.raw`
# pf.0
> Platform 0, an hour before. The velvet hangings are up. The chalk circle has been drawn by someone with a ruler. Along the tracks, in clusters, the Ward is arriving: the Gilded Court in black, the Syndicate in leather, Wraiths in the shadows under the arches, clanless Kindred in their least-ripped jeans, standing well apart from everyone.
> Nobody is talking to anybody. Everybody is watching the stairs. When you come down them, the whole platform goes quiet, and then, very carefully, pretends it didn't.
{do flag:pfDone=1}
@next pf.hub

# pf.hub
> An hour. Less. Time for a few words.
* Lord Ashby, at the edge of the Gilded benches, with his good sword.  -> pf.ashby {once} {if !flag:ashbyDead&!flag:ashbyGone}
* Local 0, by the east tunnel, with a thermos.  -> pf.union {once} {if flag:side_union|rel:dutch>=1}
* A small woman in grey pearls in the front row, writing in a notebook.  -> pf.ott {once} {if !flag:ottilieExposed&!flag:ottConfessed}
* Gregory, the Magistrate's chauffeur, standing by the chair, very still.  -> pf.greg {once} {if flag:petitionDone}
* A man in a plain black mask at the top of the stairs. He isn't coming down.  -> pf.oldp {once} {if flag:mqOldPrince|mem:oldkin.lyon}
* Gaston, behind Séverine's chair, holding her shawl.  -> pf.gaston {once} {if alive:sev&!flag:gastonFree}
* Coral, in a hoodie, at the very back, holding a paper cup.  -> pf.coral {once} {if flag:coralFree}
* Stand in the chalk circle, alone, before anyone asks you to.  -> pf.circle {once}
* Go back up. Wait for one o'clock somewhere else.  -> pf.out

# pf.out
> You go back up the stairs. Behind you, the platform breathes out.
@end

# pf.ashby
@gate flag:ashbyStands ? pf.ash1 : pf.ash2

# pf.ash1
ashby: There you are. I'm sober. Disgracefully. I've had nothing since Wednesday. My hands are shaking. Look. Like a curate's.
ashby: When I stand up, I'm going to look at Ottilie. I've decided. Even if she's not guilty, I'm going to look at her. She's been writing me down in that book since 1931.
{do rel:ashby+1}
@next pf.hub

# pf.ash2
ashby: The diablerist. Here early. Keen. I like that.
ashby: I'm not going to say anything tonight, you understand. I never do. I sit in the second row and drink and watch people burn. It's the only Court function I'm any good at.
* "Stand up for me, Edmund. Once."  -> pf.ash3 {if rel:ashby>=2}
* "Enjoy the show."  -> pf.hub

# pf.ash3
ashby: Stand. Me. In the... oh, God. Oh, you're asking. You're actually asking.
? velvet 11 "You said sorry to Coral. You said sorry to a Wraith. Say one true thing in public. Just one."  -> pf.ash4 | pf.ash5 {id pf_ash} {mod like:ashby}

# pf.ash4
ashby: One true thing. In public. All right. All right. God help me. I'll stand up.
{do flag:ashbyStands=1; rel:ashby+1}
@next pf.hub

# pf.ash5
ashby: No. No, I'm sorry. I'd fall over. Literally. My knees are made of gin.
@next pf.hub

# pf.union
dutch: Brother, sister, whatever. Here we are. Sixty-three of us. Biggest turnout since 1987. Somebody brought a banner. I told them not to bring the banner. They brought the banner.
> At the back of the clanless: a bedsheet painted in house paint. LOCAL 0. WE ARE ALSO THE WARD.
* "It's a good banner."  -> pf.u1
* "Put the banner away. Don't give the Court a reason."  -> pf.u2

# pf.u1
dutch: It IS a good banner. Teo did the lettering. He's got a very steady hand for a dead teenager.
{do rel:dutch+1}
@next pf.hub

# pf.u2
dutch: ...Yeah. Yeah, you're right. Fold it up, guys. We'll unfurl it on Saturday. If.
{do rel:dutch+0}
@next pf.hub

# pf.ott
> Lady Ottilie Brand doesn't look up. Her pen is moving very fast and saying nothing.
ottilie: The neonate. Arrived 12:12. Early. Unaccompanied. Unafraid, or pretending.
* "Ottilie. Last chance. Go to the Magistrate before the circle."  -> pf.ott1 {if flag:knowOttilie}
* "What are you writing?"  -> pf.ott2

# pf.ott1
> The pen stops.
ottilie: Tom said... Tom said that when the lamps come on, I should be in the front row. He said the front row would be safe. He said they'd be aimed behind me.
web(7): The front row isn't safe. Nowhere on this platform is safe if the lamps fire. He told her the front row so she'd be where he could see her burn.
* "Tom lied, Ottilie. The front row is closest to the grates."  -> pf.ott3 {do lean:candour+1}
* Say nothing. Let her sit there.  -> pf.ott4 {do lean:mercy-1}

# pf.ott3
> She looks down. At her feet. At the iron grate set into the platform six inches from her shoes.
> She stands up very slowly. She closes her notebook. She walks across the platform to where Gregory stands beside the empty chair, and says something to him in a voice too low to hear, and holds out the notebook.
> Gregory takes it. He doesn't open it. He nods once, as if he'd been expecting this since 1902.
{do flag:ottConfessed=1; flag:ottilieExposed=1; xp:40:The front row}
@next pf.hub

# pf.ott4
> She goes back to writing. Her hand is shaking now. The handwriting is getting worse.
@next pf.hub

# pf.ott2
ottilie: Everything. I always write everything. Somebody has to keep the books.
@next pf.hub

# pf.greg
> Gregory stands beside the Magistrate's chair, a plain wooden chair on a dais, with his hands behind his back.
ghoulchauffeur: Good evening. His Lordship is in the car. He likes to arrive at exactly one. Not a minute before. He says early is a kind of lying.
@gate flag:magVault ? pf.greg1 : pf.greg2

# pf.greg1
ghoulchauffeur: I went down to the vault on Thursday, as instructed. I counted thirty-one. I took photographs. His Lordship has them in his pocket.
ghoulchauffeur: He asked me to tell you, if I saw you: "Thank you for the warning. It changes nothing about the law. It changes a great deal about the chair."
{do flag:gregConfirmed=1}
@next pf.hub

# pf.greg2
ghoulchauffeur: His Lordship asked me to make sure the chair was level. It is level. I've checked it four times.
@next pf.hub

# pf.oldp
> At the very top of the stairs, half in the street, half in the dark: a man in a plain black mask, in an old grey coat, sitting on the top step as if it were a bus shelter. He doesn't come down. He raises one hand.
oldkin: I said I'd watch from across the river. I lied. I wanted to be closer.
oldkin: Remember what I told you. Keep somebody alive who knew you before. That's all that matters, tonight or any night.
* "I will."  -> pf.oldp1
* "Come down. Sit with me."  -> pf.oldp2

# pf.oldp1
oldkin: Good. Go. I'll be here.
{do comp+1}
@next pf.hub

# pf.oldp2
oldkin: Down there? With all of them? Oh, no. No. I was a Prince once. If they saw my face they'd remember, and then I'd have to be something again.
oldkin: I'll stay on the stairs. It's the best seat. Nobody ever looks at the stairs.
@next pf.hub

# pf.gaston
gaston: Good evening. My lady is in the crypt. She'll come down at five to one. She always arrives last except for the Magistrate. It's a question of rank.
@gate flag:gastonWait ? pf.ga1 : pf.ga2

# pf.ga1
gaston: You said Saturday. If you're... if you're there on Saturday. I've packed a bag. It's under my bed. I've packed it four times.
* "Saturday, Gaston. I promise."  -> pf.ga3

# pf.ga3
gaston: Saturday. Ohio. I'll be sixty-three by Christmas. Properly. I'll be able to hold the baby.
{do rel:gaston+1}
@next pf.hub

# pf.ga2
gaston: Is there anything my lady should know? Anything you'd like me to pass on?
* "Tell her I'm not afraid."  -> pf.ga4
* "Nothing."  -> pf.hub

# pf.ga4
gaston: I'll tell her. She won't believe it. Nobody's ever not afraid of her.
@next pf.hub

# pf.coral
> Coral, in a hoodie and jeans, very small at the back of the platform among the clanless, with a paper cup of something steaming that she's not drinking.
coral: I know. I know. I shouldn't be here. I quit. I'm a free woman. I've got an interview on Monday at a dental practice.
coral: I just wanted to see. I wanted to see someone stand up to them. I've never seen it. Not once, in three years upstairs.
* "Stay at the back. If it goes bad, run."  -> pf.cor1
* "Stand next to Dutch. They'll keep you safe."  -> pf.cor2 {if flag:side_union}

# pf.cor1
coral: Run. Yeah. I'm good at running in sneakers. I've had a lot of practice in heels.
{do rel:coral+1}
@next pf.hub

# pf.cor2
coral: Next to the... the union guys? With the banner?
dutch: (from across the platform) Plenty of room, love. We've got a thermos.
> She goes. Somebody gives her a screwdriver to hold. She holds it like a candle.
{do rel:coral+1; rel:dutch+1}
@next pf.hub

# pf.circle
> You walk into the chalk circle. Nobody has asked you to. Nobody stops you. You stand in the middle of it, on the platform where your trial will be in an hour, and you look at the three hundred faces looking back at you.
> They don't know what to do. You can see them not knowing. A defendant who arrives early and stands in the circle before anyone tells them to, as if it were theirs.
tenant: (very quietly) I never did that. In eighty years of Tribunals I always came in last and left first. Look at them. Look at their faces. They've never seen it before.
> After a minute, you step out again. A long sigh goes along the tracks, like wind.
{do flag:pfCircle=1; lean:pride+1; comp+1}
@next pf.hub
`,'c_platform');
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const st0=ENC.tribunal.start;
ENC.tribunal.start=function(S,G){const r=st0.call(this,S,G);if(S.flags.pfCircle)r.prog+=1;if(S.flags.ottConfessed)r.threat=Math.max(0,r.threat-1);return r;};
const mv=ENC.tribunal.moves;ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
  if(S.flags.ottConfessed&&!S.flags.ottTold)M.push({t:'"Magistrate. Lady Ottilie gave your chauffeur her notebook before we began. Ask him."',once:'tb_ottbook',ok:(st,S)=>{st.prog+=3;S.flags.ottTold=1;S.flags.ottilieExposed=1;return [T('Gregory steps forward and hands the Magistrate a small grey notebook. The Magistrate opens it. He reads one page. Then another. His face does not change at all, which is how you know.'),L('magistrate','"T.H. Switchyard, eleven. Doctor and subject." In the Court\'s own hand.'),L('magistrate','Lady Ottilie. You will remain in your seat. You will not move from it until I say.')];}});
  return M;};})();
