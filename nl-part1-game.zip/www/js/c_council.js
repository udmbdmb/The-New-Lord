'use strict';
/* THE NEW LORD — "The Roof": on the last night, everyone you trust, on the roof of the Rookery, and you decide where each of them stands when the lamps come on */
(function(){const S_=NL.Script;
NL.TASKS.s_roof={n:'The Roof',xp:60,cat:'side'};
S_.place({id:'roof5',name:'The Rookery Roof',block:'C',sub:'Everyone you trust. One last time before one o\'clock.',if:'night:5&time<200&flag:mapOK&!flag:roofDone',node:'rf.0',min:10});
})();
NL.Script.add(String.raw`
# rf.0
> The roof of the Rookery. Tar paper, satellite dishes, Halloran's pigeon loft, a line of washing somebody forgot. The rain has stopped. Across the river the city glows orange, and under it, three streets away, Ferrier Lane is dark except for the floodlight at the crossing, sweeping, sweeping.
> They came. You didn't think they'd come. You sent word and they came.
{do task:s_roof; flag:roofDone=1}
@next rf.who

# rf.who
> Leo, in a parka over his pyjamas, holding a flask of tea. {if alive:leo&!flag:leoGoneTown&!flag:leoThrall}
> Leo, standing very still at your shoulder, watching you the way a dog watches its owner. He came because you wanted him to. He would always come. {if alive:leo&flag:leoThrall}
> Tiny, filling the doorway to the stairs, and behind him, Marcus, in a white vest under a borrowed coat. {if flag:tinyFriday&!flag:tinyGone}
> Tiny, filling the doorway to the stairs, arms folded. {if !flag:tinyFriday&!flag:tinyGone&!flag:tinyBetrayed&rel:tiny>=2}
> Valko, crouched on the parapet like a gargoyle that's come down for a look. {if flag:valkoAlly&!flag:valkoDead}
> Detective Miller, in her parka, with her hands in her pockets and her gun under them. {if alive:miller&rel:miller>=2}
> Tariq, who has closed the Lucky Mart for the first time in eleven years. He's brought a carrier bag of root beer. {if alive:tariq&rel:tariq>=2}
> Pemberton, in his good coat, holding an umbrella over nobody. {if alive:pemberton&!flag:pembertonGone}
> Mrs. Okafor, with her two cups. {if !flag:okaforDead&rel:okafor>=2}
> And Margo, sitting on an upturned crate with her handbag on her knees, because someone has to sit down. {if !flag:margoDead&rel:margo>=1}
@next rf.open

# rf.open
tenant: Look at them. Look at them, child. In forty years I never once had a roof like this. I had a car and a man who drove it.
* "Thank you for coming."  -> rf.thank
* "I need to tell you what happens at one o'clock."  -> rf.plan
* "You shouldn't be here. Any of you."  -> rf.shouldnt

# rf.thank
leo: Shut up. Course we came. {if alive:leo&!flag:leoGoneTown&!flag:leoThrall}
tiny: Didn't have anything on. {if flag:tinyFriday|rel:tiny>=2}
miller: I'm not here. I want that on the record. I'm at home watching a box set. {if alive:miller&rel:miller>=2}
@next rf.plan

# rf.shouldnt
margo: Well, we are. So you might as well use us. {if !flag:margoDead&rel:margo>=1}
tariq: You don't get to decide that. You're not our Sheriff yet. {if alive:tariq&rel:tariq>=2}
valko: Hounds go where they want. {if flag:valkoAlly&!flag:valkoDead}
@next rf.plan

# rf.plan
> You tell them. The Tribunal at one. Three hundred Kindred on Platform 0. The quartz lamps in the vault under the grates. The vans on Ferrier Lane. Harrow.
> When you finish, nobody says anything. Somebody's radio, three floors down, is playing a song about Galway.
leo: Right. Okay. So what do we do? {if alive:leo&!flag:leoGoneTown}
> They're all looking at you. Every one of them. Waiting for the first thing their Sheriff says.
* Give everyone a job. One by one.  -> rf.assign
* "Nothing. Go home. Lock the doors. That's the job."  -> rf.home {do lean:mercy+1}

# rf.home
> They argue. You don't let them. One by one, they go down the stairs.
> Valko goes last, because Hounds always do. He stops at the door.
valko: You know they won't, right. Go home. Not all of them. {if flag:valkoAlly&!flag:valkoDead}
{do flag:councilHome=1; task:s_roof=done; xp:30:The Roof}
@end

# rf.assign
> There are four places a person can be at one o'clock tonight. On Platform 0, in the chalk circle, beside you. On Ferrier Lane, in the dark, near the vans. On the street, knocking on doors, getting the living out of the Ward before the gas-leak story becomes true. Or home.
@next rf.a_leo

// --- LEO ---
# rf.a_leo
@gate alive:leo&!flag:leoGoneTown ? rf.l0 : rf.a_tiny

# rf.l0
leo: Me first. Go on. I can take it.
* "The street. Knock on doors. Get them out. You know everyone."  -> rf.lstreet
* "The vans. Watch them. Tell me if anything moves."  -> rf.lvans
* "The platform. With me."  -> rf.lplat {if flag:leoThrall|rel:leo>=4}
* "Home. Your mom's there. Stay with her."  -> rf.lhome {if flag:rosaStays}
* "Home."  -> rf.lhome {if !flag:rosaStays}

# rf.lstreet
leo: Knock on doors. At midnight. In a parka. Telling people there's a gas leak.
leo: That's... yeah. That's actually perfect. Nobody ever argues with a man in a parka. They think I'm from the city.
{do flag:job_leo=street}
@next rf.a_tiny

# rf.lvans
leo: Watch the... the feds. With guns. In vans. Me.
leo: Okay. Okay. I've got a phone with forty percent battery and a flask. What could go wrong.
pulse(5): His heart has gone very fast. He'll do it. He'll do it because you asked.
{do flag:job_leo=vans}
@next rf.a_tiny

# rf.lplat
leo: The platform. With three hundred vampires. In the chalk. Okay.
leo: I'll stand at the back. I'll stand really, really at the back. I'll be the only person on that platform with a pulse who isn't on a menu.
{do flag:job_leo=platform}
@next rf.a_tiny

# rf.lhome
leo: Home. I... okay. Okay. You're the boss.
leo: I'll be on the roof though. Up here. I'll watch. I won't do anything. I'll just watch.
{do flag:job_leo=home}
@next rf.a_tiny

// --- TINY ---
# rf.a_tiny
@gate flag:tinyFriday|rel:tiny>=2 ? rf.t0 : rf.a_valko

# rf.t0
@gate flag:tinyBetrayed|flag:tinyGone ? rf.a_valko : rf.t1

# rf.t1
tiny: What do you want, boss?
> He's never called you boss before.
* "The platform. The Court won't touch me with you on the stairs."  -> rf.tplat
* "Ferrier Lane. If a van moves, put something heavy in front of it."  -> rf.tvans
* "Get Marcus and the club staff out of the building."  -> rf.tstreet
* "Go home, Tiny. You've done eleven years."  -> rf.thome

# rf.tplat
tiny: The stairs. Right. Nobody comes down while you're talking. Nobody goes up unless you say.
tiny: Nine years I've been standing at the top of those stairs. Might as well stand at the bottom for once.
{do flag:job_tiny=platform}
@next rf.a_valko

# rf.tvans
tiny: Something heavy. I know a dumpster on Kerr Street that's got a fridge in it. And I know a lad with a tow truck.
marcus: I'll help. I'm good at heavy. {if flag:marcusSafe|flag:marcusGhoul}
{do flag:job_tiny=vans}
@next rf.a_valko

# rf.tstreet
tiny: Staff out. The bar lot, the cloakroom girls, the DJ. Right. I'll tell them there's a gas leak. They'll believe it. The club smells like a gas leak most nights.
{do flag:job_tiny=street}
@next rf.a_valko

# rf.thome
tiny: Home. I don't have a home. I've got an apartment with a couch in it.
tiny: ...Fine. I'll be on the sofa. If you need me, ring. I'll come in my socks.
{do flag:job_tiny=home}
@next rf.a_valko

// --- VALKO ---
# rf.a_valko
@gate flag:valkoAlly&!flag:valkoDead ? rf.v0 : rf.a_miller

# rf.v0
valko: Hounds hunt. Point me.
* "Platform 0. At my left hand. Like you said."  -> rf.vplat
* "Ferrier Lane. The vans. Find the man with his thumb on the switch."  -> rf.vvans
* "The roofs. Watch the whole Ward. Howl if anything comes."  -> rf.vroof

# rf.vplat
valko: Left hand. Yes.
> He stands up on the parapet. He's grinning.
valko: Rask always stood at the right. I'll stand at the left. So there's room.
{do flag:job_valko=platform}
@next rf.a_miller

# rf.vvans
valko: The thumb. I'll smell him. Menthol and peppermint. I'll sit under his van all night like a dog under a table.
? sundial 9 "Go at 12:50. Not before. The floodlight sweeps every forty seconds."  -> rf.vvansok | rf.vvansno {id rf_vsun}

# rf.vvansok
valko: Twelve-fifty. Forty seconds. Yes. I'll count.
{do flag:job_valko=vans; flag:valkoTimed=1}
@next rf.a_miller

# rf.vvansno
valko: I'll go when it feels right. Hounds don't use watches.
{do flag:job_valko=vans}
@next rf.a_miller

# rf.vroof
valko: The roofs. Above everything. Yes. I'll howl. You'll know.
{do flag:job_valko=roof}
@next rf.a_miller

// --- MILLER ---
# rf.a_miller
@gate alive:miller&rel:miller>=2 ? rf.m0 : rf.a_tariq

# rf.m0
miller: I'm not taking orders from you. I want that clear.
miller: ...But tell me where you'd put me, and I'll think about it.
* "Ferrier Lane. With a warrant, if you can get one. Arrest Harrow on the street."  -> rf.mvans
* "The street. You're police. People will leave if you tell them to."  -> rf.mstreet
* "Nowhere near it. If this goes wrong, someone has to be left to tell it."  -> rf.mhome

# rf.mvans
@gate flag:millerRayJar|flag:haveRayJar|has:lanternfile ? rf.mvans2 : rf.mvans1

# rf.mvans1
miller: A warrant. For a federal agent. On no evidence. At midnight.
miller: I'll get my lieutenant out of bed. He'll laugh at me. Then I'll go and stand on Ferrier Lane anyway. In a parka. With my badge out.
{do flag:job_miller=vans}
@next rf.a_tariq

# rf.mvans2
miller: A warrant. With Ray's last words on a jam jar and the Tuesday files. Judge Okonkwo owes me from 2017. She'll sign. She'll sign in her dressing gown.
miller: Precinct 3, not Precinct 9. Two cars. Real sirens. I'll walk up to his van and knock on the window.
{do flag:job_miller=vans; flag:millerWarrant=1}
@next rf.a_tariq

# rf.mstreet
miller: Clear the Ward. Door to door. Gas leak. My badge and Leo's parka.
miller: ...That's the most useful thing anyone's asked me to do all week. Fine.
{do flag:job_miller=street}
@next rf.a_tariq

# rf.mhome
miller: Someone to tell it. Like Ray.
> She looks at you for a long time.
miller: No. No. I've been the one left to tell it once already. I'm not doing it twice.
miller: I'll be on Ferrier Lane. You can't stop me.
{do flag:job_miller=vans}
@next rf.a_tariq

// --- TARIQ ---
# rf.a_tariq
@gate alive:tariq&rel:tariq>=2 ? rf.q0 : rf.a_pem

# rf.q0
tariq: I sell cigarettes. I'm not a soldier. But I know every family on Halloran Street, and every family on Kerr, and most of Ferrier.
* "Then get them out. Every one."  -> rf.qstreet
* "Open the Lucky Mart. Lights on, kettle on. Somewhere for people to go."  -> rf.qshop
* "Go home to your wife, Tariq."  -> rf.qhome

# rf.qstreet
tariq: Every one. Mrs. Shah with her mother. The Polish boys in 4C. Kenny. I'll do it with my wife. She's louder than me.
{do flag:job_tariq=street}
@next rf.a_pem

# rf.qshop
tariq: A light on. Yes. The Lucky Mart, at two in the morning, with the kettle on. Like a lighthouse. If anyone's scared, they'll know where to go.
tariq: I'll put the coffee on for you, too. Like always.
{do flag:job_tariq=shop}
@next rf.a_pem

# rf.qhome
tariq: My wife will kill me if I go home. She's packed sandwiches.
{do flag:job_tariq=street}
@next rf.a_pem

// --- PEMBERTON ---
# rf.a_pem
@gate alive:pemberton&!flag:pembertonGone ? rf.p0 : rf.a_okafor

# rf.p0
pemberton: I shall go wherever I am of use. I always have.
* "On the platform. Behind me. Holding the Sheriff's coat."  -> rf.pplat
* "The car. Engine running at the top of the Switchyard stairs."  -> rf.pcar
* "Home, Pemberton. Watch the sunrise for me."  -> rf.phome

# rf.pplat
pemberton: Behind you. With the coat.
> Something passes over his face that he doesn't let stay there.
pemberton: I stood behind the Sheriff at forty-one Tribunals. I shall stand behind you at this one. It will be my privilege.
{do flag:job_pem=platform}
@next rf.a_okafor

# rf.pcar
pemberton: Engine running. The Bentley holds five, or seven if one isn't fussy. I shall be at the top of the stairs at twelve fifty-five.
{do flag:job_pem=car}
@next rf.a_okafor

# rf.phome
pemberton: ...The sunrise.
pemberton: I haven't watched a sunrise since 1983. One doesn't, in service. One draws the curtains.
pemberton: Very well. If you insist. I shall go up on the roof of the Heights and watch it, and think of you, and the Sheriff, and draw no curtains at all.
{do flag:job_pem=home}
@next rf.a_okafor

// --- OKAFOR ---
# rf.a_okafor
@gate !flag:okaforDead&rel:okafor>=2 ? rf.o0 : rf.a_margo

# rf.o0
okafor: I'm not useful. I'm a dinner lady. I'm sixty-one.
okafor: But I've been knocking on doors about Dani since August. Nobody's better at knocking on doors than me.
* "Then knock. Get the building out."  -> rf.ostreet
* "Stay in 404. Keep the light on. Someone has to be home."  -> rf.ohome

# rf.ostreet
okafor: The Rookery. Every apartment. I'll start at the top. I know which ones have babies.
{do flag:job_okafor=street}
@next rf.a_margo

# rf.ohome
okafor: The light on. Yes. Dani always said I left the light on too much. Waste of electric.
{do flag:job_okafor=home}
@next rf.a_margo

// --- MARGO ---
# rf.a_margo
@gate !flag:margoDead&rel:margo>=1 ? rf.g0 : rf.close

# rf.g0
margo: Don't you look at me like that. I'm coming to the Tribunal. I've been to every Tribunal on Platform 0 since 1979. I'm not missing the interesting one.
* "Then sit in the front row and save me a seat."  -> rf.gplat
* "Margo. Please. Not tonight."  -> rf.ghome

# rf.gplat
margo: Front row. I'll bring a cushion. Those benches are murder.
{do flag:job_margo=platform}
@next rf.close

# rf.ghome
margo: ...Oh, all right. All right. Since you said please. You always say please. It's very disarming.
{do flag:job_margo=home}
@next rf.close

// --- the close ---
# rf.close
> It's done. Everyone has somewhere to be. They stand on the roof for a moment longer, not quite ready.
@gate flag:job_leo=vans&!flag:harrowWalked ? rf.worry : rf.close2

# rf.worry
web(6): Leo. At the vans. With forty percent battery. Harrow knows his name. Harrow's been to his gigs.
* Change Leo's job. "Leo. Actually. The street."  -> rf.worryfix
* Leave it. He wanted to help.  -> rf.close2

# rf.worryfix
leo: Oh thank God. I mean. Fine. Whatever. Street. Yeah.
{do flag:job_leo=street}
@next rf.close2

# rf.close2
tenant: Say something to them. A Sheriff always says something. It doesn't have to be good. It just has to be said.
* "Whatever happens: thank you."  -> rf.sthank
* "If I don't come back up those stairs, don't come looking."  -> rf.sdont
* "By dawn, this is our Ward. Not theirs. Ours."  -> rf.sours {do lean:pride+1}
* Say nothing. Hug the nearest one.  -> rf.shug

# rf.sthank
> Nobody says anything back. Mrs. Okafor pours tea into her second cup and holds it out to you, and you take it, and hold it, and don't drink it, and that's enough.
{do comp+3:The Roof; task:s_roof=done; xp:60:The Roof}
@end

# rf.sdont
leo: Yeah, we're definitely coming looking. {if alive:leo&!flag:leoGoneTown}
tiny: Course we are. {if flag:tinyFriday|rel:tiny>=2}
{do comp+2:The Roof; task:s_roof=done; xp:60:The Roof}
@end

# rf.sours
> It sounds ridiculous, said out loud, on a roof, to a doorman and a dinner lady and a comedian in pyjamas. It sounds ridiculous and nobody laughs.
valko: Ours. {if flag:valkoAlly&!flag:valkoDead}
tariq: Ours. {if alive:tariq&rel:tariq>=2}
{do comp+3:The Roof; task:s_roof=done; xp:60:The Roof; flag:roofOurs=1}
@end

# rf.shug
> It's Leo. Of course it's Leo. He makes a noise like a balloon going down and hugs you back so hard you'd have bruises if you could bruise. {if alive:leo&!flag:leoGoneTown}
> It's Tiny. He's very surprised. He pats you on the back like he's burping a baby. {if !alive:leo|flag:leoGoneTown}
{do comp+3:The Roof; task:s_roof=done; xp:60:The Roof}
@end
`,'c_council');

/* consequences of the roof */
(function(){const {L,T,ENC}=NL.DSL;const N=NL.DSL.N;
const job=(S,who)=>S.flags['job_'+who]||null;
/* on the platform: allies at your side in the Tribunal */
if(ENC.tribunal){const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
  if(job(S,'pem')==='platform')M.push({t:'Hold out your hand without looking. Pemberton puts the Sheriff\'s gloves in it.',once:'tb_pemglove',ok:st=>{st.prog+=1;return [T('The oldest Elders on the platform recognize the gloves. And the man who carries them. Forty-one Tribunals.'),L('magistrate','...Pemberton. You serve this one now?'),L('pemberton','I serve the Marrow Ward, Magistrate. I always have. This is who it chose.')];}});
  if(job(S,'valko')==='platform')M.push({t:'"Valko. Tell them what Harrow did on the pier."',once:'tb_valko',ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [L('valko','Harrow\'s men shot my pack-father on Pier Nine in 1977. Rask. They used his body to make the first lamp. I know because I smelled him on it.'),T('Three hundred Kindred go very quiet. Hounds don\'t lie in Tribunals. They don\'t know how.')];}});
  if(job(S,'tiny')==='platform')M.push({t:'Nod at the stairs. Tiny folds his arms.',once:'tb_tiny',ok:st=>{st.threat=Math.max(0,st.threat-1);return [T('A Syndicate man who\'d been edging toward the exit looks at the doorman on the stairs, and decides to stay and listen after all.')];}});
  if(job(S,'margo')==='platform')M.push({t:'"Margo. You\'ve been to every Tribunal since 1979. Have you ever seen this one\'s like?"',once:'tb_margo',ok:st=>{st.prog+=1;return [L('margo','Never. Not once. Forty-one years. I\'ve never seen a defendant say please to the Magistrate.'),T('A ripple of laughter along the tracks. Not cruel. Surprised.')];}});
  if(job(S,'leo')==='platform')M.push({t:'Point to the back of the platform. "There\'s a mortal here who knows exactly what I am, and came anyway."',once:'tb_leo',ok:(st,S)=>{st.prog+=1;st.threat+=1;S.flags.leoSeenAtTribunal=1;return [T('Three hundred heads turn. At the back, Leo Pruitt, in a parka over pyjamas, raises a hand and gives a little wave.'),L('leo','Hiya.'),L('magistrate','...A living man. At a Tribunal. Unescorted. Who invited the snack?'),L('leo','I\'m with the defendant. I\'m the opening act.')];}});
  return M;};}
/* at the lamps: the people on Ferrier Lane */
document.addEventListener('DOMContentLoaded',()=>{const n=N['lamps.0'];if(!n||!n.lines)return;
  n.lines.push(T('From the street, a sound like a fridge being dropped off a tow truck in front of a van. Then a doorman\'s voice: "Oops."',{if:S=>job(S,'tiny')==='vans'}));
  n.lines.push(T('And a howl, long and grey, from the roofs above Ferrier Lane, and a man shouting "Danny, what is THAT," and a van door slamming.',{if:S=>job(S,'valko')==='vans'||job(S,'valko')==='roof'}));
  n.lines.push(T('Sirens, real ones, from the wrong precinct. A woman\'s voice, flat and furious, through a car\'s PA: "Thomas Harrow. Step away from the vehicle."',{if:S=>job(S,'miller')==='vans'&&S.flags.millerWarrant&&!S.flags.harrowWalked&&!S.flags.harrowDeadEarly,do:S=>{S.flags.millerAtVan=1;}}));
});
/* afterwards */
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];if(!f.roofDone||f.councilHome)return o;
  const street=['leo','tiny','miller','tariq','okafor'].filter(k=>job(S,k)==='street').length;
  if(street>=2)o.push(['Halloran Street','Was empty by half past twelve. A man in a parka, a detective, a shopkeeper and his wife, a dinner lady: three hundred and eleven people out of the Ward on a Friday night for a gas leak that never quite happened. Nobody on the street was hurt. Nobody on the street ever knew why.']);
  else if(street===1)o.push(['Halloran Street','Half-emptied by one in the morning. One person, door to door, in the rain. It was enough for some of them.']);
  if(job(S,'tariq')==='shop')o.push(['The Lucky Mart','Stayed open all Friday night with every light on. Forty people came in out of the dark and drank Tariq\'s coffee and didn\'t know why they were scared. At five, he poured one more, and left it on the counter.']);
  if(job(S,'leo')==='vans'&&!f.harrowWalked&&!f.harrowDead)o.push(['Leo Pruitt','Was picked up on Ferrier Lane at 12:48 by two men in black who were very polite about it. Released at dawn. Harrow bought him a coffee. Leo did twenty minutes about it the next Tuesday. It was the first set that ever killed.']);
  if(job(S,'pem')==='home'&&!f.pemDead)o.push(['Pemberton (at dawn)','Stood on the roof of the Heights and watched the sun come up over the river for the first time since 1983, with his hat in his hands, and drew no curtains at all.']);
  if(job(S,'valko')==='roof')o.push(['The roofs of the Ward','Valko howled at 12:59, once, from the top of St. Agatha\'s. Every dog in the Marrow Ward answered.']);
  if(f.millerAtVan)o.push(['Ferrier Lane, 1 AM','Detective Ines Miller knocked on the window of a grey van with a warrant signed by a judge in a dressing gown. Two cars from Precinct 3. Real sirens. Ray would have loved it.']);
  return o;});
})();
