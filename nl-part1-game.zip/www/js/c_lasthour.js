'use strict';
/* THE NEW LORD — "The Last Hour": the hour before dawn, wherever you've chosen to sleep, and whoever is still awake there with you */
(function(){
const pick=(S,hav)=>{const n=S.night,f=S.flags;const k=hav||'freezer';
  const alive=id=>!f[id+'Dead'];
  if(k==='leo'&&alive('leo')&&!f.leoGoneTown)return 'lh.leo'+n;
  if(k==='pawn'&&alive('gideon'))return 'lh.gid'+n;
  if(k==='shrine'&&alive('soot'))return 'lh.soot'+n;
  if(k==='crypt')return alive('sev')&&!f.sevEnemy?'lh.sev'+n:'lh.crypt';
  if(k==='rookery')return f.valkoAlly&&!f.valkoDead&&n>=3?'lh.valko'+n:'lh.roof'+n;
  return 'lh.alone'+n;};
document.addEventListener('DOMContentLoaded',()=>{const C=NL.Camp;if(!C||!C.sleep)return;const orig=C.sleep;
  C.sleep=async function(hav){const S=NL.G.S;
    if(!C.sleeping&&S.night>=2&&S.night<=4&&!S.flags['lh_'+S.night]&&!(hav&&hav===S.flags.havenLost&&hav!=='car')){
      const id=pick(S,hav);S.flags['lh_'+S.night]=1;
      if(NL.STORY.nodes[id]){try{await NL.G.talk(id);}catch(e){console.error('lasthour',e);}}}
    return orig.apply(this,arguments);};});
})();
NL.Script.add(String.raw`
// =====================================================================
// LEO'S COUCH
// =====================================================================
# lh.leo2
> Leo's couch is four feet long and you are not. He's put a blanket over the window and another over you. He's sitting on the floor with his back against the couch, eating dry cereal out of the box, very quietly, the way you'd eat near a sleeping dog.
leo: I can't sleep. Obviously. There's a vampire on my couch.
leo: Can I ask you something? Do you dream? Like, when you go... off. Is it like sleep, or is it like being switched off?
* "It's like being switched off. And then I dream anyway."  -> lh.leo2a
* "I don't know yet. Ask me tomorrow."  -> lh.leo2b
* "Go to bed, Leo."  -> lh.leo2c

# lh.leo2a
leo: That's horrible. That's so horrible. That's the most horrible thing I've ever heard and I once saw a man eat a whole jar of pickled eggs for a bet.
leo: What do you dream about?
* "The freezer."  -> lh.leo2d
* "Someone reading to me. I don't know who."  -> lh.leo2e

# lh.leo2d
leo: Oh. Right. Yeah. Sorry. Stupid question.
> He reaches up without looking and pats the blanket over your foot, twice, like you'd pat a dog.
leo: If you dream about the freezer, just remember you're on my couch. It smells of Doritos. Freezers don't smell of Doritos.
{do comp+1; rel:leo+1}
@end

# lh.leo2e
leo: Reading. That's nice. That's a nice one.
leo: I could read to you. If you want. I've got... I've got *The Hobbit* and a Haynes manual for a 2004 Ford Focus. The Hobbit's better. The Focus has a twist ending.
* "Read the Hobbit."  -> lh.leo2f
* "Read the Focus."  -> lh.leo2g

# lh.leo2f
> He reads the Hobbit. He does the voices. His Gollum is very bad. He's still reading when the window starts to go grey round the edges of the blanket, and you go under to "In a hole in the ground there lived..."
{do comp+2; rel:leo+1}
@end

# lh.leo2g
> He reads the Haynes manual for a 2004 Ford Focus with tremendous gravity, like a man reading a psalm. *Remove the four retaining bolts.* You go under laughing, which is the strangest thing you've done all week.
{do comp+2; rel:leo+1}
@end

# lh.leo2b
leo: Tomorrow. Okay. I'll write it down. Question one for tomorrow: does the vampire dream. I'll make a list.
{do rel:leo+1}
@end

# lh.leo2c
leo: Yeah. Yeah, okay. Sorry. Goodnight. Good day. Whatever it is.
> He goes. A minute later he comes back and turns the little lamp off. A minute after that he comes back and turns it on again, in case you're scared of the dark. Then he goes for good.
@end

# lh.leo3
> Leo's couch again. He's not on the floor tonight. He's sitting at the little table by the window with his notebook, writing, crossing out, writing.
leo: Don't mind me. I've got a gig. I mean, I haven't. But I will. I'm writing about you. Not *about* you. About a guy who has a friend who's... it's fiction. It's highly fictional.
leo: Can I try a bit on you? You don't have to laugh. You won't laugh. Nobody does.
* "Go on."  -> lh.leo3a
* "Not tonight. I'm tired."  -> lh.leo3b

# lh.leo3a
leo: Okay. Okay. Ahem.
leo: "So my mate's a vampire. Very polite. Doesn't drink, doesn't smoke, doesn't breathe. Comes round at two in the morning and sits on my couch and says 'sorry, sorry, sorry.' The only British vampire in America. I said, mate, you can have a bit of my neck. He said: 'Oh, I couldn't possibly, unless you're having some.'"
* Laugh. It's not that funny. Laugh anyway.  -> lh.leo3c
* Laugh. It's actually funny.  -> lh.leo3d
* "I'm not British."  -> lh.leo3e

# lh.leo3c
> You laugh. He looks at you like you've given him a kidney.
leo: You laughed. You LAUGHED. Was it a pity laugh? Don't tell me. I don't want to know. I'm keeping it.
{do rel:leo+2; comp+1}
@end

# lh.leo3d
> You laugh properly. It surprises both of you. It comes out of somewhere deep and old, maybe yours, maybe his, and it doesn't stop for a while.
leo: Oh my God. Oh my GOD. I'm doing that one on Tuesday. That's going in. That's the closer.
{do rel:leo+2; comp+2; flag:leoJokeTested=1}
@end

# lh.leo3e
leo: No, I know. It's a bit. You SOUND British though. Sometimes. When you're tired. Like, two hundred years British.
tenant: Corsican, actually. With a Mayfair finish. The boy has an ear.
{do rel:leo+1}
@end

# lh.leo3b
leo: Yeah. Course. Sorry. I'll do it quietly.
> You go under to the scratch of a biro and Leo whispering punchlines to himself, testing them, discarding them, one after another, like a man skimming stones.
{do comp+1}
@end

# lh.leo4
> The last night before the last night. Leo hasn't written anything. He's sitting on the floor again, back against the couch, holding the cactus in his lap.
leo: If it goes wrong. Tomorrow. I want you to know I'll look after the... I'll look after stuff. I don't know what stuff. Your coat. I'll keep your coat.
leo: And if it goes right, I want to be there. I want to see you be the Sheriff. I want to see you in the chair.
* "You'll be there."  -> lh.leo4a
* "Promise me you'll stay home tomorrow, Leo."  -> lh.leo4b
* Put your hand on his shoulder. Say nothing.  -> lh.leo4c

# lh.leo4a
leo: Yeah. Yeah, I will. Front row. With a sign. "THAT'S MY MATE." In glitter.
{do rel:leo+1; comp+1}
@end

# lh.leo4b
leo: Promise. Stay home. While you're... while everyone's...
leo: No. Sorry. No. I can't promise that. I'd be lying, and you'd know, and then I'd be a liar on the night before you maybe die. I'll stay home if you make me. Don't make me.
{do rel:leo+1}
@end

# lh.leo4c
> He doesn't say anything either. He leans his head back against the couch, against your hand. His heart slows down. After a while, he's asleep, sitting up, with the cactus in his lap. You go under to the sound of him breathing.
{do comp+3; rel:leo+1}
@end

// =====================================================================
// THE PAWN & COFFIN
// =====================================================================
# lh.gid2
> Box three. The lid sticks. Through the gap you can see Gideon at his counter by the light of one green banker's lamp, doing a crossword in the *Times* that someone posted him from London in 1997.
gideon: Comfortable? Box three's the softest. Velvet lining. A Sovereign had it made in 1923. He said he wanted to be buried like a cello.
gideon: I'll be here till you go under. I always stay. Absalom used to say I was like a nurse. I said a nurse gets paid.
* "Tell me about the Sovereign who wanted to be buried like a cello."  -> lh.gid2a
* "What's seven down?"  -> lh.gid2b
* "Goodnight, Gideon."  -> lh.gid2c

# lh.gid2a
gideon: Lord Fennimore Hatch. He played the cello very badly for three hundred years. He was so bad the Court paid him not to play at functions. He used the money to buy cellos. He had forty when he died.
gideon: He walked into the sun in 1961, on a Sunday, with his favorite cello, playing Elgar. Badly. The neighbors complained about the noise right up until the noise stopped.
{do comp+1}
@end

# lh.gid2b
gideon: Seven down. "Dead, but still in business." Eight letters.
* "Pawnshop."  -> lh.gid2d
* "Vampires."  -> lh.gid2e

# lh.gid2d
> He laughs. You've never heard him laugh. It's like a door opening in an old house.
gideon: Pawnshop. Ha. No. It's "Undertaker". But I'm going to write yours in.
{do rel:gideon+1; comp+1}
@end

# lh.gid2e
gideon: Eight letters, I said. Don't they teach you to count, in the freezer?
@end

# lh.gid2c
gideon: Goodnight. Mind the lid. It sticks.
@end

# lh.gid3
> Box three again. Gideon isn't doing the crossword tonight. He's sitting by your box on a folding chair with the ledger open on his knees.
gideon: I'm going to read you something. You don't have to listen. It helps me to read it out.
> He reads you a page of the ledger. Names. Dates. *Box 4, Lucien, 1974–1981, paid in full.* *Box 7, Mary-Ellen, 1983, paid in kindness.* *Box 2, unnamed, 1990, did not wake.* Forty years of the dead who slept in his shop.
* "Why do you keep it?"  -> lh.gid3a
* Listen to the end.  -> lh.gid3b

# lh.gid3a
gideon: Because nobody else does. Your kind don't keep records. You remember, or you don't. And when you don't, it's as if it never happened.
gideon: I'm seventy-four. I won't be here much longer. Somebody has to know that Mary-Ellen paid in kindness.
{do rel:gideon+1}
@end

# lh.gid3b
> He reads to the end. The last entry is in fresh ink. *Box 3. The Sheriff's child. Monday onwards. Paid in* — and a gap, where he hasn't decided what to write yet.
gideon: I'll fill it in when I know. Don't look at me like that. I'm not being sentimental. I'm being accurate.
{do rel:gideon+1; comp+2}
@end

# lh.gid4
> Box three. The last night before. Gideon has put a hot water bottle in the box with you, which is absurd, because you can't feel it, and because it'll be cold by dawn, and you hold onto it anyway.
gideon: My wife used to put one in my bed every night for forty-one years. Even in August. I've kept doing it. For the boxes. Habit.
gideon: Whatever happens tomorrow. You've been a good tenant. You never once complained about the lid.
* "Gideon. If I don't come back, write it in the ledger. Whatever you were going to write."  -> lh.gid4a
* "I'll be back. Keep the box."  -> lh.gid4b

# lh.gid4a
gideon: I'll write it now, then. In pencil. I'll ink it in Saturday if you're not back to argue.
> He writes something in the ledger. You can't see what. He closes it and puts his hand on it, flat, the way you'd put a hand on a sleeping animal.
{do rel:gideon+2; comp+2; flag:gideonWrote=1}
@end

# lh.gid4b
gideon: I'll keep the box. I always keep the box.
{do rel:gideon+1; comp+1}
@end

// =====================================================================
// MOTHER SOOT'S SHRINE
// =====================================================================
# lh.soot2
> In the shrine under the Switchyard, two hundred candles and a thousand jars. Soot has made you a nest of old coats in an alcove behind the oldest pipe. The rats are already in it, warm, rustling. They make room for you.
soot: Sleep. Sleep, sleep. The rats keep watch. The pipes sing. Mm. Do you want a song? Soot sings. Badly. Mm.
* "Sing."  -> lh.soot2a
* "Tell me a story instead."  -> lh.soot2b
* "Just the pipes."  -> lh.soot2c

# lh.soot2a
> She sings. It isn't a song. It's a sound like water in a long pipe, rising and falling, no words, with the rats squeaking in time. It should be horrible. It's the most peaceful thing you've ever heard.
{do comp+2; rel:soot+1}
@end

# lh.soot2b
soot: A story. Mm. Once there was a girl who lived in a big house with lots of windows, and she was so pretty that everyone looked at her, all the time, and she hated it. So she found a man who could make it so nobody would ever look at her again. Mm.
soot: He made her very, very ugly. And she went down into the pipes. And she was so happy. Nobody looked. Nobody ever looked again.
soot: The end. Mm. It's a happy story. Everyone thinks it's sad. It's happy.
{do comp+1; rel:soot+1; mem:soot:story}
@end

# lh.soot2c
> Just the pipes. The water goes past, an inch from your head, the whole city's water, carrying everybody's words down to the sea. You go under to the sound of a thousand people saying goodnight to each other in their kitchens.
{do comp+2}
@end

# lh.soot3
> The nest of coats. The rats. Soot is sitting at the mouth of the alcove with a jar in her lap. She's listening to it with her eyes shut.
soot: Shh. Shh. It's my favorite. Do you want to hear? Mm. Mm. It's the first one I ever kept.
* "Yes."  -> lh.soot3a
* "Whose is it?"  -> lh.soot3b

# lh.soot3a
> She holds it to your ear. Very faint, under the hiss: a woman laughing at a party, a long time ago, and glasses clinking, and a man saying "Mathilde, you're the most beautiful woman in the room."
> And the woman, still laughing, saying: "I know. Isn't it awful?"
soot: That's me. Mm. 1871. Before. I keep it so I remember I didn't like it.
{do rel:soot+2; mem:soot:mathilde; comp+1}
@end

# lh.soot3b
soot: Mine. Mine. Before. Mm. You can hear. If you like.
@next lh.soot3a

# lh.soot4
> The night before. Soot has lit every candle in the shrine. All two hundred. The jars glitter like a sky.
soot: For you. Mm. For tomorrow. So the jars know. They're all very excited. They don't get many visitors.
soot: If you go into the light tomorrow, Soot will keep you. A jar. Your voice. Mm. Say something. Something to keep.
* Say your name.  -> lh.soot4a {if name}
* Say "Thank you, Mother."  -> lh.soot4b
* Say "Don't keep me. Let me go."  -> lh.soot4c

# lh.soot4a
> You say your name into an empty jam jar. She corks it fast, like catching a moth.
soot: There. Casey Morrow. In a jar. Forever. Mm. Mm. Nobody can take it now. Not even you.
{do rel:soot+2; comp+2; flag:sootJar=name}
@end

# lh.soot4b
> She corks it fast. She holds it to her chest.
soot: Mother. Nobody's called me that and meant it since... mm. Mm. Since never. Since never.
{do rel:soot+3; comp+2; flag:sootJar=mother}
@end

# lh.soot4c
soot: Let you go. Let you go. Nobody ever asks that.
> She holds the empty jar for a long time. Then she puts it back on the shelf, with nothing in it, and doesn't cork it.
soot: All right. All right. For you. The empty one. Mm. That's yours.
{do rel:soot+1; comp+1; flag:sootJar=empty}
@end

// =====================================================================
// THE VIP CRYPT
// =====================================================================
# lh.sev2
> A guest coffin in the Gilded Court's crypt. Satin, rosewood, a brass plate with no name on it. Just as you're settling into it, the lid you haven't closed yet is held open by a gloved hand.
severine: Comfortable? It was made for a Duchess. She was very fat. You'll rattle.
severine: I don't sleep, you know. Not really. I lie in the dark and listen to the Court snore. Would you like to know a secret about every person in this crypt?
* "Yes."  -> lh.sev2a
* "No. Goodnight, my lady."  -> lh.sev2b

# lh.sev2a
severine: Lisette counts her teeth every night to be sure they're still there. Ashby talks in his sleep about a horse called Bramble. Old Hatchett in the end coffin is not asleep, he's been dead-dead since 1987, and nobody has had the heart to tell the Prince.
severine: And I cry. Every dawn. For about four minutes. Nobody knows why. Least of all me.
severine: Goodnight, darling. Don't tell.
{do rel:severine+1; mem:severine:cries}
@end

# lh.sev2b
severine: Goodnight. How refreshingly dull.
@end

# lh.sev3
> The Duchess's coffin. This time she doesn't hold the lid. She sits on the floor of the crypt beside it, in her evening dress, with her back against the rosewood, like a girl at a sleepover.
severine: I don't want to talk. Don't make me talk. I just want to sit here.
> She sits there. You lie there. Somewhere in the crypt, Lord Ashby murmurs something about Bramble.
* Say nothing.  -> lh.sev3a
* "Are you all right, Séverine?"  -> lh.sev3b

# lh.sev3a
> After a long time, very quietly, she starts to hum. A Caruso aria, the one from the gramophone. She stops when the dawn comes, about four minutes in.
{do rel:severine+1; comp+1}
@end

# lh.sev3b
severine: No. Nobody is. That's the secret. Go to sleep.
{do rel:severine+1}
@end

# lh.sev4
> The last night before. The Duchess's coffin. Séverine is not there. On the satin pillow: a single white rose, and a card in purple ink.
> *"Tomorrow, whatever I have to say in the circle, know that tonight I left you a rose. That is the only true thing I will do this week. — S."*
{do comp+1; flag:sevRose=1}
@end

# lh.crypt
> A guest coffin in the Gilded Court's crypt. Nobody comes to see you off. The Court snores. Somewhere, Lord Ashby murmurs about a horse.
@end

// =====================================================================
// THE ROOKERY ROOF
// =====================================================================
# lh.roof2
> The sniper nest on the Rookery roof: a water tank, a tarpaulin, a sleeping bag somebody left in 1994. Halloran's cats find you within minutes. Six of them. They arrange themselves on top of you like sandbags.
* Let them stay.  -> lh.roof2a
* Shoo them.  -> lh.roof2b

# lh.roof2a
> You go under with six cats on you, purring, warm, completely unbothered that you're dead. Cats don't care. Cats have never cared. It's the most restful thing in the world.
{do comp+2}
@end

# lh.roof2b
> They go. They come back. They go. They come back. Cats.
{do comp+1}
@end

# lh.roof3
> The water tank. The tarpaulin. From up here you can see the whole Marrow Ward, all the lights going out one by one, and the river, and the first grey line in the east.
tenant: Look at it. Look at it, child. I watched this city from rooftops for eighty years. Every dawn. Right up to the last minute. It was the only thing I was ever brave about.
* Watch it with him. Right up to the last minute.  -> lh.roof3a
* Get under the tarpaulin. Now.  -> lh.roof3b

# lh.roof3a
> You watch it together. The lights. The river. The grey going to pearl going to the very first edge of something you can't look at. At the last second, the very last, you roll under the tarpaulin, and your hand is smoking, and he's laughing.
tenant: There. Now you know. That's the bravest thing there is. Not fighting. Watching.
{do sync+2; comp+2; vitae-1}
@end

# lh.roof3b
tenant: Coward. Good. Stay a coward. Cowards live.
@end

# lh.roof4
> The last night before. The cats are here. Halloran is here too, in a dressing gown, with a flask, sitting on an upturned bucket.
halloran: Couldn't sleep. Never can, the night before something. You've got something tomorrow. The cats know. They've been funny all day.
halloran: Here. Cocoa. You can't drink it. Hold it. It's warm.
> You hold it. It's warm.
{do comp+2}
@end

# lh.valko3
> The sniper nest. Valko is already in it. He's turned round three times and lain down across the mouth of it, between you and the stairs.
valko: Hounds guard the den. It's not a choice. It's what we are.
valko: Sleep. Nothing comes up those stairs. Nothing.
* "Thank you, Valko."  -> lh.valko3a
* "Lie down. You need rest too."  -> lh.valko3b

# lh.valko3a
valko: Don't thank a Hound for guarding. That's like thanking water for being wet.
> But he's pleased. His ears, which are not quite human ears, have gone back.
{do rel:valko+1}
@end

# lh.valko3b
valko: Rest. Hounds rest with one eye open.
> He lies down properly. Within a minute, both eyes are shut and he's twitching, running in a dream, making small sounds like a puppy.
{do rel:valko+1; comp+1}
@end

# lh.valko4
> The last night before. Valko on the roof, howling softly at the river. When he sees you he stops, embarrassed.
valko: I was telling Rask. About tomorrow. He'd want to know.
valko: Sleep. I'll be here when you wake. Or I'll be ash. Either way, I'll be here.
{do rel:valko+1; comp+1}
@end

// =====================================================================
// THE FREEZER · alone, with him
// =====================================================================
# lh.alone2
> Kowalski's walk-in. Back where it began. The door that doesn't open from the inside, wedged with a crate. The cold doesn't bother you now. That's the worst thing about it.
tenant: Here again. You could sleep anywhere in the city and you came back here.
* "It's the only place that feels like mine."  -> lh.al2a
* "I didn't want anyone to see me."  -> lh.al2b

# lh.al2a
tenant: Yours. A meat freezer. Where I died and you were born. That's a terrible place to call your own.
tenant: ...I understand it, though. I slept in the cellar of the house where I was Embraced for twenty years. You go back. You always go back.
{do sync+1}
@end

# lh.al2b
tenant: Nobody sees you. Good. I see you. That's company of a sort.
@end

# lh.alone3
> The freezer. The crate against the door. You lie on the steel floor where an old man knelt and burned.
tenant: I'll tell you a thing, since there's nobody else to hear. The last thing I saw, on Monday, before the light. It was your face. Above me. Terrified. Hungry. Sorry.
tenant: You said sorry, child. With your mouth on my throat. You said sorry the whole time.
* "Did it help?"  -> lh.al3a
* "I don't remember."  -> lh.al3b

# lh.al3a
tenant: No. It didn't help. It was the kindest thing anyone had said to me in thirty years.
{do sync+2; comp+1}
@end

# lh.al3b
tenant: No. You wouldn't. I'll remember it for both of us. I've got the room.
{do sync+1}
@end

# lh.alone4
> The freezer, the last night before. You came back. Of course you came back.
tenant: Tomorrow, one way or another, this ends. You'll be Sheriff, or ash, or something we haven't thought of. And I'll be whatever I am inside whatever you are.
tenant: I want to say something. Before. While there's quiet.
* "Say it."  -> lh.al4a
* "Don't. Not here. Say it after."  -> lh.al4b

# lh.al4a
tenant: I was a coward for eighty years. I stood at the back of every room. I stood at the back of Agnes's funeral. I stood at the back of my own life.
tenant: You've been at the front all week. Every room. Even when you were terrified. Especially then.
tenant: Thank you. For dragging me to the front. It's very loud there. I like it more than I thought.
{do sync+3; comp+3}
@end

# lh.al4b
tenant: After. Yes. After. A good word. I'll hold you to it.
{do sync+1; flag:tenantAfter=1}
@end
`,'c_lasthour');
