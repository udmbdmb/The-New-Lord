'use strict';
/* THE NEW LORD — Night Three personal arcs, part one: Leo, Tariq, Pemberton (the Sheriff's letter), Gideon, Tiny, Mrs. Okafor, Valko, and the third dawn dream */
Object.assign(NL.ITEMS,{
  vaneletter:{n:'The Sheriff\'s Letter',type:'read',d:'Cream laid paper, sealed in black wax with a hound. "To whoever drinks me." Pemberton has carried it since Sunday.'},
  harrowcard:{n:'Federal Health Survey Card',type:'read',d:'"U.S. Department of Health · Community Blood Survey · Agent T. Harrow." A phone number. On the back, in pencil: "Leonard — call me. You may be ill."'},
  payslip:{n:'Dani\'s Pay Stub',type:'read',d:'$500.00. Payer: LANTERN RESEARCH LLC, a P.O. box in Virginia. Memo: "Volunteer honorarium · Cohort B · #3".'}
});
NL.Script.npc({id:'valko',room:'alley',at:[7.6,3.6,-2.2],pose:'crouch',label:'Valko',if:'flag:valkoAlly&night>=3&night<=4&!flag:valkoDead'});
NL.Script.add(String.raw`
// =====================================================================
// LEO · Night Three
// =====================================================================
# lx3.0 arc=leo night=3 label="\"How did the set go?\"" if=room:apt&leo:here&flag:lanternDone
@focus leo
leo: It went. It went! It WENT. Did you hear them? You were there. You saw the guy with the beer come out his nose. That was real. That was a real nose and real beer.
leo: I got a free drink. The barman said "kid, that was good." The barman has never said anything to me except "you're on after the juggler".
stagecraft(3): He's been replaying it all day. Every laugh, every beat. Performers do that. It's how they live off one good night for a year.
leo: And then. And then afterwards, a woman. A woman in a red dress with a voice like a lift going down came up and said she ran "entertainment" at Club Reliquary and would I like to do a private set. Thursday. For "the patrons downstairs". Five hundred dollars.
pedigree(6): The Reliquary doesn't book comedians. A Court hostess, recruiting. Downstairs is the crypt. Five hundred dollars and a basement full of Kindred.
web(5): Séverine wants something with your face on it in her pocket. Leo is the boy who survived the freezer.
* "Don't go. Whatever she offers."  -> lx3.no {do lean:mercy+1}
* "Go. I'll be there. Nobody touches you."  -> lx3.go {do lean:loyalty+1}
* "Go. It's good money."  -> lx3.money {do lean:mercy-1}
* "Tell me exactly what she looked like."  -> lx3.who

# lx3.who
leo: Red dress. Red lipstick. Red... everything. Black hair cut like a helmet. Pale. Really pale. Like, you pale. She had a ring with a little crown on it. She called me "sweetness". Nobody calls me sweetness. My mom calls me Leonard. Junie calls me dickhead.
pedigree(5): A Court signet. Lisette, probably, Séverine's hostess. She doesn't book acts. She books dinners.
{do flag:knowLisette=1}
@next lx3.choice

# lx3.choice
* "Don't go."  -> lx3.no {do lean:mercy+1}
* "Go. I'll be there."  -> lx3.go {do lean:loyalty+1}
* "Go. It's good money."  -> lx3.money {do lean:mercy-1}

# lx3.no
leo: Five hundred dollars. FIVE HUNDRED. Do you know how many Tuesday open mics that is? It's all of them. It's every Tuesday until I'm forty.
leo: ...She's one of you, isn't she. The red lady.
* "Yes. And she'd eat you between the first joke and the second."  -> lx3.notruth {do lean:candour+1}
* "Just trust me."  -> lx3.notrust

# lx3.notruth
leo: Between the... okay. Okay. Not great for my timing, being eaten. I'll call her and say I've got the flu. Do vampires believe in flu? Can I give one of you flu? That's a weapon. That's a GREAT weapon.
{do flag:leoGig=no; mem:leo:gigno; rel:leo+1}
@next lx3.hub

# lx3.notrust
leo: I do. That's the weird part. I trust you more than anyone I know and you're the only one who's ever bitten me. That's a bad sign for my love life.
{do flag:leoGig=no; mem:leo:gigno}
@next lx3.hub

# lx3.go
leo: You'll be there? Like, actually there? Downstairs? With the... patrons?
leo: Okay. Okay, if you're there I'll do it. I'll do the freezer bit. I'll kill. Not kill. I'll do well. I'm going to stop saying kill.
tenant: You've just promised to stand between a mortal and the Gilded Court on their own floor. That's either heroism or a very elaborate way of dying.
{do flag:leoGig=guarded; promise:leogig:Stand by Leo at his Reliquary gig on Thursday; mem:leo:giggo}
@next lx3.hub

# lx3.money
leo: Good money. Right. It's just a gig. It's just a basement. It's just a... yeah.
pulse(5): His heart sped up when you said it. He wanted you to say no. He wanted someone to say no.
{do flag:leoGig=alone; mem:leo:gigalone; rel:leo-1}
@next lx3.hub

# lx3.nolantern
@next lx3.hub

# lx3b.0 arc=leo night=3 label="Knock. Say sorry about Tuesday." if=room:apt&leo:here&!flag:lanternDone
@focus leo
> Leo opens the door, sees you, and closes it again. Then opens it.
leo: You didn't come. To the set. I looked. The whole time. I did the freezer bit and I looked at the back where the light's bad and you weren't there.
leo: That's fine. That's fine. You've got, like, vampire stuff. I get it. Vampire stuff comes first. It's fine.
pulse(5): It isn't fine.
* "I'm sorry. I should have been there."  -> lx3b.sorry {do lean:loyalty+1}
* "I was busy keeping you alive."  -> lx3b.busy
* "You don't need me in the audience."  -> lx3b.need

# lx3b.sorry
leo: Yeah. You should've. It went really well. I wanted you to see.
{do mem:leo:sorrysetmissed; break:leoset}
leo: There's another one. Not Tuesday. Thursday. A woman in a red dress came up after and said she'd pay five hundred dollars for a private set at the Reliquary.
@next lx3.who

# lx3b.busy
leo: Keeping me alive. From what? Who? You keep saying stuff like that and then not telling me anything. It's like dating someone in the CIA. I assume. I've never dated anyone in anything.
{do mem:leo:busy; break:leoset}
leo: Anyway a woman in a red dress wants me to do a gig at the Reliquary on Thursday.
@next lx3.who

# lx3b.need
leo: No. I don't need you. I don't need anybody in the audience. That's the whole point of the audience: they're strangers.
leo: I just wanted one person who wasn't.
{do mem:leo:dontneed; rel:leo-1; break:leoset}
leo: Whatever. Big news anyway. A woman in a red dress wants to book me at the Reliquary.
@next lx3.who

# lx3.hub
* "Did anyone else come to the door?"  -> lx3.card {once}
* "Leo. Do you want what I have? The blood?"  -> lx3.blood {once} {if !flag:leoGhoul&!flag:leoAskedBlood}
* "Where would you go, if you had to leave?"  -> lx3.leave {once}
* "Get some sleep."  -> lx3.bye

# lx3.card
leo: Oh. Yeah. This was under the door this morning. I nearly used it for a roach.
> A white card. US DEPARTMENT OF HEALTH · COMMUNITY BLOOD SURVEY. A phone number. On the back in pencil: *Leonard, please call. You may be ill. — T.H.*
web(5): Harrow. "You may be ill." He wants the bitten boy for his program. A fresh subject with Sheriff's blood in his wound.
* "Give it to me. Don't call."  -> lx3.cardtake {do give:harrowcard}
* "Call. Find out what he wants. Tell me after."  -> lx3.cardcall {do lean:mercy-1}

# lx3.cardtake
leo: Fine. Take it. I wasn't going to call. I don't call anyone. I text, like a civilised human being.
{do mem:leo:cardtaken}
@next lx3.hub

# lx3.cardcall
leo: Call a guy in sunglasses who left a card under my door saying I'm ill. Sure. Yeah. That's a sane thing for me to do in my life right now.
leo: ...Okay. For you. I'll call him tomorrow.
tenant: You've just used the boy as bait. I did that too, once, with a girl called Ruth. Ruth didn't come back.
{do flag:leoCallHarrow=1; mem:leo:bait}
@next lx3.hub

# lx3.blood
leo: The... what? Like, drink you? Is that a thing? I thought it was a one-way street. Like Uber.
autopsy(5): A little of your blood, regularly, and he'd heal fast, age slow, see in the dark. And he'd be bound to you. Not a slave. Worse. Devoted.
leo: What happens if I do?
* Tell him. Everything. The good and the leash.  -> lx3.bloodtruth {do lean:candour+1}
* "You'd be stronger. Safer."  -> lx3.bloodsell {do lean:candour-1}
* "Nothing. Forget I asked."  -> lx3.bloodno

# lx3.bloodtruth
> You tell him. The healing. The years. The way he'd start to need it. The way he'd start to need *you*, the way Pemberton needs the Sheriff, the way a man needs a cigarette at a funeral.
leo: So I'd be like... a fan. A really, really committed fan.
leo: No. No, thank you. I've seen what fans do. I'd rather be scared and mine.
{do flag:leoAskedBlood=1; mem:leo:refusedblood; rel:leo+1}
@next lx3.hub

# lx3.bloodsell
leo: Stronger. Safer. That sounds... I mean, the red lady, the grey suit... safer sounds amazing.
> He holds out his wrist, then laughs, embarrassed, and turns it the other way, as if he isn't sure which side you use.
* Give him your blood.  -> lx3.bloodgive {blood 1}
* "No. Not like this."  -> lx3.bloodno

# lx3.bloodgive
> You open your own wrist on your teeth and he drinks like someone taking medicine, wincing, and then not wincing, and then closing his eyes.
leo: Oh. Oh, that's... that's not what I expected. That's like Christmas. That's like being nine on Christmas.
tenant: And now he's yours, and he'll never quite be his again. Congratulations. You've made a ghoul. Pemberton will be thrilled to have a colleague.
{do flag:leoGhoul=1; flag:leoAskedBlood=1; mem:leo:ghoul; lean:mercy-1; rel:leo+2}
@next lx3.hub

# lx3.bloodno
leo: Okay. Weird question to ask a guy and then take back, but okay.
{do flag:leoAskedBlood=1}
@next lx3.hub

# lx3.leave
leo: Leave? The Ward? Bayside, I guess. Junie's. She's got a sofa bed with a bar across the middle. Or the pier. There's a comedy night on the pier on Fridays in the summer. I always said I'd do it. I'd need a different name. Leon. Leon Pruette. That's a pier name.
web(4): If it comes to it: Bayside, Junie's sofa, the pier. "Leon Pruette."
{do mem:leo:pier; flag:knowLeoPier=1}
@next lx3.hub

# lx3.bye
leo: Sleep. Ha. Yeah. You too. Sorry, I mean: you too, but in the day, in a box. Sleep in a box. Sleep well in your box.
@end

// =====================================================================
// TARIQ · Night Three · before Wednesday's collection
// =====================================================================
# tx3a.0 arc=tariq night=3 label="\"It's Wednesday, Tariq.\"" if=room:luckymart&!flag:racketDone
@focus tariq
> Tariq has counted the till four times. You can tell because there are four little piles of coins on the counter in a neat row, like a man making offerings.
tariq: It's Wednesday. I know it's Wednesday. I have known it's Wednesday since Sunday. Wednesday sits in my week like a stone in a shoe.
tariq: I have a hundred and forty. They want two hundred. My cousin was going to lend me sixty and then his car broke and now he is lending sixty to a mechanic.
* "I'll be here at three."  -> tx3a.here {do lean:loyalty+1}
* Put sixty dollars on the counter.  -> tx3a.money {if cash>=60}
* "Have you thought about not paying?"  -> tx3a.notpay
* "What happens if you don't?"  -> tx3a.ifnot

# tx3a.here
tariq: Here. At three. To do what? Stand there? Look at them? You can look at people very hard, I have seen you, the milk went off.
tariq: Okay. Okay. Be here. But remember what I said. Stop, not hurt.
{do mem:tariq:willbehere; rel:tariq+1}
@next tx3a.hub

# tx3a.money
> You count it out. He stares at it.
tariq: No. No, no, no. Then they win. Then it's you paying instead of me, and next week it's two hundred and twenty because they know there's a friend with sixty.
tariq: ...Thank you. Take it back. Really. Thank you. Take it back.
* Take it back.  -> tx3a.hub {do mem:tariq:offeredmoney; rel:tariq+1}
* Leave it anyway.  -> tx3a.leaveit

# tx3a.leaveit
tariq: You're very stubborn for a dead nurse.
> He puts the money in an envelope, writes YOURS on it, and puts the envelope in the drawer under the till.
{do cash-60; flag:tariqEnvelope=1; mem:tariq:leftmoney; rel:tariq+1}
@next tx3a.hub

# tx3a.notpay
tariq: Not pay. Yes. I've thought of it every Wednesday for two years. Then I think of the health inspector, and the fire inspector, and Mr. Dale's cousin who runs the newsagent on Halloran who will buy my lease for nothing when I'm closed.
tariq: It's not two hundred dollars. It's the shop. The shop is my father's back room. You understand?
{do mem:tariq:shop}
@next tx3a.hub

# tx3a.ifnot
tariq: The first time I said no, in 2022, someone put a brick through the window at four in the morning. At four. Exactly at four. They knew.
tariq: The second time, nothing happened. Then the inspector came and found rats. In a bag. In the back. A bag of rats.
gutter(5): A bag of rats. That's not even crime. That's theatre. Somebody enjoys it.
@next tx3a.hub

# tx3a.hub
* "Tell me about Pruitt. The sorry one."  -> tx3a.pruitt {once}
* "I'll see you later."  -> tx3a.bye

# tx3a.pruitt
tariq: Pruitt. Ken. He's maybe fifty. He has a nephew. He told me once, when Dale was in the toilet. "My sister's kid works nights too, at the butcher's." Then he heard himself and said "no relation" twice.
tariq: He takes the money with his eyes closed. Like a man taking medicine.
web(6): Pruitt's nephew works nights at the butcher's. Leo.
{do flag:knowPruittNephew=1; mem:tariq:pruitt}
@next tx3a.hub

# tx3a.bye
tariq: Three o'clock. Come or don't come. I'm going to pretend you said you'd come, so I can sleep. That's a lie, I can't sleep. So I can stand here.
@end

# tx3b.0 arc=tariq night=3 label="\"Are you all right?\"" if=room:luckymart&flag:racketDone&!flag:racketDone=left
@focus tariq
@gate flag:racketDone=feed ? tx3b.feed : tx3b.calm

# tx3b.calm
tariq: All right? I'm... I don't know. They left. They left and nobody broke anything and nobody shouted and nobody is in the walk-in fridge.
tariq: Twenty-two months. Every Wednesday. Twenty-two months and it took you four minutes.
tariq: You're going to tell me there will be a price. In the stories there is always a price.
* "No price."  -> tx3b.noprice {do lean:mercy+1}
* "Keep a light on for me. That's the price."  -> tx3b.light {do lean:loyalty+1}
* "I'll think of something."  -> tx3b.think

# tx3b.noprice
tariq: No price. My grandmother would say that's when you should be most afraid.
tariq: My grandmother also said onions cure deafness. Thank you.
{do mem:tariq:noprice; rel:tariq+1}
@end

# tx3b.light
tariq: A light. I can do a light. I always have the light on. Now it's on for someone.
> He reaches under the counter and puts a little brass lamp next to the till, the kind with a green glass shade, and switches it on. It's very ugly. It's the most hopeful thing on Ferrier Lane.
{do flag:tariqLamp=1; mem:tariq:lamp; rel:tariq+1}
@end

# tx3b.think
tariq: Okay. Think. I will be terrified quietly until you decide.
{do mem:tariq:think}
@end

# tx3b.feed
> Tariq won't come out from behind the counter. He's holding the little silver hand from beside the till in his fist so tightly it's cutting him.
tariq: I saw. Through the glass of the walk-in. I saw his face. He was smiling. Why was he smiling? Why do they smile?
tariq: I said stop, not hurt. I said it two times. I said it like a person says a thing that matters.
* "He's alive. I didn't kill him."  -> tx3b.alive {if !flag:dalekilled}
* "He took your money for two years."  -> tx3b.deserved {do lean:mercy-1}
* "I'm sorry, Tariq."  -> tx3b.sorry {do lean:mercy+1}

# tx3b.alive
tariq: Alive. Alive like a fish on a slab is alive. He walked out of here like a sleepwalker. Pruitt took him to the car by the elbow like an old man.
tariq: Please don't come in for a while. Please. I'll leave the coffee on the step.
{do mem:tariq:afraid; rel:tariq-2; break:tariqnohurt}
@end

# tx3b.deserved
tariq: Deserved. Yes. Everybody deserves everything, in this city. That's what makes it so tired.
{do mem:tariq:deserved; rel:tariq-2; break:tariqnohurt}
@end

# tx3b.sorry
tariq: ...I know. I can see you are. That's the worst part. It would be easier if you were a monster all the way through.
{do mem:tariq:sorry; rel:tariq-1; break:tariqnohurt}
@end

// =====================================================================
// PEMBERTON · Night Three · the Sheriff's letter
// =====================================================================
# px3.0 arc=pemberton night=3 label="\"You've got something on your mind.\"" if=flag:mapOK&!flag:pemDead
@focus pemberton
> Pemberton is standing by the car with his gloves off, which you have never seen. His hands are older than his face. Or they were. You can't decide.
pemberton: ‹Sir›. I have something for you. I should have given it to you on Monday. I have been... deciding.
> From the inside pocket of his coat, an envelope. Cream laid paper. Black wax, a hound's head pressed into it. On the front, in a beautiful copperplate hand: *To whoever drinks me.*
pemberton: The Sheriff wrote it on Sunday night, in the car, outside St. Jude's. He told me that if anything happened, I was to give it to "whoever turns up wearing my coat". I said, "‹Sir›, nobody would dare." He said, "Pemberton, everybody would dare. That's rather the point."
tenant: ...I'd forgotten. God. I'd forgotten I wrote that.
* Break the seal and read it.  -> px3.read
* "Did you read it?"  -> px3.didyou
* "Why did you wait?"  -> px3.wait

# px3.didyou
pemberton: ‹Sir›. I've carried his post for forty-one years. I have never read a word that wasn't addressed to me.
pemberton: Though I confess I held this one up to the light, on Tuesday, when you were sleeping. I couldn't read it. His ink was always too good.
{do mem:pemberton:honest}
@next px3.read

# px3.wait
pemberton: Because if I gave it to you, it would mean he was really gone. And because I didn't know yet if you were the sort of person who deserved to read it.
@gate like:pemberton>=2 ? px3.waitgood : px3.waitbad

# px3.waitgood
pemberton: I've decided you are. Mostly. On balance. With reservations.
@next px3.read

# px3.waitbad
pemberton: I still don't know. But I find I can't carry it any longer. It's heavy, for paper.
@next px3.read

# px3.read
> The wax breaks with a sound like a small bone. Two sheets, close-written, no corrections. Vane didn't make corrections.
> *To whoever drinks me,*
> *If you are reading this, then one of two things has happened: either Elena's treatment has failed, or it has succeeded in a way neither of us intended. In either case I am inside you now, and you are confused, and I owe you an explanation I never gave anyone while I was alive.*
> *For eighty years I have kept the Marrow Ward. I have done it badly and expensively and well. I have taken ten percent of everything. I have put down three uprisings and one Prince's nephew. I am tired. I am so tired I could weep, and I have forgotten how.*
> *Dr. Rostova says she can make me able to stand in the sun. Not mortal. Not quite. A thing that walks at noon. She has been testing it on mortals in the basement, which I discovered three weeks ago and should have stopped, and did not, because I wanted it to work. That is my crime, and it is the only one I am ashamed of.*
@next px3.read2

# px3.read2
> *There is a federal program behind her. They call it LANTERN. They want what she is making. They want soldiers who don't burn. I believe they intend to use the first success to hunt the rest of us. I meant to bring this before the Prince on Friday. If I am dead, then someone moved first.*
> *To whoever you are: the seven in the basement were not volunteers in any sense a decent person would recognize. There was an eighth. I took them out of the program on the ninth of October because they asked me to, very politely, and because they reminded me of someone. I gave them a job instead. A witness, for Friday. If you are reading this and you have a gap in your memory the shape of the last year, I am sorry. I am more sorry than this letter can hold.*
> *Keep the Ward. Or don't. But keep Pemberton. He's the only one of us who ever meant it.*
> *A. V.*
nostalgia(4): The eighth. A gap the shape of a year. A job instead. It's you. It's you, it's you, it's you.
pemberton: ‹Sir›? You've gone a very strange color. Stranger. Than usual.
{do give:vaneletter; flag:readVaneLetter=1; flag:knowVaneWitness=1; sync+4:His handwriting; mem:tenant:letter}
* "He hired me. Before. I worked for him."  -> px3.hired
* "He knew about the seven. He let it happen."  -> px3.knew
* Give the letter to Pemberton. "Read the last line."  -> px3.lastline

# px3.hired
pemberton: ...The young person in the back seat. On Sunday night. He picked you up outside St. Jude's at nine. You sat in the back and didn't say a word all the way to the Courthouse and back. He called you "my witness". I never saw your face properly. You wore a hood.
pemberton: Good Lord. It was *you*.
{do mem:pemberton:witness; flag:pemKnowsWitness=1}
@next px3.after

# px3.knew
pemberton: He knew. Yes. Three weeks. He drove past that clinic every night for three weeks and sat in the car, and I thought he was ill.
pemberton: He was. In a manner of speaking.
tenant: I wanted it to work, child. I wanted to see one more summer. Is that so much?
* "Yes. Seven people's worth."  -> px3.toomuch {do lean:candour+1; sync-2:Judgment}
* "No. I'd have wanted it too."  -> px3.understand {do lean:mercy+1; sync+2:Understanding}

# px3.toomuch
tenant: ...Yes. Yes, it is.
@next px3.after

# px3.understand
tenant: Don't forgive me. Not yet. You'll want to save that for something worse.
@next px3.after

# px3.lastline
> He reads it once. Then again. Then he folds the letter very carefully along its old creases and gives it back, and takes out a handkerchief, and does not use it, and puts it away.
pemberton: "He's the only one of us who ever meant it."
pemberton: Forty-one years. He never said. Not once.
{do mem:pemberton:lastline; rel:pemberton+2; lean:mercy+1}
@next px3.after

# px3.after
pemberton: What will you do with it, ‹sir›? The letter is evidence. Of a sort. It names the doctor and the program. A Magistrate might find it interesting.
web(5): A dead Sheriff's own confession that LANTERN exists and Rostova worked for it. In his hand. Under his seal. Friday could turn on this.
* "Keep it safe. Friday."  -> px3.keep
* "Burn it. Some things should stay buried."  -> px3.burn {do lean:candour-1}

# px3.keep
pemberton: Very good, ‹sir›. I'll keep the car warm and the letter dry.
{do flag:keepVaneLetter=1}
@end

# px3.burn
pemberton: ‹Sir›. Are you quite sure?
* Burn it.  -> px3.burned
* "No. You're right. Keep it."  -> px3.keep

# px3.burned
> The lighter. The cream paper curls. The copperplate goes brown, then black, then gone. Pemberton watches every second of it.
tenant: That's my last will and testament, child. I suppose I ought to be grateful you didn't read it aloud at a party.
{do take:vaneletter; flag:vaneLetterBurned=1; rel:pemberton-1; sync-3:Ashes}
@end

// =====================================================================
// GIDEON · Night Three · the empty box
// =====================================================================
# gx3.0 arc=gideon night=3 label="\"Gideon. Who was the girl in the fur coat?\"" if=room:pawn&mem:gideon.history
@focus gideon
gideon: Winter. That's what she called herself. Winter. Not her name. She said names were for people who could be found.
gideon: She was a Wraith, you know the sort. Corpse-faced. She wore a fur coat and a porcelain mask to cover what she'd become. The coat was mink. The mask had a little painted mouth, smiling. She paid in Krugerrands from 1971 to 1982.
gideon: Every winter, the first frost, the bell over the door. And then, '83, no bell.
* "Did you look for her?"  -> gx3.look
* "Why does it still matter?"  -> gx3.why
* "I could find out what happened."  -> gx3.offer

# gx3.look
gideon: I'm a pawnbroker. I don't look for anything. Things come to me.
gideon: I asked Soot, once. 1990. She said "that will cost you". I asked how much. She said "your watch". My father's watch. I said no.
gideon: I've regretted it every Tuesday since.
{do mem:gideon:soot}
@next gx3.offer

# gx3.why
gideon: Because she was the first. Because she said thank you when she left, every spring. Because she once told me the name of every star you can see from the Rookery roof and I was forty and nobody had told me anything for free in twenty years.
gideon: And because a box sitting empty for forty years is the only thing in this shop I can't put a price on. That annoys me.
@next gx3.offer

# gx3.offer
gideon: You'd do that? Find her? Or what became of her?
gideon: I'll pay. Not in money. You don't want money. In something better. Something I've been keeping.
{do task:s_winter; note:s_winter|Gideon's first customer, a Wraith called Winter in a mink coat and a smiling porcelain mask, stopped coming in 1983. Find out what happened to her. Mother Soot might know, for a price.; mem:gideon:winter}
@end

# gx3b.0 arc=gideon night=3 label="\"You're hiding Margo.\"" if=room:pawn&task:s_margo=active
@focus gideon
gideon: I'm not hiding anyone. I'm *renting* a box to a lady who pays in pork chops. There's a difference. One of them is a crime and the other is business.
gideon: She came in Tuesday with a carrier bag and a face like the end of the world. Fifty years she's sold me sausages. I wasn't going to say no.
gideon: But I'll tell you this, and you can tell whoever you like: if anybody comes through that door for her without an appointment, they'll find I'm not as old as I look.
> He taps the counter. Under it, something long and heavy shifts.
gutter(4): A shotgun under the counter of a pawnshop on Reliquary Row. Loaded with something. Silver? Rock salt? Gideon's been in this business since 1971.
{do mem:gideon:margo; flag:gideonGuardsMargo=1}
@end

// =====================================================================
// TINY · Night Three · what he remembers
// =====================================================================
# kx3.0 arc=tiny night=3 label="\"Tiny. Sunday night. Who came downstairs?\"" if=room:reliquary&flag:vipOK
@focus tiny
tiny: Sunday. Sunday's quiet. Regulars. Coral's lot from the dancefloor. Lord Ashby with a girl from the university who didn't come up again till Monday lunchtime.
tiny: And at half eleven, a man. Grey suit. Sunglasses. Didn't give a name, didn't need one. Lisette came up and walked him down herself. The Lady doesn't do that. The Lady sends Lisette for people who matter.
tiny: He was down there an hour. When he came up he was carrying a folder and he smelled like her perfume. Jasmine and old church.
web(6): Harrow, in Séverine's crypt, the night before the ambush. With a folder.
{do flag:tinySawHarrow=1; flag:knowSevHarrow=1; mem:tiny:harrow}
* "Would you say that in front of a Magistrate?"  -> kx3.testify
* "Thank you. Forget you told me."  -> kx3.forget {do lean:loyalty+1}
* "Why tell me?"  -> kx3.why

# kx3.testify
tiny: A Magistrate. Of your lot. In a room full of your lot. Saying the Lady had a fed in her crypt.
tiny: I'd be dead by Saturday.
@gate like:tiny>=2|done:s_tiny ? kx3.testyes : kx3.testno

# kx3.testyes
> He's quiet for a long time. He clicks someone in without looking at them.
tiny: ...But you got me the kit. Or you would've. You're the only one who ever asked how I was.
tiny: If you need it, Friday, I'll stand up. Once. Then I'm leaving this door and I'm never coming back to it. You understand? That's the price. My door.
{do flag:tinyWitness=1; mem:tiny:witness; rel:tiny+1}
@end

# kx3.testno
tiny: No. Sorry. I like you. Not that much.
@end

# kx3.forget
tiny: Already forgotten. I have a terrible memory. Ask anyone.
> He has the best memory on Reliquary Row. Everybody knows it.
@end

# kx3.why
tiny: Because the Lady doesn't keep broken things, and I'm getting broken. When she finds out, I'm out the door with nothing. I want somebody to owe me something before that.
tiny: You, specifically. You seem like you pay your debts. Don't prove me wrong.
{do mem:tiny:debt}
@end

// =====================================================================
// MRS. OKAFOR · Night Three
// =====================================================================
# ox3.0 arc=okafor night=3 label="\"Mrs. Okafor. Did you find anything?\"" if=room:apt&flag:met404&!flag:daniTold
@focus okafor
okafor: I went through her things again. Her bank papers. I never did that. It felt like reading her diary.
> She hands you a pay stub, folded twice. $500.00. LANTERN RESEARCH LLC. A post office box in Virginia. *Volunteer honorarium · Cohort B · #3.*
okafor: Number three. She was a number. They paid her five hundred dollars and called her number three.
web(5): A federal shell company's name on a pay stub, paid to a missing girl. Miller would kill for this. Possibly literally.
{do give:payslip; mem:okafor:payslip}
* "I'll take this to Detective Miller."  -> ox3.miller {do lean:candour+1}
* "Keep it hidden. People are killing over this."  -> ox3.hide
* "I know what happened to her."  -> ox3.know {if flag:knowSeven|seen:tr.0}

# ox3.miller
okafor: The detective. Yes. She'll know what to do. She always has a little notebook.
{do flag:payslipForMiller=1}
@end

# ox3.hide
okafor: Hidden. Where? In this flat, the walls listen. In the chimney, something scratches.
okafor: You keep it. You're the only safe thing I know, and you're not safe.
@end

# ox3.know
okafor: Then tell me. Not now. When you're sure. Tell me when you're sure, and tell me all of it, and don't make it kind.
@end

// =====================================================================
// VALKO · Night Three · the Hound, sworn or not
// =====================================================================
# vx3.0 arc=valko night=3,4 label="Crouch beside the Hound." if=room:alley&flag:valkoAlly
@focus valko
> Valko is crouched at the end of the lane in the rain, the way a dog sits at the end of a garden, watching the gate. He doesn't turn when you come. He knew you were coming four streets ago.
valko: You smell like him. It's hard. Every time the wind changes I think he's come back.
valko: Then you open your mouth.
* "Tell me about him. The real him."  -> vx3.him
* "What do you want, Valko? Not for him. For you."  -> vx3.want
* "Hunt with me."  -> vx3.hunt
* "Séverine set you on me."  -> vx3.sev

# vx3.him
valko: He found me in a dog-pit in 1951. I was fighting for a bookmaker. I'd been fighting for eleven years. He bought me for twelve pounds and a favour. Then he let me go. Opened the cage and walked off.
valko: I followed him for three days. He said, "What do you want?" I said, "Whatever you want." He said, "That's the saddest thing I've ever heard," and gave me a job.
valko: Seventy years. He never once called me a dog. Everyone else did. He called me Mr. Valko. Even when he was beating me. He beat me when I deserved it. I always deserved it.
pulse(4): He's telling you this the way people talk about a parent who's just died: proud and furious and lost.
* "He didn't beat you because you deserved it."  -> vx3.notdeserve {do lean:mercy+1}
* "Sounds like he was good to you."  -> vx3.good
* "I'm not going to beat you, Mr. Valko."  -> vx3.mister {do lean:mercy+1}

# vx3.notdeserve
valko: You don't know. You weren't there.
valko: ...I've had seventy years to think about it. I've had seventy years to decide that I deserved it, so that it would make sense.
{do mem:valko:notdeserve; rel:valko+1}
@next vx3.hub

# vx3.good
valko: Good. He was the best thing that ever happened to me. That's not the same as good. You'll learn.
{do mem:valko:good}
@next vx3.hub

# vx3.mister
> He looks at you for the first time. Properly. His eyes are amber and very old and very wet.
valko: "Mr. Valko."
valko: Don't. Don't do that. Don't use his voice for that.
nostalgia(5): You didn't use his voice. Or you did. You can't tell any more.
{do mem:valko:mister; rel:valko+1; sync+2:Mr. Valko}
@next vx3.hub

# vx3.want
> A long silence. The rain.
valko: Nobody has asked me that since 1951.
valko: I want to know who killed him. Not you. The ones before you. The ones who pointed the light. I want to find them and I want to make it last.
valko: And then I want to lie down somewhere quiet and not get up for a while.
* "I'll give you the name. When I have it."  -> vx3.name {do promise:valkoname:Give Valko the name of whoever pointed the lance}
* "Vengeance won't bring him back."  -> vx3.vengeance
* "Then let's find them together."  -> vx3.together {do lean:loyalty+1}

# vx3.name
valko: Swear it. Not like a mortal. On his blood. On the blood in you.
valko: ...Good.
{do mem:valko:sworn; rel:valko+1}
@next vx3.hub

# vx3.vengeance
valko: Nothing brings anything back. That's not why you do it. You do it so the world has the right shape again.
@next vx3.hub

# vx3.together
valko: Together. A thief and a dog. He'd laugh. He'd laugh until he cried.
{do mem:valko:together; rel:valko+1}
@next vx3.hub

# vx3.hunt
valko: Hunt. You want to hunt. With me. Now.
> He grins, for the first time, and there are far too many teeth in it.
? frenzy 9 "Race him across the rooftops."  -> vx3.huntwin | vx3.huntlose {id vx3_hunt}
* "Teach me how you track."  -> vx3.track

# vx3.huntwin
> Over the bins, up the fire escape, across the Rookery roof, the gap between the gasometers, down a drainpipe into Halloran Street. You land a half-second before him and he laughs out loud, a real bark, and a dog in a yard somewhere answers.
valko: Again. Again tomorrow. God, again.
{do mem:valko:raced; rel:valko+2; tick:20; lean:restraint-1}
@next vx3.hub

# vx3.huntlose
> You lose him on the second roof. When you find him he's sitting on the parapet of the Rookery, not out of breath, because he doesn't breathe, but making a show of it for you.
valko: You run like him. Like a man late for a train. It's all right. He was always late too.
{do mem:valko:raced; rel:valko+1; tick:20}
@next vx3.hub

# vx3.track
valko: Blood has a trail. Fear has a trail. Lies have a trail, but it's very faint, like burnt sugar. Close your eyes. Breathe in, even though you don't need to. What do you smell?
osmosis: Rain. Bins. A cat. Diesel. Under that: a woman's perfume, jasmine and old church. Two hours old. Going toward the Reliquary.
valko: Good. That's Lisette. Séverine's. She's been walking your street every night since Monday. She's counting your doors.
{do mem:valko:tracked; flag:knowLisetteWatching=1}
@next vx3.hub

# vx3.sev
valko: She told me where you'd be. She didn't tell me what you were. If she had, I might not have come.
valko: She knew I'd want to tear you apart, and she knew you might win. She'd have been pleased either way. That's the Lady. She keeps her hands clean by using everyone else's.
{do mem:valko:sev}
@next vx3.hub

# vx3.hub
* "Stay close, Valko."  -> vx3.bye

# vx3.bye
valko: Close. Yes. I'm good at close.
@end

// =====================================================================
// DREAM 3 — Wednesday's dawn. After the Seizure.
// =====================================================================
# dr3.0 dream=3
@gate flag:seizure=surrender ? dr3.surr : dr3.next1

# dr3.next1
@gate flag:seizure=harmonize ? dr3.harm : dr3.supp

# dr3.supp
> The study is dim. The lamp is out. Vane is sitting in the chair by the cold fireplace instead of at his desk, a blanket over his knees like an invalid, very small.
tenant: You won. In the cistern, in the flashback, when it came to who would hold the hands. You held them.
tenant: I'm not angry. I want you to know that. I'm... diminished. Like a radio in another room.
* "Are you in pain?"  -> dr3.suppain {do lean:mercy+1}
* "Good."  -> dr3.suppgood {do lean:mercy-1}
* "I'm sorry it had to be that way."  -> dr3.suppsorry

# dr3.suppain
tenant: Pain. I don't know. That was always Agnes's question. Does it hurt. It's more like being very, very cold in a house where someone has turned off the heating and gone on holiday.
tenant: Thank you for asking. Nobody asks the furniture.
{do sync+1}
@next dr3.strike

# dr3.suppgood
tenant: Yes. I suppose it is. For you.
@next dr3.strike

# dr3.suppsorry
tenant: Don't be. Somebody has to be in charge. I'd rather it was someone who was sorry about it.
@next dr3.strike

# dr3.harm
> The study is warm. You're sitting at the desk, and so is he, and that should be impossible, and isn't. Two pens. One ledger. You're both writing the same sentence in two different hands, and the hands are slowly becoming the same hand.
tenant: Look at that. We agree on a sentence. Eighty years I couldn't agree on a sentence with anybody.
tenant: Harmony. It's a terrible word. It's what they call it in the Court when two people decide to lie in the same key.
* "It doesn't feel like a lie."  -> dr3.harmtrue
* "Where do I end and you start?"  -> dr3.harmwhere
* "Don't get comfortable."  -> dr3.harmwarn {do lean:pride+1}

# dr3.harmtrue
tenant: No. It doesn't. That's what worries me.
{do sync+3:In harmony}
@next dr3.strike

# dr3.harmwhere
tenant: Somewhere around the third vertebra, I think. It moves. Some nights I think I'll wake up and you'll have taken my handwriting. Some nights I think you'll wake up with mine.
{do sync+2}
@next dr3.strike

# dr3.harmwarn
tenant: I'm never comfortable. I'm three hundred years old and I've been sleeping in a dead neonate's veins. Comfort was several centuries ago.
@next dr3.strike

# dr3.surr
> You're in the chair. The visitor's chair. He's at the desk, writing, and he doesn't look up when you come in, the way a busy man doesn't look up when his secretary enters.
tenant: Ah. You. Sit. I'll be with you in a moment.
> The moment goes on. The pen scratches. Out of the corner of your eye, you see that the photograph on the desk has been turned face up, and it isn't Agnes any more. It's you. Your face, smiling at something outside the frame.
tenant: You let me in. In the cistern. You stopped holding the door.
tenant: I'm grateful. I'm going to try very hard to deserve it. But you should know, child, that I'm much better at this than you are, and I've been doing it a great deal longer.
* "I want the hands back."  -> dr3.surrback {do sync-5:Pulling back}
* "Do what you have to."  -> dr3.surrok {do sync+5:Giving way}
* "What are you writing?"  -> dr3.surrwrite

# dr3.surrback
tenant: Of course you do. And tonight you'll have them. Tomorrow you'll have them. But one night, child, you'll be tired, and frightened, and I'll be here, and I won't be.
@next dr3.strike

# dr3.surrok
tenant: ...Thank you. You're very trusting. That was always my favorite thing about the young.
@next dr3.strike

# dr3.surrwrite
> He turns the ledger round so you can see. Columns. Names. Sums. And at the bottom, in fresh ink: *Saturday: resume duties.*
tenant: My diary. One likes to plan ahead.
{do flag:sawResume=1}
@next dr3.strike

# dr3.strike
@gate flag:havenLost ? dr3.burned : dr3.endq

# dr3.burned
tenant: And then there was the fire. Your haven. Someone came in the last hour before dawn with a can of gas and a grudge.
tenant: That's how they do it in this city. They don't kill you. They take away the dark and let the sun do the rest. It's considered very elegant.
@next dr3.endq

# dr3.endq
tenant: Tomorrow is Thursday. On Thursday, everyone picks a side. Make sure you know which one is yours before they pick it for you.
@end
`,'c_n3a');
NL.TASKS.s_winter={n:'The Girl in the Fur Coat',xp:60,cat:'side'};
