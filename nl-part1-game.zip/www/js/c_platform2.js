'use strict';
/* THE NEW LORD — Before One, part two: more faces on Platform 0, and what your week has made them think of you */
(function(){const O=NL.Script.opt;
O('pf.hub','* Malakor, sitting on the edge of the platform with his legs over the tracks.  -> pf2.mal {once} {if !flag:malakorDead}');
O('pf.hub','* Mother Soot. She has come up. She is standing in a drain grate, half in, half out.  -> pf2.soot {once} {if alive:soot}');
O('pf.hub','* Valko, crouched on a girder above the chalk, watching everybody.  -> pf2.val {once} {if !flag:valkoDead&flag:valkoAlly|!flag:valkoDead&flag:valkoWalks|!flag:valkoDead&flag:msgTenDone}');
O('pf.hub','* Lisette, on the Court benches, counting heads.  -> pf2.lis {once} {if !flag:lisetteDead}');
O('pf.hub','* A fledgling in a Gilded coat that\'s too big for her, standing alone.  -> pf2.fl {once} {if !flag:nineDone}');
O('pf.hub','* Pemberton, at the top of the stairs, with the car keys in his hand.  -> pf2.pem {once} {if !flag:pemDead}');
})();
NL.Script.add(String.raw`
# pf2.mal
malakor: Nephew. Sit. Watch them. Look at them all, pretending they're not here to see you burn.
@gate flag:pact=syndicate ? pf2.mal1 : pf2.mal0

# pf2.mal0
@gate flag:refused_syn ? pf2.mal2 : pf2.mal3

# pf2.mal1
malakor: I'll stand up when you say. I've told the boys. Nobody in leather moves until the Sheriff looks at me. Then I stand, and I say my piece, and the Court has to listen to a Butcher tell the truth in public. It'll be the best night of my life.
{do rel:malakor+1}
@next pf.hub

# pf2.mal2
malakor: You said no. To the Switchyard. To my face. In my shop.
malakor: ...I've thought about it. I'm going to stand up anyway. Not for you. Because I don't want the Court thinking the lance was a mirror. It's a matter of craft.
{do rel:malakor+1}
@next pf.hub

# pf2.mal3
malakor: I've got four hundred dollars on you not burning. Don't make me look like a fool. I'm a fool often enough without help.
@next pf.hub

# pf2.soot
> She's come up. Mother Soot, who never comes up. She's standing in the drain grate at the end of the platform, half in and half out, like a cat in a doorway, with a candle in each hand.
soot: Don't look at me. Everyone's looking at me. I knew they'd look.
soot: I came because it's a Tribunal and the last time there was a Tribunal this big, in 1912, I listened through the pipes and didn't come, and they burned a boy who hadn't done it. I've wondered ever since if I'd have said something.
* "Say something tonight, then. If it comes to it."  -> pf2.soot1
* "Thank you for coming up, Mother."  -> pf2.soot2

# pf2.soot1
soot: If it comes to it. Hm. Hm. I might. I've got a jar of things that were said in booths. I've been saving it.
{do rel:soot+1; flag:sootSpeaks=1}
@next pf.hub

# pf2.soot2
soot: Thank. Three thank-yous. I'm going to have to start charging for them.
{do rel:soot+1}
@next pf.hub

# pf2.val
> He drops off the girder and lands beside you without a sound.
valko: I've been up there since eleven. I can see every exit. Every hand. Every pocket. I'll know before anyone moves.
@gate flag:valkoStopped ? pf2.val1 : pf2.val2

# pf2.val1
valko: I'm not hunting. You understand. I stopped. He told me I could. I'm just... watching. Because I want to. That's different. I've never done anything because I wanted to before. It's very strange. I like it.
{do rel:valko+1}
@next pf.hub

# pf2.val2
valko: If anyone goes for you, they go through me. That's not a promise. That's just what's going to happen. Like weather.
{do rel:valko+1}
@next pf.hub

# pf2.lis
lisette: Two hundred and ninety-one. Two hundred and ninety-two. You. Two hundred and ninety-three.
lisette: That's everyone. That's more than 1912. More than 1888. Everyone in the Ward who isn't dead or hiding has come to see what you are.
* "What do they think I am?"  -> pf2.lis1
* "What do you think I am?"  -> pf2.lis2

# pf2.lis1
lisette: The Court thinks you're a thief. The Syndicate thinks you're a joke. The Wraiths think you're one of them. The clanless think you're a promise.
lisette: I counted the ones who don't know. A hundred and six. A hundred and six people who came down those stairs not having decided. That's the number that matters.
{do flag:lisetteCount=1}
@next pf.hub

# pf2.lis2
lisette: I think you're the first new number in a long time.
> She almost smiles. Then, very deliberately, she does.
{do rel:lisette+1}
@next pf.hub

# pf2.fl
> A girl of nineteen in a Gilded coat cut for somebody taller, standing alone at the end of the Court benches with her hands in her sleeves. Nobody is standing near her. She keeps looking at the chalk like it might reach out.
> When she sees you coming, she nearly runs.
* "It's all right. I'm only five days older than you."  -> pf2.fl1
* "Who made you?"  -> pf2.fl2

# pf2.fl1
> She stops. She laughs, the frightened kind.
> "Five days. I'm three weeks. Somebody at a party. I don't remember his face. I remember a ring with a little bird on it."
> "Everyone's here to see you burn," she says. "I'm here to see if you don't. If you don't, then maybe..."
> She doesn't finish. She doesn't need to.
{do flag:metFledgling=1; comp+1}
@next pf.hub

# pf2.fl2
> "I don't know. Somebody at a party. A ring with a bird on it. A silver bird. He said I was beautiful and then I woke up in a skip behind the Golden Dragon."
> She says "skip" and then corrects herself, embarrassed. "Dumpster. Sorry. My mom's from Leeds."
pulse: The hummingbird ring. Valentin Roux. She's one of his.
{do flag:metFledgling=1; flag:knowRouxGirl=1}
@next pf.hub

# pf2.pem
> Pemberton, at the top of the Switchyard stairs, in his chauffeur's cap, with the keys to the Continental in his gloved hand, not coming down.
pemberton: I'm not permitted on the platform, ‹sir›. Ghouls aren't. Tradition. I'll be in the car. Engine running.
@gate flag:vaneWill ? pf2.pem1 : pf2.pem2

# pf2.pem1
pemberton: I've decided, ‹sir›. About the last clause. The car's mine, and so's the choice. And I choose to wait at the top of the stairs with the engine running, for whoever comes up. I'd like you to know it's a choice. It's the first one I've made since 1983.
{do rel:pemberton+2; comp+1}
@next pf.hub

# pf2.pem2
pemberton: If it goes badly, ‹sir›, I'd be obliged if you'd come up the stairs anyway. However you can. I've a blanket in the boot. And a thermos.
pemberton: Sorry. The trunk. Forty years in this country and I still say boot.
{do rel:pemberton+1}
@next pf.hub
`,'c_platform2');
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);const f=S.flags;
  if(f.sootSpeaks&&!f.sootDead)M.push({t:'Look at the drain grate at the end of the platform. Nod.',once:'tb_sootjar',ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-1);return [T('Mother Soot opens a jar. Just a little. Out of it, very clear, like a radio, comes a woman\'s voice, low, from a booth in a crypt: *The doctor did her part. Let Valko do his.*'),T('Every head on the Court benches turns to Séverine. She doesn\'t move. She doesn\'t have to. Everyone knows the voice. It\'s hers.')];}});
  if(f.lisetteCount)M.push({t:'"There are a hundred and six people on this platform who haven\'t decided yet. I\'m talking to you."',once:'tb_106',ok:st=>{st.prog+=1;return [T('You don\'t look at the Court or the Syndicate or the Magistrate. You look at the middle of the crowd. The ones in plain coats, in the back rows, who came down the stairs not knowing.'),T('Some of them look away. Some of them don\'t. Lisette, on the benches, mouths a number to herself and smiles.')];}});
  return M;};})();
