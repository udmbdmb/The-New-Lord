'use strict';
/* THE NEW LORD — the Tenant's errands: small things a dead man asks you to do with his hands, and whether you do them */
NL.Script.add(String.raw`
# te.ask arc=tenant night=3,4 label="\"You've been wanting to ask me something all night.\"" if=sync>=30&!flag:teAsked prio=1
@focus tenant
tenant: I have. Three things. Small things. Things I'd do myself, if I had hands.
tenant: One: there are forty francs I owe a man, and I'd like them paid. Two: there's an apology I owe my driver, and I'd like it made. Three: there's a woman in a crypt who has hated me since 1926, and I'd like her to know why.
tenant: You don't have to. Any of them. I'm a lodger. Lodgers don't get to ask for errands. But I'm asking.
{do flag:teAsked=1}
* "Tell me about the francs."  -> te.fr
* "Tell me about the apology."  -> te.ap
* "Tell me about 1926."  -> te.26
* "Not tonight."  -> te.no

# te.no
tenant: Not tonight. Of course. Of course. There's always another night. That's what I said for two hundred years, and look.
{do sync-1}
@end

# te.fr
tenant: Forty francs. To Ambrose. The Magistrate. For a handkerchief I bled on in a goat pen above Ajaccio in 1790. He's been asking for it for two hundred and thirty-four years. It's the only joke we have.
tenant: I'd like him paid. Properly. Not in dollars. Francs. Old ones. Gideon will have some. Gideon has everything.
{do flag:teFrancs=1; note:te_fr|The Tenant wants forty old francs paid to the Magistrate. Gideon might have some.}
* "And the apology?"  -> te.ap
* "And 1926?"  -> te.26
* "I'll see what I can do."  -> te.bye

# te.ap
tenant: Pemberton. 1999. He'd driven me for sixteen years. One night he asked, very carefully, at a red light, whether he might have Christmas Day off to see his sister in Leeds, whom he hadn't seen since 1983.
tenant: I said no. I didn't need him on Christmas Day. I never needed anyone on Christmas Day. I said no because I could. Because the blood decides. His sister died in 2004. He never asked again.
tenant: I'd like him to know I'm sorry. In my words. Through your mouth. I know it isn't fair to ask.
{do flag:teSorry=1; note:te_ap|The Tenant wants to apologize to Pemberton for Christmas 1999.}
* "And the francs?"  -> te.fr
* "And 1926?"  -> te.26
* "I'll see what I can do."  -> te.bye

# te.26
tenant: 1926. Séverine. Everyone in the Court thinks she hates me because I took the Sheriff's chair she wanted. I let them think it. It was easier.
tenant: The truth is that in 1926 she asked me for a favour. Her first ever. A boy she'd been fond of, a mortal, the great-great-nephew of the priest she hid in her cellar in Lyon. He'd come to Port Vellum. He was dying. She wanted him brought across. Made. And she couldn't ask the Prince, and she couldn't do it herself, because the Choir's rules.
tenant: I said no. Because the law said no. And he died, in January, in the hospital on the Heights, and she sat with him, and I didn't. And she's never forgiven me. And she was right not to.
tenant: I'd like her to know I've been sorry for a hundred years. That's all. That I was sorry the whole time.
{do flag:teSev=1; note:te_26|The Tenant wants Séverine to know he has been sorry about 1926 for a hundred years.}
* "And the francs?"  -> te.fr
* "And the apology?"  -> te.ap
* "I'll see what I can do."  -> te.bye

# te.bye
tenant: Thank you. Even if you don't. Thank you for listening to all three.
{do sync+1}
@end

# te.gid arc=gideon night=3,4,5 label="\"Gideon. Have you got any old French francs?\"" if=flag:teFrancs&!flag:teFrancsGot prio=3
@focus gideon
gideon: Old francs. Old *French* francs. You've come to the only shop in the state.
> He goes into the back. He comes back with a cigar box. Inside: coins, sorted by date, in little paper envelopes. He picks out four. Silver. Worn almost smooth. *Louis XVI. 1789.*
gideon: Ten-franc pieces. Well. Écus, really, but near enough. Forty francs. What on earth do you need forty francs from 1789 for?
* "To pay a debt from 1790."  -> te.gid1
* "Don't ask, Gideon."  -> te.gid2

# te.gid1
gideon: A debt from 1790. Of course. Of course it is. On the house. I've always wanted to settle a debt from 1790.
{do flag:teFrancsGot=1; rel:gideon+1}
tenant: (very quietly) 1789. The year before. He's given us coins from the year before. Ambrose will appreciate that. He'll say I'm a year early for once.
@end

# te.gid2
gideon: I never do. Twenty dollars. They're very nice coins.
* Pay.  -> te.gid3 {if cash>=20}
* "I'll come back."  -> te.gid4

# te.gid3
{do cash-20; flag:teFrancsGot=1}
gideon: Pleasure. Tell whoever it is the Pawn & Coffin says hello.
@end

# te.gid4
gideon: The coins have waited two hundred years. They can wait till Thursday.
@end

# te.pem arc=pemberton night=3,4,5 label="\"Pemberton. The Sheriff wants to say something to you. Through me.\"" if=flag:teSorry&!flag:teSorryDone prio=3
@focus pemberton
pemberton: Through... you mean he's... still...
pemberton: Yes, ‹sir›. All right. I'm listening. I always listened.
* Let him speak. Let his words come out of your mouth.  -> te.pem1
* Say it yourself, in your own words.  -> te.pem2

# te.pem1
> You open your mouth and it's his voice. Not yours. You can feel your face rearranging itself around it, the way a coat settles on a different pair of shoulders.
tenant: Pemberton. Christmas, 1999. You asked me at a red light on Halloran Street for the day off to see Margaret in Leeds. I said no. I said it because I could.
tenant: I'm sorry. I was sorry by Boxing Day. I've been sorry every Christmas since. I never said it because a Sheriff doesn't, and I was a coward who hid behind the word Sheriff.
tenant: I'm so sorry about Margaret.
> Pemberton doesn't move. He's holding the car keys. His knuckles are white around them.
pemberton: ...Thank you, sir. Both of you. ‹Sir›.
pemberton: She had a garden. Margaret. In Leeds. She grew sweet peas. She sent me a packet of seeds every Christmas in a card. I've got twenty of them in the glovebox. I never planted them. There was nowhere to plant them.
* "Plant them. The study has a window box nobody uses."  -> te.pem3
* Say nothing. Let him have it.  -> te.pem4

# te.pem2
> You tell him. In your words. Christmas, 1999. A red light. Margaret. That the man in your head has been sorry since Boxing Day.
pemberton: Since Boxing Day. He said that? Boxing Day?
pemberton: ...He would. He'd count it like that. Exactly a day late. That's him.
{do flag:teSorryDone=1; rel:pemberton+2; sync+1}
@end

# te.pem3
pemberton: A window box. Sweet peas, in the Sheriff's study. Climbing up the bars.
pemberton: Yes, ‹sir›. I think I will. I'll do it Saturday. If there's a Saturday.
{do flag:teSorryDone=1; flag:sweetPeas=1; rel:pemberton+3; sync+2; xp:30:Sweet Peas}
@end

# te.pem4
> You let him have it. The car keys. The glovebox. Twenty packets of seeds. A sister in Leeds. He holds all of it for a long time without saying anything, and you don't make him.
{do flag:teSorryDone=1; rel:pemberton+2; sync+2}
@end

# te.sev arc=severine night=4,5 label="\"My lady. The Sheriff asked me to tell you about 1926.\"" if=flag:teSev&!flag:teSevDone&alive:sev prio=3
@focus severine
> The fan stops. Everything stops.
severine: He asked you. From inside you. To tell me about 1926.
severine: Go on, then. Tell me what he's decided I should know. A hundred years late.
* Tell her exactly what he said. Sorry. The whole time.  -> te.sev1
? velvet 11 "Tell her his name. The boy. Tell her the Sheriff remembered his name."  -> te.sev2 | te.sev1 {id te_sev} {if sync>=40}

# te.sev1
> You tell her. That he said no because the law said no. That he didn't sit with him. That he's been sorry the whole time, every year, a hundred years.
severine: The whole time.
severine: ...He sent flowers. To the hospital. In January. White roses. No card. I thought they were from the Prince. I threw them out of the window into the snow.
severine: They were his. Weren't they.
* "I don't know, my lady. I can ask."  -> te.sev3

# te.sev3
tenant: (through you, before you can stop it) Yes. They were mine.
> Séverine closes her eyes.
severine: You stupid, stupid man. You could have put a card in.
{do flag:teSevDone=1; rel:severine+2; sync+2}
@end

# te.sev2
> You don't know his name. Then you do. It comes up from somewhere under your tongue, in a voice that isn't yours.
tenant: (through you) Étienne. Étienne Aubert. Twenty-six. He had his great-great-uncle's hands. He played the piano in the ward on the Heights for the nurses with drips in both arms.
> Séverine makes a sound that you will never repeat to anyone.
severine: You remembered his name. You remembered his... a hundred years. And you never once...
severine: Get out. No. Stay. Stay. Don't say anything. Just sit there and let him be in the room. Five minutes. Then go.
> You sit. Five minutes. In the crypt beneath Club Reliquary, the Keeper of Elysium sits with the Sheriff she hated for a hundred years, in the body of the child who ate him, and nobody says anything, and it's the closest thing to a funeral either of them has had.
{do flag:teSevDone=1; flag:sevForgaveVane=1; rel:severine+4; sync+3; xp:40:Étienne}
@end
`,'c_tenant6');
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);const f=S.flags;
  if(f.teFrancsGot)M.push({t:'Before anyone speaks, walk to the Magistrate\'s chair and put four silver coins from 1789 on the arm of it.',once:'tb_francs',ok:st=>{st.threat=Math.max(0,st.threat-2);st.prog+=1;return [T('The Magistrate looks down at four worn écus of Louis XVI. Forty francs. A year early.'),L('magistrate','...Absalom.'),T('He doesn\'t pick them up. He looks at them for a long time. Then he takes out a white linen handkerchief, old, very old, with a brown stain on one corner, and lays it over the coins, gently, like a man covering a face.'),L('magistrate','Paid. We are square, you and I. After two hundred and thirty-four years.'),L('magistrate','Proceed.')];}});
  if(f.sevForgaveVane&&!f.sevDead)M.push({t:'Say nothing. Look at the Accuser. Let her decide.',once:'tb_etienne',ok:st=>{st.threat=Math.max(0,st.threat-3);return [T('Séverine looks back at you across the chalk. At what\'s in you.'),L('severine','...The Accuser has no further questions.'),T('A ripple through three hundred Kindred. The Keeper of Elysium has never, in living memory, had no further questions.')];}});
  return M;};})();
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.sweetPeas)o.push(['A window box in the Sheriff\'s study','Sweet peas, climbing the bars, from twenty years of packets sent at Christmas from a garden in Leeds. Pemberton waters them at dusk. He says they smell of his sister.']);
  if(f.teFrancsGot&&f.magChristmas)o.push(['Christmas Eve','The Magistrate came to the study in the Continental with a bottle and a goat. Nobody knows where he got the goat. Pemberton has asked him not to bring it again. He brings it every year.']);
  return o;});
