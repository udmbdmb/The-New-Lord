'use strict';
/* THE NEW LORD — Ascension: the third tier of every Discipline.
   Tier 1 is the gift, Tier 2 the Mutation (skill points), Tier 3 the Ascension. Tier 3 stays sealed until your clan's blood rite,
   offered by the Tenant from Night 3. The rite ascends one power for free (and mutates it if it wasn't). The others cost 3 skill points
   each afterwards, and need their Tier 2 first. In dialogue, {ab kneel 3} or {ab:'kneel',t3:true} marks a Tier 3 option (+2 Vitae). */
(function(){
const T3={
  /* Sovereign */
  kneel:{n:'The Absolute',d:'One command that even Kindred cannot refuse. They will know you did it.'},
  fog:{n:'Palimpsest',d:'Rewrite a whole night for a mortal, or for every mortal in a room.'},
  blueblood:{n:'Divine Right',d:'Turn a vampire\'s hidden debt into a blood-oath sworn to you.'},
  /* Wraiths */
  veil:{n:'Forgotten',d:'Everyone present forgets you were ever in the room.'},
  carrion:{n:'Plague Lord',d:'Every rat and roach in the Ward reports to you: ask what any room saw tonight.'},
  mark:{n:'The Grey Parliament',d:'Call up the Wraiths\' dead-network to testify, or to haunt.'},
  /* Glass */
  dejavu:{n:'The Unbroken Hour',d:'Live a whole conversation twice. Keep the better one.'},
  splinter:{n:'Kaleidoscope',d:'Shatter one mind into many and turn a room on itself.'},
  coldread:{n:'Open Book',d:'Read a vampire\'s whole life at a glance: sire, crimes, and the thing they fear.'},
  /* Choir */
  siren:{n:'Requiem',d:'Sing a room still. Every listener, living or dead, stops and weeps.'},
  touch:{n:'Echo Chamber',d:'Play back the last hour of a place, aloud, for everyone in it.'},
  encore:{n:'Grand Finale',d:'Make a whole room perform the scene you choose.'},
  /* Butchers */
  bonekey:{n:'Ossuary Form',d:'Wear your skeleton as armour. Nothing short of fire puts you down for a minute.'},
  borrowed:{n:'Thousand Faces',d:'Become anyone you have touched, voice and scent included.'},
  nerve:{n:'Marionette',d:'Take a body, mortal or Kindred, for one long minute.'},
  /* Hounds */
  scent:{n:'The Long Hunt',d:'Name anyone in the city and know where they are standing.'},
  claws:{n:'Wolf-Form',d:'Become the thing that hunts. Nothing in the room stays standing.'},
  pack:{n:'Wild Hunt',d:'Every dog, and every Hound in earshot, runs at your word.'},
  /* Alchemists */
  boil:{n:'Philosopher\'s Fire',d:'Light a vampire\'s Vitae from the inside. Usually the threat is enough.'},
  ward:{n:'Covenant',d:'Write a contract in blood. Whoever breaks it burns.'},
  vintage:{n:'Vintage of the Dead',d:'Drink a dead Kindred\'s ash or blood and live their last night.'},
  /* Hollow */
  shadowstep:{n:'The Long Dark',d:'Step into any shadow in the Ward and out of any other.'},
  snuff:{n:'Eclipse',d:'Put out the Ward: every light, camera and screen, for an hour.'},
  strings:{n:'Shadow Court',d:'Every shadow in the room obeys you, theirs included.'},
  /* Rot */
  corpse:{n:'Resurrection Men',d:'Raise the recent dead to walk and speak for one night.'},
  miasma:{n:'The Black Breath',d:'A sickness that drops a room and leaves no trace.'},
  stillheart:{n:'Death Unending',d:'Die in front of them. Get up when they have gone. Even fire only slows you.'},
  /* Stray */
  scavenger:{n:'Mongrel King',d:'Keep every gift you have ever tasted, all at once.'},
  spark:{n:'Live Wire',d:'Ride the grid. Step out of any lit sign in the Ward.'},
  badluck:{n:'Black Cat',d:'Bad luck becomes a curse that follows them for a week.'}
};
NL.CLAN_ORDER.forEach(c=>{const ab=NL.CLANS[c].ab;Object.keys(ab).forEach(k=>{if(T3[k]){ab[k].t3=T3[k];if(NL.ABIL[k])NL.ABIL[k].t3=T3[k];}});});
NL.T3=T3;

/* effects the script can call: fx:ascend:kneel, fx:ascendOpen */
const FX=NL.Script.FX=NL.Script.FX||{};
FX.ascend=(S,G,k)=>{S.flags.ascend=1;S.flags.ascendNight=S.night;if(k&&NL.ABIL[k]){S.mut[k]=2;S.flags.ascendFirst=k;G.toast('level',NL.ABIL[k].t3.n,'Ascension · Tier 3');}G.xp&&G.xp(80,'Ascension');};
FX.ascendOpen=(S,G)=>{S.flags.ascend=1;S.flags.ascendNight=S.night;};
})();

/* ===================== the rite ===================== */
NL.Script.add(String.raw`
# asc.0 arc=tenant night=3,4,5 label="\"Something's wrong with my teeth. With all of it.\"" if=!flag:ascend&!flag:ascOffered prio=4
@do flag:ascOffered=1
> It starts in the back teeth. A pressure, like a word you can't remember. Then in the wrists. Then in the tips of the fingers, where the blood goes last.
tenant: Ah. There it is. I wondered when you'd notice.
tenant: You've three hundred years of me in you, and three nights of you, and the blood has run out of room to argue. It's thickening. Pressing on the hinges.
tenant: Every bloodline keeps a third door. Most neonates take fifty years to find the handle. You're leaning on it.
parasite: It wants out. Whatever's behind that door is hungry and very, very patient.
sundial: Third night. Most of them don't get a third night.
* "What's behind it?"  -> asc.what
* "How do I open it?"  -> asc.how
* "Not tonight."  -> asc.later

# asc.what
tenant: What's behind any door, in our condition? More. More of what you already are.
tenant: A Kneel that works on Kindred. A shadow you can climb into from across the city. A song that makes a room cry. It isn't a new gift. It's the old one, finished.
tenant: There's a cost. There's always a cost. Mostly it's that you stop being able to pretend you're a person who could have said no.
@next asc.how

# asc.how
tenant: Every blood has a rite. Some are pretty. Most aren't. Yours is...
@gate clan:sovereign ? asc.sov : asc.g1

# asc.g1
@gate clan:wraiths ? asc.wra : asc.g2
# asc.g2
@gate clan:glass ? asc.gla : asc.g3
# asc.g3
@gate clan:choir ? asc.cho : asc.g4
# asc.g4
@gate clan:butchers ? asc.but : asc.g5
# asc.g5
@gate clan:hounds ? asc.hou : asc.g6
# asc.g6
@gate clan:alchemists ? asc.alc : asc.g7
# asc.g7
@gate clan:hollow ? asc.hol : asc.g8
# asc.g8
@gate clan:rot ? asc.rot : asc.str

# asc.later
tenant: Of course. It'll keep. It's very good at keeping. It's the only thing it does better than me.
> The pressure in your teeth doesn't go away. It just gets quieter, the way a dog does when you stop looking at it.
@end

# asc.again arc=tenant night=3,4,5 label="\"The door. I'm ready.\"" if=flag:ascOffered&!flag:ascend prio=4
tenant: Good. It was getting crowded in here.
@next asc.how

// ---------------------------------------------------------------- Sovereign
# asc.sov
tenant: ...mine. Ours. The Sovereign rite is very simple and very nasty. You command something that does not want to obey you. Not a mortal. Mortals want to be told. Something with teeth.
tenant: The traditional choice is a rival. I'd suggest something closer to home.
> He means the Beast. The hunger you've been keeping on a short lead since Monday, the one that gets up and paces when someone's pulse is showing.
* Kneel before the bathroom mirror and command it to kneel.  -> asc.sov1
* "Help me. Do it with me."  -> asc.sov1 {do sync+6}

# asc.sov1
> You go to the cracked mirror over the sink, where there's no face for you, only the room behind you, and you say it the way he would. One word, from the bottom of the lungs you don't use.
you: "Kneel."
> Nothing. Then something in your chest, the thing that sits up when it smells blood, turns round three times like a dog and lies down. It doesn't want to. It does anyway.
> The quiet afterwards is enormous. You hadn't realized how loud it was, all week.
apex: That's what it feels like. Being obeyed by something that hates you. Get used to it. You're going to like it.
tenant: (very softly) Well done. That took me forty years.
> The door is open. Something comes through it. You get to choose which hand it fills first.
* The Absolute. A Kneel that binds the dead as well as the living.  -> asc.done {do fx:ascend:kneel; vitae-2}
* Palimpsest. Rewrite a night, not fifteen minutes.  -> asc.done {do fx:ascend:fog; vitae-2}
* Divine Right. A debt becomes an oath.  -> asc.done {do fx:ascend:blueblood; vitae-2}

// ---------------------------------------------------------------- Wraiths
# asc.wra
tenant: ...the Wraith one. I always found it unbearably sad. You go down where the city keeps the things it doesn't want to look at, and you wait until even the dead stop noticing you.
echo(4): There's a sign for it, in the chalk under the grates. A closed eye with a line through it. Soot's people leave it where one of them went down and came back.
* Go down into the drains under Ferrier Lane and sit.  -> asc.wra1

# asc.wra1
> Down a storm drain, along a pipe, into a brick room where the water stands still. You sit with your back to the wall.
> The rats notice you for the first hour. Then they don't. They run over your shoes like you're a step.
> In the second hour something else notices you, a long way off in the pipes: a coldness, a listening. Then that stops noticing too.
soot: (from very far away, in the water) Mm. There you are. And there you aren't. Good child.
echo: You can hear the whole Ward breathing. Nobody can hear you.
> When you climb back up, the street doesn't look at you. Not one face. You've been unremembered, and the door is open.
* Forgotten. Let a whole room lose you.  -> asc.done {do fx:ascend:veil; vitae-2}
* Plague Lord. The vermin keep the city's minutes. Read them.  -> asc.done {do fx:ascend:carrion; vitae-2}
* The Grey Parliament. Call the dead-network to the stand.  -> asc.done {do fx:ascend:mark; vitae-2}

// ---------------------------------------------------------------- Glass
# asc.gla
tenant: ...the Glass. You break a mirror and look at every piece at once. The pieces show you every way tonight could go. The trick is not going mad. Most of them go a little mad. It suits them.
* Break the bathroom mirror with your fist.  -> asc.gla1
* Break it gently. Tap. Tap. Until it gives.  -> asc.gla1 {do comp+1}

# asc.gla1
> It comes apart in your hand, and every shard is a different room.
> In one, Leo is laughing at a joke you haven't told. In one, Miller is standing over your ash with her hat in her hands. In one you're on Platform 0 and the light is coming up through the grates and it's very, very white.
web: They're not guesses. They're branches. All of them are real until you pick.
pulse: You can feel which ones are kind. That's the worst part.
> You make yourself look at all of them, every one, until they stop being frightening and start being a map. Then the shards are just glass again, and your hand is bleeding, and the door is open.
* The Unbroken Hour. Live a conversation twice.  -> asc.done {do fx:ascend:dejavu; vitae-2}
* Kaleidoscope. Turn a room against itself.  -> asc.done {do fx:ascend:splinter; vitae-2}
* Open Book. Read a whole life at a glance.  -> asc.done {do fx:ascend:coldread; vitae-2}

// ---------------------------------------------------------------- Choir
# asc.cho
tenant: ...the Choir's. You sing one note and hold it until your dead lungs give it back. Séverine did hers in a cathedral in Lyon in 1771, and the windows still have a crack in them.
* Go up on the roof and sing.  -> asc.cho1

# asc.cho1
> Up on the roof, in the wet. You find the note. It's lower than you'd think, and it isn't yours, quite: it's the one the city hums under the traffic.
> You hold it. Thirty seconds. A minute. Your lungs run out and the note doesn't. It keeps coming out of you on its own, like water from a cracked pipe.
> All over the Ward, things tune themselves to it. A car alarm drops a semitone. A dog stops barking. Somebody's radio, three streets away, goes quiet to listen.
nostalgia: Your mother used to hum while she washed up. This is that. This is that times a city.
severine: (a text, a minute later, no words, just a single musical note)
> When you stop, the silence rings. The door is open.
* Requiem. Sing a room still.  -> asc.done {do fx:ascend:siren; vitae-2}
* Echo Chamber. Make a place play back its last hour.  -> asc.done {do fx:ascend:touch; vitae-2}
* Grand Finale. Make a room perform.  -> asc.done {do fx:ascend:encore; vitae-2}

// ---------------------------------------------------------------- Butchers
# asc.but
tenant: ...the Butchers'. You take something of yours apart and put it back better. Traditionally a hand. Malakor did his whole face. You can tell, if you know where to look.
* Take your left hand apart at the kitchen table.  -> asc.but1

# asc.but1
> You lay your left hand on the table, palm up, and you go in with your right thumb, the way the blood tells you to. There's no pain. There's a sort of loud, attentive interest.
> Tendon. Joint. Bone. You lay them out like cutlery. You can see now how it was built, and all the places where it was built lazily.
autopsy: Twenty-seven bones. You could do it with twenty. You could do it with steel.
abattoir: Or you could put a blade in the knuckle. Just saying.
> You put it back together. It closes like a zip. It's your hand, and it's better than your hand, and it's slightly too long. The door is open.
* Ossuary Form. Your skeleton becomes armour.  -> asc.done {do fx:ascend:bonekey; vitae-2}
* Thousand Faces. Anyone you've touched.  -> asc.done {do fx:ascend:borrowed; vitae-2}
* Marionette. Take a body for a minute.  -> asc.done {do fx:ascend:nerve; vitae-2}

// ---------------------------------------------------------------- Hounds
# asc.hou
tenant: ...the Hounds'. You run the bounds of your territory in one night, without stopping, and you let whatever follows you follow. Valko did his in Bucharest. He says the whole city's dogs came. He exaggerates. It was most of them.
* Run the Ward. All of it.  -> asc.hou1

# asc.hou1
> Ferrier Lane. The Strip. The docks. Platform 0's iron fence. The river wall. Up St. Jude's hill and down the other side. You don't stop. You can't. Your legs aren't asking.
> On the docks, a dog falls in behind you. By the Switchyard there are six. By the time you come round past Kowalski's again there are twenty, and a fox, and something much bigger keeping pace in the dark on the other side of the road.
valko: (out of the dark, running) Don't look at me. Don't stop. Last mile. Go.
frenzy: MORE. FASTER. MORE.
> You finish where you started, and the dogs sit down in a ring around you, tongues out, waiting for you to tell them what's next. The door is open.
* The Long Hunt. Name anyone. Know where they are.  -> asc.done {do fx:ascend:scent; vitae-2}
* Wolf-Form. The thing that hunts.  -> asc.done {do fx:ascend:claws; vitae-2}
* Wild Hunt. Every dog, and every Hound, at your word.  -> asc.done {do fx:ascend:pack; vitae-2}

// ---------------------------------------------------------------- Alchemists
# asc.alc
tenant: ...the Alchemists'. You write a contract with yourself, in your own blood, and you sign it. You promise one thing forever. Your blood holds you to it. That's the price of the third door: the Alchemist becomes their own first customer.
* "What should I promise?"  -> asc.alc1

# asc.alc1
tenant: Something you'd keep anyway. Don't be clever. The clever ones always pick something they can't keep and then they burn.
* "I will never drink from someone who can't say no."  -> asc.alc2 {do flag:alcVow=consent}
* "I will never lie to someone who saved my life."  -> asc.alc2 {do flag:alcVow=saviour}
* "I will never sell anyone I've given my word to."  -> asc.alc2 {do flag:alcVow=word}

# asc.alc2
> You open your thumb and write it on the back of an envelope, one line, in a hand that's half yours and half his. You sign it. The blood goes into the paper and the paper goes warm, then hot, then it's ash, and the ash is in your mouth.
osmosis: It tastes of you. Of a contract. Of being held to something.
> Your blood sits up very straight, like a clerk who has just been given the most important file in the building. The door is open.
* Philosopher's Fire. Light their Vitae from the inside.  -> asc.done {do fx:ascend:boil; vitae-2}
* Covenant. Contracts that burn the people who break them.  -> asc.done {do fx:ascend:ward; vitae-2}
* Vintage of the Dead. Drink a dead Kindred's last night.  -> asc.done {do fx:ascend:vintage; vitae-2}

// ---------------------------------------------------------------- Hollow
# asc.hol
tenant: ...the Hollow's. You stand in the dark until your shadow stands up on its own and you shake its hand. The ones who don't come back from that are the ones who let go first.
* Turn every light in the flat off. Tape the window. Stand.  -> asc.hol1

# asc.hol1
> Total dark. You stand in the middle of the room. An hour. You stop being sure where your edges are.
> Then something peels up off the floor in front of you, very slowly, like a page turning. It's your height. It's your shape. It has your posture, which is not, you notice, very good.
> It holds out its hand.
echo: It's cold. It's not cold. It's the absence of every temperature.
* Shake it.  -> asc.hol2
* Hold on and don't let go first.  -> asc.hol2 {do comp+1}

# asc.hol2
> You shake hands with your shadow. It has a firm grip. Afterwards it lies down where it belongs, but it's paying attention now, and you can feel it there, the way you feel a dog under the table. The door is open.
* The Long Dark. Any shadow, to any shadow.  -> asc.done {do fx:ascend:shadowstep; vitae-2}
* Eclipse. Put out the Ward.  -> asc.done {do fx:ascend:snuff; vitae-2}
* Shadow Court. Every shadow in the room is yours.  -> asc.done {do fx:ascend:strings; vitae-2}

// ---------------------------------------------------------------- Rot
# asc.rot
tenant: ...the Rot's. Unpleasant, even by my standards. You lie down in the earth, you let it close over you, and you wait until the worms decide you belong to them.
* The community garden behind St. Jude's. Dig.  -> asc.rot1

# asc.rot1
> Wet soil, a spade borrowed from a shed, a hole you don't measure. You lie down in it and pull the earth in over yourself with your hands until there's no more sky.
> It's very quiet. It's not frightening. That's the frightening thing.
> Something touches your face, curious, and then another thing. They decide. You can feel them deciding. You belong here.
rigor: Not breathing is easy. Not breathing *for an hour, under a garden* is a skill.
parasite: Everything down here is eating everything else, slowly, politely. You fit right in.
> When you come up, there's a ring of flowers around the hole that wasn't there before, all of them dead, all of them still standing. The door is open.
* Resurrection Men. Raise the recent dead for a night.  -> asc.done {do fx:ascend:corpse; vitae-2}
* The Black Breath. A sickness that drops a room.  -> asc.done {do fx:ascend:miasma; vitae-2}
* Death Unending. Die, and get up later.  -> asc.done {do fx:ascend:stillheart; vitae-2}

// ---------------------------------------------------------------- Stray
# asc.str
tenant: ...well. That's the thing. The Stray doesn't have one. No clan, no rite. The Court thinks that's the point.
tenant: I've always thought it meant you could steal one.
* "Then I'll steal all of them."  -> asc.str1

# asc.str1
> You do a little of every rite in one night, badly. You tell your hunger to sit, and it half-sits. You crack a mirror. You hum a note on the bus. You sit in a drain until the rats get bored of you. You take your thumb apart and put it back slightly wrong. You run three blocks with a dog. You sign a promise on a napkin. You stand in a dark stairwell until your shadow shrugs.
gutter: Nobody gave you anything, ever. So you took a bit of everything. That's not a rite. That's a *life*.
> It shouldn't work. It works. The door doesn't open so much as get kicked in.
* Mongrel King. Keep every gift you've tasted.  -> asc.done {do fx:ascend:scavenger; vitae-2}
* Live Wire. Ride the grid.  -> asc.done {do fx:ascend:spark; vitae-2}
* Black Cat. A week of bad luck, aimed.  -> asc.done {do fx:ascend:badluck; vitae-2}

// ---------------------------------------------------------------- after
# asc.done
@do tick:60
> It settles. It settles the way a house settles, all at once and with a long creak.
tenant: There. Now you're something. Not much yet. But something with a third door, which is more than most of the Court can say.
tenant: The others will come, if you feed them. (Ascend the other gifts from your character sheet. They each need their Mutation first.)
pedigree(4): The Elders will smell it on you. Some of them will be afraid. Some of them will start being polite. Watch the polite ones.
@end
`,'c_ascend.js');
