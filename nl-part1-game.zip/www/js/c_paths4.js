'use strict';
/* THE NEW LORD — Nights 3 and 4, other ways through: Wednesday at the Lucky Mart, and Thursday in the Keeper's crypt, as whoever you are */
(function(){const O=NL.Script.opt;
O('rk.hub','* "Officer Dale. Officer Pruitt, badge 4471. I used to log your seizures in the cage. I kept copies."  -> p4.clerk {if past:clerk}',0);
O('rk.hub','* "Ken. Your nephew\'s alive. I\'ve seen him. Put the envelope down and I\'ll tell you where."  -> p4.ken {if alive:leo&fact:leo:name}',0);
O('rk.hub','* Step between Tariq and the counter. Say nothing. Just stand there, very still, the way the Tenant used to.  -> p4.still {if rep:pride>=2|clan:sovereign}',0);
O('rk.hub','* "Gentlemen. Tariq\'s shop is under the protection of Local 0." (It isn\'t. Yet.)  -> p4.union {if flag:side_union|flag:local0Member}',0);
O('rk.hub','* Whistle. Softly. Let every dog on Ferrier Lane hear it.  -> p4.dogs {if clan:stray|flag:strayDog}',0);
O('s4.hub','* "My lady. You went back into the opera house in 1966. Three times. I know."  -> p4.fire {once} {if mem:malakor.sevfire}');
O('s4.hub','* "A Kyrie. Forty-one bars. Pour S. Stand with me, and it\'s yours."  -> p4.kyrie {once} {if flag:kyrieSheet&!flag:kyrieGiven&!flag:side_court}');
O('s4.hub','* "Ten years as your Sheriff. We agreed. Now stand with me."  -> p4.pact {once} {if flag:pact=court&!flag:side_court}');
O('s4.hub','* "I don\'t need you to stand with me. I need you to stop lying. Just for one night."  -> p4.truth {once} {if rep:candour>=3&!flag:side_court}');
})();
NL.Script.add(String.raw`
# p4.clerk
> Dale goes white. Pruitt goes whiter.
dale: You... the clerk. From the cage. You're... they said you were...
> You tell them the numbers. Dates. Amounts seized. Amounts logged. The difference. Every Wednesday for two years, in a column, in your head, where you put it at the time without knowing why.
dale: That's... you can't prove...
* "I kept copies. Everyone knows I kept copies."  -> p4.clerk1

# p4.clerk1
> You didn't. Or you did, and you don't remember where. It doesn't matter. Dale's already counting the cost of finding out.
> He puts the envelope back on the counter. He puts two more twenties on top of it, which nobody asked him to do. He leaves. Pruitt goes after him without looking at Tariq at all.
tariq: What... what did you say to them? What numbers?
* "Their own. Back to them."  -> p4.clerk2

# p4.clerk2
{do flag:racketDone=clerk; task:s_tariq=done; rel:tariq+2; cash+40:Dale's guilt; xp:40:Wednesday}
tariq: Their own numbers. Okay. Okay. My father kept a ledger, too. He said a man who writes things down is the most dangerous man in the shop.
@next rk.end

# p4.ken
> Ken Pruitt stops with the envelope halfway to his pocket.
kenpruitt: ...What did you say?
dale: Ken. Ken, don't. It's a trick. They do tricks.
kenpruitt: Shut up, Dale. What did you say about Leo?
* "He's alive. He's scared. He works at Kowalski's and he's been hiding since Monday. He thinks you'd be ashamed of him."  -> p4.ken1

# p4.ken1
> The envelope goes down on the counter. Ken Pruitt sits down on the stack of newspapers by the door like his legs have gone.
kenpruitt: Ashamed. Of him. I'm... I'm standing in a convenience store taking envelopes off a man whose father I went to school with. Ashamed of *him*.
kenpruitt: Dale. Go. Go and sit in the car. I'm not doing this any more. Tell the sergeant what you like.
dale: Ken...
kenpruitt: GO.
> Dale goes. Ken sits on the newspapers with his head in his hands. Tariq, very quietly, puts the kettle on.
{do flag:racketDone=ken; flag:kenOut=1; task:s_tariq=done; rel:tariq+2; rel:kenpruitt+2; xp:40:Wednesday}
@next rk.end

# p4.still
> You don't say anything. You step between Tariq and the till and you stand there, one hand behind your back, the way a heron stands in a river it disapproves of.
> Dale opens his mouth. Shuts it. Looks at Pruitt. Pruitt is looking at the floor.
> Nobody in the Lucky Mart moves for nearly a minute. The fridge hums. The coffee pot ticks.
? pedigree 10 "Keep standing."  -> p4.still1 | p4.still2 {id p4_still}

# p4.still1
> Dale cracks first. He always would have.
dale: ...Fine. Fine. Whatever. This shop's more trouble than it's worth.
> They go. They don't run. They walk very carefully, the way you'd walk out of a church you'd wandered into by mistake.
tenant: Two hundred years and that's still the best trick I know. Stand there. Let them imagine what you'll do.
{do flag:racketDone=still; task:s_tariq=done; rel:tariq+2; lean:pride+1; xp:30:Wednesday}
@next rk.end

# p4.still2
dale: What are you, a statue? Move.
> He moves you. Or tries to. He puts a hand on your chest and pushes, and you don't move, and his hand is very cold suddenly, and he takes it away and looks at it.
dale: ...Okay. Okay. We'll come back. Next week.
{do flag:racketDone=still; task:s_tariq=done; rel:tariq+1; heat+1; xp:20:Wednesday}
@next rk.end

# p4.union
dale: Local... what? The bus drivers?
> The bell over the door goes. Then again. Then again. Dutch comes in, and two clanless Kindred in their least-ripped jeans behind him, and a fourth, enormous, in a knit hat, carrying a pot of soup for some reason.
dutch: Evening, officers. Evening, Tariq. We're the union. We're picketing. This shop's unionized.
dale: ...You can't unionize a shop you don't work at.
dutch: Watch us.
> They stand there. With the soup. Dale and Pruitt leave without the envelope, very fast, and Little Sal sets the soup down on the counter and says "for later" to Tariq, who has no idea what is happening.
{do flag:racketDone=union; task:s_tariq=done; rel:tariq+2; rel:dutch+1; flag:side_union=1; xp:40:Wednesday}
@next rk.end

# p4.dogs
> You whistle. Not loud. A note you didn't know you knew.
> For a moment, nothing. Then, from up and down Ferrier Lane, through the rain: barking. One dog. Five. Twenty. Claws on wet asphalt. Shapes at the Lucky Mart window, pressing their noses to the glass, all of them looking at Dale.
> A grey lurcher with one ear up comes in through the door when a customer opens it and sits down on Dale's foot. {if flag:strayDog}
dale: What the... what the hell is...
> They leave. Out through a corridor of silent, staring dogs, very slowly, not making eye contact with any of them.
{do flag:racketDone=dogs; task:s_tariq=done; rel:tariq+2; heat+1; xp:30:Wednesday}
tariq: My mother would say: when the dogs choose a side, choose the dogs' side.
@next rk.end

# p4.fire
> The fan stops completely.
severine: Who told you that.
severine: ...Malakor. Of course. He was there. He held the door. He was the only one who held the door.
severine: Three times. I went back three times because Absalom had gone in for his *hat*. His hat. He came out with it on, singed, and said "thank you, Séverine" as if I'd passed him the salt.
severine: That's the last time I did anything brave. Fifty-eight years. I've been very careful since.
* "Do one more brave thing. Tomorrow. Stand with me."  -> p4.fire1
* "You don't have to be brave. Just be there."  -> p4.fire2

# p4.fire1
severine: One more. In the chalk. In front of everyone. With the Magistrate watching and the lamps in the grates.
severine: ...God help me. He'd laugh. He'd laugh so hard. Very well. One more. Then I'm retiring from bravery forever.
{do flag:side_court=fire; flag:sevPardon=1; flag:bloodHunt=0; flag:sevStands=1; rel:severine+3; xp:40:The Opera House}
@next s4.hub

# p4.fire2
severine: Just there. Like furniture. I can do furniture. I've been furniture for fifty-eight years.
{do rel:severine+1}
@next s4.hub

# p4.kyrie
> You hold up the folded printer paper. She sees *pour S.* through the back of it and goes completely still.
severine: That's... where did you...
severine: You're bargaining with me. With *that*. That's the cruelest thing anyone's ever done to me, and I've been at court for two hundred years.
* "Then have it. No bargain. It was always yours."  -> p4.kyrie1
* "Stand with me, and it's yours."  -> p4.kyrie2

# p4.kyrie1
> You give it to her. She takes it like it might burn.
severine: No bargain. You fool. You absolute fool. That was the only card you had.
severine: ...I'll stand with you. Not because of this. Because you gave it to me anyway. Nobody gives me anything anyway.
{do flag:kyrieGiven=1; flag:side_court=kyrie; flag:sevPardon=1; flag:bloodHunt=0; flag:sevStands=1; rel:severine+4; lean:mercy+1; xp:40:Pour S.}
@next s4.hub

# p4.kyrie2
severine: Yes. Yes, of course. That's how it's done. You're learning.
> She stands with you. She takes the paper. She doesn't thank you. She'll never forgive you, and she'll never forget what it was like to hold it, and both of those things will last longer than either of you.
{do flag:kyrieGiven=1; flag:side_court=kyrie; flag:sevPardon=1; flag:bloodHunt=0; rel:severine+1; lean:mercy-1}
@next s4.hub

# p4.pact
severine: We agreed. Yes. Ten years. And a Sheriff who's mine stands in the chalk under my protection.
@gate flag:pactFalse ? p4.pact2 : p4.pact1

# p4.pact1
severine: Very well. I'll stand. I'll accuse you of murder and diablerie in the gentlest possible voice, and then I'll sit down. You'll have the best Accuser in two hundred years.
{do flag:side_court=pact; flag:sevPardon=1; flag:bloodHunt=0; rel:severine+1}
@next s4.hub

# p4.pact2
severine: We agreed. And you didn't mean it. I saw your face on Thursday, darling. You have a face like a shop window.
severine: I'll stand anyway. I want to see what you do with a promise you didn't mean when the person you made it to is standing right next to you.
{do flag:side_court=pact; flag:sevPardon=1; flag:bloodHunt=0; rel:severine+1; lean:candour-1}
@next s4.hub

# p4.truth
severine: Stop... lying. For one night.
> She laughs. It isn't a nice laugh, at first. Then it is.
severine: Do you know what you're asking? I lie the way other people breathe. Did. Do. You've no idea what would happen if I stood up in the chalk and told the truth. Nor do I. That's what frightens me.
? velvet 12 "Find out. Tomorrow. I'll be standing right there."  -> p4.truth1 | p4.truth2 {id p4_truth}

# p4.truth1
severine: Find out.
> She closes the fan. She puts it down on the sarcophagus. It's the first time you've seen her without it in her hand.
severine: Very well. One night. I'll tell the truth. All of it. About the doctor, and the federal man, and what I let happen in that freezer because I wanted him gone. God help us both.
{do flag:side_court=truth; flag:sevPardon=1; flag:bloodHunt=0; flag:sevTruth=1; rel:severine+2; xp:50:One Night}
@next s4.hub

# p4.truth2
severine: No. No, darling. Not even for you. Some of us are made of lies all the way down. Take them away and there's nothing left to stand anywhere.
{do rel:severine+1}
@next s4.hub
`,'c_paths4');
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);const f=S.flags;
  if(f.sevTruth&&!f.sevDead)M.push({t:'Turn to the Accuser. "My lady. You promised me one night."',once:'tb_sevtruth',ok:st=>{st.prog+=3;st.threat=Math.max(0,st.threat-2);return [T('Séverine Marchetti stands up in the chalk without her fan.'),L('severine','I knew. About the doctor. About the lance. The federal man told me in my own booth, and I said "the doctor did her part", and I sent the Hound after a child so that nobody would ask who had.'),L('severine','I wanted Absalom gone. I have wanted him gone since 1926. I did not lift a finger. That is my crime. Not the Accused\'s.'),T('Three hundred Kindred do not make a sound. The Magistrate takes off his gloves.'),L('magistrate','...Sit down, Lady Séverine. I will deal with you after.'),L('magistrate','Thank you.')];}});
  return M;};})();
