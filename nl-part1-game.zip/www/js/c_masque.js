'use strict';
/* THE NEW LORD — "The Masque": on Wednesday night the Gilded Court holds its October masque in the ballroom over the Reliquary. The neonate everyone is talking about has been invited, as a joke. */
(function(){const X=NL.EXTRAS,S_=NL.Script;
X.ottilie=X.ottilie||{n:'Lady Ottilie Brand',color:'#c8c8d0',role:'Accountant to the Gilded Court',spec:{face:{long:1.08,cheek:1.2,jaw:.9},skin:[.9,.86,.84],hair:{style:'bun',color:[.6,.6,.62]},coat:{color:[.45,.45,.5],length:.9,collar:true},shirt:[.85,.85,.88],glasses:{type:'round'},eyeGlow:[.25,.2,.25]}};
NL.TASKS.s_masque={n:'The Masque',xp:80,cat:'side'};
S_.place({id:'masque',name:'The Masque, Club Reliquary',block:'B',sub:'The Gilded Court\'s October ball, in the old ballroom upstairs. You\'ve been invited. The invitation is printed on black card and says "Do come. Everyone wants to see."',if:'night:3&flag:mapOK&!flag:masqueDone&time<330',node:'mq.0',min:8});
})();
NL.Script.add(String.raw`
# mq.0
> The ballroom above Club Reliquary has been shut since 1974 except for one night a year. Tonight the dust sheets are off. Chandeliers. A string quartet of the long dead playing a waltz from before any of their deaths. A hundred Kindred in masks, in silk, in velvet, in grey wool and diamonds, moving round each other like fish in a tank.
> At the door, a ghoul in livery holds out a silver tray of masks.
ghoulgirl: For the guest. Everyone wears one. It's tradition. Choose.
* A plain black half-mask.  -> mq.m1 {do flag:mqMask=black}
* A gold mask with a beak. A bird of prey.  -> mq.m2 {do flag:mqMask=hawk; lean:pride+1}
* A white mask with no expression at all.  -> mq.m3 {do flag:mqMask=blank}
* Wear the cracked porcelain mask from the bottom of the Vellum.  -> mq.m4 {if has:wintermask}
* No mask. Go in barefaced.  -> mq.m5 {do flag:mqMask=none; lean:candour+1}

# mq.m1
stagecraft(5): Black. Discreet. Nobody will remember it. That's either very clever or very boring.
@next mq.enter

# mq.m2
stagecraft(5): A hawk. In a room full of songbirds. They'll notice. They'll pretend they haven't.
@next mq.enter

# mq.m3
stagecraft(6): No expression. They'll project whatever they're afraid of onto it. That can be useful.
@next mq.enter

# mq.m4
> You put on Winter's mask, cracked down the middle, mended with gold, smiling. The ghoul's tray rattles.
pedigree(6): Every Kindred over fifty in this room knows that mask. They know whose it was. They know who broke it. Half of them were there.
{do flag:mqMask=winter}
@next mq.enter

# mq.m5
> No mask. The ghoul's mouth falls open a little.
stagecraft(7): Barefaced at a masque. It's either an insult or a declaration of war. They'll spend all night deciding which.
@next mq.enter

# mq.enter
> You go in. The waltz doesn't stop. But for a moment, all hundred masks turn toward you, like sunflowers.
> Then they turn away, and pretend they never looked.
{do task:s_masque; note:s_masque|The Gilded Court's masque, Wednesday night. Everyone who matters in Elysium is here, masked.}
@next mq.hub

# mq.hub
> The ballroom. The quartet. Chandeliers and masks.
* A tall figure by the window in a fox mask, very drunk, very loud.  -> mq.ashby {once} {if !flag:ashbyDead}
* A small woman in grey pearls and a plain grey mask, sitting alone with a notebook.  -> mq.ott {once}
* A young man in a peacock mask, holding court among art students.  -> mq.val {once} {if !flag:rouxDone}
* Someone singing "Daisy Bell", slightly flat, at the punch bowl.  -> mq.fred {once} {if !flag:freddieDone}
* Lisette, in red, unmasked, counting.  -> mq.lis {once} {if !flag:lisetteGone}
* A circle of Kindred playing a game. Someone is laughing too hard.  -> mq.game {once}
* The hostess, in silver, at the top of the room. Séverine.  -> mq.sev {once} {if alive:sev}
* Leave the masque.  -> mq.leave

// --- Ashby ---
# mq.ashby
ashby: The DIABLERIST! Here! At the masque! Oh, this is the best thing to happen to the October ball since Lady Haversham caught fire in 1953.
ashby: Is that a... what is that on your face? A mask. Of course. Everyone's in a mask. Everything's swimming. Have you met my friend? This is my friend. He's a pillar.
* "Lord Ashby. You're drunk."  -> mq.ash1
* "Introduce me to someone useful."  -> mq.ash2

# mq.ash1
ashby: I am MAGNIFICENTLY drunk. It's the only way to survive the October ball. Everyone here hates everyone else and they've all been doing it for a century. Sober, you'd notice.
ashby: ...See the little grey woman with the notebook? Ottilie. Don't talk to her. Everyone who talks to Ottilie ends up in her notebook. Everyone who ends up in her notebook ends up somewhere else.
{do flag:mqOttWarn=1}
@next mq.hub

# mq.ash2
ashby: Useful! Ha! Nobody here is useful, darling, we're decorative. But: the boy in the peacock mask is Valentin Roux. Séverine's latest pet. Collects art students. The one singing at the punch bowl is Freddie, who's lovely and terrible. And the grey one with the notebook is the only person in this room the Prince actually reads.
{do flag:mqIntro=1}
@next mq.hub

// --- Ottilie ---
# mq.ott
> She doesn't look up from her notebook. Her handwriting is tiny, perfect, in columns.
ottilie: The neonate. Thank you for coming. I've been asked to note who speaks to you, and for how long, and what they look like while they do it. You've saved me a great deal of walking.
* "Who asked you?"  -> mq.ott1
* "What are you writing about me?"  -> mq.ott2
* Sit beside her. Read the notebook upside down.  -> mq.ott3

# mq.ott1
ottilie: The Court. The Prince. Whoever reads it. I don't ask who reads it. I write it down. It's very restful.
pulse(6): Her heart did something when you asked. One beat, out of time. Someone else reads it too.
@next mq.ott4

# mq.ott2
ottilie: "Arrived 1:47. Mask: noted. Spoke first to Lord Ashby, who was drunk." That's all so far. You've been very dull. Do something interesting and I'll write it down.
@next mq.ott4

# mq.ott3
? web 11 "Read the column on the right. The one headed with initials."  -> mq.ott3ok | mq.ott3no {id mq_web}

# mq.ott3ok
> Upside down, in perfect copperplate: a column of dates. A column of names. And at the top of the right-hand column, two small initials: *T.H.* Beside Absalom Vane's name, last Sunday: *Switchyard, 11 PM. Malakor. Doctor & subject.*
web(8): She logged it. She logged his Sunday movements for T.H. Harrow knew where Absalom would be because Ottilie wrote it in a column.
> She closes the notebook. Not fast. She looks at you over her glasses.
ottilie: Reading upside down is very rude.
{do flag:knowOttilie=1; flag:sawOttLedger=1; xp:30:Upside down}
@next mq.ott4

# mq.ott3no
> Columns. Numbers. Names. Too small, too fast. She closes it before you can make anything out.
ottilie: Reading upside down is very rude.
@next mq.ott4

# mq.ott4
* "Does T.H. know you're here tonight?"  -> mq.ott5 {if flag:sawOttLedger|flag:knowOttilie}
* Leave her to her notebook.  -> mq.hub

# mq.ott5
> Her pen stops. For a moment, a very long one, Lady Ottilie Brand doesn't write anything down.
ottilie: I don't know what you mean.
ottilie: ...I have done the Court's accounts since 1902. Do you know what that's like? A hundred and twenty years of being the person in the room nobody sees. And then a man comes along who sees you. Who asks your opinion. Who says *please*.
ottilie: He promised I'd be the one they didn't manage. When the lamps come. He promised.
* "He's lying, Ottilie. He'll manage you with the rest of them."  -> mq.ott6
* "Tell the Magistrate. Before Friday. Save yourself."  -> mq.ott7
* "I'll make sure everyone sees you on Friday. In the chalk."  -> mq.ott8 {do lean:mercy-1}

# mq.ott6
ottilie: ...He wouldn't. He said please.
pulse(7): She knows. She's known since the first meeting. She's been telling herself the story so long it's become load-bearing.
{do flag:ottDoubt=1}
@next mq.hub

# mq.ott7
ottilie: The Magistrate. Ambrose. He'd... he'd burn me. Slowly. In front of everyone.
? velvet 12 "He'd burn you slower if he found out from me. Go to him first. Confessions are admissible. Ledgers are evidence."  -> mq.ott7ok | mq.ott7no {id mq_ott}

# mq.ott7ok
> She closes the notebook. She stands up. She smooths her grey skirt.
ottilie: ...The Heights. Tonight. Before I lose my nerve. Will you... no. No, I'll go alone. I've always gone alone.
{do flag:ottConfessed=1; flag:ottilieExposed=1; xp:50:Grey pearls}
@next mq.hub

# mq.ott7no
ottilie: No. No. I'll take my chances with Tom. Tom has always been very kind to me.
@next mq.hub

# mq.ott8
ottilie: Sees me. In the chalk. In front of the Court. Like a... like a specimen.
> She goes very pale. She writes something in the notebook in a shaking hand and you see what it is, upside down: your mask. And the time.
@next mq.hub

// --- Valentin ---
# mq.val
> A young man in a peacock mask, with dark curls, sketching a girl in a green dress who is sitting very still on a chaise and smiling the smile of someone who has been fed on.
valentin: The famous neonate! Oh, your face. Even under the mask. Has anyone told you that you have a remarkable architecture to your face?
* "Somebody said that to a girl called Priya."  -> mq.val1 {if flag:priya}
* "What are you drawing?"  -> mq.val2

# mq.val1
> The charcoal stops moving.
valentin: ...Did they. How funny. It's a very common compliment. Everyone says it.
{do flag:knowRoux=1; note:s_hbird|The man in the peacock mask at the masque, Valentin Roux, flinched when you said "Priya".}
@next mq.hub

# mq.val2
valentin: Faces. I collect them. Mortal faces, the young ones, before they go. One day they'll all be old and I'll still have them at twenty. That's art, darling. That's preservation.
autopsy(6): Look at the corner of the drawing pad. A small cross, on the page before. And the page before that.
{do flag:knowRoux=1}
@next mq.hub

// --- Freddie ---
# mq.fred
freddie: *...and you'll look sweet, upon the seat...* Oh, hello! A new face! Or a mask, anyway. Have some punch. It's blood and champagne, it's disgusting, it's tradition.
freddie: You're the one who ate Absalom. Oh, I'm so jealous. He was so stuck up. I always wanted to bite him and see if he tasted of starch.
* "Do you know any other songs?"  -> mq.fr1
* "Where did you learn 'Daisy Bell'?"  -> mq.fr2

# mq.fr1
freddie: Other songs! I know a Russian one. I learned it from a doctor, in Petersburg. Lovely man. I can only remember the tune.
> He hums it. It's beautiful.
web(6): A doctor. In Petersburg. Rostova's father went out for cigarettes in Petersburg in February 1993. {if task:s_pyotr}
{do flag:knowFreddie=1; flag:mqFredRussian=1}
@next mq.hub

# mq.fr2
freddie: My nanny. In Surrey. In 1899. She sang it to me every night and then I ate her. Not like that! Years later. She was very old. She asked me to.
@next mq.hub

// --- Lisette ---
# mq.lis
lisette: You came. In that. Hm. Interesting choice. I had twenty on you not coming. You've cost me twenty.
lisette: Everyone's watching you. You know that. Every single mask in this room has turned to you nine times since you walked in. I've been counting.
* "What are they waiting for?"  -> mq.lis1
* "Dance with me, Lisette."  -> mq.lis2

# mq.lis1
lisette: For you to do something gauche. Eat a guest. Insult Séverine. Fall over. They're waiting for permission to despise you.
lisette: Don't give it to them. It's the only thing they want.
@next mq.hub

# mq.lis2
> She looks at you as if you'd suggested she remove her teeth.
lisette: ...Nobody asks me to dance. I'm the hostess. The hostess doesn't dance, she counts.
lisette: Fine. One. Don't step on me. I'll know if you step on me.
> You dance. She's very good. You're not. She steers you round the ballroom like a tugboat steering a liner, and she counts under her breath the whole time, and at the end she almost smiles.
{do rel:lisette+2; flag:mqDanced=lisette}
@next mq.hub

// --- the game ---
# mq.game
> In an alcove, a circle of a dozen masked Kindred on velvet cushions, passing round a glass. A woman in a swan mask is laughing too loudly.
plume: The neonate! Join us! We're playing the Question. It's very simple. Whoever holds the glass must answer one question truthfully, or drink. You know what's in the glass.
> The glass. Thick, black, and you can smell it from here: holy water, laced with something bitter. One sip would burn like acid.
* Sit. Play.  -> mq.g1
* "No thank you."  -> mq.hub

# mq.g1
> The glass comes round. A man in a stag mask holds it out to you.
kestrel: The Question for the neonate: Did you enjoy him? Absalom. When you drank. Did you enjoy it?
* "Yes."  -> mq.g2 {do lean:candour+1}
* "No."  -> mq.g3
* Drink instead.  -> mq.g4

# mq.g2
> A silence round the circle. Then the swan laughs, delighted. Then they all do.
plume: Honest! At a masque! How shocking.
tenant: (very quietly) ...Yes. You did. I felt it. It's all right. I'd have enjoyed it too.
> Your turn to ask. The glass is in your hand.
@next mq.g5

# mq.g3
pulse(5): Your heart doesn't beat. It can't betray you. But the Gilded can smell a lie on the breath, if they're close enough, and the stag is very close.
kestrel: Liar.
> They all lean in. You have to drink after all, or lose face.
* Drink.  -> mq.g4
* "Prove it."  -> mq.g3b

# mq.g3b
kestrel: Prove it. Ha. Fine. Keep your secret, neonate. It'll keep you.
@next mq.g5

# mq.g4
> You drink. It goes down like lit gas. You don't scream. You don't let your face move. Behind the mask, your eyes are streaming.
> Around the circle, a dozen masks look at you with a new kind of respect.
{do vitae-1; comp-1; flag:mqDrank=1}
plume: Oh, very good. Very good. Your turn to ask.
@next mq.g5

# mq.g5
> The glass in your hand. A dozen masks waiting. You can ask anyone anything.
* Ask the swan: "Who in this room is working for LANTERN?"  -> mq.g6
* Ask the stag: "Where were you at 4:14 on Monday?"  -> mq.g7
* Ask the woman in lilac: "What does the Court really want me to do on Friday?"  -> mq.g8
* Ask: "Who here has walked into the sun and come back?"  -> mq.g9

# mq.g6
> The swan stops laughing. She looks at the glass. She looks across the ballroom, very quickly, at a small grey woman with a notebook.
> Then she drinks. All of it. She makes a sound like a kettle and doesn't say a word.
web(6): She'd rather drink holy water than say it. She looked at Ottilie first.
{do flag:knowOttilie=1}
@next mq.gend

# mq.g7
kestrel: At 4:14 on Monday I was in the back of Malakor's chop shop counting gold. A lady in a surgeon's mask had paid in full the night before. Malakor was very pleased. He bought us all a drink.
{do flag:maskedBuyer=1}
@next mq.gend

# mq.g8
plume: Burn. Darling. Of course. Quietly, with dignity, at dawn on Saturday, so the matter is closed and nobody has to think about what Absalom was doing at Kowalski's with a mortal doctor.
plume: Nobody wants to know. That's the secret. Nobody in this room wants to know what happened. They want it *finished*.
{do flag:mqCourtWants=1}
@next mq.gend

# mq.g9
> Nobody answers. Nobody drinks. The glass goes round the circle untouched and comes back to you.
> Then, very quietly, from the back, a man in a plain black mask you hadn't noticed:
oldkin: Lyon. 1793. The Prince of Lyon walked out of his own court at dawn and never came back. Everyone thinks he burned.
oldkin: He didn't. He walked to a gallows on Vine Street, and sat down, and has been sitting there ever since.
> When you look again, the cushion is empty.
{do flag:mqOldPrince=1}
@next mq.gend

# mq.gend
plume: Oh, the neonate plays SO well. We must have it back next year. If there's a next year.
{do rel:severine+0}
@next mq.hub

// --- Séverine ---
# mq.sev
> At the top of the ballroom, on a dais, in silver, masked in silver, Séverine. She watches you cross the whole floor toward her and doesn't move.
severine: Darling. You came. You came dressed like that. Everyone has been talking about nothing else.
@gate flag:mqMask=winter ? mq.sevW : mq.sev2

# mq.sevW
severine: ...And that mask. That mask.
> For a moment she doesn't speak at all.
severine: The Wraith girl. 1983. Freddie, and Edmund, and the curb. I was there. I laughed too.
severine: You wear it to my ball. To my face. In front of everyone who laughed.
* "Someone should remember her."  -> mq.sevW1
* "I didn't know you were there."  -> mq.sevW2

# mq.sevW1
severine: ...Yes. Someone should.
> She stands up. The quartet stops. A hundred masks turn. Lady Séverine of the Gilded Court says, to the whole ballroom, in a voice like a bell:
severine: The mask the neonate wears was broken on Reliquary Row in 1983 by members of this Court, for a bet. The Court has never apologized. The Court apologizes now.
> Nobody breathes. Nobody needs to. Then, from a corner, Lord Ashby, very drunk, very quietly, starts to clap. Nobody joins him. He keeps clapping anyway.
{do flag:sevApologisedWinter=1; rel:severine+2; xp:40:The Court apologizes}
@next mq.sevdance

# mq.sevW2
severine: No. Nobody knows who was there. That's what masks are for.
@next mq.sevdance

# mq.sev2
severine: Will you dance with me? It's customary. The hostess dances once with the guest of honour. You are, God help us all, the guest of honour.
@next mq.sevdance

# mq.sevdance
* Dance with Séverine.  -> mq.sd1
* "I don't dance, my lady."  -> mq.sd2

# mq.sd1
> She leads. Of course she leads. The quartet plays the Caruso aria, arranged for strings, slower than the record. She dances like water finding its way downhill. A hundred masks watch.
severine: (low, as you turn) They think I'm going to bite you in the middle of the floor. Shall I? It would make the evening.
* "Not tonight."  -> mq.sd3
* "Go on, then."  -> mq.sd4

# mq.sd3
severine: Not tonight. How restrained. You're turning into a terrible bore. Absalom took sixty years.
> At the end of the dance, she curtseys, deeply, which she has not done to anyone in this room in a century. The room sees it. The room never forgets anything.
{do rel:severine+2; flag:mqDanced=severine; lean:restraint+1}
@next mq.hub

# mq.sd4
> She laughs, real and surprised, and doesn't. She just puts her mouth very close to your throat for the length of one bar, and then pulls away, and the whole room exhales.
severine: Not in front of the help. Ask me again on Saturday.
{do rel:severine+2; flag:mqDanced=severine}
@next mq.hub

# mq.sd2
severine: You don't dance. At my ball. As guest of honour.
severine: ...How refreshingly rude. Go and stand somewhere, then. Stand very still. Let them stare.
{do rel:severine-1}
@next mq.hub

# mq.leave
> You leave the ballroom at three. Behind you the waltz goes on, the masks turn, the Court goes on hating itself in silk. On the stairs, a ghoul takes your mask and puts it back on the silver tray as if it had never been worn.
{do flag:masqueDone=1; task:s_masque=done; xp:80:The Masque; tick:30}
@end
`,'c_masque');
