'use strict';
/* THE NEW LORD — more personal arcs: Leo when he's forgotten you or become yours; Miller on Night Three; Séverine and Malakor follow-ups; Pemberton and Valko; Mrs. Okafor's room for Dani; Tiny on Friday */
NL.Script.npc({id:'miller',room:'luckymart',at:[2.7,4.0,-1.6],pose:'hold',label:'Miller',if:'night:3&time>=150&time<300&!flag:millerMorgue&!flag:miller3Gone'});
NL.Script.npc({id:'tiny',room:'reliquary',at:[10.05,1.75,2.6],pose:'arms',label:'Tiny',if:'night:5&time<235&!flag:tinyGone&!flag:tinyBetrayed'});
NL.Script.add(String.raw`
// =====================================================================
// LEO · when he doesn't know you (Night Two to Four)
// =====================================================================
# lf2.0 arc=leo night=2,3,4 label="Introduce yourself. Again." if=room:apt&leo:forgot prio=1
@focus leo
leo: Hi! Sorry. Do I know you? You've got a face like I should know you. Are you from the building? Are you the guy from 6C who sings? You don't look like you sing.
pulse(4): Nothing. Not a flicker. You took it all. He's kind to you the way he's kind to everyone: openly, a little nervously, with no idea.
* "I'm a friend. From work. You don't remember."  -> lf2.friend
* "Just a neighbor."  -> lf2.neighbor
* "How are you sleeping, Leo?"  -> lf2.sleep

# lf2.friend
leo: From work? Kowalski's? Oh, man. I'm so sorry. I had this weird... I lost a couple of days. Monday's just gone. Like, gone gone. The doctor says stress. I think it was the fryer fumes.
leo: You must think I'm so rude. Come in. You want tea? I've got two cups out for some reason. I always have two cups out lately. Like I'm expecting someone.
nostalgia(4): Two cups. He's setting a place for someone he can't remember. For you.
* Sit. Have the tea you can't drink.  -> lf2.tea {do lean:mercy+1}
* "I can't stay."  -> lf2.go

# lf2.tea
> You sit with him for twenty minutes while he tells you, a stranger, all about his week: the open mic, his mother, a detective who keeps asking him about Monday, which he can't remember, which is very frustrating, because she's clearly disappointed in him.
leo: Sorry. I'm doing a whole set at you. I do that when I'm nervous. I don't know why I'm nervous. You've got a calm face. A weird calm face. Like a lake at night.
{do tick:20; mem:leo:strangertea; rel:leo+1}
@end

# lf2.go
leo: Oh. Okay. See you around. At work. When it reopens. If it reopens. It's closed because of a murder. Did you hear? A murder. At my work. And I can't remember a thing.
@end

# lf2.neighbor
leo: Oh hey, neighbor! Hi! Leo. 3B. I do comedy. Badly. On Tuesdays. You should come. Everyone says that. Nobody comes.
@end

# lf2.sleep
leo: Weird question from a stranger. But: badly. I keep dreaming about being cold. Like, really cold. Like a freezer. And someone's crying in the dark next to me, and I'm saying "it's okay, it's okay," and I don't know who it is.
leo: Do you ever get dreams like that? Like they're someone else's?
* "Every night."  -> lf2.every
* "Maybe it's yours, from before you forgot."  -> lf2.before {do lean:candour+1}

# lf2.every
leo: Huh. Okay. Cool. Two weird sleepers. We should start a club.
@end

# lf2.before
leo: Before I forgot. You talk like you know what I forgot.
> He's looking at you differently now. Not remembering. Just suspecting.
leo: ...Did something happen to me? On Monday? Were you there?
* "Yes. And I took it from you. I'm sorry."  -> lf2.confess
* "No. I just meant everyone forgets things."  -> lf2.lie

# lf2.confess
> He sits down. He holds Gerald the cactus in his lap like a cat.
leo: You took it. How do you take a Monday?
leo: ...No. Don't. Don't tell me. If you took it, you had a reason. I'm going to decide you had a reason, because otherwise I'm going to have to be very scared of you, and I don't want to be scared of someone with a face like a lake.
{do mem:leo:confessedwipe; lean:candour+1}
@end

# lf2.lie
leo: Yeah. Yeah, that's true. Everyone forgets. My grandma forgot the whole of the eighties. She said it was a blessing.
@end

// =====================================================================
// LEO · when he's yours (thrall or ghoul)
// =====================================================================
# lt2.0 arc=leo night=2,3,4,5 label="\"How are you, Leo?\"" if=room:apt&leo:thrall prio=1
@focus leo
> He's already standing when you come in. He's always already standing. He's been waiting by the door. There's a cup of tea on the table that you'll never drink and it's still hot, because he's made it fresh every half hour since sunset.
leo: You came. You came! I knew you'd come. I didn't know. I hoped. I knew.
pulse(5): Heart racing, pupils huge. He's happy the way a dog is happy. Completely. Without thinking. That's what you did.
@gate night:5 ? lt2.five : lt2.hub

# lt2.hub
* "Have you eaten today?"  -> lt2.eat
* "Did you go to your set?"  -> lt2.set
* "Leo. What do you want? For yourself."  -> lt2.want
* "You don't have to wait for me."  -> lt2.wait

# lt2.eat
leo: Eaten? I... I had some cereal. At three. Or yesterday. I've been busy. I've been tidying. I've been thinking about what you might need. I made a list.
> The list: *batteries, black curtains, a second key, something to make you laugh*.
{do mem:leo:list}
@end

# lt2.set
leo: My set? Oh. No. I didn't go. I thought you might come round. I didn't want to miss you.
leo: It's okay. It's just comedy. It's not important. You're important.
tenant: There it is, child. The sound of a man giving up the only thing that was his. You'll hear it a lot, if you keep thralls. I heard it for three hundred years.
{do mem:leo:missedset; lean:mercy-1}
@end

# lt2.want
leo: For myself? I want... I want you to be happy. I want to be useful. I want...
> He stops. Something crosses his face, very far down, like a fish under ice.
leo: ...I used to want to do an hour. A whole hour, at the Lantern Room, my name on the poster. That's stupid. That's so small. That's nothing, next to you.
* "It's not stupid. Do it. For me."  -> lt2.dohour {do lean:mercy+1}
* "It is small. You've got bigger things now."  -> lt2.small {do lean:mercy-2}

# lt2.dohour
leo: For you? Okay. Okay! For you I'll do anything. I'll write the hour. I'll do it for you.
pulse(4): It's still for you. It'll always be for you now. But at least it's an hour.
{do flag:leoHour=1; mem:leo:hour}
@end

# lt2.small
leo: Yeah. You're right. You're right. Bigger things.
> He looks at the joke notebooks stacked on the coffee table and then he puts them, carefully, in the bin.
{do flag:leoBinned=1; mem:leo:binned}
@end

# lt2.wait
leo: Don't have to? I want to. I like waiting. I like knowing you're coming. It's the best part of my day.
@end

# lt2.five
leo: Tonight's the night, isn't it. I can feel it. Like a storm. Take me with you. Please. I'll stand at the back. I'll hold your coat. I'll do anything.
* "Stay here, Leo. That's an order."  -> lt2.stay
* "Leo. I'm letting you go. After tonight, you're free."  -> lt2.free {do lean:mercy+2}
* "Come, then."  -> lt2.come

# lt2.stay
leo: An order. Okay. Okay. I'll stay. I'll keep the tea hot.
@end

# lt2.free
leo: Free? From what? I don't want to be free. Free's lonely. Free's being a guy with a cactus and five minutes about his landlord.
leo: ...That was me, wasn't it. That's who I was.
> It'll take a month. Maybe more. The blood will fade and he'll wake up one morning and be furious and heartbroken and himself.
{do flag:leoFreed=1; mem:leo:freed}
@end

# lt2.come
leo: Really? Really! I'll get my coat. I'll get two coats.
{do flag:leoAtTribunal=1}
@end

// =====================================================================
// MILLER · Night Three, at the Lucky Mart
// =====================================================================
# ix3b.0 arc=miller night=3 label="\"They took you off the case.\"" if=room:luckymart&actor:miller
@focus miller
> Miller's in her coat at the window counter, with two coffees: one for her, one going cold opposite her, for nobody. She doesn't look up.
miller: Noon today. Harrow pulled the Kowalski file. Federal jurisdiction. Some task force on "blood-borne pathogens". I'm off it. I'm off everything. The Captain's given me a parking-fine review. Eleven hundred parking fines.
miller: I've been sitting here for an hour working out how many parking fines Ray would've had to review before they let him back on Homicide. He'd have stolen a car on the second day out of spite.
* Sit in the chair with the cold coffee.  -> ix3b.sit
* "Harrow's protecting something."  -> ix3b.harrow
* "Give it up, Ines. Before they hurt you."  -> ix3b.giveup

# ix3b.sit
> You sit. You don't touch the coffee. She looks at it, and then at you.
miller: That was Ray's. I buy him one. Every night. Since 2019. Tariq thinks I'm mad. He's right.
miller: You can have it. You won't drink it either. That's two of you now.
{do mem:miller:raycoffee; rel:miller+1}
@next ix3b.hub

# ix3b.harrow
miller: Protecting. Yes. That's the word. You don't pull a dead butcher's file for "blood-borne pathogens". You pull it because there's something in it with your name on.
miller: I made copies. Before noon. I always make copies. Ray taught me that. "Ines, the day you don't make a copy is the day they take the original."
{do flag:millerCopies=1; mem:miller:copies}
@next ix3b.hub

# ix3b.giveup
miller: Give up. Everybody says that like it's a place you can go. Like it's a little town on the coast with a pier.
miller: I've been "giving up" since 2011. I'm terrible at it. I keep getting up in the morning.
@next ix3b.hub

# ix3b.hub
* "What's in your copies?"  -> ix3b.copies {once} {if flag:millerCopies}
* "Tonight, at three, there'll be two cops here shaking down Tariq."  -> ix3b.racket {once} {if flag:tariqRacket&!flag:racketDone}
* "Go home, Ines."  -> ix3b.bye

# ix3b.copies
miller: Shipping dates from Kowalski's. Rendering, every Wednesday. Seven dates that match my seven missing. And a signature on the receipts. "E.R." in a doctor's handwriting.
miller: I'm going to St. Jude's tomorrow. Basement. Without a warrant. I'll lose my badge. I've decided I don't care.
{do flag:millerToMorgue=1}
@next ix3b.hub

# ix3b.racket
miller: Dale and Pruitt. I know. I've known for a year. I can't prove it. Tariq won't make a statement. He's scared of the inspector.
miller: If something happens to them tonight, I'd rather not be here to see it. I'd rather be able to say I wasn't here.
* "Then don't be here."  -> ix3b.leave
* "Stay. Film it. Then you can prove it."  -> ix3b.film {do flag:millerFilms=1}

# ix3b.leave
miller: Right. Right. I'll go and review some parking fines.
{do flag:miller3Gone=1}
@leave miller

# ix3b.film
miller: Film it. On my phone. Like a teenager.
miller: ...Ray would have. Ray filmed everything. Okay. I'll be in the car across the road with my phone out.
@next ix3b.hub

# ix3b.bye
miller: Home. Yeah. Home's where the files are. Night.
{do flag:miller3Gone=1}
@leave miller

// =====================================================================
// SÉVERINE · Night Two, the report on Malakor
// =====================================================================
# sx2r.0 arc=severine night=2,3 label="\"I have a word about Malakor, my lady.\"" if=room:vip&alive:sev&flag:sevTaskMalakor&!flag:sevReported prio=2
@focus severine
severine: A word. About the butcher. Go on. I've been looking forward to this all evening. It's the only thing I've looked forward to since 1968.
* "A generator. For light on Platform 0."  -> sx2r.gen {if flag:malakorGenerator}
* "He's building you. Out of spare parts. It already sneers."  -> sx2r.joke
* "Nothing worth telling."  -> sx2r.nothing {do lean:loyalty+1; rel:malakor+1}
* "He built the light that killed the Sheriff."  -> sx2r.lance {if flag:malakorAdmitLance} {do lean:loyalty-1}

# sx2r.gen
severine: A generator. Light. On Platform 0. Independent of the city. Of the *Court's* city.
severine: He means to stop paying us for electricity. Clever butcher. Very well. That's worth knowing. You've earned a little favour.
{do flag:sevReported=gen; rel:severine+1; mem:severine:report}
@end

# sx2r.joke
> She looks at you for a very long moment. Then she laughs, behind her hand, like a girl in a box at the Opéra.
severine: He said that. He said exactly that, didn't he. He's been saying that since 1931.
severine: Go away. I can't bear to be amused by Malakor. It undoes decades of work.
{do flag:sevReported=joke; rel:severine+1; rel:malakor+1}
@end

# sx2r.nothing
severine: Nothing. You went down to his shop and came back with nothing. Either you're bad at spying or good at loyalty. I'll find out which. I always do.
{do flag:sevReported=nothing}
@end

# sx2r.lance
> The candles in the bone chandelier go out. Then, one at a time, they come back on.
severine: The butcher built it. Of course he did. Who else in this city could build a light that kills a Sheriff?
severine: Thank you. That will matter on Friday. That will matter a great deal.
{do flag:sevReported=lance; flag:sevKnowsLance=1; rel:severine+2; rel:malakor-2; mem:malakor:betrayed}
@end

// =====================================================================
// PEMBERTON AND VALKO · Night Three, in the car
// =====================================================================
# pv3.0 arc=pemberton night=3,4 label="\"Pemberton. Valko's with us now.\"" if=flag:valkoAlly&!flag:pemDead prio=3
@focus pemberton
pemberton: Mr. Valko. Yes. He's sitting on the roof of the car. He's been sitting on the roof of the car since Wednesday. I've asked him to come in. He says he prefers the weather.
pemberton: We go back a long way, Mr. Valko and I. Seventy years and twenty-two. He held my hand once. In a container yard. While the Sheriff fed me.
pemberton: He's never mentioned it. I've never mentioned it. It's the most intimate thing either of us has ever done and we've been politely ignoring it since 1977.
* "Maybe you should mention it."  -> pv3.mention
* "Some things are better left."  -> pv3.leave

# pv3.mention
> He winds down the window. Rain comes in.
pemberton: Mr. Valko. Pier Nine. 1977. I never thanked you.
> A long silence from the roof.
valko: (from above) ...You were bleeding on my coat. I liked that coat.
pemberton: I'll buy you a new one.
valko: (from above) It was a very good coat.
> Pemberton winds the window back up. He's smiling. You've never seen him smile.
{do rel:pemberton+1; rel:valko+1; mem:pemberton:valko}
@end

# pv3.leave
pemberton: Yes. Quite right. We're very British about it, the two of us. He's not British. I've decided he is.
@end

// =====================================================================
// MRS. OKAFOR · Dani's room
// =====================================================================
# ox2r.0 arc=okafor night=2,3,4 label="\"Can I see Dani's room?\"" if=room:apt&flag:met404&mem:okafor.dani
@focus okafor
okafor: Her room. Nobody's been in. Not since August. Not even me, except to dust.
> She opens a door you hadn't noticed. A small room. A single bed with a duvet with horses on it, from when she was twelve and refused to give it up. Veterinary textbooks. A poster of a band you don't know. A corkboard with photos, a rota from St. Jude's, a postcard from the coast.
> On the desk, a mug with a heart drawn on it in marker. And a library book: *The Idiot*, Dostoevsky. Overdue since September.
nostalgia(6): *The Idiot*. A cot in a white basement. You were reading it. Somebody on the next cot asked to borrow it when you'd finished.
* Pick up the book.  -> ox2r.book
* Look at the corkboard.  -> ox2r.board
* "Thank you for letting me see it."  -> ox2r.bye

# ox2r.book
> A library sticker: Port Vellum Central, Halloran Street branch. Inside the cover, in pencil, two handwritings. The first: *C.M. — finished Pt 1, it's so sad, you'll hate it.* The second, rounder, with a little heart over the i: *Dani says DON'T tell me the ending.*
> You. Casey Morrow. You lent her the book on the cots. She was halfway through.
okafor: She brought that home in July. She said a friend at the trial lent it to her. A person who read Russian novels and was nice to her. She said it was the saddest book she'd ever read and she was going to finish it anyway.
{do flag:daniBook=1; mem:okafor:book; sync-1}
* "I was that friend."  -> ox2r.friend {do lean:candour+1}
* Say nothing.  -> ox2r.silent

# ox2r.friend
okafor: You. You were... you were on the cots too.
> She looks at you for a very long time. Not angry. Not anything. Just looking.
okafor: Then you were the last kind person she met. Thank you for being kind to her. I mean it. Sit. Sit. I'm going to make tea you won't drink.
{do rel:okafor+2; mem:okafor:friend}
@end

# ox2r.silent
@end

# ox2r.board
> The rota. Dani on nights, Monday to Thursday. The postcard: a beach on the coast, *wish you were here, J.* Photos: Dani at sixteen with a bandaged pigeon; Dani with her mother at a wedding; Dani in a hospital lanyard laughing at someone off-camera.
okafor: That's the doctor. Rostova. Off the side of the picture. Dani took that one. She said, "Mom, she's very intense, but she does her rounds at four in the morning just to make sure everyone's breathing."
web(5): Rostova did rounds at four in the morning. On the patients she was killing.
@end

# ox2r.bye
okafor: You're welcome. Close the door, please. She hated a draught.
@end

// =====================================================================
// TINY · Friday, on the door for the last time
// =====================================================================
# kx5.0 arc=tiny night=5 label="\"Last night on the door, Tiny?\"" if=room:reliquary&actor:tiny
@focus tiny
tiny: Last night. Yeah. The club's empty. Everyone's gone down to the platform. I'm standing on a door with nobody to let in.
tiny: Nine years. Forty-one thousand two hundred and something faces. I can still see every one of them. I'll see them on my deathbed. It's a curse, a memory like this. Nobody tells you.
@gate flag:tinyWitness ? kx5.wit : kx5.nowit

# kx5.wit
tiny: I'll come down when you call. I'll say my piece. Then I'm putting this clicker in the bin and walking up Reliquary Row and never looking back.
tiny: Mom's knitting me a scarf for the garden center job. It's orange. Garden centers are very orange.
@next kx5.end

# kx5.nowit
tiny: I'm not coming down. Sorry. I like you. Not that much. I'll be up here, holding the door, in case anybody needs to run.
tiny: That's the job, really. Not keeping people out. Keeping the way out open.
@next kx5.end

# kx5.end
* "Thank you, Tiny."  -> kx5.thanks
* "Henry. Thank you."  -> kx5.henry {if mem:tiny.henry}

# kx5.thanks
tiny: Yeah. You too.
@end

# kx5.henry
> He looks at you. He looks at the empty street. He looks at the floor.
tiny: ...Yeah. Okay. You can have that one. Once.
{do rel:tiny+1}
@end
`,'c_more1');
