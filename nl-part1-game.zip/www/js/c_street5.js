'use strict';
/* THE NEW LORD — street events, part five: the consequences come looking for you */
NL.Script.add(String.raw`
# ev.gaston street=4,5 if=flag:gastonFree
> At the Greyhound station on Vine Street, at three in the morning, a man of sixty in an impeccable coat is sitting on a plastic bench with a single suitcase and a bowler hat on his knee. Gaston. His hands are shaking already.
gaston: Oh. Oh, it's you. I'm getting the four-ten. To Columbus. Then Dayton. Then a taxi.
gaston: I'm sixty-three already. I can feel it. My knees started on Wednesday. It's marvellous. I'd forgotten knees.
* Sit with him until the bus comes.  -> ev.gs1
* "Good luck, Gaston."  -> ev.gs2

# ev.gs1
> You sit with him. He talks about his daughter. Her name is Claire. She's a dental hygienist. The baby is called Margaux, with an x. He's never seen a photograph. He hasn't asked. He wants to see her face for the first time in person.
> The four-ten comes. He gets on it slowly, holding the rail. At the top of the steps he turns and lifts the bowler hat to you, very formally, the way they did in the Court.
{do comp+2}
@end

# ev.gs2
gaston: Thank you. Thank you. Nobody has said good luck to me since 1983.
@end

# ev.kyle street=3,4,5 if=seen:ev.kid9
> Halloran Street, half past midnight. Four boys of nine or ten, in Sixers jerseys, on bikes, in a row, waiting. One of them points at you.
kid: THAT'S the vampire. I TOLD you.
> The other three stare at you with their mouths open.
* Show them the teeth. Just a flash.  -> ev.ky1 {do lean:candour+1}
* "Go home, Kyle. It's half past twelve."  -> ev.ky2
* Shrug. "I'm a goth."  -> ev.ky3

# ev.ky1
> You show them. Just for a second. One of them screams and falls off his bike. One of them cheers. Kyle looks at the others like he's just won the World Series.
kid: I TOLD you. I told you, Jayden.
> They pedal away down Halloran Street shrieking, absolutely delighted. Nobody will ever believe them. They know that. They don't care.
{do comp+1}
@end

# ev.ky2
kid: Grandma's asleep. ...Fine. FINE. Come on, guys.
> They go. Kyle looks back at the corner and waves.
@end

# ev.ky3
kid: You are NOT a goth. You said. You SAID.
> His friends laugh at him. He's furious. You feel quite bad about it.
@end

# ev.ollie street=4,5 if=flag:ollieSafe
> On the Vellum footbridge, by the padlocks, a young man is tying something to the railing. A bunch of flowers from the Lucky Mart, still in the cellophane. He sees you and goes red.
boyfriend: Oh. Oh, hi. It's you. Ollie. From... from the other night.
boyfriend: I'm not... I'm not going to... I'm putting these here. For the version of me who nearly did. That's what my counsellor said to do. Is that stupid?
* "It's not stupid."  -> ev.ol1
* "How are you, Ollie?"  -> ev.ol2

# ev.ol1
boyfriend: Okay. Okay. Thanks. I've got a job interview on Monday. A warehouse. Nights. I like nights now. Is that weird?
{do comp+2}
@end

# ev.ol2
boyfriend: Better. Not good. Better. I'm sleeping in a bed. My sister's spare room. She cried when I turned up. She'd been ringing hospitals.
boyfriend: Thank you. For the bridge. I don't know who you are.
{do comp+2}
@end

# ev.brann street=4,5 if=flag:brannName&!flag:ashbyApologised&!flag:ashbyDead w=3
> Reliquary Row, outside the club. A woman in her seventies in a good coat, standing very still by a lamp post, with a sports bag at her feet. You know her. Mrs. Brannigan. She's watching Tiny's door.
pulse(5): Her heart is steady. Very steady. A woman who's decided something. The bag is long and heavy and the shape of it is wrong for groceries.
* Go and stand beside her.  -> ev.bn1
* Leave her. It's her choice.  -> ev.bn2 {do lean:mercy-1}

# ev.bn1
brannigan: You. You gave me his name. Edmund Ashby. I looked him up. He was a fencing master. He's on a list of the Prince's household from 1923. They have a portrait of him in the Courthouse.
brannigan: He's in there. Tonight. I saw him go in.
* "Mrs. Brannigan. If you go in there with that, they'll kill you before you get down the stairs."  -> ev.bn3
* "Let me bring him out to you. Let him say it to your face."  -> ev.bn4 {if !flag:ashbyDead}

# ev.bn3
brannigan: I know. I'm seventy-four. I've had a good life with Patrick, and two bad years without him.
? velvet 11 "Patrick wouldn't want you to have two bad years and then a terrible last night."  -> ev.bn5 | ev.bn6 {id ev_bnv}

# ev.bn5
> She stands very still for a long time. Then she picks up the bag and walks away down the Row, slowly, not looking back. At the corner she stops and drops it in a dumpster. It makes a heavy sound.
{do flag:brannStood=1; lean:mercy+1}
@end

# ev.bn6
brannigan: You didn't know him. Don't tell me what Patrick would want.
> She picks up the bag. She crosses the road toward the club.
* Stop her. Gently. Hold her arm.  -> ev.bn7
* Let her go.  -> ev.bn2

# ev.bn7
> You take her arm. She's tiny. She hits you with her handbag, once, very hard, and then she sags against you and cries into your coat on the sidewalk of Reliquary Row while the queue for the club looks the other way.
{do flag:brannStood=1; comp+1}
@end

# ev.bn4
> You go in. You find Ashby. You tell him who is outside. He goes white.
> He comes out. He stands in front of her on the sidewalk in his good coat and takes off his hat. He doesn't say much. He doesn't need to. She looks at him for a long time and then she picks up her bag and goes home, and he stands there in the rain until you lead him back inside.
{do flag:ashbyApologised=1; flag:brannStood=1; rel:ashby+1}
@end

# ev.bn2
> You walk on. Behind you, after a while, you hear Tiny's voice say "sorry, love, private party," very kindly, and a long argument, and then nothing.
@end

# ev.nightwatch street=4,5 if=flag:forumDown
> A group of young men in camouflage jackets outside the Anchor, arguing loudly about something on a phone. One of them has a crossbow from a sports shop in a gym bag.
drunk2: ...just GONE. The whole site. Nightwatch, gone. Daybreak's account deleted. Something got to her. Something got to Daybreak.
> They see you. They don't recognize you. They just see someone in a coat walking past at three in the morning.
* Walk past. Say nothing.  -> ev.nw1
? stagecraft 9 "Stop and ask them, very seriously, if they've seen a big dog."  -> ev.nw2 | ev.nw1 {id ev_nw}

# ev.nw1
> You walk past. One of them says "evening" without looking up. You say "evening" back. That's all.
@end

# ev.nw2
> They stare at you. One of them says "what kind of dog?" You describe Valko. They go very pale. They go back into the Anchor and lock the door.
{do comp+1}
@end

# ev.priya street=4,5 if=flag:priya&flag:newbTaught|flag:priya&flag:newbSafe
> Behind the Golden Dragon, by the bins. A young woman crouched on a crate, very still, watching a man smoke by the kitchen door. Priya. She sees you and holds up one finger: wait.
> The man finishes his cigarette and goes in. She lets him. She climbs down off the crate and comes over.
priya: I was going to. I was going to, and then I thought: no. Not him. He's tired. He's got a kid, you can see it in how he stands. I'll find a drunk.
priya: Is that... is that right? Is that how it works?
* "That's exactly how it works."  -> ev.py1
* "There's no right. Only what you can live with."  -> ev.py2

# ev.py1
priya: Okay. Okay. I'm getting the hang of it. I haven't eaten a cat since Tuesday.
{do comp+1}
@end

# ev.py2
priya: What I can live with. That's... that's quite a lot, actually. That's forever.
@end
`,'c_street5');
