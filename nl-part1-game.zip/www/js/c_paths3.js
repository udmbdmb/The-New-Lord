'use strict';
/* THE NEW LORD — Night 2, other ways through: things you can say to Miller and to Mother Soot, and what they cost later */
(function(){const O=NL.Script.opt;
O('m2.hub','* "It was me. In the freezer. I was there when the Sheriff died."  -> p3.conf {once} {if !flag:millerConfess}',3);
O('m2.hub','* "Leo Pruitt is alive. I\'ve seen him. Tonight."  -> p3.leo {once} {if alive:leo&!flag:leoGoneTown}',3);
O('m2.hub','? apex 10 "Detective. Walk away from this case. For your own sake."  -> p3.warn | p3.warnNo {id p3_warn} {once} {red}',3);
O('m2.hub','* "When did you last sleep, Miller?"  -> p3.sleep {once}',3);
O('so.hub','* "Pay you in a memory, Mother. One of mine. From before."  -> p3.mem {once} {if !flag:sootMemPaid}');
O('so.hub','* "Tell me about the Sheriff. Not the Court\'s version. Yours."  -> p3.vane {once}');
O('so.hub','? echo 11 "Listen with her. Put your ear to the pipe and tell her what you hear."  -> p3.pipe | p3.pipeNo {id p3_pipe} {once}');
})();
NL.Script.add(String.raw`
# p3.conf
> Miller doesn't move. The rain keeps coming down on the alley and on her hat and on the case file in her hand.
miller: You were there.
miller: Okay. Okay. I'm going to need you to say the next part very carefully, because I'm a police officer and I'm standing two feet from you and I'm off the clock, and I'm tired, and I haven't decided yet which of those things matters most.
* "He was dying when I got there. Somebody shot him. I didn't."  -> p3.conf1
* "I killed him. He'd have killed me."  -> p3.conf2
* "I don't remember. That's the truth. I don't remember."  -> p3.conf3

# p3.conf1
miller: Shot. With what? There was no bullet. No casing. No blood. There was dust and a meat hook.
? autopsy 9 "A UV weapon. Long. From the doorway. The ash pattern fans away from the door."  -> p3.conf4 | p3.conf5 {id p3_conf}

# p3.conf4
> She looks at you for a very long time. Then she gets out her notebook and draws the freezer floor, very fast, from memory. She draws a fan of dust. She draws the door.
miller: It does fan. Away from the door. I noticed that Monday. I thought it was the extractor.
miller: You'd better not be lying to me. You'd better not be lying to me, because I'm going to go and look.
{do flag:millerConfess=shot; rel:miller+2; lean:candour+1; fact:miller:seven}
@end

# p3.conf5
miller: A UV... what? A sunlamp? Listen to yourself.
> But she writes it down.
{do flag:millerConfess=shot; rel:miller+1; lean:candour+1}
@end

# p3.conf2
> Her hand moves to her hip. It stops there. It doesn't go any further.
miller: You killed him.
miller: There's no body. There's no weapon. There's no blood. There's dust. You know what the DA does with a confession to killing a pile of dust? He laughs. Then he has me tested.
miller: ...Why are you telling me this?
* "Because you'd find out. And I'd rather you heard it from me."  -> p3.conf6
* "Because nobody else will believe it either."  -> p3.conf7

# p3.conf6
miller: From you. Okay.
miller: I don't know what you are. I don't think I want to know. But that's the first honest thing anybody's said to me in the Marrow Ward in two months, and I'm going to hold onto it, and you're going to stay where I can find you.
{do flag:millerConfess=killed; rel:miller+1; lean:candour+2; heat+1}
@end

# p3.conf7
miller: No. They won't. You know what that makes you? That makes you the only person in this city I can't arrest and can't ignore.
{do flag:millerConfess=killed; lean:candour+1; heat+1}
@end

# p3.conf3
miller: You don't remember.
miller: Everybody I talk to in this neighborhood doesn't remember. The guy at the bus stop doesn't remember. The woman in 404 doesn't remember her own phone call. Seven people disappear and the whole Ward has amnesia.
miller: Don't you dare be one more.
{do flag:millerConfess=forgot; rel:miller-1}
@end

# p3.leo
miller: Alive. Leo Pruitt. You've *seen* him.
> She has her notebook out before you've finished the sentence.
miller: Where? Is he hurt? His mother's called the precinct four times. His uncle's a cop, did you know that, and he won't talk to me about it, which is... where is he?
* "He's safe. He's scared. Give him a few days."  -> p3.leo1
* "He's still doing stand-up. Open mic at the Lantern Room, any night they'll have him."  -> p3.leo2
* "I can't tell you where. But I'll get him to call his mother."  -> p3.leo3

# p3.leo1
miller: A few days. A missing person, and you want me to give him a few days.
miller: ...Okay. Okay. Because you're the only person who's told me he's breathing. Three days. Then I come looking.
{do flag:millerLeo=wait; rel:miller+1; promise:leocall:Make sure Leo is all right, for Miller.}
@end

# p3.leo2
miller: On stage. He's... he's doing *comedy*? His mother thinks he's in a ditch and he's doing a tight five at an open mic?
> She laughs, once, hard, like something breaking.
miller: Okay. Okay. I'll be at the back. I won't arrest him. I might heckle.
{do flag:millerLeo=gig; rel:miller+1}
@end

# p3.leo3
miller: Call his mother. Tonight.
miller: You do that, and I'll stop looking for him. Not for you. For her.
{do flag:millerLeo=call; rel:miller+2; promise:leocall:Get Leo to call his mother.}
@end

# p3.warn
> You let a little of the thing in your blood up into your voice. Not much. The weight of a hand on a shoulder.
> She takes a step back. She doesn't know why.
miller: ...For my own sake.
miller: Is that a threat? It sounded like a threat. It felt like a threat. I've been threatened by the best. This one felt like somebody's grandfather telling me to put my coat on.
miller: I'm not walking away. But I'll... I'll be careful. That's the most you're getting.
{do flag:millerWarned=1; rel:miller-1; lean:pride+1}
tenant: (quietly) That was my voice. You used my voice on her. I'm not sure how I feel about it.
@end

# p3.warnNo
miller: Walk away. For my own sake.
miller: Two months, seven people, and *you're* the one telling me to walk away. You know what that does? That makes me want to look at you a lot harder.
{do rel:miller-2; heat+1}
@end

# p3.sleep
miller: Sleep.
miller: What day is it? Tuesday. I slept Sunday. In the car. Outside the Rookery, for about forty minutes, until a man knocked on the window to ask if I was dead.
miller: Why do you care when I last slept?
* "Because you'll make a mistake. And it'll be the one that gets you killed."  -> p3.sleep1
* "Because I can't. And I miss it."  -> p3.sleep2

# p3.sleep1
miller: Everybody's so worried about me getting killed this week. It's very touching. It's very suspicious.
> But she yawns. A real one. She looks furious about it.
{do rel:miller+1; flag:millerSlept=1}
@end

# p3.sleep2
> She looks at you. Really looks. The grey skin. The not-breathing.
miller: You can't sleep. Like... at all?
miller: That's... okay. I'm going to go home and sleep for five hours. Out of spite. For both of us.
{do rel:miller+2; flag:millerSlept=1; lean:candour+1}
@end

# p3.mem
soot: A memory. From before. Yes. Those are the dearest thing anyone ever pays me. Most of you lot have so few left.
soot: Put your mouth to the pipe. Say it in. Once it's in the pipe, it's mine. You'll still know it happened. You won't remember it.
* Give her the smell of your mother's kitchen on a Sunday.  -> p3.mem1
* Give her the first time you saw the sea.  -> p3.mem2
* Give her the night you were bitten. All of it.  -> p3.mem3
* "I've changed my mind."  -> p3.mem4

# p3.mem1
> You say it into the pipe. Onions. Something burning a little. A radio. Somebody singing along to it wrong.
> And then it's gone. You know your mother cooked on Sundays. You know there was a radio. You can't smell it. You'll never smell it again.
soot: Thank you. That's a good one. That's a very good one. I'll keep it warm.
{do flag:sootMemPaid=kitchen; rel:soot+2; comp-2:A Sunday kitchen; xp:30; mem:soot:kitchen}
tenant: (very quietly) I'd have given her mine instead, if I'd known how. I've got hundreds of kitchens. I'd have given her Ajaccio.
@end

# p3.mem2
> You say it into the pipe. A parking lot. Grey water. Wind so cold it made you cry and you pretended it was the wind.
> And then it's gone. You know you've seen the sea. You can't see it.
soot: Ah. The sea. Everybody gives me the sea, in the end. I've got four hundred seas. Yours is very grey. I like it best.
{do flag:sootMemPaid=sea; rel:soot+2; comp-1:The first sea; xp:30}
@end

# p3.mem3
> You say it into the pipe. All of it. The clinic. The needle. The freezer. The Sheriff's throat. The light.
> And then it's gone. Not the facts. The *feeling*. The terror of it. You know it happened the way you know the date of a war.
soot: ...Oh. Oh, child. You gave me the worst one. On purpose.
soot: That's not payment. That's a gift. I'll keep it. You won't have to.
{do flag:sootMemPaid=bite; rel:soot+3; comp+2:A weight off; xp:40; sync-2}
tenant: You gave her the freezer. You gave her the part with me in it. ...I'm still here. I can still feel it. You can't. That's lonely. That's very lonely.
@end

# p3.mem4
soot: Changed your mind. Good. Keep them. You'll want them when you're old.
@end

# p3.vane
soot: Mine. Hm.
soot: Absalom Vane came down the stairs to my cistern for the first time in 1888, three weeks after he arrived, with his hat in his hands. He wanted to know who in the Ward was worth knowing. He paid me in Corsican. A lullaby, in Corsican, that his mother sang. Nobody had ever paid me in a song.
soot: He came every year after. Once a year. In December. Always with something: a song, a smell, a name. He never asked for anything twice. He was the only Sheriff who ever said please on my step.
soot: The Court thinks he was cold. He was the warmest thing that ever came down those stairs. He just had nowhere to put it.
* "Why are you telling me this?"  -> p3.vane1
* "Do you still have the lullaby?"  -> p3.vane2

# p3.vane1
soot: Because he's in you. And he can hear me. And I never once told him.
{do sync+2; rel:soot+1}
tenant: (after a long silence) ...She never told me. A hundred and thirty-six Decembers, and she never told me.
@end

# p3.vane2
soot: I have everything. I keep everything. That's my curse and my trade.
> She puts a bone microphone to your ear. Through it, very faint, a woman's voice, young, in a language that's almost Italian and isn't, singing the same six bars over and over.
> Inside you, something goes completely still.
tenant: Mamma.
{do sync+3; rel:soot+1; flag:heardLullaby=1; xp:20}
@end

# p3.pipe
> You put your ear to the pipe beside hers. The cold of it goes into your skull.
> The whole Ward. A woman laughing on Halloran Street. A dog. A car alarm. And somewhere, under all of it, very clearly, a man's voice in an expensive car with the window up: *"Friday. Make sure the Magistrate sees the lance."*
* "That was Ashby's voice."  -> p3.pipe1
* "I don't know who that was."  -> p3.pipe2

# p3.pipe1
soot: It was. You've got good ears for a fledgling. Good ears and a short life, usually. Keep them.
{do flag:heardAshby=1; rel:soot+2; xp:25:Good Ears}
@end

# p3.pipe2
soot: No? I do. That's why I live down here and you live up there.
{do rel:soot+1}
@end

# p3.pipeNo
> Cold. Water. Your own heartbeat, except you haven't got one. Nothing.
soot: It takes forty years. Don't feel bad. It took me sixty.
@end

# p3c.mil arc=miller night=3,4,5 label="\"About what I told you on Tuesday.\"" if=flag:millerConfess prio=3
@focus miller
@gate flag:millerConfess=shot ? p3c.mil1 : p3c.mil0

# p3c.mil0
@gate flag:millerConfess=killed ? p3c.mil2 : p3c.mil3

# p3c.mil1
miller: The fan pattern. Yeah. I went and looked. I took a lab tech from the Ninth who owes me forty bucks. She says the ash is consistent with a "very intense, very brief exposure to a broad-spectrum light source". She says there's no such thing outside of a semiconductor plant.
miller: So either you're lying to me, or somebody in my city has a weapon that doesn't exist. I'm leaning towards the weapon. I hate that I'm leaning towards the weapon.
* "Find out who paid for it. Start with St. Jude's."  -> p3c.mil4
* "Drop it, Miller. That weapon's pointed at people like me. Not you."  -> p3c.mil5

# p3c.mil4
miller: St. Jude's. The clinic list. Of course. It's always the clinic list.
{do rel:miller+1; flag:millerLance=1}
@end

# p3c.mil5
miller: People like you. Okay. Then who's it pointed at next, after you?
> She doesn't wait for an answer. She doesn't need one.
{do rel:miller+1; flag:millerLance=1}
@end

# p3c.mil2
miller: I've been thinking about what you said. That you killed him.
miller: I went to the DA's night clerk on Wednesday and said, hypothetically, if someone confessed to killing a man who turned to dust. She said, "Ines, go home." So I didn't. I went to church. First time since Mateo. I sat at the back and didn't pray. I just sat there.
miller: I don't know what to do with you. I'm a cop. You confessed. There's no crime. I can't make that come out even.
* "Then don't. Leave it uneven."  -> p3c.mil6
* "Arrest me, then. See what happens."  -> p3c.mil7

# p3c.mil6
miller: Uneven. Yeah. I've got a whole life that doesn't come out even. One more won't hurt.
{do rel:miller+2; lean:mercy+1}
@end

# p3c.mil7
> She looks at you. She looks at the cuffs on her belt. She looks at the sky, which is going grey at the edges.
miller: See what happens. No. I know what happens. You'd let me. That's the worst part. You'd let me and you'd sit in a cell till sunrise.
miller: Go home. Wherever home is. Go home, and don't confess to me again.
{do rel:miller+1; heat-1}
@end

# p3c.mil3
miller: You still don't remember?
* "I remember a bit more. Every night."  -> p3c.mil8
* "No."  -> p3c.mil9

# p3c.mil8
miller: Okay. Okay. When you remember all of it, I'll be at the Lucky Mart at two. Every night. I'm always at the Lucky Mart at two.
{do rel:miller+1}
@end

# p3c.mil9
miller: No. Course not. Nobody does.
@end

# p3c.leo arc=leo night=3,4,5 label="\"Leo. Miller knows you're alive. I told her.\"" if=flag:millerLeo&alive:leo&!flag:leoGoneTown prio=2
@focus leo
leo: You told the... the detective? The one with the hat? The one who looks at you like you're a cold case?
@gate flag:millerLeo=call ? p3c.leo1 : p3c.leo2

# p3c.leo1
leo: And she says if I call Mom she'll stop looking. She said that. Okay. Okay.
* Hand him your phone.  -> p3c.leo3

# p3c.leo3
> He holds it like it's hot. He dials. It rings once.
leo: Mom? Mom. It's me. No. No, I'm fine. I'm... I'm with a friend. I'm sorry. I'm so sorry. No, don't... Mom, don't cry, if you cry I'll... yeah. Yeah. I love you too. I'll come home soon. I promise. I'll come home.
> He hangs up and gives you back the phone and walks to the end of the alley and stands there with his hands on his knees.
{do flag:leoCalledMom=1; keep:leocall; rel:leo+2; comp+1}
@end

# p3c.leo2
leo: And she's coming to a gig? To *heckle*? Oh my God. Oh my God, I'm going to have a cop in the back row. That's going to be the best gig of my life or I'm going to throw up.
{do rel:leo+1}
@end
`,'c_paths3');
