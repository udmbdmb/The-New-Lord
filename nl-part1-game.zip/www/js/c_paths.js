'use strict';
/* THE NEW LORD — other ways in: on Night Four, the people you need for Friday can be won with what you've actually learned about them, not only with what you carry */
(function(){const O=NL.Script.opt;
O('s4.hub','* "Lyon, 1793. Mercy goes to the window. Stand with me and we close it together."  -> pa.sevlyon {once} {if mem:severine.lyon&!flag:side_court}','start');
O('s4.hub','* "You cry every dawn for four minutes. I\'m asking you not to cry for me on Saturday."  -> pa.sevcry {once} {if mem:severine.cries&!flag:side_court}','start');
O('s4.hub','* "You like me, Séverine. You\'ve liked me since Monday. Admit it, and stand with me."  -> pa.sevfond {once} {if like:severine>=5&!flag:side_court}','start');
O('s4.hub','* "Harrow\'s informant is in your Court. Grey pearls. I\'ll give her to you, and her ledger."  -> pa.sevott {once} {if flag:knowOttilie&!flag:side_court&!flag:ottilieExposed}','start');
O('mk4.0','* "Mikołaj. The butcher\'s boy from Kraków who wanted to play the violin. Stand with me."  -> pa.malname {once} {if mem:malakor.name&!flag:side_syndicate}','start');
O('mk4.0','* "I\'ve never once lied to you. I won\'t start now. I need you on Friday."  -> pa.malcand {once} {if rep:candour>=4&!flag:side_syndicate}','start');
O('mk4.0','* "I refused your thirteenth face. Someone worse will make it for Ottilie. Help me stop her."  -> pa.malface {once} {if flag:face13=refused&!flag:side_syndicate|flag:face13=taken&!flag:side_syndicate}','start');
O('so4.0','* "Mother. I said your name into a jar. Mathilde. I\'ll keep it as long as you keep mine."  -> pa.sootmat {once} {if mem:soot.mathilde&!flag:side_soot}','start');
O('so4.0','* "The jars, Mother. Ray\'s. Dani\'s. Rask\'s. I gave them back to the living. Give me Friday."  -> pa.sootjars {once} {if done:s_jars&!flag:side_soot}','start');
O('mi4.0','* "Ines. I brought you Ray\'s last words in a jam jar. Will you trust me one night more?"  -> pa.miljar {once} {if flag:millerRayJar&!flag:side_miller}','start');
O('mi4.0','* "Your brother is alive. Sort of. He\'s nineteen forever and he watches you through windows."  -> pa.milteo {once} {if task:s_mateo&!flag:millerMetMateo&!flag:side_miller}','start');
})();
NL.Script.add(String.raw`
// --- Séverine ---
# pa.sevlyon
> Séverine goes very still. Behind her, on the ossuary wall, Brother Anselm grins with his cracked jaw.
severine: I told you that. I told you that in confidence, in a moment of weakness, and you bring it here, to my table, in front of my ghouls.
? velvet 11 "I bring it because it's the truest thing you've ever said to me. I'm asking the woman who hid the priest, not the Keeper."  -> pa.sevlyonok | pa.sevlyonno {id pa_lyon} {mod like:severine}

# pa.sevlyonok
> She looks at you for a long time. Then she dismisses the ghouls with two fingers. When they've gone, she pours two glasses of something old and red and doesn't drink either.
severine: His name was Père Antoine. He had terrible teeth and the kindest hands in France.
severine: Very well. Friday. The Gilded Court stands behind you. Not for policy. For a priest who went to the window.
severine: If you ever repeat that sentence to anyone, I'll have your tongue in a jar beside Soot's.
{do flag:side_court=lyon; flag:sevPardon=1; flag:bloodHunt=0; xp:40:The Keeper; rel:severine+2}
@next s4.hub

# pa.sevlyonno
severine: No. You've misjudged. That woman is two hundred years dead. Mercy went to the window, and the Keeper drew the curtains.
{do rel:severine-1}
@next s4.hub

# pa.sevcry
severine: ...Who told you that?
* "You did. In the crypt. You told me not to tell."  -> pa.sevcry2

# pa.sevcry2
severine: And you haven't. You've brought it back to me, privately, as a... as a what? A gift? A threat?
? stagecraft 10 "A gift. It's the only thing I've got that you don't."  -> pa.sevcryok | pa.sevcryno {id pa_cry}

# pa.sevcryok
> She laughs, a little too high. Then she stops laughing. She touches the corner of her eye with one gloved finger as if checking for something.
severine: Four minutes. Every dawn. For three hundred years. You're the first person who ever asked me not to.
severine: Fine. Friday. Don't make me cry on Saturday. I'll be furious.
{do flag:side_court=tears; flag:sevPardon=1; flag:bloodHunt=0; xp:40:The Keeper; rel:severine+2}
@next s4.hub

# pa.sevcryno
severine: A threat, then. I know threats. I'll answer it in the circle.
@next s4.hub

# pa.sevfond
> For a moment, nothing at all. Then something extraordinary: Lady Séverine of the Gilded Court blushes. You didn't know they could.
severine: How dare you.
severine: ...Yes. All right. Yes. You're the first new thing that's happened in Elysium since the gramophone. I like you. I find it very irritating.
severine: Friday. Behind you. Don't make a song and dance about it.
{do flag:side_court=fond; flag:sevPardon=1; flag:bloodHunt=0; xp:40:The Keeper; rel:severine+1}
@next s4.hub

# pa.sevott
severine: Ottilie. My accountant. Who has done my books since 1902 and sat on my left at every Tribunal for a century.
severine: You're saying she sold my Court to Harrow.
* "Since 2016. In exchange for being the one LANTERN doesn't manage."  -> pa.sevott2 {if mem:harrow.ottilie}
* "Ask her. Ask her about the man with the peppermints."  -> pa.sevott2
* "Malakor's making her a face. Absalom's face. To wear on Friday."  -> pa.sevott3 {if flag:faceOttilie}

# pa.sevott2
> Séverine rings a small silver bell. A ghoul appears. She says one word to him. He goes pale and leaves.
severine: If you're right, she'll be in the cellar by dawn and you'll have my gratitude, which is worth more than my word, because I give it so much less often.
severine: If you're wrong, you'll be in the cellar with her.
{do flag:ottilieExposed=1; flag:side_court=ottilie; flag:sevPardon=1; flag:bloodHunt=0; xp:50:The Keeper; rel:severine+1}
@next s4.hub

# pa.sevott3
severine: Absalom's face. On my accountant. In my Tribunal.
> Séverine stands up. The candles all lean away from her at once.
severine: Gaston. Fetch Lady Ottilie. Use the chains.
{do flag:ottilieExposed=1; flag:side_court=ottilie; flag:sevPardon=1; flag:bloodHunt=0; xp:50:The Keeper; rel:severine+2; flag:ottilieChained=1}
@next s4.hub

// --- Malakor ---
# pa.malname
> Malakor's face, the current one, flickers. Just for a second you can see something else under it: a boy of fourteen with flour on his hands, in a shop in Kraków, looking at a violin through a window.
malakor: You remembered. Nobody remembers anything I tell them that isn't a price.
malakor: Mikołaj. God. I haven't heard it said out loud since 1919.
? velvet 10 "Then let me say it on Friday, in the circle. 'Mikołaj stands with me.'"  -> pa.malnameok | pa.malnameno {id pa_mal} {mod like:malakor}

# pa.malnameok
malakor: You'll say Malakor. Everyone says Malakor. But I'll know.
malakor: The Syndicate stands with you. No invoice. Don't tell my accountant. Oh, wait, I'm my accountant.
{do flag:side_syndicate=name; xp:40:The Butcher; rel:malakor+2}
@next mk4.0

# pa.malnameno
malakor: No. No, keep the name. Keep it in your pocket. It's worth more to me there than on a platform.
@next mk4.0

# pa.malcand
malakor: You haven't. That's true. It's the single most suspicious thing about you.
malakor: All week I've waited for the lie. The angle. The bit where you sell me out to the Lady for a better coffin. It never came.
malakor: ...Fine. Fine. I'll take a punt on an honest one. It's the only bet I've never made.
{do flag:side_syndicate=candour; xp:40:The Butcher; rel:malakor+1}
@next mk4.0

# pa.malface
malakor: Someone worse. Yes. There's a girl in Bayside who does faces for the Court ladies. Cheap, nasty, glue. She'll make Ottilie a Sheriff that looks like a waxwork in a heatwave.
malakor: And I'll have to sit on that platform and watch somebody wear a bad version of my best work.
malakor: No. No, I won't have it. Professional pride. The Syndicate stands with you, and on Friday when the cheap face comes off, I want to be the one who pulls.
{do flag:side_syndicate=face; xp:40:The Butcher; rel:malakor+1}
@next mk4.0

// --- Soot ---
# pa.sootmat
> The candles gutter. The rats all stop at once.
soot: ...Mathilde. Nobody. Nobody. Mm. Nobody's said that since the windows.
soot: You heard the jar. You heard me laughing. "Isn't it awful."
soot: Mm. Mm. Yes. All right. All right. The Wraiths will sit in your walls on Friday. Every one. Because you said my name and didn't laugh.
{do flag:side_soot=mathilde; xp:40:The Pipes; rel:soot+2}
@next so4.0

# pa.sootjars
soot: The jars. Yes. Mm. I heard. The rats told me. The detective cried. The mother laughed. The dog howled.
soot: Nobody ever takes the jars to the living. They're for the dead. They're for me.
soot: ...But it was good. It was good. They wanted them. Mm. All right. Friday. The Wraiths sit in your walls.
{do flag:side_soot=jars; xp:40:The Pipes; rel:soot+2}
@next so4.0

// --- Miller ---
# pa.miljar
miller: One night more. After that jar.
miller: I listened to it eleven times on Wednesday. "Bring the good cookies." I'll hear it every night for the rest of my life.
miller: Yeah. Yeah, one night more. Tell me where to stand.
{do flag:side_miller=jar; flag:millerAlly=1; flag:miller4done=1; xp:40:Miller; rel:miller+1}
@next mi4.0

# pa.milteo
> She puts her coffee down on the magazine rack very carefully.
miller: My brother is... say that again. Slower.
> You say it again. Mateo. Nineteen. The Union. The windows. The way he watches her car from the roof of the parking garage on Kerr Street when she does her night rounds.
miller: ...He watches me. Thirteen years and he's been WATCHING me?
? velvet 10 "He watches because he loves you and he's ashamed. Come to the platform Friday and I'll make sure he's there."  -> pa.milteook | pa.milteono {id pa_teo}

# pa.milteook
miller: Friday. A platform full of... with my brother on it.
miller: Okay. Okay. I'll be there. Not for you. For Teo. I want that very clear.
{do flag:side_miller=teo; flag:millerAlly=1; flag:millerTeoFriday=1; flag:miller4done=1; xp:40:Miller; rel:miller+2}
@next mi4.0

# pa.milteono
miller: No. No, I can't... I can't do this tonight. Give me a minute. Give me a day.
@next mi4.0
`,'c_paths');
