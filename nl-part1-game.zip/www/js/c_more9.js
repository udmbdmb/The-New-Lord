'use strict';
/* THE NEW LORD — more arcs, part nine: Teo, Ezra, Ottoline, the Prophet and Coral, and what they want from whoever you are */
NL.Script.add(String.raw`
# m9.teo arc=teo night=4,5 label="\"Teo. What do you remember about the jacket?\"" if=mem:miller.glassheard&!flag:teoGone prio=2
@focus teo
teo: The jacket. Ines's jacket. Navy, with the softball patch. How do you know about the jacket?
teo: It was raining. She lent it to me at the door. She said "bring it back Sunday, I mean it, Teo, Sunday." I said "yeah, yeah." I was nineteen. I was going to a party at the Switchyard.
teo: It's in the cistern. With Soot. I gave it to her for a room in 2011, the first week. It was all I had. I've been ashamed of that for thirteen years.
* "Get it back. Give it to Ines."  -> m9.teo1
* "Tell Ines it's safe. That's enough."  -> m9.teo2

# m9.teo1
teo: Get it back. From Soot. She'll want something. She always wants something.
teo: ...I'll pay. Whatever it is. I'll give her the party. The whole night. I don't want it any more. I'd rather Ines had the jacket.
{do flag:teoJacket=1; rel:teo+2}
@end

# m9.teo2
teo: Safe. In a jar, probably. On a shelf. Next to everything else nobody came back for.
teo: Yeah. Tell her that. Tell her I kept it. Sort of.
{do rel:teo+1}
@end

# m9.jac arc=miller night=4,5 label="Give Miller the navy jacket with the softball patch." if=flag:teoJacket&!flag:millerDead&!flag:jacketGiven prio=4
@focus miller
> It smells of the cistern: candle smoke and cold water. The softball patch on the sleeve is faded almost white. Precinct 9 Wildcats, 2010.
> She takes it like it's a body.
miller: ...Where.
miller: No. No, don't. Don't tell me where. Don't tell me how.
> She puts it on. Over her own coat. It's too small for her now, or she's too big for it, or both. She stands on the sidewalk in the rain in her dead brother's jacket that was hers first, and she doesn't cry, and she doesn't cry, and then she does.
{do flag:jacketGiven=1; keep:jacket; rel:miller+3; comp+2; xp:40:Sunday}
@end

# m9.ezra arc=ezra night=4,5 label="\"Ezra. What will you do now? Now that you're out.\"" if=flag:ezraFree prio=1
@focus ezra
ezra: Now. Now is a very large word. I was in the chimney for... what year is it?
* Tell him.  -> m9.ezra1

# m9.ezra1
ezra: Ah. Ah. That's... more than I thought. That's a great deal more than I thought.
ezra: I'd like to see the river. I used to fish in it. There were salmon, once, under the Halloran Street bridge. Are there still salmon?
* "No. Not for a long time."  -> m9.ezra2
* "I don't know. Let's go and look."  -> m9.ezra3

# m9.ezra2
ezra: No. Of course not. Nothing stays. Not salmon. Not bridges. Not me.
ezra: I'll go and look anyway. You can be sad about a river and still go and look at it.
{do rel:ezra+1}
@end

# m9.ezra3
> You walk him to the Halloran Street bridge. He leans on the parapet for a long time looking at the black water.
> Something moves under the bridge. A long, silver shape, very fast, against the current. Then gone.
ezra: ...There. Did you see? There. There's still one.
> It was probably a carp. You don't tell him.
{do rel:ezra+2; comp+2; tick:20}
@end

# m9.ott arc=ottoline night=4,5 label="\"Ottoline. If the Vessel works, what happens to you?\"" if=met:ottoline&!flag:ottolineDead prio=1
@focus ottoline
ottoline: To me. Nobody ever asks about the Alchemist. They ask about the formula. The yield. The side effects.
ottoline: If it works, I'll have finished what my grandmother started in Lyon in 1793. Two hundred and thirty years of my family trying to make sunlight bearable. And I'll be the one who did it. And then I'll have nothing to do.
ottoline: I'm frightened of that, actually. More than of failing. Failing I know how to do. My family's been doing it for six generations.
* "Then do something else. Something small."  -> m9.ott1
* "You'll never have nothing to do. Someone will always want more."  -> m9.ott2

# m9.ott1
ottoline: Small. I've never done anything small in my life. I had a pet once. A tortoise. Even he lived to be ninety.
ottoline: ...Perhaps I'll grow tomatoes. In the sun. If I can stand in it. Tomatoes are very small and very difficult and they don't care about my grandmother.
{do rel:ottoline+2}
@end

# m9.ott2
ottoline: Yes. That's what I'm afraid of, actually. Not nothing. More. Always more. That's what killed her. That's what killed all of them.
{do rel:ottoline+1}
@end

# m9.pro arc=prophet night=3,4,5 label="\"Prophet. What do you see when you look at me?\"" if=room:switchyard prio=-2
@focus prophet
prophet: You. Hm. Hm. You I see double. Always double. Two people in one coat, like a pantomime horse.
@gate sync>=50 ? m9.pro1 : m9.pro2

# m9.pro1
prophet: The two halves are walking in step now. Front legs, back legs. Very good. Very good. Soon nobody'll know which half is which. Not even the halves.
prophet: I see a window box. Flowers climbing. A heron in a frame. A Hound asleep on a step. I see a lot of small things. Small things are the true ones. Big things are just small things a long way off.
{do sync+1}
@end

# m9.pro2
prophet: The two halves are pulling different ways. Front legs want to go to the river. Back legs want to go to the Heights. Hm. Hm. That's how pantomime horses fall over.
prophet: Pick a direction. Or let him go. Either. Not both. Both is how you end up on your face in the middle of the stage.
@end

# m9.cor arc=coral night=4,5 label="\"Coral. Teach me to dance.\"" if=flag:metCoral&!flag:coralGone prio=-1
@focus coral
coral: You. Dance. Nobody asks me to teach. They ask me to perform. There's a difference. One of them you pay for.
coral: Okay. Okay. Stand there. Feet like that. No. Like that. You stand like a coat on a hanger. Somebody else's coat.
* "It is somebody else's coat."  -> m9.cor1
* Try. Really try.  -> m9.cor2

# m9.cor1
coral: Then take it off. For four minutes. Just for the song.
> You take off the Sheriff's coat. You've not had it off since Monday. Without it, you're smaller. You're someone you don't recognise.
> Coral puts a song on her phone. Something old. She shows you how to move your weight from one foot to the other. That's all. Just that. Four minutes of moving your weight from one foot to the other in an empty corner of the Reliquary.
coral: There. That's dancing. Everything else is just showing off.
{do rel:coral+2; comp+2; sync-1}
@end

# m9.cor2
> You try. You're terrible. You're terrible in a coat from Vienna that was built for a man who never danced in two hundred years.
> Coral laughs so hard she has to sit down on the edge of the stage.
coral: Oh. Oh, that's... no. That's the worst thing I've ever seen. Do it again.
> You do it again. It's still terrible. She does it with you, just as badly, on purpose, until you're both laughing.
{do rel:coral+2; comp+2}
@end
`,'c_more9');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.jacketGiven&&!f.millerDead)o.push(['A navy jacket with a softball patch','Hangs on the back of Detective Miller\'s chair at Precinct 9. It is too small for her. She wears it anyway, on Sundays.']);
  return o;});
