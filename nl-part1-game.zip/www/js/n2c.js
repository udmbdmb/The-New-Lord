'use strict';
/* THE NEW LORD — Act II · Night Two: the ten clan quests (one per playthrough) and the district side quests */
(function(){
const NL=window.NL,G=NL.G,A=NL.Audio;const {N,ENC,L,T,O,C,H,STORY}=NL.DSL;const {pushPop,pushNpc,pushEnter}=NL.Act;
const leoAlive=S=>!S.flags.leoDead;
NL.Camp.HAVENS.ash5A={room:'rookery',spawn:{x:5.9,z:1.2,ry:3},n:'The Ashcombes\' spare room'};
const X=NL.EXTRAS;
Object.assign(X,{
  ashcombe:{n:'Lionel Ashcombe',color:'#c8b890',role:'Rookery 5A',spec:{face:{long:1.06,jaw:1.1,nose:1.3,brow:1.3,cheek:0.6},skin:[.86,.78,.72],hair:{style:'fringe',color:[.9,.9,.88]},shirt:[.5,.45,.38],coat:{color:[.3,.22,.18],length:.3,collar:true},height:.95}},
  phoebe:{n:'Phoebe Ashcombe',color:'#e0c0d0',role:'Rookery 5A',spec:{skin:[.9,.8,.74],hair:{style:'long',color:[.55,.35,.2]},shirt:[.3,.4,.6],pants:[.15,.15,.2],height:.95}},
  pip:{n:'Pip',color:'#a0a8c0',role:'A Wraith fledgling',spec:{face:{long:1.1,cheek:1.7,jaw:1.3},skin:[.62,.64,.68],hair:{style:'crop',color:[.2,.2,.22]},shirt:[.2,.2,.22],pants:[.15,.15,.17],eyes:[.85,.88,.95],eyeGlow:[.3,.32,.4],height:.92}},
  coral:{n:'Coral',color:'#f0b0c0',role:'Club Reliquary',spec:{skin:[.62,.45,.34],hair:{style:'curly',color:[.08,.06,.06]},shirt:[.85,.3,.4],pants:[.1,.08,.1]}},
  ashby:{n:'Lord Ashby',color:'#d0a0a0',role:'The Gilded Court',spec:{face:{long:1.06,cheek:1.4,jaw:1.2},skin:[.9,.84,.8],hair:{style:'slick',color:[.75,.6,.35]},shirt:[.9,.88,.85],coat:{color:[.2,.05,.08],length:.4,collar:true},eyeGlow:[.3,.05,.05]}},
  mina:{n:'Mina Sorel',color:'#d0e0f0',role:'Cellist',spec:{skin:[.92,.86,.82],hair:{style:'bun',color:[.85,.8,.7]},shirt:[.06,.06,.08],pants:[.06,.06,.08]}},
  laurent:{n:'Laurent',color:'#e0d0a0',role:'A Gilded defector',spec:{face:{long:1.05,cheek:1.5},skin:[.88,.8,.76],hair:{style:'slick',color:[.15,.1,.08]},shirt:[.85,.8,.75],pants:[.2,.18,.2]}},
  wight:{n:'The Wight',color:'#a08070',role:'Something feral',spec:{face:{long:1.15,cheek:1.8,jaw:1.4,nose:1.4},skin:[.55,.5,.48],hair:{style:'long',color:[.25,.22,.2]},shirt:[.2,.15,.12],pants:[.15,.12,.1],eyes:[.9,.2,.1],eyeGlow:[.7,.1,.05]}},
  ottoline:{n:'Ottoline Vass',color:'#a0e0b0',role:'An Alchemist',spec:{face:{long:1.04,cheek:1.3},skin:[.9,.75,.65],hair:{style:'bun',color:[.4,.1,.08]},shirt:[.9,.9,.88],eyes:[.35,.85,.55],eyeGlow:[.2,.6,.3]}},
  lamplighter:{n:'The Lamplighter',color:'#9080e0',role:'An Elder of the Hollow',spec:{face:{long:1.12,cheek:1.6,jaw:1.3,nose:1.4},skin:[.75,.72,.78],hair:{style:'long',color:[.1,.08,.12]},coat:{color:[.05,.04,.06],length:.95,collar:true},eyes:[.5,.42,.9],eyeGlow:[.4,.3,.85],alpha:.85}},
  dutch:{n:'Dutch',color:'#e0b080',role:'Clanless',spec:{skin:[.5,.36,.28],hair:{style:'curly',color:[.06,.05,.05]},shirt:[.5,.2,.1],coat:{color:[.3,.25,.15],length:.4,collar:true},pants:[.15,.15,.2],eyes:[.85,.55,.15],eyeGlow:[.6,.35,.05]}},
  okafor:{n:'Mrs. Okafor',color:'#e0c0a0',role:'Rookery 404',spec:{face:{wide:1.06,jaw:0.6,cheek:0.9},skin:[.38,.27,.22],hair:{style:'bun',color:[.75,.75,.75]},glasses:{type:'reading'},shirt:[.6,.4,.25],coat:{color:[.45,.3,.2],length:.3,collar:false},height:.92}},
  ezra:{n:'Ezra',color:'#c0a0a0',role:'Bricked in the chimney',spec:{face:{long:1.12,cheek:1.9,jaw:1.4},skin:[.6,.55,.52],hair:{style:'long',color:[.2,.15,.12]},shirt:[.25,.2,.18],pants:[.2,.18,.15],eyes:[.9,.3,.2],eyeGlow:[.6,.15,.05],height:.9,width:.8}},
  pixel:{n:'Pixel',color:'#a0f0e0',role:'Dealer',spec:{skin:[.85,.72,.62],hair:{style:'crop',color:[.3,.9,.8]},shirt:[.1,.1,.12],coat:{color:[.15,.4,.4],length:.3,collar:true},pants:[.1,.1,.12]}}
});
const relic=(id,n,mods,d,sp)=>{NL.ITEMS[id]={n,slot:'pocket',mods,d,sp};};
relic('r_seal','The Ashcombe Seal',{pedigree:1,velvet:1},'A carnelian intaglio of a stag. Ninety years of debt, settled.','Sovereign relic.');
relic('r_paperface','Pip\'s Paper Face',{stagecraft:1,velvet:1},'A face cut from a fashion billboard and pressed flat in a book. It still smiles.','Wraith relic.');NL.ITEMS.r_paperface.slot='face';NL.ITEMS.r_paperface.cover=true;NL.ITEMS.r_paperface.look={mask:'porcelain'};
relic('r_shard','Shard of the Maze',{web:1,osmosis:1},'A sliver of the Reliquary\'s washroom mirror. In it, it is always twenty minutes from now.','Glass relic.');
relic('r_bow','The Bow of Bone',{velvet:1,nostalgia:1},'A cello bow of horsehair and a long, pale bone. It hums when held near a throat.','Choir relic.');
relic('r_scalpel','Malakor\'s Scalpel',{abattoir:1,autopsy:1},'A Butcher\'s blade, honed so thin you can see light through it.','Butcher relic.');
relic('r_collar','The Wight\'s Collar',{frenzy:1,apex:1},'Rotten leather and a brass ring. It smells of everything a Hound wants to chase.','Hound relic.');
relic('r_contract','The Unburnt Contract',{pedigree:1,rigor:1},'Vellum, Latin, scorched at every edge but the signature line. Ottoline owes you.','Alchemist relic.');
relic('r_dark','A Pocket of Dark',{stagecraft:1,echo:1},'Nothing, folded small. It is heavier than it should be.','Hollow relic.');
relic('r_mold','Culture of Ward 4',{autopsy:1,rigor:1},'A petri dish of grey-green mold that glows faintly when it\'s happy.','Rot relic.');
relic('r_union','Union Card No. 1',{gutter:1,sundial:1},'Laminated, hand-drawn: THE NIGHT SHIFT · LOCAL 0. Your name on the line, spelled wrong.','Stray relic.');

/* ---------- 10 PM: the clan quest calls ---------- */
const CALL={
  sovereign:['A note, slid under your haven door in copperplate: "The Ashcombe tithe is due. Rookery, 5A. The family awaits its creditor." It is addressed to the heir of House Vane.','Rookery, 5A: the Ashcombe family\'s ninety-year blood debt to House Vane has come due.'],
  wraiths:['A rat sits up on the curb in front of you, holding something in its teeth: a strip of billboard, a printed smile. Mother Soot\'s voice comes from nowhere: "One of mine is tearing faces off the dummies at Gideon\'s. Bring him home or put him down."','A Wraith fledgling is tearing faces off mannequins at the Pawn & Coffin.'],
  glass:['Every reflective surface you pass shows the same thing, half a second late: a girl in a pink top, in the VIP crypt, with someone\'s mouth on her neck. The Reliquary washroom mirror. You know it without knowing how.','The washroom mirror at Club Reliquary is showing a murder twenty minutes before it happens.'],
  choir:['You hear it from two blocks away: a cello, playing a melody that makes your teeth ache and your legs want to stop. Every vampire on Reliquary Row has stopped walking.','A cellist at Club Reliquary is playing a melody that paralyses vampires.'],
  butchers:['A text from M.: "Kin. I have a client who wants a new face and a new life. I need steady hands. Platform 0. Bring your fingers."','Malakor wants your hands on Platform 0 for a delicate piece of surgery.'],
  hounds:['The scent hits you like a slap: blood, a lot of it, in the lanes off the Strip, and over it something wrong. Not mortal. Not quite vampire. And under that, deliberately smeared, *Hound*.','Something feral is killing in the Abattoir alleys and leaving your clan\'s scent on the bodies.'],
  alchemists:['Your blood itches. Somewhere nearby, a contract is being broken, and the breaker is burning. A frantic text from an unknown number: "Rookery. Bathroom, 6C. Please. I\'m on fire. Please."','An Alchemist is burning alive in a bathtub at the Rookery, punished by a broken contract.'],
  hollow:['At ten o\'clock exactly, your shadow stops following you. It stands on the sidewalk for a moment, deciding, and then walks off toward the Switchyard without you.','Your shadow has walked off toward Platform 0. Follow it.'],
  rot:['A nurse at St. Jude\'s is giggling uncontrollably on the payphone outside the clinic. The air around her smells of mildew and roses. Something is growing in Ward 4.','A euphoric blood-mold is spreading through St. Jude\'s.'],
  stray:['A flyer, stapled to every lamppost on Halloran Street: "CLANLESS? TIRED OF ELDERS? ROOF OF THE ROOKERY, MIDNIGHT. BRING A SCREWDRIVER." Somebody has drawn a crown on a rubbish bin.','The clanless neonates are organizing on the roof of the Rookery.']
};
NL.Camp.tickHooks.push((S,G)=>{if(S.night===2&&S.time>=60&&S.clan&&!S.flags.clanCall&&!G.busy){S.flags.clanCall=1;const c=CALL[S.clan];if(!c)return;
  setTimeout(()=>{G.task('c_'+S.clan);S.quests['note_c_'+S.clan]=c[1];G.say([T(c[0]),L('pedigree','Blood calls to blood. This one is yours, and nobody else\'s.',{pass:4})]);},600);}});

/* =====================================================================
   1 · THE SOVEREIGN — "A Debt of Vintage" (Rookery 5A)
   ===================================================================== */
NL.ROOMS.rookery.inter.push({id:'door5A',label:'Upstairs · 5A',at:[5.9,1.4,0.1],box:[5.5,0,0,6.3,2.2,0.2],stand:[5.9,0.9],face:[5.9,0],if:S=>S.tasks.c_sovereign==='active'||S.flags.haven5A});
NL.ROOMS.rookery.inter.push({id:'door6C',label:'Upstairs · 6C',at:[5.9,1.4,0.1],box:[5.5,0,0,6.3,2.2,0.2],stand:[5.9,0.9],face:[5.9,0],if:S=>S.tasks.c_alchemists==='active'});
H.use.door5A=async(S,G)=>{S.aptWho='5A';await G.enterRoom('apt',{x:5.2,z:4.2,ry:-2.4});};
pushPop('apt',(S,G)=>{if(S.aptWho==='5A'&&(S.tasks.c_sovereign==='active'||S.flags.haven5A)){G.addActor('ashcombe',X.ashcombe.spec,{x:4.6,z:2.2,ry:-1.4,breathes:true,pose:'sit'});G.addActor('phoebe',X.phoebe.spec,{x:3.6,z:1.4,ry:-0.6,breathes:true,pose:'arms'});}});
pushNpc('apt',(S,G)=>G.actor('ashcombe')?[{id:'ashcombe',actor:'ashcombe',label:'Mr. Ashcombe'},{id:'phoebe',actor:'phoebe',label:'Phoebe'}]:null);
H.use.ashcombe=async(S,G)=>G.talk(S.flags.haven5A?'cs.haven':'cs.0');
N['cs.haven']={lines:[L('ashcombe','My lord. The spare room is ready.')],opts:[O('Sleep in the spare room until tomorrow night.',null,{if:S=>NL.Camp.canSleep(S),end:true,do:()=>setTimeout(()=>NL.Camp.sleep('ash5A'),300)}),O('"Not yet."',null,{end:true,leave:true})]};H.use.phoebe=H.use.ashcombe;
N['cs.0']={enter:(S,G)=>{G.focus(['you','ashcombe','phoebe'],.8);G.look('ashcombe','you');G.look('phoebe','you');},lines:[
  T('A tiny flat that was once a grand one: a mahogany table too big for the room, two candles, a clock that has stopped. An old man in a cardigan sits very straight. A girl of nineteen stands behind his chair with her arms folded and murder in her face.'),
  L('ashcombe','You are from House Vane. I can tell. You stand like him.'),
  L('ashcombe','In 1936 my grandfather borrowed a fortune from Absalom Vane, and the price was a pint of Ashcombe blood a year, for ninety years. I have paid it since I was eleven. This year I am ninety-one and my doctor says another pint will kill me.'),
  L('phoebe','So it\'s me. That\'s what he means. It\'s *me* now.'),
  L('pedigree','A blood tithe. Old Sovereign law. The debt passes to the heir of the creditor, and Vane\'s heir is, technically, whoever drank him.',{pass:5})],
  opts:[O('Blue Blood: feel the debt itself.','cs.blue',{ab:'blueblood',once:true}),
    C('pulse',9,'"The debt is forgiven. All of it. Go and live."','cs.forgive','cs.forgiveNo',{id:'cs_forgive'}),
    O('Collect. From Phoebe.','cs.collect',{if:S=>S.clan!=='sovereign'||true}),
    O('Royal Decree: "This flat is mine now. You will both keep it for me."','cs.decree',{ab:'kneel',t2:true}),
    O('"I need to think."',null,{end:true,leave:true})]};
N['cs.blue']={lines:[T('The debt hangs in the room like smoke: ninety years of it, thick and sour. And a second thread, newer, fainter, tied to it like a parasite. Not Vane\'s. Somebody else has been *collecting* in his name.'),
  L('ashcombe','The collector? A woman from the butcher\'s. She comes every December with a little cool-bag. She says the Sheriff sends his regards.'),
  L('web','Margo Kowalski. Vane cancelled this debt decades ago, or never knew it was still being paid. She\'s been selling Ashcombe blood out of the freezer as vintage.',{do:S=>S.flags.ashFraud=1})],next:'cs.0'};
N['cs.forgive']={lines:[T('You say it the way a Sovereign says things: as law. The candle flames lean toward you. Something old and heavy goes out of the room like air out of a tyre.'),
  L('ashcombe','...Ninety years. Ninety years and the last of it is four words from a stranger.'),
  L('phoebe','Is that it? Is that actually it? Grandad?'),
  T('The old man gets up, very slowly, and goes to a drawer, and comes back with a carnelian seal on a chain.',{do:(S,G)=>{G.give('r_seal');G.task('c_sovereign','done');G.comp(2,'You let them go');G.offer('shepherd');S.flags.c_done='forgive';}}),
  L('ashcombe','The family seal. It was the only thing my grandfather kept. Take it. And thank you, ‹my lord|my lady›.')],cs:async(G,S)=>{S.aptWho=null;},end:true};
N['cs.forgiveNo']={lines:[L('phoebe','You don\'t mean it. They never mean it. You\'ll be back in December like the other one.'),L('pulse','Your voice was too soft. A Sovereign\'s mercy has to sound like a sentence.')],next:'cs.0'};
N['cs.collect']={lines:[T('Phoebe doesn\'t run. She rolls up her sleeve and holds out her arm and looks at the wall the whole time.'),
  T('It tastes of pencil shavings and anger and a future she\'s just been robbed of a pint of.',{fx:['flash','sfx:drink'],do:(S,G)=>{G.feed(3,'choleric','Phoebe Ashcombe\'s tithe',{kind:'consent'});G.comp(-2,'You collected');G.task('c_sovereign','done');G.give('r_seal');G.offer('darwin');S.flags.c_done='collect';}}),
  L('ashcombe','The seal. Take it. It\'s yours, apparently. Everything is yours.'),L('pedigree','The law is satisfied. That is all the law ever is.')],cs:async(G,S)=>{S.aptWho=null;},end:true};
N['cs.decree']={lines:[T('You stack the commands like plates. *This flat is mine. You will keep it. You will tell no one. You will be at peace.* Their faces go smooth and grateful.'),
  L('ashcombe','Of course, ‹my lord|my lady›. The flat is yours. The spare room is dark and has no window.',{do:(S,G)=>{G.give('r_seal');G.task('c_sovereign','done');S.flags.haven5A=1;G.toast('task','New haven: the Ashcombes\' spare room, Rookery 5A.','Royal Decree');S.flags.c_done='decree';S.aptWhoKeep=1;}}),
  L('pulse','They\'ll be happy. You made them happy. That is worse than anything else you could have done.')],cs:async(G,S)=>{S.aptWho=null;},end:true};

/* =====================================================================
   2 · THE WRAITHS — "The Face in the Drain" (Pawn & Coffin)
   ===================================================================== */
NL.ROOMS.pawn.inter.push({id:'mannequins',label:'Faceless mannequins',at:[7.4,1.4,3.2],box:[7.0,0,2.6,7.9,2.0,4.2],stand:[6.4,3.4],face:[7.4,3.2],if:S=>S.tasks.c_wraiths==='active'});
H.use.mannequins=async(S,G)=>G.talk('cw.0');
N['cw.0']={lines:[T('Three shop mannequins in the corner, dressed in pawned wedding gear. Their faces have been torn off, cleanly, like the peel off an orange. On the floor: magazine faces, billboard faces, a face cut out of a cereal box.'),
  L('gideon','Started on Saturday. I hear him at night in the boxes. I leave the faces out like milk for a cat. Is that wrong?'),
  L('echo','Third coffin-box, bottom row. Something in there is holding its breath, which is funny, because it doesn\'t need to.',{pass:7})],
  opts:[O('Carrion Whisper: ask the moths in the window where he hides.','cw.find',{ab:'carrion'}),C('echo',9,'Listen for him.','cw.find','cw.no',{id:'cw_echo'}),O('Leave him be.',null,{end:true,leave:true})]};
N['cw.no']={lines:[T('Nothing. A clock ticks. Gideon coughs. A fledgling Wraith can stay silent longer than you can listen.')],end:true};
N['cw.find']={lines:[T('You lift the lid. A boy of maybe twenty, grey as newspaper, curled in the foam with a face held over his own face like a mask: a smiling model from a perfume ad.'),
  L('pip','Don\'t look at me. Don\'t LOOK at me. I\'m ugly. I\'m dead and I\'m ugly and everybody on the billboards is so *beautiful*.'),
  L('pip','Mother says it gets better. It doesn\'t. I looked in the window at Reliquary and the people inside looked back and *screamed*.'),
  L('pulse','He\'s three weeks dead. Walking Cadaver. Every lit window in the city has told him what he is.',{pass:5})],
  opts:[O('"Come home, Pip. Mother Soot is waiting. Down there nobody looks."','cw.home'),
    C('nostalgia',10,'"I hated my face too. Before. Everyone does. Here: wear this, and walk with me."','cw.walk','cw.walkNo',{id:'cw_nos'}),
    O('End it, gently.','cw.end'),O('Close the lid.',null,{end:true,leave:true})]};
N['cw.home']={lines:[L('pip','...Down there nobody looks.'),T('He climbs out of the box, holding the paper face over his own, and follows you to the door like a dog that has been kicked a lot and is willing to try once more.',{do:(S,G)=>{G.give('r_paperface');G.task('c_wraiths','done');G.rel('soot',2);S.flags.c_done='home';G.xp(30,'Pip came home');}}),
  L('pip','You can have this one. It\'s my best. It\'s smiling.')],end:true};
N['cw.walk']={lines:[T('You take off whatever you\'re wearing over your own face, or you find him a surgical mask from Gideon\'s drawer, and you put it on him, and you walk him through the shop past the mirrors, one by one, and nobody screams.'),
  L('pip','...Nobody screamed.',{do:(S,G)=>{G.give('r_paperface');G.task('c_wraiths','done');G.rel('soot',2);G.comp(2,'A small grace');S.flags.c_done='walk';}}),L('nostalgia','Nobody screamed.')],end:true};
N['cw.walkNo']={lines:[L('pip','You\'re lying. You\'re *grey* too. I can see it.')],next:'cw.find'};
N['cw.end']={lines:[T('He doesn\'t fight. He takes the paper face away from his real one, finally, so you can see it, and you do it quickly, while he\'s looking at you, so that the last thing that happens to him is being looked at.',{do:(S,G)=>{G.give('r_paperface');G.task('c_wraiths','done');G.rel('soot',-2);G.comp(-2,'You put him down');S.kills++;S.flags.c_done='end';}}),
  L('gideon','...I\'ll bury him with the faces. He\'d want them.')],end:true};

/* =====================================================================
   3 · THE GLASS — "The Mirror Maze at Reliquary"
   ===================================================================== */
NL.ROOMS.reliquary.inter.push({id:'clubmirror',label:'Washroom',at:[0.1,1.4,3.6],box:[0,0.9,3.2,0.4,2.2,4.1],stand:[1.3,3.6],face:[0,3.6]});
H.use.clubmirror=async(S,G)=>{S.flags.mirror_reliq=1;if(S.tasks.c_glass==='active')return G.talk('cg.0');const ghost=NL.CLANS[S.clan]&&NL.CLANS[S.clan].ghost;return G.say([T('The club washroom: gold taps, black tiles, a long mirror with a crack you recognize.'),T(ghost?'No reflection. A girl fixing her eyeliner glances at the empty glass beside her and drops the pencil.':'You, under club light. Fashionably dead.')]);};
N['cg.0']={lines:[T('The washroom mirror shows the washroom. Then it shows the crypt: the booth, the candles, and a girl in a pink top, Coral from the dance floor, laughing at something a pale man in a burgundy coat is whispering. The clock in the mirror says 11:20.'),
  T('The clock on your burner says 11:00.'),
  L('web','Twenty minutes. In twenty minutes, Lord Ashby of the Gilded Court drains a mortal inside Elysium, where feeding is forbidden. Séverine\'s house. Séverine\'s law.',{pass:4}),
  L('tenant','Ashby. Séverine\'s favorite. She\'d cover it up. She\'d have to.')],
  opts:[O('Cold Reading: hear what Ashby\'s planning.','cg.read',{ab:'coldread',once:true}),
    O('Déjà Vu: live the next twenty minutes, then rewind.','cg.live',{ab:'dejavu',once:true}),
    O('Warn Tiny. He decides who goes down.','cg.tiny',{if:S=>S.dos.tiny}),
    O('Splinter: put a horror of the crypt into Coral\'s head.','cg.splinter',{ab:'splinter'}),
    O('Let it happen. Watch. Remember everything.','cg.let'),
    O('Walk away.',null,{end:true,leave:true})]};
N['cg.read']={lines:[T('Ashby\'s loudest thought is a sentence he has rehearsed: *the Sheriff\'s gone, the Keeper owes me, and who will enforce the Masquerade now? Nobody. Nobody at all.*'),L('web','He\'s testing whether anyone still enforces the law. Whoever stops him becomes the law.')],next:'cg.0'};
N['cg.live']={lines:[T('Twenty minutes in a heartbeat: Coral on the velvet, Ashby\'s mouth, the moment her heart stops, Séverine arriving too late and smoothing her hair and saying "Oh, Ashby, the *carpet*." And then you are back at the mirror, with the taste of it.'),
  L('web','Now you know where he\'ll be, what he\'ll say, and the exact second his guard drops.',{do:S=>S.flags.cgKnow=1})],next:'cg.0'};
N['cg.tiny']={lines:[T('You find Tiny at the rope. You tell him. He looks at you for a long moment.'),L('tiny','Lord Ashby goes down when he likes. That\'s the rule.'),L('tiny','...But the girl doesn\'t. That\'s my rule.'),
  T('He un-hooks the rope, walks down the stairs, and comes back up a minute later with Coral by the elbow, bewildered and furious and alive.',{do:(S,G)=>{G.task('c_glass','done');G.give('r_shard');G.rel('tiny',2);S.flags.c_done='saved';G.xp(30,'Twenty minutes early');}}),
  L('tiny','Ashby is not happy. I am not paid enough to care.')],end:true};
N['cg.splinter']={lines:[T('Across the dance floor, Coral stops dancing. She turns toward the VIP stairs, and goes white, and leaves through the street door without her coat.',{do:(S,G)=>{G.task('c_glass','done');G.give('r_shard');S.flags.c_done='saved';G.xp(30,'Twenty minutes early');}}),
  L('pulse','She\'ll never set foot in a club again. She\'ll never know why. She\'ll live.')],end:true};
N['cg.let']={lines:[T('You go down at 11:21 with your phone held low. You see all of it. So does the phone.'),
  L('severine','*Ashby.* Oh, Ashby, the *carpet*.'),T('She looks up and sees you, and sees the phone, and her face does something very complicated.'),
  L('severine','...What do you want?',{do:(S,G)=>{G.task('c_glass','done');G.give('r_shard');S.flags.c_done='leverage';S.flags.ashbyLeverage=1;G.comp(-2,'You let a girl die');S.flags.sevOwesYou=1;G.offer('capitalism');}}),
  L('web','Now the Keeper of Elysium owes you a favour she can never refuse. It cost a girl called Coral.')],end:true};

/* =====================================================================
   4 · THE CHOIR — "The Cello of Bone" (Reliquary stage)
   ===================================================================== */
pushPop('reliquary',(S,G)=>{if(S.tasks.c_choir==='active'){G.removeActor('dancer0');G.addActor('mina',X.mina.spec,{x:5.5,z:1.0,ry:0.1,breathes:true,pose:'sit'});}});
pushNpc('reliquary',(S,G)=>G.actor('mina')?{id:'mina',actor:'mina',label:'The cellist',stand:[5.5,2.4],face:[5.5,1]}:null);
H.use.mina=async(S,G)=>G.talk('cc.0');
N['cc.0']={lines:[T('The DJ has gone. In her place, on a kitchen chair, a woman with white-blonde hair plays a cello the color of old ivory. The melody goes round and round like a drain. Every vampire on the dance floor is standing perfectly still with their eyes open.'),
  L('osmosis','The cello isn\'t wood. It\'s *bone*. Ribs, a spine, a pelvis for the scroll. And it was alive once. It was one of *us*.',{pass:5}),
  L('mina','Do you like it? I found it in a pawnshop. It plays itself, mostly. I just hold on.')],
  opts:[O('Touch of Velvet: lay your hand on the cello.','cc.touch',{ab:'touch',once:true}),
    O('Siren\'s Pitch: sing the counter-melody until she stops.','cc.siren',{ab:'siren'}),
    O('Take the cello from her. To Séverine.','cc.sev',{if:S=>S.flags.ccKnow}),
    O('Break it over your knee.','cc.break'),
    O('Let her play.','cc.let'),
    O('Leave.',null,{end:true,leave:true})]};
N['cc.touch']={lines:[T('Your palm on the bone. Ten thousand nights come up through it like heat through a stove: a woman singing in Naples in 1690, a lullaby, four notes; a Butcher\'s saw in a cellar in 1890; and Séverine, younger, screaming as they took her sire apart.'),
  L('web','This is Séverine\'s sire. Malakor made a cello out of him. Somebody sold it to a pawnshop for a joke.',{do:S=>S.flags.ccKnow=1}),L('tenant','I was there in 1890. I let it happen. I was paid.')],next:'cc.0'};
N['cc.siren']={lines:[T('You open your mouth and the note that comes out is the one under hers, the root of the chord. The cello shrieks like a cat and the bow skids off the strings.'),L('mina','...Oh. Oh, my hands. What was I doing?',{do:(S,G)=>{S.flags.ccFree=1;}})],next:'cc.0'};
N['cc.sev']={lines:[T('You carry it down to the crypt wrapped in your coat. Séverine looks at it for a long time without touching it.'),L('severine','...Papa.'),L('severine','Where did you find him? No. Don\'t tell me. Leave him here. Leave me alone with him.',{do:(S,G)=>{G.give('r_bow');G.task('c_choir','done');G.rel('severine',3);S.flags.sevOwesYou=1;S.flags.c_done='severine';G.xp(30,'A sire, returned');}})],end:true};
N['cc.break']={lines:[T('It doesn\'t snap. It *sings* as it breaks, a long final chord, and every vampire on the dance floor sits down at once, like puppets with the strings cut, and begins to weep.',{fx:['shake:.8'],do:(S,G)=>{G.give('r_bow');G.task('c_choir','done');S.flags.c_done='broken';G.rel('severine',-1);G.xp(30,'The music stops');}}),L('mina','You — that was *mine*.'),L('osmosis','The bow is still humming in your hand. It\'s all that\'s left of him.')],end:true};
N['cc.let']={lines:[T('You stand at the back and let it play. It is the most beautiful thing you have ever heard and it is eating everyone in the room.',{do:(S,G)=>{G.give('r_bow');G.task('c_choir','done');S.flags.c_done='let';S.flags.reliquaryWeak=1;}}),L('pedigree','Every Kindred in the club is helpless. Anyone who wanted to raid this place would never have a better night.')],end:true};

/* =====================================================================
   5 · THE BUTCHERS — "The Ship of Theseus" (Platform 0)
   ===================================================================== */
pushPop('switchyard',(S,G)=>{if(S.tasks.c_butchers==='active')G.addActor('laurent',X.laurent.spec,{x:3.3,z:2.6,ry:0.6,breathes:true,pose:'sit'});});
pushNpc('switchyard',(S,G)=>G.actor('laurent')?{id:'laurent',actor:'laurent',label:'The patient'}:null);
H.use.laurent=async(S,G)=>G.talk('cb.0');
N['cb.0']={lines:[L('malakor','Kin. Meet Laurent. Courtier to the Gilded Court for a hundred and six years. He would like to die in a car crash on Thursday and wake up on Friday as a man called Gary who works nights at a convenience store.'),
  L('laurent','I\'m so tired of the parties. You can\'t imagine. Every night, the same parties.'),
  L('malakor','He wants a mortal\'s face. Living color, pores, a bad tooth, the lot. I do the bones. You do the face. Borrowed, then sculpted.')],
  opts:[C('abattoir',10,'Take the scalpel. Do the bones under his cheeks.','cb.bones','cb.botch',{id:'cb_ab'}),O('Borrowed Face: give him a face from your last meal.','cb.face',{ab:'borrowed',if:S=>S.flags.cbBones}),
    O('Flesh-Sculpt: make him someone new from scratch.','cb.face',{ab:'borrowed',t2:true,if:S=>S.flags.cbBones}),
    O('Sell him out. Tell Séverine where he is.','cb.betray'),O('"Not tonight."',null,{end:true,leave:true})]};
N['cb.bones']={lines:[T('Malakor shows you where the zygomatic arch can be persuaded. You persuade it. Laurent hums through the whole thing.',{do:S=>S.flags.cbBones=1}),L('malakor','Good hands. Now the skin.')],next:'cb.0'};
N['cb.botch']={lines:[T('The scalpel slips. Laurent screams, a beautiful operatic scream. Malakor takes the blade off you gently.'),L('malakor','...I\'ll finish. You watch.',{do:(S,G)=>{S.flags.cbBones=1;G.rel('malakor',-1);}})],next:'cb.0'};
N['cb.face']={lines:[T('You press your palms to his face and push, and the face underneath forgets itself, and remembers someone else: a little older, a little plainer, a mole by the nose. A face you could pass in the street a thousand times.'),
  L('laurent','...Oh. Oh, I look *boring*. I look like a man who has a dentist. Thank you. Thank you.'),
  L('malakor','Beautiful work, kin. Take this. You\'ve earned the right to hold it.',{do:(S,G)=>{G.give('r_scalpel');G.task('c_butchers','done');G.rel('malakor',2);S.flags.c_done='gary';S.flags.gary=1;G.xp(30,'A new man');}}),
  L('tariq','(Two nights later, at the Lucky Mart, a new clerk called Gary will start the overnight shift. Tariq will say he\'s the best co-worker he\'s ever had.)',{if:()=>false})],end:true};
N['cb.betray']={lines:[T('You send one text to S.: *Laurent. Platform 0. New face. Tonight.*'),T('An hour later a black car pulls up at the Switchyard stairs. Laurent goes up the steps between two men in good coats, wearing half a new face, and doesn\'t look back.',{do:(S,G)=>{G.give('r_scalpel');G.task('c_butchers','done');G.rel('malakor',-3);G.rel('severine',2);S.flags.c_done='betray';S.flags.malakorHates=1;}}),L('malakor','...Keep the scalpel. I want you to remember whose it was.')],end:true};

/* =====================================================================
   6 · THE HOUNDS — "Stray Dog Strut" (Ferrier Lane → the tunnels)
   ===================================================================== */
NL.ROOMS.alley.inter.push({id:'gangblood',label:'Blood on the cobbles',at:[7.0,0.2,2.6],box:[6.4,0,2.0,7.6,0.3,3.2],stand:[6.2,2.0],face:[7,2.6],if:S=>S.tasks.c_hounds==='active'&&!S.flags.chTrail});
H.use.gangblood=async(S,G)=>G.talk('ch.0');
N['ch.0']={lines:[T('A lot of blood, washed thin by the rain. A trainer. A gold chain, snapped. Two Rookery Boys came down this lane tonight and only bits of them left it.'),
  L('parasite','And over it, smeared on the wall at nose height like a signature: Hound musk. Somebody wants this to look like one of yours.',{pass:4}),L('pedigree','Framed. If the Court decides a Hound is killing mortals, every Hound in the Ward goes on the pyre.')],
  opts:[O('Blood-Scent: follow the real trail.','ch.trail',{ab:'scent'}),C('parasite',10,'Follow it with your nose alone.','ch.trail','ch.lose',{id:'ch_par'}),O('Leave it.',null,{end:true,leave:true})]};
N['ch.lose']={lines:[T('The rain wins. The trail goes into a drain and doesn\'t come out.')],end:true};
N['ch.trail']={lines:[T('The real trail glows under the fake one like a vein under skin: down the drain, into the storm tunnels, toward the Switchyard. You follow it on all fours for some of the way, and don\'t think about that.',{do:S=>S.flags.chTrail=1}),
  T('At the end of a dead tunnel, crouched on a nest of rags and bones: something that was a vampire once. Grey, starved, its lips gone, its eyes two red coins. A Wight: a Kindred with nothing human left at all.'),
  T('Around its neck, a leather collar with a brass ring. Somebody owned it. Somebody let it off the leash.'),
  L('frenzy','It wants to fight. Good. GOOD.')],
  opts:[C('frenzy',10,'Put it down.','ch.kill','ch.hurt',{id:'ch_fr'}),O('Jugular Leap.','ch.kill',{ab:'claws',t2:true}),
    C('apex',11,'Leash it. Make it yours.','ch.leash','ch.hurt',{id:'ch_ap'}),O('Back away.',null,{end:true,leave:true})]};
N['ch.kill']={lines:[T('It\'s fast. You\'re faster, or angrier. When it\'s over there is a pile of grey dust in the rags and a collar in your hand.',{fx:['shake:1.2','sfx:crash'],do:(S,G)=>{G.give('r_collar');G.task('c_hounds','done');S.flags.c_done='kill';G.xp(30,'The Wight');}}),
  T('Stamped inside the collar, very small: PROPERTY OF LANTERN · SPECIMEN 4.'),L('web','LANTERN. Harrow\'s people kept this thing. They let it loose to frame the Hounds.',{do:S=>S.flags.knowsLantern=1})],end:true};
N['ch.leash']={lines:[T('You don\'t move. You let it see what\'s in your blood: older, hungrier, *higher*. It lowers its head. It crawls to your feet. It licks your shoe.',{do:(S,G)=>{G.give('r_collar');G.task('c_hounds','done');S.flags.c_done='leash';S.flags.wightPet=1;G.xp(30,'The Wight');}}),
  T('Stamped inside the collar: PROPERTY OF LANTERN · SPECIMEN 4.'),L('web','LANTERN made it. You own it now. On Friday, you could let it off the leash somewhere very crowded.',{do:S=>S.flags.knowsLantern=1})],end:true};
N['ch.hurt']={lines:[T('It opens you from collarbone to hip before you can blink.',{fx:['shake:1.5','hurt:1.2'],do:(S,G)=>{G.vitae(-2);G.comp(-1,'The Wight');}})],next:'ch.trail'};

/* =====================================================================
   7 · THE ALCHEMISTS — "The Broken Clause" (Rookery 6C)
   ===================================================================== */
H.use.door6C=async(S,G)=>{S.aptWho='bath';await G.enterRoom('apt',{x:5.2,z:4.2,ry:-2.4});};
pushPop('apt',(S,G)=>{if(S.aptWho==='bath'&&S.tasks.c_alchemists==='active')G.addActor('ottoline',X.ottoline.spec,{x:4.7,z:3.2,ry:-1.5,breathes:true,pose:'sit'});});
pushNpc('apt',(S,G)=>G.actor('ottoline')?{id:'ottoline',actor:'ottoline',label:'Ottoline'}:null);
H.use.ottoline=async(S,G)=>G.talk('ca.0');
N['ca.0']={lines:[T('Steam. A bathtub full of cold water and ice from the Lucky Mart, and in it, fully clothed, a woman with copper hair whose skin is smoking. Every few seconds a little flame licks up from her wrist and she pushes it under.'),
  L('ottoline','I promised. 1802. "I shall never set foot in Port Vellum again so long as the river runs." The river\'s *still running*. I came for my sister\'s funeral. I thought — I thought —'),
  T('She holds up a vellum contract. Latin, a seal, and the signatures already blistering.'),
  L('pedigree','Contract Bound. Alchemist law. The words are the law; break them and the blood keeps the bargain for you.',{pass:4})],
  opts:[C('pedigree',10,'Read the Latin. Every word.','ca.read','ca.readNo',{id:'ca_ped',mod:S=>S.past==='litigator'?3:0}),
    O('Taste the Vintage: a drop of the burning blood.','ca.taste',{ab:'vintage',once:true}),
    O('Find the loophole: "so long as the river runs".','ca.river',{if:S=>S.flags.caRead}),
    O('Leave her to burn.',null,{end:true,leave:true})]};
N['ca.read']={lines:[T('*...non intrabo urbem Portus Vellum, dum flumen currit...* "I shall not enter the city of Port Vellum while the river runs."'),L('web','"The city." Not the Ward. Not the borough. And the river... which river?',{do:S=>S.flags.caRead=1})],next:'ca.0'};
N['ca.readNo']={lines:[T('The Latin swims. Your Latin is a seminary joke.')],next:'ca.0'};
N['ca.taste']={lines:[T('Her blood is boiling literally: iron, myrrh, the chalky ghost of 1802. And a date in it, like a watermark: the day the Vellum was diverted. 1911. They built the Switchyard over the old river bed.'),L('web','The river she swore by doesn\'t run any more. It\'s under Platform 0, in a cistern, standing still.',{do:S=>{S.flags.caRead=1;S.flags.caRiver=1;}})],next:'ca.0'};
N['ca.river']={lines:[L('you','"The Vellum hasn\'t run since 1911. They buried it under the Switchyard. It\'s a cistern now. It\'s *still*."'),
  T('The flames on her wrist go out. All of them. The steam stops. Ottoline sits in the bathtub of melting ice and stares at you, and then laughs until she cries.',{do:(S,G)=>{G.give('r_contract');G.task('c_alchemists','done');S.flags.c_done='loophole';S.flags.ottolineOwes=1;G.xp(30,'A loophole');}}),
  L('ottoline','I owe you. Properly. Contract-owe. Call on it once and I\'ll come, wherever you are, whatever it costs.'),
  L('tenant','An Alchemist\'s debt. Worth more than a Sheriff\'s badge.')],cs:async(G,S)=>{S.aptWho=null;},end:true};

/* =====================================================================
   8 · THE HOLLOW — "Where the Shadows Go" (Platform 0, the subway car)
   ===================================================================== */
N['hol.car']={lines:[T('Your shadow is sitting on the bricks at the sealed end of the subway car, waiting for you, like a dog outside a shop. When you arrive it gets up and walks *through* the bricks.'),
  L('echo','There\'s a car behind the wall. Pre-war. Nobody has opened it since 1941.')],
  opts:[O('Shadow-Step after it.','hol.in',{ab:'shadowstep'}),C('frenzy',11,'Take the bricks down by hand.','hol.in','hol.no',{id:'hol_fr'}),O('Leave your shadow behind.',null,{end:true,leave:true})]};
N['hol.no']={lines:[T('The bricks don\'t move. They\'re not really bricks, any more than your shadow is really a shadow.')],end:true};
N['hol.in']={lines:[T('Inside: perfect dark, of a kind you have never seen. Not absence of light. The presence of something else. And in the middle of it, lying across three seats like a cat, a man in a coat from the 1600s, very still, very old. Your shadow is curled at his feet.'),
  L('lamplighter','...A child of the Hollow. Come closer. I have been asleep since the Blitz and I am thirsty for news.'),
  L('lamplighter','I will trade you. A sip of my dark for a sip of your light. You have so very much of it still; you were only made on Monday.')],
  opts:[O('Drink the dark.','hol.drink'),O('"No. I keep my light."','hol.refuse')]};
N['hol.drink']={lines:[T('You kneel and he offers his wrist and what comes out is not blood. It is a long cold night in 1588 with no moon, poured into you. You will never be quite afraid of the dark again, because some of it is you now.',{do:(S,G)=>{G.give('r_dark');G.task('c_hollow','done');S.mut.shadowstep=1;G.toast('level','Shadow-Step mutates: Abyssal Pocket','The Lamplighter');G.sync(-5,'Older dark crowds him out');S.flags.c_done='drink';}}),
  L('lamplighter','Good. Now go. And send me a newspaper.')],end:true};
N['hol.refuse']={lines:[L('lamplighter','...Wise. Rude, but wise. Take this anyway. It is only a little dark. Keep it in your pocket for emergencies.',{do:(S,G)=>{G.give('r_dark');G.task('c_hollow','done');S.flags.c_done='refuse';G.comp(1,'You kept your light');}})],end:true};

/* =====================================================================
   9 · THE ROT — "Patient Zero in Ward 4" (St. Jude's)
   ===================================================================== */
const cubB=H.use.cubicle;H.use.cubicle=async(S,G)=>{if(S.tasks.c_rot==='active')return G.talk('cr.0');return cubB(S,G);};
N['cr.0']={lines:[T('Behind the curtain the old diabetic is dead, and smiling, and furred from collar to hairline with soft grey-green mold that glows faintly like a watch face. The nurse on the far side is giggling into her hands.'),
  L('autopsy','Dead two hours. The mold is in the blood, not on the skin. It\'s a culture. Somebody *grew* this.',{pass:5}),L('parasite','It smells of roses. It smells of Rostova\'s basement.')],
  opts:[O('Corpse-Speak: ask him where it came from.','cr.speak',{ab:'corpse',once:true}),
    C('autopsy',10,'Sterilise it. Alcohol, heat, the lot.','cr.kill','cr.killNo',{id:'cr_aut'}),
    O('Breathe it in. Let it grow in you.','cr.grow'),O('Leave him.',null,{end:true,leave:true})]};
N['cr.speak']={lines:[T('You put your hand on his chest and ask. His nerves answer like a radio between stations: *injection. Tuesday. The doctor. "Just a supplement, Mr. Hale." Basement. Cold. Seven others. Seven.*'),
  L('web','Rostova is testing things on her free-clinic patients. In the basement. Tuesdays.',{do:S=>{S.flags.knowSeven=1;S.flags.crSpoke=1;}})],next:'cr.0'};
N['cr.kill']={lines:[T('Surgical spirit from the trolley, the steriliser\'s UV wand at arm\'s length, a trash bag. It screams very faintly as it dies.',{do:(S,G)=>{G.give('r_mold');G.task('c_rot','done');S.flags.c_done='sterile';G.xp(30,'Ward 4 is clean');G.comp(1,'You stopped it');}}),L('autopsy','You kept a sample. Of course you did.')],end:true};
N['cr.killNo']={lines:[T('You get most of it. A spore cloud puffs up when you lift the sheet and the nurse starts laughing again.')],next:'cr.0'};
N['cr.grow']={lines:[T('You lean over him and breathe in. It goes down like warm smoke and settles in your lungs, and it is *happy* there, and so, for a moment, are you.',{do:(S,G)=>{G.give('r_mold');G.task('c_rot','done');S.flags.c_done='grow';S.flags.moldLungs=1;G.toast('level','Miasma costs no Vitae while the mold lives in you.','Ward 4');}}),
  L('rigor','You are a garden now. Try not to think about it.')],end:true};

/* =====================================================================
   10 · THE STRAY — "King of the Trash Heap" (the Rookery roof)
   ===================================================================== */
// handled in the roof scene below

/* =====================================================================
   THE ROOKERY: roof, 3B (Leo), 404 (the crying wall), mailboxes
   ===================================================================== */
H.exit.toRoof=async(it,S,G)=>{await G.talk('roof.0');return false;};
N['roof.0']={lines:[T('Six flights up, a fire door, and the roof: tar paper, puddles, a water tower, and the whole Marrow Ward laid out in sodium orange under a low brown sky.'),
  T('In the corner behind the water tower: a nest of sandbags and a folding chair facing St. Jude\'s across the street. A rifle bipod. Shell casings, odd ones, with a blue band.',{if:S=>!S.flags.nestCleared}),
  L('sundial','Those are UV rounds. Somebody sat up here and watched the clinic with a gun that shoots sunlight.',{if:S=>!S.flags.nestCleared,pass:6}),
  T('A dozen young vampires sit on upturned crates around a camping lantern, arguing about electricity.',{if:S=>S.clan==='stray'&&S.tasks.c_stray==='active'})],
  opts:[O('Clear out the nest and make it yours.','roof.clear',{if:S=>!S.flags.nestCleared}),
    O('Bed down in the nest until tomorrow night.',null,{if:S=>S.flags.nestCleared&&NL.Camp.canSleep(S),end:true,do:()=>setTimeout(()=>NL.Camp.sleep('rookery'),300)}),
    O('Join the meeting.','cst.0',{if:S=>S.clan==='stray'&&S.tasks.c_stray==='active'}),
    O('Go back down.',null,{end:true,leave:true})]};
N['roof.clear']={lines:[T('You pile the sandbags into walls, hang the tarp across the top, wedge the door. Behind the water tower, out of the wind, there is just enough dark for a body to sleep in.',{do:(S,G)=>{S.flags.nestCleared=1;G.tick(15);}}),
  T('Under the folding chair: a thermos, a logbook. The last entry is Sunday night. *Subject V. entered clinic 22:40 with case. R. confirms the apparatus. Await go.*',{do:S=>{S.flags.sniperLog=1;S.flags.knowsLantern=1;}}),
  L('web','Somebody was watching Vane go into the clinic on Sunday. "R. confirms." R.')],next:'roof.0'};
N['cst.0']={lines:[L('dutch','New face! Clanless? Good. Sit. We\'re unionizing.'),
  L('dutch','The Elders treat us like rats. Fine. Rats chew wires. We want to rig the whole Rookery grid so that every light in the building goes UV the second anyone with a Court ring walks through the door. An Elder-proof building. Our building.'),
  L('dutch','We need someone who can talk to the transformer. You, maybe?')],
  opts:[O('Spark-Jump: wire the transformer.','cst.wire',{ab:'spark'}),C('gutter',10,'"You\'ll fry yourselves. Here\'s how to do it without dying."','cst.advise','cst.no',{id:'cst_gut'}),O('"Count me out."',null,{end:true,leave:true})]};
N['cst.wire']={lines:[T('You put your palm on the transformer box and drink. It tastes of copper and thunder. When you take your hand away, every bulb in the Rookery flickers violet, then back to yellow, waiting.',{do:(S,G)=>{G.give('r_union');G.task('c_stray','done');S.flags.c_done='wired';S.flags.rookerySafe=1;G.offer('union');G.xp(30,'Local 0');}}),
  L('dutch','Brothers and sisters: the Rookery is ours.')],end:true};
N['cst.advise']={lines:[T('You draw it on the back of a flyer: which breaker, which wire, which way to stand. Dutch copies it carefully with his tongue between his teeth.',{do:(S,G)=>{G.give('r_union');G.task('c_stray','done');S.flags.c_done='advised';S.flags.rookerySafe=1;G.offer('union');}}),L('dutch','You\'re in the union. Card number one.')],end:true};
N['cst.no']={lines:[L('dutch','Yeah, yeah, we know. We\'re going to do it anyway.')],next:'cst.0'};

// 3B: Leo's apartment (side quest: The Dishwasher's Alibi)
H.exit.to3B=async(it,S,G)=>{S.aptWho='leo';return true;};
H.exit.to404=async(it,S,G)=>{S.aptWho='404';return true;};
const leoHome=S=>S.night>=2&&leoAlive(S)&&!S.flags.leoGoneTown&&S.flags.tedState!=='hiding_back';
pushPop('apt',(S,G)=>{if(S.aptWho==='leo'&&leoHome(S))G.addActor('leo',NL.CHARS.leo.spec,{x:2.2,z:3.85,ry:0.6,breathes:true,pose:'sit'});
  if(S.aptWho==='404'){G.addActor('okafor',X.okafor.spec,{x:2.4,z:3.85,ry:-0.4,breathes:true,pose:'sit'});if(S.flags.ezraFree&&!S.flags.ezraGone)G.addActor('ezra',X.ezra.spec,{x:1.1,z:2.9,ry:1.2,breathes:true,pose:'crouch'});}});
pushNpc('apt',(S,G)=>[G.actor('leo')?{id:'leo',actor:'leo',label:'Leo'}:null,G.actor('okafor')?{id:'okafor',actor:'okafor',label:'Mrs. Okafor'}:null,G.actor('ezra')?{id:'ezra',actor:'ezra',label:'Ezra'}:null].filter(Boolean));
pushEnter('apt',async(S,G)=>{NL.ROOMS.apt.name=({leo:'Room 3B',
  '404':'Room 404','5A':'Room 5A',bath:'Room 6C'})[S.aptWho]||'Apartment';if(S.aptWho==='leo'&&!leoHome(S)&&G.once('leoEmpty'+S.night))await G.say([T(S.flags.leoDead?'Room 3B. A cactus called Gerald on the windowsill, a stack of joke notebooks, a sink full of mugs. Nobody is ever coming home to it.':'Room 3B is empty. A note on the fridge: GONE TO MOM\'S. FEED GERALD. Gerald is a cactus.')]);});
const leoUse=H.use.leo;
H.use.leo=async(S,G)=>{if(S.room==='apt')return G.talk(S.seen['l2.0']?'l2.hub':'l2.0');return leoUse?leoUse(S,G):false;};
N['l2.0']={enter:(S,G)=>{G.focus(['you','leo'],.8);G.look('leo','you');G.look('you','leo');},lines:[
  T(S=>({forgot:'Leo opens the door in a dressing gown with a cactus in his arms. He doesn\'t know you. He invites you in anyway, because that\'s who he is.',ally:'Leo opens the door, sees you, and pulls you inside by the sleeve before anyone in the corridor can look.',thrall:'Leo is waiting behind the door. He has been waiting since sunset. He has made you a cup of tea you can\'t drink.',paid:'Leo opens the door three inches on the chain, sees you, and closes his eyes.'})[S.flags.tedState]||'Leo opens the door. He has a bandage on his neck and a cactus on the windowsill.'),
  L('leo',S=>({forgot:'Do I know you? You look like someone from a dream I keep having. A bad one. With hooks.',ally:'Okay. Okay okay. A detective came here this morning. Miller. She asked me a lot of questions about a "night-shift person". I said you were a co-worker called Dave.',thrall:'You came! You came. Do you need anything? I could do anything. I\'ve been thinking about it all day.',paid:'I didn\'t say anything. I want you to know I didn\'t say anything. The detective came. I didn\'t say anything.'})[S.flags.tedState]||'Hi. Hey. That detective came round asking about you.'),
  L('web','Miller has been here. She\'s working outward from Leo. Sooner or later she gets to you.',{pass:5,do:(S,G)=>{G.task('s_leo');S.quests.note_s_leo='Miller is circling Leo. Get him out of the Ward, bind him, or make sure he never talks.';G.fact('leo','apartment');}})],next:'l2.hub'};
N['l2.hub']={opts:[
  O('"Gideon at the Pawn & Coffin makes passports. Want a new life somewhere sunny?"','l2.passport',{once:true,if:S=>!S.flags.passportAsk}),
  O('Give him the forged passport.','l2.give',{if:(S,G)=>G.has('passport')}),
  O('Open your wrist. "Drink. You\'ll never be afraid again."','l2.ghoul',{if:S=>S.flags.tedState!=='thrall',blood:1}),
  O('Crown of Fog: take the whole week out of his head.','l2.fog',{ab:'fog',if:S=>S.flags.tedState!=='forgot'}),
  O('"What did you tell Miller, exactly?"','l2.told',{once:true}),
  O('Make sure he never talks. Ever.','l2.silence',{if:S=>S.night>=2}),
  O('"Look after Gerald."',null,{end:true,leave:true})]};
N['l2.passport']={lines:[L('leo','Passports? Like a spy? I\'ve never been further than the coast. ...Somewhere sunny. Ha. You\'d hate it.'),L('leo','Yeah. Yeah, okay. Junie could visit. Mom would kill me. Mom would get over it.',{do:S=>{S.flags.passportAsk=1;S.quests.note_s_leo='Get Leo a forged passport from Gideon at the Pawn & Coffin ($150, or a favour), and bring it to Room 3B.';}})],next:'l2.hub'};
N['l2.give']={lines:[T('He opens it. His own face, a different name: LEON PRUETTE. Born in a town he\'s never been to.'),L('leo','Leon Pruette. That\'s a *stage name*. That\'s a stage name if I ever heard one.'),
  L('leo','I\'ll go Thursday. Bus to the coast. I\'ll do open mics on the pier. Thank you. Thank you, night person.',{do:(S,G)=>{G.take('passport');S.flags.leoGoneTown=S.night+1;G.task('s_leo','done');G.rel('leo',2);G.comp(2,'You got him out');G.offer('shepherd');}}),
  L('nostalgia','Somebody\'s going to get out of this city alive. It\'s not going to be you. It\'s going to be him. That\'s enough.')],end:true};
N['l2.ghoul']={lines:[L('pedigree','Making a ghoul without the Court\'s leave is a crime. So is everything else you\'ve done this week.'),
  T('He drinks like a kid drinking from a garden hose: fast and messy and laughing. When he looks up his pupils are huge and soft and entirely yours.',{fx:['flash'],do:(S,G)=>{if(!G.thought('thrallmaster'))G.vitae(-1);S.flags.tedState='thrall';S.flags.illegalThrall=1;S.flags.leoGhoul=1;G.rel('leo',3);G.task('s_leo','done');G.comp(-1,'You made a thrall');}}),
  L('leo','Oh, *wow*. Okay. I would die for you. Is that weird? That\'s weird. I\'d do it though.')],end:true};
N['l2.fog']={lines:[T('You take the week out of him like a splinter: the freezer, the hook, you. It leaves a soft blank space he\'ll fill with something kinder.',{do:(S,G)=>{S.flags.tedState='forgot';G.task('s_leo','done');S.flags.leoFogged=1;}}),L('leo','...Sorry, I think I\'ve got a migraine coming. Who are you, again?')],end:true};
N['l2.told']={lines:[L('leo','That I fell asleep in the walk-in. That someone let me out. That I didn\'t see who.'),L('leo','She didn\'t believe me. She looked at my neck for ages. She said, "Leo, if somebody hurt you, I can protect you." And I almost —'),L('pulse','He almost told her. He still might.')],next:'l2.hub'};
N['l2.silence']={lines:[L('pulse','No. Not him. Not after everything. Not *him*.'),L('frenzy','It\'s the safest thing. It\'s the only safe thing.')],
  opts:[O('Do it.','l2.kill'),O('"...No. Forget I was here."','l2.hub')]};
N['l2.kill']={lines:[T('He doesn\'t understand until it\'s too late, and then he does, and he says your name. Your real one. You never told him your real name. You don\'t remember it yourself.'),
  T('It is very quiet in Room 3B afterwards.',{fx:['flash','sfx:drink'],do:(S,G)=>{G.feed(5,'melancholic','Leo, all of him',{kind:'mortal',kill:true});S.flags.leoDead=1;S.flags.tedState='dead';G.comp(-4,'You killed Leo');G.heat(1);G.task('s_leo','done');G.offer('darwin');G.sync(6,'The Tenant approves of efficiency');}}),
  L('tenant','...I would have done the same. I want you to know that I am not saying that to make you feel better.')],cs:async(G,S)=>{G.dlgHide();G.pose('leo','slump',2);await G.wait(1.4);G.removeActor('leo');},end:true};

// 404: The Crying Wall
H.use.okafor=async(S,G)=>G.talk(S.flags.met404?'w4.hub':'w4.0');
N['w4.0']={enter:(S,G)=>{G.focus(['you','okafor'],.8);G.look('okafor','you');},lines:[
  T('A tiny old woman in a cardigan in a flat full of photographs, most of them of the same smiling girl. A rosary. A cup of tea gone cold. She doesn\'t get up.'),
  L('okafor','Are you from the council? About the noise? Nobody believes me about the noise.'),
  L('okafor','It\'s in the chimney. Scratching. At night. Ten years I\'ve heard it, and since my granddaughter went missing, it\'s *crying*.'),
  L('web','Okafor. Dani Okafor. One of the faces on the MISSING posters in the lane.',{pass:5,do:(S,G)=>{S.flags.met404=1;G.task('s_404');S.quests.note_s_404='Something has been scratching inside Mrs. Okafor\'s chimney for ten years. Her granddaughter Dani is one of the seven missing.';}})],next:'w4.hub'};
N['w4.hub']={opts:[O('Look at the chimney.','w4.chim',{if:S=>!S.flags.ezraFree}),O('"Tell me about Dani."','w4.dani',{once:true}),O('"I\'ll find out what happened to her."','w4.promise',{once:true,if:S=>S.seen['w4.dani']}),O('Leave her be.',null,{end:true,leave:true})]};
H.use.chimney=async(S,G)=>{if(S.aptWho==='404')return G.talk(S.flags.ezraFree?'w4.after':'w4.chim');return G.say([T('A chimney breast, bricked up, painted over three times.')]);};
N['w4.dani']={lines:[L('okafor','She\'s nineteen. She has asthma. She went to the free clinic at St. Jude\'s for her inhaler, on a Tuesday, three weeks ago, and she never came home.'),L('okafor','The detective lady comes round. She\'s kind. She doesn\'t know anything either.',{do:S=>S.flags.daniClinic=1})],next:'w4.hub'};
N['w4.promise']={lines:[L('you','"I\'ll find out what happened to her."'),L('okafor','...Everybody says that. You say it like you mean it. That\'s worse, somehow.',{do:(S,G)=>{G.promise('dani','Find out what happened to Dani Okafor');S.flags.daniPromise=1;}})],next:'w4.hub'};
N['w4.chim']={lines:[T('You put your ear to the painted brick. Behind it, very faint: fingernails on mortar, slow and patient. And breathing that isn\'t breathing.'),
  L('parasite','Not a rat. A *vampire*. Starved down to almost nothing. Torpid, waking a little every night, scratching, falling back.',{pass:4}),
  L('tenant','...Oh. Oh, Ezra. I forgot you were there. God help me, I forgot.')],
  opts:[O('"Why is there a vampire in her chimney, Absalom?"','w4.why',{once:true}),O('Take the bricks down.','w4.open'),O('Leave him. Tell her it\'s rats.','w4.rats'),O('Step back.','w4.hub')]};
N['w4.why']={lines:[L('tenant','2016. Ezra was a neonate who saw something he shouldn\'t: men in a van with federal plates taking a vampire off the street with a light that burned like noon. LANTERN, before it had a name. They were looking for him.'),
  L('tenant','I hid him. I bricked him in where nobody would ever look and I fed him through a gap once a week, and then the Court made me busy, and then... I forgot. I simply forgot.'),
  L('pulse','He sounds ashamed. You didn\'t know he could.',{do:S=>S.flags.ezraWhy=1})],next:'w4.chim'};
N['w4.open']={lines:[T('The bricks come out one by one. Behind them, folded into the flue like a letter in an envelope: a young man, grey, curled, with eyes like two coals that have nearly gone out.'),
  T('Mrs. Okafor makes a small sound and holds the rosary very tight.'),
  L('ezra','...Hungry. Hungry. Hungry. Is it 2016? Is the Sheriff here?'),
  L('parasite','He\'s going to go for her. He can\'t help it. Ten years.',{pass:2})],
  opts:[O('Give him a blood bag. Now.','w4.feed',{if:(S,G)=>G.has('bloodbag')}),O('Give him your wrist.','w4.wrist',{blood:1}),C('apex',10,'"Down. *Down*."','w4.hold','w4.attack',{id:'w4_ap'}),O('End him before he moves.','w4.end')]};
N['w4.feed']={lines:[T('He tears the bag open with his teeth and drinks it on the floor like a dog, and sobs, and drinks.',{do:(S,G)=>{G.take('bloodbag');S.flags.ezraFree=1;G.task('s_404','done');G.xp(40,'Ezra');}}),L('ezra','Thank you. Thank you. They\'re still out there, aren\'t they? The men with the light.'),L('okafor','...I\'ll make him a cup of tea. I don\'t know what else to do.')],next:'w4.after'};
N['w4.wrist']={lines:[T('You open your wrist and he latches on and you have to pry him off, and you\'re lighter afterwards in a way you don\'t like.',{do:(S,G)=>{G.vitae(-2);S.flags.ezraFree=1;G.task('s_404','done');G.xp(40,'Ezra');S.flags.ezraBond=1;}}),L('ezra','You taste like him. Like the Sheriff. Are you him?')],next:'w4.after'};
N['w4.hold']={lines:[T('He stops halfway out of the flue, shaking.'),L('ezra','...Yes. Yes. Down.'),T('He gets out slowly, keeping away from her, and sits in the corner with his arms round his knees.',{do:(S,G)=>{S.flags.ezraFree=1;G.task('s_404','done');G.xp(40,'Ezra');}})],next:'w4.after'};
N['w4.attack']={lines:[T('He goes for her. You get between them. He bites your arm instead, deep, and hangs on.',{fx:['shake:1'],do:(S,G)=>{G.vitae(-2);G.comp(-1,'Bitten');S.flags.ezraFree=1;G.task('s_404','done');}}),L('okafor','Holy Mary, Mother of God —')],next:'w4.after'};
N['w4.end']={lines:[T('Quick, before he wakes properly. It is the kindest thing you have done all week and it feels exactly like the worst.',{do:(S,G)=>{G.task('s_404','done');S.flags.ezraDead=1;S.kills++;G.comp(-1,'You ended him');}}),L('okafor','...Was that the noise? Was that all it was?')],end:true};
N['w4.rats']={lines:[L('you','"Rats, Mrs. Okafor. Big ones. I\'ll have the council send someone."'),L('okafor','Rats. Of course. Ten years of rats.',{do:(S,G)=>{G.task('s_404','done');S.flags.ezraLeft=1;}}),L('pulse','She doesn\'t believe you. She\'s too tired not to pretend she does.')],end:true};
H.use.ezra=async(S,G)=>G.talk('w4.after');
N['w4.after']={lines:[L('ezra','The men with the light. Federal. They had a list, in 2016. Vampires and the people who fed them. A doctor was helping them: young, then. Clever hands.'),
  L('ezra','She\'d bring them blood samples from her clinic. She\'d point. They\'d come at night with the light.'),
  L('web','A doctor, eight years ago, pointing LANTERN at vampires from her clinic. Rostova\'s been doing this for a long time.',{do:S=>{S.flags.ezraTold=1;S.flags.knowsLantern=1;}}),
  L('ezra','I\'ll go down to Mother Soot. She always liked me. If you need me on Friday, call down a drain.',{do:S=>{S.flags.ezraAlly=1;}})],cs:async(G,S)=>{S.flags.ezraGone=1;},end:true};

// mailboxes: a fragment of who you were
H.use.mailboxes=async(S,G)=>G.talk('mb.0');
N['mb.0']={lines:[T('A wall of brass mailboxes, most of them dented, some of them taped shut. One for every flat in the Rookery. Your eyes go straight to 2C before you know why.'),L('nostalgia','You lived here. Two years. You had a plant that died and a neighbor who played the trumpet at three a.m.',{pass:5,if:S=>!S.th.done.includes('amnesiac')})],
  opts:[O('Open 2C.','mb.open',{if:S=>!S.flags.frag_letter&&!S.th.done.includes('amnesiac')}),O('Leave it shut.',null,{end:true,leave:true})]};
N['mb.open']={lines:[T('The lock gives to a thumbnail; it always did. Inside: a final notice from the electricity company, a catalogue, and a postcard of the sea.'),
  T('*Hope the new job\'s less awful than the last one. Call Mom, she worries. Love, your sister.* No name, just a doodle of a fish. Your name on the front. You read it twice and it still doesn\'t sound like anyone.',{do:(S,G)=>{G.give('letter');S.flags.frag_letter=1;G.task('x_name');S.quests.note_x_name='Fragments of who you were. You have found: '+['watch','letter','chart'].filter(k=>S.flags['frag_'+k]).join(', ')+'. One more waits in still water.';}}),
  L('nostalgia','A sister. You have a sister. Somewhere by the sea there is somebody who thinks you\'re alive.')],end:true};

/* =====================================================================
   SIDE QUESTS around the district
   ===================================================================== */
// Velvet Rope Blues: Tiny's dialysis
NL.ROOMS.stjude.inter.push({id:'supplies',label:'Supply room',at:[4.6,1.3,0.1],box:[4.2,0,0,5.0,2.1,0.2],stand:[4.6,0.8],face:[4.6,0]});
const sjB=NL.ROOMS.stjude.build;NL.ROOMS.stjude.build=function(rb,S){sjB.call(this,rb,S);NL.PROPS.door(rb,4.2,5.0,0,2.1,NL.mats().white);};
H.use.supplies=async(S,G)=>G.talk('sup.0');
N['sup.0']={lines:[T('A door marked SUPPLIES · STAFF ONLY, propped open with a box of gauze. Inside: shelves of tubing, bags of saline, gowns, masks, a dialysis kit in a sealed white case.')],
  opts:[O('Take a triage mask from the dispenser.','sup.mask',{if:(S,G)=>!G.has('triagemask')}),
    C('stagecraft',9,'Walk out with the dialysis kit like you work here.','sup.kit','sup.no',{id:'sup_kit',if:(S,G)=>S.tasks.s_tiny==='active'&&!G.has('dialysis'),mod:(S,G)=>(S.past==='paramedic'?3:0)+(G.equipped('triagemask')?1:0)}),
    O('Take a box of latex gloves.','sup.gloves',{if:(S,G)=>!G.has('latex')}),
    O('Take a yellow morgue smock off the hook.','sup.smock',{if:(S,G)=>!G.has('smock')&&S.night>=2}),
    O('Leave.',null,{end:true,leave:true})]};
N['sup.mask']={lines:[T('A pale-blue surgical mask, loops behind the ears. In here it makes you invisible.',{do:(S,G)=>G.give('triagemask')})],next:'sup.0'};
N['sup.gloves']={lines:[T('Powder-free. A hundred of them.',{do:(S,G)=>G.give('latex')})],next:'sup.0'};
N['sup.smock']={lines:[T('Yellow, rubberised, wipe-clean.',{do:(S,G)=>G.give('smock')})],next:'sup.0'};
N['sup.kit']={lines:[T('You walk out with it under your arm, nodding at the nurse, who nods back.',{do:(S,G)=>{G.give('dialysis');S.quests.note_s_tiny='You have a dialysis kit. Take it to Tiny at the Reliquary door.';}})],next:'sup.0'};
N['sup.no']={lines:[L('nurse','Where are you going with that, baby?'),T('You put it back.')],next:'sup.0'};
const tinyB=H.use.tiny;H.use.tiny=async(S,G)=>{if(S.tasks.s_tiny==='active'&&(G.has('dialysis')||S.night>=2))return G.talk('tk.0');return tinyB(S,G);};
N['tk.0']={lines:[L('tiny','You again.')],opts:[O('Give him the dialysis kit.','tk.kit',{if:(S,G)=>G.has('dialysis')}),O('Open your wrist. "This will fix your kidneys. And other things."','tk.blood',{blood:1}),O('"Let me down to the crypt."','tiny.0'),O('Nothing.',null,{end:true,leave:true})]};
N['tk.kit']={lines:[T('He opens the case, looks inside, closes it. His jaw works. He doesn\'t say anything for long enough that you think he\'s going to throw you down the stairs.',{do:(S,G)=>{G.take('dialysis');G.task('s_tiny','done');G.rel('tiny',3);S.flags.tinyLoyal=1;S.flags.vipOK=1;}}),
  L('tiny','...My sister\'s a nurse. She can run this at home. I don\'t — nobody —'),L('tiny','The door\'s yours. Any door in this building. Any time.')],end:true};
N['tk.blood']={lines:[T('He looks at your wrist the way a drowning man looks at a rope he knows is attached to something worse.'),T('He drinks. Color comes back into his face like a tide.',{fx:['flash'],do:(S,G)=>{if(!G.thought('thrallmaster'))G.vitae(-1);G.task('s_tiny','done');G.rel('tiny',3);S.flags.tinyLoyal=1;S.flags.tinyGhoul=1;S.flags.vipOK=1;}}),
  L('tiny','...I can feel my feet. I haven\'t felt my feet since June.'),L('tiny','Whatever you need. Whenever. The door\'s yours.')],end:true};

// The Butcher's Ledger: Kowalski's manifests (back room filing cabinet)
const cabB=H.use.cabinet;H.use.cabinet=async(S,G)=>{if(S.night>=2)return G.talk('led.0');return cabB?cabB(S,G):false;};
N['led.0']={lines:[T('Margo\'s filing cabinet, drawer by drawer. Most of it is invoices for pork. The bottom drawer is shipping manifests, carbon copies, 1984 to last week: RENDERING · GILDED COURT · 1 UNIT. Over and over. Hundreds of them.'),
  L('abattoir','"Rendering." Fat, bone, the parts nobody buys. Or a body.',{pass:5})],
  opts:[C('web',10,'Decode the dates against the missing-persons posters.','led.ok','led.no',{id:'led_web',if:S=>!S.flags.ledgerDone}),O('Take them.','led.take',{if:(S,G)=>!G.has('manifest')}),O('Shut the drawer.',null,{end:true,leave:true})]};
N['led.ok']={lines:[T('You lay the manifests out on the floor in date order. Forty years of "units". Then the last two months: seven units. Seven dates. Each one the Wednesday after a disappearance. Signed for at the Gilded Court\'s service door. Counter-signed: E.R.'),
  L('web','Kowalski\'s has been disposing of bodies for the Gilded Court for forty years. And the seven missing came here, after the clinic, signed for by E.R. Elena Rostova.',{do:(S,G)=>{S.flags.ledgerDone=1;G.task('s_ledger');G.task('s_ledger','done');G.fact('margo','render');S.flags.knowSeven=1;G.xp(30,'The manifests');}}),
  L('nostalgia','Dani Okafor. Pete Sowa. Seven people. Rendered.',{if:S=>S.flags.met404})],next:'led.0'};
N['led.no']={lines:[T('Dates and dates and dates. Your eyes slide off them.')],next:'led.0'};
N['led.take']={lines:[T('You fold them into your coat.',{do:(S,G)=>G.give('manifest')})],next:'led.0'};

// The Bad Batch: Grave-Dust at the Reliquary
pushPop('reliquary',(S,G)=>{if(S.night>=2&&S.night<=3&&!S.flags.batchDone)G.addActor('pixel',X.pixel.spec,{x:2.6,z:4.0,ry:2.2,breathes:true,pose:'lean'});});
pushNpc('reliquary',(S,G)=>G.actor('pixel')?{id:'pixel',actor:'pixel',label:'Kid with green hair'}:null);
H.use.pixel=async(S,G)=>G.talk('px.0');
N['px.0']={lines:[T('A kid with green hair and a clip-seal bag of grey powder that glitters under the club lights like crushed mirror. Two ravers in front of him have pupils like dinner plates and are trying to fight the bass.'),
  L('parasite','That\'s ash. Vampire ash. Cut with ketamine and something else. Snort it and you get Kindred rage for an hour.',{pass:5}),
  L('pixel','Grave-Dust, friend. Feel like a god. Twenty a bag. You look like you could use it. You look *dead*.')],
  opts:[O('Buy a bag. ($20)','px.buy',{if:S=>(S.cash||0)>=20}),C('apex',9,'"Where do you get it?"','px.src','px.no',{id:'px_ap'}),O('Kneel: "Tell me where it comes from."','px.src',{ab:'kneel'}),O('Leave.',null,{end:true,leave:true})]};
N['px.buy']={lines:[T('He slips it into your palm with a wink.',{do:(S,G)=>{G.cash(-20,'Grave-Dust');G.give('grave');G.task('s_batch');S.quests.note_s_batch='Grave-Dust is vampire ash cut with ketamine, sold at the Reliquary. Find who cooks it.';}}),L('osmosis','Taste it. Go on. Just on your tongue. Find out whose it was.')],next:'px.0'};
N['px.src']={lines:[L('pixel','Okay, okay! Platform 0. Guy called Rook cooks it in the back of Malakor\'s place. Says he gets the ash from a butcher shop. Says it\'s *pork*. Ha.'),
  L('web','Ash from a butcher shop. Kowalski\'s. Forty years of rendering... and a bucket of the Sheriff, if you swept him into one.',{do:(S,G)=>{G.task('s_batch');S.flags.batchSource=1;S.quests.note_s_batch='Rook cooks Grave-Dust on Platform 0 from ash out of Kowalski\'s. Shut it down, take a cut, or give it to Miller.';}}),L('tenant','Tell me I am not being snorted at a nightclub. TELL me.',{if:S=>S.flags.ashGone==='bucket'})],next:'px.0'};
N['px.no']={lines:[L('pixel','Ha. No.')],next:'px.0'};
NL.ROOMS.switchyard.inter.push({id:'cookbench',label:'Rook\'s cook table',at:[10.4,1.2,5.0],box:[9.8,0,4.7,11,1.1,5.3],stand:[9.6,4.2],face:[10.4,5],if:S=>S.flags.batchSource&&!S.flags.batchDone});
const yB=NL.ROOMS.switchyard.build;NL.ROOMS.switchyard.build=function(rb,S){yB.call(this,rb,S);if(S.flags.batchSource&&!S.flags.batchDone){const m=NL.mats();rb.box([9.8,0,4.7],[11,0.9,5.3],m.steelDark,{block:true});rb.box([9.9,0.9,4.8],[10.9,0.95,5.2],m.white,{noDepth:true});}};
H.use.cookbench=async(S,G)=>G.talk('ck.0');
N['ck.0']={lines:[T('A steel table at the edge of the platform: scales, a hot plate, a heap of grey ash on a sheet of newspaper, and a skinny man in a respirator weighing it into baggies with a teaspoon.'),
  L('osmosis','Forty years of the dead, mixed together. Some of them were Kindred. Some of them were just people.',{pass:5})],
  opts:[O('Tip it all into the fire barrel.','ck.burn'),C('velvet',10,'"Malakor wants a bigger cut. Mine."','ck.cut','ck.no',{id:'ck_vel'}),O('Photograph it and send it to Miller\'s tip line.','ck.miller',{if:S=>S.dos.miller}),O('Leave it.',null,{end:true,leave:true})]};
N['ck.burn']={lines:[T('The ash goes into the fire with a sound like a sigh. Rook screams through his respirator. The flames go blue, then violet, then white for one long second, and then it\'s just a barrel.',{do:(S,G)=>{S.flags.batchDone='burn';G.task('s_batch','done');G.rel('malakor',-1);G.xp(30,'The Bad Batch');G.comp(1,'Laid to rest');}})],end:true};
N['ck.cut']={lines:[L('rook','...Fine. Fifty a week. Don\'t tell him.',{do:(S,G)=>{S.flags.batchDone='cut';G.task('s_batch','done');G.cash(100,'Your cut');G.offer('capitalism');}})],end:true};
N['ck.no']={lines:[L('rook','The boss didn\'t say nothing to me.')],next:'ck.0'};
N['ck.miller']={lines:[T('Click. Send. Tip line.',{do:(S,G)=>{S.flags.batchDone='miller';G.task('s_batch','done');G.rel('miller',1);S.flags.millerTheory=S.flags.millerTheory||'syndicate';G.xp(20,'A tip');}}),L('web','Miller will come down here with a warrant and a SWAT team in a day or two. Malakor will know someone sent her.')],end:true};

// Hematology vault (The Midnight Triage Heist)
NL.ROOMS.stjude.inter.push({id:'vault',label:'Hematology vault',at:[2.9,1.3,0.1],box:[2.45,0,0,3.35,2.2,0.15],stand:[2.9,0.8],face:[2.9,0]});
const sjB2=NL.ROOMS.stjude.build;NL.ROOMS.stjude.build=function(rb,S){sjB2.call(this,rb,S);const m=NL.mats();rb.box([2.45,0,0],[3.35,2.2,0.12],m.steelDark);rb.cyl([2.9,1.2,0.12],0.22,0.22,0.05,m.chrome,{rot:[Math.PI/2,0,0]});};
H.use.vault=async(S,G)=>G.talk('vt.0');
N['vt.0']={lines:[T('A steel door with a wheel and a card reader: HEMATOLOGY · AUTHORISED PERSONNEL. Behind it, Parasite tells you, two hundred pints of whole blood at four degrees.'),
  L('nostalgia','The night nurse keeps her card on a lanyard and takes it off to wash her hands.',{pass:7})],
  opts:[O('Use the vault card.','vt.in',{if:(S,G)=>G.has('vegancard')}),C('velvet',10,'Ask the night nurse to let you in. Sweetly.','vt.card','vt.no',{id:'vt_vel',if:(S,G)=>!G.has('vegancard')}),
    O('Spark-Jump the reader.','vt.in',{ab:'spark'}),O('Leave.',null,{end:true,leave:true})]};
N['vt.card']={lines:[L('nurse','You want the *vault*? ...Oh, honey. You\'re one of Dr. R\'s, aren\'t you. Fine. Five minutes. Don\'t take the B-negative, it\'s for a baby.',{do:(S,G)=>{G.give('vegancard');G.task('s_vault');}})],next:'vt.0'};
N['vt.no']={lines:[L('nurse','Nice try.')],end:true};
N['vt.in']={lines:[T('Cold air, a hum, racks of red. You need to be quick and quiet and look like you belong.')],
  opts:[C('echo',9,'Mind the camera in the corner.','vt.cam','vt.caught',{id:'vt_echo'}),O('Leave.',null,{end:true,leave:true})]};
N['vt.cam']={lines:[T('Under the camera, along the wall, out of its cone.')],opts:[C('stagecraft',9,'Bag five pints and walk out like a porter.','vt.ok','vt.caught',{id:'vt_stg',mod:(S,G)=>G.equipped('smock')||G.equipped('triagemask')?2:0})]};
N['vt.ok']={lines:[T('Five bags in a cool-box. Out the door. Nobody looks up.',{do:(S,G)=>{G.give('bloodbag',5);G.task('s_vault');G.task('s_vault','done');G.xp(30,'The vault');if(!G.equipped('latex'))S.flags.prints=1;}}),L('pulse','Bagged blood. Nobody has to bleed for this. Hold on to that.')],end:true};
N['vt.caught']={lines:[T('An alarm, polite and electronic. You leave fast with two bags instead of five.',{do:(S,G)=>{G.give('bloodbag',2);G.heat(1);G.task('s_vault');G.task('s_vault','done');}})],end:true};
})();
