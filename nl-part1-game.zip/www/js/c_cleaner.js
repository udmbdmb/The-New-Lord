'use strict';
/* THE NEW LORD — "The Cleaner": when you leave witnesses, the Court sends someone to tidy them. He's very polite. He'd like your opinion on each of them. */
(function(){const X=NL.EXTRAS;
X.vole={n:'Mr. Vole',color:'#a0a090',role:'The Court\'s cleaner',spec:{face:{long:1.15,cheek:1.0,jaw:.8,nose:1.4},skin:[.74,.72,.7],hair:{style:'slick',color:[.2,.2,.2]},coat:{color:[.18,.18,.16],length:.9,collar:true},shirt:[.85,.85,.82],glasses:{type:'round'},gloves:{color:[.9,.9,.88]},height:1.04}};
NL.TASKS.s_clean={n:'Loose Ends',xp:50,cat:'side'};
})();
NL.Script.add(String.raw`
# vo.0 arc=tenant night=3,4,5 label="A man in white gloves has been following you since sunset." if=heat>=3|flag:omResult=art|flag:omResult=walked|flag:marcusGhoul&flag:fightDone prio=6
@focus vole
> He catches up with you under the railway bridge on Vine Street. Tall, thin, in a long dark coat and white cotton gloves, like a museum curator. He carries a leather folder under his arm.
vole: Good evening. My name is Vole. I clean up after the Court. You've been very busy this week, and I've been very busy after you. I thought it was time we met.
vole: Don't be alarmed. I'm not here for you. I'm here for them.
> He opens the folder. Inside, photographs. Faces.
{do task:s_clean; note:s_clean|Mr. Vole, the Court's cleaner, has a folder of people who saw too much of you this week. He'd like your opinion on each.}
vole: The Masquerade is a very old and very fragile thing. Every mortal who sees too much is a crack. I fill cracks. Usually I don't ask anyone. But you're the Sheriff's child, and I'm old-fashioned. So I'm asking.
@next vo.hub

# vo.hub
vole: Shall we go through them?
* The forty people at the Lantern Room on Tuesday.  -> vo.mic {once} {if flag:omResult=art|flag:omResult=walked}
* Two hundred people in the Reliquary cellar who saw a boy drink from your wrist.  -> vo.fight {once} {if flag:marcusGhoul&flag:fightDone}
* A girl on a delivery bike.  -> vo.bike {once} {if seen:ev.bk4}
* A cab driver with a rosary on his mirror.  -> vo.cab {once} {if flag:gotWallet}
* A detective called Miller.  -> vo.miller {once} {if flag:millerKnows|flag:millerAlly}
* A comedian called Leo Pruitt.  -> vo.leo {once} {if alive:leo&!flag:leoEmbraced&!flag:leoThrall}
* "That's enough, Mr. Vole."  -> vo.end

# vo.mic
vole: The Lantern Room. Forty people. A performance that was, I'm told, rather too convincing. Most of them will decide it was art. Six of them have been searching the internet since Tuesday.
vole: I can visit the six. A little fog. They'll remember a good night and a bad poet.
* "Fog them. Gently."  -> vo.mic1
* "Leave them. They'll talk themselves out of it."  -> vo.mic2

# vo.mic1
vole: Gently. I'm always gentle. It's a point of pride.
{do flag:voMic=fog}
@next vo.hub

# vo.mic2
vole: As you like. If one of them talks themselves *into* it, I'll be back.
{do flag:voMic=leave; heat+1}
@next vo.hub

# vo.fight
vole: The cellar. Two hundred people saw a dying boy drink from a stranger's wrist and sit up. That is a great deal of crack.
vole: Fog won't do it. Not two hundred. I'd need a story. Something to put in the hole.
* "A drug. A new one. Say the Syndicate was testing it."  -> vo.fight1
* "Say it was staged. Vossler's idea of a show."  -> vo.fight2
* "Say nothing. Let them wonder."  -> vo.fight3

# vo.fight1
vole: A drug. Hm. Malakor won't thank you, but it will hold. Everyone believes in drugs.
{do flag:voFight=drug; rel:malakor-1}
@next vo.hub

# vo.fight2
vole: Staged. A show. Vossler. Oh, he'll hate that. He'll have to admit his fights are fixed. Delicious.
{do flag:voFight=staged}
@next vo.hub

# vo.fight3
vole: Wonder. You want two hundred mortals to *wonder*. In the Marrow Ward. During a Tribunal week.
vole: I'll note that you said so.
{do flag:voFight=wonder; heat+1}
@next vo.hub

# vo.bike
vole: A girl of sixteen, who was carried two miles in ninety seconds by something that smelled of a freezer. She's told her mother. Her mother thinks she's been taking something.
* "Let her mother think it. She'll grow out of it."  -> vo.bike1
* "Fog her. She's sixteen. She doesn't need this."  -> vo.bike2

# vo.bike1
vole: She'll grow out of it. Yes. They usually do. Then they grow back into it at forty and write a book.
{do flag:voBike=leave}
@next vo.hub

# vo.bike2
vole: Gently.
{do flag:voBike=fog}
@next vo.hub

# vo.cab
vole: A cab driver. Thirty-one years. He's been telling his wife about the fare who didn't breathe. She's told her sister. Her sister's a nurse at St. Jude's.
* "Leave him. He gave me back my wallet."  -> vo.cab1
* "Fog him."  -> vo.cab2

# vo.cab1
vole: He gave you back your wallet. That's... hm. That's a very sentimental criterion for the Masquerade.
vole: Fine. He's got a bad heart. Nobody listens to men with bad hearts.
{do flag:voCab=leave}
@next vo.hub

# vo.cab2
{do flag:voCab=fog}
@next vo.hub

# vo.miller
> He turns the photograph round. Ines Miller, in her parka, outside the Lucky Mart, with her coffee.
vole: The detective. She knows. Not suspects. *Knows*. She's writing it down. She has two columns in a notebook. That is the single largest crack in the Ward.
vole: I'd like to do her properly. Not fog. Fog doesn't hold with that kind. Properly.
pulse(6): He means kill her. He says it like a man discussing guttering.
* "No. She's mine. Under my protection."  -> vo.mil1 {do lean:loyalty+1}
* "Fog her. Try. Just fog."  -> vo.mil2
* "If you touch her, Mr. Vole, I'll clean you."  -> vo.mil3 {do lean:pride+1}

# vo.mil1
vole: Yours. A mortal, under a neonate's protection. That's not a thing, you understand. There's no law for that.
? velvet 11 "Then I'm making one. Write it in your folder."  -> vo.mil1ok | vo.mil1no {id vo_mil}

# vo.mil1ok
> He looks at you for a long time over his glasses. Then he takes a fountain pen out of his coat and writes something next to Miller's photograph.
vole: "Protected. By request of the Sheriff's child." There. That's never been written in my folder before. You understand, if she writes a book, that's on you.
{do flag:voMiller=protected; rel:miller+0}
@next vo.hub

# vo.mil1no
vole: No. I'm sorry. Feelings aren't law. I'll do it on Saturday, after the Tribunal, when you're either Sheriff and can stop me, or ash and can't.
{do flag:voMiller=saturday}
@next vo.hub

# vo.mil2
vole: Fog. On a detective. She'll come out of it in a week asking why she can't remember Tuesday. They always do, that kind. But very well.
{do flag:voMiller=fog; lean:candour-1}
@next vo.hub

# vo.mil3
vole: Clean me.
> He smiles. It's a very thin smile.
vole: Do you know, nobody's threatened me since 1943? It was a Prince of Vienna. I cleaned him. But I take your point. I'll leave the detective for Saturday. If you're Sheriff on Saturday, we'll discuss it.
{do flag:voMiller=saturday}
@next vo.hub

# vo.leo
vole: The comedian. He's told his sister. His sister's told his uncle. His uncle is a police officer who takes money off a corner shop. That is a very leaky family.
* "Not Leo. Never Leo."  -> vo.leo1
* "Fog him. Make him forget me."  -> vo.leo2

# vo.leo1
vole: Never. A strong word, in our world. We have a great deal of never to get through.
vole: Fine. The comedian stays leaky. But if he puts it in his act...
* "He already has. Nobody believes him. It's comedy."  -> vo.leo3

# vo.leo3
vole: ...That's actually very clever. The best place to hide a truth is in a joke nobody laughs at.
{do flag:voLeo=leave}
@next vo.hub

# vo.leo2
> Something in you goes very cold.
tenant: Child. If he fogs the boy, the boy will look at you on Saturday like a stranger. Do you understand that? A stranger.
* "Yes. Do it. It's safer for him."  -> vo.leo4
* "No. Wait. Never mind. Leave him."  -> vo.leo1

# vo.leo4
vole: Gently. Of course.
{do flag:voLeo=fog; flag:leoFogged=1; lean:mercy+0}
@next vo.hub

# vo.end
vole: Very good. Thank you. You've been more considerate than most. Absalom never once looked at my folder. He'd say "do what you must, Vole," and go to bed.
vole: I'll be in touch. I'm always in touch. That's the job.
> He tips a hat he isn't wearing, and goes off under the bridge, and you don't hear his footsteps at all.
{do task:s_clean=done; xp:50:Loose Ends}
@end
`,'c_cleaner');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.voMiller==='protected')o.push(['Mr. Vole\'s folder','Has a note beside a detective\'s photograph that has never been written there before: "Protected. By request." He checks on her once a month, from a distance. She has noticed. She waves.']);
  if(f.voLeo==='fog'&&!f.leoDead)o.push(['Leo Pruitt','Doesn\'t remember you. He still does the bit about the night shift. He doesn\'t know where it came from. Sometimes, on Tuesdays, he looks at the back of the room as if he\'s expecting someone.']);
  return o;});
