'use strict';
/* THE NEW LORD — codas: after the last decision and before the epilogue, one more scene and one more choice for every ending */
NL.Script.add(String.raw`
// =====================================================================
// THE NEW LORD · coda
// =====================================================================
# cd.lord
> The Magistrate rises. Three hundred Kindred watch him go up the stairs to the street, where the sky is going white, and down the other side into a car with black glass. Then they look at you.
> They're waiting. For the first thing the new Sheriff of the Marrow Ward says.
* "Go home. All of you. It's nearly dawn."  -> cd.lord1
* "Séverine. Malakor. Soot. My study, tomorrow, at nine."  -> cd.lord2 {if !flag:massacre}
* "The tithe is five percent from now on. Not ten."  -> cd.lord3
* Say nothing. Walk up the stairs.  -> cd.lord4

# cd.lord1
> They go. Slowly at first, and then all at once, like a theatre emptying. Nobody bows. A few nod. Lisette winks. Dutch salutes with a screwdriver.
{do flag:coda=home}
@next end.show.lord

# cd.lord2
> Séverine inclines her head a precise half-inch. Malakor grins with all twelve faces' worth of teeth. Soot, by the cistern grate, says "Mm."
severine: Nine. Very well. I'll bring the minutes.
malakor: I'll bring the invoice.
soot: I'll bring a jar.
{do flag:coda=council}
@next end.show.lord

# cd.lord3
> A ripple goes along the tracks. Somebody laughs. Somebody else gasps. Malakor puts his hand over his heart in mock agony.
malakor: Five. Five! You're going to bankrupt us with kindness.
tenant: Five percent. I never thought of it. In eighty years I never once thought of taking less.
{do flag:coda=fivepercent; lean:mercy+1}
@next end.show.lord

# cd.lord4
> You walk up the stairs from Platform 0 into the last grey minutes before the sun, with three hundred Kindred watching your back, and Pemberton holds the car door, and you get in, and nobody follows.
> In the Marrow Ward, that's how you know who's in charge.
{do flag:coda=silent}
@next end.show.lord

// =====================================================================
// THE DAYWALKER · coda
// =====================================================================
# cd.day
> 5:09 AM. The sun on your face. Your heart beating, loud as a fist on a door. Your shadow on the sidewalk, solid, *yours*.
> The Marrow Ward in daylight. You've never seen it. You've seen it every day of your life. Bins. Gulls. A bread van. Steam from the launderette vent. It's the most beautiful thing in the world.
> Where do you go first?
* The Lucky Mart. Tariq's light is still on.  -> cd.day1 {if !flag:dalekilled}
* The Rookery. Leo's door.  -> cd.day2 {if !leo:dead}
* The harbour. To see what color it is.  -> cd.day3
* St. Jude's. To tie a scarf to the railings.  -> cd.day4 {if flag:okaforScarf}

# cd.day1
> The bell over the door. Tariq looks up from the till with his face ready to say "nurse" and then he sees you, in the daylight, in the doorway, with the sun behind you like a cape.
tariq: ...You're standing in the door. In the sun.
> You buy a coffee. You drink it. It's terrible. It's the best thing you've ever tasted.
tariq: You drank it. You DRANK it. Forty-one cups and you drank the forty-first.
{do flag:coda=tariq}
@next end.show.daywalker

# cd.day2
> You knock on 3B at seven in the morning. Leo opens the door in a dressing gown with Gerald under one arm and sees you in the light from the stairwell window and screams, a little, and then laughs, a lot.
leo: You're... you're in the... is that the sun? Is that the actual sun on you?
leo: Okay. Okay. I've got the end of the joke. "A vampire walks into a butcher's at four in the morning. The guy says we're closed. The vampire says 'that's fine, I'll come back at noon.'"
leo: It's not great. Shut up. It's a work in progress. Come in. I'll make you a coffee you can actually drink.
{do flag:coda=leo}
@next end.show.daywalker

# cd.day3
> The harbour at seven in the morning. The cranes. The gulls. The water.
> It's grey and green and purple, all at once, like a pigeon's neck.
tenant: (very faintly, very far away) ...Oh. Oh, she was right. She was right.
> And then he's quiet. And then he's gone. You're alone in your own blood for the first time since Monday, standing on the quay in the sun, crying, with your heart going like a drum.
{do flag:coda=harbour}
@next end.show.daywalker

# cd.day4
> Mrs. Okafor is already at the railings outside St. Jude's at seven with the seven-colored scarf over her arm, and she sees you coming up the street in the daylight and doesn't understand, and then does.
okafor: You're... the sun.
okafor: Help me with the knot. My fingers. I can't do the knot.
> You tie it. Seven colors on the black railings. The green is wider than the others. Nobody will notice. You'll notice.
{do flag:coda=scarf}
@next end.show.daywalker

// =====================================================================
// NOON · coda
// =====================================================================
# cd.noon
> In the last half-second, as the Vessel opens and the noon comes up through every grate and drain and window in the Marrow Ward, there's time for one thought. Just one.
* Pemberton.  -> cd.noon1 {if !flag:pemDead}
* Agnes, in daylight.  -> cd.noon2 {if mem:tenant.letters|flag:readAgnes}
* Your sister, on the coast.  -> cd.noon3 {if name}
* Nothing. Just the light.  -> cd.noon4

# cd.noon1
> Pemberton, in the car at the north stair, with the engine running. He'll see the light. He'll understand. He'll sit there for a long time. And then he'll drive to Galway and see the cottage, and it will rain.
{do flag:coda=pemberton}
@next end.show.noon

# cd.noon2
> *Yours, in daylight.* That's all. That's all you get. It's enough.
{do flag:coda=agnes}
@next end.show.noon

# cd.noon3
> A door with a fish doodle on the post box, a long way off, on the coast. Somebody who'll never know why the phone rang on Monday and nobody spoke.
{do flag:coda=sister}
@next end.show.noon

# cd.noon4
> White. Warm. Everywhere. It's very simple, in the end. It's only warm.
{do flag:coda=light}
@next end.show.noon

// =====================================================================
// THE MORTAL WAY · coda
// =====================================================================
# cd.mortal
> Saturday night. Not in Elysium. Not on Platform 0. In the back booth of the Lucky Mart, with Miller, and a box of files, and a judge in a wheelchair who's asleep with her mouth open.
miller: So what now? You're still... you. You're still whatever you are. No title. No throne. Just you and a coffee you won't drink.
* "Now I work nights."  -> cd.mortal1
* "Now I find my sister."  -> cd.mortal2 {if name}
* "Now you get a dog."  -> cd.mortal3

# cd.mortal1
miller: Nights. Doing what?
miller: ...Actually, don't tell me. I'll find out. I'm a detective.
> Tariq brings two coffees and a third for nobody, for Ray, without being asked.
{do flag:coda=nights}
@next end.show.mortal

# cd.mortal2
miller: Your sister. Morrow. On the coast. I ran the name. She's a primary school teacher. She's got a fish doodle on her post box.
miller: Do you want the address? You don't have to want it. I'll leave it on the table.
> She leaves it on the table. You don't pick it up. Then you do.
{do flag:coda=sister}
@next end.show.mortal

# cd.mortal3
miller: A dog. Yes. My sister's dog had puppies. I'm getting the runt. I'm going to call him Ray.
{do flag:coda=dog}
@next end.show.mortal

// =====================================================================
// THE SHERIFF RETURNS · coda
// =====================================================================
# cd.tenant
> Somewhere very far down, in a study with no walls on the bed of an old river, you sit in the visitor's chair, and watch through somebody else's eyes as your body walks up the stairs from Platform 0.
> He's very good at it. He's better at being you than you ever were. He nods to Séverine. He shakes Malakor's hand. He stops by the old woman with the candle and says something that makes her laugh.
> There's one last thing you can do before you sleep.
* Knock on the inside of his skull. Once. So he remembers.  -> cd.ten1
* Let go. Sleep.  -> cd.ten2
* Leave him a note. In the ledger, in your handwriting.  -> cd.ten3

# cd.ten1
> Knock.
> On the stairs, the Sheriff of the Marrow Ward stops in the middle of a sentence, and listens, and smiles.
tenant: I know, Casey. I know. I'll keep the light on.
{do flag:coda=knock}
@next end.show.tenant

# cd.ten2
> The study goes soft. The river comes down its old bed, very gently, and fills the room, and it's warm, and you let it.
{do flag:coda=sleep}
@next end.show.tenant

# cd.ten3
> You take the fountain pen. You write, on the last page of the ledger, below *Saturday: resume duties*, in your own handwriting, not his: *Be kind to Pemberton. Let Tariq keep his light. Five percent. — C.*
> Then you close the ledger and go to sleep.
{do flag:coda=note}
@next end.show.tenant

// =====================================================================
// GOLCONDA · coda
// =====================================================================
# cd.gol
> The sun. You're standing in it. You're not burning. The Beast in you is very quiet, the way a dog goes quiet when its owner finally comes home.
> On the stairs behind you, three hundred Kindred are watching through the grate. None of them can follow you. One of them is crying.
* Turn round. Hold out your hand to them.  -> cd.gol1
* Walk on, into the Ward.  -> cd.gol2
* Sit down on the steps in the sun.  -> cd.gol3

# cd.gol1
> You hold out your hand, in the sunlight, to the dark. Nobody takes it. Nobody can. But they all see you do it.
> Later, they'll tell each other it's a story. A fairy tale for neonates. It was always a fairy tale. And then one night, years from now, one of them will try.
{do flag:coda=hand}
@next end.show.golconda

# cd.gol2
> You walk into the Marrow Ward in daylight. Past the Lucky Mart. Past the Pawn & Coffin, where an old man is opening his shutters and sees you and drops his keys. Past the Rookery. You're not in a hurry. For the first time in a week you've got all the time in the world, and it's daytime.
{do flag:coda=walk}
@next end.show.golconda

# cd.gol3
> You sit on the top step of the Switchyard in the November sun and close your eyes and feel it on your eyelids, red and warm. Pigeons. A bus. Somewhere, a radio.
> Pemberton parks the car across the road and gets out and sits on the step beside you and doesn't say anything, and that's the best thing anyone's ever done for you.
{do flag:coda=step}
@next end.show.golconda

// =====================================================================
// FUGITIVE · coda
// =====================================================================
# cd.run
> The storm drain. The pipe. A dark so deep it's nearly the freezer again. You're alive. Whatever that means.
> Somewhere above, in the Ward, the sun's coming up, and the Court will be counting the drains by nightfall.
* Go deeper. Under the river.  -> cd.run1
* Find Soot's pipes. Ask her to hide you.  -> cd.run2 {if !flag:sootDead}
* Head for the coast.  -> cd.run3

# cd.run1
> Under the old Vellum the tunnels go on forever: Victorian sewers, wartime shelters, a whole drowned railway station with the tiles still on the walls. Nobody's been down here in a hundred years. You'll be the first.
{do flag:coda=deep}
@next end.show.run

# cd.run2
soot: (through the pipe, very faint) Mm. Mm. Greedy child. Come along. Left at the third grate. I've got a jar with your name in it. I'll keep it warm.
{do flag:coda=soot}
@next end.show.run

# cd.run3
> The coast. A sister with a fish on her post box. You'll never get there. It's eighty miles and there are only so many drains. But you start walking anyway, underground, east.
{do flag:coda=coast}
@next end.show.run

// =====================================================================
// ASH · coda
// =====================================================================
# cd.ash
> The light comes down through the grate in bars. It's very bright. It's warmer than you thought.
> You have time for one thing.
* Look up.  -> cd.ash1
* Hold the Tenant.  -> cd.ash2
* Say your name. Out loud.  -> cd.ash3 {if name}

# cd.ash1
> You look up. Through the grate, beyond the bars, the sky over the Marrow Ward is the color of a pigeon's neck.
{do flag:coda=up}
@next end.show.ash

# cd.ash2
tenant: I'm here. I'm here, Casey. I've done this before, a long time ago, in a manner of speaking. Hold on to me. It doesn't hurt for very long.
{do flag:coda=hold}
@next end.show.ash

# cd.ash3
> "Casey Morrow." It comes out clear, in your own voice, into the light. Three hundred Kindred hear it. Somebody will remember it. Somebody always does.
{do flag:coda=name}
@next end.show.ash

// =====================================================================
// THE RED GOD · coda
// =====================================================================
# cd.red
> So many. So many voices. The Magistrate, ancient and furious. Séverine, singing. Malakor, laughing. Three hundred Kindred, all talking, all at once, in the hallway, in the study, in the blood.
> And somewhere under all of them, very small, very quiet, a voice that's yours.
* Listen for it.  -> cd.red1
* Drown it.  -> cd.red2

# cd.red1
> You listen. For a long time. Through three hundred voices. It's saying something. It's saying *I'm still here.* It's saying *Casey.*
> You hold on to it. You don't know how long you can.
{do flag:coda=listen}
@next end.show.redgod

# cd.red2
> You stop listening. It's easier. It's so much easier. There's nobody to argue with any more.
{do flag:coda=drown}
@next end.show.redgod

// =====================================================================
// SUBJECT EIGHT · coda
// =====================================================================
# cd.subject
> The van stops at a gate in a fence in a field that could be anywhere. Grey sky. Grey men. A white building with no windows, like the Prince's house, but newer.
harrow: Welcome to Virginia. Well. Welcome to a field. Virginia's later.
* "I'll get out of here."  -> cd.sub1
* "What happens to me now?"  -> cd.sub2
* Say nothing. Let him wonder.  -> cd.sub3

# cd.sub1
harrow: I'm sure you'll try. Everyone does. I'll be very disappointed if you don't.
{do flag:coda=escape}
@next end.show.subject

# cd.sub2
harrow: Now? Now you sleep. Then on Tuesday, we take a little blood. Then we talk. We've got years.
{do flag:coda=years}
@next end.show.subject

# cd.sub3
> You say nothing. For eleven years, you say nothing to Harrow at all. It's the only weapon you have, and it works better than you'd think. He retires in 2034 and never once hears your voice.
{do flag:coda=silence}
@next end.show.subject
`,'c_endings');

(function(){const N=NL.STORY.nodes;
// insert the codas between each ending's last lines and its epilogue screen
const map={lord:'cd.lord',daywalker:'cd.day',noon:'cd.noon',mortal:'cd.mortal',tenant:'cd.tenant',golconda:'cd.gol',run:'cd.run',ash:'cd.ash',redgod:'cd.red',subject:'cd.subject'};
const hook=()=>{for(const k in map){const n=N['end.'+k];if(n&&n.next==='end.show.'+k)n.next=map[k];}};hook();document.addEventListener('DOMContentLoaded',hook);
// epilogue lines from the coda
(NL.Act.extraFates=NL.Act.extraFates||[]).push(S=>{const f=S.flags,c=f.coda;const T={
  home:'The Ward went home when you told it to. It still does.',council:'Every night at nine: the Keeper, the Butcher and the old woman with the candle, in the Sheriff\'s study, arguing.',fivepercent:'Five percent. The Marrow Ward has never been so poor or so quiet.',silent:'You never explained yourself to the Ward. It never asked again.',
  tariq:'You still buy a coffee at the Lucky Mart every morning. Tariq still writes it down.',leo:'"I\'ll come back at noon." It\'s a terrible joke. It\'s in his act. It gets a laugh every time.',harbour:'The harbour was the color of a pigeon\'s neck. You were the last person to see it for him.',scarf:'The scarf is still on the railings. Nobody has dared take it down.',
  pemberton:'Pemberton drove to Galway. The cottage was small and damp and he loved it.',agnes:'In daylight.',sister:'Somewhere on the coast, a phone rang once, a long time ago, and nobody spoke.',light:'Only warm.',
  nights:'You work nights. Miller never asks doing what.',dog:'The dog is called Ray. He is a terrible dog. He is the best dog.',
  knock:'Some nights the Sheriff stops mid-sentence and listens to a knock nobody else hears.',sleep:'You sleep. It\'s warm.',note:'The last page of the ledger is in two handwritings. Five percent.',
  hand:'Years later a neonate on Platform 0 asks if it\'s true, about the one who walked into the sun. Somebody says: it\'s a fairy tale. Somebody else says: no.',walk:'Gideon still tells customers about the morning a guest walked past his window in the sun.',step:'Pemberton still sits on the Switchyard step at dawn sometimes, in case.',
  deep:'Nobody has found the drowned station under the Vellum. You have it all to yourself.',soot:'Soot keeps you in the pipes like a secret. You\'ve never been so well informed.',coast:'Eighty miles is a long way underground. You\'re still walking.',
  up:'The sky was the color of a pigeon\'s neck.',hold:'He held on too.',name:'Three hundred Kindred heard your name. A few of them still say it.',
  listen:'Some nights, under three hundred voices, one still says Casey.',drown:'There is nobody left inside to argue with.',
  escape:'You tried four times. The fifth time was in 2033.',years:'Years. Tuesdays. Talk.',silence:'Harrow retired without ever hearing your voice.'}[c];
  return T?[['After',T]]:[];});
})();
