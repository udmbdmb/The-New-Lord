'use strict';
/* THE NEW LORD — Saturday, the debts come due: pacts, promises, and the people you made them to */
(function(){const O=NL.Script.opt;
O('sat.hub','* The Switchyard, where Local 0 is holding a meeting.  -> sat5.dutch {once} {if flag:side_union&!flag:purge&!flag:satVisit3}','start');
O('sat.hub','* Platform 0. Malakor has sent a boy with a note: "Come and collect."  -> sat5.mal {once} {if !flag:malakorDead&flag:pact=syndicate&!flag:satVisit3|!flag:malakorDead&flag:sevMalakorTruce&!flag:satVisit3}','start');
O('sat.hub','* A grey van parked on Vine Street with its engine off.  -> sat5.har {once} {if !flag:harrowDead&flag:lanternRefused&!flag:satVisit3|!flag:harrowDead&flag:harrowDoubt&!flag:satVisit3}','start');
O('sat.hub','* Lord Ashby, who has sent flowers. Again.  -> sat5.ash {once} {if !flag:ashbyDead&!flag:ashbyGone&flag:ashbyLance&!flag:satVisit3|!flag:ashbyDead&!flag:ashbyGone&flag:gildedJoke&!flag:satVisit3}','start');
O('sat.hub','* The bus shelter on Vine Street. Two deckchairs.  -> sat5.lyon {once} {if flag:lyonReunion&!flag:sevDead&!flag:satVisit3|flag:lyonLater&!flag:sevDead&!flag:satVisit3}','start');
})();
NL.Script.add(String.raw`
# sat5.dutch
> Behind the bins at the Switchyard, sixty-three clanless Kindred on upturned crates, and a very big man in a knit hat stirring a pot of soup that nobody will eat. Little Sal. Big Sal's son, who is bigger than his father ever was and has his father's soup recipe and his father's tendency to cry. He's crying already.
dutch: Order. Order! The Sheriff's here. Item one: the Sheriff's here.
@gate flag:pact=union ? sat5.dutch1 : sat5.dutch2

# sat5.dutch1
dutch: Item two. The stool. Or the chair. Whatever it was. We've had a vote on who sits in it first.
> He holds up an exercise book. Sixty-three names, sixty-two ticks against one of them.
dutch: Little Sal. Unanimous. Except Little Sal, who voted for me, the idiot.
* "Then Little Sal sits at Elysium on Monday."  -> sat5.dutch3
* "Dutch should sit. He did the work."  -> sat5.dutch4

# sat5.dutch3
> Little Sal drops the ladle in the soup. He doesn't fish it out. He sits down on his crate and puts his face in his hands, and sixty-two Kindred pat him on the back at once.
{do flag:salSeat=1; rel:dutch+1; comp+2; keep:stool}
@next sat.count

# sat5.dutch4
dutch: Me. No. No, I'm a shop steward, brother. Shop stewards don't sit. They stand at the back with their arms folded.
dutch: Little Sal sits. That's final. I'll stand behind him. With my arms folded.
{do flag:salSeat=1; rel:dutch+2; keep:stool}
@next sat.count

# sat5.dutch2
dutch: Item two. You didn't promise us anything. Nobody did. That's the usual. But you stood near us. On Friday. When the Court was looking.
dutch: That's on the minutes now. Forever. "Item two: the Sheriff stood near us."
* "Then let's make it item three. Local 0 gets a seat at Elysium."  -> sat5.dutch5
* "It's a start."  -> sat5.dutch6

# sat5.dutch5
> Silence behind the bins. Then a noise like a football crowd, and somebody kicks over the soup, and nobody cares.
dutch: Item three. Item three! Write it down, somebody! Little Sal, stop crying and write it down!
{do flag:unionSeat=1; rel:dutch+3; lean:pride-1; comp+2}
@next sat.count

# sat5.dutch6
dutch: A start. Yeah. Everything's a start, with us. We've been starting for forty years.
{do rel:dutch+1}
@next sat.count

# sat5.mal
> Platform 0 in the evening, with no Court on it, is just a railway platform: wet, quiet, a pigeon walking along the yellow line. Malakor is sitting on the edge with his legs over the tracks, eating a sausage out of paper.
malakor: Nephew. Sit. Have a sausage. You can't. Hold one, then. It's polite.
@gate flag:pact=syndicate ? sat5.mal1 : sat5.mal2

# sat5.mal1
malakor: The Switchyard is ours. Signed in blood, in a manner of speaking. Nobody comes down without knocking.
malakor: I've come to collect the first favour. It's small. It's very small. I want you to knock. Once. Right now. On the platform. So everyone can hear the Sheriff knock.
* Knock on the iron pillar. Three times.  -> sat5.mal3
* "I don't knock, Malakor. Not on my own Ward."  -> sat5.mal4

# sat5.mal3
> You knock. Three times, on the cast-iron pillar, the way you'd knock on a door. It rings like a bell down the whole length of the Switchyard.
malakor: Come in!
> He laughs so hard he drops the sausage on the tracks. A rat takes it. He doesn't mind.
{do rel:malakor+2; lean:pride-1}
@next sat.count

# sat5.mal4
malakor: Not on your own Ward. Hm. Hm. I see.
> He looks at you for a long time. Then he shrugs, enormous, like a landslide deciding not to.
malakor: Absalom said exactly that, in 1962. Then he knocked anyway, at Christmas, with a bottle. Come at Christmas, nephew. With a bottle.
{do rel:malakor-1; lean:pride+1}
@next sat.count

# sat5.mal2
malakor: Séverine sent me a letter. A real one. Purple ink. Do you know what it said?
malakor: "Mikołaj. Thank you for not going to the Magistrate. I find I don't know how to say this, so I've written it down. — S." That's all. In two hundred years.
malakor: You did that. With a lie, I think. Don't tell me if it was a lie. I don't want to know.
{do rel:malakor+1; comp+1}
@next sat.count

# sat5.har
> A grey van on Vine Street. Engine off. Lights off. Agent Thomas Harrow in the driver's seat with the window down and no sunglasses on, drinking coffee from a paper cup, watching the street go dark.
harrow: You came. I thought you might.
@gate flag:harrowDoubt ? sat5.har1 : sat5.har2

# sat5.har1
harrow: I didn't sign the battery requisition. Or the next one. Or the transfer order on Friday afternoon. They had to bring a man from Virginia to sign them all.
harrow: He signed them once each. Very neatly.
harrow: They've reassigned me. Records. A basement in Maryland. No windows. I start Monday.
* "Is that what you want?"  -> sat5.har3
* "I'm sorry."  -> sat5.har4

# sat5.har3
harrow: Want. I don't know. I haven't wanted anything since 2004.
harrow: ...My daughter's at college in Baltimore. Forty minutes from Records. I might ring her. At a normal hour. Somebody told me that once. At a normal hour.
{do rel:harrow+2; comp+1; flag:harrowMaryland=1}
@next sat.count

# sat5.har4
harrow: Don't be. It's the first honest job they've given me in twenty years. Filing things. Things that already happened. No lamps.
{do rel:harrow+1; flag:harrowMaryland=1}
@next sat.count

# sat5.har2
harrow: You tore up the card. I waited by the phone until one. Then I understood.
harrow: I've made that offer to four Kindred in three cities. Every one of them said yes. Every one. You're the first one who didn't.
harrow: I don't know what to do with that. I've been sitting here for three hours trying to work out what to do with it.
* "Go home, Agent Harrow."  -> sat5.har5
* "Stop making the offer."  -> sat5.har6

# sat5.har5
harrow: Home. Right. Home.
> He starts the van. He doesn't drive away. He sits with the engine running and the window down, and when you look back from the corner, he's still sitting there.
{do rel:harrow+1}
@next sat.count

# sat5.har6
harrow: Stop... it's not my offer. It's theirs. I'm just the man in the van.
harrow: ...But I could stop being the man in the van. I suppose. People do. I've read about it.
{do rel:harrow+1; flag:harrowQuits=1}
@next sat.count

# sat5.ash
> The VIP crypt beneath the Reliquary, on a Saturday, with nobody in it but Lord Edmund Ashby, lying on the Keeper's own sarcophagus with his boots on, eating grapes.
ashby: Darling! Don't tell Séverine. She's at the opera. She'd have me staked for the boots.
@gate flag:ashbyLance ? sat5.ash1 : sat5.ash2

# sat5.ash1
ashby: The Magistrate came to see me. Me. In my rooms. He's never been to my rooms. He sat on my chaise and said, "Lord Ashby, I owe you an apology for two hundred years of not listening."
ashby: Then he left. He didn't stay for a drink. I've been drunk ever since. It's been wonderful.
ashby: You did that. You believed me. Nobody's believed me since 1888. I don't know how to thank you. I've sent you flowers. Twice. It seemed inadequate.
* "Stop being vulgar for a week. As thanks."  -> sat5.ash3
* "The flowers were enough."  -> sat5.ash4

# sat5.ash3
ashby: Stop... for a *week*? Darling, I'd die. I'd actually die.
ashby: ...Three days. I'll do three days. Starting Monday. Nobody will recognize me.
{do rel:ashby+2; comp+1}
@next sat.count

# sat5.ash4
ashby: Enough. Nothing's ever enough. That's the whole point of me. More flowers are coming. You can't stop them.
{do rel:ashby+1}
@next sat.count

# sat5.ash2
ashby: I told the joke, you know. At the Tribunal. While everyone was waiting. "The new Sheriff wants the room with the good mirror." It killed. Three hundred Kindred. Even the Magistrate's driver.
ashby: You're a legend, darling. A small one. Legends this size are the best kind. Nobody tries to kill you for them.
{do rel:ashby+1; comp+1}
@next sat.count

# sat5.lyon
> Vine Street. The bus shelter. Two deckchairs on the roof now, both dry.
@gate flag:lyonReunion ? sat5.lyon1 : sat5.lyon2

# sat5.lyon1
> In one, the old man in tartan. In the other, in an evening coat, with a thermos, the Keeper of Elysium. Neither of them is talking. The 9 comes in, late, as always. They both watch it.
severine: (without looking down) Come up. There's no third chair. Stand.
> You climb up. You stand. The three of you watch Vine Street.
oldkin: She brought soup. In a thermos. Séverine Marchetti brought soup in a thermos to a bus shelter.
severine: It's not soup. It's consommé. There's a difference, Monseigneur, and you used to know it.
> They don't say anything else for a long time. You don't either. It's the best visit of the day.
{do comp+3; rel:severine+1}
@next sat.count

# sat5.lyon2
> One deckchair. The old man in tartan. On the sidewalk below, standing quite still, a lady in an evening coat, looking up.
> She hasn't climbed up. She's been there an hour. He hasn't looked down. Both of them know.
* Climb up. Bring the second chair down for her.  -> sat5.lyon3
* Leave them. Some things take as long as they take.  -> sat5.lyon4

# sat5.lyon3
> You climb up. You unfold the second deckchair. You pass it down to Séverine without a word.
> She looks at it. She looks at you. She looks up at the old man, who still hasn't looked down.
> Then she climbs. In her evening coat. You go before you can see her get to the top.
{do flag:lyonReunion=1; rel:severine+2; comp+2}
@next sat.count

# sat5.lyon4
> You leave them. On the corner you look back. She's still there. He's still there. The 9 comes in, late.
{do comp+1}
@next sat.count
`,'c_saturday4');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.salSeat)o.push(['Little Sal','Sits at Elysium on the first Monday of every month, in the seat his father was never given, on a stool with a cushion, with a napkin tucked in his collar, and cries at the speeches. All the speeches. Even the budget.']);
  if(f.harrowQuits)o.push(['Thomas Harrow','Resigned from LANTERN in January. He works nights now, as a security guard at an aquarium in Baltimore. He says the fish don\'t ask him anything. He rings his daughter at a normal hour.']);
  else if(f.harrowMaryland)o.push(['Thomas Harrow','Files things that already happened in a basement in Maryland. He rings his daughter on Sundays. She answers, mostly.']);
  return o;});
