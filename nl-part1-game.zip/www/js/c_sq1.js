'use strict';
/* THE NEW LORD — side quests, set one: "Not Yet" (Mr. Halloran's cats), "Pike Pest Solutions" (the exterminator), "The 3:12 to the Docks" (the night bus) */
(function(){
const X=NL.EXTRAS,S_=NL.Script;
X.halloran={n:'Mr. Halloran',color:'#c8b8a0',role:'Room 302 · the Rookery',spec:{face:{long:1.08,jaw:0.7,nose:1.25,cheek:0.8},skin:[.86,.76,.7],hair:{style:'fringe',color:[.75,.72,.68]},glasses:{type:'reading'},shirt:[.4,.38,.32],coat:{color:[.32,.3,.26],length:.5,collar:false},height:.94}};
X.pike={n:'Dwayne Pike',color:'#c0c070',role:'Pike Pest Solutions',spec:{face:{wide:1.1,jaw:0.5,cheek:1.1},skin:[.86,.68,.58],hair:{style:'crop',color:[.5,.38,.25]},shirt:[.55,.55,.2],pants:[.25,.25,.15],height:1.04,width:1.12}};
X.dot={n:'Dot Mulligan',color:'#e0a070',role:'Driver, the number 9',spec:{skin:[.84,.7,.62],hair:{style:'bun',color:[.6,.55,.5]},shirt:[.2,.25,.45],coat:{color:[.18,.22,.4],length:.4,collar:true},height:.95}};
X.luis={n:'Luis Ferreira',color:'#f0c090',role:'The passenger',spec:{face:{long:1.08,cheek:1.6,jaw:1.2},skin:[.78,.5,.42],hair:{style:'crop',color:[.15,.1,.08]},shirt:[.6,.6,.62],pants:[.3,.3,.32],eyes:[.95,.6,.2],eyeGlow:[.6,.3,.05]}};
Object.assign(NL.TASKS,{s_cats:{n:'Not Yet',xp:40,cat:'side'},s_pest:{n:'Pike Pest Solutions',xp:50,cat:'side'},s_bus:{n:'The 3:12 to the Docks',xp:70,cat:'side'}});
NL.ITEMS.cattrap={n:'A Humane Cat Trap',type:'tool',d:'Galvanised wire, spring door, PIKE PEST SOLUTIONS stencilled on the side. Somebody has written "CHARLIE?" on the tag in biro.'};
NL.ITEMS.pikeorder={n:'Pike\'s Work Order',type:'read',d:'"Client: US Dept. of Health (Community Survey). Job: full rodent eradication, Platform 0 subsurface, 31 grate access points. Agent: cyanide-based. Deadline: FRIDAY 23:00. Authorised: T.H."'};
S_.npc({id:'halloran',room:'rookery',at:[3.4,3.0,1.2],pose:'hold',label:'Mr. Halloran',if:'night>=2&night<=4&!flag:halloranGone',node:{first:'hl.0',again:'hl.hub'}});
S_.npc({id:'pike',room:'alley',at:[8.6,1.4,-0.8],pose:'arms',label:'A man in yellow overalls',if:'night>=3&night<=4&!flag:pikeDone',node:{first:'pk.0',again:'pk.hub'}});
S_.place({id:'bus9',name:'The Number 9 Night Bus',block:'C',sub:'Stops outside St. Jude\'s at 3:12. Dot drives.',if:'night>=2&night<=4&flag:mapOK&!flag:busDone',node:S=>S.time>=300&&S.time<=345?'bus.312':'bus.0',min:10});
})();
NL.Script.add(String.raw`
// =====================================================================
// NOT YET · Mr. Halloran and his cats
// =====================================================================
# hl.0
@focus halloran
> A thin old man in a cardigan on the landing outside 302, holding a saucer of something that smells of fish, calling softly down the stairwell.
halloran: Puss puss puss. Puss puss puss. Oh. Hello. Sorry. I thought you were a cat. You move like one. People never do.
{do meet:halloran}
@gate night:2 ? hl.n2 : hl.next

# hl.next
@gate night:3 ? hl.n3 : hl.n4

# hl.n2
halloran: Thirty-one of them, in the yard behind the bins. I feed them every night. Have done for six years. Tariq at the Lucky Mart thinks I'm mad because I buy cat food and I don't have a cat.
halloran: I don't have a cat. I have thirty-one cats that aren't mine. If I named one it'd be mine and then it would die. Things that are mine die. That's been my experience.
* "That's a sad rule to live by."  -> hl.sad {do lean:mercy+1}
* "Mrs. Halloran. Is she one of the things that dies?"  -> hl.wife {if flag:sootHalloran|seen:ux2.0}
* "Can I help you feed them?"  -> hl.feed

# hl.sad
halloran: Is it? It's kept me going. Fifty-one years married. A son in Melbourne who rings at Christmas. A brother who died in a car on the coast road in 1987. You make rules.
{do mem:halloran:rule}
@next hl.hub

# hl.wife
> He goes very still with the saucer.
halloran: You know about that. Everybody knows about that. These walls are made of paper. She says she's leaving. She's said it every few months since 1990. I go and feed the cats.
halloran: She never leaves. Neither do I. That's marriage. Two people threatening to leave a flat neither of them can afford to leave.
{do mem:halloran:wife}
@next hl.hub

# hl.feed
halloran: Help? Oh. Oh, would you? They're shy. They won't come if they smell a stranger.
> You go down the back stairs together into the yard behind the bins. Sodium light. Wet concrete. Halloran rattles the saucer. Nothing comes.
> Then something does: the cats, all of them, thirty-one, out of every crack and drain and shadow at once, and then they see you and stop, a ring of yellow eyes at the edge of the light, every one of them bristling.
osmosis(4): They know what you are. Animals always know.
* Crouch. Go still. Let them come.  -> hl.still {do lean:restraint+1}
* Hiss. Clear them off.  -> hl.hiss {do lean:mercy-1}

# hl.still
> You go as still as the dead can go, which is very still. One by one, the cats come back to the saucer. A big ginger tom with half an ear comes and sits by your shoe and looks up at you with total contempt.
halloran: Well. I've never seen that. Charlie doesn't sit by anyone. Not that he's called Charlie. He's not called anything.
{do mem:halloran:charlie; rel:halloran+1}
@next hl.hub

# hl.hiss
> They vanish. All of them. Halloran stands in the yard with his saucer and his cardigan and looks at you like you've kicked him.
halloran: ...They'll come back. They always come back. Not for you, mind.
{do rel:halloran-1}
@next hl.hub

# hl.n3
halloran: They've gone. Four of them. Last night. Charlie... the ginger one... and the tabby with the white feet, and the two little black ones from the litter in June. Gone.
halloran: There was a van in the lane. Yellow. A man putting cages out. Humane traps, he said, when I asked. "Humane for whom?" I said. He laughed.
web(4): A pest controller in the Ward, putting out cages, during the week the federal government arrived. That's not a coincidence. Nothing this week is.
{do task:s_cats; note:s_cats|Mr. Halloran's yard cats are disappearing into traps set by a man in yellow overalls with a van on Ferrier Lane. He hasn't named them. He named one anyway: Charlie, the ginger tom.; flag:catsMissing=1}
* "I'll find them."  -> hl.find {do lean:loyalty+1}
* "They're only cats."  -> hl.only {do lean:mercy-1}

# hl.find
halloran: Would you? I know it's silly. Everything's happening. The murders, the lights, the police. And I'm crying about cats that aren't mine.
halloran: ...Charlie. I called him Charlie last night. In my head. I shouldn't have. That's why.
{do mem:halloran:find}
@next hl.hub

# hl.only
halloran: Yes. Only cats. Only thirty-one things in this building that are pleased to see me.
{do rel:halloran-1}
@next hl.hub

# hl.n4
halloran: The lights. The lights came on at nine and they were in the yard. Charlie came back from wherever he was, Tuesday, and he was in the yard when the light on the Rookery roof swung round, and his fur... his fur...
halloran: He's alive. He's under my bed. His back's all burned. Like a sunburn. In November. On a cat.
autopsy(5): UV burns on a cat. Hard ultraviolet, from the roofs. The lamps don't care what they burn.
@gate flag:pikeDone=freed ? hl.freed : hl.notfreed

# hl.freed
halloran: And the others came back. All of them. Out of nowhere, on Wednesday night, the ones from the cages. Someone let them out. Was it you? It was you. I can tell. You've got that face.
{do task:s_cats=done; rel:halloran+2; xp:40:Not Yet; mem:halloran:freed}
@next hl.charlie

# hl.notfreed
@next hl.charlie

# hl.charlie
* "Bring him to Dr. Rostova at St. Jude's. She'll treat him."  -> hl.vet {if alive:rostova}
* Give the cat a drop of your blood.  -> hl.blood {blood 1}
* "Keep him in the dark. He'll heal."  -> hl.dark

# hl.vet
halloran: A doctor? For a cat? At a hospital?
halloran: ...She'd do it, wouldn't she. She's that sort. She once stitched up my hand for nothing and called me an idiot. I'll take him.
{do flag:charlieVet=1; mem:halloran:vet}
@next hl.hub

# hl.blood
> You crouch by the bed. Charlie hisses at you from the dark. You let a drop fall from your fingertip onto his nose. He licks it off, furious, and then stops being furious, and then purrs, which he has never done in six years.
> The burns on his back are pink by the time you stand up.
halloran: What did you... he's purring. He doesn't purr. He's never purred.
tenant: You've made a ghoul of a cat. I'm genuinely impressed. I never once thought of it.
{do flag:charlieGhoul=1; mem:halloran:charlieghoul; rel:halloran+2; task:s_cats=done; xp:30:Not Yet}
halloran: ...He's mine now, isn't he. He's called Charlie and he's mine.
@next hl.hub

# hl.dark
halloran: The dark. Yes. I'll pull the curtains. He likes the dark. We both do, these days.
@next hl.hub

# hl.hub
* "Goodnight, Mr. Halloran."  -> hl.bye

# hl.bye
halloran: Goodnight. Mind the stairs. They're not mine either.
@end

// =====================================================================
// PIKE PEST SOLUTIONS · the exterminator on Ferrier Lane
// =====================================================================
# pk.0
@focus pike
> A broad man in yellow overalls, leaning on a van with PIKE PEST SOLUTIONS · WE CATCH WHAT CATCHES YOU on the side, eating a hot dog from Tariq's with the steady concentration of a man on overtime.
pike: Help you? Sorry. Can't stop for long. Big contract. Government. Rats, mostly. Rats under the whole Switchyard. Gotta do the lot by Friday.
pike: Dwayne Pike. Pike Pest. Pike, like the fish. Not like the weapon. People get confused.
* "Government contract? For rats?"  -> pk.govt
* "You've been catching cats too."  -> pk.cats {if flag:catsMissing}
* "What are you using?"  -> pk.agent

# pk.govt
pike: Department of Health. Community survey something. A fella in sunglasses. Paid triple, upfront, cash. Said the rats under Platform 0 are "carrying information". I said what, like gossip? He didn't laugh.
pike: Thirty-one access points. Every grate on that platform. Cyanide bait and a fogger. Friday, eleven p.m. latest. He was very particular about the time.
web(6): Harrow is gassing Soot's rats. Every rat in every grate. Two hours before the Tribunal. No rats, no ears in the pipes, and nobody to chew a wire under thirty-one lamps.
{do flag:knowPike=1; task:s_pest; note:s_pest|Dwayne Pike, an exterminator hired by "the Department of Health", is going to gas every rat under Platform 0's thirty-one grates on Friday at 11 PM. Mother Soot's ears. And anything else down there.}
@next pk.hub

# pk.cats
pike: Cats? Nah. Well. Yeah. The traps are for rats, but cats get in. Big ones. I've got six in the van. Can't let 'em go here, they'll just get back in. I'll drop 'em at the pound Saturday.
pike: Pound gasses on Monday. Not my problem. Don't look at me like that. Everyone looks at me like that. It's a job.
@next pk.hub

# pk.agent
pike: Bait for the rats. Fogger for the tunnels. Proper stuff. Military surplus. The fella in sunglasses brought it in an unmarked box. Says on the side NOT FOR CIVILIAN USE, which is a funny thing to give a civilian.
pike: Smells like almonds. That's how you know it's the good stuff.
autopsy(5): Hydrogen cyanide. In a tunnel. Under a platform where three hundred Kindred and anyone else will be standing on Friday. It won't kill the Kindred. It'll kill every mortal ghoul and servant and a whole Wraith's network of rats.
@next pk.hub

# pk.hub
* Show him what you are. "Leave the Ward. Tonight."  -> pk.scare {do lean:mercy-1}
* "Let the cats go. I'll pay you for them."  -> pk.buycats {if cash>=40}
* Let the cats out of the van while he's eating.  -> pk.freecats {if flag:catsMissing&!flag:catsFreed}
? velvet 10 "Do you know what's under that platform, Dwayne? It isn't rats."  -> pk.truth | pk.truthno {id pk_vel}
* Make him forget the job.  -> pk.fog {ab fog}
* Take his work order.  -> pk.steal {if !has:pikeorder}
* "Never mind."  -> pk.bye

# pk.scare
> You let him see your eyes. Just your eyes. The hot dog falls on the cobbles.
pike: Oh no. Oh no no no. Nobody said. Nobody said anything about. About.
> He's in the van and gone before you've blinked. He leaves the cages. He leaves the cats. He leaves the unmarked box of military surplus on the curb.
{do flag:pikeDone=scared; flag:catsFreed=1; task:s_pest=done; heat+1; xp:40:Pike Pest Solutions; give:pikeorder}
@end

# pk.buycats
pike: Forty for six cats? You're mad. Done.
> He opens the back. Six cages. Six furious cats. One of them is a big ginger tom with half an ear who looks at you with total contempt.
{do cash-40; flag:catsFreed=1; mem:pike:cats}
@next pk.hub

# pk.freecats
> He's facing the other way, mustard on his chin, telling a story to nobody about a rat the size of a terrier. You open the van doors. Six cages. You open those too. Six cats vanish into the night like smoke.
> The ginger one with half an ear stops at the end of the lane and looks back at you for a long second before he goes.
{do flag:catsFreed=1; flag:pikeDone=freed; mem:halloran:catsback}
@next pk.hub

# pk.truth
> You tell him. Not everything. Enough. The things that sleep under Platform 0, and the old woman in the pipes, and the grey man who wants every ear in the Ward deaf on Friday night.
pike: You're having me on.
> Then he looks at you properly. At your face in the sodium light. At the way you're not breathing unless you're talking.
pike: You're not having me on.
pike: Christ. He paid me triple. I should've known. Nobody pays triple for rats.
* "Don't do the job."  -> pk.nojob
* "Do the job. But do it wrong. Water in the canisters."  -> pk.wrong {do lean:candour-1}

# pk.nojob
pike: Don't do the job. And when the fella in sunglasses comes asking? He's got my van registration. He's got my mom's address.
pike: ...Fine. Fine. I'll tell him I got sick. Food poisoning. From Tariq's hot dogs. It's not even a lie, I've had three.
{do flag:pikeDone=refused; task:s_pest=done; xp:50:Pike Pest Solutions; lean:candour+1; rel:soot+1}
@end

# pk.wrong
pike: Water. In the canisters. Oh, that's good. That's very good. He'll never know till Saturday. By Saturday I'll be in Florida. I've always wanted to go to Florida.
{do flag:pikeDone=sabotaged; task:s_pest=done; xp:50:Pike Pest Solutions; rel:soot+1}
@end

# pk.truthno
pike: Under the platform? Rats. Big ones. I've seen the droppings. You can't tell me what's under a platform, mate, I've been under every platform in this city.
@next pk.hub

# pk.fog
> A grey fog rolls through him. He stands in the lane with a hot dog and a puzzled expression and then gets into his van and drives away to a different job in a different part of the city, entirely convinced that's where he was going.
{do flag:pikeDone=fogged; task:s_pest=done; xp:40:Pike Pest Solutions}
@end

# pk.steal
? stagecraft 9 Lift the clipboard off the van seat while he talks.  -> pk.stole | pk.stoleno {id pk_steal}

# pk.stole
> A work order, on a clipboard, in a plastic sleeve. *Client: US Dept. of Health (Community Survey). 31 grate access points. Cyanide-based. Deadline: FRIDAY 23:00. Authorised: T.H.*
web: Harrow's initials. A federal agency poisoning a train platform. That's a crime even mortals would prosecute.
{do give:pikeorder; mem:pike:stole}
@next pk.hub

# pk.stoleno
pike: Oi. That's mine. That's my clipboard.
@next pk.hub

# pk.bye
pike: Mind how you go. Mind the rats.
@end

// Soot hears about it
# ux3p.0 arc=soot night=3,4 label="\"Mother. Someone's coming to gas your rats.\"" if=room:shrine&flag:knowPike&!flag:sootKnowsPike prio=3
@focus soot
soot: Gas. Gas, gas, gas. Mm. I know. I heard him eat a hot dog. You can hear everything a man is through his teeth.
soot: You came to tell me. You didn't have to. Nobody tells me anything I haven't already heard. But you came anyway. That's new.
{do flag:sootKnowsPike=1; rel:soot+1; lean:loyalty+1}
@end

// =====================================================================
// THE 3:12 TO THE DOCKS · the number 9 night bus
// =====================================================================
# bus.0
> The number 9 night bus stops outside St. Jude's every forty minutes from midnight to six. Tonight it's almost empty: a nurse asleep against the window, a man with a bag of empty cans, and at the wheel a woman in her sixties with a Thermos wedged between her knees and the radio tuned to the shipping forecast.
dot: On or off, love. I'm not a waiting room.
{do meet:dot}
* Get on. Sit up front.  -> bus.ride
* "Do you see a lot of people like me?"  -> bus.like
* Step back. Let it go.  -> end

# bus.ride
> You sit in the seat behind her. The bus pulls away into the floodlit Ward.
dot: Dot Mulligan. Thirty-one years on the 9. Nights since 1997. I've seen everything a city can do between midnight and six, and some things it can't.
dot: You're one of the quiet ones. I can always tell. You sit at the front, you don't touch the rail, you don't show up in the mirror.
> She taps the long mirror over the windscreen. In it: the nurse, the cans, the empty seats. Not you.
dot: Don't worry. I don't mind. You lot tip. The live ones never tip.
@next bus.hub

# bus.like
dot: Like you? Pale, polite, no reflection? Three or four a night. They ride to the docks and back. They read the paper. One of them did a crossword every night for eleven years and got stuck on the same clue every time. I gave him the answer in 2009. He cried.
@next bus.hub

# bus.hub
* "Anything strange on the route lately?"  -> bus.strange {once}
* "Thirty-one years. Why nights?"  -> bus.why {once}
* Ride to the end of the line and back.  -> bus.loop

# bus.strange
dot: Strange. Love, everything's strange. But there is one. Since August. A young lad gets on outside St. Jude's at 3:12. Every night. Same seat, at the back. Rides to the docks. Doesn't get off. Rides back. Gets off at St. Jude's at 4:40.
dot: He's not one of yours. He shows up in the mirror. Just. Like a reflection in a puddle. He's warm, I think. Or he was. He shakes. He smells like a sunbed.
dot: I asked him once where he's going. He said "home". I said where's home, love? He said "I'll know it when I see it". Every night. He never sees it.
web(6): Since August. From St. Jude's. Shaking, smelling of UV. One of the seven didn't die. One of LANTERN's failures is riding the night bus because he can't remember where he lives.
{do task:s_bus; note:s_bus|Since August, a young man gets on the number 9 night bus outside St. Jude's at 3:12 AM, rides to the docks and back, and gets off at 4:40. He's warm, or was. He's looking for home. Take the 3:12 bus.; flag:knowBusBoy=1}
@next bus.hub

# bus.why
dot: My husband drove the day shift for thirty years. I drove nights so one of us would always be home with the kids. Then the kids grew up and he died and I kept driving nights out of spite.
dot: Also, the night's honest. In the day you can't tell who's bad. At night they don't bother hiding it.
@next bus.hub

# bus.loop
> Forty minutes to the docks and forty back, through the Ward under its floodlights. The cranes. The container yards. The black water. Dot points out the sights like a tour guide: where a man jumped in 1999, where a woman had twins on the back seat in 2004, where she saw something walking on the water once, in 2011, and decided she hadn't.
{do tick:80; comp+2:The night bus}
dot: Back where we started. That's the beauty of a loop, love. You always end up home.
@end

# bus.312
> 3:12. The number 9 pulls up outside St. Jude's. Dot opens the doors. A young man in hospital-issue grey sweatpants and a thin T-shirt gets on, holding the rail with both hands, and walks to the back seat, shaking.
dot: (quietly) That's him. That's my lad.
> He sits. He looks out of the window at the floodlights. In the mirror over the windscreen, he's there, but faint, like a man standing behind frosted glass.
@gate flag:knowBusBoy ? bus.312b : bus.312a

# bus.312a
dot: Same every night. Since August.
@next bus.312b

# bus.312b
* Sit beside him.  -> bus.sit
* Watch him from the front.  -> bus.watch

# bus.watch
> He shakes all the way. When the floodlight at the Halloran crossing sweeps the bus, he flinches and pulls the T-shirt up over his face, and where the light touches his forearm the skin goes red.
autopsy(5): UV sensitivity. Tremors. Pupils blown, amber at the rims. He's not dead. He's not a vampire. He's somewhere in between, and it's killing him slowly.
@next bus.sit

# bus.sit
> You sit down beside him. He doesn't look at you. He's very warm. Not warm like the living: warm like a fever, like a stone left in the sun.
luis: Is this the right bus? For home? I keep thinking it's the right bus.
* "Where's home?"  -> bus.home
* "What's your name?"  -> bus.name
* "You were in the basement at St. Jude's."  -> bus.basement {if flag:knowSeven|seen:tr.0|flag:knowTrial}

# bus.home
luis: There's a house with a blue door. And my mother. She makes caldo verde on Sundays. And there's a dog. Or there was. I can see the door. I can't see the street.
@next bus.name

# bus.name
luis: Name. I had a. I had a name card. On the cot. With my name on it.
luis: Luis. Luis Ferreira. Cohort A, number six. That's what the card said. I read it every morning for two months. Luis Ferreira, Cohort A, six.
web(5): Luis Ferreira. One of the seven. He wanted his mother to have his watch. Rostova said so.
{do flag:metLuis=1; meet:luis; note:s_bus|The passenger is Luis Ferreira, Cohort A #6, one of the seven. He's not dead. He's not Kindred. He's somewhere in between, and it's killing him. He's looking for a house with a blue door.}
@next bus.luis

# bus.basement
> He goes rigid. His hands come up over his face.
luis: No. No, I don't go back there. I don't. They put the light on me. Twenty minutes. Thirty. I could stand in it. I could STAND in it. And then I couldn't stop shaking.
luis: They said I died. I heard the doctor say it. "Six is gone." And they put me in a sheet. And I got up and walked out of the back of the butcher's in the sheet and nobody saw me.
@next bus.name

# bus.luis
dot: (from the front) Docks in five, love. End of the line.
luis: End of the line. Then back. Then back again. Every night. I can't stop. If I stop, I'll have to know where I am.
* "I'll take you home. Tonight."  -> bus.mother {do lean:mercy+1}
* "There's a detective who's been looking for you."  -> bus.miller
* "There's a doctor who might help."  -> bus.rostova {if alive:rostova}
* Give him your blood. It might stop the shaking.  -> bus.blood {blood 2}
* "There's nothing anyone can do. I'm sorry."  -> bus.mercy

# bus.mother
> You ask Dot where Ferreira lives. She knows, of course she knows: everyone who's driven the 9 for thirty years knows every name in the Ward. Pinewood Terrace, number 14. Blue door. She drives you there herself, off the route, at four in the morning, which she has never done in thirty-one years.
> The blue door. A light on in the kitchen. A woman in a dressing gown opens it before you knock, and sees her son on her step in hospital sweatpants, shaking, and makes a sound you'll remember for the rest of your life.
luis: Mãe. I found it. I found the door.
{do flag:busDone=home; flag:luisHome=1; task:s_bus=done; xp:70:The 3:12 to the Docks; tick:40; comp+3:The blue door; mem:luis:home}
dot: (in the bus, wiping her eyes with her sleeve) Right. Right. Back on route. Nobody saw that. I didn't see that.
@end

# bus.miller
luis: A detective. Police. Police put me in a sheet. No. No, the doctor put me in a sheet. The police lost the forms.
luis: ...A detective who looks for people? Like on TV?
* "Like on TV."  -> bus.millerok

# bus.millerok
> You call Miller on the burner from the back of the bus. She's at the end of the line in eleven minutes in her own car with her coat over her pyjamas.
> She looks at Luis. She looks at the file in her head. She sits down on the curb by the bus shelter at the docks and puts her face in her hands for one second, and then she stands up and puts her coat round his shoulders.
miller: Luis Ferreira. I've had your picture on my wall since August. Come on. Come on. We're going to get you a doctor who isn't her. And then we're going to talk.
{do flag:busDone=miller; flag:luisWitness=1; task:s_bus=done; xp:70:The 3:12 to the Docks; rel:miller+2; mem:miller:luis; flag:side_miller_luis=1}
web(5): A living survivor of the program. In police custody. With a mortal doctor's report. That's the case. That's the whole case.
@end

# bus.rostova
luis: The doctor. The doctor. No.
? velvet 11 "She's the only one who knows what they did to you. She's the only one who can undo it."  -> bus.rosok | bus.rosno {id bus_vel}

# bus.rosok
> You get off with him at St. Jude's at 4:40, and walk him in through the front doors, and Rostova looks up from a chart and sees him and drops it.
rostova: Six. Six is. Luis.
rostova: You were... I signed... I put you in a...
> She doesn't finish. She takes him by the arm, very gently, into cubicle four and draws the curtain. You hear her crying through it, and then you hear her start asking him questions in a steady voice, the way doctors do.
{do flag:busDone=rostova; flag:luisRostova=1; task:s_bus=done; xp:60:The 3:12 to the Docks; flag:rostovaGuilt=1; mem:rostova:luis}
@end

# bus.rosno
luis: No. No. Let me off. Let me off at the docks. I'll get the next one back.
@next bus.luis

# bus.blood
> You open your wrist. He doesn't understand. Then he smells it, and something in him that the program put there understands perfectly.
> He drinks. The shaking stops. All at once. He sits back against the window and breathes like a man surfacing from deep water, and in the mirror over the windscreen he's suddenly *clear*, solid, a young man with a tired face.
luis: Oh. Oh. I can see the street. I can see my street. Pinewood Terrace. Fourteen. Blue door.
tenant: Your blood finished what Elena's started. He's yours now. A ghoul, of a sort. A very strange sort. I don't know what he'll become.
{do flag:busDone=blood; flag:luisGhoul=1; task:s_bus=done; xp:60:The 3:12 to the Docks; mem:luis:ghoul; lean:mercy+1}
@next bus.mother

# bus.mercy
> He looks at you for the first time. Amber eyes. Very tired.
luis: Then let me ride. Please. Just let me ride.
> You get off at the docks. The bus pulls away with him on it, in the back seat, shaking, looking out at the dark for a blue door.
dot: Every night, love. Every night since August. I'll keep the heating on.
{do flag:busDone=left; task:s_bus=done; comp-2:The 3:12; mem:luis:left}
@end
`,'c_sq1');

/* consequences: Pike's gas on Friday at 11 PM, and new evidence at the Tribunal */
NL.Camp.tickHooks.push((S,G)=>{if(S.night===5&&S.time>=120&&!S.flags.pikeDone&&!S.flags.pikeGassed){S.flags.pikeGassed=1;
  if(S.flags.ratsGrates){S.flags.ratsGrates=0;S.flags.ratsDied=1;setTimeout(()=>G.text('Unknown','mm. mm. the almond smell came down the grates at eleven. my rats are dead. all of them. the lamps are still there. i\'m sorry, greedy. i\'m so sorry.'),1500);}
  else setTimeout(()=>G.toast('hurt','A smell of almonds comes up through the drains on Ferrier Lane and is gone.','Something died below'),1500);}});
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
  ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
    if(S.flags.luisWitness)M.push({t:'"Detective Miller has a living survivor of the program. Luis Ferreira, Cohort A, number six."',once:'tb_luis',ok:st=>{st.prog+=2;return [T('A ripple goes along the tracks. Survivors. Nobody survives LANTERN.'),L('magistrate','A living one. In the mortals\' hands. Then this is no longer only our business, is it.')];}});
    if(G.has('pikeorder'))M.push({t:'"And this: a federal work order to gas every grate on this platform two hours before you sat."',once:'tb_pike',ok:st=>{st.prog+=1;return [L('magistrate','Cyanide. For the rats. And for the ears.'),L('soot','My children. Mm. My little children.',{if:S=>!S.flags.sootDead})];}});
    return M;};})();
