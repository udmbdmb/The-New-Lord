'use strict';
/* THE NEW LORD — Night Two personal arcs, part one: Leo, Tariq, Pemberton, Gideon, Tiny, Mrs. Okafor, and the first dawn dream */
NL.Script.add(String.raw`
// =====================================================================
// DREAM 1 — Monday's dawn. The first time the Tenant speaks to you in sleep.
// =====================================================================
# dr1.0 dream=1
> You go down into the day the way a stone goes into a well. No dreams. Then, a long way down, a room.
> A study. Green lamp. Leather. A window with the curtains drawn so tight they look stitched. A man sits behind the desk with his back to you, writing with a fountain pen that scratches like a rat in a wall.
tenant: Sit down. You're making the furniture nervous.
> There is a chair. You sit in it. It is the most comfortable chair you have ever sat in and you hate it immediately.
tenant: This is my study. Was. It's yours now, I suppose, in the sense that a house belongs to whoever burned it down. I've kept it tidy. One does.
pedigree(4): Mahogany, Edwardian, a Bokhara rug worn through by one pair of feet pacing the same eleven steps for eighty years.
> He turns the chair. A long, grave, handsome face, older than its lines. He looks at you the way a man looks at the dog that ate his dinner: not angry. Interested in the logistics.
tenant: We should establish terms. You are, as far as I can tell, going to be living in my body's blood for the rest of whatever you have. I am going to be living in yours. One of us will eventually get tired of the arrangement.
* "Who killed you? Before I did."  -> dr1.who
* "Get out of my head."  -> dr1.out
* "What do you want from me?"  -> dr1.want
* Say nothing. Look at the desk.  -> dr1.desk

# dr1.who
tenant: Ah. Straight to the point. I liked that in clerks.
tenant: The honest answer is that I don't know. I remember a cold room, a light that wasn't the sun but was trying very hard, and a smell like a struck match the size of a church. And then I remember you, at my throat, which I will confess is the more vivid memory.
tenant: Someone knew I'd be in that freezer. Someone fixed the door. Someone pointed something at me that had no business existing. You find out who, and I'll be... grateful. As grateful as a thing in your veins can be.
web(6): Three questions, then. Who knew where he'd be. Who fixed the door. Who built the light.
{do mem:tenant:askedwho; lean:candour+1}
@next dr1.terms

# dr1.out
tenant: I would love to. I'd like a great many things. A cigar. My hands back. To have been somewhere else at a quarter past four on Monday morning.
tenant: But we've passed the point where either of us gets to leave, child. There is a word for what you did to me, and it isn't murder, though it has murder in it the way a cathedral has stone in it. Diablerie. You didn't just drink me. You *ate the part that sits behind the eyes*.
frenzy: And it was DELICIOUS.
tenant: ...Yes. Thank you. Your Beast and I will have words.
{do mem:tenant:toldout; lean:restraint+1}
@next dr1.terms

# dr1.want
tenant: What every tenant wants. Not to be evicted. Reasonable heating. Someone to talk to who isn't a rat.
> He puts the pen down.
tenant: And I want my Ward kept. Eighty years I held the Marrow Ward together with string and bribes and the occasional decapitation. It's a bad place full of good people and worse people and the line between them moves every night. If it falls apart while I'm in here, I'll have to watch.
pedigree(5): He means it. Under the vanity there's something like love for the place. The way you can love a dog that bites.
{do mem:tenant:askedwant; lean:loyalty+1}
@next dr1.terms

# dr1.desk
> The desk. A blotter. An inkwell. A framed photograph, face down. A ledger, open, every line in the same patient hand: names, sums, dates. *Ten percent.* Over and over. Ten percent.
tenant: Snooping. Good. You'll need the habit.
tenant: That's the book of everything I was owed. Every establishment in the Ward paid a tithe to the Court through me, and I took a tenth of the tithe for my trouble. Everyone does it. It's practically in the job description.
gutter(4): Ten percent off the top of a protection racket run by the people you're supposed to be protecting people from. He calls it the job description.
* Turn the photograph over.  -> dr1.photo
* Leave it.  -> dr1.terms

# dr1.photo
> A woman in a summer dress, 1920s, laughing at something outside the frame, holding her hat on against a wind that stopped blowing a century ago.
tenant: Put that down.
> His voice doesn't rise. The room gets colder anyway. The lamp gutters.
tenant: ...Please.
> You put it down. He breathes, the way the dead breathe, out of habit.
tenant: Her name was Agnes. I'll tell you about her when I know you better. Or never. Never is more likely.
nostalgia(3): Something in your chest that isn't yours aches, briefly, like a pulled tooth.
{do mem:tenant:agnes; sync+2:Agnes}
@next dr1.terms

# dr1.terms
tenant: Now. Terms. I will speak when I think you're about to do something stupid, or when I'm bored, which is often. You may ignore me. Most people did.
tenant: In return I ask one thing. When you are at your hungriest, and someone is soft and warm in front of you, and every voice in your head is screaming *yes*, I would like you to remember that I'm watching. Not because I'm good. I'm not. But because I would like the record to show I was, at least once, a bad influence on *nobody*.
* "Deal."  -> dr1.deal
* "I don't make deals with corpses."  -> dr1.nodeal
* "What do I get?"  -> dr1.get

# dr1.deal
tenant: Splendid. I'll have my people draw up the papers. I don't have people. I'll draw them up myself, in your sleep, in blood. Joke. Mostly.
{do flag:tenantDeal=1; lean:loyalty+1; sync+2:The terms}
@next dr1.wake

# dr1.nodeal
tenant: You've been making them all night, child. With Séverine, with Gideon, with that poor boy in the freezer. Corpses are the only people you *do* make deals with now.
{do flag:tenantDeal=0; lean:pride-1}
@next dr1.wake

# dr1.get
tenant: Eighty years of knowing where the bodies are buried. Literally, in several cases. Which clerk takes bribes in gold and which in gin. Which Elder is afraid of the dark. My manners, when yours fail. My name, when you need to frighten someone.
tenant: And company. You'll find the nights are long.
{do flag:tenantDeal=1; lean:pride+1}
@next dr1.wake

# dr1.wake
> The study tilts. The lamp slides off the desk without falling. Somewhere above you, a hundred miles of earth up, the sun is crossing the Marrow Ward like a searchlight looking for you.
tenant: Sleep, child. I'll keep watch. I've had practice.
@end

// =====================================================================
// LEO · Night Two · Room 3B
// =====================================================================
# lx2.0 arc=leo night=2 label="Sit down. Ask how he's really doing." if=room:apt&leo:here
@focus leo
> Leo moves a pile of joke notebooks off the other end of the couch so you can sit. Gerald the cactus watches from the windowsill.
leo: So. Tuesday. I've had a normal day. I slept until three, I ate cereal, I googled "vampire bite how long until" and then I cleared my search history like a man with something to hide, which, it turns out, I am.
leo: I keep touching my neck. Look. I'm doing it now. It's like having a song stuck in your head, except the song is two holes.
pulse(5): His pupils are a little wide. Heart steady, but he's sleeping badly. He keeps glancing at the door.
* "How are the holes? Let me look."  -> lx2.look
* "Have you told anyone?"  -> lx2.told
* "I'm sorry about Monday. About all of it."  -> lx2.sorry
* "You're handling this better than I would."  -> lx2.better

# lx2.look
> He tilts his head and pulls his collar down with the air of a man at a very strange doctor's appointment. Two neat punctures, healing clean. Your marks.
autopsy(4): Healing well. Faster than they should. Your blood got into him, a little, through the bite. He'll heal fast for a week, then it'll fade.
frenzy: You could reopen them. Easily. He wouldn't even mind. Look how he's offering.
leo: You're looking at me like I'm a pie in a window.
* Step back. "Sorry. Habit."  -> lx2.lookback {do lean:restraint+1}
* "You heal fast now. For a week or so. Don't waste it."  -> lx2.lookfast {do lean:candour+1}
* Lean closer. Just to smell.  -> lx2.looksmell {do lean:restraint-1}

# lx2.lookback
leo: A habit. Of course. One of those. Like nail-biting, but you bite other people's... necks.
leo: That's a joke. I'm writing it down. Not because it's good. Because I need to process.
{do mem:leo:restrained}
@next lx2.hub

# lx2.lookfast
leo: Fast. Like a superhero. Like a very small, specific superhero. Captain Paper Cut.
leo: Okay, that's actually useful. I've got a burn on my thumb from the fryer and it's already gone pink. I thought I was going mad. I mean. Madder.
{do mem:leo:toldtruth}
@next lx2.hub

# lx2.looksmell
> You lean in. Under the cheap soap and fryer oil, his blood is singing to yours, the way a tuning fork hums when its twin is struck.
leo: Hey. Hey. Personal space. Personal SPACE.
> He's off the couch and behind Gerald before you've straightened up. Holding the cactus like a shield.
tenant: Sit back, child. You're frightening the boy, and the cactus.
leo: ...We're cool. We're cool. I'm going to stand over here for this part of the conversation.
{do mem:leo:scared; rel:leo-1}
@next lx2.hub

# lx2.told
leo: Told anyone? Told them WHAT? "Hey Mom, I got bitten at work by a person who came out of a freezer, the Sheriff was ash, there's a detective sniffing around, also I'm thinking of quitting the meat counter to pursue comedy full-time"?
leo: She'd only hear the last bit. She'd only hear the last bit and she'd cry.
leo: Junie knows something's up. My sister. She texted me four times. "You alive?" Four times. I said yeah. She said "you sound weird." I texted that I'm always weird. That's been my brand since 2008.
nostalgia(5): A sister who checks if you're alive. Somewhere, you had one of those. You can feel the shape of the gap.
* "Tell Junie the truth. All of it."  -> lx2.junietruth {do lean:candour+1}
* "Keep it from her. It's safer."  -> lx2.junielie {do lean:candour-1}
* "Does Junie live near here?"  -> lx2.junienear

# lx2.junietruth
leo: You're serious. The truth. "Junie, vampires are real, I work at a vampire butcher, also I need you to keep calm."
leo: She'd believe me. That's the worst part. She'd believe me instantly and she'd come down here with a baseball bat and garlic. She's like that.
leo: I'll... I'll think about it. Maybe after Friday. Is Friday a thing? You keep saying Friday in your sleep.
{do mem:leo:junietruth; flag:leoJunie=truth}
@next lx2.hub

# lx2.junielie
leo: Safer. Yeah. That's what everyone in my family says before something gets worse.
leo: Fine. I'll be weird. I'm good at weird.
{do mem:leo:junielie; flag:leoJunie=lie}
@next lx2.hub

# lx2.junienear
leo: Junie? No, she's out on the coast. Bayside. She's a nurse. Nights. We're a night family, apparently. It's genetic, like the nose.
web(5): Out of town, a nurse, nights. If Leo ever needs somewhere to run, it's there.
{do flag:leoJunie=coast}
@next lx2.hub

# lx2.sorry
> He doesn't say anything for a while. He picks a bit of fluff off the couch arm, and then another.
leo: You know what's weird? You're the only person who's said that. Not the detective. Not the guy with the car. Not Margo, wherever Margo is. You. And you're the one who... you know.
leo: I don't know if I forgive you. I don't know if that's even the right category. It's like forgiving the weather.
* "You don't have to forgive me."  -> lx2.noforgive {do lean:mercy+1}
* "I was dying. I'd do it again."  -> lx2.again {do lean:candour+1; lean:mercy-1}
* "Then let me make it up to you."  -> lx2.makeup {do lean:loyalty+1}

# lx2.noforgive
leo: Good. Because I've got a lot on. I've got a set tonight. Forgiveness can go on the list after "work out if I'm still allowed to eat garlic bread".
leo: (Can I? Is that a thing? Would I hurt you if I ate garlic bread? Don't answer, I'm going to eat it anyway, but I'm going to feel really bad about it.)
{do mem:leo:sorry; rel:leo+1}
@next lx2.hub

# lx2.again
leo: ...Okay. Wow. Okay.
leo: No, that's. Actually that's better? That's honest. Everyone in my life lies to me to make me feel nice, it's kind of refreshing to be told I was dinner.
leo: I'm going to put that in the act. "I was dinner, and I was okay with it." Big laugh. Or a long silence. Fifty-fifty.
{do mem:leo:again}
@next lx2.hub

# lx2.makeup
leo: Make it up to me how? Are you going to buy me a car? Can vampires get credit? You've got like a three hundred year credit history. No. Wait. That's not you. That's the other guy.
leo: Come to my set. Tuesday. Tonight. The Lantern Room, ten o'clock. Sit at the back where the light's bad. If you laugh, I'll know it's real, because you won't have to.
{do mem:leo:invited; flag:leoInvited=1; promise:leoset:Go to Leo's set at the Lantern Room}
@next lx2.hub

# lx2.better
leo: Better? I've thrown up three times today. Once because of you, once because of the detective, once because of a burrito, which, to be fair, was going to happen anyway.
leo: But yeah. I've got this thing. When something's too big I make it smaller by making it stupid. Vampires? Okay. Vampires are tall mosquitoes with feelings. I can do five minutes on tall mosquitoes.
stagecraft(4): That's not coping. That's a craft. He takes the unbearable and sands it down into a shape you can hold. Watch him do it.
{do mem:leo:better}
@next lx2.hub

# lx2.hub
* "What are you going to do on stage tonight?"  -> lx2.set {once} {if !flag:lanternDone}
* "Who else has been asking about me?"  -> lx2.who {once}
* "Do you want me to make you forget all this?"  -> lx2.forget {once} {if !leo:forgot}
* "Margo locked the walk-in. Did she ever say why?"  -> lx2.margo {once}
* "I should go."  -> lx2.bye

# lx2.set
leo: New material. All new. I threw out my whole act this morning. The act was about my landlord and dating apps. Who cares. I got bitten by a vampire, my landlord's a pussycat now.
leo: I've got this opener: "I work nights at a butcher's. Monday night a customer came in and asked for something rare." And then I just look at the audience. And wait.
stagecraft(3): The timing is right. The pause does the work.
leo: Is that too much? Is that breaking the... what do you call it. The thing where nobody's allowed to know.
pedigree(4): The Masquerade. A joke on a stage is the safest place to tell the truth: nobody believes it. But someone at the back might.
* "It's perfect. Do it."  -> lx2.setgo {do lean:pride-1; flag:leoMaterial=vamp}
* "Cut it. Someone in that room might be one of us."  -> lx2.setcut {do lean:pride+1; flag:leoMaterial=safe}
* "Make it about the detective instead."  -> lx2.setmiller {do flag:leoMaterial=miller}

# lx2.setgo
leo: Yes. YES. Okay. I'm doing it. If I die on stage it'll be because a vampire told me to, which is a very funny way to die on stage.
{do mem:leo:encouraged; rel:leo+1}
@next lx2.hub

# lx2.setcut
leo: One of... at the Lantern Room? At an OPEN MIC? Who would... why would a vampire come to... oh, you're coming. Right. Okay. Fine. I'll do the landlord stuff. The landlord stuff kills on Tuesdays.
leo: Kills. Bad word. Goes well. The landlord stuff goes well.
{do mem:leo:careful}
@next lx2.hub

# lx2.setmiller
leo: The detective. Oh, that's good. "There's a detective who's very interested in my neck. That's the second most interested anyone's ever been in my neck this week." Oh, that's very good. You're good at this. Have you done comedy? Before you were... dead?
nostalgia(4): You don't know. You might have. You might have done anything.
{do mem:leo:millerbit; rel:leo+1}
@next lx2.hub

# lx2.who
leo: The detective. Miller. She came by this morning, well, afternoon, at like one, with coffee, which was manipulative, because I was going to tell her everything for the coffee.
leo: I didn't. I said I fell asleep in the back and woke up and everybody was gone. She wrote it down like it was poetry.
leo: And a guy. In a grey suit. Didn't knock. Just stood outside on the landing and looked at my door and left. I saw him through the peephole. Sunglasses. Indoors. At night.
web(5): Harrow. Already. He wants the boy who survived.
tenant: Grey suits. I never liked grey suits. They mean someone in an office far away has written your name on a list.
{do mem:leo:greysuit; flag:leoGreySuit=1}
@next lx2.hub

# lx2.forget
leo: Forget? Like... you can do that? Like, the flashy-thing in the movies?
> He thinks about it with his whole face. You watch it go across him: relief, then loss, then something stubborn.
leo: No. No, I think... if I forget, then it still happened, I just don't get to know it happened. Then it's not mine. Then I'm just a guy who lost a Monday.
leo: I'd rather have it. Even if it's terrible. It's the most interesting thing that's ever happened to me. Isn't that pathetic?
* "It isn't pathetic."  -> lx2.forgetok {do lean:mercy+1}
* "Your choice. I'll respect it."  -> lx2.forgetok {do lean:loyalty+1}
* "I'm not asking."  -> lx2.forgetforce {ab kneel} {if !flag:leoFogged}

# lx2.forgetok
leo: Okay. Thanks. That's... yeah. Thanks.
{do mem:leo:keptmemory}
@next lx2.hub

# lx2.forgetforce
> Your voice goes into him like a hand into a glove. His eyes go soft.
leo: ...Sorry, what were we talking about? Did you want tea? I don't know why I've got two cups out.
> He has no idea who you are. He's polite about it, the way you're polite to someone who's come to read the meter.
tenant: That was a choice, child. A neat one. I made it often. I'm not certain it was ever the right one.
{do flag:leoFogged=1; flag:tedState=forgot; lean:mercy-1; lean:candour-1; rel:leo-1; mem:leo:wiped}
@end

# lx2.margo
leo: Margo? She said "Lock the walk-in when you're done, Leonard." She never says that. She never calls me Leonard, either, that's my mom's thing. It was like she was saying it for a tape recorder.
leo: And the latch. The safety knob on the inside. It's been missing for a week. I asked her, she said she was getting it fixed. She didn't get it fixed.
web(5): Someone told her to make the freezer a trap. She did it, and then she warned Leo to stay out of it without saying why.
{do mem:leo:margolatch; fact:margo:lock}
@next lx2.hub

# lx2.bye
leo: Okay. Hey. Be careful out there. I don't know what careful means for you. Wear a hat? Avoid stakes? Don't walk under any... windows... at dawn?
leo: Just. Come back. You're kind of the only person who knows what's going on with me.
@end

// =====================================================================
// TARIQ · Night Two · the Lucky Mart
// =====================================================================
# tx2.0 arc=tariq night=2 label="Lean on the counter. \"How's business?\"" if=room:luckymart
@focus tariq
> Tariq is restocking the cigarette rack with the focus of a man defusing a bomb. He doesn't look round. He knows your footstep already.
tariq: You came back. Second night in a row. People will talk. People already talk. Mrs. Okafor says you have the face of someone who has been "through a hedge, spiritually".
tariq: Business is business. The murder down the street is very good for business. Police buy coffee. Reporters buy cigarettes. Ghouls buy... I don't know what ghouls buy. Gum. They buy so much gum.
gutter(4): He knows what ghouls are. He's using the word casually. He's been on this strip a long time.
* "You know what I am, don't you."  -> tx2.know
* "Tell me about the people who come in at night."  -> tx2.regulars
* "You look tired, Tariq."  -> tx2.tired
* "Wednesday. Dale and Pruitt. Tell me more."  -> tx2.cops {if flag:tariqRacket}

# tx2.know
tariq: I know what you buy. You buy nothing. You stand by the freezer and look at the ice cream like it insulted your mother. You don't sweat. When you came in last night the milk in the fridge went off.
tariq: ...That last part maybe was the fridge. The fridge is old.
tariq: I don't need to know what you are. My grandmother said, in the old country, there are people who come out at night and you give them bread and salt and you don't ask questions and they don't burn down your house. I give you coffee. Coffee is modern salt.
* "Bread and salt. I'll remember that."  -> tx2.salt {do lean:loyalty+1; rel:tariq+1}
* "If anyone asks, I'm a night-shift nurse."  -> tx2.cover {do lean:candour-1}
* "I'm a vampire, Tariq."  -> tx2.truth {do lean:candour+1}

# tx2.salt
tariq: Good. Then we have an understanding. You don't eat my customers. I don't tell the detective you smell like a freezer.
{do mem:tariq:salt}
@next tx2.hub

# tx2.cover
tariq: A nurse. Of course. Nights. Very hard work. Very pale nurses at St. Jude's. Many pale nurses. It's an epidemic of paleness.
tariq: I will say "nurse". I am a good liar for other people. For myself I'm very bad. My face does a thing.
{do mem:tariq:nurse}
@next tx2.hub

# tx2.truth
> He stops restocking. He looks at you properly for the first time. Then, very slowly, he crosses himself, which you suspect is not his religion, and then he touches the little silver hand hanging by the till, which you suspect is.
tariq: Okay. Okay. Thank you for telling me. I would prefer you didn't, but thank you.
tariq: I'm going to keep selling you coffee, and you're going to keep not drinking it, and we'll both pretend you said "nurse".
pedigree(4): You've just broken the Masquerade to a shopkeeper. Small. Private. It still counts.
{do mem:tariq:truth; flag:tariqKnows=1; heat+0}
@next tx2.hub

# tx2.regulars
tariq: The night people. Okay. Midnight, Mr. Halloran from the Rookery, cat food, he doesn't have a cat. One o'clock, the girls from the Reliquary, energy drinks, chips, they're very loud and they tip in compliments. Two o'clock, the detective, burnt coffee. She likes it burnt, she says it's like the job.
tariq: Three o'clock, nobody. Three o'clock is the dead hour. Even the drunks go home. Sometimes something walks past the window at three o'clock, slowly, and doesn't come in.
tariq: Four o'clock, the bread van. Five o'clock I lock the door for twenty minutes and pray and nobody knows except you now.
echo(5): He's been counting the hours for years. He knows the rhythm of this street like a heartbeat. If anything changes, he'll feel it first.
* "What walks past at three?"  -> tx2.three
* "Mr. Halloran has no cat?"  -> tx2.halloran
* "Thank you. That's useful."  -> tx2.hub

# tx2.three
tariq: I don't know. Tall. Coat. It walks like it's listening to the sidewalk. It stopped once, looked in at me through the glass, and the security camera turned off by itself.
tariq: It came every night for a year. It stopped coming about two weeks ago.
tenant: That was me, child. I walked my Ward at three. I used to look in at him. He always had his little light on.
nostalgia(5): A shop window, yellow, the only light on the strip. A young man behind the counter, reading. Watching him was a kind of rest.
{do mem:tariq:three; sync+1:The walk at three}
@next tx2.hub

# tx2.halloran
tariq: No cat. I asked. He said "Not yet." Every night for six years, "not yet". He feeds the strays in the yard behind the Rookery. Twenty, thirty cats. He says if he names one it will die. So: no cat.
tariq: Everyone on this street is a little bit broken, my friend. It's what makes it a street and not a catalogue.
{do flag:knowHalloran=1}
@next tx2.hub

# tx2.tired
tariq: Tired. Yes. I haven't slept properly since 2019. It's okay. It's a long story with a short end. My father had a stroke in the back room. Right there, by the mop bucket. At four in the morning. I was at home sleeping. Nobody found him until the bread van.
tariq: So now I'm here at four in the morning. Every morning. In case.
pulse(5): Grief he's turned into a schedule. He's very careful to say it lightly. It isn't light.
* Say nothing. Just stay a while.  -> tx2.stay {do lean:mercy+1; rel:tariq+1}
* "That wasn't your fault."  -> tx2.notfault {do lean:mercy+1}
* "I could make you sleep. One night. No dreams."  -> tx2.sleep {ab kneel}

# tx2.stay
> You stand by the counter. He restocks. Neither of you says anything for ten minutes. A bus goes past outside with nobody on it.
tariq: ...Thank you. That was nice. You're a strange nurse.
{do tick:10; mem:tariq:stayed; comp+1:Ten quiet minutes}
@next tx2.hub

# tx2.notfault
tariq: Everybody says that. My mother says that. The imam says that. I know it's not my fault. That's the problem. If it was my fault I could stop doing it.
{do mem:tariq:notfault}
@next tx2.hub

# tx2.sleep
> You say *sleep* into him gently, the way you'd tuck a blanket. He puts his head down on the counter between the lottery tickets and the gum and is asleep before you've finished the word.
> You mind the shop. Two customers come in. You sell them cigarettes and look them in the eye and they leave without paying and without remembering. You put the money in the till yourself.
> At four, the bread van. At four-oh-one, Tariq wakes up and looks at you as if he's never seen a face before.
tariq: I slept. I SLEPT. In the shop. Nothing... nobody... I *slept*.
> He laughs, and then he's crying, and then he's laughing again, and wiping his face with a napkin from the hot dog stand.
{do mem:tariq:slept; rel:tariq+2; lean:mercy+1; tick:60}
@next tx2.hub

# tx2.cops
tariq: Dale and Pruitt. Wednesdays, three a.m., unmarked Crown Vic. Two hundred a week or the health inspector finds rats. There are no rats. I've never had rats. Rats are scared of this shop.
tariq: Dale's the big one. He's a pig, but an honest pig. He wants money, he takes money. Pruitt's worse. Pruitt looks at me like he's sorry. Then he takes it anyway.
pulse(5): He's frightened of the sorry one. That tells you something about Tariq.
tariq: I don't want you to hurt them. I want them to stop. Those are two different things and I need you to understand them as two different things.
* "Understood. Nobody gets hurt."  -> tx2.nohurt {do promise:tariqnohurt:Nobody gets hurt over Tariq's racket; lean:mercy+1}
* "I'll do what's needed."  -> tx2.needed {do lean:mercy-1}

# tx2.nohurt
tariq: Okay. Good. I'm going to hold you to that. I don't know how. I'll glare at you.
{do mem:tariq:nohurt}
@next tx2.hub

# tx2.needed
tariq: ...That's what they say too.
{do mem:tariq:needed; rel:tariq-1}
@next tx2.hub

# tx2.hub
* "Have you seen Margo Kowalski?"  -> tx2.margo {once}
* "Any trouble on the strip tonight?"  -> tx2.trouble {once}
* "See you, Tariq."  -> tx2.bye

# tx2.margo
tariq: Margo? Tuesday morning, six, I see her at the bus stop with a carrier bag. All her stuff. She doesn't take the bus. Margo has a car. Margo has a very big car.
tariq: She saw me through the window. She did like this. Finger on her lips. Then the bus came.
web(4): She ran on Tuesday morning, after the Sheriff died, before anyone could ask her about the door. She went somewhere you can get to on a bus.
{do flag:knowMargoBus=1}
@next tx2.hub

# tx2.trouble
tariq: Trouble? A woman in a red dress came in at eleven and bought nothing and looked at every customer like a menu. Very beautiful. Very bad for business. She asked me if I'd seen "the new one". I said what new one, the new chips? She laughed. My teeth hurt.
pedigree(5): A Gilded Court huntress. Séverine's people are already walking your streets, asking.
{do flag:courtAsking=1}
@next tx2.hub

# tx2.bye
tariq: Go with God, or whoever you go with. Coffee's on the house. I know you won't drink it. Take it anyway. It's warm. Hold it. It's nice.
{do give:coffee}
@end

// =====================================================================
// PEMBERTON · Night Two · in the car
// =====================================================================
# px2.0 arc=pemberton night=2 label="\"Pemberton. Talk to me.\"" if=flag:mapOK&!flag:pemDead
@focus pemberton
> Pemberton opens the rear door for you and, when you shake your head, closes it again and opens the front passenger door instead. He considers this a tremendous concession.
pemberton: Sir. Madam. I apologize. I have not yet settled on a form of address. The Sheriff preferred "sir" and I find my mouth still wants to make the shape.
* "Call me whatever you called him."  -> px2.sir {do lean:pride+1; sync+1:Sir}
* "Use my name. When I find out what it is."  -> px2.name {do lean:pride-1}
* "Boss is fine."  -> px2.boss

# px2.sir
pemberton: Very good, sir. It's a comfort. Forgive an old man his comforts. {if !flag:female}
pemberton: Very good... sir. The Sheriff would have laughed at me. But it's a comfort. Forgive an old man his comforts. {if flag:female}
{do flag:pemAddress=sir; mem:pemberton:sir}
@next px2.hub

# px2.name
pemberton: When you find it. Yes. Until then, I shall say nothing at all, which the Sheriff always said was my best form of address.
{do flag:pemAddress=name; mem:pemberton:name}
@next px2.hub

# px2.boss
pemberton: "Boss." Very modern. I shall try it. ...Boss. No. No, it tastes of chewing gum. I will practice in the mirror.
{do flag:pemAddress=boss}
@next px2.hub

# px2.hub
* "How long did you serve him?"  -> px2.years {once}
* "What do you know about Monday night?"  -> px2.monday {once}
* "Do you hate me?"  -> px2.hate {once}
* "What do you need, Pemberton? For yourself."  -> px2.need {once}
* "Drive."  -> px2.drive

# px2.years
pemberton: Forty-one years. I came to him at twenty-three from the merchant navy with one good suit and a bad reputation. He gave me the suit's twin, and a sip, and a set of keys. I've driven him through two wars, four elections and one very bad night in 1977 that we agreed never to discuss.
pemberton: He was not a kind man. He was a *fair* man, which is rarer and colder. He paid on time. He never asked me to do anything he wouldn't do himself, though there was very little he wouldn't do.
tenant: He's being generous. I asked him to do several things I wouldn't. That's what ghouls are *for*.
pedigree(4): A ghoul is a mortal fed vampire blood regularly. It keeps them young and strong, and bound. Forty-one years of the Sheriff's blood. He's older than he looks. And without the Sheriff, the blood will run out.
{do mem:pemberton:years}
@next px2.hub

# px2.monday
> His hands tighten on the wheel. Leather creaks. He looks at the rear-view mirror, where you don't appear.
pemberton: I was asleep in the car on Ferrier Lane until eleven, ‹sir›. I said so to the detective.
web(5): That's what he said last night. Word for word. He's practised it.
* "Pemberton. The truth."  -> px2.truth {if seen:pr.done|flag:prophetDone}
? velvet 11 "You can lie to Miller. You don't have to lie to me."  -> px2.truth | px2.lie {id px2_vel} {mod like:pemberton}
* "All right. Asleep until eleven."  -> px2.lie {do lean:loyalty+1}

# px2.truth
pemberton: ...I wasn't asleep.
pemberton: I drove him to Kowalski's at ten to four. He went in the back. You were already there, you'd come in with him, he'd brought you for something, a witness, a courier, I didn't ask. Then a car I didn't know with its lights off. A woman. Then a light under the freezer door, white, like a welding arc, and a sound like a kettle screaming.
pemberton: Then you came out. Running. Burning. With him in your arms, what was left of him, and your mouth... I won't say. You fell in the lane. I carried you back in. I told Mrs. Kowalski to lock the door against the sun. And then I sat in the car until it was light and did not go in.
pemberton: Forty-one years and I sat in the car.
pulse(5): His voice hasn't changed. His knuckles are white on the wheel. He's been carrying this alone for two days.
* "You saved my life."  -> px2.saved {do lean:mercy+1; rel:pemberton+1}
* "You could have saved his."  -> px2.couldhave {do lean:mercy-1}
* "Who was the woman?"  -> px2.woman

# px2.saved
pemberton: I saved *something*. I'm still deciding what.
pemberton: Thank you, ‹sir›. It does help, a little, to be told so by the something.
{do flag:pemConfessed=1; mem:pemberton:saved}
@next px2.hub

# px2.couldhave
pemberton: Yes. I could have. I've thought of very little else.
> He starts the engine. He doesn't look at you for the rest of the night.
{do flag:pemConfessed=1; mem:pemberton:blamed; rel:pemberton-1; comp-1:You said it}
@next px2.hub

# px2.woman
pemberton: Small. Dark coat. She moved like someone carrying something heavy and expensive. She drove a Volvo, an estate, the old boxy kind. Doctor's car. Everyone on the Strip knows that car.
web(6): Rostova drives a Volvo. Her clinic is two blocks away.
{do flag:pemConfessed=1; flag:knowVolvo=1; mem:pemberton:woman}
@next px2.hub

# px2.lie
pemberton: Asleep until eleven. Yes. Thank you, ‹sir›.
{do mem:pemberton:lied}
@next px2.hub

# px2.hate
pemberton: Hate you? ‹Sir›, I've had forty-one years to learn to hate. I'm very bad at it. I start with good intentions and then somebody needs a lift.
pemberton: I don't know what I feel about you. You're wearing his coat. You're wearing his *blood*. Sometimes when you turn your head the light does what it did on him. And then you say something he would never say in a thousand years, and I remember.
* "What would he never say?"  -> px2.never
* "I'm not him."  -> px2.nothim {do lean:pride-1}
* "Maybe I'll grow into him."  -> px2.grow {do lean:pride+1; sync+2:Growing into the coat}

# px2.never
pemberton: "Thank you." "Sorry." "Are you all right, Pemberton." You've said all three already. He said them perhaps twice, in forty-one years. One of those was on a sinking ship, so it may not count.
{do mem:pemberton:never; rel:pemberton+1}
@next px2.hub

# px2.nothim
pemberton: No. No, ‹sir›. That's becoming clear.
{do mem:pemberton:nothim}
@next px2.hub

# px2.grow
pemberton: I would be careful with that, ‹sir›. Coats get heavier the longer you wear them. His certainly did.
{do mem:pemberton:grow}
@next px2.hub

# px2.need
> A very long silence, by Pemberton's standards, which are geological.
pemberton: Need. I hadn't thought. One doesn't, in service.
pemberton: The blood, ‹sir›. If I'm honest. I took my last sacrament from the Sheriff on Sunday. Ghouls don't die without it, not quickly. We simply... catch up. All forty-one years, over a month or so, like a bill that comes due.
pemberton: I'm not asking. I want to be very clear that I am not asking.
autopsy(5): He's already started. The tremor in the left hand. The tired eyes. A man of sixty-four wearing a man of seventy-two like an overcoat.
* Open a vein on your wrist. Offer it.  -> px2.feed {blood 1}
* "I can't spare it. Not yet."  -> px2.notyet {do lean:candour+1}
* "We'll talk about it after Friday."  -> px2.friday {do promise:pemblood:Talk about Pemberton's blood after Friday}

# px2.feed
> You hold your wrist over the gearstick. He looks at it the way a drowning man looks at a rope that might be a snake.
pemberton: ‹Sir›. I...
> He drinks. Not much. He's a gentleman about it. When he sits back, the tremor in his hand is gone, and he is looking at you with an expression you will spend the rest of the week trying to read.
tenant: There. Now he's yours. Not mine. Yours. I hope you understand what you've just signed.
{do flag:pemFed=1; flag:pemBound=1; rel:pemberton+2; lean:loyalty+1; sync-2:Your blood, not his; mem:pemberton:fed}
@next px2.hub

# px2.notyet
pemberton: Of course not. Quite right. I withdraw the not-question.
{do mem:pemberton:notyet}
@next px2.hub

# px2.friday
pemberton: After Friday. Yes. If there is an after.
{do mem:pemberton:friday}
@next px2.hub

# px2.drive
pemberton: Where to?
@end

// =====================================================================
// GIDEON · Night Two · the Pawn & Coffin
// =====================================================================
# gx2.0 arc=gideon night=2 label="\"Slow night, Gideon?\"" if=room:pawn
@focus gideon
> Gideon is mending a pocket watch under a jeweller's lamp, his loupe screwed into one eye like a monocle that has given up pretending.
gideon: Slow? Slow is good. Slow means nobody's dead yet tonight. Fast means I'm renting boxes to people who look over their shoulder while they sign.
gideon: You slept well? Box three, wasn't it. Good box. The lid sticks, but you didn't need to get out in a hurry, did you. Nobody came.
* "Nobody? You're sure?"  -> gx2.nobody
* "How long have you been doing this? Renting to us."  -> gx2.howlong
* "What's that watch?"  -> gx2.watch
* "I need a favour."  -> gx2.favour

# gx2.nobody
gideon: A woman came at noon. Daylight. Asked for "the guest in three". I said there's no guest in three, there's a coffin in three, coffins are for sale not rent, and would she like to look at our oak range. She looked at our oak range for eleven minutes. Then she left.
gideon: She had a federal haircut. You know a federal haircut. Like a helmet made of hair.
web(5): LANTERN, in daylight. They knew where you slept. They didn't open the box. Why not?
tenant: Because they want you to walk to them, child. Daylight is when they shop.
{do flag:lanternKnowsPawn=1; mem:gideon:protected; rel:gideon+1}
@next gx2.hub

# gx2.howlong
gideon: Since 1971. My father sold coffins to the living. I sell them to the other sort. Better customers. They never complain about the fit.
gideon: First one was a Wraith girl in a fur coat who needed somewhere to sleep that wasn't a drain. She paid in Krugerrands. I asked no questions. She came back every winter for eleven years and then one winter she didn't. Her box is still in the back. Nobody rents it.
nostalgia(4): He's kept it fifty years. Paid rent on an empty coffin out of his own pocket. Sentiment, from a man who prices sentiment by the ounce.
gideon: Rules of the house: cash, no questions, no feeding on the premises, and sunrise guaranteed. The last one is the only one that matters. In fifty-five years I've never had a guest burn. I intend to die with that record.
{do mem:gideon:history}
@next gx2.hub

# gx2.watch
gideon: A Waltham, 1910. Pawned by a gentleman who said it was his grandfather's. It's not. It's the Sheriff's.
gideon: Vane pawned it with me in 1952 when he was short for a bribe. Never came back for it. I keep it wound. Every Tuesday. Seventy years.
> He turns it over. Engraved on the back: *A. from A.*
tenant: ...I'd forgotten that. I'd forgotten I gave it to him. Agnes gave it to me. I pawned the only thing she ever gave me to pay off a Prince's catamite.
* "Can I buy it?"  -> gx2.buywatch {if cash>=60}
* "Keep it wound for him."  -> gx2.keepwound {do lean:loyalty+1; sync+1:Agnes's watch}
* "Sell it to me cheap. He was my... he's family now."  -> gx2.cheapwatch

# gx2.buywatch
gideon: Sixty. The interest on seventy years would buy you the shop.
> You count it out. He wraps the watch in tissue like an egg.
{do cash-60; give:watch; flag:agnesWatch=1; sync+3:Agnes's watch; mem:tenant:watch}
tenant: ...Thank you. That was unnecessary and I'm grateful in a way I'd rather not discuss.
@next gx2.hub

# gx2.keepwound
gideon: I will. I was going to anyway. It's company.
{do mem:gideon:watchkept}
@next gx2.hub

# gx2.cheapwatch
gideon: Family. Ha. That's a new one. "He's family now, I drank him." I've had people try "it's my grandmother's" on me with things they stole from their grandmother, but never that.
? velvet 9 "Thirty. He'd want me to have it."  -> gx2.cheapok | gx2.cheapno {id gx2_watch}

# gx2.cheapok
gideon: Thirty. For the cheek.
{do cash-30; give:watch; flag:agnesWatch=1; sync+3:Agnes's watch; mem:tenant:watch}
@next gx2.hub

# gx2.cheapno
gideon: Sixty. Cheek costs extra.
@next gx2.hub

# gx2.favour
gideon: A favour. Everyone wants a favour. A favour is a debt with good manners. What sort?
* "Somewhere safe for a friend. A mortal."  -> gx2.safe
* "Information about the Court."  -> gx2.court
* "A gun."  -> gx2.gun
* "Never mind."  -> gx2.hub

# gx2.safe
gideon: The back room's safe. Safe from your sort. Not from the police, not from the tax man. Sunrise guaranteed, that's the rule. For a mortal I'd charge less, they eat more. Fifty a night.
gideon: Who's the friend?
web(4): You might need this later. For Leo, or Margo, or someone you haven't met yet.
{do flag:gideonSafehouse=1; mem:gideon:safehouse}
@next gx2.hub

# gx2.court
gideon: About the Court. I know they pay on the ninth of every month, by courier, in old notes that smell of cloves. I know Lady Séverine has rented box eleven every Christmas Eve since 1965 and never once slept in it. She sits in the back with the lid open and reads.
gideon: I don't know what. I don't ask. That's the business.
pedigree(5): Séverine, alone, on Christmas Eve, in a pawnshop, reading. You will want to know what.
{do flag:knowSevBox=1}
@next gx2.hub

# gx2.gun
gideon: No guns. I sell watches and boxes. Guns make holes in boxes.
gideon: ...There's a man on Platform 0 who'll sell you anything with a trigger. Don't tell him I sent you. He'll charge me a referral fee.
@next gx2.hub

# gx2.hub
* "What do you think of me, Gideon? Honestly."  -> gx2.think {once}
* "Goodnight, Gideon."  -> gx2.bye

# gx2.think
gideon: Honestly? You're a good customer. You pay. You say thank you. You haven't eaten anyone in my shop.
gideon: The ones who say thank you are usually the dangerous ones. The rude ones are just rude. The polite ones are deciding something.
{do mem:gideon:think}
@gate like:gideon>=2 ? gx2.thinkwarm : gx2.hub

# gx2.thinkwarm
gideon: And you keep your word. That's rare in a young one. Rare in an old one. I've started setting a cup out for you. I know you don't drink it. Habit.
@next gx2.hub

# gx2.bye
gideon: Sunrise guaranteed.
@end

// =====================================================================
// TINY · Night Two · the Reliquary door
// =====================================================================
# kx2.0 arc=tiny night=2 label="Stand with him a while." if=room:reliquary&flag:vipOK
@focus tiny
> Tiny is on the door with his clicker and his clipboard, letting in a girl with glitter on her eyelids and turning away a man in a suit that cost more than the club. He doesn't explain. He never explains.
tiny: You again. You're on the list. You've been on the list since Monday. I don't know who put you there. Nobody I let on the list.
pedigree(4): Séverine's list. Her hand on your name. That's either a courtesy or a leash.
* "How are you feeling? Your kidneys."  -> kx2.kidney {if fact:tiny:kidney|flag:tinyKidney|task:s_tiny}
* "Who gets turned away? Why?"  -> kx2.door
* "Nine years on this door. What have you seen?"  -> kx2.seen
* "What's the list?"  -> kx2.list

# kx2.kidney
> He doesn't look at you. He clicks someone in.
tiny: Grey. That's how I feel. Grey all the way down, like a sidewalk. Three sessions a week is what they want, I'm doing one. The machine takes four hours. The door doesn't wait four hours.
tiny: Lady said if I'm sick I'm out. Not cruel. She just doesn't keep broken things. Everybody knows that.
* "Then I'll keep you out of the hospital's records."  -> kx2.cover {do lean:mercy+1}
* "Why stay? Quit. Go get treated."  -> kx2.quit
* "Your secret's safe."  -> kx2.secret {do lean:loyalty+1; rel:tiny+1}

# kx2.cover
tiny: How?
web(4): You don't know yet. St. Jude's has supplies. Rostova sells things out of a back fridge. There's a way.
tiny: ...Don't promise. Just do it or don't. I've had enough promises from the people in that basement.
{do mem:tiny:cover}
@next kx2.hub

# kx2.quit
tiny: Quit. And do what? I'm six foot six with a memory for faces and no qualifications. I've got a mom in a home on the Heights at two grand a month. The door pays for the home.
tiny: The door is the only place in this city where I'm the one deciding. You understand? Out here, I'm a big lad with bad kidneys. On the door, I'm God.
{do mem:tiny:god}
@next kx2.hub

# kx2.secret
tiny: Better be.
{do mem:tiny:secret}
@next kx2.hub

# kx2.door
tiny: Suits that think they own the place. Men who look at the girls before they look at me. Anyone who asks me what's "really" downstairs. Anybody whose hands shake. Shaky hands means drugs or fear, and both make trouble.
tiny: And anybody the Lady's people point at. They point, I turn. No arguing.
gutter(5): He keeps the mortals and the monsters from noticing each other. It's harder than it looks.
{do mem:tiny:door}
@next kx2.hub

# kx2.seen
tiny: I've seen a man walk downstairs at midnight and walk up again at four, sixty years younger. I've seen a woman come up with her throat open, smiling, and get in a taxi. I've seen the Sheriff turn a fight off by walking into the room.
tiny: Once I saw a kid come up the stairs crying, about nineteen, Court ring on his finger, saying "she said she'd make me like her". He went back down. I never saw him come up again.
tiny: You get to know what this place is. You decide what you are about it.
{do mem:tiny:seen}
@next kx2.hub

# kx2.list
tiny: Three lists. The guest list, which is for the dancefloor. The Lady's list, which is for downstairs, and which I don't read, I just get told. And mine, in my head. Nobody's seen mine.
tiny: You're on my list too. Under "don't know yet".
@gate like:tiny>=2 ? kx2.listgood : kx2.hub

# kx2.listgood
tiny: ...Moved you up, actually. To "all right". Don't let it go to your head. It's a short list. My mom's on it, and a dog.
{do mem:tiny:alright}
@next kx2.hub

# kx2.hub
* "Need anything?"  -> kx2.need {once}
* "Good night, Tiny."  -> kx2.bye

# kx2.need
tiny: Need. A new body. A new mom. A new job where nobody bites.
tiny: Bring me a coffee next time. Black. That's need enough.
{do flag:tinyCoffee=1}
@next kx2.hub

# kx2.bye
tiny: Mind the stairs. Third one's loose. Lady won't fix it. Says it keeps people honest.
@end

// =====================================================================
// MRS. OKAFOR · Night Two · Room 404
// =====================================================================
# ox2.0 arc=okafor night=2 label="Ask about Dani." if=room:apt&flag:met404
@focus okafor
> Mrs. Okafor makes tea you won't drink and sets it in front of you anyway, on a saucer with a doily, because there are standards.
okafor: Dani was going to be a vet. Twenty-two. Third year. She worked nights at St. Jude's on the desk to pay for it. She said the night shift was full of interesting people. I said interesting people are the ones who get you killed.
okafor: Then in August she went in for her shift and she didn't come home, and the police said "she's an adult, Mrs. Okafor, adults go where they want".
pulse(4): She's said this a hundred times to a hundred people. It doesn't get easier. It gets smoother.
* "Tell me about her. Not the disappearance. Her."  -> ox2.her {do lean:mercy+1}
* "Who did she talk about at the clinic?"  -> ox2.clinic
* "Did the police do anything at all?"  -> ox2.police

# ox2.her
> She brightens like a lamp being turned up.
okafor: She was a terrible cook. TERRIBLE. She burnt rice. Who burns rice? She sang in the bath and the man in 304 banged on the ceiling. She was rude to bus drivers and kind to pigeons. She had a boyfriend called Marcus who I didn't like and then I did like and then they broke up and I was sad for a month.
okafor: She drew a heart on everything. Her school books, her coffee cups, her name card at the clinic. She'd done it since she was nine.
nostalgia(4): A heart in biro on a name card. You'll know it if you see it.
{do mem:okafor:dani; rel:okafor+1; flag:knowDaniHeart=1}
@next ox2.hub

# ox2.clinic
okafor: The doctor. Rostova. Dani liked her. She said Dr. R. was "intense but fair". Said she was working on something big, research, in the basement, something that would "change everything about blood".
okafor: In July Dani said she'd signed up for a "trial". Paid. Five hundred dollars. She was going to buy textbooks. I said what kind of trial? She said, "Mom, it's just blood tests, they want healthy people."
web(6): A paid trial, healthy volunteers, in the basement. Seven of them. The Tuesday room.
{do flag:knowTrial=1; mem:okafor:trial}
@next ox2.hub

# ox2.police
okafor: A detective came. The woman. Miller. She was the only one who wrote things down properly. She said "I believe you". Nobody had said that.
okafor: Then she came back in September and said her captain had taken her off it. She cried in my kitchen. A police detective. She drank three cups of tea and cried and then she put her coat on and said "I'm going to keep going anyway, just quieter".
pedigree(4): Miller's been working this alone for months, off the books, against her own captain.
{do mem:okafor:miller}
@next ox2.hub

# ox2.hub
* "And the chimney? The scratching?"  -> ox2.chimney {once}
* "I'll find out what happened to her."  -> ox2.promise {once} {if !flag:daniTold}
* "Thank you for the tea."  -> ox2.bye

# ox2.chimney
okafor: Ten years. Since before Dani was gone. It scratches at night and sometimes it cries. I used to think it was a bird. Then I thought it was Dani. Then I thought I was going mad.
okafor: Mr. Halloran in 302 says it's rats. Mr. Halloran says everything is rats.
{do mem:okafor:chimney}
@next ox2.hub

# ox2.promise
okafor: Don't. People promise. Then they don't come back.
? velvet 8 "I'll come back. Whatever I find."  -> ox2.promok | ox2.promno {id ox2_prom} {mod like:okafor}

# ox2.promok
okafor: ...All right. All right. Come back, then. Whatever it is.
{do promise:dani:Find out what happened to Dani Okafor and tell her mother; lean:loyalty+1; mem:okafor:promised}
@next ox2.hub

# ox2.promno
okafor: You say it like a policeman. Sit. Drink your tea. Don't promise me anything.
@next ox2.hub

# ox2.bye
okafor: You didn't drink it. You never do. Next time I'll make you something else you won't drink.
@end
`,'c_n2a');
