'use strict';
/* THE NEW LORD — last words before the sun, part four: the people this week added */
(function(){const O=NL.Script.opt;
O('dw.talk','* Nell, in her too-big coat, at the foot of the stairs, about to go and catch the 9.  -> dw4.nell {once} {if flag:nell=taught&!flag:purge|flag:nell=fed&!flag:purge|flag:nell=gideon&!flag:purge}','start');
O('dw.talk','* Mother Soot, half in the drain grate, about to go back down.  -> dw4.soot {once} {if alive:soot&seen:pf2.soot&!flag:purge}','start');
O('dw.talk','* Little Sal, by the east tunnel, with a pot of soup nobody ate.  -> dw4.sal {once} {if flag:side_union&!flag:purge}','start');
O('dw.talk','* The fledgling in the Gilded coat, still standing alone.  -> dw4.fl {once} {if flag:metFledgling&!flag:purge}','start');
O('dw.talk','* Lisette, counting the people going up the stairs.  -> dw4.lis {once} {if flag:lisetteCount&!flag:purge}','start');
})();
NL.Script.add(String.raw`
# dw4.nell
@focus nell
nell: I'm getting the 9. The last one. Earl waits at the depot for me now. He says it's because the timetable's wrong. It isn't.
nell: You didn't burn. I came to see if you didn't. You didn't.
* "Mind the step, sweetheart."  -> dw4.nell1
* "Go on. You'll miss it."  -> dw4.nell2

# dw4.nell1
> She laughs. It's the first time you've heard her laugh. It sounds nineteen.
nell: That's his line. You stole his line. I'm telling him.
> She goes up the stairs two at a time, coat flapping, and at the top she turns and lifts her hand.
{do comp+2}
@next dw.talk

# dw4.nell2
nell: I won't. He'll wait. He always waits.
{do comp+1}
@next dw.talk

# dw4.soot
@focus soot
soot: Up. I came up. Two hundred people saw me. They'll talk about it for a century.
soot: I'm going down now. It's very bright up here. Even at five in the morning. You lot don't know how bright it is.
* "Thank you for coming up, Mother."  -> dw4.soot1
* "Come up again. Sometime. For no reason."  -> dw4.soot2

# dw4.soot1
soot: That's four. Four thank-yous. I'm putting them all in one jar. It'll be the warmest jar on the shelf.
{do rel:soot+1}
@next dw.talk

# dw4.soot2
soot: For no reason. Hm. Hm. I've never done anything for no reason in my life.
soot: ...Perhaps. In the spring. When the candles need changing. I'll pretend it's for the candles.
{do rel:soot+2; flag:sootUpAgain=1}
@next dw.talk

# dw4.sal
> Little Sal, in his knit hat, stirring a pot of cold soup by the east tunnel with enormous care, as if it might still be eaten.
> He's been crying all night. He's crying now. He looks up at you and doesn't stop.
* "It was never about the soup, Sal."  -> dw4.sal1
* Take a spoon. Have some.  -> dw4.sal2

# dw4.sal1
> He nods, very fast, several times. He holds out the ladle anyway. You don't take it. He doesn't mind. He puts the lid back on the pot and pats it, the way you'd pat a dog.
{do comp+1}
@next dw.talk

# dw4.sal2
> You can't eat it. You both know you can't eat it. You take the spoon. You hold it. You lift it to your mouth and put it back in the pot.
> Little Sal makes a sound like a building falling down in slow motion, and puts his arms round you, and lifts you off the platform, and Local 0 cheers.
{do comp+3; rel:dutch+1}
@next dw.talk

# dw4.fl
> She's still standing at the end of the Court benches, alone, hands in her sleeves. The Court is leaving around her. Nobody has spoken to her all night.
> "You didn't burn," she says. "So... so maybe..."
* "Come and see Gideon. At the Pawn & Coffin. Tell him I sent you."  -> dw4.fl1 {if alive:gideon}
* "Find Dutch. Local 0 takes everyone."  -> dw4.fl2 {if flag:side_union}
* "Maybe. Go home. Come and find me tomorrow."  -> dw4.fl3

# dw4.fl1
> "Gideon," she says, like a word in a language she's learning. "The Pawn & Coffin." She goes up the stairs. Halfway up, she starts to run.
{do flag:fledglingSafe=gideon; comp+1}
@next dw.talk

# dw4.fl2
> Dutch, overhearing, turns round with a thermos in each hand. He holds one out to her without a word. She takes it. She stands next to him. That's how it starts. That's how it always starts.
{do flag:fledglingSafe=union; comp+1}
@next dw.talk

# dw4.fl3
> "Tomorrow," she says. "Okay." She doesn't believe there'll be one. She goes anyway.
@next dw.talk

# dw4.lis
@focus lisette
lisette: Two hundred and forty-one going up. Fifty-two staying down. That's a better number than I expected. That's a much better number than Hamburg.
lisette: Do you want to know the best one? The hundred and six who came down not knowing. Ninety-one of them went up talking to someone. I counted.
* "Count yourself, Lisette."  -> dw4.lis1
* "Thank you for counting."  -> dw4.lis2

# dw4.lis1
lisette: Myself. One.
> She looks at you. She almost smiles. Then, very deliberately, she does, and it isn't almost at all.
lisette: One. That's enough. I'm going to stop counting for a while. I'm going to go upstairs and look at the painting and not count anything.
{do rel:lisette+2; comp+1}
@next dw.talk

# dw4.lis2
lisette: Somebody has to. Agnes Lark used to say that. About the Courthouse files. Somebody told me. I've forgotten who.
{do rel:lisette+1; sync+1}
@next dw.talk
`,'c_dawn4');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.fledglingSafe==='gideon')o.push(['A girl in a Gilded coat','Turned up at the Pawn & Coffin at a quarter to six on Saturday morning and asked for Gideon. He gave her box ten and a library card. She has read forty-one books since. She has not been to a party.']);
  else if(f.fledglingSafe==='union')o.push(['Local 0, member sixty-five','Joined at dawn on a Saturday, holding somebody else\'s thermos. Dues paid. Little Sal knitted her a hat.']);
  if(f.sootUpAgain)o.push(['The steps of the old cistern','In April, at four in the morning, a small grey figure came up them carrying a box of new candles. She sat on the top step for an hour, in the open air. She said it was for the candles.']);
  return o;});
