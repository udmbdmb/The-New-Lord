'use strict';
/* THE NEW LORD — "The Grey Card": telephone calls with Special Agent Harrow, one a night, from the payphone on Ferrier Lane; a negotiation, a confession, a man with a plant on a windowsill */
NL.Script.opt('phone.0','* Dial the number on the grey survey card.  -> hc.dial {if has:harrowcard&night>=2&night<=5&!flag:harrowDead&!flag:harrowArrested}','start');
NL.Script.add(String.raw`
# hc.dial
> Fifty cents. The coins drop with a sound like teeth. You dial the number off the card. It rings once.
@gate night:2 ? hc2.0 : hc.d3

# hc.d3
@gate night:3 ? hc3.0 : hc.d4

# hc.d4
@gate night:4 ? hc4.0 : hc5.0

// ---------------------------------------------------------------------
// NIGHT TWO · first contact
// ---------------------------------------------------------------------
# hc2.0
@gate flag:hcN2 ? hc.again : hc2.go

# hc2.go
{do flag:hcN2=1}
harrow: Department of Health, Community Blood Survey, Tom speaking. How can I help?
* Say nothing. Listen.  -> hc2.sil
* "It's me. Subject Eight."  -> hc2.eight {if flag:knowSubject8|flag:knowLantern}
* "I found your card on a friend of mine."  -> hc2.card

# hc2.sil
> You listen. You can hear him breathing, easy, unhurried. You can hear a television somewhere behind him: a quiz show. You can hear a kettle starting to boil.
harrow: ...Hello? Ah. I think I know who this is.
harrow: Take your time. I'm making a tea. Builders', two sugars. I picked up the habit in England. My colleagues think it's an affectation. They're right.
* Hang up.  -> hc2.hang
* "How do you know who this is?"  -> hc2.know

# hc2.know
harrow: Because nobody else calls this number at two in the morning and doesn't speak. The volunteers call to ask about their payments. The police call to ask why I'm not real. You're the only person in this city who'd call just to hear what I sound like.
harrow: It's fine. I'd do the same. I *did* do the same, as it happens. Your Sheriff had a number. I used to ring it and listen to him breathe. Well. He didn't breathe. Listen to him not breathing.
tenant: ...The silent calls. 1998. For a year. I thought it was a Rot with a crush.
@next hc2.hub

# hc2.eight
> A pause. The kettle clicks off behind him.
harrow: Well. Well, well. You've done some reading.
harrow: I prefer Casey, if I'm honest. Subject Eight sounds so clinical. But I'll call you whatever you like. It's your call. Literally.
@next hc2.hub

# hc2.card
harrow: Oh, that's my friend Leonard. Lovely lad. Terrible comedian. Tell him I said his Tuesday set was much better than last month. He'll know I was there.
pulse(5): He was at the Lantern Room. In the audience. He's been closer than you thought for longer than you thought.
@next hc2.hub

# hc2.hub
* "What do you want?"  -> hc2.want {once}
* "Stay away from my friends."  -> hc2.away {once}
* "Who were the seven?"  -> hc2.seven {once} {if flag:knowSeven|task:s_seven}
* "Why did you kill him?"  -> hc2.vane {once}
* Hang up.  -> hc2.hang

# hc2.want
harrow: Right now? A cookie. In general? The same thing I've wanted since 2004. For nobody else to find eleven people in a basement.
harrow: From you? A conversation. Once a night. That's all. You don't have to agree to anything. You don't have to tell me anything. Just pick up the phone and talk to me like a person.
harrow: Nobody talks to me like a person any more. It's an occupational hazard. Will you?
* "Maybe."  -> hc2.hub {do flag:hcMaybe=1}
* "No."  -> hc2.hub
* "Only if you talk to me like one."  -> hc2.deal {do lean:candour+1}

# hc2.deal
harrow: Deal. I'll never lie to you on this phone. I might not tell you things. But I won't lie. That's a promise. I'm told you set great store by those.
{do flag:hcDeal=1; mem:harrow:deal}
@next hc2.hub

# hc2.away
harrow: I'm not *near* your friends. I'm near the city. Your friends are just in it.
harrow: But all right. Noted. I'll ask my people to give the Rookery a wide berth. Not because you asked. Because it's polite. I'm a polite man.
{do flag:hcRookery=1}
@next hc2.hub

# hc2.seven
> The longest pause yet. The quiz show behind him is asking a woman from Swindon about the capital of Peru.
harrow: Seven volunteers. Ages twenty to fifty-one. Paid four hundred dollars a session. Fed. Housed for the duration. Signed forms.
harrow: I read their files every night. I know their shoe sizes. I know which one hated mushrooms. I'm not going to tell you their names on an open line. They deserve better than being shouted down a payphone.
@next hc2.hub

# hc2.vane
harrow: I didn't. I authorized. There's a difference, legally. Morally, no, there isn't, and I know that.
harrow: He was going to end the program. He had a file. He'd have walked it into the Prince's court and the Prince would have done what Princes do, and every one of my people in this city would have been in a canal by Saturday. My people have children.
harrow: I'm sorry he's dead. I am. He was magnificent, in his way. I'm not sorry I did it.
tenant: Magnificent. He calls me magnificent. Like a horse he shot.
@next hc2.hub

# hc2.hang
> You hang up. The payphone clicks. The coins don't come back.
@end

# hc.again
> It rings once. He picks up.
harrow: Again? Twice in one night. People will talk.
harrow: I'm afraid I've nothing more to say tonight. Try me tomorrow. Sleep well. Well, you know what I mean.
@end

// ---------------------------------------------------------------------
// NIGHT THREE · the plant
// ---------------------------------------------------------------------
# hc3.0
@gate flag:hcN3 ? hc.again : hc3.go

# hc3.go
{do flag:hcN3=1}
harrow: Tom speaking. Ah, it's you. I was hoping.
> There's no television tonight. Just a radiator ticking, and, very faintly, rain on a window.
harrow: I'm at the motel on Route 9. The Starlight. It has neither stars nor light, which I respect as a kind of honesty.
* "Why tell me where you are?"  -> hc3.where
* "Busy day?"  -> hc3.day
* "You were at St. Jude's tonight."  -> hc3.jude {if seen:hw3.0}

# hc3.where
harrow: Because you already know. Mother Soot's rats were in the parking lot at nine. Very well-behaved rats. One of them sat on my bonnet and watched me eat a sandwich.
harrow: I'm not hiding. I've never hidden. That's my one advantage over your kind. You hide. I stand in parking lots.
@next hc3.hub

# hc3.day
harrow: Long. I had to tell a colleague in Virginia that we lost another volunteer's family to a lawyer. And I had to tell myself, again, that Elena will pull the trigger on Friday. She always says she won't. She always does.
harrow: Do you ever get tired of being certain? I do. I'm so tired of it.
pulse(5): You can't hear his heart over the phone. You can hear something better: the little catch in the breath before a man says something true.
@next hc3.hub

# hc3.jude
harrow: I was. With *Country Life*. You sat next to me. That was nice. People don't sit next to me.
@next hc3.hub

# hc3.hub
* "Tell me about the plant on your windowsill."  -> hc3.plant {once} {if mem:harrow:home|seen:hw4.home}
* "Tell me about your wife."  -> hc3.wife {once}
* "Why Rostova?"  -> hc3.ros {once}
* "What happens on Friday?"  -> hc3.fri {once}
* "What would make you stop?"  -> hc3.stop {once}
* Hang up.  -> hc3.bye

# hc3.plant
harrow: The plant. You remember that. Nobody remembers that.
harrow: It's a spider plant. My mother's. Well, a cutting of a cutting of my mother's. She had it in the kitchen in the servants' wing in Virginia, on the windowsill above the sink. When she died I took a cutting. When I went to Iraq I gave it to a colleague. When I came back I took a cutting from his.
harrow: There have been about nine of them now. Nine generations. I've never been home long enough to keep one alive myself. Somebody always waters it for me.
* "Maybe you should go home and water it."  -> hc3.plantgo
* "That's the saddest thing I've ever heard."  -> hc3.plantsad

# hc3.plantgo
harrow: Maybe. After Friday.
harrow: ...That's what I said after Fallujah. After Kandahar. After my divorce. After my mother. "After this."
harrow: There's always another this.
{do mem:harrow:plant; flag:hcPlant=1}
@next hc3.hub

# hc3.plantsad
harrow: Is it? You've had a sad week. That's high praise.
{do mem:harrow:plant; flag:hcPlant=1}
@next hc3.hub

# hc3.wife
harrow: Carol. A pediatric nurse. We met in Germany at a field hospital. She left in 2009. She said I'd come back from the war with a hole in me and I'd filled it with work. She said she'd rather be alone than married to a project.
harrow: She was right. She remarried. A dentist. They have a boat. I send a card at Christmas. She sends one back. They have a dog called Biscuit.
@next hc3.hub

# hc3.ros
harrow: Because she's the best. Because she was so close, on her own, with nothing. Because she lost her father to one of you in Petersburg in 1993, when she was twelve, and she's never stopped trying to understand what took him.
harrow: And because she hates me. Which is useful. People who hate you never stop working. They want to prove you wrong.
@next hc3.hub

# hc3.fri
harrow: You know what happens on Friday. You've been asking everyone. The lamps. The platform. The Court, all in one place, for once.
harrow: I'll be honest, since we agreed to be: I would rather you weren't there. You're the most important thing that's happened to my work in twenty years. Burning you would be like burning the Dead Sea Scrolls to keep warm.
* "Then call it off."  -> hc3.off
* "Then I'll make sure you can't."  -> hc3.cant

# hc3.off
harrow: I can't. The Court's going to vote to burn you anyway, and when they do, every Kindred on that platform will have seen a diablerist go free or go to the pyre. Either way the Ward goes to war. Either way more basements.
harrow: The lamps end it. One morning. Clean. I don't like it. I'm not supposed to like it.
@next hc3.hub

# hc3.cant
harrow: You'll try. I hope you do. I mean that. It would be interesting.
@next hc3.hub

# hc3.stop
> He doesn't answer for so long that you think the line's gone dead.
harrow: ...If someone showed me there was another way. One that didn't end in a basement. I've looked for twenty years. I haven't found one.
harrow: If you find one, you have my number.
{do flag:hcAnotherWay=1}
@next hc3.hub

# hc3.bye
harrow: Goodnight. Mind the floodlight at the crossing. It's on a forty-second sweep. I'd hate for you to get caught by accident.
@end

// ---------------------------------------------------------------------
// NIGHT FOUR · the offer
// ---------------------------------------------------------------------
# hc4.0
@gate flag:hcN4 ? hc.again : hc4.go

# hc4.go
{do flag:hcN4=1}
harrow: Tom speaking.
> His voice is different tonight. Tighter. There are other voices in the room with him, low, professional. Someone says "range test at four".
harrow: Give me a moment. ...Gentlemen, could I have the room? Thank you.
> A door closes.
harrow: Sorry. Busy night. We're doing final checks. You know that. I'm not telling you anything you don't know.
* "I've found your other way."  -> hc4.way {if flag:hcAnotherWay}
* "Make me an offer."  -> hc4.offer
* "Who's in the room with you?"  -> hc4.room
* "I'm going to kill you, Tom."  -> hc4.kill

# hc4.room
harrow: Six specialists. Two from the Army, one from the Navy, three from a company in Arizona whose name I'm not allowed to say. Good people. Most of them have children. One of them has a terrible singing voice; he does karaoke on Thursdays.
harrow: If anything happens to them on Friday it'll be because I put them there. I'd like you to know that if you do anything to them, it's me you're doing it to.
@next hc4.hub

# hc4.kill
harrow: Are you? Good. Honest. Thank you.
harrow: I've been told I'm going to be killed by a lot of things. Insurgents. Kindred. Carol's lawyer. My doctor, about the menthols. None of them have managed it yet. I'm a very lucky man, and lucky men are the most dangerous kind, because we start believing in it.
{do lean:candour+1}
@next hc4.hub

# hc4.offer
harrow: An offer. All right. My final offer, since it's Thursday.
harrow: Come in. Tonight. Walk out to the van on Ferrier Lane before midnight with your hands where my people can see them. In return: the lamps stay dark on Friday. The Court has its Tribunal without you, finds you absent, declares a Blood Hunt, and nobody can find you because you're in Virginia with a spider plant.
harrow: Nobody on the platform burns. Nobody. Not Séverine, not the old woman with the rats, not the Hound. I call off the whole thing. I'll take you instead of them.
web(8): He's not lying. He's offering to trade a massacre for one prisoner. And the prisoner is you.
tenant: Child. Don't. He'll take me out of you with a needle and a centrifuge and I will scream for a hundred years in a jar in Virginia.
* "Swear it. No lamps. Nobody burns."  -> hc4.swear
* "No."  -> hc4.no
* "I'll think about it."  -> hc4.think

# hc4.swear
harrow: I swear it. On Carol, on the plant, on my mother. If you walk to the van before midnight, the lamps never fire.
* "Then I'm coming in."  -> hc4.surrender
* "...I needed to hear you say it. The answer's still no."  -> hc4.no

# hc4.surrender
> There is a silence on the line, very long.
harrow: ...Thank you. I didn't think you would. I didn't think anyone ever would.
harrow: Before midnight. The van. Hands visible. Don't be afraid. You'll be the best-looked-after thing in the whole program.
{do flag:hcSurrender=1; promise:harrowvan:Walk to Harrow's van before midnight; lean:mercy+2}
tenant: You fool. You beautiful, stupid, merciful fool.
@end

# hc4.think
harrow: Think. Midnight. The van will be there. So will I.
{do flag:hcThink=1}
@end

# hc4.no
harrow: No. I thought not. I'd have said no too. Well. I'd like to think I would.
@next hc4.hub

# hc4.way
harrow: You've... what?
* Tell him: daywalking with consent. Vane's own blood, given freely, studied openly.  -> hc4.waycons {if flag:chord|flag:seizure=surrender}
* Tell him: the Court registers itself. Séverine's census, given to a mortal, not taken.  -> hc4.waycens {if flag:knowCensus|seen:sx3.0}
* Tell him: the seven's families, the papers, the truth. Shut it down and confess.  -> hc4.waytruth {if task:s_seven}
* Tell him you were bluffing.  -> hc4.bluff

# hc4.waycons
harrow: Consent. A Sheriff's blood, given. Not stolen from a freezer.
tenant: I'd give it. Tell him. In a clean room, with Elena, with the door open. A little, every Tuesday. For the cure he wants. If he kills nobody, I'll give it.
> You tell him. You tell him in Vane's words, because they're the only ones that fit.
harrow: ...He'd do that. Absalom Vane would do that. After what I did to him.
harrow: I need to sit down. I'm sitting down.
? velvet 12 "Call off Friday, Tom. Go home and water the plant."  -> hc4.wayok | hc4.wayno {id hc_way} {mod like:harrow}

# hc4.waycens
harrow: A voluntary register. The Court counts itself, and hands the count to someone it trusts. No curfews. No lamps. Just... knowing who's there.
harrow: That's what I've wanted all along. I just never thought they'd do it without a gun to their heads.
? velvet 13 "They will if I make them. Give me Friday to make them."  -> hc4.wayok | hc4.wayno {id hc_way} {mod like:harrow}

# hc4.waytruth
harrow: Confess. Shut down the program, and stand in a room with seven families and tell them what I did.
harrow: ...They'd crucify me. They'd be right to.
? velvet 13 "That's the other way, Tom. It's the only one that doesn't end in a basement."  -> hc4.wayok | hc4.wayno {id hc_way} {mod like:harrow}

# hc4.wayok
> On the other end of the line you hear a man sit very still for a long time. Somewhere behind him, a door opens, and somebody says "Sir? Range test?" and he says "Not now, Danny," in a voice like an old coat.
harrow: I can't call it off. Not by myself. Not this late. There are people above me who've spent forty million dollars on Friday.
harrow: But I can make sure the lamps are on a manual switch. Mine. Not the van's. And I can promise you that when the moment comes, I'll have my thumb on it, and I'll think about you, and about the plant.
harrow: That's all I've got. It's more than I've ever given anybody.
{do flag:harrowWavers=1; xp:60:Another way; rel:harrow+2; mem:harrow:anotherway}
@next hc4.hub

# hc4.wayno
harrow: It's a beautiful idea. It's the kind of idea I had in 2004. Before the basement.
harrow: I'm sorry. I really am. See you on Friday.
@next hc4.hub

# hc4.bluff
harrow: Of course you were. That's all right. I'd have bluffed too.
@next hc4.hub

# hc4.hub
* "Why did you really start all this?"  -> hc4.start {once}
* "Is there anything you'd like me to tell anyone? After?"  -> hc4.after {once}
* Hang up.  -> hc4.bye

# hc4.start
harrow: The basement. You know about the basement.
harrow: ...No. That's what I tell people. That's the story. The truth is that when the man in the basement laughed and thanked me, I wasn't afraid. I was *jealous*. Eleven dead and I stood there with an empty magazine and I wanted to be him. I wanted to never be tired again.
harrow: I've spent twenty years trying to make sure nobody can be him. And trying to find out how I could be. I've never been able to tell which.
{do mem:harrow:jealous; flag:hcJealous=1}
@next hc4.hub

# hc4.after
harrow: After. If it goes badly for me.
harrow: Tell Carol I'm sorry about the boat. She'll know. And water the plant. The windowsill in Virginia, the lab at Langley, third floor, Danny Reyes has a key. Tell him a cupful every Sunday.
{do flag:hcPlantTask=1}
@next hc4.hub

# hc4.bye
harrow: Goodnight. I'll see you on the platform. Wear something warm. It's going to be a bright night.
@end

// ---------------------------------------------------------------------
// NIGHT FIVE · before the platform
// ---------------------------------------------------------------------
# hc5.0
@gate flag:hcN5 ? hc.again : hc5.go

# hc5.go
{do flag:hcN5=1}
@gate time>=235 ? hc5.late : hc5.early

# hc5.late
> It rings and rings. Nobody picks up. You can hear, faintly, through the street above you and the earpiece both: an engine idling, a megaphone being tested. *One two. One two.*
@end

# hc5.early
harrow: Tom.
> No television. No radiator. Wind. He's outside. A car door. Someone offering him a coffee and him saying no thank you.
harrow: Hello. Last call. I'm on Ferrier Lane. I can see your payphone from here, as it happens. No, don't look. Don't look. I'm in the van with the tinted windows. It's very comfortable.
@gate flag:hcSurrender ? hc5.surr : hc5.hub

# hc5.surr
harrow: You didn't come. Last night. I sat in the van until four. I ate a whole packet of peppermints.
harrow: I'm not angry. I'm not even surprised. I just wanted to say: I'd have kept my end. I want you to know I'd have kept it.
{do break:harrowvan; unflag:hcSurrender}
@next hc5.hub

# hc5.hub
* "Last chance, Tom. Walk away."  -> hc5.walk {once}
* "Is your thumb on the switch?"  -> hc5.thumb {once} {if flag:harrowWavers}
* "Thank you. For talking to me like a person."  -> hc5.thanks {once}
* "See you on the platform."  -> hc5.bye

# hc5.walk
harrow: Walk away. Leave the van. Leave forty million dollars and six specialists and twenty years.
harrow: Do you know, I've thought about it every night this week? Driving to the airport. Getting a flight. Turning up at Carol's with a spider plant.
harrow: She'd say: "Tom, you look terrible." And she'd be right.
? velvet 14 "Then go. Tonight. Be the man who left."  -> hc5.walkok | hc5.walkno {id hc_walk} {mod like:harrow}

# hc5.walkok
> The wind on the line. A long, long breath.
harrow: ...Danny. Danny, are you there? The lamps are yours. Manual only. Nobody fires them without the Magistrate on the platform giving you a reason. I'm going to get a coffee.
harrow: I'm going to get a coffee. And I'm going to keep walking, I think. Down to the beltway. I've never seen the beltway at night. I bet it's ugly.
> The line goes dead. Through the brick above you, on Ferrier Lane, a car door opens and shuts. Footsteps, walking away. Not hurrying.
{do flag:harrowWalked=1; flag:harrowFled=1; xp:100:Tom walks away; mem:harrow:walked}
@end

# hc5.walkno
harrow: I'd like to. I really would. I'm not the man who leaves. I've been trying to be him for fifteen years and I just keep turning up.
@next hc5.hub

# hc5.thumb
harrow: It's on the switch. Mine. Not the van's. I've told Danny if I don't say "go", nobody goes.
harrow: I haven't decided. I want you to know that. I've decided everything else in my life four moves ahead. I haven't decided this.
{do flag:harrowThumb=1}
@next hc5.hub

# hc5.thanks
> He laughs. It's the first time you've heard him laugh, a real one, surprised out of him.
harrow: You're thanking me. The man who's going to try to burn you at one o'clock.
harrow: You're welcome. You're welcome. Thank you for picking up. It's been the best part of my week. Isn't that pathetic?
{do rel:harrow+1; mem:harrow:thanks}
@next hc5.hub

# hc5.bye
harrow: See you on the platform. Good luck. I mean it, in the most complicated possible way.
@end
`,'c_harrow');

/* consequences: the surrender, the thumb, and the walk */
(function(){const S_=NL.Script;
/* if you promised to walk to the van, a toast reminds you at 23:00 */
S_.on('hcvanremind',{if:'night:4&flag:hcSurrender&time>=120'},'text:Unknown|The van is on Ferrier Lane. Hands where we can see them. Midnight. — T.');
/* the walk to the van itself, at the alley, Night 4, before midnight */
NL.Script.npc({id:'harrow',room:'alley',at:[2.0,1.6,0.9],pose:'arms',label:'Agent Harrow',if:'night:4&flag:hcSurrender&time<150&!flag:harrowDead',node:'hcV.0'});
})();
NL.Script.add(String.raw`
# hcV.0
@focus harrow
> The grey van. Its side door open. Inside, a clean steel bench, straps, a drip stand, a small fridge with a sticker on it that says *PROPERTY OF U.S. GOV.* Harrow is standing beside it in his brown coat, holding the door for you like a chauffeur.
harrow: You came. You actually came.
> Behind him, two men in black with rifles that don't look like rifles. Their safeties are on. Their hands are shaking.
* Get in the van.  -> hcV.in
* "I wanted to see your face when I said no."  -> hcV.no
* Take his throat, here, now, while the lamps are pointed at the sky.  -> hcV.throat {blood}

# hcV.in
tenant: Child. Please.
> You step up into the van. It smells of antiseptic and peppermint. The bench is cold. Harrow climbs in after you and sits opposite, with his knees almost touching yours, and pulls the door shut himself.
harrow: Thank you. I mean that. I'll keep every word.
> The van pulls away from Ferrier Lane. Through the tinted window you see the Lucky Mart go past, and Tariq's light, and then the river, and then the beltway, which is ugly.
{do keep:harrowvan; flag:wentInVan=1; flag:endingVan=1}
@next hcV.road

# hcV.road
> At a service station on the interstate, at five in the morning, he buys you a blanket and himself a coffee and stands outside the van in the cold while the sky goes grey, so the light won't come through the open door.
harrow: You'll sleep the whole way. Virginia's nineteen hours. When you wake up, there'll be a room. Books. A window that's not a window.
harrow: I'll bring the plant.
> You sleep. The Tenant doesn't. All the way down the interstate, all through the long grey day, you hear him in your dream, very quietly, singing in Corsican to keep himself company.
{do flag:vanEnding=1}
@next end.van

# hcV.no
harrow: ...Ah.
> He looks at you for a long moment. Then he nods, and closes the van door himself, softly, like a man closing a door on a sleeping child.
harrow: I'd have done the same. Well. I'd like to think so.
{do break:harrowvan; unflag:hcSurrender; flag:hcRefusedAtVan=1}
@leave harrow

# hcV.throat
> You're on him before the men with the not-rifles can lift them. Brown coat, menthol, peppermint, and under it, a man's heart, very steady, even now.
> He doesn't struggle. He puts one hand on the back of your head, almost gently, the way you'd hold a child who'd fallen.
harrow: ...There it is. There. That's what I was jealous of.
* Drink until he's gone.  -> hcV.drink
* Stop. Let the soldiers see you stop.  -> hcV.stop {do lean:restraint+1}

# hcV.drink
> You drink until he's gone. It takes a long time; he's a big man, and steady. The soldiers don't fire. They stand there with their safeties on and watch, and one of them is crying.
> When it's done, you lay him on the steel bench in the van that was meant for you. His coat falls open. In the inside pocket: a Christmas card from someone called Carol, and a cutting of a spider plant in a twist of wet newspaper.
{do kill; flag:harrowDead=1; flag:harrowDeadEarly=1; break:harrowvan; unflag:hcSurrender; feed:5:Melancholic:Thomas Harrow:mortal; lean:mercy-2; heat+2}
tenant: He wanted to be us. Now he is, in a way. A little of him, in you, with me. God help us all.
@leave harrow

# hcV.stop
> You stop. You step back. There's blood on his collar. He's alive, swaying, holding the van door.
> The soldiers are staring at you. Not at their target. At you. At a thing that stopped.
harrow: ...You stopped.
harrow: Danny. Danny, put that down. Put it down. Go home, all of you. Go home.
{do break:harrowvan; unflag:hcSurrender; flag:harrowWavers=1; flag:harrowBitten=1; feed:2:Melancholic:Thomas Harrow:mortal; rel:harrow+2}
@leave harrow
`,'c_harrow2');

/* the van ending */
(function(){const N=NL.DSL.N;
NL.ENDINGS.van={t:'Subject Eight',k:'Ending · The van on Ferrier Lane',lines:[],epi:S=>[
  'You live in a room in Virginia with a window that isn\'t a window. On the sill there is a spider plant, the tenth generation, and every Sunday Tom Harrow comes in and waters it himself, a cupful, and sits for a while, and talks to you like a person.',
  'On Friday night the Tribunal met on Platform 0 without its defendant, and found you absent, and declared a Blood Hunt on a thing nobody could find. The lamps never fired. Nobody on the platform burned.',
  S.flags.side_union||S.flags.tinyFriday?'Somebody on the Ward still leaves a coffee on the counter of the Lucky Mart at five every morning. Somebody still saves you a seat on Platform 0.':'The Marrow Ward got a new Sheriff in the spring. Nobody you know.',
  'Every Tuesday, under anaesthetic, they take a little of Absalom Vane out of you. Every Wednesday he grows back. He still sings, very quietly, in Corsican. Nobody in Virginia knows what the words mean. You do.']};
N['end.van']={lines:[],next:'end.show.van'};
N['end.show.van']={cs:async()=>{await NL.Act.showEnding('van');},end:true};
})();
/* Night 5: the thumb on the switch. If Harrow wavers, the lamps can fail at the moment of firing */
(function(){const N=NL.STORY&&NL.STORY.nodes||NL.DSL.N;const {L,T}=NL.DSL;
document.addEventListener('DOMContentLoaded',()=>{const n=N['lamps.0'];if(!n||!n.lines)return;
  const gone=S=>S.flags.harrowWalked||S.flags.harrowDeadEarly;
  const held=S=>S.flags.harrowThumb&&!gone(S)&&((S.rel.harrow||0)>=3||S.flags.harrowBitten);
  if(n.lines[1])n.lines[1].if=S=>!gone(S);
  if(n.lines[2])n.lines[2].if=S=>!gone(S)&&!held(S);
  n.lines.push(T('Under every grate, a quartz lamp begins to whine. And then, from the street, very faintly, a voice you know, not through a megaphone: "Danny. Not yet. Not yet." A long pause. "...Not at all. Stand down. Stand everybody down."',{if:held,do:S=>{S.flags.harrowHeld=1;}}));
  n.lines.push(T('From the street, very faintly, a voice you know, not through a megaphone: "Danny. Not yet. Not yet." And then, after a long time, quietly: "...Go."',{if:S=>S.flags.harrowThumb&&!gone(S)&&!held(S)}));
  n.lines.push(T('There is no megaphone. Nobody on the street says anything at all. Up on Ferrier Lane, three grey vans sit with their engines off and their drivers smoking, waiting for an order from a man who went for a coffee on the beltway and never came back.',{if:S=>S.flags.harrowWalked}));
  n.lines.push(T('There is no megaphone. The man who would have held it is in a steel bench in a grey van on Ferrier Lane, under a sheet, and nobody on the street knows who is supposed to give the order now. The vans sit with their engines running. Nobody presses anything.',{if:S=>S.flags.harrowDeadEarly&&!S.flags.harrowWalked}));
  const d=N['lamps.dead'];if(d&&d.opts&&d.opts[1]){const f0=d.opts[1].if;d.opts[1].if=S=>!gone(S)&&(!f0||f0(S));}
  const nx=n.next;n.next=S=>(gone(S)||held(S))?'lamps.dead':(typeof nx==='function'?nx(S):nx);
});
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.harrowWalked)o.push(['Thomas Harrow','Was last seen on the beltway at 2 AM on Friday, walking north with a coffee. A month later a woman called Carol in Maryland found a spider plant on her porch in a twist of wet newspaper with no note. She knew.']);
  else if(f.harrowBitten&&!f.harrowDead)o.push(['Thomas Harrow','Has two small scars on his neck that he touches when he\'s thinking. Doesn\'t sleep much. Resigned from the program in December. Wrote a report nobody will ever read, which ends: "It stopped."']);
  if(f.hcPlantTask&&f.harrowDead)o.push(['Danny Reyes','Got a letter in a hand he didn\'t recognize, posted from a city he\'d never been to: "A cupful every Sunday. He asked me to tell you." He still does it. The plant is the tenth generation. It\'s thriving.']);
  return o;});
})();
