'use strict';
/* THE NEW LORD — alternative dawn dreams, chosen by what you did that night */
NL.Script.add(String.raw`
// =====================================================================
// NIGHT TWO · if you drank Leo
// =====================================================================
# drL.0 dream=2 if=leo:dead prio=9
> The study, but there's someone else in it. In the visitor's chair, where you usually sit, a young man in a Florida-stained shirt with a cactus on his knees, looking around with polite interest.
leo: Oh hey. Hi. Is this... is this where you live? It's nice. It's very brown. Is that a real Bokhara?
tenant: He came in an hour ago. He's been asking about the rug.
leo: I don't remember how I got here. I remember Room 3B and you, and then it was really quiet, and then I was here. Is this heaven? It's very brown for heaven.
* "I'm sorry, Leo."  -> drL.sorry
* "It's not heaven. It's me."  -> drL.me
* Say nothing.  -> drL.nothing

# drL.sorry
leo: Sorry? For what? Oh. Oh. Right. The... yeah.
leo: It's okay. It didn't hurt. That's the weird thing. I thought it would hurt.
> He looks down at Gerald.
leo: Can I stay here? Is that allowed? I don't want to go down the corridor. There's people down the corridor. They're very sad.
tenant: He can stay in the study. I'll find him a chair. God knows I've room.
{do mem:tenant:leostays; comp-3:Leo}
@next drL.end

# drL.me
leo: You. Inside you. Like... like a tapeworm. A tapeworm with a cactus.
leo: That's going in the act. I don't have an act any more. That's going in the act anyway.
{do comp-2:Leo}
@next drL.end

# drL.nothing
> He looks at you for a long time. Then he puts Gerald on the desk, carefully, and sits back in the chair.
leo: Yeah. Me neither. Nothing to say. That's new for me.
{do comp-2:Leo}
@next drL.end

# drL.end
> The study goes soft. The last thing you see is Leo trying to get the Tenant to laugh at a joke about landlords, and the Tenant, very slightly, failing not to.
@end

// =====================================================================
// NIGHT THREE · if you killed Valko
// =====================================================================
# drV.0 dream=3 if=flag:valkoDead prio=9
> The study. On the Bokhara rug in front of the cold fireplace, curled up like a dog, a huge grey shape with amber eyes. It lifts its head when you come in. Valko. Not the man. The Beast in him, all fur and patience.
tenant: He came in an hour ago. He went straight to the rug. He always slept on that rug, in 1952, when he was new and couldn't sleep in a bed.
tenant: I haven't been able to make him speak. He just watches the door. He's waiting for someone to come through it and tell him what to do.
* Kneel by him. Put your hand on his head.  -> drV.hand {do lean:mercy+1}
* "Good dog."  -> drV.good
* "Mr. Valko."  -> drV.mister

# drV.hand
> His fur is cold and coarse. He doesn't move. Then, very slowly, he puts his great grey head down on his paws and closes his eyes.
tenant: He's resting. I've never seen him rest. Seventy years.
{do sync+3:The rug}
@next drV.end

# drV.good
> He looks at you with those amber eyes, and you can see him decide, slowly, that you're not his master, and you never were, and that he doesn't mind.
{do sync+2}
@next drV.end

# drV.mister
> At *Mister*, his ears go up. He looks at you. Then he looks at the Tenant, at the desk, and something in his huge grey face falls apart, very quietly, the way a sandcastle goes when the tide arrives.
tenant: ...I'm sorry, Mr. Valko. I'm sorry. I'm so sorry.
{do sync+4:Mister}
@next drV.end

# drV.end
> In the corridor beyond the study door, a hundred voices. On the rug, one Hound, finally asleep.
@end

// =====================================================================
// NIGHT THREE · the quiet one (no kills, Suppress)
// =====================================================================
# drQ.0 dream=3 if=kills=0&flag:seizure=suppress prio=8
> Not the study. Somewhere you've never been: a white beach in the morning, sun on wet sand, gulls, a wind off the sea that smells of salt and seaweed and nothing else. No blood in it at all.
> You're standing at the edge of the water. It's daytime. It doesn't hurt.
nostalgia: Bayside. A beach on the coast. You were here as a child. You built a sandcastle and someone helped you dig the moat.
> Far down the beach, a figure walking toward you. It's too far to see a face. It waves.
* Wave back.  -> drQ.wave
* Walk toward it.  -> drQ.walk
* Look for the Tenant.  -> drQ.tenant

# drQ.wave
> It waves again, bigger, delighted, the way you wave at someone you've been waiting for at a station. Then the tide comes in over your feet, warm, and you wake.
{do flag:dreamBeach=1; comp+3:The beach}
@end

# drQ.walk
> You walk. It walks. You get closer, and closer, and just before you can see its face, the sun gets very bright, and warm, and it's only warm, and you wake.
{do flag:dreamBeach=1; comp+3:The beach}
@end

# drQ.tenant
tenant: (from very far away, a voice in the wind) I'm here. I can't come any closer. This isn't my place. This is yours. It's the first dream you've had that I'm not in.
tenant: Enjoy it, Casey. I've never seen a beach in daylight. Tell me what it's like.
> You tell him. It takes the rest of the day.
{do flag:dreamBeach=1; comp+3:The beach; mem:tenant:beach}
@end

// =====================================================================
// NIGHT FOUR · if Pemberton is gone
// =====================================================================
# drP.0 dream=4 if=flag:pemDead|flag:lastCallDone=sunrise prio=9
> The study. The car is parked inside it, somehow, a black 1960s Bentley nosed up against the bookcase with its engine idling, its headlights on the rug. The driver's door is open. The seat is empty.
tenant: He's not here. I looked. He didn't come into the corridor like the others. Pemberton always did know where he wasn't wanted.
tenant: I think he's somewhere better. I think he went where ghouls go when there's no more blood: somewhere very ordinary, with a garden, and rain.
* Sit in the driver's seat.  -> drP.seat
* Turn off the engine.  -> drP.engine
* "Did you ever thank him?"  -> drP.thank

# drP.seat
> The seat knows the shape of a man who sat very straight for forty-one years. The rear-view mirror is angled for someone who wasn't there.
> On the dashboard, a note in a careful hand: *Gas on the Court's account. Tyres done in September. The heater's temperamental. Look after yourself, sir. P.*
{do comp+2:Pemberton; sync+2}
@next drP.end

# drP.engine
> You turn the key. The engine stops. The headlights go out. It's very quiet in the study.
tenant: Thank you. I couldn't bear it running. It sounded like waiting.
@next drP.end

# drP.thank
tenant: Once. 1977. "Thank you, Pemberton." On the dock, with his blood on my cuffs. He said, "Your cuff's ruined, sir." I laughed so hard I nearly lost him.
tenant: That's the only time. Forty-one years. Once.
{do sync+2}
@next drP.end

# drP.end
@end

// =====================================================================
// NIGHT FOUR · if Leo became Séverine's
// =====================================================================
# drC.0 dream=4 if=flag:leoCourt prio=8
> The study. On the desk, where the photograph of Agnes usually lies face down, a new photograph, face up. Leo, in Séverine's chapel, among the monks, smiling, eating a sandwich, very happy. Too happy.
tenant: She's got him. You let her. Or you couldn't stop her. It doesn't matter which, now.
tenant: He'll be fine. That's the terrible thing about the Court. Everyone they take is *fine*. They just never quite stop smiling.
* "I'll get him back tomorrow."  -> drC.back {do promise:leoback:Get Leo back from Séverine on Friday}
* "He's safer there than anywhere."  -> drC.safer

# drC.back
tenant: Tomorrow's Friday. You'll be busy. But yes. Try. She'll want something for him. She always wants something.
@end

# drC.safer
tenant: Safer. Yes. Like a canary in a very nice cage is safer.
@end

// =====================================================================
// NIGHT TWO · the hungry dream (if you went to sleep hungry)
// =====================================================================
# drH.0 dream=2 if=vitae<=2 prio=7
> No study. No desk. Just a corridor, very long, very dark, lined with doors, and behind every door a heartbeat. Some fast, some slow, some very, very slow, like old people asleep.
frenzy: Open one. Open ANY one. You're so hungry. Nobody would ever know.
tenant: (from somewhere far behind you) Casey. Don't. Come back to the study. Come back and sit with me.
* Open a door.  -> drH.open {do lean:restraint-1}
* Turn back toward his voice.  -> drH.back {do lean:restraint+1}

# drH.open
> Behind the door, a room just like Leo's, with a cactus on the windowsill and someone asleep on the couch. You stand over them for a long time in the dream, so hungry you're shaking.
> You wake up on your last drops with blood in your mouth that isn't real and a taste you can't spit out.
{do comp-2:The corridor}
@end

# drH.back
> You walk back down the corridor toward his voice. It's a long way. Every door you pass, a heartbeat calls you by your name. You don't stop.
> When you get to the study he's standing in the doorway, holding it open.
tenant: Good. Good. Sleep. You'll wake hungry. Feed on someone who wants it. There's always someone who wants it.
{do comp+1:The study}
@end
`,'c_dreams');
