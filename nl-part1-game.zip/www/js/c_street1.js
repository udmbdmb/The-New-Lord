'use strict';
/* THE NEW LORD — street events, part one: things that happen on the way */
(function(){const X=NL.EXTRAS;const P=(n,role,skin,hair,shirt,coat,o)=>Object.assign({n,role,color:'#c8c0b0',spec:Object.assign({skin,hair:{style:hair[0],color:hair[1]},shirt,coat:coat?{color:coat,length:.5,collar:true}:null},o||{})});
Object.assign(X,{
  mugger:P('A kid with a knife','Halloran Street',[.78,.6,.5],['crop',[.1,.08,.06]],[.2,.22,.3],[.15,.15,.18]),
  victim:P('A man in a suit','Halloran Street',[.88,.76,.7],['slick',[.3,.22,.16]],[.85,.85,.88],[.2,.2,.25]),
  huntress:P('A woman in a fur stole','The Gilded Court',[.92,.84,.82],['long',[.75,.55,.25]],[.15,.05,.1],[.6,.5,.4],{eyeGlow:[.35,.05,.05]}),
  girl:P('A girl in a pink coat','Lost',[.86,.7,.6],['long',[.35,.2,.1]],[.9,.5,.6],[.9,.45,.55],{height:.7}),
  preacher:P('The Preacher of Vine Street','A milk crate and a megaphone',[.5,.36,.3],['crop',[.7,.7,.7]],[.15,.15,.15],[.1,.1,.12]),
  ghoulbeg:P('An old man in a good suit','Somebody\'s ghoul, once',[.84,.76,.72],['fringe',[.9,.9,.9]],[.8,.78,.72],[.25,.22,.2]),
  busker:P('A busker with a violin','Reliquary Row',[.82,.66,.56],['curly',[.4,.25,.12]],[.5,.3,.2],[.3,.2,.15]),
  nurse2:P('A nurse on her break','St. Jude\'s',[.66,.5,.4],['bun',[.1,.08,.06]],[.5,.7,.8],null),
  drunk2:P('A very drunk man','The Anchor\'s finest',[.9,.66,.6],['shaved',[.6,.5,.4]],[.6,.2,.2],[.3,.25,.2]),
  courtboy:P('A Court boy','The Gilded Court',[.92,.86,.84],['slick',[.85,.75,.5]],[.9,.88,.85],[.1,.05,.08],{eyeGlow:[.3,.05,.05]}),
  lanterntech:P('A man in grey overalls','LANTERN',[.8,.66,.58],['shaved',[.3,.25,.2]],[.4,.42,.4],[.35,.38,.35],{glasses:{type:'aviator'}}),
  michelle:P('Michelle Danes','A blue coat, Superkings',[.86,.72,.64],['long',[.5,.3,.15]],[.3,.3,.5],[.2,.3,.6]),
  widow:P('An old woman with a dog','Halloran Street',[.86,.78,.74],['bun',[.85,.85,.85]],[.5,.3,.4],[.4,.25,.3],{height:.88})
});})();
NL.Script.add(String.raw`
// =====================================================================
// A KNIFE ON HALLORAN STREET
// =====================================================================
# ev.mug street=2,3,4
> A shortcut down an alley off Halloran Street. Ahead, under a broken lamp: a boy of sixteen with a kitchen knife, and a man in a suit with his hands up and his wallet out, saying "take it, take it" in the voice of someone who has always been told he'd never be the one this happened to.
mugger: Phone. PHONE. And the watch. Come on.
pulse(4): The boy's heart is going like a sewing machine. He's more scared than the man is. The knife's shaking.
frenzy: Two of them. One alley. Nobody watching. You could have BOTH.
* Step into the light. Let the boy see your eyes.  -> ev.mug1 {do lean:mercy+0}
* Take the knife off him. Quietly.  -> ev.mug2
* Walk on. Not your business.  -> ev.mug3 {do lean:mercy-1}
* Feed on the boy. He's a thief.  -> ev.mug4 {do lean:restraint-2}

# ev.mug1
> You step into the lamp's circle and let him see. Just the eyes.
> The knife hits the cobbles. He's gone so fast he leaves a shoe behind. The man in the suit looks at you, and at the shoe, and at you.
victim: Thank you. Thank you. Are you... is that a contact lens thing?
* "Yes."  -> ev.mug1a
* "Go home."  -> ev.mug1b

# ev.mug1a
victim: They're very good. Very... very good.
> He leaves. He'll tell the story at work tomorrow. Nobody will believe him. It'll get better every time.
{do heat+0; xp:10}
@end

# ev.mug1b
> He goes home. He'll never take a shortcut again.
{do xp:10}
@end

# ev.mug2
> You walk up behind the boy and take the knife out of his hand the way you'd take a pen off a desk. He spins. You're closer than he expected. You're always closer than they expect.
mugger: Give it back. Give it BACK. It's my mom's.
? velvet 8 "Your mom's knife. Your mom's kitchen. Go home and put it back before she notices."  -> ev.mug2a | ev.mug2b {id ev_mug}

# ev.mug2a
> He stares at you. Then something in him gives way, the bravado or the fear or both, and he's just a sixteen-year-old in an alley at one in the morning.
mugger: ...She'll kill me.
> He goes. You put the knife in a drain. The man in the suit has already gone without saying thank you.
{do lean:mercy+1; xp:15}
@end

# ev.mug2b
> He runs. You keep the knife. You'll find it in your coat pocket on Saturday and not know what to do with it.
{do xp:5}
@end

# ev.mug3
> You walk on. Behind you, a scuffle, a shout, and then running feet. You don't look back to see who's running.
tenant: The Sheriff of the Marrow Ward would have stopped that. Not out of kindness. Out of territory. Thieves on his street were a personal insult.
@end

# ev.mug4
> He doesn't even see you. One moment he's shouting about a watch, the next he's on his back on the wet cobbles with your teeth in his neck and his mother's knife spinning away into the dark.
> The man in the suit watches the whole thing. Then he throws up, and runs.
? rigor 9 Stop before he goes still.  -> ev.mug4a | ev.mug4b {id ev_mug4} {mod vitae>=6?1}

# ev.mug4a
> You stop. He's grey. He's breathing. He'll wake up in an hour with a headache and the worst story of his life.
{do feed:3:choleric:a thief, sixteen:mortal; heat+1}
@end

# ev.mug4b
> You don't stop. He was sixteen. He had his mother's knife.
{do feed:4:choleric:a thief, sixteen:mortal; kill; heat+2; comp-3:Sixteen}
tenant: ...Sixteen, child. He was sixteen.
@end

// =====================================================================
// THE HUNTRESS
// =====================================================================
# ev.hunt street=2,3,4
> Reliquary Row, outside a late bar. A woman in a fur stole and evening gloves is walking a young man to a taxi rank, her arm through his, laughing at something he said. He's drunk. He's very happy. He doesn't notice that she isn't breathing.
pedigree(4): Court. Lady Mireille of the Gilded Court, an old huntress. She'll take him to the crypt and he'll come up at dawn with a smile and a hole in his memory, or he won't come up.
huntress: (to you, without turning, in a voice only the dead hear) Find your own, neonate. This one's spoken for.
* Nod. Walk on. It's the Court's way.  -> ev.hunt1 {do lean:pride+1}
* "Bring him back by dawn, my lady. Alive."  -> ev.hunt2
* Call out to the boy: "Mate. Your taxi's here."  -> ev.hunt3 {do lean:mercy+1}
* "I'm the Sheriff's heir. This is my street."  -> ev.hunt4 {if sync>=30|flag:readVaneLetter}

# ev.hunt1
> She smiles at you over her shoulder. You've done the polite thing. She'll remember you as polite.
{do rel:severine+0}
@end

# ev.hunt2
huntress: Alive. By dawn. How *quaint*. Did Absalom teach you that? He used to say it to me in 1932.
huntress: ...Very well. Alive. For you. You'll owe me a dance.
{do flag:mireilleDance=1; xp:10}
@end

# ev.hunt3
> The boy turns round. "Taxi?" In the half-second he isn't looking at her, you catch his eye, and something in your face makes him sober up very fast.
> He mumbles an excuse and gets into the first taxi in the rank. Mireille watches it go, and then looks at you for a long time.
huntress: That was rude. I'll tell Séverine you were rude.
{do rel:severine-1; xp:15}
@end

# ev.hunt4
> The words come out in a voice older than yours. Mireille stops. Her arm comes out of the boy's.
huntress: ...Absalom.
huntress: No. Not Absalom. Something wearing his voice. Keep your street, then, whatever you are. I'll find another.
> She walks away. The boy stands on the sidewalk looking around, confused, wondering where she went and why he feels so cold.
{do sync+3:His street; lean:pride+1; xp:15}
@end

// =====================================================================
// THE GIRL IN THE PINK COAT
// =====================================================================
# ev.girl street=2,3,4
> Ferrier Lane, two in the morning. A girl of about seven in a pink coat and wellies, alone, standing under a streetlight, crying in the quiet way children cry when they've been doing it for a long time.
girl: I can't find my mom. She went in the launderette and I waited and she didn't come out and the launderette doesn't have a door at the back and I looked.
echo(4): The Ever-Open Launderette is fifty yards away. Its light is on. There's nobody in it but a Wraith folding shrouds.
* Kneel down. "What's your mom's name?"  -> ev.girl1 {do lean:mercy+1}
* Walk her to the Lucky Mart. Tariq will know what to do.  -> ev.girl2 {do lean:mercy+1}
* Keep your distance. A pale stranger at 2 AM is the last thing she needs.  -> ev.girl3
* Hungry. So hungry. And she's alone.  -> ev.girl4 {if vitae<=2}

# ev.girl1
girl: Michelle. Michelle Danes. She's got a blue coat and she smokes and she says I'm not to tell Gran.
> You walk her up and down Ferrier Lane, her hand in yours, cold, holding on. At the corner of Halloran a woman in a blue coat comes running, white-faced, a cigarette still in her fingers.
michelle: Lily! LILY! Oh my God, I said wait by the bench, I SAID —
> She grabs the child, and then looks at you. At your face. At your hand that was holding her daughter's.
michelle: ...Thank you. Who are you? Your hands are freezing.
{do xp:20; comp+1:Lily}
@end

# ev.girl2
> Tariq is out from behind the counter before the door's closed behind you, with a blanket from somewhere and a carton of chocolate milk.
tariq: A child. At two in the morning. On the Strip. Sit, sit, little one. I know your mother, I think. Blue coat? Smokes Superkings? She buys them here.
> Ten minutes later Michelle Danes is in the doorway crying and swearing and hugging her daughter, and Tariq is pretending he doesn't have tears in his eyes.
tariq: (to you, quietly) You brought a lost child to my shop. Of all the shops. Okay. Okay. I'll put that in my book.
{do rel:tariq+1; xp:20}
@end

# ev.girl3
> You stay on the other side of the street and watch until a night bus pulls up and Dot Mulligan leans out and says "Lily? Is that you, love? Where's your mom?" in a voice that's clearly done this before.
@end

# ev.girl4
frenzy: ALONE. Nobody's watching. Nobody would ever —
tenant: No. NO. Not this one. Not ever this one.
> For a moment you can't tell which voice is yours. Then the girl looks up at you with her wet face and says, "Are you a ghost?"
* "Yes. Go home." Walk away very fast.  -> ev.girl4a {do lean:restraint+2}
* ...  -> ev.girl4b

# ev.girl4a
> You walk away fast enough that your shoes slip on the wet cobbles. You don't stop until you're three streets away. Then you lean against a wall and shake.
{do comp-1:Nearly; lean:mercy+1}
tenant: Good. Good. That's the line. Never cross it. I crossed every other line in three hundred years. Never that one.
@end

# ev.girl4b
tenant: CASEY.
> It's his voice, in your mouth, out loud, enormous. The girl screams and runs, straight up the lane, and into her mother's arms at the corner. You're standing alone under the light with your hands out.
{do comp-3:Nearly; lean:restraint-1}
@end

// =====================================================================
// THE PREACHER OF VINE STREET
// =====================================================================
# ev.preach street=2,3,4,5
> At the corner of Vine Street, on a milk crate, under a floodlight, a man with a megaphone and a Bible with no cover. He's been preaching on this corner for twenty years. Tonight there's nobody listening but a fox.
preacher: THEY WALK AMONG US. THE DRINKERS OF BLOOD. THE CHILDREN OF CAIN. THEY WEAR THE FACES OF YOUR NEIGHBOURS. THEY SLEEP IN THE DAY LIKE THIEVES.
> He sees you. He lowers the megaphone.
preacher: ...Evening, ‹brother|sister›. You look like you need to hear the word.
* "Tell me about the children of Cain."  -> ev.pr1
* "You're right, you know."  -> ev.pr2 {do lean:candour+1}
* Drop a few dollars in his hat.  -> ev.pr3 {if cash>=5}
* Walk on.  -> end

# ev.pr1
preacher: Cain killed Abel and God marked him and cursed him to walk the earth. And Cain went into the land of Nod, east of Eden, and he begat a people. Pale. Hungry. Who drink the blood of the righteous by night.
preacher: People think I'm mad. I'm not mad. I've seen them. In 1999 a woman in a fur stole tried to take my brother. I hit her with a hymnal. She laughed and let him go.
tenant: Mireille. She does like a man who fights back.
{do xp:5}
@end

# ev.pr2
> He stares at you. Then at the floodlight, at your face in it. You don't flinch, not quite, but your skin starts to itch.
preacher: ...Lord preserve us. Lord preserve us. You're one.
preacher: Why aren't you running? Why aren't you burning?
* "It's not real sunlight. It just itches."  -> ev.pr2a
* "Because I'm not a monster. Not tonight."  -> ev.pr2b

# ev.pr2a
preacher: Itches. Twenty years I've preached against you and you're telling me the floodlights *itch*.
> He sits down on his milk crate and laughs until he cries.
@end

# ev.pr2b
preacher: Not tonight. Not tonight. Then which night, ‹brother|sister›? Which night are you?
> You don't have an answer. He doesn't expect one. He blesses you, crooked, with two fingers, and goes back to his megaphone.
{do comp+1:A blessing}
@end

# ev.pr3
preacher: Bless you, ‹brother|sister›. Bless you. Twenty years and you're the first person who's paid for a sermon.
{do cash-5; xp:5}
@end

// =====================================================================
// THE ABANDONED GHOUL
// =====================================================================
# ev.ghoul street=2,3,4
> Outside the Reliquary, sitting on the curb in a beautiful old suit gone shiny at the elbows, an old man with his hat in his hands. His hands are shaking. When you get closer you see his face: seventy, eighty, and getting older while you watch.
ghoulbeg: Please. Please. You're one of them. I can tell. Please. Just a drop. Just a little drop.
ghoulbeg: Forty years with the Danforths. Forty years. Then they went to Florida and said they'd send for me. They didn't send for me.
autopsy(5): A ghoul in withdrawal. He's ageing a year a week. Without blood he'll be a hundred in a month and dead in two.
* Give him a drop of your blood.  -> ev.gh1 {blood 1}
* Give him money for Mother Hask's market.  -> ev.gh2 {if cash>=50}
* "I can't. I'm sorry."  -> ev.gh3
* "Go to the crypt. Ask the Court."  -> ev.gh4

# ev.gh1
> He takes your wrist in both hands like a chalice and drinks one mouthful and sits back with his eyes closed. The shake stops. Ten years fall off his face like a coat.
ghoulbeg: Oh. Oh, that's strong. That's very old. Who... who are you?
ghoulbeg: Thank you. I'll... I'll find work. A house. A family. Someone who needs a man who can lay a table for a hundred and polish silver.
tenant: You've given a stray ghoul your blood. He'll come back for more. They always come back. You've just acquired a butler.
{do flag:ghoulFollower=1; lean:mercy+1; xp:15}
@end

# ev.gh2
> You give him fifty dollars. He looks at it as if it were a love letter.
ghoulbeg: Mother Hask. Platform 0. Yes. Yes. A month. That's a month. Thank you. Thank you.
{do cash-50; lean:mercy+1; xp:10}
@end

# ev.gh3
ghoulbeg: No. No, of course. Of course.
> He puts his hat back on, very carefully, the way gentlemen used to. You walk on. When you look back he's still sitting there, perfectly upright, ageing.
@end

# ev.gh4
ghoulbeg: The Court. I went. Tiny wouldn't let me down. The list. I'm not on the list any more. Nobody's on the list once their masters go to Florida.
@end

// =====================================================================
// THE BUSKER WHO HEARS THINGS
// =====================================================================
# ev.busk street=2,3,4
> Reliquary Row, a doorway. A busker with a violin case open at her feet, playing something slow and Irish to nobody at one in the morning. When you pass, the tune changes. Without missing a beat it becomes something else: something old and sad and in a minor key you've never heard and know perfectly.
busker: That's yours. That's the tune you're humming. Did you know you were humming?
busker: People hum their whole lives without knowing. I play it back to them. Sometimes they cry. Sometimes they give me twenty bucks. Sometimes both.
nostalgia(4): It's the song from Agnes's letters. No. It's older. It's the song somebody hummed to Absalom Vane in 1720 on a boat on the Vellum with a coffin in the bottom.
* "Play it again."  -> ev.bu1
* Give her twenty.  -> ev.bu2 {if cash>=20}
* "Who taught you to hear that?"  -> ev.bu3

# ev.bu1
> She plays it again. Slower. Somewhere inside you, the Tenant is very quiet, the way a man is quiet in a church he hasn't been to since he was a boy.
{do sync+2:The tune; comp+1}
@end

# ev.bu2
busker: Both. You're a both. Thanks.
{do cash-20; comp+2:The tune}
@end

# ev.bu3
busker: Nobody. My grandma said I had the gift. My mom said I had tinnitus. Both, probably. Like everything.
busker: You've got a lot of tunes in you, mate. More than one person's worth. You should get that seen to.
@end

// =====================================================================
// A NURSE ON HER BREAK
// =====================================================================
# ev.nurse street=2,3,4
> Outside the side door of St. Jude's, under the NO SMOKING sign, a nurse in scrubs and a parka smoking a cigarette with the desperate concentration of someone with four minutes.
nurse2: Don't. Whatever it is. I've got four minutes. If you're bleeding, go to the front. If you're dying, go to the front faster.
pulse(4): Bad back. Bad feet. Twelve hours on. She hasn't sat down since six.
* "Just passing. Long night?"  -> ev.nu1
* "What do you know about Dr. Rostova's basement?"  -> ev.nu2
* Stand with her in silence for four minutes.  -> ev.nu3 {do lean:mercy+1}

# ev.nu1
nurse2: Long night. Long week. Long life. We had a man in at eleven who said he'd been bitten by a woman in a fur stole and wanted a rabies shot. I said sir, it's a hickey. He said it was a very sharp hickey.
@end

# ev.nu2
> She stops smoking. She looks at you properly for the first time.
nurse2: The basement's off limits. Research. Dr. R. and the government people. We're not allowed down. Bea from nights went down once in August for a cylinder and came up white as a sheet and handed in her notice the next day.
nurse2: She works at a Tesco in Bayside now. She won't talk about it. She sends me a Christmas card every year that just says "don't go down".
{do flag:knowBea=1}
@end

# ev.nu3
> Four minutes. She smokes. You stand. Neither of you says anything. When she grinds the cigarette out on the wall she looks at you with something like gratitude.
nurse2: Thanks. Nobody just stands. Everyone wants something.
{do comp+1:Four minutes}
@end

// =====================================================================
// THE DRUNK WHO KNOWS
// =====================================================================
# ev.drunk street=2,3,4,5
> Dock Road. A very drunk man in a docker's jacket comes out of the Anchor, sees you, stops, points.
drunk2: I KNOW what you are. I KNOW. My dad told me. He worked the docks in '77. He saw one. On Pier Nine. Tearing a man in half. Big grey dog-thing that stood up like a man.
drunk2: Then another one came and killed it. Tall. In a long coat. Like yours. JUST like yours.
* "Your dad saw right. Go home."  -> ev.dr1 {do lean:candour+1}
* Laugh. "You've had a few, mate."  -> ev.dr2 {do lean:candour-1}
* Make him forget. All of it. Even his dad's story.  -> ev.dr3 {ab fog}

# ev.dr1
drunk2: ...He did? He DID? Everyone said he was mad. Everyone. He died saying it. "Grey dog-thing, Pier Nine."
> He sits down on the curb. He's suddenly very sober.
drunk2: He wasn't mad. He wasn't mad. Thank you. I've got to tell my mom.
pedigree(4): You've just confirmed the Masquerade to a drunk on Dock Road. Nobody will believe him. That's the beauty of drunks. But still.
{do heat+0; xp:10}
@end

# ev.dr2
drunk2: Few? I've had NINE. And I'm right. You'll see. One day you'll all see.
@end

# ev.dr3
> The fog takes the whole of it: tonight, the pier, the grey dog-thing, his father's story told on a hundred Saturday nights. He blinks at you.
drunk2: ...Sorry, mate. Thought you were someone. Which way's the taxi rank?
tenant: You took his father's story, child. The one thing the old man left him. It was true, too.
{do lean:candour-1}
@end

// =====================================================================
// THE COURT BOY'S DARE
// =====================================================================
# ev.dare street=3,4
> At the Halloran crossing, under the sweeping floodlight, three young Court Kindred in dinner jackets are daring each other to stand in the beam. One of them does: five seconds, six, his skin going pink, laughing. The other two cheer.
courtboy: Seven! Seven seconds! Beat THAT, Freddie!
courtboy: Oh, look. The diablerist. The *famous* diablerist. Go on, then, Sheriff-eater. How long can you stand in it?
* "Longer than you."  -> ev.da1 {do lean:pride+1}
* "That's a federal light. It's not a game."  -> ev.da2
* Walk on.  -> ev.da3

# ev.da1
? rigor 10 Stand in the beam. Count.  -> ev.da1a | ev.da1b {id ev_dare}

# ev.da1a
> One. Two. It's like standing in a nettle bed that's on fire. Five. Six. Your eyes water. Eight. Nine. Ten.
> You step out at twelve. The Court boys are silent. One of them claps, slowly.
courtboy: Twelve. TWELVE. Who ARE you?
{do vitae-1; lean:restraint-1; xp:15; rel:ashby+1}
@end

# ev.da1b
> Four seconds. Your hand goes up before you can stop it. You stagger out with your face blistering and the Court boys falling about laughing.
courtboy: FOUR! Four! The Sheriff-eater, four!
{do vitae-1; comp-2:Four seconds}
@end

# ev.da2
courtboy: A federal what? Don't be such a bore. It's just lights. Séverine put them up.
pedigree(5): They don't know. The Court doesn't know whose lights these are. Séverine hasn't told them. Or she doesn't know herself.
* "Tell Séverine to ask Harrow what frequency they run at."  -> ev.da2a {if flag:know414|flag:knowCode}
* "Suit yourselves."  -> end

# ev.da2a
courtboy: Frequency. What are you, a radio? Fine. Fine. I'll tell her. She'll be thrilled.
> He won't. Or he will, drunk, at four in the morning, and she'll remember it on Friday.
{do flag:sevHeardFrequency=1}
@end

# ev.da3
courtboy: Coward! Ha! Coward!
> You walk on. Behind you, someone counts to nine and screams.
@end

// =====================================================================
// THE LANTERN TECHNICIAN
// =====================================================================
# ev.tech street=3,4
> Down a side street behind Platform 0, a grey van with its back doors open, and a man in grey overalls on a ladder, fitting a lamp into a drain grate with a cordless screwdriver. He's whistling.
lanterntech: Evening! Gas board. Routine. Don't mind me.
web(5): Not gas board. That's a quartz lamp, plate-sized, wired to a box with a blinking light. A grate lamp. He's installing them. This is one of the thirty-one.
* Ask him how many he's done tonight.  -> ev.te1
? stagecraft 9 "Supervisor says you've got the wrong grate. That's number thirty-two. There is no thirty-two."  -> ev.te2 | ev.te3 {id ev_tech}
* Break his ladder.  -> ev.te4 {do lean:restraint-1}

# ev.te1
lanterntech: Tonight? Four. Thirty-one all in, by tomorrow. They're all on one circuit. Clever stuff. You switch one on, they all come on. Like Christmas lights.
lanterntech: Don't know what they're for. Something about a "survey". I don't ask. I'm paid by the hour.
{do flag:knowCode=1; xp:10}
@end

# ev.te2
lanterntech: Thirty-two? There's no... I've got thirty-one on the sheet.
> He checks his clipboard. He scratches his head. He packs up his screwdriver and climbs down and drives off to find his supervisor, leaving the lamp half-fitted and the wires hanging.
{do flag:lampUnwired=1; xp:20}
@end

# ev.te3
lanterntech: Nah, mate. Thirty-one on the sheet. This is twenty-eight. I can count.
@end

# ev.te4
> One kick. The ladder goes. He comes down on the cobbles with a yell and the lamp in his arms, unhurt, furious.
lanterntech: You MANIAC. That's government property!
> He drives off. The lamp goes with him. Tomorrow there'll be a different man, with a different ladder.
{do heat+1}
@end

// =====================================================================
// THE WIDOW AND THE DOG
// =====================================================================
# ev.widow street=2,3,4,5
> Halloran Street, three in the morning. An old woman in a quilted coat walking a fat terrier on a tartan lead. The terrier sees you and sits down on the sidewalk and won't move. It doesn't growl. It just looks at you, very seriously.
widow: Come on, Biscuit. Come ON. He does this. He's never done this. I'm so sorry.
widow: He sat down like this in front of my husband's coffin. Wouldn't move for an hour. The vicar had to step over him.
* Crouch down and let Biscuit sniff your hand.  -> ev.wi1
* "Dogs know things."  -> ev.wi2
* "Why are you walking at three in the morning?"  -> ev.wi3

# ev.wi1
> Biscuit sniffs your hand for a long time. Then he licks it, once, very carefully, the way you'd lick a stamp. Then he gets up and walks on as if nothing had happened.
widow: Well. Well. He likes you. He didn't like my husband.
{do comp+1:Biscuit}
@end

# ev.wi2
widow: They do. Biscuit knew my husband was going three weeks before the doctors did. Sat on his feet every night.
widow: ...Are you all right, dear? You look very cold.
@end

# ev.wi3
widow: Since Gerald died I can't sleep. So I walk Biscuit. Three o'clock. It's the quietest. Sometimes I see things. Last week I saw a tall man in a long coat standing outside the Lucky Mart, just looking in the window. Very still. Like he was saying goodbye.
tenant: (very quietly) Sunday. That was Sunday. The last time I walked the Ward.
@end
`,'c_street1');
