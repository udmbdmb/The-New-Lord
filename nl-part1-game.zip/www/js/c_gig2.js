'use strict';
/* THE NEW LORD — more ways to help Leo through his set in Elysium */
(function(){const O=NL.Script.opt;
O('gig.you','* Shout from the back: "TELL THEM ABOUT THE RUG."  -> gg2.rug {if flag:leoJokeTested|flag:nbRead}',2);
O('gig.you','* Walk to the front and sit in the empty chair by the stage, so he can see you.  -> gg2.front',2);
O('gig.you','* Let the Tenant laugh. His laugh. The one the whole Court knows.  -> gg2.vane {if sync>=30}',2);
})();
NL.Script.add(String.raw`
# gg2.rug
> Three hundred dead faces turn to look at you. Leo, in the spotlight, goes white and then red.
leo: The rug. Okay. The rug. So my mate, the one at the back, the one who just shouted, has an old man living in their head who has very strong opinions about my rug. I don't have a rug. He has opinions about it anyway.
> And the room laughs. Not a ripple. A laugh. Because every Kindred over a hundred in this room knows exactly whose opinions those are, and has heard them, at length, at dinner.
tenant: (in your blood, appalled) It's a perfectly reasonable position. Bokhara, or nothing.
> Lord Ashby is crying with laughter. Lisette has her hand over her mouth. Even Séverine's fan stops moving for a moment.
{do flag:gigLaughed=1; flag:gigRug=1; rel:leo+2; xp:30:The rug}
@next gig.after

# gg2.front
> You walk the length of the crypt in front of three hundred Kindred while a mortal comedian waits at a microphone. You sit in the front chair. You look up at him.
> He looks down at you. He breathes out.
leo: ...Okay. Okay. Hi. This is my mate. My mate's in the front row. My mate's never been in the front row of anything. Neither have I.
> He does his set to you. Only to you. Fifteen minutes, looking at nobody else. Behind you, slowly, without being asked, the room starts to listen, because there's nothing as compelling as watching someone perform for one person.
{do flag:gigFront=1; rel:leo+3; lean:pride-1; xp:30:Front row}
@next gig.after

# gg2.vane
> You let him. Just his laugh. It comes out of your mouth from the back of the crypt: a dry, delighted, unmistakable bark, the one he used at the Prince's dinners when someone said something he hadn't expected.
> Three hundred Kindred turn round. They know that laugh. They've known it for a hundred years. It's coming out of the neonate.
> And then they laugh too, because Absalom Vane is laughing, and Absalom Vane never laughed at anything that wasn't actually funny.
tenant: (afterwards, very quietly) He IS funny. The boy. Nobody ever told me mortals could be funny on purpose.
{do flag:gigLaughed=1; flag:gigVane=1; flag:courtKnowsVaneLives=1; rel:leo+2; sync+2; xp:40:His laugh}
@next gig.after
`,'c_gig2');
