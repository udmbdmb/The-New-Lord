'use strict';
/* THE NEW LORD — painted portraits for the main cast (dialogue box and People panel) */
(function(){NL.PAINTED=NL.PAINTED||{};
['gideon','harrow','leo','malakor','margo','miller','pemberton','rostova','severine','soot','tariq','tenant','tiny','valko'].forEach(id=>{NL.PAINTED[id]='art/'+id+'.webp';});
NL.PAINTED.sev=NL.PAINTED.severine;NL.PAINTED.pem=NL.PAINTED.pemberton;
/* the player, by clan and look */
['sovereign','wraiths','glass','choir','butchers','hounds','alchemists','hollow','rot','stray'].forEach(c=>['m','f'].forEach(g=>{NL.PAINTED['you_'+c+'_'+g]='art/you_'+c+'_'+g+'.webp';}));
/* the sixteen voices */
['parasite','apex','frenzy','osmosis','nostalgia','pulse','velvet','stagecraft','echo','pedigree','web','gutter','rigor','autopsy','abattoir','sundial'].forEach(k=>{NL.PAINTED['skill_'+k]='art/skill_'+k+'.webp';});
/* menus and screens */
NL.ART=Object.assign(NL.ART||{},{title:'art/title_wide.webp',titleTall:'art/title_tall.webp',panel:'art/panel.webp',gameover:'art/gameover.webp',dawn:'art/dawn.webp'});
/* warm the cache so the first line of dialogue doesn't pop in */
if(typeof Image!=='undefined')setTimeout(()=>{Object.keys(NL.PAINTED).filter(k=>!/^you_/.test(k)).forEach(k=>{const i=new Image();i.src=NL.PAINTED[k];});},4000);
})();
