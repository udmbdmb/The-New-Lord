'use strict';
/* THE NEW LORD — your blood remembers: a clan scene for each of the ten bloodlines, after the clan quest, through the Tenant and the street */
NL.Script.add(String.raw`
// =====================================================================
// THE SOVEREIGN
// =====================================================================
# cl.sov arc=tenant night=3,4 label="The Ashcombe debt" if=clan:sovereign&done:c_sovereign prio=3
tenant: The Ashcombes. Ninety years they owed House Vane, and you settled it on Tuesday. Do you know what the Sovereign say about debts? That a debt settled is a relationship ended.
tenant: For ninety years Lionel Ashcombe hated me and needed me and sent me a Christmas card. This year, nothing. You've freed him. Or you've orphaned him. Sovereign can never tell the difference.
* "Did you want them to stay in debt?"  -> cl.sov1
* "Is that what the Court is? Debts?"  -> cl.sov2

# cl.sov1
tenant: Of course. A debt is a leash with good manners. I kept half the Ward on leashes like that. It's how the Sovereign rule: not by force. By *invoice*.
tenant: You've just shown the Ashcombes that a Vane can forgive. Every other debtor in the Ward will have heard by now. Some will be grateful. Some will think you're weak. All of them will be watching to see if you forgive them too.
@end

# cl.sov2
tenant: Debts, and the memory of debts, and the hope of new ones. The Gilded Court is a ledger that wears velvet. Your blood knows how to read it. You'll find you can tell, now, just by looking, who owes whom in a room.
tenant: It's a terrible gift. It makes dinner parties unbearable.
@end

# cl.sov0 arc=tenant night=3,4 label="The Ashcombe debt" if=clan:sovereign&!done:c_sovereign prio=2
tenant: You didn't collect the Ashcombe tithe. Lionel will have noticed. The Court will have noticed. A Sovereign who doesn't collect is either merciful or a fool, and the Court has never in its history guessed merciful.
@end

// =====================================================================
// THE WRAITHS
// =====================================================================
# cl.wra arc=tenant night=3,4 label="Soot's children" if=clan:wraiths prio=2
tenant: You're Soot's now, in the blood. Have you noticed your face? In the bright rooms? It's starting. A little grey at the temples, a little tight across the bones.
tenant: Every Wraith remembers the night they first saw their own skull in a mirror. Some of them break the mirror. Some break themselves. Soot says the trick is to fall in love with it. She says it's the only face that will never lie to you.
* "Did you ever see a Wraith fall in love with their face?"  -> cl.wra1
* "I don't want to look like that."  -> cl.wra2

# cl.wra1
tenant: Once. A woman called Winter, in the fifties, who sat on the Courthouse steps and counted stars and wore a porcelain mask with a painted smile. One night I saw her take it off on the steps, when she thought nobody was looking, and turn her real face up to the stars.
tenant: She was smiling. Under it. The real face, smiling. I never told anyone. I've thought about it often.
{do mem:tenant:winterface}
@end

# cl.wra2
tenant: Nobody does. Then one day you will. Or you'll wear masks until the masks are all that's left. Either way, you'll be listened to. Nobody watches a Wraith. Everybody talks in front of one.
@end

// =====================================================================
// THE GLASS
// =====================================================================
# cl.gla arc=tenant night=3,4 label="What the mirrors show" if=clan:glass prio=2
tenant: The mirrors are showing you things. I can feel it when they do; you go very still, like a dog hearing a whistle. What do you see?
* "Friday."  -> cl.gla1
* "You. Young."  -> cl.gla2
* "Nothing I understand."  -> cl.gla3

# cl.gla1
tenant: Friday. Of course. Everybody's mirrors are full of Friday this week. Don't trust them. The Glass see what's possible, not what's certain. The future in a mirror is a draft.
@end

# cl.gla2
tenant: Me? Young? Oh, God. With the feather in my hat? Don't. I looked ridiculous. 1803. I thought I was the most dangerous thing in Port Vellum. I was the second most.
@end

# cl.gla3
tenant: Good. The ones who understand the mirrors are the ones who go mad first. Stay confused. It's safer.
@end

// =====================================================================
// THE CHOIR
// =====================================================================
# cl.cho arc=tenant night=3,4 label="The song in your throat" if=clan:choir prio=2
tenant: You've been humming. All night. You didn't notice. Under your breath, a tune I haven't heard since Lyon. Séverine's tune. The Bell Song.
tenant: The Choir share music the way other clans share blood. You've picked up hers. Be careful: she'll hear it, the next time you're in her crypt. She'll know you've been listening.
* "Is that bad?"  -> cl.cho1
* "Teach me something of yours."  -> cl.cho2

# cl.cho1
tenant: Bad? For a Choir? It's the closest thing you have to a love letter. She hasn't been sung back to in a hundred and thirty years.
@end

# cl.cho2
tenant: Mine? I'm not Choir. I can't sing. I can whistle, badly. There's one tune. An old parlour song, *I'll Take You Home Again, Kathleen*, older than the Courthouse. Agnes sang it, flat, at the top of the Courthouse stairs.
> And then you're humming it. An old parlour song, slightly flat.
tenant: ...Yes. Like that. Exactly like that.
{do sync+2:Kathleen}
@end

// =====================================================================
// THE BUTCHERS
// =====================================================================
# cl.but arc=tenant night=3,4 label="The face you were born with" if=clan:butchers prio=2
tenant: Malakor said something to you about faces. I could hear him through your ears. "Every Butcher meets the face they were born with, and has to decide whether to keep it."
tenant: Look in the next mirror you pass. Look properly. Your hands know how to change it now. Do you want to?
* "No. I want to know who that face was."  -> cl.but1 {do lean:candour+1}
* "Maybe. When I know whose face I'd want."  -> cl.but2

# cl.but1
tenant: Good. Keep it, then. Wear it into the chalk circle on Friday. Let them all see a face that's never been anyone but yours.
@end

# cl.but2
tenant: Whose face would you want? Don't say mine. Please don't say mine. I couldn't bear to watch you shave.
@end

// =====================================================================
// THE HOUNDS
// =====================================================================
# cl.hou arc=tenant night=3,4 label="The pack" if=clan:hounds prio=2
tenant: You're a Hound. You'll have felt it with Valko: the pull. Hounds know each other the way wolves do, by the smell of the hunt on them. He'll want to run with you. You'll want to let him.
tenant: The thing about the pack is that it needs a front and a back. Someone to lead and someone to follow. Valko has followed for seventy years. He doesn't know how to do anything else.
* "Then I'll lead."  -> cl.hou1 {do lean:pride+1}
* "Then I'll teach him to run beside me."  -> cl.hou2 {do lean:mercy+1}

# cl.hou1
tenant: Of course you will. That's what I did. It worked very well for me and very badly for him.
@end

# cl.hou2
tenant: Beside. Hmm. I never thought of that. Seventy years and it never occurred to me that a dog could walk *beside*.
{do rel:valko+1}
@end

// =====================================================================
// THE ALCHEMISTS
// =====================================================================
# cl.alc arc=tenant night=3,4 label="Your promises" if=clan:alchemists prio=2
tenant: Have you counted your promises? I have. I can feel them in your blood like stitches. Some are pulling tight. Some have come undone, and you burned for them.
tenant: Alchemists keep a ledger of every promise they've ever made, in their heads. The old ones say the only freedom is to stop promising. The young ones never listen.
* "How many have I made?"  -> cl.alc1
* "What happens if I break one on Friday?"  -> cl.alc2

# cl.alc1
tenant: Enough that I'd be careful on Friday. Leo, Tariq, Valko, Pemberton, the old woman in the pipes. You've promised the whole Ward something. They'll all be on the platform.
@end

# cl.alc2
tenant: You burn. In front of the Magistrate. In front of everyone. He'll see your blood boil and know exactly what kind of creature you are: one whose word costs something.
tenant: ...Actually, that might help you. Nobody else in that court's word costs anything at all.
@end

// =====================================================================
// THE HOLLOW
// =====================================================================
# cl.hol arc=tenant night=3,4 label="Your shadow" if=clan:hollow prio=2
tenant: Your shadow came back. On Tuesday. I watched it come up the Switchyard stairs by itself and slide back under your feet like a cat coming in through a flap.
tenant: Where did it go? Did it tell you? The Hollow say a shadow that walks off is looking for something you've forgotten you need.
* "It went to Platform 0. To the grates."  -> cl.hol1
* "It won't say."  -> cl.hol2

# cl.hol1
tenant: The grates. Then it was looking at the lamps before any of us knew they were there. Your shadow's cleverer than both of us.
{do flag:shadowSawLamps=1}
@end

# cl.hol2
tenant: No. They never do. They just come back looking pleased with themselves.
@end

// =====================================================================
// THE ROT
// =====================================================================
# cl.rot arc=tenant night=3,4 label="The sick" if=clan:rot prio=2
tenant: You can smell it, can't you. Every sick person in the Ward. Like a map drawn in fever. The man in 302 with his chest. Tiny's kidneys. The coughing on the steps of St. Jude's.
tenant: The Rot can cure as well as spread. You'll have found that out in Ward 4. Elena Rostova would weep to have your blood in a dish. You could make her an offer. You could make the whole program unnecessary.
* "Give her my blood? After what she did?"  -> cl.rot1
* "I'll think about it."  -> cl.rot2

# cl.rot1
tenant: After what she did. Yes. Seven people died because she didn't have what's in your veins. Give it to her, and she might never kill anyone again. Or she might kill more, faster, better. I don't know. I'm a policeman, not a philosopher.
@end

# cl.rot2
tenant: Think quickly. She's on a roof on Thursday deciding whether to jump.
@end

// =====================================================================
// THE STRAY
// =====================================================================
# cl.str arc=tenant night=3,4 label="No clan" if=clan:stray prio=2
tenant: The Stray. No clan, no lineage, no table. You've noticed how the Court looks at you: through you, like a window.
tenant: I want you to know something. Rina, the girl who made Teo, was Stray. And the Prophet was made by a Wraith on her own. And Dutch was made by a Hound who died the next night. Half the Marrow Ward's Kindred are somebody's accident.
tenant: The Court has spent three hundred years pretending otherwise. You're the first accident in history to eat a Sheriff. They're terrified of you. Enjoy it.
{do lean:pride-1}
@end
`,'c_clan');
