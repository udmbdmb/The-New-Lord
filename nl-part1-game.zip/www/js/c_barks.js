'use strict';
/* THE NEW LORD — the voices notice things: ambient remarks, room by room, night by night */
(function(){const H=NL.DSL.H;
const C={alley:[5,3],luckymart:[4,3],reliquary:[5.5,3.5],vip:[3.5,3],pawn:[4,3],stjude:[5,3],rookery:[5,2.5],apt:[3,2.5],switchyard:[6,3.5],shrine:[4,3],morgue:[5,3],cistern:[5,3]};
const add=(room,list)=>{H.barks[room]=H.barks[room]||[];list.forEach(([id,s,t,cond,r,pass])=>{const c=C[room];H.barks[room].push({id:'cb_'+id,s,t,at:[c[0],1,c[1]],r:r||3.2,if:cond||null,pass:pass||null});});};
const n=k=>S=>S.night===k;
add('alley',[
  ['al2','gutter','Same rain as Monday. Different you.',n(2)],
  ['al3','echo','Someone has scrubbed the cobbles outside Kowalski\'s back door. Twice. There\'s still a coat-shaped space on the stones where nothing burned.',n(3),3.5,6],
  ['al4','sundial','Floodlight at the crossing, forty-second sweep. You can do the lane in thirty if you don\'t stop.',n(4)],
  ['al5','nostalgia','Last night on Ferrier Lane. Whatever happens. Look at it properly.',n(5)],
  ['alT','pulse','Tariq\'s light is on. It\'s always on. It\'s the steadiest heartbeat on the street.',S=>S.night>=3&&S.flags.tariqLamp]
]);
add('luckymart',[
  ['lm2','parasite','Four people bought cigarettes in the last hour. Two of them were bleeding slightly. Gums. It\'s the cold.',n(2),3,5],
  ['lm3','stagecraft','He\'s put the coffee on for you again. He\'ll pour it out at five. Every night. Don\'t mention it.',n(3)],
  ['lm4','sundial','Cardboard on the windows. He\'s worked out what the lights do without anyone telling him.',n(4)],
  ['lm5','nostalgia','Root beer. Fridge three, bottom shelf. You used to buy one every Friday after a shift. Somewhere. Somewhen.',n(5)]
]);
add('reliquary',[
  ['rq2','velvet','Lisette is counting the room. Count her back. She hates being counted.',n(2)],
  ['rq3','parasite','Nobody\'s dancing for joy tonight. They\'re dancing like people who think they\'re being watched. They are.',n(3)],
  ['rq4','web','The DJ has played the same three songs since ten. Court instructions: keep the mortals upstairs and loud.',n(4),3.5,5],
  ['rq5','echo','Empty. A dancefloor with nobody on it sounds like the inside of a bell.',n(5)]
]);
add('vip',[
  ['vp2','pedigree','Seventeenth-century Capuchin ossuary. Brother Anselm is the one with the cracked jaw. He\'s her favorite.',n(2),3,4],
  ['vp3','osmosis','Jasmine and old church. And under it, faint, menthol cigarettes. The grey man\'s been down here again.',S=>S.night===3&&S.flags.knowSevHarrow,3,6],
  ['vp4','stagecraft','Three hundred Kindred being counted like sheep. Every one of them is pretending it\'s a party.',n(4)],
  ['vp5','nostalgia','The gramophone is silent. She\'s taken the Caruso record down to the platform.',n(5)]
]);
add('pawn',[
  ['pw2','echo','Fourteen pocket watches ticking. Six stopped. Each one has a different idea of what time it is. Like the dead.',n(2)],
  ['pw3','gutter','Under the counter: a shotgun, two boxes of shells, and a bottle of holy water with a price tag on it.',n(3),3,5],
  ['pw4','pulse','Gideon\'s heart is very steady. Seventy-four and he\'s the calmest man on Reliquary Row.',n(4)],
  ['pw5','nostalgia','Box three. The lid sticks. You\'ve slept in it. It\'s the nearest thing you have to a bed of your own.',n(5)]
]);
add('stjude',[
  ['sj2','autopsy','Three overdoses, a stabbing, a man who swallowed a key. Rostova\'s triaged them all in under an hour.',n(2),3,5],
  ['sj3','echo','The staff lift. B1. The cables hum. Something heavy went down tonight. Something that didn\'t walk.',n(3),3,6],
  ['sj4','parasite','The blood fridge is empty. Someone cleared it out at sunset. Expired or not, every bag.',n(4)],
  ['sjS','nostalgia','Ambulance bay. Diesel and wet asphalt. Your hands know where the gloves go.',S=>S.past==='paramedic',3]
]);
add('rookery',[
  ['rk2','echo','Six floors. Forty-two flats. Somebody in 6C is singing in the bath. Somebody in 302 is calling cats.',n(2),3,4],
  ['rk3','web','A brown coat on the landing two floors up. Menthols. He\'s been watching the stairwell since sunset.',S=>S.night===3&&S.flags.sootTipHaven,3,5],
  ['rk4','sundial','The roof floodlight sweeps the yard every minute. Halloran\'s cats have learned the rhythm. Learn it too.',n(4)],
  ['rk5','nostalgia','Leo\'s door. A note taped to it in marker: BACK LATER. Underneath, smaller: probably.',S=>S.night===5&&S.flags.leoGoneTown]
]);
add('apt',[
  ['ap2','nostalgia','Two mugs on the draining board. A cactus. Joke notebooks. A life that fits in one room.',S=>S.night===2&&S.aptWho==='leo'],
  ['ap4','echo','The chimney is quiet. For the first time in ten years, nothing is scratching.',S=>S.night>=3&&S.aptWho==='404'&&S.flags.ezraFree],
  ['ap5','pulse','His heart\'s going fast. Not fear. He\'s been waiting for you.',S=>S.night===5&&S.aptWho==='leo']
]);
add('switchyard',[
  ['sy3','sundial','The grates. Thirty-one of them. Count them every time you come down. Make it a habit.',S=>S.night>=3&&S.flags.knowCode],
  ['sy4','echo','Under the platform, very faint, a hum. One note. 4.14. It doesn\'t stop.',S=>S.night===4,3.5,6],
  ['sy5','frenzy','Three hundred of them. All in one place. All of them looking at you. Wouldn\'t it be EASY.',n(5)],
  ['syU','gutter','At the far end, Local 0, in their least-ripped jeans. Somebody\'s brought a thermos.',S=>S.night===5&&S.flags.side_union]
]);
add('shrine',[
  ['sh2','echo','Two hundred candles. A thousand jars. And under it all, the pipes, breathing.',n(2)],
  ['sh4','nostalgia','The oldest pipe is green with verdigris. It was laid in 1871. It still carries the sound of a boy buying cigarettes in 2011.',S=>S.night>=3&&S.tasks.s_mateo,3,5],
  ['sh5','pulse','No heartbeat in the room but the rats\'. Hundreds. Steady. Waiting.',n(5)]
]);
add('morgue',[
  ['mg3','autopsy','Forty drawers. Nineteen occupied. One of them is wrong. One of them has been sewn shut by an amateur.',n(3),3,5],
  ['mgS','nostalgia','Cold steel. Formalin. A drawer you\'ve lain in. No. That was the freezer. It all smells the same.',n(3)]
]);
add('cistern',[
  ['cs3','echo','The water hasn\'t moved since 1911. Not a ripple. Your voice goes out across it and doesn\'t come back.',S=>S.night>=3],
  ['cs4','nostalgia','Candle-rafts. A hundred of them, each one for somebody drowned. Soot lights them by hand.',S=>S.night>=3,3,4]
]);
})();
