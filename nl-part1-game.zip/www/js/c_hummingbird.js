'use strict';
/* THE NEW LORD — "The Hummingbird Ring": someone in the Gilded Court has been making childer at parties and leaving them in the river */
(function(){const X=NL.EXTRAS,S_=NL.Script;
X.valentin={n:'Valentin Roux',color:'#d0a0c8',role:'The Gilded Court',spec:{face:{long:1.02,cheek:1.5,jaw:.95},skin:[.92,.86,.84],hair:{style:'curly',color:[.15,.1,.08]},coat:{color:[.2,.1,.25],length:.75,collar:true},shirt:[.95,.9,.92],eyes:[.6,.45,.7],eyeGlow:[.35,.08,.2]}};
X.priya=X.priya||{n:'Priya',color:'#e0a0b0',role:'Embraced last month',spec:{face:{long:1.0,cheek:1.2,jaw:.95},skin:[.62,.46,.38],hair:{style:'long',color:[.08,.06,.05]},shirt:[.3,.2,.3],coat:{color:[.2,.15,.2],length:.5,collar:true},eyeGlow:[.3,.05,.05]}};
NL.TASKS.s_hbird={n:'The Hummingbird Ring',xp:90,cat:'side'};
S_.place({id:'roux',name:'The Orangery, Club Reliquary',block:'B',sub:'A glasshouse on the Reliquary roof, all palms and dead orchids. Valentin Roux holds his salons there.',if:'night>=3&night<=4&flag:mapOK&flag:knowRoux&!flag:rouxDone',node:'hb.roux',min:6});
})();
NL.Script.add(String.raw`
# hb.0 arc=lisette night=3,4 label="\"Lisette. A silver ring with a hummingbird on it.\"" if=flag:knowNewbSire&!flag:knowRoux prio=5
@focus lisette
> She stops counting the room. Her eyes go, very quickly, to the stairs that lead to the roof.
lisette: Hummingbirds. The Court's bird. Everyone of rank has one. Séverine's is gold. Mine is jet. Silver is for the youngest courtiers. There are four silver rings in Elysium.
lisette: Why?
* "Someone with a silver ring is Embracing people at parties and throwing them in the river."  -> hb.tell
* "No reason."  -> hb.noreason

# hb.noreason
lisette: Darling. Nobody asks about rings for no reason. Rings are the only thing anyone here asks about for a reason.
@end

# hb.tell
> She's very still for a moment.
lisette: ...Valentin. It'll be Valentin Roux. He's the only silver ring who goes to mortal parties. He says it's for the music. He's a hundred and twelve and he still thinks techno is a revolution.
lisette: He's Séverine's pet. Her favorite since Freddie went quiet. He has salons in the glasshouse on the roof. Orchids and mortal art students.
lisette: If you're right, Séverine will want to know. And if you're right, she'll want very badly for nobody else to know.
{do flag:knowRoux=1; task:s_hbird; note:s_hbird|Valentin Roux, a silver-ring courtier of the Gilded Court, may be Embracing mortals at parties and abandoning them. He holds salons in the Orangery on the Reliquary roof.}
@end

# hbP.0 arc=tenant night=3,4 label="Priya. Find out what she remembers about the man." if=flag:priya&!flag:knowRoux prio=3
@focus tenant
tenant: The girl from behind the Golden Dragon. Priya. She'll remember the man who did it. They always do. It's the last thing they saw with a heartbeat.
> You find her where you left her. She's learned to hunt, a little. She's learned to stop.
priya: The man. Yes. He had curly hair and a coat like a bruise and a voice like a radio presenter. He said I had "an architecture to my face". He said he'd make me immortal. He did. Then he put me in the river.
priya: He called himself Val. He said it like it was a joke.
{do flag:knowRoux=1; task:s_hbird; note:s_hbird|The man who Embraced Priya called himself Val. Curly hair, a bruise-colored coat, a hummingbird ring. Lisette would know.}
@end

# hb.roux
> The Orangery on the roof of Club Reliquary: a Victorian glasshouse, panes painted black on the outside, full of palms and dead orchids and velvet sofas. A record player playing something with no tune. Four mortal art students asleep in a heap on a chaise like puppies, with small bandages on their wrists.
> On a wicker throne in the middle, a young man with dark curly hair and a coat the color of a bruise, sketching one of the students in charcoal.
valentin: Oh! A visitor! The infamous visitor. Come, come in, sit, you have a fascinating architecture to your face, has anyone told you?
pulse(5): Four mortal hearts, all slow, all fed on tonight. Not drained. He's careful with these ones. These ones he keeps.
* "You said that to Priya."  -> hb.priya {if flag:priya}
* "How many have you made, Valentin?"  -> hb.many
* Look at the drawings.  -> hb.draw

# hb.draw
> On the easel behind him, a stack of charcoal portraits. Girls, boys, mostly twenty or so. Thirty, forty of them. Every one beautifully drawn. On some, in the corner, a small cross.
autopsy(6): The crosses. A tally. The ones with crosses are the ones who didn't come back up out of the river.
@next hb.many

# hb.priya
valentin: Priya. Priya. Oh, I remember Priya. Wonderful cheekbones. Did she live? She did? Oh, how lovely! I always hope they do. It's so much nicer when they do.
@next hb.many

# hb.many
valentin: Made? Oh, darling, I don't *make*. I *offer*. At a party, at three in the morning, to someone beautiful who's told me they're afraid of getting old. I give them forever. What they do with it is their business.
valentin: Some climb out of the river. Most don't. That's not cruelty, that's selection. The ones who climb out are the ones who were meant to.
valentin: Séverine knows. Séverine thinks it's charming. She calls it my "little gardening".
* "That's not gardening. That's murder with extra steps."  -> hb.murder
* "The Prince's law forbids an Embrace without sanction."  -> hb.law
* "Show me the drawings with crosses."  -> hb.crosses

# hb.crosses
> He hands them over without a second thought. Twenty-three faces with crosses. A boy in a football scarf. A girl with a nose ring. A young man in a graduation gown.
web(6): Twenty-three. Embraced, abandoned, drowned or burned at dawn without knowing what they were. Every one of them a missing persons report on Miller's desk.
@next hb.law

# hb.murder
valentin: Murder! What a mortal word. They were going to die anyway. Everyone mortal is. I just... chose the hour. And gave them a chance.
@next hb.law

# hb.law
valentin: The Prince's law. The Prince hasn't been seen since 1912. Laws are what Séverine says they are, and Séverine says I'm charming.
valentin: Are you going to tell on me? To whom? You're on trial on Friday, darling. Nobody will believe a word you say.
* "I'll tell the Magistrate. In the chalk. With the drawings."  -> hb.mag
* "You'll take responsibility. For every one who lived. Priya, and the rest. You'll be their sire, properly."  -> hb.sire
* "I'll give you to Séverine. Let her decide how charming you are."  -> hb.sev {if alive:sev}
* Burn the drawings. Then him.  -> hb.kill {blood}
* "Stop. Tonight. And I'll never mention it."  -> hb.stop {do lean:mercy+0}

# hb.mag
valentin: The Magistrate. Ambrose. Oh, he'd... oh. Oh, he would, wouldn't he. He's so dreadfully *literal*.
> For the first time, he looks frightened.
> You take the drawings. All of them. He doesn't try to stop you.
{do flag:rouxDrawings=1; flag:rouxDone=1; give:rouxdrawings; note:s_hbird|You have Valentin Roux's drawings: twenty-three faces with crosses. The Magistrate should see them.}
@end

# hb.sire
valentin: Sire. Properly. You mean... feed them? Teach them? Visit them? On *Tuesdays*?
? apex 11 "On Tuesdays. And Thursdays. Every one who climbed out. Or I take your ring to Ambrose."  -> hb.sireok | hb.sireno {id hb_apex} {red}
? velvet 12 "You said you offer them forever. Forever with nobody to show them how is just drowning slowly."  -> hb.sireok | hb.sireno {id hb_vel}

# hb.sireok
> He looks at the drawings without crosses. Seventeen of them. Seventeen faces, alive somewhere in the Ward, in storage units and sewers and the backs of cars, hungry and alone.
valentin: ...Seventeen. I never... I never counted the ones without crosses. Only the ones with.
valentin: Fine. Fine. Tuesdays. I'll find them. I'll... I'll make a list. I'm very good at lists, actually. Nobody knows that about me.
{do flag:rouxSires=1; flag:rouxDone=1; task:s_hbird=done; xp:90:The Hummingbird Ring; lean:mercy+1}
@end

# hb.sireno
valentin: No. No, I don't think I will. I think I'll take my chances with Ambrose. He's never once believed a neonate.
@next hb.law

# hb.sev
> You take him down to the VIP by the elbow. He doesn't struggle. He chatters the whole way about orchids.
> Séverine looks at him, and at the drawings, and at you. Her face does nothing.
severine: Valentin. Go to the crypt. Get in a coffin. Shut the lid.
valentin: My lady, I...
severine: SHUT THE LID.
> He goes. When he's gone she looks at the drawings for a long time. She stops at the boy in the graduation gown.
severine: ...I thought it was music. Parties. Little sips. "Gardening." I never once asked what he was growing.
severine: Thank you. I hate you for this, and thank you. He'll be in Lisbon by Sunday, without his ring.
{do flag:rouxSev=1; flag:rouxDone=1; task:s_hbird=done; xp:70:The Hummingbird Ring; rel:severine+1}
@end

# hb.kill
> The drawings go first, in the stove that heats the glasshouse. Then the record player, because you can't stand the music. Then Valentin, who tries to talk the whole time, about architecture and forever and selection, until he can't.
> The art students sleep through it, in a heap, like puppies.
{do kill; feed:4:Sanguine:Valentin Roux:kindred; flag:rouxDead=1; flag:rouxDone=1; task:s_hbird=done; xp:60:The Hummingbird Ring; lean:mercy-1; heat+1; flag:sevAngryRoux=1}
tenant: Séverine's second favorite, in one week. You know she'll know whose hands. You know what she'll do.
@end

# hb.stop
valentin: Stop. My gardening. Just like that.
valentin: ...Oh, very well. It was getting boring anyway. Everyone at parties is so young now. They all want to talk about their mental health.
{do flag:rouxStopped=1; flag:rouxDone=1; task:s_hbird=done; xp:40:The Hummingbird Ring}
@end
`,'c_hummingbird');
NL.ITEMS.rouxdrawings={n:'Twenty-Three Charcoal Drawings',type:'read',d:'Faces, beautifully done, each with a small cross in the corner. A boy in a football scarf. A girl with a nose ring. A young man in a graduation gown. Valentin Roux\'s tally of the ones who didn\'t climb out of the river.'};
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
  if(G.has('rouxdrawings'))M.push({t:'Lay the charcoal drawings in the chalk, one by one. Twenty-three faces with crosses.',once:'tb_roux',ok:(st,S)=>{st.prog+=2;return [T('The Magistrate looks at every one. It takes a long time. Nobody on the platform moves.'),L('magistrate','Valentin Roux. Stand.'),T('In the Gilded benches, a young man with curly hair stands, very slowly, with his silver hummingbird ring on his finger.'),L('magistrate','A matter for another night. But it will be another night. Sit down, and do not leave the city.'),L('severine',S.flags.sevDead?'':'(very quietly) ...I didn\'t know. I didn\'t ask.',{if:S=>!S.flags.sevDead})];}});
  return M;};
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.rouxSires)o.push(['Valentin Roux','Visits seventeen of his childer every Tuesday and Thursday, with a list and a thermos. He is terrible at it. Priya says he\'s getting better. She says he cried, once, in a storage unit on Kerr Street, when one of them said thank you.']);
  else if(f.rouxSev)o.push(['Valentin Roux','Lisbon, without his ring. Séverine had the glasshouse on the Reliquary roof pulled down. The orchids were already dead.']);
  else if(f.rouxDead)o.push(['Valentin Roux','Ash in a glasshouse full of dead orchids. Four art students woke up the next evening with bandages on their wrists and no idea why.']);
  if(f.priya)o.push(['Priya',f.rouxSires?'Has a sire who comes on Tuesdays, badly. Has a box at Gideon\'s. Has learned to stop.':'Has learned to stop. Has never once eaten another cat.']);
  return o;});
})();
