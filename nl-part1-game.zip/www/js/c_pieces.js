'use strict';
/* THE NEW LORD — "Pieces": what comes back of the person you were before the freezer, and what you decide to do with it */
(function(){
NL.TASKS.s_pieces={n:'Pieces',xp:30,cat:'side'};
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];const k=['pcBeach','pcLibrary','pcCots','pcForm','pcBad'].filter(x=>f[x]==='keep').length,g=['pcBeach','pcLibrary','pcCots','pcForm','pcBad'].filter(x=>f[x]==='give').length,l=['pcBeach','pcLibrary','pcCots','pcForm','pcBad'].filter(x=>f[x]==='let').length;
  if(k+g+l===0)return o;
  if(k>=3)o.push(['Casey Morrow, before','Came back in pieces, and you kept them: a beach, a library, a ward full of cots, a form signed for five hundred dollars, a bad year and the sister who drove through it. They don\'t fit together yet. You carry them anyway, in the inside pocket, where the wallet was.']);
  else if(g>=3)o.push(['Casey Morrow, before','You gave the pieces to him to keep, one by one, and he keeps them, very carefully, in the study with the brown rug. When you want them, you ask. He always gives them back.']);
  else if(l>=3)o.push(['Casey Morrow, before','Let go, piece by piece. A beach. A library. A bad year. You decided you didn\'t need them to be who you are now. Some nights you\'re sure that was right.']);
  return o;});
})();
NL.Script.add(String.raw`
// =====================================================================
// THE BEACH · from the cab driver's wallet
// =====================================================================
# pc.beach arc=tenant night=2,3,4,5 label="Look at the photograph in the wallet again." if=flag:gotWallet&!flag:pcBeach prio=3
@focus tenant
> Two kids on a beach. The older one laughing at a dog. The younger one, maybe six, scowling at the camera with sand on their face and a bucket on their head.
> You look at it for a long time. And then the photograph isn't a photograph any more.
> Saltmarsh, August. The smell of suncream and vinegar. Robin, eleven, holding a crab in a bucket and screaming. Dad behind the camera saying "smile, Case, smile," and you refusing, because there's sand in your eyes and you're furious about it. A dog. A big stupid golden dog called Captain who is trying to eat the crab.
> Mom, out of shot, laughing so hard she has to sit down on the cool box.
nostalgia(4): Captain. The dog was called Captain. He died when you were fourteen. You cried for a week and Robin let you sleep in her room.
{do task:s_pieces}
tenant: ...That's yours. That's not mine. I never had a beach. What do you want to do with it?
* Keep it. Hold onto it.  -> pc.beachK
* "You keep it. Somewhere safe. I'll ask for it back."  -> pc.beachG
* Let it go. It's too much to carry this week.  -> pc.beachL

# pc.beachK
> You keep it. The sand. The crab. The dog. It sits in your chest, warm, like a stone that's been in the sun.
{do flag:pcBeach=keep; comp+3:The beach; sync-2}
@end

# pc.beachG
tenant: I'll keep it. In the study. On the mantelpiece, next to Agnes's letters. I'll dust it.
{do flag:pcBeach=give; comp+1; sync+2}
@end

# pc.beachL
> You let it go. It goes the way a dream goes when you wake: all at once, and then you can't remember what it was you've forgotten.
> The photograph is just a photograph. Two kids on a beach. A dog.
{do flag:pcBeach=let; comp-1; sync+1}
@end

// =====================================================================
// THE LIBRARY · from the card
// =====================================================================
# pc.lib arc=tenant night=3,4,5 label="Something about the library card in the wallet." if=flag:gotWallet&flag:pcBeach&!flag:pcLibrary prio=2
@focus tenant
> The library card, the name rubbed off. Central Library. A barcode. A tiny photo that's mostly glare.
> The reading room on the second floor. Green lamps. The radiator that knocks. Ten minutes to closing every night, and you, at the end of the long table, reading about lighthouses, because you wanted to be a lighthouse keeper when you were nine and somehow you never stopped.
> The librarian, a tall man with a ponytail, flicking the lights twice at five to eight. "Morrow. Closing." Every night. You never once left before he flicked the lights.
nostalgia(5): Lighthouses. Fresnel lenses. The Bell Rock. Eddystone. Keepers who went mad from the quiet. You knew all of it. You used to recite it on the bus.
tenant: Lighthouses. Of course. A whole life arranged around a light you could look at.
* Keep it.  -> pc.libK
* Give it to him.  -> pc.libG
* Let it go.  -> pc.libL

# pc.libK
{do flag:pcLibrary=keep; comp+2:The reading room; sync-2}
@end

# pc.libG
tenant: The reading room. I'll put it by the fire. I'll read about lighthouses. I've never read about lighthouses.
{do flag:pcLibrary=give; sync+2}
@end

# pc.libL
{do flag:pcLibrary=let; sync+1}
@end

// =====================================================================
// THE COTS · the study ward
// =====================================================================
# pc.cots arc=tenant night=3,4,5 label="The book on the cots. Dani." if=seen:ox2r.book|flag:met404&flag:knowName&night>=4 prio=2
@focus tenant
> It comes back on its own. You didn't ask for it.
> The fourth floor of St. Jude's. A ward with the windows painted over. Twelve cots. A television on a bracket showing a cookery program with the sound off. The smell of antiseptic and toast.
> A girl in the next cot, twenty-two, with her hair up in a scarf, reading the book you lent her. *The Idiot.* She keeps reading bits out loud. She keeps laughing in the wrong places.
> "Casey. CASEY. Prince Myshkin is such a disaster. He's like you. He keeps saying sorry to people who are robbing him."
> You laugh. You're warm. It's the first time in a year you've been warm. You've got five hundred dollars coming on Friday, and a bed, and toast, and someone to laugh with.
> The girl is Dani Okafor. In eleven days she'll stand in the sun for twenty-two minutes.
tenant: ...You were happy there. In the study. Before. You were happy.
* Keep it. Even that. Especially that.  -> pc.cotsK
* Give it to him. You can't hold it.  -> pc.cotsG
* Let it go.  -> pc.cotsL

# pc.cotsK
> You keep it. It hurts. It's the most important thing you have.
{do flag:pcCots=keep; comp+2:Dani laughing; sync-3; mem:okafor:cots}
@end

# pc.cotsG
tenant: I'll keep her. Laughing. In the study, in the visitor's chair, where Leo sat when you dreamed him. She can laugh at my rug.
{do flag:pcCots=give; sync+2}
@end

# pc.cotsL
{do flag:pcCots=let; comp-2; sync+2}
@end

// =====================================================================
// THE FORM · October
// =====================================================================
# pc.form arc=tenant night=4,5 label="He says there's a piece about October." if=flag:pcCots|has:lanternfile|flag:rostovaTestify prio=2
@focus tenant
tenant: There's another piece. It's been sitting at the back, behind the cots. I don't think you'll like it. I think you should see it anyway.
> October. The free clinic on the ground floor of St. Jude's. A cough you've had for a month. No insurance. Rostova in a white coat, tired, kind, looking at your chart.
> "There's a trial," she says. "Upstairs. It's blood work, mostly. It pays five hundred a session. Bed and meals for the duration. You'd be helping."
> You sign. You don't read it. You haven't read anything you've signed in two years. You sign *Casey Morrow* in the box and think: Robin's going to be so relieved I've got a job.
> You never told Robin. You were going to tell her when you'd saved enough to pay her back.
web(6): Pay her back. For what? There's a debt there, behind the bad year. Something she paid for that you were ashamed of.
* Keep it.  -> pc.formK
* Give it to him.  -> pc.formG
* Let it go.  -> pc.formL

# pc.formK
{do flag:pcForm=keep; comp+1; sync-2}
@end

# pc.formG
tenant: The form. Signed. I'll file it. I was a notary, once. I'm good at forms.
{do flag:pcForm=give; sync+2}
@end

# pc.formL
{do flag:pcForm=let; sync+1}
@end

// =====================================================================
// THE BAD YEAR · the hardest piece
// =====================================================================
# pc.bad arc=tenant night=4,5 label="The last piece. The bad year." if=flag:pcForm&flag:sisterTalked|flag:pcForm&seen:sr.canttell prio=3
@focus tenant
tenant: This one. You'll want to sit down for this one, if you can sit down inside your own head.
> A bad year. Two years, really. Pills first, from a back injury at a job you lost. Then not pills. Then an apartment with no furniture and a mattress and a phone you didn't answer.
> Robin, at three in the morning, in her car outside, in her pyjamas, with the engine running, having driven eighty miles because you'd texted her one word and then turned your phone off.
> Robin, sitting on the end of the mattress, not shouting. Not crying. Just sitting there. Saying "okay. Okay, Case. We're going home." Paying the rent you owed. Paying for the clinic. Paying for the program. Never once mentioning it again.
> You'd been clean nineteen months when you signed the form in October. You'd been clean nineteen months and you still couldn't look her in the eye, and you thought five hundred dollars a session might fix that.
tenant: ...Child.
> That's all he says. For a long time.
* Keep it. It's yours. It's the truest piece.  -> pc.badK
* Give it to him. He's carried worse.  -> pc.badG
* Let it go. You've been carrying it long enough.  -> pc.badL

# pc.badK
> You keep it. All of it. The mattress. The car outside. Robin's hand on your ankle through the blanket.
tenant: Good. That's the one that makes you who you are. Not the freezer. That. Somebody came for you at three in the morning. You know what that's worth, now. That's why you go back for people.
{do flag:pcBad=keep; comp+3:Robin came; sync-3; task:s_pieces=done; xp:60:Pieces}
@end

# pc.badG
tenant: I'll keep it. I'll keep it in the safest place I have, which is next to my own worst year. 1720. They'll get on. They'll have a lot to talk about.
{do flag:pcBad=give; sync+3; task:s_pieces=done; xp:40:Pieces}
@end

# pc.badL
> You let it go. It's harder than the others. It doesn't go all at once. It goes slowly, like a car pulling away down a long road at three in the morning, its tail lights getting smaller.
> And then you don't remember why you go back for people. You just do.
{do flag:pcBad=let; sync+2; task:s_pieces=done; xp:30:Pieces}
@end
`,'c_pieces');
