'use strict';
/* THE NEW LORD — "In the Car": when Pemberton drives you, he sometimes talks. Not often. When he does, it's worth listening. */
NL.Script.add(String.raw`
# car.navy street=2,3,4,5 if=flag:carOK&!flag:carGone&alive:pemberton&!flag:pembertonGone w=3
> The back of the Bentley. Leather that smells of eighty years of the same cologne. The blinds down. Pemberton's eyes in the mirror, on the road, never on you.
pemberton: You'll forgive me, ‹sir›. One shouldn't talk while driving. But the Sheriff used to like a story on the longer journeys.
* "Tell me how you met him."  -> car.n1
* "Silence is fine, Pemberton."  -> car.n0

# car.n0
pemberton: Very good, ‹sir›.
> The car hums. The city goes by behind the blinds. It's the most peaceful thing that's happened all night.
{do comp+1}
@end

# car.n1
pemberton: 1983. I was twenty-three. I'd just been put off a merchant ship in the Vellum docks for punching a second officer, who deserved it. I was sitting on a bollard on Pier Nine with one good suit and eleven dollars.
pemberton: A tall gentleman in dark glasses sat down on the next bollard and said: "Can you drive?" I said I could drive anything with an engine. He said: "Good. I need a man who isn't afraid of the dark." I said I'd been at sea for five years and the dark was the only thing I wasn't afraid of.
pemberton: He gave me the keys to this car that night. I've never given them back.
* "Did you know what he was?"  -> car.n2
* "Pier Nine. Six years after Rask."  -> car.n3 {if mem:tenant.rask}

# car.n2
pemberton: Not for a week. Then he asked me to drive him to a funeral at four in the morning, and then a christening at five, and both of them were in cellars. I put two and two together.
pemberton: I stayed. People ask why. I never had an answer that wasn't "he asked me to."
{do rel:pemberton+1}
@end

# car.n3
pemberton: ...Yes. He went there every year. On the anniversary. To sit on Rask's bollard. I didn't know that until later. I thought he'd just gone for some air.
tenant: (very quietly) I had. I'd gone for some air. And I found a man who wasn't afraid of the dark.
{do rel:pemberton+1; sync+1}
@end

# car.1977 street=3,4,5 if=flag:carOK&!flag:carGone&alive:pemberton&!flag:pembertonGone&rel:pemberton>=2
> The car, the blinds, the mirror. Pemberton clears his throat.
pemberton: ‹Sir›. I've driven you all week and I've noticed you never ask the question everybody asks.
* "What question?"  -> car.q1

# car.q1
pemberton: "Do you drink from him?" Everyone asks. The Court asks it with their eyebrows. Leo asked it with his whole face on Monday.
pemberton: I do. I did. Every Sunday. A sip, from his wrist, in this car, parked by the river. For forty-one years. That's why I look as I do.
pemberton: I haven't since last Sunday. It's been six days. I can feel it already. In my knees. In my hands on the wheel.
* "Do you want it from me?"  -> car.q2
* "What happens if you stop?"  -> car.q3

# car.q2
> His hands tighten on the wheel. For a long moment, he says nothing. The car goes through a red light. He doesn't seem to notice.
pemberton: ...From you. The Sheriff's blood, in someone else's wrist.
pemberton: No. Thank you. No. Not yet. I think... I think I'd like to see what six days feels like. And then seven. I've never once wondered what I'd be without it.
{do rel:pemberton+2; lean:restraint+1}
@end

# car.q3
pemberton: I grow old. Quickly, then slowly. I'll be sixty-four by Easter, properly. My knees will go. My eyes. My hands on the wheel.
pemberton: I'm told it's quite pleasant, being old. Everybody I knew from the ship who's still alive says so. They all have grandchildren and allotments and complain about their hips.
{do rel:pemberton+1}
@end

# car.rules street=2,3,4 if=flag:carOK&!flag:carGone&alive:pemberton&!flag:pembertonGone
> The car. The blinds. Pemberton signals left, though there's nobody else on the road at four in the morning.
pemberton: The Sheriff had rules for the car, ‹sir›. I don't know whether you'd like to keep them. I'll tell you them, and you can decide.
pemberton: One: the window stays down an inch, always, even in the rain. He liked to smell the city. Two: no feeding in the back seat. Ever. Three: if he fell asleep before we got home, I was to drive round the Heights until he woke, and not wake him.
* "Keep all three."  -> car.r1
* "Keep the window. Lose the others."  -> car.r2
* "No rules, Pemberton. Just drive."  -> car.r3

# car.r1
pemberton: Very good, ‹sir›. The window.
> He lowers it an inch. The city comes in: rain, diesel, chip fat, the river. You hadn't noticed how much you'd missed it.
{do rel:pemberton+1; sync+1}
@end

# car.r2
pemberton: The window. Yes. I'd have kept that one anyway.
> He lowers it an inch.
{do rel:pemberton+1}
@end

# car.r3
pemberton: No rules. Very good, ‹sir›.
> He doesn't lower the window. After a while, you notice he's driving a little faster, and humming.
@end

# car.galway street=4,5 if=flag:carOK&!flag:carGone&alive:pemberton&!flag:pembertonGone&flag:pemResigns
> The car. The blinds. Pemberton, for the first time all week, is driving with one hand.
pemberton: I looked at the cottage on the computer last night. Galway. My sister's. It has a yellow door. There's a seagull on the roof in the photograph. I've decided it's the same seagull and it's waiting for me.
pemberton: I've never had a door of my own. Forty-one years of other people's doors.
{do comp+1}
@end
`,'c_car');
