'use strict';
/* THE NEW LORD — reactions, part three: people notice the choices you made this week, and tell you what they think of them */
NL.Script.add(String.raw`
# rx3.leoNell arc=leo night=4,5 label="\"Leo. I did something on the 9.\"" if=flag:nell=dead&alive:leo prio=2
@focus leo
leo: The 9? The bus? What... what did you do on a bus?
> You tell him. A girl. Three weeks dead. Starving. Earl, the driver. What you did.
leo: Oh.
leo: Oh. Okay. Okay. Was she going to... was she going to hurt him? Earl?
* "Yes. Probably. Tonight or tomorrow."  -> rx3.leoNell1
* "I don't know. I didn't wait to find out."  -> rx3.leoNell2

# rx3.leoNell1
leo: Then you... okay. Then you saved him. That's... that's a way of looking at it.
leo: I'm going to look at it that way. I'm going to have to look at it really hard that way for a while. Give me a minute.
{do rel:leo-1}
@end

# rx3.leoNell2
leo: You didn't wait. Okay.
> He doesn't say anything else. He doesn't need to. You can see him put it somewhere, carefully, the way you'd put away a knife.
{do rel:leo-2; lean:mercy-1}
@end

# rx3.leoNine arc=leo night=4,5 label="\"Leo. I helped a bus driver ask a woman out.\"" if=flag:earlDolores=2&alive:leo prio=1
@focus leo
leo: You what? You... the vampire Sheriff of the Marrow Ward... set up a bus driver? On a date?
leo: That's the best thing I've ever heard. That's going in the act. That's the closer. "My friend's undead. Last week they ate a Sheriff. This week they're doing matchmaking on public transit."
leo: Pancakes. On Kerr Street. Oh my God. That's the diner Miller goes to. They're going to run into Miller. It's going to be amazing.
{do rel:leo+1; comp+1}
@end

# rx3.milPact arc=miller night=5 label="\"Partners, Miller. Tonight.\"" if=flag:pact=mortal&!flag:millerDead prio=3
@focus miller
miller: Partners. Yeah. I've got the seven files in the trunk. I've got a federal judge's home number on a Post-it. I've got a sandwich.
miller: If you're not out of there by four, I'm coming down those stairs. I don't care what's down there. I've been to the Switchyard. I know where the stairs are.
* "Don't. Whatever happens. Don't come down."  -> rx3.milPact1
* "If I'm not out by four, come down."  -> rx3.milPact2

# rx3.milPact1
miller: Don't. Okay. Okay. I won't.
> She's lying. You can both tell. Neither of you says anything about it.
{do rel:miller+1}
@end

# rx3.milPact2
miller: Four. Okay. I'll set an alarm. Ray used to set alarms. I'd always turn them off.
miller: I won't turn this one off.
{do rel:miller+2; flag:millerFour=1}
@end

# rx3.tarDogs arc=tariq night=4,5 label="\"Have the dogs been back, Tariq?\"" if=flag:racketDone=dogs&alive:tariq prio=1
@focus tariq
tariq: Every night. Not all of them. Three or four. They sit outside the door from midnight till six and they don't let anyone in who smells wrong.
tariq: I've started buying dog biscuits. The good ones. From the pet shop on Kerr. I've never had a dog. Now I've got four, and they're not mine, and they're not anyone's.
tariq: My mother says it's a sign. She won't say of what.
{do rel:tariq+1; comp+1}
@end

# rx3.tarUnion arc=tariq night=4,5 label="\"Is Local 0 still picketing, Tariq?\"" if=flag:racketDone=union&alive:tariq prio=1
@focus tariq
tariq: Picketing. There's a man called Little Sal sitting on a crate outside my door every night with a sign that says THIS SHOP IS UNIONIZED. Nobody knows what it means. Business has doubled.
tariq: He doesn't buy anything. He brings his own soup. Nobody eats the soup. He says it's not about the soup.
{do rel:tariq+1; comp+1}
@end

# rx3.pemBlood arc=pemberton night=4,5 label="\"Pemberton. You've been looking at me in the mirror.\"" if=flag:pact=lantern&!flag:lanternBack prio=3
@focus pemberton
pemberton: I can't see you in the mirror, ‹sir›. I look anyway. Forty years' habit.
pemberton: You've made an arrangement with the federal man. I don't know what. I can smell it on you. Peppermint.
pemberton: I won't ask. It isn't my place. But I'll say this, ‹sir›, once, because the Sheriff never let me say anything once. The blood decides who I serve. It doesn't decide whether I'm proud of it.
* "I can still take it back."  -> rx3.pemBlood1
* "It's the right thing, Pemberton."  -> rx3.pemBlood2

# rx3.pemBlood1
pemberton: Then I'd take it back, ‹sir›. Before the morning. Mornings are when you find out what you've done.
{do rel:pemberton+1}
@end

# rx3.pemBlood2
pemberton: Very good, ‹sir›.
> He says it in exactly the voice he'd use to tell you the car is ready. He doesn't look in the mirror again for the rest of the drive.
{do rel:pemberton-2}
@end

# rx3.gidClan arc=gideon night=3,4,5 label="\"Gideon. You keep looking at my hands.\"" if=flag:carveScar|flag:carveLesson prio=-1
@focus gideon
gideon: Your palm. That's a Butcher's lesson. I've seen that line on a dozen hands across this counter. Malakor does it to all his nephews. It's the first thing he teaches and the last thing they forget.
gideon: He did it to a boy in 1991. Nice boy. Wanted to be a sculptor. Became a surgeon instead, for the Syndicate, and was never happy a day in his life.
gideon: Be careful what Malakor teaches you. He's very good at teaching. He's less good at knowing when to stop.
{do mem:gideon:butcher}
@end

# rx3.sootMem arc=soot night=3,4,5 label="\"Mother. The memory I gave you.\"" if=flag:sootMemPaid prio=1
@focus soot
soot: In a jar. On the shelf. Do you want to visit it? People do. They come down and sit next to it. They can't remember what's in it. They sit with it anyway.
* "Can I have it back?"  -> rx3.sootMem1
* "Keep it. It's yours."  -> rx3.sootMem2

# rx3.sootMem1
soot: Back. Hm. Nobody's ever asked for one back. Not in sixty years.
soot: ...No. No. A trade's a trade. But I'll tell you one thing about it, for free. It was warm. Whatever it was. It was warm the whole way down the pipe.
{do comp+1}
@end

# rx3.sootMem2
soot: Mine. Yes. I'll keep it warm. I keep all of them warm. That's the only thing I'm good for, really. Keeping things warm that nobody else remembers.
{do rel:soot+1}
@end

# rx3.okaLight arc=okafor night=4,5 label="\"Mrs. Okafor. The landing light.\"" if=flag:msgRosDone&flag:msgRos=exact prio=-1
@focus okafor
okafor: It's on. It'll be on when I'm dead. I've told Joyce next door: if I go, you leave that light on. She said, "Mrs. O, the bill." I said, "I'll haunt you."
okafor: I told the doctor. Rostova. I went to St. Jude's on Thursday and I sat in her office and I said: thank you for telling me. Through your friend. She cried. I didn't. Isn't that funny? Since August I've been the one crying.
{do rel:okafor+1; rel:rostova+1; comp+1}
@end

# rx3.ashJoke arc=ashby night=4,5 label="\"Ashby. Everyone's repeating my mirror joke.\"" if=flag:gildedJoke&!flag:ashbyDead&!flag:ashbyGone prio=-1
@focus ashby
ashby: Of course they are. I told it at four separate dinners. I credited you at three of them. At the fourth I pretended it was mine and the Seneschal laughed so hard she had to be helped from the room.
ashby: You've made a reputation, darling. Not a big one. Not a frightening one. A *funny* one. In this Court, that's worth more than a body count. Nobody ever stakes the funny one. They need someone to talk to at parties.
{do rel:ashby+1}
@end

# rx3.valFront arc=valko night=4,5 label="\"How's the front seat, Valko?\"" if=flag:valkoFront&!flag:valkoDead prio=-1
@focus valko
valko: Too small. My knees are by my ears. The old man drives with the window down an inch on my side. He thinks I don't know it's for me.
valko: He's reading the newspaper out loud again. To himself. For his diction. I'm learning the words. *Council. Zoning. Pothole.* Halloran Street has a pothole. It's been there since 2009.
{do rel:valko+1; rel:pemberton+1}
@end
`,'c_react3');
