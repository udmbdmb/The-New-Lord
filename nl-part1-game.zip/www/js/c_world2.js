'use strict';
/* THE NEW LORD — the world changes, part two: walking back into places after this week's choices */
(function(){const E=NL.Act.pushEnter,C=NL.Script.cond;
const on=(room,id,cond)=>{const c=C(cond);E(room,async(S,G)=>{if(S.flags['wd2_'+id])return;if(!c(S,G))return;S.flags['wd2_'+id]=1;await G.talk('wd2.'+id);});};
on('luckymart','dogs','flag:racketDone=dogs&night>=4');
on('luckymart','sal','flag:racketDone=union&night>=4');
on('luckymart','cruller','flag:tariqToldMiller');
on('pawn','nell','flag:nell=gideon');
on('pawn','watch','flag:leoWatchGiven');
on('vip','dogs2','flag:leoMoo');
on('shrine','wick','flag:wickLit');
on('shrine','kyrie','flag:kyrieGiven');
on('stjude','note','flag:rosRelief');
on('rookery','light','flag:msgRosDone&flag:msgRos=exact');
on('alley','napkin','flag:leoNapkin&night>=4');
on('switchyard','coaster','flag:local0Sheriff&night>=4');
on('reliquary','mirror','flag:gildedJoke&night>=4');
on('apt','lasagne','flag:leoMomText');
on('pawn','box11','flag:sevToSoot&night>=5');
on('alley','peas','flag:sweetPeas');
on('stjude','bay','flag:law_carry|flag:hyMedic=1&past:paramedic&night>=4');
})();
NL.Script.add(String.raw`
# wd2.dogs
> Four dogs outside the Lucky Mart, lying in a row along the wall under the awning, out of the rain. A pit bull with a torn ear lifts his head as you pass and puts it down again. Inside, on the counter, a box of dog biscuits with the price label still on.
@end

# wd2.sal
> Outside the Lucky Mart, on an upturned crate, a very large man in a knit hat with a hand-painted sign: THIS SHOP IS UNIONIZED. He nods to you. You nod back. Inside, Tariq is serving a line of six people, which has never happened at this hour.
@end

# wd2.cruller
> On the counter, by the till, a plate with a cruller on it. Whole. Untouched. A sticky note on the plate in Miller's handwriting: *FOR TOMORROW. I'LL FINISH IT. — I.M.*
@end

# wd2.nell
> Behind the counter of the Pawn & Coffin, on Gideon's stool, a girl in a too-big Gilded coat is pricing pocket watches with a jeweler's loupe in one eye. She waves without looking up. Gideon, from the back, is teaching her the difference between gold and gold-plated, loudly, and she's arguing.
@end

# wd2.watch
> The space under the counter where a gold watch used to sit is empty. Gideon has put a small card there instead, in copperplate: *L.P. — PAID IN JOKES (ONGOING).*
@end

# wd2.dogs2
> At the door of the VIP crypt, Gaston, very formally, holding a silver tray. On the tray: a single folded card in purple ink. *Knock knock.* Nothing else. Séverine, on her sarcophagus, is pointedly not looking at you.
@end

# wd2.wick
> On the black water of the cistern, among Soot's hundred candles, one tallow candle has drifted all the way to the far wall, where the old ticket hall used to be. It's still burning. It's not supposed to be able to get there. Soot says it goes back every night.
@end

# wd2.kyrie
> Through the pipes, very faint, from three streets away: a woman's voice humming forty-one bars of a Kyrie in an old mode. Mother Soot is sitting very still on her step with a bone microphone to her ear and her eyes closed. She doesn't say anything. She doesn't need to.
@end

# wd2.note
> On the fourth floor of St. Jude's, taped to the door of Dr. Rostova's office: a drawing of a lightbulb in colored pencil, very large, very yellow, done carefully by somebody who doesn't usually draw. Underneath, in neat handwriting: *FOR THE DOCTOR. FROM MRS. OKAFOR (AND DANI).*
@end

# wd2.light
> On the fourth floor of the Rookery, the landing light outside 404 is on, as always. Somebody has put a little brass plaque under the switch, the kind you can get engraved at the key-cutting place on Kerr Street: *PLEASE LEAVE ON.*
@end

# wd2.napkin
> On the wall of Ferrier Lane, by the back door of Kowalski's, somebody has taped a Lucky Mart napkin in a plastic sandwich bag. A frog in a coat, in biro. Underneath, in marker: *IF FOUND, THIS IS MY FRIEND. — L.P.*
@end

# wd2.coaster
> On the cast-iron pillar at the bottom of the Switchyard stairs, at eye level, somebody has nailed a bar coaster. *L0 · 1 WK · PAID · THE SHERIFF.* Under it, in the same pencil, smaller, a column of ticks. Sixty-three of them. One for every member who's come down the stairs and touched it for luck.
@end

# wd2.mirror
> Above the bar at the Reliquary, where there used to be a long gilt mirror, there's a gap on the wall the shape of a mirror. A small brass plate has been screwed into the plaster in the middle of it: *THE GOOD MIRROR · RESERVED.* Lord Ashby, at the bar, raises his glass to you without turning round.
@end

# wd2.lasagne
> On the kitchen counter in Leo's apartment, a foil dish with a Post-it on the lid in a mother's handwriting: *LEONARD. HEAT AT 350 FOR 40 MIN. EAT ALL OF IT. CALL ME. — MOM.* It's half gone. There's a fork in it.
@end

# wd2.bay
> The ambulance bay behind St. Jude's. By the door, on the concrete, a paper cup of coffee with a lid on it, still warm, and a note in a paramedic's block capitals: *FOR WHOEVER BRINGS THEM IN. — R.O.*
@end

# wd2.box11
> Box eleven, at the back of the Pawn & Coffin, has a white rose on its lid. No card. Gideon, at the counter, doesn't mention it and doesn't need to. He's been keeping that box empty since 1999, and he's just found out why. Somebody came in at dawn, he says, in an evening coat and rubber boots, and asked if she could sit in it for an hour with the lid open. She paid in gold. She left the rose.
@end

# wd2.peas
> In the back of the Continental, parked on Ferrier Lane with the engine idling, a seed tray on the passenger seat. Twenty little pots, each with a handwritten label on a popsicle stick: SWEET PEA · MARGARET · 2004. 2005. 2006. Pemberton, behind the wheel, is reading a gardening book with his glasses on the end of his nose, and doesn't hear you until you knock on the window.
@end
`,'c_world2');
