'use strict';
/* THE NEW LORD — procedural canvas textures */
(function(){
const NL=window.NL;
function rng(seed){let a=seed>>>0;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function cv(w,h){const c=document.createElement('canvas');c.width=w;c.height=h||w;return c;}
const rgb=(r,g,b,a)=>a==null?`rgb(${r|0},${g|0},${b|0})`:`rgba(${r|0},${g|0},${b|0},${a})`;
function speckle(x,w,h,R,n,col,amin,amax,smin,smax){for(let i=0;i<n;i++){x.fillStyle=col(R);x.globalAlpha=amin+R()*(amax-amin);const s=smin+R()*(smax-smin);x.beginPath();x.arc(R()*w,R()*h,s,0,7);x.fill();}x.globalAlpha=1;}
function blotch(x,w,h,R,n,col,a,smin,smax){for(let i=0;i<n;i++){const cx=R()*w,cy=R()*h,r=smin+R()*(smax-smin);const g=x.createRadialGradient(cx,cy,0,cx,cy,r);g.addColorStop(0,col(R,a));g.addColorStop(1,col(R,0));x.fillStyle=g;x.fillRect(cx-r,cy-r,r*2,r*2);
  for(const ox of [-w,w])for(const oy of [-h,0,h]){x.save();x.translate(ox,oy);x.fillRect(cx-r,cy-r,r*2,r*2);x.restore();}
  for(const oy of [-h,h]){x.save();x.translate(0,oy);x.fillRect(cx-r,cy-r,r*2,r*2);x.restore();}}}
const F={
  steel(){const c=cv(512),x=c.getContext('2d'),R=rng(11);x.fillStyle='#7f8d95';x.fillRect(0,0,512,512);
    for(let i=0;i<900;i++){x.fillStyle=R()<.5?'rgba(255,255,255,.05)':'rgba(0,10,20,.06)';x.fillRect(0,R()*512,512,1+R()*2);}
    for(let p=0;p<4;p++){const px=p*128;const g=x.createLinearGradient(px,0,px+128,0);g.addColorStop(0,'rgba(255,255,255,.10)');g.addColorStop(.5,'rgba(255,255,255,0)');g.addColorStop(1,'rgba(0,0,0,.14)');x.fillStyle=g;x.fillRect(px,0,128,512);
      x.fillStyle='#3e474d';x.fillRect(px,0,4,512);x.fillStyle='rgba(220,235,245,.35)';x.fillRect(px+4,0,2,512);
      for(let r=0;r<8;r++){x.fillStyle='#4a545a';x.beginPath();x.arc(px+12,r*64+20,3.5,0,7);x.fill();x.fillStyle='rgba(230,240,250,.5)';x.beginPath();x.arc(px+11,r*64+19,1.4,0,7);x.fill();}}
    for(let i=0;i<40;i++){const sx=R()*512,sy=R()*512,l=40+R()*140;const g=x.createLinearGradient(0,sy,0,sy+l);g.addColorStop(0,'rgba(200,225,240,.0)');g.addColorStop(.3,'rgba(200,225,240,.18)');g.addColorStop(1,'rgba(200,225,240,0)');x.fillStyle=g;x.fillRect(sx,sy,2+R()*3,l);}
    blotch(x,512,512,R,10,(R,a)=>`rgba(40,48,40,${a})`,.12,30,90);return c;},
  concrete(){const c=cv(512),x=c.getContext('2d'),R=rng(5);x.fillStyle='#6f7476';x.fillRect(0,0,512,512);
    blotch(x,512,512,R,40,(R,a)=>R()<.5?`rgba(40,45,50,${a})`:`rgba(160,170,175,${a})`,.18,30,120);
    speckle(x,512,512,R,2500,R=>R()<.5?'#3a3f42':'#a9b1b5',.2,.5,.5,1.8);
    x.strokeStyle='rgba(25,28,30,.55)';x.lineWidth=1.4;for(let i=0;i<5;i++){x.beginPath();let px=R()*512,py=R()*512;x.moveTo(px,py);for(let k=0;k<9;k++){px+=(R()-.5)*60;py+=(R()-.3)*40;x.lineTo(px,py);}x.stroke();}
    x.strokeStyle='rgba(30,30,35,.35)';x.lineWidth=3;x.strokeRect(0,0,512,512);return c;},
  quarry(){const c=cv(512),x=c.getContext('2d'),R=rng(7);x.fillStyle='#3a2622';x.fillRect(0,0,512,512);
    for(let i=0;i<4;i++)for(let j=0;j<4;j++){const v=R();x.fillStyle=rgb(150+v*40,62+v*20,46+v*14);x.fillRect(i*128+4,j*128+4,120,120);
      const g=x.createLinearGradient(i*128,j*128,i*128+128,j*128+128);g.addColorStop(0,'rgba(255,220,200,.10)');g.addColorStop(1,'rgba(40,10,5,.18)');x.fillStyle=g;x.fillRect(i*128+4,j*128+4,120,120);
      if(R()<.3){x.fillStyle='rgba(30,10,8,.35)';x.beginPath();x.arc(i*128+8+R()*110,j*128+8+R()*110,3+R()*6,0,7);x.fill();}}
    blotch(x,512,512,R,14,(R,a)=>`rgba(60,10,10,${a})`,.22,20,80);
    speckle(x,512,512,R,1500,R=>R()<.5?'#5a2a20':'#d08a6a',.15,.35,.5,1.5);return c;},
  checker(){const c=cv(512),x=c.getContext('2d'),R=rng(9);x.fillStyle='#2a2826';x.fillRect(0,0,512,512);
    for(let i=0;i<4;i++)for(let j=0;j<4;j++){const dark=(i+j)%2===1,v=R()*.08;x.fillStyle=dark?rgb(36+v*120,34+v*110,36+v*110):rgb(212-v*200,204-v*200,184-v*200);x.fillRect(i*128+3,j*128+3,122,122);}
    blotch(x,512,512,R,26,(R,a)=>`rgba(70,58,40,${a})`,.24,20,90);speckle(x,512,512,R,900,()=>'#151413',.1,.3,.6,2);return c;},
  subway(){const c=cv(512),x=c.getContext('2d'),R=rng(13);x.fillStyle='#8b8f86';x.fillRect(0,0,512,512);
    for(let r=0;r<16;r++)for(let k=-1;k<8;k++){const off=r%2?32:0,v=R()*.07;x.fillStyle=rgb(226-v*300,229-v*300,214-v*300);x.fillRect(k*64+off+2,r*32+2,60,28);
      const g=x.createLinearGradient(0,r*32,0,r*32+32);g.addColorStop(0,'rgba(255,255,255,.35)');g.addColorStop(1,'rgba(0,0,0,.08)');x.fillStyle=g;x.fillRect(k*64+off+2,r*32+2,60,28);}
    blotch(x,512,512,R,12,(R,a)=>`rgba(120,110,70,${a})`,.18,30,90);x.strokeStyle='rgba(60,60,50,.25)';x.lineWidth=.8;
    for(let i=0;i<14;i++){x.beginPath();let px=R()*512,py=R()*512;x.moveTo(px,py);for(let k=0;k<4;k++){px+=(R()-.5)*30;py+=(R()-.5)*30;x.lineTo(px,py);}x.stroke();}return c;},
  plaster(){const c=cv(512),x=c.getContext('2d'),R=rng(17);x.fillStyle='#8d9c86';x.fillRect(0,0,512,512);
    blotch(x,512,512,R,40,(R,a)=>R()<.6?`rgba(70,85,65,${a})`:`rgba(190,200,170,${a})`,.2,30,140);
    for(let i=0;i<8;i++){const sx=R()*512;const g=x.createLinearGradient(0,0,0,512);g.addColorStop(0,'rgba(90,70,40,.18)');g.addColorStop(1,'rgba(90,70,40,0)');x.fillStyle=g;x.fillRect(sx,0,6+R()*16,200+R()*300);}
    speckle(x,512,512,R,800,()=>'#5d6a58',.1,.3,.5,2);return c;},
  brick(){const c=cv(512),x=c.getContext('2d'),R=rng(21);x.fillStyle='#4a3d36';x.fillRect(0,0,512,512);
    for(let r=0;r<14;r++){const rh=512/14,off=r%2?64:0;for(let k=-1;k<4;k++){const v=R();x.fillStyle=rgb(118+v*50,52+v*24,38+v*18);x.fillRect(k*128+off+3,r*rh+3,122,rh-6);
      if(R()<.4){x.fillStyle='rgba(20,10,8,.3)';x.fillRect(k*128+off+3+R()*100,r*rh+3,10+R()*20,rh-6);}}}
    blotch(x,512,512,R,18,(R,a)=>`rgba(20,20,25,${a})`,.3,30,120);speckle(x,512,512,R,1200,()=>'#c48a70',.1,.3,.5,1.4);return c;},
  asphalt(){const c=cv(512),x=c.getContext('2d'),R=rng(31);x.fillStyle='#26272b';x.fillRect(0,0,512,512);
    speckle(x,512,512,R,6000,R=>R()<.5?'#3d3e44':'#121215',.3,.8,.4,1.6);blotch(x,512,512,R,25,(R,a)=>`rgba(10,10,12,${a})`,.35,30,120);return c;},
  wood(){const c=cv(512),x=c.getContext('2d'),R=rng(41);for(let p=0;p<8;p++){const v=R();x.fillStyle=rgb(92+v*30,58+v*18,36+v*10);x.fillRect(0,p*64,512,64);
      for(let k=0;k<30;k++){x.strokeStyle=`rgba(40,22,12,${.1+R()*.2})`;x.lineWidth=1;x.beginPath();const y=p*64+R()*64;x.moveTo(0,y);x.bezierCurveTo(170,y+(R()-.5)*8,340,y+(R()-.5)*8,512,y);x.stroke();}
      x.fillStyle='rgba(20,10,5,.6)';x.fillRect(0,p*64,512,2);}return c;},
  cardboard(){const c=cv(256),x=c.getContext('2d'),R=rng(51);x.fillStyle='#9a7a52';x.fillRect(0,0,256,256);blotch(x,256,256,R,10,(R,a)=>`rgba(80,55,30,${a})`,.25,20,60);
    x.fillStyle='rgba(200,180,140,.5)';x.fillRect(0,118,256,20);x.fillStyle='rgba(60,40,20,.5)';x.font='bold 22px "Barlow Condensed",sans-serif';x.fillText('PORK STOCK',60,80);x.fillText('THIS SIDE UP ↑',70,190);return c;},
  bloodbag(){const c=cv(128),x=c.getContext('2d');x.fillStyle='#5a0a12';x.fillRect(0,0,128,128);const g=x.createLinearGradient(0,0,128,128);g.addColorStop(0,'rgba(255,90,90,.35)');g.addColorStop(1,'rgba(0,0,0,.3)');x.fillStyle=g;x.fillRect(0,0,128,128);
    x.fillStyle='#e9e2d0';x.fillRect(22,40,84,40);x.fillStyle='#222';x.font='bold 14px "Barlow Condensed",sans-serif';x.fillText('PORK STOCK',30,58);x.font='italic 15px Caveat,cursive';x.fillStyle='#8a1520';x.fillText('B-neg',44,75);return c;},
  chalk(){const c=cv(512,384),x=c.getContext('2d'),R=rng(61);x.fillStyle='#1d2420';x.fillRect(0,0,512,384);blotch(x,512,384,R,20,(R,a)=>`rgba(200,210,200,${a})`,.06,30,120);
    x.strokeStyle='#5a3c22';x.lineWidth=18;x.strokeRect(9,9,494,366);x.fillStyle='rgba(235,235,225,.92)';
    x.font='600 44px "Bodoni Moda",serif';x.textAlign='center';x.fillText("Today's Cuts",256,72);
    x.font='34px Caveat,cursive';x.textAlign='left';const L=[['Pork chops','4.99'],['Brisket','8.49'],['Pig trotters','1.29'],['Tongue','(ask Margo)'],['Soup bones','free w/ purchase']];
    L.forEach((l,i)=>{x.fillText(l[0],40,124+i*44);x.textAlign='right';x.fillText(l[1],470,124+i*44);x.textAlign='left';});
    x.font='24px Caveat,cursive';x.fillStyle='rgba(230,160,160,.9)';x.fillText('No credit. No questions.',150,356);return c;},
  blood(){const c=cv(256),x=c.getContext('2d'),R=rng(71);x.clearRect(0,0,256,256);
    for(let i=0;i<26;i++){const cx=128+(R()-.5)*120*(i>5?1.4:.6),cy=128+(R()-.5)*120*(i>5?1.4:.6),r=i<5?18+R()*24:2+R()*8;x.fillStyle=rgb(90+R()*40,6,14,.75+R()*.25);x.beginPath();x.arc(cx,cy,r,0,7);x.fill();}
    for(let i=0;i<10;i++){x.strokeStyle='rgba(110,8,16,.7)';x.lineWidth=2+R()*3;x.beginPath();x.moveTo(128,128);const a=R()*7,l=50+R()*70;x.lineTo(128+Math.cos(a)*l,128+Math.sin(a)*l);x.stroke();}return c;},
  ash(){const c=cv(256),x=c.getContext('2d'),R=rng(81);const g=x.createRadialGradient(128,128,10,128,128,120);g.addColorStop(0,'rgba(120,118,115,.95)');g.addColorStop(.55,'rgba(95,92,90,.75)');g.addColorStop(1,'rgba(80,78,78,0)');x.fillStyle=g;x.fillRect(0,0,256,256);
    speckle(x,256,256,R,1200,R=>R()<.6?'#3a3836':'#cfccc6',.3,.8,.5,1.8);return c;},
  frost(){const c=cv(256),x=c.getContext('2d'),R=rng(91);const g=x.createLinearGradient(0,256,0,0);g.addColorStop(0,'rgba(225,240,250,.9)');g.addColorStop(.5,'rgba(220,238,250,.35)');g.addColorStop(1,'rgba(220,238,250,0)');x.fillStyle=g;x.fillRect(0,0,256,256);
    x.strokeStyle='rgba(245,252,255,.6)';for(let i=0;i<120;i++){const sx=R()*256,sy=150+R()*106;x.lineWidth=.6+R();x.beginPath();x.moveTo(sx,sy);x.lineTo(sx+(R()-.5)*20,sy-R()*40);x.stroke();}return c;},
  grime(){const c=cv(256),x=c.getContext('2d');const g=x.createRadialGradient(128,128,0,128,128,128);g.addColorStop(0,'rgba(20,14,12,.55)');g.addColorStop(1,'rgba(20,14,12,0)');x.fillStyle=g;x.fillRect(0,0,256,256);return c;},
  puddle(){const c=cv(256),x=c.getContext('2d'),R=rng(97);x.fillStyle='rgba(0,0,0,0)';for(let i=0;i<7;i++){const cx=128+(R()-.5)*90,cy=128+(R()-.5)*60,r=30+R()*50;const g=x.createRadialGradient(cx,cy,0,cx,cy,r);g.addColorStop(0,'rgba(120,140,170,.55)');g.addColorStop(.8,'rgba(60,70,90,.35)');g.addColorStop(1,'rgba(60,70,90,0)');x.fillStyle=g;x.fillRect(0,0,256,256);}return c;},
  drain(){const c=cv(128),x=c.getContext('2d');x.fillStyle='#1b1c1e';x.beginPath();x.arc(64,64,40,0,7);x.fill();x.strokeStyle='#5d6266';x.lineWidth=5;x.stroke();x.fillStyle='#5d6266';for(let i=-3;i<=3;i++)x.fillRect(64+i*10-1.5,30,3,68);return c;},
  neon(){const c=cv(512,128),x=c.getContext('2d');x.clearRect(0,0,512,128);x.font='italic 700 78px "Bodoni Moda",serif';x.textAlign='center';x.shadowColor='#ff3050';x.shadowBlur=22;x.fillStyle='#ff9aa8';
    x.save();x.translate(512,0);x.scale(-1,1);x.fillText("Kowalski's",256,92);x.restore();return c;},
  sign24(){const c=cv(512,128),x=c.getContext('2d');x.fillStyle='#e9e1cf';x.fillRect(0,0,512,128);x.strokeStyle='#7a1018';x.lineWidth=8;x.strokeRect(6,6,500,116);x.fillStyle='#7a1018';x.font='700 54px "Barlow Condensed",sans-serif';x.textAlign='center';x.fillText("BROOKER'S 24-HOUR MEATS",256,62);x.font='italic 28px "Bodoni Moda",serif';x.fillStyle='#2a2422';x.fillText('We never close.',256,104);return c;},
  missing(){const c=cv(256,340),x=c.getContext('2d'),R=rng(101);x.fillStyle='#ece6d6';x.fillRect(0,0,256,340);x.fillStyle='#111';x.font='800 52px "Barlow Condensed",sans-serif';x.textAlign='center';x.fillText('MISSING',128,56);
    x.fillStyle='#b8b2a2';x.fillRect(58,72,140,150);x.fillStyle='#6e675c';x.beginPath();x.ellipse(128,135,38,48,0,0,7);x.fill();x.fillRect(80,180,96,42);
    x.fillStyle='#222';x.font='600 24px "Barlow Condensed",sans-serif';x.fillText('HAVE YOU SEEN ME?',128,252);x.font='18px Spectral,serif';x.fillText('Last seen: The Marrow Ward',128,280);x.fillText('Call PVPD · Det. Miller',128,306);
    x.fillStyle='rgba(120,100,60,.25)';for(let i=0;i<6;i++)x.fillRect(R()*256,R()*340,30,8);return c;},
  graffiti(){const c=cv(512,256),x=c.getContext('2d');x.clearRect(0,0,512,256);x.font='italic 800 92px "Bodoni Moda",serif';x.fillStyle='rgba(190,30,50,.85)';x.textAlign='center';x.fillText('who drinks',256,110);
    x.font='800 72px "Barlow Condensed",sans-serif';x.fillStyle='rgba(220,210,190,.8)';x.fillText('THE MARROW WARD?',256,200);x.strokeStyle='rgba(190,30,50,.8)';x.lineWidth=6;x.beginPath();x.moveTo(40,220);x.lineTo(470,226);x.stroke();return c;},
  tv(){const c=cv(128,96),x=c.getContext('2d'),R=rng(111);const d=x.createImageData(128,96);for(let i=0;i<d.data.length;i+=4){const v=R()*200+30;d.data[i]=v*.8;d.data[i+1]=v*.9;d.data[i+2]=v;d.data[i+3]=255;}x.putImageData(d,0,0);
    x.fillStyle='rgba(20,40,80,.4)';x.fillRect(0,0,128,96);x.fillStyle='#f5f0e0';x.font='700 13px "Barlow Condensed",sans-serif';x.fillText('7TH MISSING · SHAMBLES',8,86);return c;},
  ledger(){const c=cv(128),x=c.getContext('2d');x.fillStyle='#5a1a1a';x.fillRect(0,0,128,128);x.fillStyle='#e8dcc0';x.fillRect(8,8,112,112);x.strokeStyle='rgba(60,60,120,.4)';for(let i=0;i<10;i++){x.beginPath();x.moveTo(12,20+i*10);x.lineTo(116,20+i*10);x.stroke();}return c;},
  sticky(){const c=cv(128),x=c.getContext('2d');x.fillStyle='#f0d860';x.fillRect(0,0,128,128);x.fillStyle='#333';x.font='22px Caveat,cursive';x.fillText('IF COURT',14,40);x.fillText('CALLS — WE',14,68);x.fillText('ARE CLOSED',14,96);return c;},
  wetfloor(){const c=cv(128,160),x=c.getContext('2d');x.fillStyle='#f2c418';x.fillRect(0,0,128,160);x.fillStyle='#111';x.font='800 26px "Barlow Condensed",sans-serif';x.textAlign='center';x.fillText('CAUTION',64,40);x.font='700 20px "Barlow Condensed",sans-serif';x.fillText('WET FLOOR',64,140);
    x.beginPath();x.arc(64,86,22,0,7);x.fill();x.fillStyle='#f2c418';x.font='800 28px sans-serif';x.fillText('!',64,96);return c;},
  mirror(){const c=cv(256),x=c.getContext('2d'),R=rng(121);const g=x.createLinearGradient(0,0,256,256);g.addColorStop(0,'#b9c6c8');g.addColorStop(.5,'#6d7c80');g.addColorStop(1,'#a4b2b4');x.fillStyle=g;x.fillRect(0,0,256,256);
    speckle(x,256,256,R,300,()=>'#2b3032',.2,.6,.5,2);x.fillStyle='rgba(255,255,255,.25)';x.beginPath();x.moveTo(30,0);x.lineTo(90,0);x.lineTo(20,256);x.lineTo(0,256);x.fill();return c;},
  car(){const c=cv(256),x=c.getContext('2d');x.fillStyle='#121216';x.fillRect(0,0,256,256);const g=x.createLinearGradient(0,0,0,256);g.addColorStop(0,'rgba(140,150,180,.35)');g.addColorStop(.4,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(60,60,90,.2)');x.fillStyle=g;x.fillRect(0,0,256,256);return c;}
};
const cache={};
NL.Tex={get(k){if(!cache[k]){if(!F[k])throw new Error('tex '+k);cache[k]=F[k]();}return cache[k];},rng,add(k,fn){F[k]=fn;},cv,speckle,blotch};
})();
