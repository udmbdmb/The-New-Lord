'use strict';
/* THE NEW LORD — campaign layer: five nights, dawn, havens, travel between blocks, phone texts, promises, mutations */
(function(){
const NL=window.NL,G=NL.G,A=NL.Audio;
const $=s=>document.querySelector(s),esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const NIGHTS=NL.NIGHTS=NL.NIGHTS||{};
const PLACES=NL.PLACES=NL.PLACES||[];
const NAMES=['One','Two','Three','Four','Five'];
const DAYFULL=['Monday','Tuesday','Wednesday','Thursday','Friday'];
const Camp={};NL.Camp=Camp;

/* ---------- dawn ---------- */
Camp.tickHooks=[];
Camp.afterTick=function(){const S=G.S;if(!S.flags.woke||S.chapter==='end')return;Camp.tickHooks.forEach(f=>{try{f(S,G);}catch(e){console.error(e);}});
  if(S.time>=450&&G.once('dawnwarn'+S.night)){setTimeout(()=>G.toast('hurt','Half an hour to sunrise. Get to a haven.','Sundial'),400);A.sfx('sting');}
  if(S.time>=420&&G.once('dawnwarn1_'+S.night))setTimeout(()=>G.toast('task','Dawn in an hour. Start thinking about where you\'ll sleep.','Sundial'),600);
  if(S.time>=480&&!Camp.sleeping){Camp.pendingDawn=true;Camp.tryDawn();}};
Camp.tryDawn=function(){if(!Camp.pendingDawn||Camp.sleeping)return;if(G.busy){setTimeout(Camp.tryDawn,700);return;}Camp.pendingDawn=false;G.gameOver('sunrise');};

/* ---------- havens & the turn of the night ---------- */
Camp.canSleep=function(S){const n=NIGHTS[S.night];if(S.time>=330)return true;return n&&n.canSleep?n.canSleep(S):S.time>=240;};
Camp.sleep=async function(hav){const S=G.S;if(Camp.sleeping)return;if(hav&&hav===S.flags.havenLost&&hav!=='car'){await G.say([{t:'It\'s ash and wet plaster and the smell of gas. You can\'t sleep here any more.'}]);return;}Camp.sleeping=true;
  try{
    S.hav=hav;S.flags['haven_'+S.night]=hav;G.task('haven','done');
    const n=NIGHTS[S.night];
    G.cine(true);A.music(null);
    if(n&&n.cliff)await n.cliff(G,S,hav);
    if(NL.Script&&S.night<5)await NL.Script.dream(S);
    if(S.night>=5){Camp.sleeping=false;return;}
    await G.fade(1,1.2);G.blackout(true);
    await Camp.nightSummary(S);
    // the turn of the night
    const prev=S.night;S.night++;S.time=0;
    S.res=null;S.shatter=null;S.flags.scavNow=0;
    G.vitae(-1,true);if(S.vitae<2){S.vitae=2;S.flags.wokeStarved=S.night;}
    if(G.thought('golconda')&&!(S.lethal[prev]>0))G.comp(1,'The Golconda Delusion');else S.comp=Math.min(G.compMax(),S.comp+2);
    if(S.heat>0&&!S.flags['heatHold'+S.night])S.heat=Math.max(0,S.heat-(G.thought('absolutist')?2:1)+(NIGHTS[S.night]&&NIGHTS[S.night].heatAdd?NIGHTS[S.night].heatAdd(S):0));
    else if(NIGHTS[S.night]&&NIGHTS[S.night].heatAdd)S.heat=Math.min(5,S.heat+NIGHTS[S.night].heatAdd(S));
    S.chapter='night'+S.night;G.refresh();
    const nx=NIGHTS[S.night];
    await G.card(`Night ${NAMES[S.night-1]}`,`${DAYFULL[S.night-1]} · 9:00 PM${nx&&nx.sub?' · '+nx.sub:''}`,{k:nx&&nx.title?nx.title:'The New Lord',cls:'loc',hold:3.4});
    G.blackout(false);
    if(nx&&nx.start)await nx.start(G,S,hav);
    else{await G.enterRoom(Camp.havenRoom(hav).room,Camp.havenRoom(hav).spawn,{instant:true});}
    G.cine(false);G.autosave();
  }finally{Camp.sleeping=false;}};
Camp.HAVENS={freezer:{room:'freezer',spawn:{x:3.1,z:3.15,ry:Math.PI/4},n:'Kowalski\'s walk-in'},pawn:{room:'pawn',spawn:{x:6.8,z:3.6,ry:-2.4},n:'A coffin-box at the Pawn & Coffin'},rookery:{room:'rookery',spawn:{x:7.6,z:1.4,ry:3},n:'The sniper nest in the Rookery'},shrine:{room:'shrine',spawn:{x:2,z:3,ry:0},n:'Mother Soot\'s shrine'},crypt:{room:'vip',spawn:{x:4,z:4,ry:3},n:'A guest coffin in the VIP crypt'},leo:{room:'rookery',spawn:{x:2.2,z:1.4,ry:3},n:'Leo\'s couch'}};
Camp.havenRoom=h=>Camp.HAVENS[h]||Camp.HAVENS.freezer;
Camp.nightSummary=async function(S){
  const ov=$('#nightsum');if(!ov)return;
  const n=S.night,done=Object.keys(S.tasks).filter(k=>S.tasks[k]==='done'&&(S.flags['taskNight_'+k]||0)===0).length;
  const rows=[['Fed',S.feeds?`${S.feeds} time${S.feeds>1?'s':''} so far`:'Not yet'],['Killed',S.kills?String(S.kills):'No one'],['Heat',`${S.heat} / 5`],['Diablerie Sync',`${Math.round(S.sync)}%`],['Cash',`$${S.cash||0}`]];
  ov.innerHTML=`<div class="ns"><div class="mk">Dawn · ${DAYFULL[n-1]}</div><h2>${esc((NIGHTS[n]&&NIGHTS[n].endTitle)||'You sleep.')}</h2><p>${esc((NIGHTS[n]&&NIGHTS[n].endLine&&NIGHTS[n].endLine(S))||'The sun comes up over the Marrow Ward without you.')}</p><dl>${rows.map(r=>`<dt>${esc(r[0])}</dt><dd>${esc(r[1])}</dd>`).join('')}</dl><button class="bigbtn" id="nsGo">Night ${NAMES[n]||''}</button></div>`;
  ov.hidden=false;requestAnimationFrame(()=>ov.classList.add('in'));A.sfx('dawn');
  await new Promise(r=>{$('#nsGo').onclick=()=>{A.sfx('click');r();};});
  ov.classList.remove('in');await G.sleep(500);ov.hidden=true;};

/* ---------- travel ---------- */
// PLACES entries: {id,name,block,room,spawn,sub,open(S),locked(S)->string|null}
const BLOCKS={A:'Block A · The Abattoir Strip',B:'Block B · Reliquary Row',C:'Block C · St. Jude\'s & the Rookery',D:'Block D · The Sunken Switchyard'};
Camp.BLOCKS=BLOCKS;
Camp.here=function(){const S=G.S;const p=PLACES.find(p=>p.room===S.room)||PLACES.find(p=>(p.rooms||[]).includes(S.room));return p;};
Camp.canMap=function(){const R=NL.ROOMS[G.S.room];return !!(R&&R.map)&&G.S.flags.mapOK;};
Camp.cost=function(from,to){const S=G.S;let m=from&&from.block===to.block?6:(Math.abs('ABCD'.indexOf(from?from.block:'A')-'ABCD'.indexOf(to.block))>1?24:16);if(S.flags.carOK&&!S.flags.carGone&&from&&from.block!==to.block)m=Math.max(6,m-8);if(S.night===4&&from&&from.block!==to.block)m+=10;return m;};
Camp.openMap=function(){const S=G.S;if(G.busy)return;if(!Camp.canMap()){G.toast('task','Go outside first. You can only travel from the street.','Map');return;}
  const ov=$('#map');const here=Camp.here();
  const list=PLACES.filter(p=>!p.hidden||p.hidden(S)===false).filter(p=>!p.open||p.open(S));
  let html=`<div class="mp"><header><div><div class="mk">Port Vellum · the Marrow Ward</div><h2>Where to?</h2><p>${S.flags.carOK&&!S.flags.carGone?'Pemberton has the car running.':'On foot, under the streetlights.'} ${S.night===4?'UV floodlights sweep the crossings tonight.':''}</p></div><button id="mpX" aria-label="Close">✕</button></header>`;
  for(const b of 'ABCD'){const ps=list.filter(p=>p.block===b);if(!ps.length)continue;html+=`<section><h4>${esc(BLOCKS[b])}</h4>`;
    for(const p of ps){const lk=p.locked&&p.locked(S);const isHere=here&&here.id===p.id;const c=Camp.cost(here,p);
      html+=`<button class="mpp ${isHere?'here':''}" data-pl="${p.id}" ${lk||isHere?'disabled':''}><b>${esc(p.name)}</b><span>${esc(lk||p.sub||'')}</span><em>${isHere?'You are here':`${c} min`}</em></button>`;}
    html+='</section>';}
  const hn=S.flags['hunts'+S.night]||0,late=S.time>=450;
  html+=`<section class="mpact"><h4>Or spend the time</h4><button class="mpp" id="mpHunt" ${hn>=2||late||(S.night===5&&S.flags.tribunalDone)?'disabled':''}><b>Hunt</b><span>${hn>=2?'You\'ve pushed your luck enough tonight.':'Find blood somewhere nearby. Every choice costs something.'}</span><em>${S.night===4?45:30} min</em></button><button class="mpp" id="mpWait" ${late?'disabled':''}><b>Wait</b><span>Let the night move on. Somewhere dark, somewhere out of the way.</span><em>30 min</em></button></section>`;
  html+='</div>';ov.innerHTML=html;ov.hidden=false;ov.scrollTop=0;requestAnimationFrame(()=>ov.classList.add('in'));A.sfx('page');
  $('#mpX').onclick=Camp.closeMap;
  ov.querySelectorAll('[data-pl]').forEach(b=>b.onclick=()=>Camp.travel(b.dataset.pl));
  const hb=$('#mpHunt');if(hb)hb.onclick=()=>{Camp.closeMap();A.sfx('click');setTimeout(()=>G.talk('hunt.0'),250);};
  const wb=$('#mpWait');if(wb)wb.onclick=()=>{Camp.closeMap();A.sfx('click');G.tick(30);G.toast('task',`It\'s ${G.clockStr()}.`,'Thirty minutes pass');};};
Camp.closeMap=function(){const ov=$('#map');ov.classList.remove('in');setTimeout(()=>{if(!ov.classList.contains('in'))ov.hidden=true;},300);};
Camp.travel=async function(id){const S=G.S;const p=PLACES.find(x=>x.id===id);if(!p)return;const here=Camp.here();Camp.closeMap();
  if(p.before){const r=await p.before(S,G);if(r===false)return;}
  const c=Camp.cost(here,p);G.tick(c);
  if(Camp.pendingDawn)return;
  for(const f of (Camp.onTravel||[])){const r=await f(S,G,p,here);if(r===false)return;}
  A.sfx(S.flags.carOK&&!S.flags.carGone&&here&&here.block!==p.block?'door':'step');
  await G.enterRoom(p.room,p.spawn);};
Camp.onTravel=[];

/* ---------- texts ---------- */
G.text=(from,body,o)=>{const S=G.S;S.texts.push({from,body,t:G.clockStr(),n:S.night});G.toast('dos',`<b>${esc(from)}</b>: ${esc(body.length>70?body.slice(0,68)+'…':body)}`,'New text · burner phone');A.sfx('ring');};
Camp.textsHTML=function(){const S=G.S;if(!S.texts.length)return '<p>No messages.</p>';return S.texts.slice().reverse().map(m=>`<p><b>${esc(m.from)}</b> <small>Night ${m.n} · ${esc(m.t)}</small><br>${esc(m.body)}</p>`).join('');};

/* ---------- promises (Alchemists) ---------- */
G.promise=(id,what)=>{const S=G.S;if(S.promises[id])return;S.promises[id]={what,kept:null};if(S.clan==='alchemists')G.toast('task',`Sworn: ${esc(what)}`,'Contract Bound');};
G.keep=id=>{const S=G.S;if(S.promises[id])S.promises[id].kept=true;};
G.breakPromise=id=>{const S=G.S;const p=S.promises[id];if(!p||p.kept===false)return;p.kept=false;if(S.clan==='alchemists'){G.vitae(-3);G.toast('hurt','You broke your word. Your blood boils: −3 Vitae','Contract Bound');G.shake(1);}};

/* ---------- Diablerie Sync ---------- */
G.sync=(d,why)=>{const S=G.S;S.sync=Math.max(0,Math.min(100,S.sync+d));if(d>0)G.toast('rel',`Diablerie Sync ${Math.round(S.sync)}%`,why||'The Tenant settles in');};

/* ---------- quest helpers ---------- */
G.q=(k,v)=>{const S=G.S;if(v===undefined)return S.quests[k];S.quests[k]=v;};

/* ---------- map button ---------- */
document.addEventListener('click',e=>{const b=e.target.closest('[data-p="map"]');if(b){e.stopPropagation();A.sfx('click');Camp.openMap();}},true);
Camp.refreshMapBtn=()=>{const b=$('[data-p="map"]');if(b)b.classList.toggle('dim',!Camp.canMap());};
setInterval(Camp.refreshMapBtn,800);
})();
