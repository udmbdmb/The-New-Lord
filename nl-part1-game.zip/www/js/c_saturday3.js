'use strict';
/* THE NEW LORD — Saturday, more visits; and how the Ward remembers you */
(function(){const O=NL.Script.opt;
O('sat.hub','* Dr. Rostova, fourth floor, St. Jude\'s.  -> sat3.ros {once} {if alive:rostova&!flag:rostovaFled&!flag:satVisit3}','start');
O('sat.hub','* Tiny, on the door at the Reliquary, for the first time since Friday.  -> sat3.tiny {once} {if !flag:tinyGone&!flag:tinyBetrayed&!flag:satVisit3}','start');
O('sat.hub','* Margo, at Kowalski\'s, which has its lights on.  -> sat3.margo {once} {if !flag:margoDead&rel:margo>=1&!flag:satVisit3}','start');
O('sat.hub','* Father Dominic\'s chapel.  -> sat3.dom {once} {if !flag:dominicDead&flag:metDominic&!flag:satVisit3}','start');
O('sat.hub','* The wall behind the Golden Dragon.  -> sat3.wen {once} {if flag:wenMet|flag:wenWater&!flag:satVisit3}','start');
})();
NL.Script.add(String.raw`
# sat3.ros
> Fourth floor, St. Jude's. Her office door is open. For the first time since you've known her, the blinds are up and the window is open, and she's sitting at her desk eating a proper sandwich, not yoghurt.
rostova: The Sheriff. Of course. Come in. Don't sit on the files; they're not mine any more. Federal agents came this afternoon and took everything. They were very polite. One of them said please.
@gate flag:cohortRos ? sat3.ros1 : sat3.ros2

# sat3.ros1
rostova: Marisol and Jerome came at eight. Like they promised. I took bloods. Marisol's hands were warmer. Only by a degree. One degree.
rostova: I'm going to try every night. I've written to the medical council, too. Not about this. About going back to pediatrics. I'll be the oldest junior doctor in the state.
{do comp+2; rel:rostova+1}
@next sat.count

# sat3.ros2
rostova: I don't know what happens now. I'm a doctor who confessed to murder in a court that doesn't exist. Nobody's arrested me. Nobody's fired me. I came in this evening and did my ward round, because there was nobody else to do it.
* "Keep doing the ward round."  -> sat3.ros3

# sat3.ros3
rostova: Yes. Yes, I think I will. Bed nine has a little girl. She asked me if I was a vampire because I'm so pale. I said no. She said "good, because my mommy says they're not real." I said her mommy was very wise.
{do comp+1; rel:rostova+1}
@next sat.count

# sat3.tiny
> The rope. The queue. The rain. Tiny, on the door, in his best coat. He sees you coming up Reliquary Row and opens the rope before you get there.
tiny: Evening, boss.
> He doesn't call you anything else. He doesn't need to.
@gate flag:tinyDoor ? sat3.tiny1 : sat3.tiny2

# sat3.tiny1
tiny: Last night on this rope. Monday I'm on your door. The study. Me and the old man. We've already argued about where the chair goes.
{do comp+1}
@next sat.count

# sat3.tiny2
tiny: Marc's got his windows. Mom's crying. Not the bad kind. The kind where she keeps saying "look at the light, Tiny, look at the light" about a bedroom window.
tiny: Go on. Go in. They're waiting for you downstairs. All of them. They'll stand up when you walk in. I want to see their faces.
{do comp+2}
@next sat.count

# sat3.margo
> Kowalski's has its lights on, at nine on a Saturday night, which it never does. Through the window: Margo, in an apron, behind the counter, and Leo, in another apron, looking terrified, holding a string of sausages like it might bite him. {if alive:leo}
> Kowalski's has its lights on, at nine on a Saturday night, which it never does. Through the window: Margo, in an apron, behind the counter, alone, wiping it down. {if !alive:leo}
margo: We're open late. A butcher's. Just a butcher's. Mince and sausages and nothing in the walk-in but meat. I've put a new release on the inside of the door. Gideon fitted it.
margo: Do you want to see? You don't have to. I'd understand.
* Look at the walk-in.  -> sat3.mg1
* "No. I believe you."  -> sat3.mg2

# sat3.mg1
> She opens the door. The walk-in. Steel walls, hooks, frost, the smell of cold. Where you woke up. Where he burned.
> On the inside of the door, at hand height, a brand new brass release, polished, with a little engraved plate under it that Gideon must have done: *FROM THE INSIDE. ALWAYS.*
> You push it. The door swings open. It's the simplest thing in the world.
{do comp+3:From the inside}
@next sat.count

# sat3.mg2
margo: Believe me. Hm. Nobody's believed me since 1979.
> She goes back to wiping the counter. She's smiling. She doesn't want you to see.
{do comp+1}
@next sat.count

# sat3.dom
> The chapel. The bad electric candle. Father Dominic in the front pew with a crossword. He doesn't look up.
dominic: Ah. You're alive. Well. You know what I mean.
dominic: Eight down. "Not burned, after all." Nine letters. Starts with S.
* "Spared."  -> sat3.dom1
* "Sheriff."  -> sat3.dom2

# sat3.dom1
dominic: Six letters. Bad luck. ...Ha. No. It's "survivors". I've been staring at it all evening.
dominic: Sit down. Stay a while. You can be in the back or the front. I don't mind which. Neither does He.
{do comp+2}
@next sat.count

# sat3.dom2
dominic: Seven letters. And not what the clue says at all. But I'll write it in. In pencil.
{do comp+1}
@next sat.count

# sat3.wen
> The wall behind the Golden Dragon. Old Wen, sitting very straight, with a takeaway carton. He hands it to you without looking.
wen: Duck. The cook put in extra tonight. He said the poor old fellow looked like he was celebrating something.
wen: Two fish in a bowl. Still. I can hear you both. Quieter. Not one. Not drowning. Swimming. Good.
wen: Seven hundred years. You're the first I've seen do it in a week.
{do comp+2; sync+1}
@next sat.count
`,'c_saturday3');

/* how the Ward remembers you: a final reputation line on every epilogue */
NL.Act.extraFates.push(S=>{const R=NL.Rep;if(!R)return [];const e=k=>R.eff(S,k);const parts=[];
  const m=e('mercy'),c=e('candour'),r=e('restraint'),p=e('pride'),l=e('loyalty');
  if(m>=3)parts.push('the one who stopped');else if(m<=-3)parts.push('the one who didn\'t');
  if(c>=3)parts.push('the one who never lied');else if(c<=-3)parts.push('the one nobody could read');
  if(r>=3)parts.push('the stillest thing in the room');else if(r<=-3)parts.push('the one who couldn\'t say no to themselves');
  if(p>=3)parts.push('a Sheriff with his walk');else if(p<=-3)parts.push('the one who sat on the floor of the Lucky Mart');
  if(l>=3)parts.push('the one who came back');else if(l<=-3)parts.push('the one whose word went in red ink');
  if(!parts.length)return [['How the Ward remembers you','Nobody can agree. Some say kind, some say dangerous, some say both. Gideon says "a good tenant". That\'s the one that sticks.']];
  const s=parts.length===1?parts[0]:parts.slice(0,-1).join(', ')+', and '+parts[parts.length-1];
  return [['How the Ward remembers you','As '+s+'.']];});
