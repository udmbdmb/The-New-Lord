'use strict';
/* THE NEW LORD — "Seven Names": the seven missing, and the people who are still waiting for them. Grace Mbeki, Tom Lund, Ahmed Riaz, and the seventh, who had no one. */
(function(){
const S_=NL.Script;
NL.TASKS.s_seven={n:'Seven Names',xp:100,cat:'side'};
NL.ITEMS.sevenlist={n:'Seven Names',type:'read',d:'A page torn from a cot-side clipboard, in your own handwriting from a life you don\'t remember: "Dani O. · Pete S. · Luis F. · Grace M. · Tom L. · Ahmed R. · No-name (Gull) — and me."'};
S_.place({id:'mbeki',name:'Flat 9, Corder House',block:'C',sub:'Grace Mbeki\'s grandfather. He leaves the door on the latch.',if:'night>=3&night<=5&task:s_seven=active&!flag:sv_grace',node:'sv.grace',min:12});
S_.place({id:'lund',name:'The Anchor, Dock Road',block:'D',sub:'Tom Lund\'s local. His brother still drinks there.',if:'night>=3&night<=5&task:s_seven=active&!flag:sv_tom',node:'sv.tom',min:18});
S_.place({id:'riaz',name:'Riaz Bros. Kebab & Grill',block:'A',sub:'Ahmed Riaz\'s family. Open till four.',if:'night>=3&night<=5&task:s_seven=active&!flag:sv_ahmed',node:'sv.ahmed',min:8});
S_.place({id:'gull',name:'Under the Halloran Flyover',block:'A',sub:'Where the seventh slept. People called her Gull.',if:'night>=3&night<=5&task:s_seven=active&!flag:sv_gull',node:'sv.gull',min:10});
// the list surfaces the first time you see the Tuesday room
NL.Script.on('sevenStart',{if:'seen:tr.0'},(S,G)=>{setTimeout(()=>{G.give('sevenlist');G.task('s_seven');S.quests.note_s_seven='Seven names from the cots in St. Jude\'s basement. Dani, Pete and Luis you know about. Grace Mbeki, Tom Lund and Ahmed Riaz had families. The seventh, Gull, had nobody. Somebody should tell the people who are still waiting.';G.toast('task','In your own handwriting, from before. Seven names.','Seven Names');},2500);});
})();
NL.Script.add(String.raw`
// =====================================================================
// GRACE MBEKI · nineteen · her grandfather
// =====================================================================
# sv.grace
> Corder House is a block of council flats on the edge of Block C with a lift that hasn't worked since the Olympics. Flat 9, fourth floor. The door's on the latch. Inside, a radio playing gospel very quietly, and a man in his eighties in a cardigan, asleep in an armchair with his reading glasses on his forehead and a photograph frame on his chest.
> He wakes when you knock on the open door. He isn't frightened. He's been waiting for somebody to knock for three months.
mbeki: Come in. Come in. Is it about Grace? It's about Grace. Nobody comes up four flights unless it's about Grace.
mbeki: Joseph Mbeki. Sit, sit. I've made tea. I make tea at eleven every night in case.
> The photograph on his chest: a girl in a graduation gown, nineteen, enormous smile, her gown too big for her.
mbeki: Nursing. First in the family to go to college. She went to St. Jude's for the night shift in July for the experience. She said, "Grandpa, it's the best training, everyone comes in at night."
* Tell him what happened. Gently.  -> sv.gracetruth {do lean:candour+1}
* "She was brave. Right to the end."  -> sv.gracebrave {do lean:mercy+1}
* "Tell me about her first."  -> sv.graceabout

# sv.graceabout
mbeki: About her. Oh. Oh, nobody asks about her. They ask when I last saw her, what she was wearing, did she have a boyfriend.
mbeki: She sang in the choir at Mount Zion until she was fifteen and then said God was "fine but the hats were embarrassing". She was terrible at maths and brilliant at everything else. She looked after me. I'm meant to look after her. That's the wrong way round. She did my pills on Sundays in a little box with the days on.
> The pill box is on the table. Every day filled, in a careful hand, up to the twenty-eighth of August.
nostalgia(5): She filled the box before her shift. She was planning to come back and do it again.
@next sv.gracechoose

# sv.gracechoose
* Tell him what happened. Gently.  -> sv.gracetruth {do lean:candour+1}
* "She was brave. Right to the end."  -> sv.gracebrave {do lean:mercy+1}

# sv.gracetruth
> You tell him. Not the blood. Not the light. A trial. A doctor who promised it was safe and lied. A basement. A girl who signed a form because she wanted to be a nurse and the money would pay for her books.
> He listens with his eyes closed, the way old men listen to sermons.
mbeki: So she's gone. She's gone. I knew. I knew in September when the pill box ran out. She'd never have let the pill box run out.
mbeki: Thank you. Thank you for coming up four flights. Nobody comes up four flights.
{do flag:sv_grace=truth; xp:20:Grace; mem:mbeki:truth}
@next sv.graceend

# sv.gracebrave
mbeki: Brave. Brave. She was. She was never frightened of anything except the dentist.
> He knows. He's known for weeks. He lets you not say it, because you've offered him the kinder version, and he's old enough to know that sometimes a kinder version is a gift and not a lie.
{do flag:sv_grace=kind; xp:20:Grace; mem:mbeki:kind}
@next sv.graceend

# sv.graceend
mbeki: If there's a funeral. If there's ever anything. Will you tell me? I'll get down the stairs. I'll get down somehow.
* "Mrs. Okafor is organizing one. Sunday. I'll make sure she calls you."  -> sv.gracefun {if flag:shroudFuneral|flag:met404}
* "I'll come back and tell you."  -> sv.gracepromise {do promise:grace:Tell Joseph Mbeki about Grace's funeral}

# sv.gracefun
mbeki: Sunday. Yes. I'll wear my good suit. It hasn't been out since her graduation.
{do flag:graceFuneral=1}
@end

# sv.gracepromise
mbeki: Come back. Yes. Come back up the four flights. I'll have the tea ready at eleven.
@end

// =====================================================================
// TOM LUND · thirty-one · his brother
// =====================================================================
# sv.tom
> The Anchor on Dock Road is the kind of pub where the carpet sticks and the regulars have their own glasses on hooks. One of the hooks has a glass on it with masking tape round it: TOMMY. Nobody's drunk from it in months.
> At the end of the bar a big man in a docker's fleece is drinking alone with his back to the room. He has Tom's chin. You know it from the photo on the cot-side card.
lund: If you're from the papers, I've nothing to say. If you're from the police, I've less.
lund: Mick Lund. If it's about Tommy, you'd better buy me a pint, and you'd better be quick, because I'm three in and I go stupid at five.
* Buy him a pint. "It's about Tommy."  -> sv.tompint {if cash>=5}
* "It's about Tommy."  -> sv.tomnopint

# sv.tompint
{do cash-5}
@next sv.tomnopint

# sv.tomnopint
lund: Thirty-one. Out of work since the container port went automated. Bad back. Worse luck. Did a paid trial at St. Jude's in August because they paid five hundred and he owed a bloke on Pier Six four hundred and eighty.
lund: He rang me the night before he went in. Said, "Mick, I'm going to be a guinea pig. Squeak squeak." That's the last thing he said to me. Squeak squeak.
lund: The police said he skipped town to dodge the debt. Tommy never skipped anything in his life. He couldn't skip. He had a bad back.
* "He didn't skip town. He died in that trial."  -> sv.tomtruth {do lean:candour+1}
* "Who did he owe the money to?"  -> sv.tomdebt
* "He wasn't a guinea pig. He was brave."  -> sv.tombrave

# sv.tomtruth
> Mick doesn't move. Then he puts his pint down very carefully, the way you'd put down a baby, and puts both his hands flat on the bar, and stares at them.
lund: Died. In the trial. In the hospital. Where they're meant to... where they...
lund: Who did it? You tell me who did it.
* "A doctor. And the government man who paid her."  -> sv.tomwho
* "It's being dealt with. Tonight."  -> sv.tomdealt

# sv.tomwho
lund: A doctor. And a government man.
> He gets up. He's very big. Half the pub goes quiet.
lund: I'm going up to that hospital.
* "Don't. It won't bring him back, and they'll put you away."  -> sv.tomstop
? velvet 9 "Sit down, Mick. Let me do it. I'm better at it than you."  -> sv.tomsit | sv.tomgo {id sv_tom}

# sv.tomstop
lund: Put me away. Good. At least I'd have done something.
? velvet 9 "Tommy wouldn't want his big brother in a cell. He'd want you to drink his pint."  -> sv.tomsit | sv.tomgo {id sv_tom2}

# sv.tomsit
> He sits. It takes a long time. Then he reaches up to the hook behind the bar, and takes down the glass with TOMMY on the masking tape, and the barman fills it without being asked.
lund: Squeak squeak, you daft sod.
> He drinks it. All of it.
{do flag:sv_tom=truth; xp:20:Tom; mem:lund:pint}
@end

# sv.tomgo
> He's gone. Out of the door into Dock Road, in the rain, toward the Ward. You hear later he got as far as the St. Jude's parking lot and sat on the curb and cried until a nurse brought him a tea.
{do flag:sv_tom=went; xp:10:Tom}
@end

# sv.tomdealt
lund: Dealt with. Who by? You? You don't look like you could deal with a parking ticket. You look like you've been dead a week.
lund: ...Fine. Fine. Deal with it. And then come back and tell me it's dealt with, and buy me another pint, and drink one yourself, for him.
{do flag:sv_tom=truth; xp:20:Tom; promise:tom:Come back and tell Mick Lund it's done}
@end

# sv.tomdebt
lund: A bloke called Sully. Pier Six. Loans to dockers at forty percent. He came round to the flat in September asking where Tommy was. I said ask the hospital. He laughed.
gutter(4): Forty percent to dockers. Sully on Pier Six. Small fish. But the sort Malakor's people would know.
@next sv.tomnopint

# sv.tombrave
lund: Brave. Tommy. Who cried at the end of Free Willy.
lund: ...Yeah. Yeah, he was, actually. He went in, didn't he. Knowing it might be dodgy. For four hundred and eighty bucks and his brother's good opinion.
{do flag:sv_tom=kind; xp:20:Tom}
@end

// =====================================================================
// AHMED RIAZ · twenty-six · his family's grill
// =====================================================================
# sv.ahmed
> Riaz Bros. Kebab & Grill, on the corner of Ferrier and Halloran: a spit turning in the window, a fridge of fizzy drinks, a laminated menu with photos that look nothing like the food. Two men behind the counter, one old and one young, and a framed photo on the wall by the till of a third man, smiling, in a graduation gown, with a black ribbon across the corner.
riazsr: We're closing in twenty minutes, my friend. Chicken or lamb? The lamb is better. Don't tell the chicken.
riazsr: ...You're not here for food. Nobody comes in looking like that for food. You're here about Ahmed.
> The young one stops cutting meat.
* "I knew him. A little. From the trial."  -> sv.ahmedknew {if flag:knowName|flag:knowVaneWitness}
* "I'm sorry about your son."  -> sv.ahmedsorry
* "Chicken, please." Then, quietly: "And I'm here about Ahmed."  -> sv.ahmedorder

# sv.ahmedorder
> He makes you a chicken wrap, very carefully, with extra garlic sauce, and puts it in front of you on the counter. You'll never eat it. You both know.
riazsr: There. Now you're a customer. Customers I can talk to. Ask.
@next sv.ahmedsorry

# sv.ahmedknew
> Both of them look at you. The young one puts down his knife.
riazjr: The trial. You were in it. With him.
riazjr: He said there was someone. Someone on the cots who read big Russian books and lent them out and argued about the endings. He said they were the only person down there who wasn't scared. He was always scared. He was scared of dogs and flying and our dad.
nostalgia(5): A man on a cot two along, nervous, laughing too loud, asking you to explain what was happening in Part Two. *Is the prince an idiot or a saint? Which one?*
* "He asked me if Myshkin was an idiot or a saint."  -> sv.ahmedbook

# sv.ahmedbook
riazjr: ...Yeah. Yeah, that's him. That's exactly him. Which did you say?
* "Both. That's the point."  -> sv.ahmedboth
* "A saint."  -> sv.ahmedsaint

# sv.ahmedboth
riazjr: Both. He'd have hated that. He wanted answers. Accounting degree. Everything had to add up.
@next sv.ahmedsorry

# sv.ahmedsaint
riazjr: A saint. Ha. He'd have argued with you for an hour.
@next sv.ahmedsorry

# sv.ahmedsorry
riazsr: Twenty-six. Accountant. A degree. The first. I came here in 1991 with nothing and my son got a degree in accounting. Do you know what that is? That's everything.
riazsr: He did the trial because he was too proud to ask me for money for his exam fees. Too proud. He got that from me.
riazsr: The police said "adults go where they want". I said my son goes to work and comes home and checks the till and phones his mother. He doesn't "go where he wants". He's an accountant.
* Tell them the truth.  -> sv.ahmedtruth {do lean:candour+1}
* "He was too proud. That's not a sin."  -> sv.ahmedproud {do lean:mercy+1}

# sv.ahmedtruth
> You tell them. The young one leaves the counter halfway through and goes into the back and you hear him breaking something, methodically, plate by plate. The old one doesn't move. He just turns the spit, very slowly, keeping the meat from burning.
riazsr: Thank you. My wife will want to know. I'll tell her in the morning. Not tonight. Tonight she can sleep.
riazsr: Come back any time. Food is free for you. You won't eat it. It's free anyway.
{do flag:sv_ahmed=truth; xp:20:Ahmed; mem:riazsr:truth}
@end

# sv.ahmedproud
riazsr: Not a sin. No. A stupidity. The best kind. The kind fathers pass on.
> He takes the black ribbon off the corner of the photograph, very gently, and smooths it, and puts it back.
{do flag:sv_ahmed=kind; xp:20:Ahmed}
@end

// =====================================================================
// GULL · the seventh · who had nobody
// =====================================================================
# sv.gull
> Under the Halloran flyover the traffic runs overhead like weather. Cardboard and sleeping bags along the concrete wall, a shopping trolley, a fire in a drum. Four people round the fire who stop talking when you come into the light.
> One of them, a woman in three coats with a beard of grey ribbon tied in her hair, points at you with a stick.
rennie: You're not police. Police wear shoes. You're not church. Church brings soup. What are you?
* "I'm here about Gull."  -> sv.gullask
* Sit by the fire.  -> sv.gullsit

# sv.gullsit
> You sit. They watch you. Nobody says anything for a while. Somebody passes a bottle. You pass it on without drinking. That's allowed.
rennie: All right. You can stay. Ask what you came to ask.
@next sv.gullask

# sv.gullask
> The four of them look at each other.
rennie: Gull. You're the first person who's said her name since August. Even we stopped saying it. It hurt.
rennie: Nobody knew her real name. She came to the flyover in 2019 with a seagull feather in her hat and nothing else. She called everyone "pet". She could get a fire going in the rain with two matches.
rennie: A man in a grey car came in August and said there was a hospital paying people for blood tests. Five hundred. Bed for two months. Food. She went. She said, "Pet, two months in a bed, I'll come back fat."
rennie: Nobody went looking. Who'd look? Nobody looks for us. We're weather.
* "She didn't come back because they killed her."  -> sv.gulltruth {do lean:candour+1}
* "Somebody's looking now."  -> sv.gulllook

# sv.gulltruth
> The fire spits. Overhead a truck goes over like thunder.
rennie: ...Yeah. Yeah. We knew. You always know, under here.
rennie: Will she get a stone? A name on something? She hated being nobody. She said everybody should have one thing with their name on.
@next sv.gullname

# sv.gulllook
rennie: Now. Three months later. Well. Better than never, I suppose. Never's what we usually get.
@next sv.gullname

# sv.gullname
* "She'll have a stone. I promise. With 'Gull' on it."  -> sv.gullstone {do promise:gull:Get Gull a stone with her name on it}
* Give them money for the fire. All you have.  -> sv.gullcash {if cash>=20}
* "I'll tell the woman organizing the funeral. Gull will be named with the others."  -> sv.gullfun {if flag:shroudFuneral|flag:met404}

# sv.gullstone
rennie: A stone. With Gull on it. And a feather. Put a seagull feather on it.
rennie: Promise is a big word under the flyover. Nobody uses it. You've used it. We'll remember.
{do flag:sv_gull=stone; xp:20:Gull; rel:rennie+1}
@end

# sv.gullcash
> You empty your pockets into the coffee tin by the drum. They watch you do it without thanking you. That's allowed too.
{do cash-20; flag:sv_gull=cash; xp:15:Gull}
@end

# sv.gullfun
rennie: With the others. In a church. In a proper church, with her name read out. Gull.
rennie: We'll come. All of us. We'll stand at the back. We'll wear our best coats. I've got a good coat. It's underneath these.
{do flag:sv_gull=funeral; flag:gullFuneral=1; xp:20:Gull; rel:rennie+1}
@end

// =====================================================================
// the list is complete
// =====================================================================
# sv.done arc=okafor night=3,4,5 label="\"I've found all their families. All seven.\"" if=room:apt&flag:met404&flag:sv_grace&flag:sv_tom&flag:sv_ahmed&flag:sv_gull&!done:s_seven prio=8
@focus okafor
> You tell her. Joseph Mbeki and his pill box. Mick Lund and the glass on the hook. The Riaz brothers and the spit turning. Rennie and the fire and a seagull feather. Marek, for Pete. Luis, who came home, or didn't. And Dani, who she already knew.
> She writes it all down on the back of an envelope in her careful hand: seven names, seven addresses, seven people who are still waiting.
okafor: Sunday. The church on Halloran. The real one. I'll ring every one of them. I'll get Mr. Mbeki down his four flights if I have to carry him.
okafor: Seven names. Read out loud. In a church. That's all I wanted, in the end. For somebody to say their names out loud in a church.
{do task:s_seven=done; flag:sevenFuneral=1; xp:100:Seven Names; lean:mercy+1; rel:okafor+2; comp+3:Seven names}
@end
`,'c_seven');

(function(){const X=NL.EXTRAS;
X.mbeki={n:'Joseph Mbeki',color:'#d8b890',role:'Grace\'s grandfather',spec:{face:{long:1.05,jaw:0.8,cheek:0.9},skin:[.32,.22,.18],hair:{style:'crop',color:[.85,.85,.85]},glasses:{type:'reading'},shirt:[.6,.5,.4],coat:{color:[.45,.35,.28],length:.3,collar:false},height:.9}};
X.lund={n:'Mick Lund',color:'#a0b8c8',role:'Tom\'s brother',spec:{face:{wide:1.12,jaw:0.4,brow:1.3},skin:[.86,.7,.62],hair:{style:'shaved',color:[.5,.4,.3]},shirt:[.15,.25,.35],height:1.06,width:1.2}};
X.riazsr={n:'Mr. Riaz',color:'#e0b070',role:'Ahmed\'s father',spec:{face:{long:1.04,jaw:0.8,nose:1.2},skin:[.62,.46,.36],hair:{style:'crop',color:[.75,.72,.7]},mustache:[.7,.68,.65],shirt:[.9,.9,.9],apron:{color:[.85,.85,.82]},height:.95}};
X.riazjr={n:'Bilal Riaz',color:'#e0c090',role:'Ahmed\'s brother',spec:{skin:[.62,.46,.36],hair:{style:'crop',color:[.08,.06,.05]},shirt:[.9,.9,.9],apron:{color:[.85,.85,.82]}}};
X.rennie={n:'Rennie',color:'#c0c0a0',role:'Under the Halloran flyover',spec:{face:{long:1.06,cheek:1.0},skin:[.78,.66,.6],hair:{style:'long',color:[.6,.58,.55]},coat:{color:[.35,.3,.25],length:.8,collar:true},height:.92}};
// Tribunal: the families
const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
  if(S.tasks.s_seven==='done')M.push({t:'"Dani Okafor. Pete Sowa. Luis Ferreira. Grace Mbeki. Tom Lund. Ahmed Riaz. Gull. Their families are on Halloran Street tonight. I\'ve met every one."',once:'tb_seven',ok:st=>{st.prog+=2;return [T('You say the names slowly. Seven. On a platform full of the dead. Nobody interrupts. Somewhere in the Court, someone you can\'t see says "Amen".'),L('magistrate','You know their names. Not one Kindred in this court could have told me their names. You could.')];}});
  return M;};
// epilogue
(NL.Act.extraFates=NL.Act.extraFates||[]).push(S=>{const f=S.flags;if(!S.tasks.s_seven)return [];return [['The seven',S.tasks.s_seven==='done'?'Named, all seven, in the church on Halloran Street on Sunday. Joseph Mbeki came down four flights. Rennie wore her good coat. Somebody put a seagull feather on the altar.':'Some of their families know now. Some are still making tea at eleven, in case.']];});
})();
