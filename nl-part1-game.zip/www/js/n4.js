'use strict';
/* THE NEW LORD — Act IV · Night Four (Thursday): "The Blood Hunt" — martial law, the roof, turning the factions, Last Call */
(function(){
const NL=window.NL,G=NL.G,A=NL.Audio;const {N,ENC,L,T,O,C,H,STORY}=NL.DSL;const {pushPop,pushNpc,pushEnter}=NL.Act;
const X=NL.EXTRAS;
const has=(G,k)=>G.has(k);
const allies=S=>['court','syndicate','soot','miller','valko','union','ottoline'].filter(k=>S.flags['side_'+k]);
NL.Act.allies=allies;
NL.ITEMS.killcode={n:'The LANTERN frequency',type:'read',d:'A frequency written on a prescription pad in Rostova\'s neat hand: 4.14 MHz. And beneath it: "The mast on St. Jude\'s sends it. Every grate under Platform 0 has a lamp in it. When the Magistrate sits, Harrow keys it."',sp:'Whoever holds this decides whether the lamps fire.'};

/* ---------- the night ---------- */
NL.NIGHTS[4]={title:'Act IV · The Blood Hunt',sub:'Thursday · martial law',
  heatAdd:S=>1,
  canSleep:S=>S.time>=300||(S.tasks.rostova==='done'&&S.time>=240),
  endTitle:'The summons',
  endLine:S=>S.flags.bloodHunt?'Every Kindred in the Ward has your scent and leave to kill you on sight. One more night.':'The Ward holds its breath. One more night.',
  async start(G,S,hav){hav=S.hav||hav;const h=NL.Camp.havenRoom(hav);
    await G.enterRoom(h.room,h.spawn,{instant:true,noEnter:true});
    G.cine(true);A.music('dread');await G.wait(.5);
    if(S.flags.pemHurt&&!S.flags.pemDead){S.flags.lastCall=1;}
    await G.say([
      T(hav==='car'?'You wake folded into the back seat of the Sheriff\'s car with the windows taped over with newspaper. Pemberton is in the front seat, very still, breathing carefully.':'You wake to sirens. Not police sirens: the long civil-defence whoop they test on the first Monday of the month. It is Thursday.'),
      T('Through every gap in the world, light: white-violet floodlights on poles at every crossing in the Marrow Ward, sweeping slow, humming like hives.'),
      L('sundial','UV. Low-grade, but enough to blister. Whoever set those up knew exactly which streets we use.',{pass:2}),
      L('tenant','Martial law. She\'s done it. And with *federal* lamps. Séverine, my dear, you have no idea whose hand you\'re holding.')]);
    G.cine(false);
    setTimeout(()=>G.text('S.','By order of the Keeper of Elysium: the Marrow Ward is closed. Every Kindred will present themselves at Club Reliquary before midnight to be counted. Those who do not will be hunted.'),4000);
    setTimeout(()=>G.text('E.R.','Roof of St. Jude\'s. Midnight. Come alone. I want to explain before Friday. Please.'),16000);
    G.task('rostova');S.quests.note_rostova='Dr. Rostova wants to meet you on the roof of St. Jude\'s at midnight. Take the stairs past the cubicles.';
    G.task('chess');S.quests.note_chess='Friday decides everything. Go to each faction tonight and decide whose side they\'ll be on at the Tribunal: Séverine (Reliquary crypt), Malakor (Platform 0), Mother Soot (the shrine), Miller (the Lucky Mart, late), and anyone else who owes you.';
    if(S.flags.vesselLost){G.task('regain');S.quests.note_regain={court:'Séverine\'s people took the Sun-Vessel. It\'s in her crypt.',syndicate:'Malakor\'s people took the Sun-Vessel. It\'s on Platform 0.',lantern:'LANTERN took the Sun-Vessel. Harrow\'s van is parked on Ferrier Lane.'}[S.flags.vesselLost];}
    if(S.flags.lastCall)setTimeout(()=>{G.task('s_last');S.quests.note_s_last='Pemberton is bleeding and won\'t say how badly. Talk to him.';},8000);
    G.autosave();},
  async cliff(G,S,hav){
    await G.say([T('You are almost asleep when the Herald comes: a child-sized figure in a grey hood, a Wraith, holding a candle in a jam jar. It does not knock. It is simply, suddenly, there.'),
      L('pedigree','The Prince\'s Herald. Nobody has seen one in the Marrow Ward since 1977.',{pass:4}),
      T('It unrolls a scroll and reads in a voice like a radio from very far away: *Friday. Platform 0. The Magistrate sits at one. The one who wears the Sheriff will answer for him. Come, or be fetched.*'),
      L('web',S=>{const a=allies(S);return a.length>=3?'You have friends now. Enough to fill a platform. Enough, maybe, to win.':a.length?'Not many friends. Some. It might be enough.':'You have no one. Whatever happens tomorrow, you\'ll be standing alone.';}),
      L('sundial','Last night. Last sunset. Make it count.')]);}
};

/* ---------- martial law: crossing costs extra, Blood Hunt at midnight ---------- */
NL.Camp.tickHooks.push((S,G)=>{if(S.night!==4||G.busy)return;
  if(S.time>=180&&!S.flags.bhChecked){S.flags.bhChecked=1;
    if(!S.flags.sevPardon&&!S.flags.side_court){S.flags.bloodHunt=1;G.heat(1);setTimeout(()=>{G.text('S.','The Keeper of Elysium declares a Blood Hunt on the thief who wears Absalom Vane. Any Kindred may take them. Any Kindred may drink them.');G.toast('hurt','The Blood Hunt is called. Court Kindred will attack you on sight.','Blood Hunt');A.sfx('sting');},500);}}});
NL.Camp.onTravel.push(async(S,G,p,here)=>{if(S.night!==4||!here||here.block===p.block)return;
  if(G.once('crossing4'))await G.talk('mx.0');
  else if(S.flags.bloodHunt&&!S.flags.huntMet&&p.block==='B'){S.flags.huntMet=1;await G.talk('bh.0');}});
N['mx.0']={lines:[T('The crossing at Halloran and Ferrier: a floodlight on a pole, sweeping. A man in grey under it with a clipboard and a radio. Not police. Not Court.'),
  L('sundial','Fifteen seconds of that light and you\'ll smoke. Thirty and you\'ll burn.'),
  L('web','The sweep is on a timer. Eleven seconds bright, four dark. And the man with the clipboard looks up every time a car comes.',{pass:6})],
  opts:[C('sundial',9,'Count the sweep. Go on the dark.','mx.ok','mx.burn',{id:'mx_sun'}),O('Shadow-Step across.','mx.ok',{ab:'shadowstep'}),
    O('"Pemberton. Floor it."','mx.car',{if:S=>S.flags.carOK&&!S.flags.carGone&&!S.flags.pemDead}),O('Go the long way, through the drains.','mx.long')]};
N['mx.ok']={lines:[T('Dark, dark, *go*. You\'re across before the light swings back. The man with the clipboard writes something down anyway.')],end:true};
N['mx.burn']={lines:[T('You go a second too late. The light catches your hand and the back of your neck and it\'s like being slapped with a frying pan.',{fx:['hurt:1','shake:.6'],do:(S,G)=>{G.vitae(-1);G.comp(-1,'Burned');G.heat(1);}})],end:true};
N['mx.car']={lines:[T('Pemberton puts his foot down. The light washes over the windscreen, and the newspaper he taped over the back windows yesterday, and you, for one long second, through the gap. The car smells of singed hair.',{do:(S,G)=>{G.vitae(-1);}}),L('pemberton','Apologies, ‹sir›. I\'ll tape it better.')],end:true};
N['mx.long']={lines:[T('Down a storm drain, along a pipe, up a manhole in an alley behind the crossing. It takes forty minutes and your shoes are ruined.',{do:(S,G)=>G.tick(40)})],end:true};
N['bh.0']={lines:[T('Two Court enforcers step out of a doorway on Reliquary Row, long coats, short knives. One of them has a stake, an actual wooden stake, like in a film.'),
  L('ghoulmen','Blood Hunt, friend. Nothing personal. Actually, it\'s *quite* personal; the Lady\'s offering a whole floor of the Gilded Court to whoever brings your head.')],
  opts:[C('frenzy',11,'Go through them.','bh.fight','bh.hurt',{id:'bh_fr'}),C('velvet',12,'"Two of you, against what I drank? Go home."','bh.talk','bh.hurt',{id:'bh_vel',mod:S=>S.flags.seizure==='surrender'?3:S.flags.chord?1:0}),
    O('Whistle for Valko.','bh.valko',{if:S=>S.flags.valkoAlly}),O('Run.','bh.run')]};
N['bh.fight']={lines:[T('Fast and ugly. When it\'s done there are two men groaning in the gutter and a stake snapped in half.',{fx:['shake:1.2','sfx:crash'],do:(S,G)=>{G.heat(1);G.xp(20,'The Blood Hunt');}})],end:true};
N['bh.talk']={lines:[T('They look at each other. They look at you. Something in your face, someone in your face, makes them both take a step back.'),L('ghoulmen','...Nobody saw nobody.')],end:true};
N['bh.valko']={lines:[T('Two fingers, one sharp whistle. Valko comes out of the dark like he was thrown. The enforcers know him. They run before he gets there.'),L('valko','The Lady\'s people. She\'ll know I\'ve turned now. Good.')],end:true};
N['bh.hurt']={lines:[T('The stake goes in under your ribs, not quite to the heart. You pull it out yourself and keep going.',{fx:['hurt:1.4','shake:1'],do:(S,G)=>{G.vitae(-2);G.comp(-1,'Staked');}})],end:true};
N['bh.run']={lines:[T('You run. It\'s undignified. It works.',{do:(S,G)=>G.tick(10)})],end:true};

/* =====================================================================
   SCENE 4.1 · The roof of St. Jude's: Rostova and the frequencies
   ===================================================================== */
pushPop('sjroof',(S,G)=>{if(S.night===4&&!S.flags.rostovaDone&&S.time>=150)G.addActor('rostova',NL.CHARS.rostova.spec,{x:8.6,z:3.2,ry:-1.6,breathes:true,pose:'arms'});});
pushNpc('sjroof',(S,G)=>G.actor('rostova')?{id:'rostova',actor:'rostova',label:'Dr. Rostova'}:null);
pushEnter('sjroof',async(S,G)=>{A.music('dread');if(S.night===4&&S.time<150&&G.once('roofEarly'))await G.say([T('The roof: wet tar, a radio mast, a helipad nobody uses, and a strange lamp rig bolted to the middle of the H. Nobody here yet.'),L('sundial','She said midnight. It isn\'t midnight.')]);
  else if(G.actor('rostova')&&G.once('ro4'))await G.talk('r4.0');});
const roB=H.use.rostova;H.use.rostova=async(S,G)=>{if(S.room==='sjroof')return G.talk(S.flags.r4enc?'r4.hub':'r4.0');return roB?roB(S,G):false;};
N['r4.0']={enter:(S,G)=>{G.focus(['you','rostova'],.8);G.look('rostova','you');},lines:[
  T('She\'s standing at the edge in her white coat with her arms wrapped round herself, not looking at the city. A long black case lies open at her feet, empty.'),
  L('rostova','You came. I thought you\'d come through the door. I don\'t know why I thought you\'d use the door.'),
  L('rostova','I know who you are. You\'re number eight. Casey. You were *mine*, for one week. Then he took you, and I thought: good. At least one of them gets out.',{if:S=>S.flags.knowName}),
  L('rostova','I know who you are. You\'re number eight. You were on my list, for one week. Then he took you.',{if:S=>!S.flags.knowName}),
  L('tenant','Elena. Hello, Elena.',{if:S=>S.flags.seizure!=='suppress'})],next:'r4.enc'};
N['r4.enc']={enc:'doctor',win:'r4.win',lose:'r4.lose',drink:'r4.drink',jump:'r4.jump'};
ENC.doctor={title:'THE DOCTOR',sub:'Dr. Elena Rostova · the roof of St. Jude\'s',music:'grief',after:'night',
  prog:{name:'The truth',max:6,color:'#9ed0e0'},threat:{name:'The edge',max:6,color:'#e06050'},
  focus:G=>G.focus(['you','rostova'],.7),
  start(S,G){let p=0,t=1;if(S.flags.sawAmbush)p+=1;if(G.has('lanternfile'))p+=1;if(S.flags.millerAlly)t+=1;return {prog:p,threat:t};},
  intro:[L('rostova','Ask. Ask me anything. I\'m so tired of nobody asking.')],
  round(st,S,G){const Q=[
    ()=>({lines:[L('rostova','Harrow found me in 2015. A junior doctor, twenty thousand in debt, with a mother in a home. He said: you could help us end them. Help the city. Just point.')]}),
    ()=>({lines:[T('She steps backward, onto the parapet. Her heels are over nothing.')],threat:1}),
    ()=>({lines:[L('rostova','Do you know what it\'s like? Every Tuesday, seven beds. Every Wednesday, one less. I kept their name cards. I couldn\'t throw away their *name cards*.')],threat:1}),
    ()=>({lines:[L('rostova','Tomorrow they burn the whole platform. Every one of you. I built the lamps. I wanted to tell someone before it happens. That\'s all. I wanted to tell *someone*.')]})];return st.round<Q.length?Q[st.round]():null;},
  moves(st,S,G){const r=st.round,M=[];
    M.push(C('pulse',9,'"Come away from the edge, Elena."',null,null,{id:'r4_pulse'+r,ok:st=>{st.threat=Math.max(0,st.threat-2);st.prog+=1;return [T('One step. Back onto the tar. She\'s shaking.')];},no:st=>{st.threat+=1;return [L('rostova','Don\'t. Don\'t use my name like a nurse.')];}}));
    M.push(C('autopsy',10,'"The four pints. You weren\'t curing him. You were *harvesting* him."',null,null,{id:'r4_aut',once:'r4_aut',mod:(S,G)=>G.has('lanternfile')?2:0,ok:st=>{st.prog+=2;return [L('rostova','His blood was the only one that took. Old Sovereign blood. Two of the seven lived three days. *Three days*, in sunlight. Harrow cried. He actually cried.')];},no:st=>{st.threat+=1;return [L('rostova','You don\'t understand the science.')];}}));
    M.push(C('web',10,'"Why the freezer? Why 4:14?"',null,null,{id:'r4_web',once:'r4_web',mod:S=>S.flags.sawAmbush?3:0,ok:(st,S)=>{st.prog+=2;S.flags.knowWhy=1;return [L('rostova','Because he worked it out. Sunday night, after the transfusion, he looked at the bags and he *knew*. He was going to go to Séverine at dawn. Harrow said: tonight. Before dawn. Somewhere cold, somewhere nobody looks.'),L('rostova','4:14 was when he knelt. That\'s all. That\'s all it was. He knelt because I asked him to.')];},no:st=>{st.threat+=1;return [L('rostova','It doesn\'t matter why.')];}}));
    M.push(C('nostalgia',10,'"Dani Okafor drew a heart on her name card when she was nine."',null,null,{id:'r4_nos',once:'r4_nos',if:S=>S.flags.met404,ok:st=>{st.prog+=2;st.threat+=1;return [T('She makes a sound like something tearing.')];},no:st=>{st.threat+=1;return [L('rostova','Stop it.')];}}));
    if(S.flags.chord||S.flags.seizure==='surrender')M.push({t:'Let Absalom speak. "Elena. I forgive you."',once:'r4_vane',ok:st=>{st.prog+=3;return [L('tenant','I forgive you. I do. I went to you because I was tired of the dark. That was my sin, not yours.'),L('rostova','...Absalom?')];}});
    const ab=(id,t,fn,extra)=>M.push(Object.assign({t,ab:id,ok:fn},extra||{}));
    ab('coldread','Hear the thing she\'s loudest about not saying.',(st,S)=>{st.prog+=2;S.flags.knowCode=1;return [T('A number. Over and over, like a song stuck in her head: *four point one four. Four point one four. The mast sends it. The lamps hear it.*')];},{once:'r4_cold'});
    ab('siren','Siren\'s Pitch: "How do we stop the lamps?"',(st,S)=>{st.prog+=2;S.flags.knowCode=1;return [L('rostova','The mast. The frequency is four point one four. Cut the mast, the lamps never hear the order. Or... or change the order.')];},{once:'r4_siren'});
    ab('kneel','Kneel: "Step down."',st=>{st.threat=0;return [T('She steps down. Her face does not agree with her feet.')];},{once:'r4_kneel'});
    M.push(C('frenzy',10,'Drink her. She killed him. She killed *you*.',null,null,{id:'r4_fr',red:true,ok:st=>{st.result='drink';return [];},no:st=>{st.threat+=2;return [T('She sees it in your face and steps back, and back again.')];}}));
    return M;},
  decide(st){return st.prog>=4?'win':(st.threat>=5?'jump':'lose');},
  outro(r,st,S,G){S.flags.r4enc=r;return [];}
};
N['r4.win']={lines:[T('She sits down on the wet tar, quite suddenly, like a child.'),
  L('rostova','Harrow has the lamps wired into every grate on Platform 0. When the Magistrate sits, he keys the mast. Four point one four megahertz. Every Kindred on the platform burns at once. The Prince\'s Magistrate, Séverine, Malakor, Soot. You.'),
  L('rostova','And then LANTERN goes to Washington with a jar of ash and asks for a hundred million dollars.'),
  T('She writes it on her prescription pad and tears it off and holds it out to you without looking.',{do:(S,G)=>{G.give('killcode');S.flags.knowCode=1;G.task('rostova','done');G.xp(60,'The roof');S.flags.rostovaDone='talked';}})],
  opts:[O('"Come to the Tribunal. Testify."','r4.testify'),O('"Run, Elena. Tonight. Don\'t look back."','r4.run'),O('"Go to Miller. Turn yourself in."','r4.miller',{if:S=>S.dos.miller}),O('Leave her on the roof.','r4.leave')]};
N['r4.testify']={lines:[L('rostova','To a room full of vampires? They\'ll kill me.'),L('you','"Probably. But they\'ll hear it first."'),L('rostova','...Yes. Yes, all right. Somebody should hear it.',{do:(S,G)=>{S.flags.rostovaTestify=1;}})],end:true};
N['r4.run']={lines:[L('rostova','I can\'t. My mother. The home is paid until —'),L('rostova','No. You\'re right. Tonight.',{do:(S,G)=>{S.flags.rostovaFled=1;G.comp(1,'Mercy');}})],end:true};
N['r4.miller']={lines:[L('rostova','The detective. Ray Dunleavy\'s partner. She\'ll hate me.'),L('rostova','Good. Somebody should.',{do:(S,G)=>{S.flags.rostovaMiller=1;S.flags.side_miller=S.flags.side_miller||(S.rel.miller>=2?1:0);}})],end:true};
N['r4.leave']={lines:[T('You go down the stairs. Behind you, she\'s still sitting on the H, holding her own wrists.',{do:S=>S.flags.rostovaLeft=1})],end:true};
N['r4.lose']={lines:[L('rostova','No. No, I\'ve said too much. Harrow will —'),T('She snatches up the empty lance case and goes past you to the stairs at a run, and is gone.',{do:(S,G)=>{G.task('rostova','done');S.flags.rostovaDone='fled';S.flags.rostovaFled=1;}}),
  L('web','She didn\'t tell you how. But the lamp rig on the helipad is connected to that radio mast by a cable as thick as your thumb.')],end:true};
N['r4.jump']={lines:[T('She looks at you, and at the city, and makes a decision you can see happen.'),T('She steps back off the parapet. There is no sound, for a long time, and then there is.',{fx:['shake:.5'],do:(S,G)=>{G.task('rostova','done');S.flags.rostovaDone='jumped';S.flags.rostovaDead=1;G.comp(-2,'You pushed her there');G.heat(1);}}),
  L('pulse','You didn\'t touch her. You didn\'t have to.'),L('web','The rig on the helipad. The cable to the mast. She was looking at it when she went.')],end:true};
N['r4.drink']={lines:[T('You cross the roof before she can scream. She doesn\'t scream. She holds still and lets you, the way she let him kneel.'),
  T('Her blood is full of his. Of Vane\'s. Five years of drops, taken at night, to keep her hands steady. In it: every Tuesday. Every name card. A number: 4.14.',{fx:['flash','sfx:drink','shake:1'],do:(S,G)=>{G.feed(5,'melancholic','Elena Rostova',{kind:'mortal',kill:true});S.flags.rostovaDead=1;S.flags.knowCode=1;G.give('killcode');G.task('rostova','done');S.flags.rostovaDone='drunk';G.sync(5,'His blood, coming home');G.comp(-3,'You drank the doctor');G.offer('guillotine');}}),
  L('tenant','...Thank you. I hated her. I loved her. Thank you.')],cs:async(G,S)=>{G.dlgHide();G.pose('rostova','slump',2);await G.wait(1.2);G.removeActor('rostova');},end:true};
N['r4.hub']={lines:[L('rostova','There\'s nothing else. I\'m sorry. I\'m so sorry.')],end:true};
// the mast and the lamp rig
H.use.mast=async(S,G)=>G.talk('mast.0');
N['mast.0']={lines:[T('A steel radio mast with three dishes and a red lamp blinking at the top. A cable runs from its base across the tar to the lamp rig on the helipad, and another goes down into the building.'),
  L('web','This is what sends the order. Four point one four.',{if:S=>S.flags.knowCode})],
  opts:[O('Cut the cable. Kill the mast.','mast.cut',{if:S=>S.flags.knowCode&&!S.flags.mastDead&&!S.flags.mastTuned}),
    C('gutter',11,'Retune it. Make it send the order whenever *you* say.','mast.tune','mast.no',{id:'mast_gut',if:S=>S.flags.knowCode&&!S.flags.mastDead&&!S.flags.mastTuned,mod:(S,G)=>G.equipped('lineman')?3:0}),
    O('Spark-Jump into the mast. Learn its voice.','mast.tune',{ab:'spark',if:S=>S.flags.knowCode&&!S.flags.mastDead&&!S.flags.mastTuned}),
    O('Leave it.',null,{end:true,leave:true})]};
N['mast.cut']={lines:[T('Bolt cutters from the HVAC cabinet. The cable parts with a crack and a smell of ozone. The red lamp at the top of the mast goes out.',{do:(S,G)=>{S.flags.mastDead=1;G.xp(40,'The mast');G.task('chess');}}),L('sundial','Nobody burns on Friday. Not unless someone brings their own sun.')],end:true};
N['mast.tune']={lines:[T('You feel the mast\'s voice in your teeth: a carrier wave, a pulse, a key. You fold it into your burner phone like a number into a contact list. Now the lamps answer to you.',{do:(S,G)=>{S.flags.mastTuned=1;G.xp(40,'The mast');}}),L('frenzy','We could burn them ALL. Every Elder. All at once.'),L('pulse','So could Harrow. That\'s the point. That\'s why it\'s dangerous.')],end:true};
N['mast.no']={lines:[T('Sparks. A jolt up your arm that leaves your fingers numb.',{fx:['shake:.5'],do:(S,G)=>G.vitae(-1)})],next:'mast.0'};
H.use.uvrig=async(S,G)=>G.say([T('A quartz lamp the size of a dustbin lid on a steel tripod, cabled to the mast. A test unit. The real ones are under Platform 0.'),L('sundial','Don\'t stand in front of it. Ever.')]);
H.use.parapet=async(S,G)=>G.say([T('The edge. The whole Marrow Ward below you: the Strip, Reliquary Row, the Rookery, the black gap of the Switchyard. The UV floodlights at the crossings, sweeping, like lighthouses for something that wants to drown.'),L('nostalgia','You used to come up here on your break. You used to smoke. You forgot you used to smoke.')]);

/* =====================================================================
   SCENE 4.2 · Setting the board: turning the factions
   ===================================================================== */
// Séverine
const sevB=H.use.severine;H.use.severine=async(S,G)=>{if(S.night>=4&&!S.flags.sev4)return G.talk('s4.0');return sevB?sevB(S,G):false;};
pushPop('vip',(S,G)=>{if(S.night===4&&S.flags.vesselLost==='court'&&!S.flags.vesselRegained)G.toast&&0;});
N['s4.0']={enter:(S,G)=>{G.focus(['you','severine'],.8);G.look('severine','you');},lines:[
  L('severine',S=>S.flags.bloodHunt?'You walked into my house during a Blood Hunt on your own head. I am almost charmed.':'You came to be counted. Good. Sit.'),
  L('severine','The lamps were Harrow\'s idea. Federal equipment, he said, on loan, to keep the Ward calm until the Magistrate arrives. He has been very helpful. He is always very helpful.'),
  L('web','She doesn\'t know. She thinks LANTERN is her tool.',{pass:4})],next:'s4.hub'};
N['s4.hub']={opts:[
  O('"Harrow is going to burn you with those lamps. Tomorrow. All of you."','s4.warn',{if:S=>S.flags.knowCode,once:true}),
  O('Lay the 1978 Polaroids on the table.','s4.pol',{if:(S,G)=>G.has('polaroids')&&!S.flags.side_court}),
  O('"You owe me a favour, Keeper. I\'m calling it in."','s4.owe',{if:S=>S.flags.sevOwesYou&&!S.flags.side_court}),
  O('"Give me back the Vessel."','s4.vessel',{if:S=>S.flags.vesselLost==='court'&&!S.flags.vesselRegained}),
  O('Offer her the Sun-Vessel in exchange for a pardon.','s4.give',{if:(S,G)=>G.has('vessel')}),
  O('Royal Decree: "You will stand with me on Friday."','s4.decree',{ab:'kneel',t2:true,if:S=>!S.flags.side_court}),
  O('"Stand with me tomorrow. Or don\'t. Your choice."','s4.ask',{if:S=>!S.flags.side_court&&!S.seen['s4.ask']}),
  O('Leave.','s4.bye')]};
N['s4.warn']={lines:[L('severine','...What?'),L('you','"Four point one four megahertz. A lamp in every grate. When the Magistrate sits."'),T('For the first time since you\'ve known her, Séverine looks old.'),
  L('severine','He told me they were for the crossings. He showed me a *brochure*.',{do:(S,G)=>{S.flags.sevWarned=1;G.rel('severine',2);}})],next:'s4.hub'};
N['s4.pol']={lines:[T('She looks at them for a long time without touching them. Herself, in 1978, in a room under the Reliquary, with a Prince\'s Magistrate who is now very dead, doing something the Court would burn her for.'),
  L('severine','Gideon\'s river safe. Of course. Absalom always said he\'d put them somewhere wet.'),L('severine','What do you want?'),L('you','"Friday. You stand behind me. And the Blood Hunt goes away."'),
  L('severine','...Done. Leave the photographs.',{do:(S,G)=>{G.take('polaroids');S.flags.side_court='blackmail';S.flags.sevPardon=1;S.flags.bloodHunt=0;G.rel('severine',-1);G.xp(40,'The Keeper');}})],next:'s4.hub'};
N['s4.owe']={lines:[L('severine','I do. I hate that I do. Name it.'),L('you','"Stand behind me on Friday."'),L('severine','Paid, then. We are square after that. I want to be very clear: square.',{do:(S,G)=>{S.flags.side_court='debt';S.flags.sevPardon=1;S.flags.bloodHunt=0;S.flags.sevOwesYou=0;G.xp(40,'The Keeper');}})],next:'s4.hub'};
N['s4.vessel']={lines:[L('severine','It\'s in a safe in my coffin. Of course it is. Where else would one keep the sun?')],
  opts:[C('velvet',12,'"It\'s mine, Séverine. It was always going to come back to me."','s4.vok','s4.vno',{id:'s4_vv',mod:S=>(S.flags.sevWarned?3:0)+(S.flags.side_court?3:0)}),O('Take it. Now.','s4.vtake'),O('Back.','s4.hub')]};
N['s4.vok']={lines:[T('She opens the coffin, and the safe, and holds it out to you in both hands like a christening gift.',{do:(S,G)=>{G.give('vessel');S.flags.vesselRegained=1;S.flags.vesselHeld=1;G.task('regain','done');}}),L('severine','Don\'t make me regret it.')],next:'s4.hub'};
N['s4.vno']={lines:[L('severine','No.')],next:'s4.hub'};
N['s4.vtake']={lines:[T('You go over the table. Her ghouls go for you. It is short and loud and there is a great deal of broken crystal, and at the end of it you are holding a brass bottle and Séverine is holding her cheek.',{fx:['shake:1.4','sfx:crash'],do:(S,G)=>{G.give('vessel');S.flags.vesselRegained=1;S.flags.vesselHeld=1;G.task('regain','done');S.flags.sevEnemy=1;S.flags.bloodHunt=1;G.vitae(-2);G.heat(1);}}),L('severine','Get out. GET OUT.')],end:true};
N['s4.give']={lines:[L('severine','...Absalom\'s package. You\'d give it to me? Just like that?')],opts:[O('"For a pardon. And your word that it stays sealed."','s4.gok'),O('"Changed my mind."','s4.hub')]};
N['s4.gok']={lines:[T('She takes it like a woman taking a bomb from a child.',{do:(S,G)=>{G.take('vessel');S.flags.vesselGiven='court';S.flags.vesselHeld=0;S.flags.sevPardon=1;S.flags.side_court='vessel';S.flags.bloodHunt=0;G.rel('severine',3);G.breakPromise('malakorVessel');G.xp(40,'The Keeper');}}),
  L('severine','Pardoned. Of everything. You may even keep the mask.')],next:'s4.hub'};
N['s4.decree']={lines:[T('Royal Decree, against a Keeper of Elysium in her own house. You stack the commands. She resists, gracefully, for almost a full second.'),
  L('severine','...Of course. Of course I will stand with you. How could I not.',{do:(S,G)=>{S.flags.side_court='decree';S.flags.sevPardon=1;S.flags.bloodHunt=0;S.flags.sevDecreed=1;}}),L('pedigree','She\'ll know, afterwards. She\'ll know exactly what you did to her. Make sure there\'s no afterwards where that matters.')],next:'s4.hub'};
N['s4.ask']={lines:[L('severine',S=>S.flags.sevWarned?'If what you say about Harrow is true... then perhaps I must. But I need more than your word. Bring me something I can hold.':'Stand with *you*? A neonate with a stolen face? Darling. No.')],next:'s4.hub'};
N['s4.bye']={lines:[T(null,{do:S=>S.flags.sev4=1})],end:true};

// Malakor
const mkB=H.use.malakor;H.use.malakor=async(S,G)=>{if(S.night>=4)return G.talk('mk4.0');return mkB?mkB(S,G):false;};
N['mk4.0']={lines:[L('malakor',S=>S.flags.vesselLost==='syndicate'?'Kin! You\'ve come for your bottle. It\'s behind me, under a tarp, being very warm.':S.flags.vesselGiven==='court'?'You gave it to *her*. I heard. I hear everything that happens on a boat.':'The Lady\'s turned the lights on. Bad for business. What do you want?')],opts:[
  O('Lay the Kowalski manifests on his bench. "Forty years of rendering for the Court."','mk4.man',{if:(S,G)=>G.has('manifest')&&!S.flags.side_syndicate}),
  O('"Harrow\'s lamps will burn you too. Every grate on this platform."','mk4.warn',{if:S=>S.flags.knowCode,once:true}),
  O('Give him the Sun-Vessel. Keep your promise.','mk4.give',{if:(S,G)=>G.has('vessel')}),
  O('"Give me back the Vessel."','mk4.vessel',{if:S=>S.flags.vesselLost==='syndicate'&&!S.flags.vesselRegained}),
  C('abattoir',11,'"I made a man a new face on your platform. Now stand behind mine."','mk4.kin','mk4.no',{id:'mk4_ab',if:S=>!S.flags.side_syndicate&&(S.flags.gary||S.clan==='butchers'),mod:S=>S.flags.gary?3:0}),
  C('apex',12,'"Friday, you stand with me, Butcher. Or you stand in the light."','mk4.threat','mk4.no',{id:'mk4_ap',if:S=>!S.flags.side_syndicate&&!S.flags.malakorHates,mod:S=>S.flags.knowCode?2:0}),
  O('Leave.',null,{end:true,leave:true})]};
N['mk4.man']={lines:[L('malakor','Ah. Ah, Margo, you sentimental cow. She kept *carbons*.'),L('malakor','The Court has been paying me to make bodies disappear since 1984. If the Magistrate sees those, the Lady burns and I... well. I burn too, probably. Mutually assured.'),
  L('malakor','So. What do you want for them?')],opts:[O('"Friday. Stand behind me."','mk4.manok'),O('Keep them. "I\'ll let you know."','mk4.0')]};
N['mk4.manok']={lines:[L('malakor','Done. And on Saturday I come and buy them from you. Expensively.',{do:(S,G)=>{S.flags.side_syndicate='manifests';G.xp(40,'The Butcher');}})],next:'mk4.0'};
N['mk4.warn']={lines:[L('malakor','...Federal lamps. In MY grates. Under MY platform.'),T('He walks to the edge of the platform and looks down through the nearest grate for a long time.'),L('malakor','I\'ll have my boys pull every one of them tonight. — No. No, wait. Leave them. If they\'re there, and he doesn\'t know we know...',{do:(S,G)=>{S.flags.malakorWarned=1;G.rel('malakor',2);}})],next:'mk4.0'};
N['mk4.give']={lines:[L('malakor','A promise kept. You have no idea how rare that is down here.'),T('He takes it in a lead-lined cool box and closes the lid like a man closing a treasure chest.',{do:(S,G)=>{G.take('vessel');S.flags.vesselGiven='syndicate';S.flags.vesselHeld=0;G.keep('malakorVessel');S.flags.side_syndicate='vessel';G.rel('malakor',3);G.xp(40,'The Butcher');}}),
  L('malakor','The Syndicate stands behind you. Whatever you need. And on Saturday, I sell the sun to the highest bidder.')],next:'mk4.0'};
N['mk4.vessel']={lines:[L('malakor','Mine, now. Finders keepers. Unless...')],opts:[O('"Unless?"','mk4.unless'),C('frenzy',12,'Take it off him.','mk4.vtake','mk4.vfail',{id:'mk4_fr'}),O('Back.','mk4.0')]};
N['mk4.unless']={lines:[L('malakor','Unless you open it on Friday, on the platform, pointed at the Court. Then you may have it back, and I\'ll even polish it.'),T('Your promise, made in blood, the way Butchers make them.',{do:(S,G)=>{G.give('vessel');S.flags.vesselRegained=1;S.flags.vesselHeld=1;G.task('regain','done');G.promise('burnCourt','Open the Vessel on the Court at the Tribunal');S.flags.side_syndicate='burnCourt';}})],next:'mk4.0'};
N['mk4.vtake']={lines:[T('The tarp, the box, his men: in that order, and very fast.',{fx:['shake:1.4','sfx:crash'],do:(S,G)=>{G.give('vessel');S.flags.vesselRegained=1;S.flags.vesselHeld=1;G.task('regain','done');S.flags.malakorHates=1;G.vitae(-2);}}),L('malakor','Oh, *well* done. I\'ll kill you for that, on Saturday, if there\'s anything left.')],end:true};
N['mk4.vfail']={lines:[T('He catches your wrist and turns it, quite gently, until something in it goes *pop*.',{fx:['hurt:1'],do:(S,G)=>{G.vitae(-2);}})],next:'mk4.0'};
N['mk4.kin']={lines:[L('malakor','...Laurent sends a postcard. Gary, I should say. He\'s a shift manager now. Shift manager! Fine, kin. The Syndicate stands with you.',{do:(S,G)=>{S.flags.side_syndicate='kin';G.xp(40,'The Butcher');}})],next:'mk4.0'};
N['mk4.threat']={lines:[L('malakor','Ha. HA. The Sheriff\'s puppy has teeth. Fine. Fine! I like a winner. Make sure you are one.',{do:(S,G)=>{S.flags.side_syndicate='threat';}})],next:'mk4.0'};
N['mk4.no']={lines:[L('malakor','No.')],next:'mk4.0'};

// Mother Soot
const soB=H.use.soot;H.use.soot=async(S,G)=>{if(S.night>=4)return G.talk('so4.0');return soB?soB(S,G):false;};
N['so4.0']={lines:[L('soot',S=>S.flags.sootCrossed?'You broke my lock. You broke our contract. Many heard. Why are you in my house?':'Mm. You opened it. Tell me. Tell me what was inside. I hate not knowing.')],opts:[
  O('Tell her everything: the Vessel, LANTERN, the lamps.','so4.tell',{if:S=>!S.flags.sootCrossed&&!S.flags.side_soot}),
  O('"I\'m sorry. I broke the lock. I was afraid."','so4.sorry',{if:S=>S.flags.sootCrossed&&!S.flags.sootForgive}),
  O('"Stand with me on Friday, Mother."','so4.ask',{if:S=>!S.flags.side_soot&&!S.flags.sootCrossed}),
  O('Ask her to send the rats into the grates.','so4.rats',{if:S=>S.flags.side_soot&&S.flags.knowCode&&!S.flags.ratsGrates}),
  O('Leave.',null,{end:true,leave:true})]};
N['so4.tell']={lines:[T('She listens with her eyes shut and her lips moving, repeating it all to herself, filing it somewhere in the dark.'),L('soot','A sun. Lamps. A federal man who says please. Mm. Mm. *Good*. That was worth a key.',{do:(S,G)=>{S.flags.sootTold=1;G.rel('soot',2);}})],next:'so4.0'};
N['so4.sorry']={lines:[L('soot','...Afraid. Yes. You were. I heard that too.'),L('soot','Bring Ezra home and we are square.',{if:S=>!S.flags.ezraAlly,do:S=>S.flags.sootAskEzra=1}),L('soot','Ezra came home. He says you were kind. Fine. Square.',{if:S=>S.flags.ezraAlly,do:S=>{S.flags.sootForgive=1;S.flags.sootCrossed=0;}})],next:'so4.0'};
N['so4.ask']={lines:[L('soot','The Wraiths stand with nobody. We sit in the walls and listen.'),L('soot','...But I will sit in *your* walls, on Friday. If you\'ve been honest with me.',{if:S=>S.flags.sootTold}),
  T(null,{do:(S,G)=>{if(S.flags.sootTold||S.clan==='wraiths'||S.flags.c_done==='home'||S.flags.c_done==='walk'){S.flags.side_soot=1;G.xp(40,'Mother Soot');G.toast('rel','Mother Soot will stand with you at the Tribunal.','The Whisper Broker');}else G.toast('task','Mother Soot wants to be told the truth first.','The Whisper Broker');}})],next:'so4.0'};
N['so4.rats']={lines:[L('soot','Rats chew wires. Rats love to chew wires. Mm. Every grate on Platform 0, by morning.',{do:(S,G)=>{S.flags.ratsGrates=1;}})],next:'so4.0'};

// Miller (Lucky Mart, from 1 AM)
const millerN4=S=>S.night===4&&S.time>=240&&S.time<420&&!S.flags.miller4done&&!S.flags.millerGone;
pushPop('luckymart',(S,G)=>{if(millerN4(S))G.addActor('miller',NL.CHARS.miller.spec,{x:2.7,z:4.0,ry:-1.6,breathes:true,pose:'hold'});});
pushNpc('luckymart',(S,G)=>G.actor('miller')?{id:'miller',actor:'miller',label:'Miller'}:null);
const miB=H.use.miller;H.use.miller=async(S,G)=>{if(S.night>=4&&S.room==='luckymart')return G.talk('mi4.0');return miB?miB(S,G):false;};
N['mi4.0']={enter:(S,G)=>{G.focus(['you','miller'],.8);G.look('miller','you');},lines:[L('miller','They suspended me. Harrow did. "Conduct unbecoming." I have never been more becoming in my life.'),L('miller','So. Whatever you are. Talk to me.')],opts:[
  O('Give her the Tuesday files.','mi4.files',{if:(S,G)=>G.has('lanternfile')&&!S.flags.millerFiles}),
  O('Give her Ray\'s notebook.','mi4.ray',{if:(S,G)=>G.has('rayfile')}),
  O('"Tomorrow night, at one, under the Switchyard. Bring a judge and a camera."','mi4.ask',{if:S=>!S.flags.side_miller&&(S.flags.millerFiles||S.flags.millerAlly)}),
  O('Tell her what you are.','mi4.truth',{once:true,if:S=>!S.flags.millerKnows}),
  O('"Stay home tomorrow, Ines. Whatever you hear."','mi4.home'),
  O('Leave.',null,{end:true,leave:true})]};
N['mi4.files']={lines:[T('She reads them at the magazine rack, turning pages with the corner of her badge, which isn\'t her badge any more.'),L('miller','"T.H." Okay. Okay. This is a federal crime in a hospital basement. This gets him.',{do:(S,G)=>{G.take('lanternfile');S.flags.millerFiles=1;G.rel('miller',2);}})],next:'mi4.0'};
N['mi4.ray']={lines:[T('She holds the evidence bag with both hands and doesn\'t open it.'),L('miller','Ray\'s writing. "Ask Ines." I owe you. Whatever you are.',{do:(S,G)=>{G.take('rayfile');G.task('s_cold','done');G.rel('miller',3);S.flags.millerAlly=1;G.xp(50,'Ray Dunleavy');}})],next:'mi4.0'};
N['mi4.ask']={lines:[L('miller','A judge. At one in the morning. In a sewer.'),L('miller','...I know one. Judge Abernathy. She\'s eighty-two and she hates Harrow more than I do.',{do:(S,G)=>{S.flags.side_miller='judge';G.xp(40,'Miller');S.flags.miller4done=1;}})],next:'mi4.0'};
N['mi4.truth']={lines:[T('You tell her. You don\'t show her. She stands there with a cup of coffee going cold and doesn\'t laugh.'),L('miller','...Yeah. Yeah, I figured it was something like that. Ray used to say: the Ward has a night shift. I thought he meant *crime*.',{do:(S,G)=>{S.flags.millerKnows=1;G.rel('miller',1);G.heat(1);}})],next:'mi4.0'};
N['mi4.home']={lines:[L('miller','Is that a threat or a kindness?'),L('you','"Yes."'),L('miller','...Okay.',{do:S=>{S.flags.millerHome=1;S.flags.miller4done=1;}})],end:true};

// Valko, Ottoline, the union, Leo: whoever else owes you
N['pem.drive'].opts.splice(1,0,O('"Pemberton. You\'re bleeding."','lc.0',{if:S=>S.flags.lastCall&&!S.flags.lastCallDone}),O('Call Valko on the burner.','vk4.0',{if:S=>S.night===4&&S.flags.valkoAlly&&!S.flags.side_valko}),O('Text Dutch: "Local 0. Friday."','un4.0',{if:S=>S.night===4&&S.flags.rookerySafe&&!S.flags.side_union}),O('Call in Ottoline\'s debt for Friday.','ot4.0',{if:S=>S.night===4&&S.flags.ottolineOwes&&!S.flags.ottolineUsed&&!S.flags.side_ottoline}));
N['vk4.0']={lines:[L('valko','I\'m here. I\'m always here.'),L('you','"Friday."'),L('valko','Friday. I\'ll be at your left hand, where I was at his. And if the Lady\'s people so much as look at you —',{do:(S,G)=>{S.flags.side_valko=1;G.xp(20,'The Hound');}})],next:'pem.drive'};
N['un4.0']={lines:[T('A reply in eight seconds: *LOCAL 0 WILL BE THERE. BRINGING SCREWDRIVERS.*',{do:(S,G)=>{S.flags.side_union=1;}})],next:'pem.drive'};
N['ot4.0']={lines:[T('A reply on very old paper, slid under the car door ten minutes later in copperplate: *Contract-owe acknowledged. Friday, one o\'clock. I shall bring a lawyer. — O.V.*',{do:(S,G)=>{S.flags.side_ottoline=1;S.flags.ottolineUsed=1;}})],next:'pem.drive'};

/* =====================================================================
   SIDE · Last Call Before Dawn (Pemberton)
   ===================================================================== */
N['lc.0']={enter:(S,G)=>{G.focus(['you','pemberton'],.8);G.look('pemberton','you');},lines:[
  T('He\'s been holding the same folded towel to his side since last night. It\'s not white any more.'),
  L('pemberton','A graze, ‹sir›. I said. A graze.'),L('pemberton','...It isn\'t a graze. I was a medic in Aden in 1967. I know what this is.'),
  L('pemberton','Forty-one years I drove him. I\'d like to have driven the next one a bit longer. That\'s all.'),
  L('pulse','He\'s a ghoul. Vane\'s blood kept him going. Vane\'s blood is in you now.')],
  opts:[O('Open your wrist. "Drink, Pemberton."','lc.blood',{blood:2}),O('"Let me take you to St. Jude\'s."','lc.hosp'),O('"What do you want, Pemberton? Anything."','lc.want')]};
N['lc.blood']={lines:[T('He hesitates for a long time, and then he drinks, very politely, like a man taking communion.',{fx:['flash'],do:(S,G)=>{G.vitae(-2);S.flags.lastCallDone='blood';S.flags.pemHurt=0;S.flags.pemBound=1;G.task('s_last','done');G.rel('pemberton',3);G.xp(40,'Last Call');}}),
  L('pemberton','...Thank you, ‹sir›. I find I\'m not ready after all.'),L('tenant','Good man. Good man.')],next:'pem.drive'};
N['lc.hosp']={lines:[L('pemberton','With the lamps on every corner and a Blood Hunt on you? No, ‹sir›. They\'d ask questions. Questions about you.'),L('pemberton','Let\'s not.')],next:'lc.0'};
N['lc.want']={lines:[L('pemberton','...I\'d like to see a sunrise. I haven\'t seen one since 1983. He couldn\'t, so I didn\'t. Seemed rude.'),
  L('pemberton','The Rookery roof faces east. If you could drive me there before you go to ground, and leave me with a thermos, I\'d be very grateful.')],
  opts:[O('"I\'ll take you."','lc.sun'),O('"No. Drink. Stay with me."','lc.blood',{blood:2})]};
N['lc.sun']={lines:[T('You drive him to the Rookery yourself, badly, and carry him up six flights, and sit him in Rostova\'s sniper\'s folding chair behind the water tower, facing east, with a blanket and a thermos of Tariq\'s coffee.'),
  L('pemberton','Thank you, ‹sir›. You go on now. It\'s nearly time, and you shouldn\'t be here for this part.'),
  L('pemberton','He was a good man, mostly. You\'re a better one. Mostly.'),
  T('You go down the stairs. You don\'t look back. It\'s the hardest thing you\'ve done all week.',{do:(S,G)=>{S.flags.lastCallDone='sunrise';S.flags.pemDead=1;S.flags.carGone=1;G.task('s_last','done');G.comp(2,'Last Call');G.xp(40,'Last Call');G.offer('sungazer');}})],end:true};

/* ---------- regaining the Vessel from LANTERN ---------- */
pushPop('alley',(S,G)=>{if(S.night===4&&S.flags.vesselLost==='lantern'&&!S.flags.vesselRegained)G.addActor('lanternman',X.lanternman.spec,{x:7.2,z:1.4,ry:-2.6,breathes:true,pose:'arms'});});
pushNpc('alley',(S,G)=>G.actor('lanternman')?{id:'lanternman',actor:'lanternman',label:'The grey van'}:null);
H.use.lanternman=async(S,G)=>G.talk('lv.0');
N['lv.0']={lines:[T('A grey van with federal plates at the mouth of Ferrier Lane, engine running, a man in grey leaning on it with a UV torch on his belt and a coffee in his hand. Through the back windows: a lead-lined case, strapped down.'),L('web','One man. Bored. The others are at the crossings. Harrow\'s not here.')],
  opts:[C('stagecraft',11,'Walk up in the triage mask. "Doctor Rostova sent me for the case."','lv.ok','lv.no',{id:'lv_stg',mod:(S,G)=>G.equipped('triagemask')||G.equipped('smock')?3:0}),
    O('Crown of Fog: he was never guarding anything.','lv.ok',{ab:'fog'}),C('frenzy',11,'Take the van.','lv.ok','lv.no',{id:'lv_fr'}),O('Leave it for now.',null,{end:true,leave:true})]};
N['lv.ok']={lines:[T('The case is heavy and warm through the lead. You walk away with it down Ferrier Lane and nobody follows.',{do:(S,G)=>{G.give('vessel');S.flags.vesselRegained=1;S.flags.vesselHeld=1;G.task('regain','done');G.removeActor('lanternman');}}),L('sundial','The sun, back in your pocket. Never again.')],end:true};
N['lv.no']={lines:[T('The torch comes off his belt. For one second you\'re standing in noon.',{fx:['hurt:1.5','shake:1'],do:(S,G)=>{G.vitae(-2);G.comp(-1,'The torch');G.heat(1);}}),T('You run. The van stays.')],end:true};
NL.TASKS.regain={n:'Get the Sun-Vessel back',xp:50,cat:'main'};

/* ---------- sleeping rough: the back seat ---------- */
N['pem.drive'].opts.splice(1,0,O('Sleep in the back seat until tomorrow night.',null,{if:S=>S.night<5&&S.flags.havenLost&&!S.flags.carGone&&NL.Camp.canSleep(S),end:true,do:()=>setTimeout(()=>NL.Camp.sleep('car'),300)}));
})();
