'use strict';
/* THE NEW LORD — echoes: what you did comes back, in the order it matters.

   When you walk up to someone, before anything else is said, the game looks for the one thing they would bring up first.
   Precedence, highest first:
     5 · LOSS        someone they love died, or was saved, because of you
     4 · VIOLATION   you used a power on them, or broke a promise to them
     3 · DEBT        a kindness, a promise kept, a gift
     2 · STANDING    what you wear, what you've become, what the street says
     1 · COLOUR      small things
   Rules: one echo per conversation and at most one per person per night. A choice can't echo on the night you made it
   (people need a day to think about it). An echo whose `over` list names other echoes retires them when it plays: a broken promise
   retires the thanks for the gift. Ties go to the more specific echo, then to the newer one.
   Powers you use on people are logged (S.powerLog) and come back as violations the next night, from the victim or a witness. */
(function(){
const G=NL.G,{L,T,H}=NL.DSL;
const LIST=[];
const E=(id,who,pri,cond,lines,o)=>LIST.push(Object.assign({id,who:[].concat(who),pri,cond,lines},o||{}));
NL.ECHO={list:LIST,add:E};

/* ---------- who's who ---------- */
const KIN=new Set(['tenant','severine','sev','malakor','soot','valko','lisette','ashby','magistrate','ezra','winter','laurent','ottoline','valentin','freddie','oldkin','dutch','pip','cantor','lamplighter','gaston','ottilie','vole','ferryman','prophet']);
const ENC_WHO={keeper:'severine',butcher:'malakor',hound:'valko',doctor:'rostova',tribunal:'magistrate',miller:'miller',beast:'leo'};
/* how noticeable each gift is, at Tier 1/2/3: 0 quiet (nobody notices: that's the point of it), 1 felt (something strange happened;
   a mortal can't place it, a Kindred knows exactly what), 2 obvious (everyone knows). Only felt and obvious uses come back as echoes. */
const NOTICE={kneel:[2,2,2],fog:[0,0,0],blueblood:[0,2,2],veil:[0,0,0],carrion:[0,0,0],mark:[0,0,0],
  dejavu:[0,0,0],splinter:[0,2,2],coldread:[0,2,1],siren:[0,2,2],touch:[0,0,0],encore:[1,2,2],
  bonekey:[0,0,0],borrowed:[0,2,2],nerve:[1,2,2],scent:[0,0,0],claws:[2,2,2],pack:[0,2,2],
  boil:[1,2,2],ward:[0,0,0],vintage:[0,0,0],shadowstep:[0,0,0],snuff:[0,0,0],strings:[2,2,2],
  corpse:[0,0,0],miasma:[0,1,1],stillheart:[0,0,0],scavenger:[0,0,0],spark:[0,0,0],badluck:[0,0,0]};
const noticed=(p,kin)=>{const n=(NOTICE[p.ab]||[0,0,0])[Math.max(0,Math.min(2,(p.tier||1)-1))];return n>=2||(n===1);};
NL.ECHO.NOTICE=NOTICE;
const nameOf=id=>{const c=(NL.CHARS&&NL.CHARS[id])||(NL.EXTRAS&&NL.EXTRAS[id]);let n=c&&(c.n||c.name)||id;return n.replace(/^(Det\.|Dr\.|Mr\.|Mrs\.|Lady|Lord|Officer|Sgt\.|Father|Agent)\s+/,'');};
const alive=(S,id)=>!S.flags[(id==='pemberton'?'pem':id==='severine'?'sev':id)+'Dead']&&!(id==='tiny'&&S.flags.tinyGone)&&!(id==='teo'&&S.flags.teoGone);

/* ---------- the power log ---------- */
G.logPower=(o,ctx)=>{const S=G.S;if(!S)return;S.powerLog=S.powerLog||[];
  const who=ctx&&ctx.enc?ENC_WHO[ctx.enc]:(G._talkNpc||null);
  S.powerLog.push({ab:o.ab,tier:o.t3?3:o.t2?2:1,who,night:S.night,enc:ctx&&ctx.enc||null});
  /* an obvious gift used on a mortal is a Masquerade problem: +1 Heat (once per person per night). Quiet gifts cost nothing. */
  const tier=o.t3?3:o.t2?2:1,lvl=(NOTICE[o.ab]||[0,0,0])[tier-1];
  if(lvl===2&&who&&!KIN.has(who)&&who!=='tenant'){S.flags.obviousOn=S.flags.obviousOn||{};const k=who+':'+S.night;if(!S.flags.obviousOn[k]){S.flags.obviousOn[k]=1;G.heat&&G.heat(1);}}if(S.powerLog.length>300)S.powerLog.splice(0,S.powerLog.length-300);};

/* generic violation lines, by gift. {n} is their name. Mortals don't know what happened; Kindred do. */
const MORTAL={
  kneel:'{n} hesitates before doing anything you ask, even ordinary things, like someone feeling for a step in the dark.',
  fog:'{n} glances at the clock while you talk, twice. There\'s a gap in their evening they can\'t account for, and it has your shape.',
  siren:'{n} answers you slowly now, listening to their own voice, as if it might say something without them.',
  encore:'{n} starts a sentence, stops, starts it again, and looks at you, frightened, without knowing why.',
  splinter:'{n} won\'t look at the window glass while you\'re in the room.',
  boil:'{n} is sweating, though it\'s cold, and keeps touching their throat.',
  nerve:'{n} rubs one hand with the other. It went numb the last time you were close, and it hasn\'t forgiven you.',
  strings:'{n} keeps glancing down at their own shadow, checking it\'s still attached.',
  miasma:'{n} yawns, apologizes, and yawns again. They\'ve been tired since they last saw you.',
  badluck:'{n} has had a bad run. Small things. A dropped cup, a flat tyre. They\'ve started looking at you the way people look at black cats.',
  borrowed:'{n} looks at your face a beat too long, as if checking it\'s the one you came in with.'
};
const KINDRED={
  kneel:'{n} is perfectly polite. Kindred are always polite to someone who has made them kneel. It\'s how they keep count.',
  fog:'{n} looks at you with a small, cold smile. They noticed the missing minutes. Kindred always notice.',
  siren:'{n} speaks very carefully around you now, choosing each word like a step on ice.',
  encore:'{n} catches themselves repeating a phrase, and stops, and gives you a long look.',
  splinter:'{n} keeps their back to every mirror in the room.',
  boil:'{n} keeps a little more distance than before. Blood remembers being heated.',
  nerve:'{n} offers you a hand to shake, then thinks better of it.',
  strings:'{n} stands where the light throws their shadow away from you.',
  miasma:'{n} breathes through their mouth around you. It\'s a small insult and they mean it.',
  badluck:'{n} touches wood, twice, when you come over.',
  borrowed:'{n} studies your face like a forged signature.'
};
/* the main cast say it in their own words (precedence over the generic line) */
const OWN={
  miller:[T('Miller keeps both hands flat on the counter when you come over, where she can see them.'),L('miller','My body did something on Monday because you told it to. Not me. My *body*. Nineteen years a cop and I\'ve never been so frightened of a sentence.'),L('pulse','She\'s not going to tell anyone. Who would believe her?')],
  leo:[T('Leo flinches when you raise your voice, then laughs at himself for flinching.'),L('leo','Sorry. Sorry. Weird week. I keep feeling like I said yes to something I didn\'t hear.')],
  tariq:[T('Tariq has moved the coffee machine. The counter is between you now. He doesn\'t mention it.')],
  tiny:[L('tiny','Hands where I can see them, yeah? Not because... I don\'t know why. Humour me.'),L('pulse','Some part of him remembers not being able to move.')],
  rostova:[L('rostova','You did something to me. I\'ve been trying to remember it all day. I\'m a doctor. I know what a blank looks like.')],
  margo:[L('margo','You\'re doing that thing with your eyes again. Don\'t. I\'m sixty-three. I haven\'t got minutes to spare.')],
  pemberton:[L('pemberton','‹Sir›. You needn\'t do that to me. I would have done it anyway. That\'s rather the point of me.')],
  gideon:[L('gideon','Last time you were in, something happened in my shop I can\'t put in the ledger. There isn\'t a column for it. Don\'t do that in here again.')],
  harrow:[L('harrow','I saw what you did, friend. In the open. I wrote it down.'),L('harrow','That\'s the thing about doing it where people can see. Somebody always writes it down.')],
  severine:[L('severine','You put your hand inside me. In my own city. I have had two hundred years of men doing that, and I have outlived every one of them.')],
  malakor:[L('malakor','We\'re square, for what you did. Once. Do it twice and I take it out of you in kind.')],
  soot:[L('soot','Mm. You came in through the front of me without knocking. The pipes don\'t forget a guest who doesn\'t knock. Mm.')],
  valko:[L('valko','You made me sit. Like a dog. He used to do that. Only he asked first, with his eyes.')],
  lisette:[L('lisette','You went into my head. Next time, buy me a drink first. That\'s the very least.')],
  dominic:[L('dominic','I saw what you are, the last time you were in. I\'ve decided to pray for you. You\'re welcome.')],
};
function powerEcho(npc,S){
  const log=(S.powerLog||[]).filter(p=>p.who===npc&&!p.echoed&&p.night<S.night&&noticed(p,KIN.has(npc)));
  if(!log.length)return null;const p=log[log.length-1];
  return {id:'pw_'+npc+'_'+(S.powerLog.indexOf(p)),pri:4,weight:p.tier,power:p,
    lines:()=>{log.forEach(x=>x.echoed=1);if(OWN[npc]&&(NOTICE[p.ab]||[])[p.tier-1]===2)return OWN[npc];const kin=KIN.has(npc),tx=(kin?KINDRED:MORTAL)[p.ab]||(kin?'{n} is courteous in the way that means they are counting.':'{n} is a little wary of you, and can\'t say why.');
      const out=[T(tx.replace('{n}',nameOf(npc)))];
      if(kin)out.push(L('pedigree','Among the Kindred, a gift used on one of them without leave is a debt. They will collect it.'));
      if(p.tier>=3)out.push(L('tenant','You used the third door on them. They\'ll tell their friends. Some of their friends will be very old.'));
      return out;}};}

/* =============================== the echoes =============================== */
const has=(S,k)=>!!S.flags[k];

// ---- 5 · loss ----
E('okaforEzraDead','okafor',5,S=>has(S,'ezraDead'),[T('Mrs. Okafor has swept the hallway. The door to 404 is open now, and the room behind it is empty and smells of bleach.'),L('okafor','The council never came about the rats. So I did it myself. I don\'t know what you did up there. I don\'t want to.'),L('pulse','She knows. She\'s decided not to know.')],{over:['okaforEzraFree']});
E('okaforEzraFree','okafor',3,S=>has(S,'ezraFree')&&!has(S,'ezraDead'),[L('okafor','He came down for tea this morning. Before the sun, he said. He sat at my table and drank it, or held it, and told me about his mother. He\'s a very sad boy. He says you saved him.')]);
E('rosaKenSaved',['rosa','leo'],5,S=>has(S,'kenSaved')&&alive(S,'leo'),[L('leo','Uncle Ken says somebody pulled him into the dark when the lights went. By the collar. He says it was you. He says you didn\'t have to.'),L('leo','Ma wants to make you a lasagne. I told her. I told her you can\'t. She said "make it anyway".')]);
E('tinyMarcus','tiny',5,S=>has(S,'marcusSafe')&&alive(S,'tiny'),[L('tiny','Marcus slept on my couch last night. First time in two years. He snores like Dad.'),L('tiny','I don\'t know what you did at the fights. He won\'t say. He just keeps saying your name like it\'s a password.')]);
E('tinyMarcusLost','tiny',5,S=>has(S,'marcusGhoul')&&alive(S,'tiny'),[T('Tiny doesn\'t get up when you come over. He looks at his hands.'),L('tiny','Marcus is the Syndicate\'s now. He came by the door last night with blood on his teeth and asked me for a twenty.'),L('tiny','I gave him forty. I don\'t know why.')],{over:['tinyMarcus']});
E('halloranMaureen',['halloran'],3,S=>has(S,'catMaureen'),[L('halloran','Maureen came and sat on the step this morning. The cat, I mean. Not... the real one\'s upstairs. She laughed. At the cat\'s name. First time since Easter.'),L('nostalgia','A man telling you his wife laughed. That\'s the whole of the news, and it\'s enough.')]);

// ---- 4 · violation & broken promises ----
E('pemCommanded','pemberton',4,S=>has(S,'pembAsked')&&(S.powerLog||[]).some(p=>p.who==='pemberton'&&(p.ab==='kneel'||p.ab==='fog')),[T('Pemberton holds the car door for you. He doesn\'t meet your eyes in the mirror.'),L('pemberton','You said you would ask, ‹sir›. You said you\'d never command. I wrote it down. I\'m old-fashioned that way.'),L('pemberton','I\'ll still drive. I\'ll always drive. That was never the question.')],{over:['pemVialThanks','pemAskedThanks'],weight:9,power:true});
E('leoThrall','leo',4,S=>S.flags.tedState==='thrall'&&alive(S,'leo'),[T('Leo has brought you a coffee. You can\'t drink coffee. He knows that. He brings one anyway, every time now, and stands there holding it out, smiling, waiting for you to take it.'),L('pulse','That isn\'t friendship. That\'s the blood. He\'d bring you anything. He\'d bring you his own throat on a saucer.')]);
E('rostovaSirened','rostova',3,S=>has(S,'rostovaSiren')&&alive(S,'rostova'),[L('rostova','On Monday I said something to you I\'ve never said out loud to anyone. I don\'t know why I said it. I keep going over it.'),L('velvet','She thinks it was her own conscience. Let her.')]);
E('millerDecreed','miller',4,S=>has(S,'decreeMiller'),[T('Miller looks at you across the counter a long time before she speaks.'),L('miller','I went home on Monday. I don\'t remember deciding to. I called a woman and told her her son was fine. Her son\'s not fine. Her son\'s *missing*.'),L('miller','I don\'t know what you are. I\'ve started a file on it.')],{weight:5,power:true});
E('dominicFed','dominic',4,S=>has(S,'fedDominic')&&!has(S,'dominicDead'),[T('Father Dominic has a plaster on his neck, the kind you\'d put on a shaving cut. He touches it when he sees you.'),L('dominic','I\'ve been to confession. Mine, I mean. To Father Brennan in Dock Street. He gave me ten Hail Marys and a very strange look.')]);

// ---- 3 · debts, kindnesses, promises kept ----
E('pemVialThanks','pemberton',3,S=>has(S,'pemVial'),[L('pemberton','The tremor hasn\'t come back, ‹sir›. Not once. I can tie a Windsor knot again. I\'d forgotten I liked tying them.')]);
E('pemAskedThanks','pemberton',3,S=>has(S,'pembAsked'),[L('pemberton','You asked me to bring the car round, last night. "Would you mind." Forty-one years, ‹sir›. Nobody has said "would you mind" to me in forty-one years.')]);
E('margoForgiveness','margo',3,S=>has(S,'margoForgiven')&&!has(S,'margoDead'),[L('margo','I slept. First time since Monday. I hate you for it a bit. Being forgiven sits on your chest like a cat.')]);
E('leoKnee','leo',3,S=>has(S,'leoKneeFixed')&&alive(S,'leo'),[L('leo','I took the stairs at the Lantern Room two at a time. Haven\'t done that since I was twenty-five. My knee doesn\'t click any more. It\'s horrifying. Thank you. It\'s *horrifying*.')]);
E('leoMom','leo',3,S=>has(S,'leoCalledMom')&&alive(S,'leo'),[L('leo','Ma called back. This morning. We talked for an hour about Mrs. DiNapoli\'s cat. Best hour of my week. Of my year, maybe.')]);
E('leoStew',['leo','rosa'],3,S=>has(S,'ateStew')&&alive(S,'leo'),[L('leo','Ma rang me at four in the morning to tell me you ate the whole bowl. "Your friend is too thin and too polite and I like them." I didn\'t have the heart to tell her what you are.'),L('leo','...Did it hurt? Eating it?'),L('you','"A bit."'),L('leo','Yeah. That\'s Ma\'s stew.')]);
E('rosaBowlKept',['rosa'],3,S=>has(S,'rosaBowl'),[L('rosa','There\'s a bowl kept back. I said there would be. Don\'t look at me like that. You eat it after.')]);
E('tariqEnvelopeKept','tariq',3,S=>has(S,'tariqEnvelope'),[L('tariq','The envelope is still in the drawer. YOURS. I don\'t spend it. I don\'t give it back. It just lives there now, like a cat.')]);
E('tariqWaited','tariq',3,S=>has(S,'tariqWarned'),[L('tariq','I put the radio on very loud and swept, like you said. I swept the same tiles for two hours. They\'ve never been so clean.'),L('tariq','You came back. Good. Tell me if the world ended. I want to know.')]);
E('sootTooth','soot',3,S=>has(S,'sootTooth')&&alive(S,'soot'),[L('soot','You\'re wearing the tooth. Mm. The pipes know you now. Three of my children followed you home last night, to make sure you got there. You didn\'t notice. Good. You weren\'t meant to.')]);
E('tinyCardsKept','tiny',3,S=>has(S,'tinyCards')&&alive(S,'tiny'),[L('tiny','Still got the cards. Box under my stool. I looked at them last night. Every name. I said them out loud, so somebody had.')]);
E('valkoComes','valko',3,S=>has(S,'valkoFriday')&&alive(S,'valko'),[L('valko','I told Rask I wasn\'t working tonight. He asked why. I said: because of somebody. He didn\'t understand. Neither do I. I like it.')]);
E('malakorTen','malakor',3,S=>has(S,'malakorDiscount')&&alive(S,'malakor'),[L('malakor','Ten percent, for life. I\'ve written it down in the book. Under "regrettable generosity". You\'re the only entry.')]);
E('rostovaStood','rostova',3,S=>has(S,'rostovaArm')&&alive(S,'rostova'),[L('rostova','Number eight. You\'ll stand next to me. You said. I keep checking you meant it, and you keep meaning it, and I don\'t know what to do with that.')]);
E('rostovaForgiven','rostova',3,S=>has(S,'medForgave')&&alive(S,'rostova'),[L('rostova','I sat down. After you left. In that chair by the window. I slept in it for four hours. That\'s the longest I\'ve slept since August.')]);
E('millerExhaust','miller',3,S=>has(S,'millerSaved'),[L('miller','Somebody turned off my engine, Tuesday night. Put my coat on my knees. Left my file on the seat. Exhaust leak, the garage says. Another hour and I\'d have been in St. Jude\'s.'),L('miller','...I don\'t believe in guardian angels. I believe in people who don\'t want to be seen. Thank you. Whoever.')]);
E('millerPhoto','miller',3,S=>has(S,'millerHasPhoto')&&!has(S,'teoGone'),[T('Miller has the photograph in her breast pocket. You can see the corner of it. She touches it when she thinks nobody\'s looking.')]);
E('kenStood',['kenpruitt','pruitt'],3,S=>has(S,'kenCordon')&&!has(S,'pruittDead'),[L('kenpruitt','End of Halloran Street. Nobody came down it. Nobody. I stood there till my feet went. First useful thing I\'ve done in a uniform in a decade.')]);
E('gideonLedger','gideon',3,S=>has(S,'gideonWrote'),[L('gideon','It\'s in the ledger, in pencil. I\'ll ink it Saturday. Don\'t make me rub it out.')]);
E('lisetteFifty','lisette',3,S=>has(S,'lisetteBet'),[L('lisette','Fifty on Saturday. I\'ve told everyone at the bar. If you lose me fifty dollars I will be *so* rude about you at your funeral.')]);
E('halloranSock','halloran',3,S=>has(S,'sockBit')&&!has(S,'catMaureen'),[L('halloran','The black one with the sock waited on the wall for you last night. Two hours. Then bit me instead. That\'s love, that is.')]);
E('copCalled','miller',2,S=>has(S,'copToMiller'),[L('miller','A uniform from the 9th called me at six this morning, drunk, crying, wanting to give a statement about a scratch-card shop. Somebody pointed him at me. I\'ve got a funny idea who.')]);
E('dominicStill','dominic',3,S=>has(S,'dominicDefiant')&&!has(S,'dominicDead'),[L('dominic','Still here. Still lighting candles. You said I could. I mean, I would have anyway. But it was nice that the devil agreed.')]);
E('vigilOkafor','okafor',3,S=>has(S,'vigilLit'),[L('okafor','Somebody relit the candles on the church steps the other night. All of them. Luis Ferreira\'s mother told me. She said a pale person knelt next to her and didn\'t say a word.'),L('okafor','I said I didn\'t know anybody like that. You\'ve got wax on your sleeve.')]);
E('severineForgiven',['severine','sev'],3,S=>has(S,'sevForgiven')&&alive(S,'severine'),[L('severine','I\'ve been thinking about it. Being forgiven. It\'s like a stone in a shoe. I keep taking the shoe off to look at it.')]);

// ---- 2 · standing: what you wear ----
const EQ=(S,id)=>Object.values(S.eq||{}).includes(id);
E('pemHat','pemberton',2,S=>EQ(S,'widebrim'),[T('Pemberton sees the hat and stops, the way you stop on a stair that isn\'t there.'),L('pemberton','He had that hat before I was born, ‹sir›. The hole in the brim was there when I met him. He would never say how. He said it improved the line.')],{same:true});
E('sevPorcelain',['severine','sev'],2,S=>EQ(S,'porcelain')&&alive(S,'severine'),[L('severine','You wore my mask. How lovely. Do you know what it means, in the Court, to wear a Keeper\'s gift in public?'),L('pedigree','It means you\'re hers. Everyone who saw you tonight now thinks you\'re hers.')],{same:true});
E('sevCoat',['severine','sev'],2,S=>EQ(S,'greatcoat')&&alive(S,'severine'),[L('severine','Take that coat off in my presence. ...No. Don\'t. I\'d rather look at it than at you.')],{same:true});
E('valkoRing','valko',2,S=>EQ(S,'signet')&&alive(S,'valko'),[T('Valko\'s nostrils flare before you\'ve reached him. He looks at your hand, not your face.'),L('valko','Still wearing it. Good. Never take it off. If you take it off I\'ll know.')],{same:true});
E('malakorRing','malakor',2,S=>EQ(S,'signet')&&alive(S,'malakor'),[L('malakor','Nec somnus. "Nor sleep." He had that engraved in 1801 and never once let anyone forget he didn\'t sleep. Wear it lightly, neonate. It\'s heavier than it looks.')],{same:true});
E('margoGlasses','margo',2,S=>EQ(S,'glasses')&&!has(S,'margoDead'),[L('margo','Are those my *glasses*? ...Two and a half diopters. You\'ll get a headache. Keep them. I\'ve another pair. I always have another pair.')],{same:true});
E('magJacket','magistrate',2,S=>EQ(S,'dinnerjacket'),[L('magistrate','Midnight velvet. 1981. The man who died in that jacket owed the Prince a great deal of money. You wear it well. Better than he did.')],{same:true});

// ---- 2 · standing: what you've become ----
const ASC=S=>!!S.flags.ascend&&S.flags.ascendNight<S.night;
E('ascSev',['severine','sev'],2,S=>ASC(S)&&alive(S,'severine'),[T('Séverine stops talking when you come near. She tilts her head, like someone hearing music in another room.'),L('severine','You\'ve opened the third door. Already. Absalom took forty years. I took sixty. Who *are* you?')]);
E('ascMal','malakor',2,S=>ASC(S)&&alive(S,'malakor'),[L('malakor','You smell different. Deeper. Like a cellar with a second cellar under it.'),L('malakor','Third door. Congratulations. Now everybody who wanted to eat you wants to eat you *more*.')]);
E('ascSoot','soot',2,S=>ASC(S)&&alive(S,'soot'),[L('soot','Mm. Mm. The pipes went quiet when you passed tonight. They only do that for the old ones. You\'re not old. You\'re *early*.')]);
E('ascValko','valko',2,S=>ASC(S)&&alive(S,'valko'),[L('valko','You\'ve gone through. I can smell it on you. Like a storm that\'s already broken.')]);
E('ascPem','pemberton',2,S=>ASC(S)&&alive(S,'pemberton'),[L('pemberton','You\'ve changed, ‹sir›. Last night. I felt it in the car, like going over a hill. He did that, in 1801. I was told about it. I never thought I\'d drive it.')]);
E('ascLis','lisette',2,S=>ASC(S),[L('lisette','Third door, already. The bar is taking bets on what you\'ll be by Christmas. I\'ve got fifty on "terrifying".')]);
E('ascGid','gideon',2,S=>ASC(S),[T('Gideon looks at you over his glasses and, very quietly, moves the crucifix on the counter an inch further away.')]);

// ---- 2 · what the street says ----
E('tinyStreetSheriff','tiny',2,S=>has(S,'tinyStreetSheriff')&&alive(S,'tiny'),[L('tiny','Told a kid at the door last night you were the Street Sheriff. He asked what that meant. I said: it means somebody\'s looking. He said nobody\'s ever looked. I said: well. Now.')]);
E('soldBlood','tenant',2,S=>has(S,'soldVitae'),[L('tenant','Mother Hask is selling us by the vial, you know. "Three hundred years in a bottle." Twelve dollars a sip. I\'ve been *cheaper*, I suppose. Once. In Naples.')]);

// ---- more of what you set in motion ----
E('tinyDoor','tiny',4,S=>has(S,'tinySold')&&alive(S,'tiny'),[T('Tiny holds the door for you, the way he always does, and tells you to mind the step.'),L('pulse','He doesn\'t know what you told the old woman in the pipes about him. You do.')]);
E('malakorTold','malakor',4,S=>has(S,'sevKnowsLance')&&alive(S,'malakor'),[L('malakor','You told the Keeper I built the lance. She sent two of her people to my yard to *look* at me. All night. I don\'t like being looked at.'),L('malakor','I understand why you did it. I\'m writing it down anyway.')],{over:['malakorTen']});
E('sevRoux',['severine','sev'],4,S=>has(S,'sevAngryRoux')&&alive(S,'severine'),[L('severine','You ate one of my courtiers. In my own glasshouse. He was a monster, and he was *mine* to deal with.'),L('pedigree','In the Court, killing someone else\'s monster is worse than keeping your own.')],{over:['severineForgiven']});
E('sevFreddie',['severine','sev'],4,S=>has(S,'sevAngryFreddie')&&alive(S,'severine'),[L('severine','Freddie Carstairs. Eighty years in my Court. The pianist says he hummed the whole time. The Russian song.'),L('severine','...He always did hum it when he was frightened. I\'d forgotten that. You\'ve reminded me. I hate you for it.')],{over:['severineForgiven']});
E('lisRoux','lisette',3,S=>has(S,'rouxStopped'),[L('lisette','Valentin has given up gardening. He\'s taken up watercolours. They\'re dreadful. Everybody is enormously relieved.')]);
E('okaforSeven','okafor',5,S=>has(S,'sevenFuneral'),[L('okafor','I\'ve rung all seven families. Mr. Mbeki says he\'ll come down his four flights if it kills him. I told him not to say that, at a funeral.'),L('okafor','Seven names. In a church. Read out loud. You did that.')],{over:['okaforEzraFree','vigilOkafor']});
E('millerDates','miller',3,S=>has(S,'tariqToldMiller'),[L('miller','Tariq gave me dates. Sixteen of them, on the back of napkins, in Arabic and English. I\'ve got a case again. A real one.')]);
E('halloranCharlie','halloran',3,S=>has(S,'charlieGhoul'),[L('halloran','Charlie sleeps on Maureen\'s feet now. Every night. He\'s never done that. And he looks at me like he knows something I don\'t. Which, since you, he probably does.')]);
E('sootEveryone','soot',3,S=>has(S,'soldEveryone')&&alive(S,'soot'),[L('soot','I\'ve been reading what you gave me. Everyone. I\'m being careful with them, child. Mostly. Mm. Mostly.')]);
E('pemRing','pemberton',4,S=>has(S,'ringSold')&&alive(S,'pemberton'),[L('pemberton','I went to the Pawn & Coffin this morning, ‹sir›, to buy back his ring. Gideon wouldn\'t sell. He says he\'s keeping it for you, for when you come to your senses.'),L('pemberton','That is very like Gideon. I\'ve never liked him more.')]);
E('valkoRing2','valko',4,S=>has(S,'ringSold')&&alive(S,'valko'),[L('valko','You sold it. His ring. To a *pawnbroker*.'),T('He doesn\'t say anything else. He doesn\'t have to.')],{over:['valkoRing']});
E('harrowFriend','harrow',2,S=>has(S,'harrowMarked')&&!has(S,'harrowDead'),[L('harrow','Friend. Still around. Good. I like it when people stay where I can find them.')]);

// ---- batch 3: the week remembered ----
E('pemAgnes','pemberton',3,S=>has(S,'agnesFramed')&&alive(S,'pemberton'),[L('pemberton','The photograph is framed, ‹sir›. Silver. Not too much. It\'s on the dashboard. I hope you don\'t mind. She seems to like the drive.')]);
E('pemLetters','pemberton',2,S=>has(S,'pemStays'),[L('pemberton','I\'ve written another one, ‹sir›. The resignation. It\'s in the glovebox, with the others. You needn\'t tear it up. I\'ll know where it is.')]);
E('pemSelfE','pemberton',3,S=>has(S,'pemSelf')&&alive(S,'pemberton'),[L('pemberton','I considered it, ‹sir›. All the way to the Switchyard and back. I\'m still considering it. That\'s further than I\'ve got in forty years.')]);
E('pemLetterKept','pemberton',2,S=>has(S,'keepVaneLetter')&&alive(S,'pemberton'),[L('pemberton','The letter\'s still dry, ‹sir›. In the inside pocket. I check it at every red light, like a man checking for his wallet.')]);
E('brannMoney','brannigan',3,S=>has(S,'brannPaid'),[L('brannigan','I paid the gas bill. With your money. I hated every cent. The flat\'s warm. I hate that too.')]);
E('brannDoor','pemberton',4,S=>has(S,'brannForgot')&&alive(S,'pemberton'),[L('pemberton','Mrs. Brannigan came back to the office this morning, ‹sir›. Third time. She found the door again. She doesn\'t remember why she keeps coming. I didn\'t tell her.'),L('nostalgia','He did that to her twice. Now you have. She keeps finding the door.')]);
E('millerDale','miller',3,S=>has(S,'daleWitness'),[L('miller','Dale walked into my office at nine this morning with a carrier bag full of envelopes and said, "I\'m off sick." Then he sat down and talked for three hours. Did you do that?'),L('miller','Don\'t answer. I don\'t want to have to write it down.')]);
E('okaforBook','okafor',3,S=>has(S,'daniBook'),[L('okafor','I finished it. Dani\'s book. I sat up all night. She was right, it\'s the saddest thing I\'ve ever read.'),L('okafor','I\'m going to take it back to the library with her card. I think she\'d want it returned. She always returned things.')]);
E('okaforEzraStays','okafor',3,S=>has(S,'ezraStays')&&!has(S,'ezraDead'),[L('okafor','He\'s still in 404. He listens. I talk about Dani and the price of gas and he listens like it\'s the radio. Nobody\'s listened to me like that since my husband.')],{over:['okaforEzraFree']});
E('rostovaLolly','rostova',3,S=>has(S,'freddieSpared')&&alive(S,'rostova'),[L('rostova','I kept the lollipop. The one he\'d have given. It\'s in my desk drawer, with the name cards. I don\'t know what that says about me.')]);
E('gideonPassport','gideon',3,S=>has(S,'gideonFavour'),[L('gideon','Friday\'s nearly here. When they start dividing the Ward, you remember who made you a passport for a favour. I\'m only reminding. I\'m a pawnbroker. Reminding is the job.')]);
E('gideonSpaceE','gideon',3,S=>has(S,'gideonSpace')&&!S.flags.knowName,[L('gideon','The space is still there in the ledger. Blank line, best ink waiting. Whenever you\'ve got a name.')]);
E('gideonName','gideon',3,S=>has(S,'gideonSpace')&&!!S.flags.knowName,[L('gideon','Casey Morrow. I\'ve written it in. Best hand. Look.'),T('He turns the ledger round. Your name, in copperplate, in a book full of the dead and the owing.')],{over:['gideonSpaceE']});
E('gideonRoof','gideon',2,S=>has(S,'gideonWatchman'),[L('gideon','My man on the roof says there was a car parked across the street at dawn yesterday. Engine running. Nobody got out. He\'s watching it. I thought you should know.')]);
E('leoFront','leo',3,S=>has(S,'gigFront')&&alive(S,'leo'),[L('leo','Front row. You sat in the front row. Do you know nobody\'s ever done that? Not even my mom. My mom sits at the back so she can leave if I bomb.')]);
E('leoVaneLaugh','leo',3,S=>has(S,'gigVane')&&alive(S,'leo'),[L('leo','A guy in a cape came up to me after the set and said I\'d made Absalom Vane laugh. I said who. He said "the late Sheriff". I said I thought he was dead. He said "yes". I\'m putting that in the act.')]);
E('leoInvitedE','leo',2,S=>has(S,'leoInvited')&&!has(S,'gigFront')&&!has(S,'gigLaughed')&&alive(S,'leo'),[L('leo','You didn\'t come to the set. That\'s fine. That\'s totally fine. I did the bit about the vampire anyway. It killed. Ha. Sorry.')]);
E('leoFace','leo',3,S=>has(S,'leoWritesFace')&&alive(S,'leo'),[T('Leo has his notebook out before you\'ve said anything. He looks at you, writes, looks again.'),L('leo','Grey eyes. Tired. Collar up. Okay. Got you for today.')]);
E('leoColourE','leo',3,S=>has(S,'leoColour')&&alive(S,'leo'),[L('leo','It was grey this morning. Over the river. Then pink, for about a minute. Then just bright. I wrote it all down. WHAT COLOUR. Grey, pink, bright.')]);
E('leoBinnedE','leo',3,S=>has(S,'leoBinned')&&alive(S,'leo'),[T('The joke notebooks are out of the bin. They\'re on the coffee table again, stacked, with a mug on top so they can\'t escape.'),L('leo','I took them out. I know. Bigger things. But they\'re *my* things.')]);
E('kenLeo',['kenpruitt','pruitt'],3,S=>has(S,'kenKnowsLeo')&&!has(S,'pruittDead'),[L('kenpruitt','Called my sister. Rosa. First time since Christmas 2019. Told her Leo\'s alive and annoying. She cried. Then she said "of course he\'s annoying, he\'s a Pruitt".')]);
E('junieComing',['junie','leo'],2,S=>has(S,'junieOkay')&&alive(S,'leo'),[L('leo','Junie says I have to bring two cakes. One for Bea and one for her, because she always says she doesn\'t want any. She texted me a picture of a crucifix. I think it was a joke. I think.')]);
E('rostovaLuis','rostova',5,S=>has(S,'luisRostova')&&alive(S,'rostova'),[L('rostova','Luis is in cubicle four. Still. He won\'t go home until he knows what he is. I sit with him on my breaks. I signed his death certificate in August. I keep it in my pocket, so I can look at it and know I was wrong.')]);
E('millerLightE','miller',2,S=>has(S,'millerLight'),[L('miller','I asked the precinct for every "unusual lighting" report since 2015. There are sixty. Sixty, in the Ward, and every one of them was closed by the same federal office. You did that to my week.')]);
E('millerSleptE','miller',3,S=>has(S,'millerSlept'),[L('miller','I slept. Six hours. My sergeant thought I\'d been replaced by a pod person. Don\'t look smug.')]);
E('millerTrialE','miller',2,S=>has(S,'millerTrial'),[L('miller','St. Jude\'s still won\'t give me the volunteer records. So I\'ve been sitting in the car park, counting who goes in on Tuesdays. You\'d be surprised. Or you wouldn\'t.')]);
E('sevSangE',['severine','sev'],3,S=>has(S,'sevSang')&&alive(S,'severine'),[L('severine','You still have it in you. The four bars. I can hear them, faintly, when you talk. I didn\'t mean to give you that much.')]);
E('sevTruceE',['severine','sev'],2,S=>has(S,'sevTruce')&&alive(S,'severine'),[L('severine','The comedian, the shopkeeper, the old man in the car. Untouched. I\'m keeping my side. I\'d like that noticed.')]);
E('sevMillerE',['severine','sev'],3,S=>has(S,'sevSparesMiller')&&alive(S,'severine'),[L('severine','The detective came to the club last night. Asked questions at the bar. I sent her a drink and had her shown out. Politely. As promised. Write it down.')]);
E('tariqSign','tariq',3,S=>has(S,'tariqLeaves'),[T('The FOR SALE sign is still in the Lucky Mart window. Tariq has put a little cardboard cat next to it, so it looks less sad.')]);
E('teoStood','teo',3,S=>has(S,'teoStand')&&!has(S,'teoGone'),[L('teo','I stood next to her. At the precinct. She didn\'t say anything. She just put her hand on my shoulder like at the bus stop.')]);
E('tinyCoffeeE','tiny',1,S=>has(S,'tinyCoffee')&&alive(S,'tiny')&&!has(S,'tinyMorning'),[L('tiny','No coffee? Black. That\'s all I asked. Fine. Next time.')]);
E('tinyMorningE','tiny',3,S=>has(S,'tinyMorning')&&alive(S,'tiny'),[L('tiny','Bridge. Two coffees. Me and Marc, like idiots. He said the river looks like a car park at dawn. I said that\'s poetry, Marc. He said shut up.')],{over:['tinyCoffeeE']});
E('valkoLivesE','valko',3,S=>has(S,'valkoLives')&&alive(S,'valko'),[L('valko','Live. Remember. I wrote it on a bit of card and put it in my watch where his photograph used to be. It\'s ugly. I\'ll keep it.')]);
E('valkoWaitE','valko',4,S=>has(S,'valkoWait')&&alive(S,'valko'),[T('Valko is waiting where you left him. He gets up when he sees you, and brushes his knees, and doesn\'t ask.'),L('pulse','Hounds are very good at waiting. That doesn\'t mean it doesn\'t hurt.')]);
E('margoDuluthE','margo',3,S=>has(S,'margoDuluth')&&!has(S,'margoDead'),[L('margo','I rang my sister. Duluth. Her husband answered. He\'s still a bore. I said I might come for Christmas. I\'ve been practising pastry. Flour everywhere. It\'s wonderful.')]);
E('coralAfterE','coral',2,S=>has(S,'coralAfter')&&!has(S,'coralGone'),[L('coral','After Friday. You keep saying it. So I wrote it on my hand. Look. AFTER FRIDAY. Now you have to be around after Friday.')]);
E('rennieGull','rennie',5,S=>has(S,'gullFuneral'),[L('rennie','We\'ve all got our good coats out. Gull\'s name, in a church. Read out loud. We\'re practising saying it. Gull. Gull. Like that.')]);
E('mbekiGrace','mbeki',5,S=>has(S,'graceFuneral'),[L('mbeki','I\'ve pressed the suit. It hasn\'t been out since her graduation. It still fits. That\'s the worst thing, somehow. It still fits.')]);
E('sevHarrowE',['severine','sev'],3,S=>has(S,'sevGetsHarrow')&&alive(S,'severine'),[L('severine','The grey man. You\'ll leave him to me. I keep saying it to myself, like a girl with a ribbon. A hundred years, and you\'re the first to give me anything I wanted.')]);

/* ======================= the resolver ======================= */
function scan(){const S=G.S;if(!S)return;S.echoT=S.echoT||{};for(const e of LIST){if(S.echoT[e.id]!=null)continue;let ok=false;try{ok=!!e.cond(S,G);}catch(_){ok=false;}if(ok)S.echoT[e.id]=S.night;}}
G.echoScan=scan;
G.echoFor=npc=>{const S=G.S;if(!S||!npc)return null;scan();S.echo=S.echo||{};
  if(S.echo['n:'+npc]===S.night)return null;
  const c=[];
  for(const e of LIST){if(!e.who.includes(npc)||S.echo[e.id])continue;const t=S.echoT[e.id];if(t==null)continue;if(!e.same&&t>=S.night)continue;
    let ok=false;try{ok=!!e.cond(S,G);}catch(_){}if(ok)c.push(e);}
  const pe=powerEcho(npc,S);if(pe)c.push(pe);
  if(!c.length)return null;
  c.sort((a,b)=>(b.pri-a.pri)||((b.weight||0)-(a.weight||0))||((S.echoT[b.id]||0)-(S.echoT[a.id]||0)));
  const e=c[0];S.echo[e.id]=S.night;if(e.power)(S.powerLog||[]).forEach(p=>{if(p.who===npc)p.echoed=1;});S.echo['n:'+npc]=S.night;(e.over||[]).forEach(id=>{if(!S.echo[id])S.echo[id]=-1;});
  S.stats=S.stats||{};S.stats.echoes=(S.stats.echoes||0)+1;
  return typeof e.lines==='function'?e.lines(S,G):e.lines;};

/* every NPC click remembers who you walked up to, for echoes and for the power log */
document.addEventListener('DOMContentLoaded',()=>{
  const wrap=npc=>{const f=H.use[npc];if(!f||f.__echo)return;const w=async(S,G_)=>{G._echoNpc=npc;G._talkNpc=npc;try{return await f(S,G_);}finally{G._echoNpc=null;G._talkNpc=null;scan();}};w.__echo=true;H.use[npc]=w;};
  setTimeout(()=>{Object.keys(H.use).forEach(wrap);
    /* people who have no click handler of their own still go through STORY.use */
    const ST=NL.STORY,u0=ST.use;ST.use=async function(id,S,G_){const isP=!!((NL.CHARS&&NL.CHARS[id])||(NL.EXTRAS&&NL.EXTRAS[id]));if(!isP||(H.use[id]&&H.use[id].__echo))return u0.call(this,id,S,G_);
      G._echoNpc=id;G._talkNpc=id;try{return await u0.call(this,id,S,G_);}finally{G._echoNpc=null;G._talkNpc=null;scan();}};
    /* scenes reached from the map rather than by walking up to someone */
    const ENTRY={'dm.0':'dominic'};const t0=G.talk;G.talk=function(id,o){if(ENTRY[id]&&!G._echoNpc){G._echoNpc=ENTRY[id];G._talkNpc=ENTRY[id];const r=t0.call(this,id,o);Promise.resolve(r).finally(()=>{G._talkNpc=null;scan();});return r;}return t0.call(this,id,o);};
  },0);
});
})();
