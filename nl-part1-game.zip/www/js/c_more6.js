'use strict';
/* THE NEW LORD — more of Margo, Valko, Rostova and Coral */
NL.Script.add(String.raw`
// =====================================================================
// MARGO KOWALSKI
// =====================================================================
# mgY.0 arc=margo night=3,4 label="\"Margo. I want to talk about the door.\"" if=room:pawn&actor:margo&flag:margoDoor prio=3
@focus margo
> She's on the folding chair by Gideon's counter with her handbag on her knees and her coat buttoned to the neck, like a woman in a doctor's waiting room.
margo: The door. Yes. I knew you would. I've been waiting for you to.
margo: Go on, then. Shout. Bite. Whatever it is you do. I've earned it.
* "You locked me in with a dead man and the sunrise coming."  -> mgY.anger
* "You locked it because Leo was asleep in the back. I know."  -> mgY.leo
* "I forgive you, Margo."  -> mgY.forgive {do lean:mercy+1}

# mgY.anger
margo: I did. I did. I stood on the other side of that door and I heard you wake up. I heard you scratching. I heard you say "please" to a door.
margo: I stood there for an hour with my hand on the latch. Then I went home and was sick in the sink.
* "Why didn't you open it?"  -> mgY.why
* "I forgive you."  -> mgY.forgive {do lean:mercy+1}

# mgY.why
margo: Because I'd taken five thousand dollars to make sure it held. Because I'm a coward. Because my father put that release in with his own hands in 1961 and I took it off with a screwdriver in five minutes, for money, and I couldn't look at it.
margo: Because I thought if I opened it, whatever came out would be my fault. And it was. It was my fault anyway.
@next mgY.end

# mgY.leo
> She looks up. Her eyes are wet.
margo: He was asleep on the sacks in the back. He always sleeps on the sacks. He was twenty feet from that door.
margo: I didn't know what you'd be. I thought you'd come out of there like a dog out of a cage. I'd known Leonard since he was nineteen.
margo: I'd do it again. For him. I'm sorry. I'd do it again.
{do rel:margo+1}
@next mgY.end

# mgY.forgive
> She doesn't say anything at all. She looks at you. Then she opens her handbag, takes out a cotton handkerchief that's been ironed into a perfect square, and presses it to her mouth.
margo: You can't. You can't just... nobody forgives anyone. Not in this Ward. Not like that.
* "I just did."  -> mgY.forgive2

# mgY.forgive2
margo: ...Well. Well. Then I suppose I'll have to live with it.
> She folds the handkerchief and puts it back in the bag. Her hands are shaking.
margo: That's worse, you know. Being forgiven. That's much worse than being shouted at.
{do flag:margoForgiven=1; rel:margo+3; comp+2}
@next mgY.end

# mgY.end
@end

# mgY.pier arc=margo night=4,5 label="\"Margo. What will you do, after?\"" if=actor:margo&rel:margo>=2 prio=1
@focus margo
margo: After. If there is an after. If the Lady doesn't put me in my own walk-in.
margo: Sell the shop. Burn the freezer. My sister in Duluth makes pierogi. I said that, didn't I? I keep saying it. I've been saying it for twenty years.
* "Then do it. Duluth. Pierogi."  -> mgY.duluth
* "Keep the shop. Make it a different kind of shop."  -> mgY.shop

# mgY.duluth
margo: Duluth. It's cold. It's very cold. The lake freezes. My sister's husband is a bore.
margo: ...I'd like that. I'd like to stand in a kitchen with flour on my hands and make something that doesn't have to be hidden.
{do flag:margoDuluth=1; rel:margo+1}
@end

# mgY.shop
margo: A different kind. A butcher's that's just a butcher's. Mince and sausages and nothing in the walk-in but meat.
margo: Leonard could run the counter. Properly. In the daytime. With the lights on.
margo: ...You know, nobody's suggested I could just stop. Just stop doing the other thing. Like it was a choice.
{do flag:margoShop=1; rel:margo+2}
@end

// =====================================================================
// VALKO
// =====================================================================
# vxY.0 arc=valko night=4 label="\"Valko. Run with me tonight.\"" if=flag:valkoAlly&!flag:valkoDead&rel:valko>=3&!flag:vxRun prio=1
@focus valko
valko: Run. With you. Now? There's floodlights. There's vans.
> His ears, the ones that aren't quite ears, go forward.
valko: ...Yes. Yes. Where?
* "The roofs. All of them. From the Rookery to the river."  -> vxY.roofs
* "The docks. Show me where you go."  -> vxY.docks

# vxY.roofs
> You run. Rooftops, chimneys, a gap between Halloran Street and Kerr that you shouldn't be able to jump and do. The floodlight at the crossing sweeps and you're already past it. Valko runs beside you, then ahead, then back, like a dog who can't decide which is more fun.
> At the end, on the roof of St. Agatha's, by the bell, you both stop. The whole Ward under you. The river. The lights.
valko: There. You see? That's what it's for. Being fast. Not for killing. For this.
{do flag:vxRun=1; rel:valko+2; comp+3; tick:30}
@end

# vxY.docks
> The docks. A gap in a chain-link fence he knows. A container yard. A crane he climbs like a ladder, and you follow. At the top, two hundred feet up, in the wind, a little platform with a coffee tin full of cigarette ends and a blanket.
valko: Mine. Since 1979. Nobody knows. I come up here to watch the ships go out.
valko: I've never brought anyone. Rask would have liked it. He liked high places. He said you could see trouble coming.
{do flag:vxRun=1; flag:valkoCrane=1; rel:valko+3; comp+2; tick:30}
@end

# vxY.5 arc=valko night=5 label="\"Valko. If it goes wrong tonight.\"" if=flag:valkoAlly&!flag:valkoDead&time<235 prio=2
@focus valko
valko: If it goes wrong. Yes.
valko: If it goes wrong, I'm going to do something stupid. I want you to know now, so you don't waste time telling me not to.
* "What are you going to do?"  -> vxY.5a
* "Don't. Whatever it is."  -> vxY.5b

# vxY.5a
valko: If they burn you, I go into the light after you. I've decided. A Hound doesn't outlive the pack twice.
* "No. You live. Someone has to remember."  -> vxY.5b
* "...All right."  -> vxY.5c

# vxY.5b
valko: Live. Remember. That's what Rask's jar said, isn't it. Somebody has to ask. Somebody has to remember.
valko: Fine. Fine. If it goes wrong, I'll live. I'll hate it. I'll live.
{do flag:valkoLives=1; rel:valko+1}
@end

# vxY.5c
> He nods, once, satisfied, the way you'd nod at a weather forecast.
{do flag:valkoFollows=1}
@end

// =====================================================================
// ROSTOVA
// =====================================================================
# rxY.0 arc=rostova night=4,5 label="\"Elena. Do you sleep?\"" if=alive:rostova&rel:rostova>=3 prio=0
@focus rostova
rostova: Sleep. No. I lie under my desk with my coat over me and think about the seven, and Dani, and you, and the Sheriff, in that order, until it gets light.
rostova: Then I get up and do a ward round. Then I do it all again.
* "Tell me about Pasha."  -> rxY.pasha
* "What would you do if you could stop? All of it?"  -> rxY.stop

# rxY.pasha
rostova: Pasha. My brother. He was six when Papa went out for cigarettes. Nineteen when he died. Leukaemia. I was a resident. I knew everything. I knew exactly what was happening, every day, every cell. It didn't help him at all.
rostova: He made me promise not to become a "cold doctor". That's what he called them. The ones who look at the chart and not the bed.
rostova: I became the coldest doctor in this hemisphere. I looked at your kind like charts for six years.
* "You're not cold, Elena. You sat with Mr. Feeney."  -> rxY.warm {if seen:rR.merc}
* "You can keep the promise from now."  -> rxY.warm

# rxY.warm
> She looks at you for a long time.
rostova: From now. Yes. That's what Pasha would say. "From now, Lenochka." He always said my name like that when he wanted something.
{do rel:rostova+2; comp+1}
@end

# rxY.stop
rostova: Stop. Medicine? No. Never. I'd stop lying. I'd stop working for men who say please. I'd go back to a ward with windows and children in it and sit with them.
rostova: That's all I ever wanted, actually. To sit with them. I got lost.
{do rel:rostova+1}
@end

// =====================================================================
// CORAL
// =====================================================================
# coY.0 arc=coral night=4 label="\"Coral. Did you get the interview?\"" if=room:reliquary&flag:coralFree prio=3
@focus coral
> She's not in costume. She's at the bar in jeans and a sweater, with a coffee, on the customer side. Lisette, across the room, is pretending very hard not to see her.
coral: Monday. Dental receptionist. Ten till four. In the daytime. With windows.
coral: I came back to get my locker. I'm not working. I'm a customer. I've got a coffee. I'm paying for it. Look at me, paying for a coffee in the Reliquary.
* "How does it feel?"  -> coY.feel
* "Lisette's watching you."  -> coY.lis

# coY.feel
coral: Terrifying. Like jumping off something. I keep thinking someone's going to grab my arm and say "Coral, you're on in five."
coral: Nobody does. Nobody's going to. That's the scary part.
{do comp+1}
@end

# coY.lis
coral: I know. Let her watch. I'm not hers any more.
> She raises her coffee cup across the room at Lisette. A small salute. Lisette, after a long moment, raises her glass back. Just an inch.
coral: ...Huh. I didn't expect that.
{do rel:coral+1; rel:lisette+1}
@end
`,'c_more6');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.margoShop&&!f.margoDead)o.push(['Kowalski\'s','Is a butcher\'s again. Just a butcher\'s. The walk-in has a new release on the inside, fitted by Gideon. Leo runs the counter in the mornings, in daylight, and is very bad at it. Margo hasn\'t been happier since 1979.']);
  else if(f.margoDuluth&&!f.margoDead)o.push(['Margo Kowalski','Duluth. The lake froze in January. She makes pierogi with her sister and her sister\'s boring husband and never once puts anything in a freezer that she couldn\'t explain to a policeman.']);
  if(f.valkoCrane&&!f.valkoDead)o.push(['A crane on the docks','Has two blankets at the top now, and two coffee tins.']);
  return o;});
