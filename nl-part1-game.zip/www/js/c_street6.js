'use strict';
/* THE NEW LORD — street events, part six: small choices on the walk between things, where nobody is watching but you */
NL.Script.add(String.raw`
# ev.mugging street=2,3,4 w=2
> Kerr Street, under the railway bridge. A kid of maybe sixteen with a kitchen knife, shaking, and an old man in a bus driver's jacket with his wallet already out, holding it toward the knife like a man feeding a horse he doesn't trust.
> Neither of them has seen you. The kid's pulse is going like a hummingbird.
frenzy: Two of them. Both warm. Nobody looking.
* Step out of the dark. Just stand there. Let the kid see what you are.  -> ev.mg1
* "Put the knife down, son. He's got eleven dollars. I can see it from here."  -> ev.mg2
* Take the kid's wrist before he knows you've moved.  -> ev.mg3
* Keep walking. Not your business.  -> ev.mg4

# ev.mg1
> You let your eyes do the thing. Not much. Just enough.
> The kid sees. The knife hits the sidewalk before he's decided to drop it. He runs, all elbows, out the far side of the bridge, and you hear him crying before he's gone.
> The old man doesn't run. He looks at you. Then he puts his wallet back in his jacket very carefully.
* "Go home."  -> ev.mg5

# ev.mg5
> He nods. At the end of the bridge he turns round.
> "Thank you," he says. "I think." And then he goes, faster than he came.
{do heat+1; comp+1}
@end

# ev.mg2
> The kid jumps a foot. The knife turns toward you. It's a bread knife. It has a little serrated edge and a wooden handle with a burn mark on it, the kind that lives in a drawer next to a toaster.
> "Back off. Back off, I swear to God."
? velvet 9 "You don't want his eleven dollars. You want to go home and not have done this. So go home."  -> ev.mg6 | ev.mg7 {id ev_mg}

# ev.mg6
> He looks at the knife in his hand like he doesn't know whose it is.
> Then he's gone, and the old man is leaning against the wall with his hand on his chest, laughing in a way that isn't really laughing.
> "Eleven dollars," he says. "How'd you know it was eleven?"
{do comp+2; lean:mercy+1}
@end

# ev.mg7
> He doesn't hear you. He lunges. Not at you. At the old man, at the wallet, at anything.
> You're there first. You don't mean to be. The knife goes into your forearm up to the handle. It doesn't hurt. The kid screams when he sees that it doesn't hurt.
> He runs. The old man runs the other way. You stand under the bridge alone and pull a bread knife out of your arm and there's no blood at all.
{do heat+1; comp-1; vitae-1}
@end

# ev.mg3
> You have his wrist. You don't remember crossing the distance. He's looking at your hand on his wrist, and his whole arm has gone white, and the knife's fallen, and he's making a sound like a kettle.
* Let him go.  -> ev.mg8
? apex 10 "Hold on. Look at him. Make sure he never does this again."  -> ev.mg9 | ev.mg8 {id ev_mg2} {red}
* Feed. Just a little. He'll think he fainted.  -> ev.mg10

# ev.mg8
> You let go. He runs. The old man has already gone.
> You pick up the bread knife and put it in a bin on the way out. You don't know why that seems important.
@end

# ev.mg9
> You hold on. You look at him. You let him look back, into the part of you that's eleven generations of Sovereign blood.
> When you let go, he doesn't run. He walks, very slowly, out the far side of the bridge with his hands open at his sides, and you know, without knowing how you know, that he's walking home, and that he'll be in bed in twenty minutes, and that he'll never pick up a knife in anger as long as he lives.
tenant: That was me. That was something I used to do. I did it to a Gilded boy in 1929 and he became a Methodist.
{do lean:pride+1; xp:15}
@end

# ev.mg10
> Just a little. He sags against you like a sleepy child. The old man is gone. Nobody's looking.
> When he wakes up, five minutes later, sitting against the bridge pillar, he'll think he fainted. He'll go home. He won't remember your face.
{do feed:1:choleric:a boy with a bread knife:mortal; lean:restraint-1}
@end

# ev.mg4
> You keep walking. Behind you, a scuffle. Somebody running. Nobody screaming, which is something.
> You'll never know how it went. That's the price of not knowing. It's very cheap at the time.
{do lean:mercy-1}
@end

# ev.kels street=2,3,4,5 w=2
> Outside the Anchor on Dock Road, a woman in a bridesmaid's dress the color of a highlighter pen, sitting on the curb with one shoe off, eating a gyro and crying in a way that's mostly about the gyro.
> "Are you a ghost?" she says. "You look like a ghost. Sorry. That's rude. You look really nice. For a ghost."
* Sit down next to her.  -> ev.dk1
* "Where are your friends?"  -> ev.dk2
* "I'm a ghost. Go home before I haunt you."  -> ev.dk3

# ev.dk1
> You sit down on the curb in the Sheriff's coat. She offers you some gyro. You decline.
> "My sister got married today," she says. "To Derek. I hate Derek. Derek's fine. I hate that he's fine. She's going to be fine forever and I'm going to be... this. On a curb. With a gyro."
* "You're going to be fine too. Just not tonight."  -> ev.dk4
* "What's wrong with fine?"  -> ev.dk5

# ev.dk4
> She thinks about it with enormous seriousness.
> "Not tonight. Okay. Okay, that's fair. That's very fair." She puts her shoe back on. "You're a really good ghost."
> Her phone rings. It's her sister. She answers it and says "I love Derek," very loudly, and starts crying again, the good kind.
{do comp+2}
@end

# ev.dk5
> "Nothing's wrong with fine. That's what's wrong with it." She points the gyro at you. "You get it. You look like you get it. You look like someone who used to be fine."
nostalgia: You did. You were. You'd forgotten.
{do comp+1}
@end

# ev.dk2
> "Inside. Doing shots. With Derek's cousins. Derek's cousins are all called Mike."
> She waves at the window of the Anchor. Inside, a lot of people in highlighter pink are singing. One of them sees her through the glass and comes out at a run.
> "Kels! Kels, we've been looking everywhere!"
> She gets scooped up and carried back inside. Over her friend's shoulder she waves at you with the gyro.
{do comp+1}
@end

# ev.dk3
> "OKAY," she says, and gets up, and goes inside, and you hear her announce to the whole bar: "THERE'S A GHOST OUTSIDE AND IT TOLD ME TO GO HOME."
> A cheer goes up. Somebody buys her a drink.
@end

# ev.dog street=3,4,5 w=1 if=clan:stray|clan:hounds|clan:rot
> A dog. A big grey lurcher with one ear up and one ear down, following you down Halloran Street at a respectful distance. When you stop, it stops. When you look at it, it lies down on the wet sidewalk and puts its chin on its paws.
> It's been following you for six blocks. It has a collar, but no tag.
* Kneel down. Hold out your hand.  -> ev.dg1
* "Go home."  -> ev.dg2

# ev.dg1
> It comes to you. Slowly, belly low. It sniffs your hand. It doesn't flinch at the cold. It licks your wrist, once, where the vein would be if you still used it.
> Then it sits down beside you, against your leg, like it's decided.
* "All right. Come on, then."  -> ev.dg3
* Find the address on the collar.  -> ev.dg4

# ev.dg3
> It comes. It walks at heel, the whole way, without being asked. When you go inside anywhere, it waits by the door. Nobody can quite remember it being there when they look away.
{do flag:strayDog=1; comp+2}
tenant: A dog. We have a dog now. I had a dog in Ajaccio. He was called Bonaparte. It was a different time.
@end

# ev.dg4
? autopsy 8 "Look inside the collar."  -> ev.dg5 | ev.dg2 {id ev_dg}

# ev.dg5
> Inside the collar, written in marker: *ROSIE · 41 FERRIER LN · PLS RING BELL.*
> Forty-one Ferrier Lane is a house with a light on in the hall at three in the morning. You ring the bell. An old man in a dressing gown opens the door, sees the dog, and sits down on the step.
> He doesn't ask who you are. He holds the dog's head in both hands and says her name over and over.
{do comp+3; lean:mercy+1}
@end

# ev.dg2
> It gets up. It looks at you. It goes, slowly, back up Halloran Street, looking back twice.
@end

# ev.vigil street=3,4 w=1 if=night>=3
> On the steps of the Port Vellum Public Library, forty candles in jam jars and a laminated poster: HAVE YOU SEEN THEM? Seven faces. Seven names. A girl with braids. A man in a bakery apron. An old man in a bus company jacket. And taped beside the poster, on a sheet of its own, an eighth: Danielle Okafor, laughing at something off-camera.
> A woman is kneeling, relighting the ones the wind's put out. She doesn't look up.
* Help her light them.  -> ev.vg1
* Look at the seven faces. Properly.  -> ev.vg2
* Walk past.  -> ev.vg3

# ev.vg1
> You kneel. She hands you a lighter without looking. Together you go along the steps, relighting the ones that have gone out.
> "My boy's number six," she says, after a while. "Luis. Everyone thinks he drove the 9. He didn't. He rode it. Every night. To his job at the bakery."
> You don't say anything. You light the candle under Luis Ferreira's picture.
{do comp+1; lean:mercy+1; flag:vigilLit=1}
@end

# ev.vg2
> You look at them. Seven people who went to a free clinic because they were sick or broke or both. Seven people who had somebody ring the police.
> You were nearly the eighth. You *were* the eighth. You just didn't stay dead.
pulse: Somebody rang nine times for you. Somebody's still ringing.
{do comp-1; flag:sevenFaces=1}
@end

# ev.vg3
> You walk past. The candles flicker in your wake, the way they always do now, as if something cold has gone by.
@end

# ev.photo street=2,3,4,5 w=1 if=clan:wraiths|clan:moths
> A tourist couple at the corner of Vine and Kerr, at two in the morning, lost, with a phone held up. "Excuse me! Excuse me, could you take our picture? With the sign?" The sign says PORT VELLUM · THE CITY THAT NEVER SLEPT, which is a typo nobody's ever fixed.
* Take the picture.  -> ev.ph1
* "I'm really not photogenic."  -> ev.ph2

# ev.ph1
> You take the picture. You hand the phone back. They look at it and frown.
> "That's weird," says the man. "There's a sort of... smudge. Right where you were standing. Like the camera saw something."
> "It's the rain," says the woman. "It's just the rain."
> It isn't the rain.
{do heat+0}
@end

# ev.ph2
> "Oh, no, we want *you* in it! A local! Come on!"
> You let them take one. The flash goes. They look at the screen. Two smiling tourists and the sign, and, between them, a coat. Just a coat. Standing on its own.
> They look at the screen. They look at you. They look at the screen. "Thank you so much," says the woman, very brightly, and they walk away fast, holding hands.
{do heat+1}
@end

# ev.cello street=2,3,4,5 w=2
> In the Vine Street underpass, a busker with a cello and an open case with four dollars and a button in it, playing Bach to nobody at two in the morning. He's good. He's really, painfully good. His fingers are blue with cold.
* Listen. All the way to the end.  -> ev.cel1
* Put something in the case.  -> ev.cel2 {if cash>=5}
? stagecraft 10 "Stand where the commuters will be at six and start clapping. Loudly. Start a crowd."  -> ev.cel3 | ev.cel1 {id ev_cel}

# ev.cel1
> You listen. All of it. The prelude, the allemande, the sarabande. He doesn't look up until the very end. When he does, he sees you, and nods, and doesn't ask why you're not breathing.
> "Thanks for staying," he says. "Nobody stays."
nostalgia: Bach. Cello Suite No. 1. The sarabande. You could sing the bass line now if you wanted to. You didn't know that a week ago. {if clan:choir}
{do comp+1}
@end

# ev.cel2
> You put twenty in the case. He stops playing.
> "That's... that's too much."
> "It's not," you say, and he looks at you for a long time, and then he plays the sarabande again, just for you, slower.
{do cash-20; comp+2}
@end

# ev.cel3
> At ten to six, when the first commuters come down the underpass steps with their coffees, you're standing by the wall, clapping. Slow, steady, enthusiastic, the way you'd clap at the end of a gig.
> One woman stops. Then two men. Then a kid with a skateboard. By ten past, there are twenty people in the underpass and the case is full of change and a man in a suit is filming it on his phone.
> The busker looks over their heads at you. You're already gone.
{do comp+2; xp:15:Encore}
@end

# ev.fdom street=3,4,5 w=1 if=flag:confessed|flag:metDominic
> Outside St. Agnes's on Halloran Street, Father Dominic, in a cardigan, smoking a cigarette he'd deny, at three in the morning.
> "You," he says. "My Wednesday. Come here. I want to ask you something and I want you to answer it honestly, because I'm a priest and I'll know."
* "Ask."  -> ev.fd1

# ev.fd1
> "Is there anything after? For you. For any of you. When you go. Is there anything?"
> He's not asking for you. You can tell. He's asking for himself, at three in the morning, with a cigarette he gave up for Lent in 1997.
* "I don't know, Father. I've only been dead a week."  -> ev.fd2
* "There's a man in my head who died on Monday. He's still here. So: something."  -> ev.fd3
* "No. Nothing. Just the dark."  -> ev.fd4

# ev.fd2
> He laughs. He coughs. He laughs.
> "A week. Of course. I'm asking a toddler about the afterlife." He stubs out the cigarette. "Thank you. That's the most honest answer I've had in forty years of asking."
{do lean:candour+1}
@end

# ev.fd3
> He goes still. He looks at you, very hard, the way he must look at people in the confessional through the grille.
> "Still here," he says. "Huh." He puts the cigarette out on the railing very carefully. "Huh. Goodnight, my Wednesday. Thank you."
> He goes back inside. Through the door, a minute later, you hear him start to pray, very quietly, in Latin, and sound surprised by it.
{do sync+1; comp+1}
tenant: I've never been a sermon before. I rather like it.
@end

# ev.fd4
> "Nothing," he says. "Right."
> He finishes the cigarette. He lights another. He doesn't go back inside for a long time.
{do lean:candour-1}
@end

# ev.kids2 street=3,4,5 w=1 if=flag:doorNan|seen:ev.ky1
> A drawing taped to a lamppost on Halloran Street in a plastic sleeve to keep the rain off. Crayon. A figure in a long black coat with very big teeth and a crown, holding hands with a much smaller figure in a Sixers jersey. Underneath, in careful capitals: *MY FREND THE VAMPIRE · BY KYLE · AGE 9.*
* Take it.  -> ev.kd1
* Leave it where it is. Where people can see.  -> ev.kd2

# ev.kd1
> You fold it into the inside pocket of the coat, next to the flip phone and the brass lighter and everything else the Sheriff carried for a hundred years. It fits.
{do flag:kyleDrawing=1; comp+2}
tenant: Put it next to the lighter. No. The other side. Away from the lighter. Yes. There.
@end

# ev.kd2
> You leave it. Somebody will see it. Somebody will smile at the spelling. Somebody, in a few years, will remember it, and not know why.
{do comp+1}
@end
`,'c_street6');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.strayDog)o.push(['A grey lurcher with one ear up','Sleeps across the doorway of the Sheriff\'s study by day. Pemberton has bought it a bed. It doesn\'t use the bed. It has never once been photographed.']);
  if(f.kyleDrawing)o.push(['A crayon drawing','MY FREND THE VAMPIRE. In the inside pocket of a dead man\'s coat, next to the flip phone, away from the lighter.']);
  return o;});
