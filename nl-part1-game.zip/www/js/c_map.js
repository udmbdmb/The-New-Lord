'use strict';
/* THE NEW LORD — the drawn map: an inked street plan of the Marrow Ward above the travel list.
   Pins sit where each place is in the Ward; tap one to go there. */
(function(){const Camp=NL.Camp,G=NL.G;if(!Camp)return;
const W=1000,H=720;
// where things are: [x,y] in map units
const PIN={lane:[205,372],laundry:[150,300],riaz:[250,300],gull:[120,470],velvet:[95,600],dragonwall:[300,330],tattoo:[330,262],shelter:[268,405],grand:[355,420],anchor:[175,415],shelterroof:[420,355],
  reliquary:[470,170],pawn:[402,205],lantern:[560,210],courthouse:[600,120],clerk:[628,142],belltower:[520,96],dunmore:[440,128],chapel:[700,230],cellar:[488,196],freddie:[458,150],study:[540,150],roux:[505,145],choir:[520,96],masque:[470,170],ashrite:[455,190],the9:[420,355],
  stjude:[735,250],rookery:[790,340],bus9:[640,330],grave:[860,110],heights:[880,165],mbeki:[835,400],station4:[760,290],precinct:[690,410],roof5:[805,320],cbasement:[600,120],observatory:[930,80],dinner:[780,350],six_c:[800,330],doors:[790,340],
  yard:[520,540],pf:[520,540],pier9:[770,640],lund:[690,615],daimler:[400,470],vellumsteps:[600,470],marek:[380,488],servicetunnel:[300,470]};
const BLOCKC={A:[220,420],B:[500,170],C:[790,300],D:[560,560]};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function svgMap(list,here){
  const pin=p=>{let xy=PIN[p.id];if(!xy){const c=BLOCKC[p.block]||[500,360];let h=0;for(const ch of p.id)h=(h*31+ch.charCodeAt(0))>>>0;xy=[c[0]+((h%140)-70),c[1]+(((h>>8)%110)-55)];PIN[p.id]=xy;}return xy;};
  // spread pins that share a spot
  const used={};const pos=list.map(p=>{let [x,y]=pin(p);const k=Math.round(x/18)+','+Math.round(y/18);const n=used[k]=(used[k]||0)+1;if(n>1){const a=n*2.1;x+=Math.cos(a)*22*Math.ceil(n/3);y+=Math.sin(a)*22*Math.ceil(n/3);}return [x,y];});
  let s=`<svg class="wmap" viewBox="0 0 ${W} ${H}" role="img" aria-label="Map of the Marrow Ward">
<defs>
 <filter id="wmInk" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency=".02" numOctaves="2" seed="7" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="5"/></filter>
 <filter id="wmPaper"><feTurbulence type="fractalNoise" baseFrequency=".8" numOctaves="3" seed="3"/><feColorMatrix values="0 0 0 0 .55  0 0 0 0 .45  0 0 0 0 .32  0 0 0 .22 0"/><feComposite in2="SourceGraphic" operator="in"/></filter>
 <radialGradient id="wmVig" cx="50%" cy="48%" r="70%"><stop offset="60%" stop-color="#000" stop-opacity="0"/><stop offset="100%" stop-color="#000" stop-opacity=".65"/></radialGradient>
 <pattern id="wmHatch" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><line x1="0" y1="0" x2="0" y2="7" stroke="#c9b48a" stroke-opacity=".16" stroke-width="1.2"/></pattern>
 <pattern id="wmHatch2" width="9" height="9" patternUnits="userSpaceOnUse" patternTransform="rotate(-25)"><line x1="0" y1="0" x2="0" y2="9" stroke="#c9b48a" stroke-opacity=".1" stroke-width="1"/></pattern>
 <pattern id="wmWater" width="34" height="14" patternUnits="userSpaceOnUse"><path d="M0 7 q8.5 -5 17 0 t17 0" fill="none" stroke="#7fa6a8" stroke-opacity=".35" stroke-width="1.2"/></pattern>
 <pattern id="wmGrave" width="16" height="16" patternUnits="userSpaceOnUse"><path d="M8 4v8M5 7h6" stroke="#c9b48a" stroke-opacity=".35" stroke-width="1.1"/></pattern>
 <pattern id="wmRail" width="10" height="10" patternUnits="userSpaceOnUse"><line x1="5" y1="0" x2="5" y2="10" stroke="#c9b48a" stroke-opacity=".5" stroke-width="2"/></pattern>
</defs>
<rect width="${W}" height="${H}" fill="#1d1712"/>
<rect width="${W}" height="${H}" fill="#2a2119" filter="url(#wmPaper)"/>
<g filter="url(#wmInk)" stroke="#d8c39a" fill="none" stroke-linecap="round" stroke-linejoin="round">
 <!-- river Vellum -->
 <path d="M-20 655 C 160 640, 300 700, 470 660 S 760 600, 1020 640 L1020 740 L-20 740Z" fill="#1f2a2c" stroke-width="2"/>
 <path d="M-20 655 C 160 640, 300 700, 470 660 S 760 600, 1020 640 L1020 740 L-20 740Z" fill="url(#wmWater)" stroke="none"/>
 <!-- the Heights: contour hill -->
 <g stroke-opacity=".5" stroke-width="1.3"><ellipse cx="885" cy="130" rx="130" ry="95"/><ellipse cx="890" cy="122" rx="95" ry="66"/><ellipse cx="895" cy="114" rx="58" ry="40"/><ellipse cx="900" cy="108" rx="24" ry="16"/></g>
 <rect x="820" y="80" width="80" height="58" fill="url(#wmGrave)" stroke-opacity=".5" stroke-width="1.2" rx="6"/>
 <!-- block washes -->
 <path d="M30 250 L370 230 L395 520 L60 560Z" fill="url(#wmHatch)" stroke-opacity=".25" stroke-width="1"/>
 <path d="M360 60 L680 50 L700 260 L380 275Z" fill="url(#wmHatch2)" stroke-opacity=".25" stroke-width="1"/>
 <path d="M630 200 L960 240 L940 470 L620 450Z" fill="url(#wmHatch)" stroke-opacity=".25" stroke-width="1"/>
 <!-- the Sunken Switchyard: a pit with rails -->
 <path d="M410 500 Q 520 470 650 500 L640 600 Q 520 620 420 595Z" fill="#17120e" stroke-width="2.2"/>
 <g stroke-width="1.4" stroke-opacity=".75"><path d="M300 440 C 400 470, 450 520, 520 545 S 700 560, 1000 520"/><path d="M300 452 C 395 482, 445 532, 518 557 S 700 572, 1000 532"/>
  <path d="M430 520 C 480 540, 560 585, 640 580"/><path d="M432 532 C 480 552, 560 597, 638 592"/></g>
 <path d="M300 446 C 400 476, 450 526, 519 551 S 700 566, 1000 526" stroke="url(#wmRail)" stroke-width="7" stroke-opacity=".7"/>
 <!-- main streets: double-ruled -->
 <g stroke-width="2.4">
  <path d="M10 380 C 200 365, 420 370, 640 380 S 860 395, 990 385"/><path d="M10 396 C 200 381, 420 386, 640 396 S 860 411, 990 401"/>
  <path d="M418 40 C 410 200, 425 330, 415 470 S 430 600, 420 650"/><path d="M432 40 C 424 200, 439 330, 429 470 S 444 600, 434 650"/>
  <path d="M90 640 C 250 520, 520 360, 720 285 S 900 220, 990 210"/><path d="M100 652 C 260 532, 528 372, 728 297 S 905 232, 995 222"/>
  <path d="M370 160 C 470 150, 560 160, 690 150"/><path d="M370 172 C 470 162, 560 172, 690 162"/>
  <path d="M120 630 C 300 620, 520 620, 900 600"/>
 </g>
 <!-- lanes -->
 <g stroke-width="1.4" stroke-opacity=".8"><path d="M150 260 C 170 330, 200 380, 215 470"/><path d="M250 270 L 300 400"/><path d="M330 240 C 360 300, 380 340, 420 350"/>
  <path d="M600 90 L 610 260"/><path d="M700 200 L 690 450"/><path d="M760 250 C 790 300, 800 340, 830 420"/><path d="M500 210 L 495 380"/><path d="M560 210 C 600 300, 600 360, 605 470"/></g>
 <!-- the flyover -->
 <path d="M40 470 C 120 460, 200 470, 290 455" stroke-width="5" stroke-opacity=".55"/>
 <!-- buildings: little inked blocks -->
 <g stroke-width="1.6" fill="#241c16">
  <rect x="445" y="150" width="62" height="40" transform="rotate(-3 476 170)"/><rect x="385" y="190" width="32" height="26"/><rect x="580" y="96" width="60" height="44"/>
  <rect x="510" y="70" width="18" height="34"/><rect x="540" y="196" width="40" height="24"/><rect x="720" y="232" width="56" height="40" transform="rotate(4 748 252)"/>
  <rect x="770" y="310" width="22" height="54"/><rect x="798" y="306" width="22" height="58"/><rect x="826" y="312" width="22" height="52"/>
  <rect x="670" y="396" width="44" height="30"/><rect x="186" y="355" width="40" height="22"/><rect x="232" y="288" width="34" height="24"/><rect x="134" y="288" width="34" height="22"/>
  <rect x="340" y="404" width="34" height="28"/><rect x="74" y="586" width="44" height="26"/><rect x="676" y="598" width="34" height="22"/>
  <path d="M760 612 l40 -6 l2 50 l-40 6z"/>
 </g>
 <!-- the bell tower spire and the observatory dome -->
 <path d="M519 68 l0 -22 l-6 12 m6 -12 l6 12" stroke-width="1.6"/><path d="M915 76 a16 16 0 0 1 32 0z" fill="#241c16" stroke-width="1.6"/>
 <!-- compass -->
 <g transform="translate(945 560)" stroke-width="1.3"><circle r="26" stroke-opacity=".6"/><path d="M0 -34 L6 0 L0 34 L-6 0Z" fill="#d8c39a" fill-opacity=".25"/><path d="M-34 0 L34 0" stroke-opacity=".6"/></g>
</g>
<g fill="#d8c39a" font-family="Georgia,serif" font-style="italic" text-anchor="middle" opacity=".78">
 <text x="945" y="512" font-size="16" font-style="normal" font-weight="700">N</text>
 <text x="520" y="690" font-size="22" letter-spacing="6">THE VELLUM</text>
 <text x="200" y="545" font-size="15" letter-spacing="3" transform="rotate(-6 200 545)">THE ABATTOIR STRIP</text>
 <text x="520" y="40" font-size="15" letter-spacing="3">RELIQUARY ROW</text>
 <text x="805" y="492" font-size="15" letter-spacing="3">ST. JUDE'S &amp; THE ROOKERY</text>
 <text x="530" y="630" font-size="15" letter-spacing="3">THE SUNKEN SWITCHYARD</text>
 <text x="885" y="220" font-size="13">the Heights</text>
 <text x="70" y="374" font-size="12" opacity=".8">Kerr Street</text>
 <text x="447" y="300" font-size="12" opacity=".8" transform="rotate(-88 447 300)">Vine Street</text>
 <text x="600" y="330" font-size="12" opacity=".8" transform="rotate(-27 600 330)">Halloran Street</text>
 <text x="190" y="455" font-size="11" opacity=".7">the Flyover</text>
 <text x="250" y="645" font-size="11" opacity=".7">Dock Road</text>
 <text x="170" y="250" font-size="11" opacity=".7">Ferrier Lane</text>
</g>
<rect width="${W}" height="${H}" fill="url(#wmVig)" pointer-events="none"/>`;
  const boxes=[];const place=(x,y,w)=>{const opts=[[12,4,'start'],[-12,4,'end'],[12,-12,'start'],[12,20,'start'],[-12,-12,'end'],[-12,20,'end']];if(x>820)opts.unshift(opts.splice(1,1)[0]);
    for(const [dx,dy,an] of opts){const x0=an==='start'?x+dx:x+dx-w,b=[x0,y+dy-11,x0+w,y+dy+3];if(!boxes.some(q=>b[0]<q[2]&&b[2]>q[0]&&b[1]<q[3]&&b[3]>q[1])){boxes.push(b);return [dx,dy,an];}}
    return [12,4,'start'];};
  list.forEach((p,i)=>{const [x,y]=pos[i];const lk=p.locked&&p.locked(G.S),isHere=here&&here.id===p.id;
    const cls='wpin'+(isHere?' here':'')+(lk?' locked':'');
    const nm=p.name.replace(/^The /,'');const [lx,ly,anchor]=place(x,y,nm.length*7.2);
    s+=`<g class="${cls}" data-wpl="${esc(p.id)}" tabindex="${lk||isHere?-1:0}" role="button" aria-label="${esc(p.name)}"><circle cx="${x}" cy="${y}" r="16" fill="transparent"/>
      <circle class="wd" cx="${x}" cy="${y}" r="${isHere?7.5:5.5}"/>${isHere?`<circle cx="${x}" cy="${y}" r="13" fill="none" class="wring"/>`:''}
      <text x="${x+lx}" y="${y+ly}" text-anchor="${anchor}">${esc(nm)}</text></g>`;});
  s+='</svg><div class="wcap" id="wcap">Tap a place on the map, or pick from the list.</div>';
  return s;}
const orig=Camp.openMap;
Camp.openMap=function(){orig.apply(this,arguments);const ov=document.getElementById('map');if(!ov||ov.hidden)return;const mp=ov.querySelector('.mp');if(!mp||mp.querySelector('.wmap'))return;
  const S=G.S,here=Camp.here();const list=NL.PLACES.filter(p=>!p.hidden||p.hidden(S)===false).filter(p=>!p.open||p.open(S));
  const box=document.createElement('div');box.className='wmapbox';box.innerHTML=svgMap(list,here);
  const hd=mp.querySelector('header');hd.after(box);
  const cap=box.querySelector('#wcap');
  box.querySelectorAll('[data-wpl]').forEach(g=>{const p=NL.PLACES.find(x=>x.id===g.dataset.wpl);const lk=p.locked&&p.locked(S),isHere=here&&here.id===p.id;
    const info=()=>{cap.innerHTML=`<b>${esc(p.name)}</b> · ${isHere?'you are here':lk?esc(lk):Camp.cost(here,p)+' min'}<br><span>${esc(p.sub||'')}</span>`;};
    g.addEventListener('mouseenter',info);g.addEventListener('focus',info);
    g.addEventListener('click',()=>{if(isHere||lk){info();return;}if(g.classList.contains('armed')||matchMedia('(hover:hover)').matches){Camp.travel(p.id);}else{box.querySelectorAll('.armed').forEach(x=>x.classList.remove('armed'));g.classList.add('armed');info();cap.innerHTML+='<br><em>Tap again to go.</em>';}});
    g.addEventListener('keydown',e=>{if(e.key==='Enter'&&!isHere&&!lk)Camp.travel(p.id);});});
};
const css=document.createElement('style');css.textContent=`
.wmapbox{margin:10px 0 4px;border:1px solid var(--line);background:#1d1712;position:relative}
.wmap{display:block;width:100%;height:auto}
.wpin{cursor:pointer}.wpin .wd{fill:#e2c27e;stroke:#1d1712;stroke-width:2}.wpin text{font:600 13px Georgia,serif;fill:#efe2c4;paint-order:stroke;stroke:#1d1712;stroke-width:4px;stroke-linejoin:round}
.wpin:hover .wd,.wpin:focus .wd,.wpin.armed .wd{fill:#ff6a5a}.wpin:hover text,.wpin.armed text{fill:#fff}
.wpin.here .wd{fill:#b23a3a}.wpin.here text{fill:#ffb0a0}.wring{stroke:#b23a3a;stroke-width:2;stroke-dasharray:3 3}
.wpin.locked{opacity:.45;cursor:default}.wpin:focus{outline:none}
.wcap{padding:8px 12px;border-top:1px solid var(--line);font-size:14px;color:var(--paper-2);min-height:42px}.wcap span{color:var(--paper-dim);font-style:italic}.wcap em{color:var(--verdigris);font-style:normal;font:700 11px/1 var(--f-label);letter-spacing:.12em;text-transform:uppercase}
@media (max-width:600px){.wpin text{font-size:17px}}`;
document.head.appendChild(css);
// tidy a name
const lr=NL.PLACES.find(p=>p.id==='laundry');if(lr)lr.name='The Ever-Open Laundromat';
})();
