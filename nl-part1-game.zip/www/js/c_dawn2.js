'use strict';
/* THE NEW LORD — more last words on Platform 0, in the twenty minutes before the sun */
(function(){const O=NL.Script.opt;
O('dw.talk','* Leo, at the back of the platform, in his parka.  -> dw2.leo {once} {if alive:leo&flag:job_leo=platform|flag:leoEmbraced&alive:leo}','start');
O('dw.talk','* Tiny, at the foot of the stairs.  -> dw2.tiny {once} {if flag:job_tiny=platform&!flag:tinyGone}','start');
O('dw.talk','* Margo, front row, on her cushion.  -> dw2.margo {once} {if flag:job_margo=platform&!flag:margoDead}','start');
O('dw.talk','* Dr. Rostova, alone by the east tunnel.  -> dw2.ros {once} {if alive:rostova&flag:rostovaSpoke|alive:rostova&flag:pyotrDone}','start');
O('dw.talk','* The Magistrate, folding his handkerchief.  -> dw2.mag {once} {if flag:magHeardVane&!flag:massacre&!flag:purge}','start');
O('dw.talk','* Dutch and Local 0, packing up their thermos.  -> dw2.dutch {once} {if flag:side_union&!flag:purge}','start');
O('dw.talk','* Mateo, half-hidden behind a pillar, watching his sister.  -> dw2.teo {once} {if flag:millerTeoFriday&!flag:purge}','start');
})();
NL.Script.add(String.raw`
# dw2.leo
@focus leo
@gate flag:leoEmbraced ? dw2.leoK : dw2.leoM

# dw2.leoM
leo: Hey. Hey. So. That was the most insane thing I've ever seen and I once saw a man do a Robin Williams impression at a funeral.
leo: Are you okay? You're not okay. Nobody's okay. It's okay.
leo: It's nearly light. I can see it. I can see it and you can't, and that's the worst thing about you, I think. That you'll never see it again.
* "Watch it for me, Leo. Every morning. Tell me what color it was."  -> dw2.leoM1
* "Go home. Before the sun. Promise."  -> dw2.leoM2

# dw2.leoM1
leo: Every morning. What color. Okay. That's a job. I'm good at jobs. I'm bad at jobs. I'll be good at this one.
> He's crying. He's laughing. Both. He writes WHAT COLOUR on the back of his hand in biro.
{do rel:leo+1; flag:leoColour=1}
@next dw.talk

# dw2.leoM2
leo: I promise. I promise. I'll go home. I'll text you. Can you text? Do vampires text? I'll text anyway.
{do rel:leo+1}
@next dw.talk

# dw2.leoK
leo: It's coming. Isn't it. I can feel it. In my teeth. Like a dentist drill getting closer.
leo: I've never been scared of the morning before. I used to love it. I used to walk home from Kowalski's at six and buy a croissant and watch the light come up over the river.
leo: You'll show me what to do. Right? Where to go. You'll show me.
* "Stay close to me. When I go down, you go down. Don't look up."  -> dw2.leoK1
* "I'll show you everything, Leo. Every night. For as long as there are nights."  -> dw2.leoK2

# dw2.leoK1
leo: Don't look up. Okay. Okay. I won't look up.
> He holds onto the sleeve of your coat like a child in a crowd.
{do rel:leo+1}
@next dw.talk

# dw2.leoK2
leo: Forever's a long time.
leo: ...That's fine. I'll write some new material.
{do rel:leo+2; comp+1}
@next dw.talk

# dw2.tiny
@focus tiny
tiny: Nobody came down the stairs. Nobody went up. Just like I said.
tiny: Nine years at the top of those stairs and I never knew what it was like at the bottom. It's damp. It smells like old pennies. I don't know why you lot like it.
* "Thank you, Tiny."  -> dw2.tiny1
* "Go up first. Take Marcus. Go and see the morning."  -> dw2.tiny2 {if flag:marcusSafe|flag:marcusGhoul}

# dw2.tiny1
tiny: Don't. Don't, or I'll start. And I'm not starting in front of the Court.
> He holds out his hand. You shake it. His hand is enormous and warm and he doesn't flinch at how cold yours is.
{do rel:tiny+1}
@next dw.talk

# dw2.tiny2
tiny: The morning. Yeah. Marc's never seen a morning from the river. He's always in bed till two.
tiny: We'll get a coffee. Two coffees. We'll stand on the bridge like idiots.
{do rel:tiny+1; flag:tinyMorning=1}
@next dw.talk

# dw2.margo
@focus margo
margo: Well. Forty-one years, and that was the best one. I'll tell you that for nothing.
margo: You did it all wrong, you know. Said please to the Magistrate. Told the truth when you didn't have to. Nobody does it like that. It's not done.
margo: It worked, though. Funny old world.
* "Margo. What'll you do now?"  -> dw2.margo1

# dw2.margo1
margo: Me? Go home. Put the kettle on. Take my shoes off. Ring my sister in Duluth and tell her I've had a very interesting evening.
margo: She'll say, "Margo, you always have an interesting evening." And I'll say, "Yes, but this one I'll tell you about."
{do rel:margo+1; comp+1}
@next dw.talk

# dw2.ros
@focus rostova
rostova: I said it. In the chalk. In front of all of them. And nobody killed me. Isn't that strange.
@gate flag:pyotrDone ? dw2.ros2 : dw2.ros3

# dw2.ros2
rostova: The man who killed Papa is... wherever he is. And I'm here. Breathing. Eating yoghurt with a plastic spoon at five in the morning.
rostova: I keep waiting to feel finished. I don't think I will. I think I'll just feel like a doctor who has to go to work on Monday.
* "Go to work on Monday, Elena."  -> dw2.ros4

# dw2.ros3
rostova: Now what? I'm a scientist who confessed to murder in a court that doesn't officially exist. I can't put that on a CV.
* "Go to work on Monday, Elena."  -> dw2.ros4

# dw2.ros4
rostova: Monday. Yes. Bed nine has a new patient. A child. Leukaemia. Like Pasha.
rostova: I'll go to work on Monday. I'll sit with her. I'll learn to sit with her. You taught me that, I think. The sitting.
{do rel:rostova+2; comp+1}
@next dw.talk

# dw2.mag
@focus magistrate
> He's folding the white linen handkerchief into a perfect square, then unfolding it, then folding it again.
magistrate: I have presided over three hundred and twelve Tribunals. I have never once been spoken to by the victim.
magistrate: Tell him... no. Let me tell him.
> He leans close. Not to you. To what's in you.
magistrate: Absalom. You owe me forty francs. I'm not letting it go. Christmas Eve. The car. Bring the money.
tenant: (through your mouth, before you can stop it) I'll bring a goat.
> The Magistrate of the Marrow Ward makes the cupboard noise again. Three hundred Kindred turn to see what it is. None of them have ever heard him laugh.
{do sync+2; rel:magistrate+1; flag:magChristmas=1}
@next dw.talk

# dw2.dutch
@focus dutch
dutch: Local 0, brother, sister, whatever. Vote was unanimous. We're going home. Some of us have got actual homes now. Mostly vans.
dutch: Thing is. The Court looked at us tonight. First time in forty years. Looked at us like we were there. That's on you.
* "Local 0 gets a seat at Elysium. From tonight."  -> dw2.dutch1 {do lean:pride-1}
* "You did that yourselves. I just stood near you."  -> dw2.dutch2

# dw2.dutch1
> Dutch looks at you. Then at the Union behind him, thirty Kindred in ripped jeans with screwdrivers in their belts. Somebody at the back starts clapping, very slowly, and then everyone is.
dutch: A seat. At the table. With the napkins.
dutch: ...I'm going to need a napkin.
{do flag:unionSeat=1; rel:dutch+2}
@next dw.talk

# dw2.dutch2
dutch: Ha. Spoken like a shop steward. Solidarity.
{do rel:dutch+1}
@next dw.talk

# dw2.teo
@focus teo
> Mateo Miller, nineteen forever, behind a cast-iron pillar, watching his sister on the stairs. She hasn't seen him. Or she has and she's pretending, which is something they both learned from the same mother.
teo: Thirteen years. And she came. She came down into the sewer for me.
* "Go and stand next to her. That's all. Just stand there."  -> dw2.teo1
* "She knows you're here, Teo. She's waiting for you to come to her."  -> dw2.teo1

# dw2.teo1
> He walks across the platform. It takes him a long time. Thirty yards. Thirteen years.
> He stops beside her on the stairs. Neither of them says anything. After a while, Ines Miller reaches out without looking and takes her little brother's cold hand, the way she used to on the walk to school.
{do flag:millerMetMateo=1; rel:miller+2; comp+2:Ines and Teo}
@next dw.talk
`,'c_dawn2');
