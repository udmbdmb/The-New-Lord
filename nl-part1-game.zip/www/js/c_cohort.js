'use strict';
/* THE NEW LORD — "Cohort B": twelve cots on the fourth floor. Dani was number three. You were number eight. Where are the other ten? */
(function(){const X=NL.EXTRAS,S_=NL.Script;
const P=(n,role,skin,hair,shirt,coat,o)=>Object.assign({n,role,color:'#c8c0b8',spec:Object.assign({skin,hair:{style:hair[0],color:hair[1]},shirt,coat:coat?{color:coat,length:.55,collar:true}:null},o||{})});
Object.assign(X,{
  marisol:P('Marisol Vega','Cohort B, #5',[.7,.52,.42],['long',[.1,.07,.05]],[.5,.3,.35],[.3,.25,.3]),
  jerome:P('Jerome Akers','Cohort B, #11',[.36,.26,.2],['crop',[.1,.08,.06]],[.6,.55,.4],[.3,.3,.25],{height:1.04}),
  shelterman:P('Brother Tom','Kerr Street Shelter',[.84,.74,.68],['short',[.6,.6,.6]],[.4,.5,.4],null)
});
NL.TASKS.s_cohort={n:'Cohort B',xp:90,cat:'side'};
NL.ITEMS.cohortlist={n:'A List: Cohort B',type:'read',d:'Twelve names in Dr. Rostova\'s handwriting, a photocopy of a photocopy. #3: D. Okafor (deceased, sunlight, 22 min). #8: C. Morrow (subject transferred to secondary protocol). Others: discharged. Two marked "follow-up: Kerr St."'};
S_.place({id:'shelter',name:'The Kerr Street Shelter',block:'A',sub:'A church hall with forty camp beds and a tea urn. Two names on Rostova\'s list say "Kerr St."',if:'night>=3&night<=5&flag:mapOK&has:cohortlist&!flag:cohortDone',node:'co2.0',min:10});
})();
NL.Script.add(String.raw`
# coh.0 arc=rostova night=3,4,5 label="\"Doctor. Cohort B. There were twelve of us. Where are the others?\"" if=alive:rostova&has:payslip|alive:rostova&flag:pcCots|alive:rostova&flag:dcSeven prio=4
@focus rostova
> She doesn't pretend not to understand. She closes the door of her office and locks it.
rostova: Twelve. Yes. Cohort B. Paid five hundred, because Cohort A had... Cohort A had complications. B was meant to be safer. Lower dose. Shorter exposure.
rostova: Number three was Danielle Okafor. Number eight was you.
* "Subject Eight."  -> coh.8
* "What happened to the other ten?"  -> coh.ten

# coh.8
rostova: Subject Eight. Harrow's favorite phrase. You were the best responder. Lowest rejection. Highest tolerance. When he needed a living control for the Sheriff, you were the obvious choice.
rostova: I'm sorry. I've said that to you before. It doesn't get less true.
@next coh.ten

# coh.ten
rostova: Discharged. After Dani. After the sun. Harrow shut Cohort B down in the morning. Paid them off, five hundred more each, a non-disclosure, a taxi home.
rostova: Most of them were fine. Or I told myself they were fine. A headache. Light sensitivity. A taste for rare steak.
rostova: Two of them didn't go home. They had no home to go to. I wrote "Kerr St." next to their names because it's where the shelter is. I never followed up. I meant to.
* "Give me the list."  -> coh.list
* "Why didn't you follow up?"  -> coh.why

# coh.why
rostova: Because I was afraid of what I'd find. Because it was easier to write "follow-up" than to go. Because I'm a coward with a medical degree.
@next coh.list

# coh.list
> She takes a photocopy from a drawer, folded in four, worn soft at the creases. Twelve names. Her handwriting.
rostova: Marisol Vega. Number five. Jerome Akers. Number eleven. Kerr Street. If they're still... if they're still there.
{do give:cohortlist; task:s_cohort; note:s_cohort|Rostova's list of Cohort B. Two of the twelve, Marisol Vega and Jerome Akers, never went home. She wrote "Kerr St." beside their names: the shelter.}
@end

# co2.0
> The Kerr Street Shelter is a church hall with a tea urn, a noticeboard of lost cats and job ads, and forty camp beds in rows. It smells of soup and wet coats. A man in a cardigan is mopping the floor at two in the morning.
shelterman: We're full. Sorry. There's floor space by the radiator if you're desperate. Are you desperate? You look a bit desperate.
* "I'm looking for Marisol Vega and Jerome Akers."  -> co2.ask
* Show him the list.  -> co2.ask

# co2.ask
shelterman: Marisol and Jerome. Yeah. The night owls. They don't sleep. They sit in the back by the fire door with the lights off. They've been like that since October.
shelterman: They're... I don't know. There's something wrong with them. The doctor from the cooler van used to take extra from them. He said they had "interesting blood". I stopped him coming in. Was that right?
* "That was right."  -> co2.right
* "What cooler van?"  -> co2.van

# co2.van
shelterman: A man with a cooler box. Said he was a phlebotomist. Took blood on Tuesdays for a "health survey". Paid them twenty dollars. Someone stopped him last week. Left the cooler on our step with a note that said "Yours." Was that you? {if flag:coolerStopped}
@next co2.right

# co2.right
shelterman: Back by the fire door. Go gently. They frighten easy.
@next co2.meet

# co2.meet
> At the back of the hall, by the fire door, in the dark: two people on camp beds facing each other, talking in low voices. A woman of about thirty with long black hair, wrapped in a blanket though the radiator is on. A big man in his fifties with grey at his temples, very still.
> They look up when you come. And their eyes, in the dark, catch the light from the hall behind you, the way an animal's do. Not red. Not yet. Amber.
marisol: ...You. Number eight. Casey. Oh my God. You were in the bed by the window. You lent everyone books.
jerome: They said you died. They said you went with the doctor and the tall man to the... they said you died.
* "I did. Sort of."  -> co2.died
* "How are you? Both of you? Really?"  -> co2.how

# co2.died
jerome: Sort of. Right. Yeah. Sort of. That's about where we are.
@next co2.how

# co2.how
marisol: Cold. All the time. I can't go out in the day; my skin blisters. I can't eat. Soup comes back up. And I'm hungry, and not for soup, and I don't want to say what for.
jerome: Since October. Since the sun. Since Dani. They gave us five hundred dollars and a taxi. I didn't have anywhere to take the taxi.
autopsy(6): They're not Kindred. They're not mortal. They're what Luis is: half-made, stuck, a mortal body full of a Sovereign's borrowed blood, slowly not coping. Months, maybe. Not years.
{do flag:metCohort=1}
* "Do you know what's happening to you?"  -> co2.know
* "I can help. I don't know how yet. But I can."  -> co2.help

# co2.know
marisol: No. Do you? You look like you know.
* Tell them everything.  -> co2.truth {do lean:candour+1}
* "Something in the trial. Something in the blood. I'm finding out."  -> co2.help

# co2.truth
> You tell them. LANTERN. The Sheriff's blood. The lamps. What you are now. What they're halfway to being.
> Jerome listens with his hands on his knees. Marisol listens with her eyes shut.
jerome: Vampires. Real vampires. And the government. And we're... we're what, then? Science experiments that didn't take?
marisol: We're leftovers. That's what we are. They made something and we're what was left in the bowl.
@next co2.help

# co2.help
> Two people on camp beds in the dark, looking at you. Waiting to find out what you'll do. Like everyone has been waiting all week.
* "There's an old man with boxes on Reliquary Row. Somewhere dark, and safe."  -> co2.gideon {if alive:gideon}
* "Dr. Rostova. She made this. She can try to unmake it."  -> co2.ros {if alive:rostova}
* "I can stop it. My blood. You'd live. You'd need me, every week, forever."  -> co2.blood
* "What do YOU want?"  -> co2.want

# co2.want
marisol: What I want. Nobody's asked me that since I was nineteen.
marisol: I want to see the sun again. Once. Without blistering. That's all. I used to sit on the steps of the library at lunchtime and read in the sun. I want that, once.
jerome: I want to go home. I haven't got a home. I want to have one.
@next co2.help2

# co2.help2
* "There's an old man with boxes on Reliquary Row. Somewhere dark, and safe."  -> co2.gideon {if alive:gideon}
* "Dr. Rostova. She made this. She can try to unmake it."  -> co2.ros {if alive:rostova}
* "I can stop it. My blood. You'd live. You'd need me, every week, forever."  -> co2.blood
* "Marisol. If you want the sun, I'll take you to see it. I'll stand with you."  -> co2.sun

# co2.gideon
> You take them to the Pawn & Coffin at four in the morning. Gideon looks at them over his half-moon glasses: a woman in a blanket and a big man who won't stop apologizing.
gideon: Two more. Box twelve and box fourteen. Fourteen's a bit narrow, I'm sorry, Mr. Akers. Rule three: you come and see me every night so I know you're alive.
jerome: ...Thank you. Thank you, sir.
gideon: Don't call me sir. Nobody's called me sir since 1974. It makes me feel like a bank manager.
{do flag:cohortGideon=1; flag:cohortDone=1; task:s_cohort=done; xp:70:Cohort B; rel:gideon+1; lean:mercy+1}
@end

# co2.ros
> You take them up to the fourth floor of St. Jude's. Rostova opens her door. She sees who's with you. She sits down very suddenly on her desk.
rostova: Five. Eleven. Oh God. Oh, God.
marisol: Hello, Doctor. You look tired.
rostova: I... yes. I am. I'm so sorry. I'm so... I don't know if I can fix it. I don't know if it can be fixed. I can try. I can try every day. I won't stop.
jerome: That's more than you did in October.
rostova: Yes. It is.
{do flag:cohortRos=1; flag:cohortDone=1; task:s_cohort=done; xp:80:Cohort B; rel:rostova+2; lean:mercy+1}
@end

# co2.blood
marisol: Need you. Every week. Like... like a drug.
jerome: Like the man with the cooler wanted. Except it's the other way round.
tenant: Two ghouls. Two mortals bound to you, Sheriff's child, by your blood, for the rest of their lives. That's a household. That's how it starts. That's how Pemberton started.
* Open your wrist. For both of them.  -> co2.bloodyes {blood}
* "No. Not that. There has to be another way."  -> co2.help2

# co2.bloodyes
> They drink. Marisol first, then Jerome. Marisol cries. Jerome laughs, a huge laugh, the first one in a month.
> The amber goes out of their eyes. The cold goes out of their hands. They'll live. They'll live a long time. They'll need you every Sunday, forever.
jerome: Oh. Oh, I'm warm. I'm warm. Mari, I'm warm.
{do vitae-3; flag:cohortGhouls=1; flag:cohortDone=1; task:s_cohort=done; xp:70:Cohort B; lean:restraint-1}
@end

# co2.sun
marisol: You'd stand with me. In the sun. You'd burn.
* "I'd stand until you'd seen it. Then I'd go in."  -> co2.sun2

# co2.sun2
marisol: ...You would, wouldn't you. You'd actually do it.
marisol: No. No, I don't want anyone to burn for me. I just wanted someone to say they would.
> She takes your cold hand in her cold hand.
marisol: Someone said it. That's enough. That's enough for now. Take me to the old man with the boxes. I'll think about the sun another day.
{do flag:cohortGideon=1; flag:cohortDone=1; task:s_cohort=done; xp:80:Cohort B; comp+2; lean:mercy+1}
@end
`,'c_cohort');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.cohortRos)o.push(['Cohort B, #5 and #11','Marisol Vega and Jerome Akers go to the fourth floor of St. Jude\'s every night at eight. Dr. Rostova has been trying for four months. In February, Marisol sat on the library steps for six minutes at noon, in a hat, and didn\'t blister. She cried the whole time.']);
  else if(f.cohortGhouls)o.push(['Cohort B, #5 and #11','Marisol and Jerome. Sunday nights, at yours, for your blood. Jerome cooks for everyone else in the building. Marisol reads. They call themselves the leftovers, and they laugh when they say it.']);
  else if(f.cohortGideon)o.push(['Boxes twelve and fourteen','Taken, at the Pawn & Coffin, by two people who aren\'t Kindred and aren\'t mortal. Gideon has started a new page in the ledger for them. It has no heading. He\'s still thinking about what to call it.']);
  return o;});
