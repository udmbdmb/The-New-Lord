'use strict';
/* THE NEW LORD — Act V · Night Five (Friday): "The Tribunal" — the perimeter, the debate, the lamps, the sunrise, six endings and the secrets */
(function(){
const NL=window.NL,G=NL.G,A=NL.Audio;const {N,ENC,L,T,O,C,H,STORY}=NL.DSL;const {pushPop,pushNpc,pushEnter}=NL.Act;
const X=NL.EXTRAS;const allies=NL.Act.allies;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
X.magistrate={n:'The Magistrate',color:'#e8d8b0',role:'Voice of the Prince',spec:{face:{long:1.12,cheek:1.5,jaw:1.2,nose:1.3,brow:1.3},skin:[.8,.76,.74],hair:{style:'long',color:[.85,.85,.82]},shirt:[.9,.88,.84],coat:{color:[.32,.04,.06],length:1,collar:true},eyes:[.8,.7,.4],eyeGlow:[.5,.4,.15],height:1.04}};
X.judge={n:'Judge Abernathy',color:'#d0d0e0',role:'Superior Court, retired',spec:{face:{long:1.02,jaw:0.7,cheek:0.9},skin:[.86,.76,.7],hair:{style:'bun',color:[.92,.92,.92]},glasses:{type:'reading'},shirt:[.15,.12,.2],coat:{color:[.2,.18,.28],length:.6,collar:true},height:.92}};
const ghostGlass=S=>S.clan==='glass'&&['mart','reliq','vip','jude','cistern'].filter(k=>S.flags['mirror_'+k]).length>=4;
const lampsLive=S=>!S.flags.mastDead&&!S.flags.ratsGrates&&!S.flags.mastTuned;
const vesselAt=S=>{if(NL.G.has('vessel'))return 'you';if(S.flags.vesselGiven)return S.flags.vesselGiven;if(S.flags.vesselLost&&!S.flags.vesselRegained)return S.flags.vesselLost;if(S.flags.vesselHidden==='miller')return S.flags.side_miller?'miller':null;if(S.flags.vesselHidden==='morgue')return 'morgue';if(!S.flags.vesselTaken)return 'drawer';return null;};
NL.Act.vesselAt=vesselAt;

/* ---------- the night ---------- */
NL.NIGHTS[5]={title:'Act V · The Tribunal',sub:'Friday',
  heatAdd:S=>0,
  canSleep:S=>false,
  async start(G,S,hav){hav=S.hav||hav;const h=NL.Camp.havenRoom(hav);
    await G.enterRoom(h.room,h.spawn,{instant:true,noEnter:true});
    G.cine(true);A.music('dread');await G.wait(.5);
    await G.say([T('Friday. The last sunset you\'ll see one way or another goes down behind the gasometers at 7:52, and you wake at 9:00 with the taste of it, like a coin, in your mouth.'),
      L('tenant','The Magistrate sits at one. Before that, the whole Ward will be on the move. Everyone you\'ve ever lied to will be standing in one room.'),
      L('sundial','Four hours to the Tribunal. Then, one way or another, sunrise.'),
      L('web',S=>{const v=vesselAt(S);return v==='you'?'The Vessel is in your coat. Everyone knows it.':v==='court'?'Séverine has the Vessel.':v==='syndicate'?'Malakor has the Vessel.':v==='lantern'?'Harrow has the Vessel.':v==='morgue'?'The Vessel is sewn up in a dead man in drawer B-14.':v==='miller'?'Miller has the Vessel, at her sister\'s, with a dog.':v==='drawer'?'The Vessel is still in drawer B-14. You never opened it.':'You don\'t know where the Vessel is.';})]);
    G.cine(false);
    G.task('tribunal');S.quests.note_tribunal='1 AM, Platform 0. The Magistrate of the Prince sits in judgment on the death of Sheriff Vane. Go when you\'re ready. Everything you\'ve done this week comes with you.';
    G.task('friday','done');
    if(S.flags.knowName)setTimeout(()=>G.text('Unknown','Casey? It\'s your sister. Somebody called the house from a payphone on Monday and didn\'t say anything. Was that you? Call Mom. Please.'),12000);
    G.autosave();}
};

/* ---------- the perimeter ---------- */
pushEnter('switchyard',async(S,G)=>{if(S.night!==5||S.flags.tribunalDone)return;if(G.once('perimeter'))await G.talk('pm.0');});
N['pm.0']={lines:[T('Platform 0 has been transformed. The fire barrels are gone. Black velvet hangs from the girders. Kindred you\'ve never seen stand in clusters along the tracks: the Gilded Court in evening dress, Syndicate men in leather, a few grey shapes that are Wraiths, the clanless at the edges.'),
  T('Up on the street, three grey vans with federal plates have parked across the Switchyard entrances. Men in grey stand at each one, very politely not letting anyone *out*.'),
  L('web','Harrow\'s sealed the perimeter. Whatever happens down here, nobody leaves before dawn unless he lets them.',{pass:4}),
  L('sundial',S=>S.time<240?'The Magistrate sits at one. You can wait here, or go and do one last thing.':'The Magistrate is already seated.'),
  L('tenant','Every grate on this platform has a lamp in it. I can feel them. Like teeth.',{if:S=>lampsLive(S)&&S.flags.knowCode})]};
NL.ROOMS.switchyard.inter.push({id:'dock',label:'The Tribunal',at:[6,1.6,3],box:[5,0,2.4,7,1.6,3.6],stand:[6,4.2],face:[6,3],if:S=>S.night===5&&!S.flags.tribunalDone});
H.use.dock=async(S,G)=>G.talk('tb.ready');
N['tb.ready']={lines:[T('A circle of chalk on the platform under the skylight grate. A high-backed chair from the Reliquary for the Magistrate. A wooden box for the accused to stand in.'),L('sundial',S=>S.time<240?'Not yet one. You could go and finish something.':'It\'s time.')],
  opts:[O('Step into the dock.','tb.0'),O('Not yet.',null,{end:true,leave:true})]};

/* =====================================================================
   THE TRIBUNAL
   ===================================================================== */
const seat=(id,spec,x,z,ry,pose)=>G.addActor(id,spec,{x,z,ry,breathes:pose!=='sit'||true,pose:pose||'arms'});
N['tb.0']={cs:async(G,S)=>{if(S.time<240)G.tick(240-S.time);G.cine(true);A.music('dread');
    seat('magistrate',X.magistrate.spec,6.0,1.4,0,'sit');
    if(!S.flags.sevDead)seat('severine',NL.CHARS.severine.spec,3.8,2.2,0.8,'arms');
    if(!S.flags.malakorDead)seat('malakor',NL.CHARS.malakor.spec,8.2,2.2,-0.8,'arms');
    seat('soot',NL.CHARS.soot.spec,2.6,3.6,1.2,'sit');
    if(S.flags.valkoAlly||S.flags.valkoHunt)seat('valko',NL.CHARS.valko.spec,S.flags.valkoAlly?5.0:7.2,4.6,S.flags.valkoAlly?0.4:-0.6,'crouch');
    if(S.flags.rostovaTestify)seat('rostova',NL.CHARS.rostova.spec,9.4,3.6,-1.4,'arms');
    G.focus(['you','magistrate'],.9);G.look('magistrate','you');},
  lines:[T('The Magistrate is older than anything you have ever seen: a long white face, a red robe, eyes like old brass. When he sits, every Kindred on Platform 0 kneels without deciding to. You kneel too.'),
  L('magistrate','In the name of the Prince of Port Vellum. Absalom Vane, Sheriff of the Marrow Ward, was destroyed on Monday morning at 4:14 in the cold room of a butcher\'s shop. His blood is in that one. Diablerie is the oldest crime we have. Who accuses?'),
  L('severine','I do. The Keeper of Elysium accuses the neonate who wears him.',{if:S=>!S.flags.side_court}),
  L('severine','...The Keeper of Elysium is obliged to accuse. The Keeper of Elysium does so without enthusiasm.',{if:S=>S.flags.side_court}),
  L('magistrate','Speak, then, thief. You have until I am bored.')],next:'tb.enc'};
N['tb.enc']={enc:'tribunal',win:'tb.win',lose:'tb.lose'};
ENC.tribunal={title:'THE TRIBUNAL',sub:'Platform 0 · the Prince\'s Magistrate presiding',music:'dread',after:'dread',
  prog:{name:'The verdict',max:10,color:'#e2c27e'},threat:{name:'The pyre',max:8,color:'#e06050'},
  focus:G=>G.focus(['you','magistrate'],.8),
  start(S,G){const a=allies(S).length;let t=2;if(S.flags.bloodHunt)t+=1;if(S.flags.sevEnemy)t+=1;if(S.kills>=3)t+=1;if(S.flags.breaches)t+=1;return {prog:Math.min(4,a),threat:Math.min(6,t)};},
  intro:[L('magistrate','Begin.')],
  round(st,S,G){const Q=[
    ()=>({lines:[L('severine','The facts are plain. The Sheriff is ash. The thief is fat with him. The thief was seen fleeing the scene in his coat.',{if:S=>!S.flags.side_court})],threat:S.flags.side_court?0:1}),
    ()=>({lines:[L('malakor','If I may. The Syndicate notes that the thief has been *remarkably* busy this week for a common murderer.',{if:S=>S.flags.side_syndicate}),L('malakor','The Syndicate has no opinion. The Syndicate would like this to be over before the lamps come on.',{if:S=>!S.flags.side_syndicate})],prog:S.flags.side_syndicate?1:0}),
    ()=>({lines:[T('Above the skylight grate, very faintly, a sound like a generator spinning up.'),L('sundial','Something on the street just switched on.',{if:S=>S.flags.knowCode})]}),
    ()=>({lines:[L('magistrate','I am beginning to be bored.')],threat:1}),
    ()=>({lines:[L('magistrate','Last words, thief.')]})];return st.round<Q.length?Q[st.round]():null;},
  moves(st,S,G){const M=[];
    M.push(C('web',10,'"Look at the ash. He died kneeling, facing the door, burned from the front in a line. That\'s a lance. Malakor built it."',null,null,{id:'tb_lance',once:'tb_lance',mod:(S,G)=>(G.has('invoice')?3:0)+(S.flags.maskedBuyer?1:0),ok:st=>{st.prog+=2;return [T('A murmur along the tracks.'),L('malakor','...I did build it. I am a craftsman. I am not responsible for what customers *point* it at.')];},no:st=>{st.threat+=1;return [L('magistrate','Supposition.')];}}));
    if(G.has('invoice'))M.push({t:'Hand up the Red Syndicate invoice. "Buyer: R."',once:'tb_inv',ok:st=>{st.prog+=1;return [L('magistrate','R.')];}});
    if(S.flags.rostovaTestify&&!S.flags.rostovaDead)M.push({t:'"Dr. Rostova. Tell them."',once:'tb_ros',ok:(st,S)=>{st.prog+=4;S.flags.rostovaSpoke=1;return [T('She steps into the chalk circle in her white coat. Three hundred Kindred look at her like a buffet.'),L('rostova','I fired the lance. At 4:14 on Monday morning. On the orders of Special Agent Thomas Harrow, of Project LANTERN. The neonate drank him to keep him from burning. Everything else, I did.'),T('Silence. Then a sound from the Court Kindred like wind through a field.')];}});
    if(G.has('lanternfile'))M.push({t:'Throw the Tuesday files down in the chalk. "LANTERN. Seven mortals. Vane\'s blood. Counter-signed T.H."',once:'tb_files',ok:st=>{st.prog+=3;return [L('magistrate','...A federal program. Making *daywalkers*. Out of mortals. With a Sheriff\'s blood. In my Prince\'s city.'),T('The Magistrate\'s face does not move. Somewhere behind it, something very old wakes up angry.')];}});
    if(S.flags.sawAmbush)M.push(C('nostalgia',9,'Tell them what you saw in the Seizure. 4:14. The light. Harrow in the door. Why you drank.',null,null,{id:'tb_mem',once:'tb_mem',mod:S=>S.flags.chord?3:0,ok:st=>{st.prog+=2;return [L('magistrate','Blood memory. Admissible, in the old law. Barely.')];},no:st=>{st.threat+=1;return [L('severine','A neonate\'s *dream*.')];}}));
    if(S.flags.chord||S.flags.seizure==='surrender')M.push({t:'Let Absalom testify. Two voices. One throat.',once:'tb_vane',ok:st=>{st.prog+=3;return [T('The voice that comes out of you is his. Every Elder on the platform knows it.'),L('tenant','I went to Elena Rostova for a cure. I was a fool and a coward. The child drank me to save me from the light. I *consented*, Magistrate. I consent now. Diablerie requires a victim. There is none here.'),L('magistrate','...Absalom. You always were a lawyer.')];}});
    if(ghostGlass(S))M.push({t:'Turn to the black water through the grate. Let your reflection speak.',once:'tb_glass',ok:(st,S,G)=>{st.prog+=3;G.task('x_glass');G.task('x_glass','done');G.xp(60,'The Ghost in the Glass');return [T('Your reflection steps out of the water and stands beside you, and it is Monday morning in it: the freezer, the lance, the light. Every Kindred on the platform watches it happen.'),L('magistrate','...Glass. How rare. How very rare.')];}});
    if(G.has('manifest'))M.push({t:'"And while we\'re here: forty years of rendering manifests. The Court\'s dead, out of Kowalski\'s back door."',once:'tb_man',ok:(st,S)=>{st.prog+=1;st.threat+=S.flags.side_court?2:0;return [L('severine','You *viper*.'),L('magistrate','Later. I will read those later.')];}});
    if(S.flags.side_soot)M.push({t:'"Mother. What did the pipes hear?"',once:'tb_soot',ok:(st,S)=>{st.prog+=2;return [L('soot','The Lady and the federal man, talking in her booth. "The doctor did her part. Let Valko do his." Mm. Mm.',{if:S=>S.flags.knowSevHarrow}),L('soot','Many things. All of them true. The child did not kill Absalom. The child is merely *greedy*.')];}});
    if(S.flags.side_valko)M.push({t:'"Valko. You smelled her car."',once:'tb_valko',ok:st=>{st.prog+=2;return [L('valko','Half four, Monday. The doctor in her Volvo, shaking, smelling of him and of ozone. I\'ll swear it on his ash.')];}});
    M.push(C('velvet',11,'Speak to the room, not the Magistrate. "Who here wants a Sheriff who answers to LANTERN?"',null,null,{id:'tb_vel'+st.round,mod:(S,G)=>allies(S).length,ok:st=>{st.prog+=1;return [T('Heads turn toward the street, where the vans are.')];},no:st=>{st.threat+=1;return [L('magistrate','Do not campaign in my court.')];}}));
    M.push(C('apex',12,'"I drank a Sheriff. Judge me if you dare."',null,null,{id:'tb_apex'+st.round,red:true,mod:(S,G)=>(G.equipped('signet')?2:0)+(S.sync>=50?2:0),ok:st=>{st.prog+=2;st.threat+=1;return [T('Somebody in the Court laughs nervously. The Magistrate does not.')];},no:st=>{st.threat+=2;return [L('magistrate','I have judged older than you. I have *eaten* older than you.')];}}));
    if(S.flags.knowCode)M.push({t:'"Magistrate. Look at the grates. Every one has a federal lamp in it. Harrow means to burn this whole court."',once:'tb_lamps',ok:(st,S)=>{st.prog+=3;S.flags.lampsExposed=1;return [T('Three hundred faces look down at once. Somebody kicks a grate. Under it, a quartz lamp the size of a dinner plate, wired, blinking.'),L('magistrate','...Ah.')];}});
    return M;},
  decide(st){return st.prog>=7?'win':'lose';},
  outro(r,st,S,G){S.flags.verdict=r;return [];}
};
N['tb.win']={lines:[L('magistrate','The Prince finds that Absalom Vane was destroyed by a mortal weapon, in a mortal hand, at the order of a mortal agency. The neonate drank him to keep him from the light. That is not diablerie. That is *salvage*.'),
  L('magistrate','The accused is acquitted.',{do:(S,G)=>{G.task('tribunal','done');G.xp(100,'Acquitted');}}),
  T('A breath let out by three hundred dead lungs at once.')],next:'lamps.0'};
N['tb.lose']={lines:[L('magistrate','The Prince finds the neonate guilty of the diablerie of Absalom Vane. Sentence: the sun. At dawn. Through the grate.',{do:(S,G)=>{S.flags.condemned=1;G.task('tribunal','done');}}),
  T('Hands on your arms. Court ghouls. Strong ones.')],next:'lamps.0'};

/* ---------- the lamps ---------- */
N['lamps.0']={lines:[T('And then, from the street above, a voice through a megaphone, pleasant, reasonable, faintly apologetic.'),
  L('harrow','Good evening. This is Special Agent Harrow. On behalf of the United States government, I\'d like to thank you all for gathering in one place.'),
  T(S=>lampsLive(S)?'Under every grate on Platform 0, a quartz lamp begins to whine.':S.flags.mastTuned?'Under every grate, nothing happens. Because the mast doesn\'t answer to him any more. It answers to the phone in your pocket.':'Under every grate, nothing happens. A click. Another click. A long silence, and then a federal agent swearing into a live megaphone.')],
  next:S=>lampsLive(S)?'lamps.fire':S.flags.mastTuned?'lamps.yours':'lamps.dead'};
N['lamps.dead']={lines:[T('Somebody laughs. Then everybody does. Then three hundred Kindred turn, as one, toward the stairs and the vans and the men in grey.',{do:S=>{S.flags.lampsFailed=1;}}),
  L('pedigree','They\'re going to go up there and eat LANTERN alive. All of it. Unless someone stops them.')],
  opts:[O('Let them.','lamps.let'),O('"No. Nobody touches the mortals. Miller takes Harrow."','lamps.miller',{if:S=>S.flags.side_miller}),O('"STOP." Hold the room.','lamps.hold')]};
N['lamps.let']={lines:[T('It doesn\'t take long. There\'s a lot of noise from the street, and then not very much. In the morning the papers will say a gas main.',{do:(S,G)=>{S.flags.lanternEaten=1;S.flags.harrowDead=1;G.heat(2);G.comp(-2,'You let them');}})],next:'dawn.0'};
N['lamps.miller']={lines:[T('From the street: sirens. Real ones. Miller, in a parka, with a judge in a wheelchair and two squad cars from a precinct that isn\'t 9, and a warrant with a real signature on it.'),
  L('miller','Thomas Harrow, you\'re under arrest for seven counts of murder, conspiracy, and being an absolute weasel. — Judge, is "weasel" a charge? — It is now.',{do:(S,G)=>{S.flags.harrowArrested=1;G.rel('miller',2);}}),
  L('magistrate','...The mortals can keep that one. I find I have lost my appetite.')],next:'dawn.0'};
N['lamps.hold']={lines:[T('They\'re already on the stairs.')],opts:[C('apex',11,'"STOP." Every voice you have.','lamps.held','lamps.let',{id:'lh_ap',mod:S=>(S.flags.verdict==='win'?2:0)+allies(S).length})]};
N['lamps.held']={lines:[T('They stop. Three hundred Kindred, on the stairs, looking back at you.'),L('magistrate','...Hm. A Sheriff\'s voice.',{do:(S,G)=>{S.flags.heldRoom=1;S.flags.harrowFled=1;G.xp(40,'You held the room');}}),T('Up on the street, three grey vans leave very fast.')],next:'dawn.0'};
N['lamps.yours']={lines:[L('frenzy','Press it. PRESS IT. Every Elder in the Ward, gone in a breath. Nobody left to tell you no.'),L('pulse','Harrow\'s on the street. His men are on the street. The lamps are down here.'),L('tenant','Do it and you are the oldest thing left in the Marrow Ward. Do it and you are Prince of a graveyard.')],
  opts:[O('Press it. Burn the Court.','lamps.burn'),O('Put the phone away.','lamps.dead'),O('Hand the phone to the Magistrate.','lamps.give')]};
N['lamps.give']={lines:[L('magistrate','...You give me the means to burn this whole platform. Including you. Unasked.'),T('He holds the phone for a long time and then puts it, very carefully, in his robe.',{do:(S,G)=>{S.flags.gavePhone=1;G.comp(2,'You gave it up');G.xp(40,'Restraint');}}),L('magistrate','The Prince will hear of this.')],next:'lamps.dead'};
N['lamps.burn']={lines:[T('You press it.'),T('Noon comes up through every grate on Platform 0 at once. It isn\'t loud. It\'s *bright*. Three hundred Kindred, the Gilded Court, the Syndicate, the Wraiths, the Magistrate in his red robe, go up like paper.'),
  T('You\'re standing on the one dark square of tile in the middle of the chalk circle. You checked. You were always going to check.',{fx:['flash','shake:2'],do:(S,G)=>{S.flags.purge=1;S.flags.sevDead=1;S.flags.malakorDead=1;S.flags.sootDead=1;S.kills+=300;S.flags.valkoDead=S.flags.valkoDead||(S.flags.valkoAlly||S.flags.valkoHunt?1:0);G.comp(-6,'You burned them all');}}),
  L('tenant','...My God. My God, child.')],next:'end.purge'};
N['lamps.fire']={lines:[T('The lamps come on.'),T('It\'s not noon. Not quite. It\'s *November*: thin, white, cold. But it\'s enough. Along the tracks, Kindred start to smoke. The Court ladies scream. A Syndicate man runs straight up the platform wall and falls back burning.'),
  L('sundial','Fifteen seconds and you smoke. Thirty and you burn. MOVE.')],
  opts:[O('Shadow-Step into the dark under the platform.','lamps.esc',{ab:'shadowstep'}),C('sundial',11,'The cistern ladder. The grate. Count the lamps, find the gap, GO.','lamps.esc','lamps.burnt',{id:'lf_sun',mod:S=>S.flags.side_valko?3:0}),O('Get Soot out. She\'s too old to run.','lamps.soot',{if:S=>!S.flags.sootDead}),O('Hold the Vessel up. Fight light with light.','lamps.vessel',{if:(S,G)=>G.has('vessel')})]};
N['lamps.esc']={lines:[T('Down the ladder into the cistern, into the black water, under. Above you, through the water, a white glare and three hundred screams that go on for what feels like an hour and is eleven seconds.',{fx:['flash','shake:1.6'],do:(S,G)=>{S.flags.lampsBurned=1;S.flags.massacre=1;if(!S.flags.sevWarned)S.flags.sevDead=1;if(!S.flags.malakorWarned)S.flags.malakorDead=1;G.vitae(-2);}}),
  T('When you come up, Platform 0 is ash and smoke and the Magistrate\'s chair, empty, burning politely.'),
  L('web',S=>[S.flags.sevWarned&&'Séverine got out. You warned her.',S.flags.malakorWarned&&'Malakor got out. You warned him.'].filter(Boolean).join(' ')||'Nobody you knew got out.')],next:'dawn.0'};
N['lamps.burnt']={lines:[T('You find the gap a second late. The light finds you.',{fx:['flash','hurt:2','shake:2'],do:(S,G)=>{S.flags.lampsBurned=1;S.flags.massacre=1;S.flags.sevDead=S.flags.sevWarned?0:1;S.flags.malakorDead=S.flags.malakorWarned?0:1;G.vitae(-4);}})],next:S=>S.vitae<=0?'end.ash':'lamps.esc'};
N['lamps.soot']={lines:[T('You pick her up. She weighs nothing, a bundle of sticks and rags and candle wax. You carry her down into the cistern with your back to the light and your coat over both of you and you feel your shoulders start to cook.',{fx:['hurt:1.4'],do:(S,G)=>{G.vitae(-3);S.flags.sootSaved=1;S.flags.lampsBurned=1;S.flags.massacre=1;if(!S.flags.sevWarned)S.flags.sevDead=1;if(!S.flags.malakorWarned)S.flags.malakorDead=1;G.rel('soot',3);}}),
  L('soot','...Oh. Oh, you sweet greedy child.')],next:'dawn.0'};
N['lamps.vessel']={lines:[T('You turn the dial a quarter-inch, the way you\'d turn a stove on, and hold it up.'),T('The Vessel answers the lamps the way a bell answers a bell. Every quartz lamp under Platform 0 cracks at once, overloaded, and goes dark. The brass is hot enough to brand you. It does.',{fx:['flash','shake:1.4','hurt:1'],do:(S,G)=>{S.flags.vesselSaved=1;G.vitae(-2);S.flags.lampsFailed=1;G.xp(60,'Light against light');}}),
  L('magistrate','...Remarkable.')],next:'lamps.dead'};

/* =====================================================================
   DAWN: the sunrise decision
   ===================================================================== */
N['dawn.0']={cs:async(G,S)=>{G.tick(Math.max(0,450-S.time));A.music('dawn');for(const id of ['magistrate','severine','malakor','soot','valko','rostova'])if((S.flags.massacre&&id!=='valko'&&!(id==='soot'&&S.flags.sootSaved))||S.flags.purge)G.removeActor(id);},
  lines:[T('Twenty minutes to dawn. Platform 0 is quiet now. Far above, through the skylight grate, the sky is going the color of a bruise healing.'),
  L('magistrate',S=>S.flags.condemned?'It is nearly time, thief. Stand under the grate.':'The Ward is without a Sheriff. The Prince would like one by nightfall. Somebody tell me who.',{if:S=>!S.flags.massacre&&!S.flags.purge}),
  L('sundial','Decide. Whatever you\'re going to be, decide it now. The sun doesn\'t negotiate.'),
  T(S=>{const v=vesselAt(S);return v==='you'?'The Vessel is warm against your ribs, humming like a fridge in another room.':v==='court'&&!S.flags.sevDead?'Séverine is holding the Vessel in both hands, looking at you.':v==='syndicate'&&!S.flags.malakorDead?'Malakor has the Vessel under his arm like a rugby ball.':v==='lantern'?'Somewhere up on the street, the Vessel is in the back of a grey van.':v==='miller'?'Miller is coming down the stairs with something wrapped in her parka.':'The Vessel isn\'t here.';})],
  next:'dawn.hub'};
const canVessel=S=>{const v=vesselAt(S);return v==='you'||v==='miller'||(v==='court'&&!S.flags.sevDead&&(S.flags.verdict==='win'||S.flags.side_court))||(v==='syndicate'&&!S.flags.malakorDead&&(S.flags.verdict==='win'||S.flags.side_syndicate));};
N['dawn.hub']={opts:[
  O('Claim the Ward. "I\'m the Sheriff now."','end.lord',{if:S=>!S.flags.condemned&&!S.flags.purge&&(allies(S).length>=2||S.flags.heldRoom||S.flags.verdict==='win')}),
  O('Turn the dial for one. Drink the noon. Walk out into Saturday.','end.daywalker',{if:canVessel}),
  O('Turn the dial all the way. Noon over the Marrow Ward. Everyone. You too.','end.noon',{if:canVessel}),
  O('Give the Vessel and the evidence to Miller. Let the living have it.','end.mortal',{if:S=>S.flags.side_miller&&canVessel(S)&&(S.flags.harrowArrested||S.flags.millerFiles)}),
  O('Stop holding the door. Let Absalom have the hands. For good.','end.tenant',{if:S=>S.flags.seizure==='surrender'||S.sync>=80}),
  O('Walk up the stairs and stand in the sun. You aren\'t afraid of it any more.','end.golconda',{if:S=>S.kills===0&&S.flags.seizure==='suppress'&&(NL.G.thought('golconda')||S.th.known.includes('golconda'))}),
  O('Drink the Magistrate. Drink every Elder left on this platform.','end.redgod',{if:S=>!S.flags.massacre&&!S.flags.purge&&(S.flags.diablerie2||S.sync>=70)}),
  O('Run. Up the stairs, past the vans, find a drain, find a dark.','end.run',{if:S=>S.flags.condemned}),
  O('Stand under the grate. Accept the sentence.','end.ash',{if:S=>S.flags.condemned})]};

/* ---------- the endings ---------- */
const END=NL.ENDINGS={};
const ending=(id,o)=>{END[id]=o;N['end.'+id]={lines:o.lines,cs:async(G,S)=>{},next:'end.show.'+id};N['end.show.'+id]={cs:async(G,S)=>{await showEnding(id);},end:true};};
ending('lord',{t:'The New Lord',k:'Ending · The Sheriff of the Marrow Ward',lines:[
  L('you','"The Marrow Ward has a Sheriff. Me."'),
  L('magistrate','...Very well. The Prince will confirm it by nightfall. Try to last longer than Absalom.',{if:S=>!S.flags.massacre}),
  T(S=>S.flags.side_court&&S.flags.side_syndicate?'Séverine inclines her head. Malakor grins. They hate each other. They\'ll both answer to you.':S.flags.side_union?'At the edge of the platform, Dutch and Local 0 start cheering, and somebody throws a screwdriver in the air.':'One by one, the Kindred on the platform kneel. Not because they want to.'),
  L('tenant',S=>S.flags.seizure==='suppress'?'(very quietly) Good. Good. Do it better than I did.':'We did it. *We* did it.')],
  epi:S=>[S.flags.massacre?'You rule a Ward of ash and survivors, and every Kindred who comes to the Marrow Ward for the next hundred years will hear about Platform 0.':'You rule the Marrow Ward from Absalom Vane\'s old chair in the back of Club Reliquary, and you learn, slowly, how to be obeyed.',
    S.flags.harrowArrested?'Agent Harrow is convicted on seven counts. LANTERN is "defunded". You don\'t believe it for a second.':S.flags.harrowDead?'LANTERN never sends anyone to the Marrow Ward again. They send someone somewhere else.':'LANTERN goes quiet. Quiet isn\'t gone.']});
ending('daywalker',{t:'The Daywalker',k:'Ending · Saturday morning',lines:[
  T('You take the Vessel in both hands. The dial turns smoothly, as if it has been waiting a hundred years for someone to turn it this exact amount.'),
  T('You drink.'),
  T('It\'s like swallowing a summer. It hurts more than the freezer, more than the hook, more than the light. Your heart starts. Your *heart starts*. It\'s so loud.'),
  L('tenant','...Ah. Ah, child. Go on, then. Go on. Tell me what it feels like.'),
  T('You walk up the stairs from Platform 0 at 5:09 AM, and the sun comes up over the gasometers, and it\'s on your face, and it doesn\'t hurt.',{do:(S,G)=>{S.flags.cured=1;}})],
  epi:S=>[S.flags.knowName?'Casey Morrow takes the 7:40 train to the coast and knocks on a door with a fish doodle on the post box. Their sister answers. She screams. Then she doesn\'t let go for a very long time.':'You take the first train anywhere. You still don\'t know your name. You pick a new one off a billboard. It suits you.',
    'Sometimes, at four in the morning, you wake up thirsty, and remember, and go back to sleep.','The Tenant goes quiet the first morning. You miss him more than you expected.']});
ending('noon',{t:'Noon',k:'Ending · The sun over the Marrow Ward',lines:[
  T('You turn the dial until it won\'t turn any more.'),
  L('sundial','Oh. Oh, yes. Finally.'),
  T('The Vessel opens like an eye. For four blocks in every direction it is high noon in June: on Platform 0, on Reliquary Row, on the Rookery roof, in the crypt, in the sewers, in every coffin and drain and freezer in the Marrow Ward.'),
  T('It doesn\'t hurt for very long.',{fx:['flash','shake:2'],do:(S,G)=>{S.flags.noon=1;}})],
  epi:S=>['The Marrow Ward wakes up on Saturday with no vampires in it. Nobody notices for about a week.',S.flags.side_miller||S.flags.millerAlly?'Detective Ines Miller closes seven missing-persons cases, one cold case, and a file she labels NIGHT SHIFT and never opens again.':'The seven missing stay missing.',S.flags.leoGoneTown?'On the pier at the coast, Leon Pruette does five minutes of crowd work about a night-shift co-worker who was "really pale, like, medically", and kills.':S.flags.leoDead?'Leo\'s mother keeps his room exactly as it was.':'Leo Pruitt does a set at the Lantern Room on Tuesday. He dedicates it to "the night shift".']});
ending('mortal',{t:'The Mortal Way',k:'Ending · The night shift clocks out',lines:[
  L('you','"Ines. Take it. All of it. The files, the bottle, the lot."'),
  L('miller','You know what happens to this if I put it in an evidence locker.'),L('you','"It sits in the dark for a hundred years. Good."'),
  T('She takes the Vessel. The judge in the wheelchair signs something. Upstairs, the grey vans are already being towed.'),
  L('tenant','You gave away the sun. To a *policewoman*. ...Do you know, I think that might be the cleverest thing anyone\'s done in this Ward for a century.',{do:(S,G)=>{S.flags.mortalWay=1;}})],
  epi:S=>['Special Agent Thomas Harrow is convicted on seven counts of murder. Project LANTERN is dissolved by a Senate subcommittee that never once uses the word "vampire".',
    'Detective Ines Miller is reinstated. She keeps a brass bottle in a lead box in an evidence locker under Precinct 9 and checks on it every Friday.',
    S.flags.verdict==='win'?'You stay in the Marrow Ward. No title. No throne. You work nights. Somebody has to.':'You leave the Marrow Ward before the Court decides what to do with you. Somewhere else has a night shift.']});
ending('tenant',{t:'The Sheriff Returns',k:'Ending · Absalom Vane, again',lines:[
  T('You stop holding the door.'),
  T('He comes through it gently, like a man coming home late, trying not to wake anyone. Your spine straightens. Your hand goes, by itself, to a lapel you don\'t have.'),
  L('tenant','Thank you. Thank you. Shh, now. You can sleep. You\'ve earned it.'),
  T('The body in the dock turns to the Magistrate and smiles a three-hundred-year-old smile.'),
  L('you','"Magistrate. Good evening. I believe I\'m late for work."',{do:(S,G)=>{S.flags.vaneReturned=1;}})],
  epi:S=>['Sheriff Absalom Vane resumes his duties on Saturday night. He is, by every account, a better Sheriff than he was before. Kinder. Odder. He keeps a cactus on his desk.','Sometimes, very late, he stops in the middle of a sentence and listens, as if someone small were knocking on the inside of his skull.','Nobody ever finds out who the neonate was.']});
ending('golconda',{t:'Golconda',k:'Secret ending · The Golconda Protocol',lines:[
  T('You walk up the stairs from Platform 0. Nobody stops you. Nobody can quite believe what you\'re doing.'),
  L('sundial','...Wait. Wait. What are you — no. NO.'),
  T('The sun comes up over the gasometers, and you are standing in it, and you are not burning.'),
  T('Five nights. No one dead by your hand. You held the Beast down every time it asked. And somewhere in that, without noticing, you stopped being afraid.'),
  L('tenant','...Golconda. It\'s real. It\'s *real*. Three hundred years I thought it was a story for children.',{do:(S,G)=>{S.flags.golconda=1;G.task('x_golconda');G.task('x_golconda','done');}})],
  epi:S=>['You are the first Kindred in the history of Port Vellum to reach Golconda. You do not become mortal. You become something the Court has no word for.','You still drink. Not much. You never take more than is offered.','Every Saturday morning, you watch the sunrise from the Rookery roof, from Pemberton\'s chair.']});
ending('redgod',{t:'The Red God',k:'Secret ending · The Cannibal\'s Banquet',lines:[
  T('You turn to the Magistrate. He sees it in your face a second before it happens, and that is the last surprise of his very long life.'),
  T('He goes down like a cathedral. Then Séverine. Then Malakor. Then the rest, one after another, the Court and the Syndicate and the old grey Wraiths, until the platform is quiet and you are so full of the dead you can hear them all talking at once.'),
  L('tenant','...What have you done. What have you *done*. There are so many of us in here.'),
  T('Seventeen voices. Then forty. Then three hundred. And under all of them, very faint, a voice that is only yours, saying something you can\'t hear any more.',{fx:['flash','shake:2','sfx:drink'],do:(S,G)=>{S.flags.redGod=1;S.sync=100;G.task('x_banquet');G.task('x_banquet','done');}})],
  epi:S=>['The thing that walks up the stairs from Platform 0 is not a Sheriff, or a Prince. The Elders of Port Vellum call it the Red God, and pray, when they pray, that it never gets thirsty again.','It always does.']});
ending('purge',{t:'Prince of Ash',k:'Ending · The lamps',lines:[],epi:S=>['You are the only Kindred left in the Marrow Ward.','Nobody comes to judge you. There is nobody left to send.','Every night, alone in the crypt under Club Reliquary, you hold court for three hundred empty chairs.']});
N['end.purge']={lines:[T('Dawn. You go down into the cistern and sleep in the black water among the candles, and nobody comes, because there is nobody left.')],next:'end.show.purge'};
ending('ash',{t:'Ash',k:'Ending · The sentence',lines:[
  T('They walk you under the grate. You don\'t fight.'),
  T('Above you the bruise in the sky goes pink, then gold. The light comes down through the grate in bars, like a cage made of noon.'),
  L('tenant','I\'m sorry. I\'m so sorry. I\'m here. I\'m here. Hold on to me.'),
  T('It doesn\'t hurt for very long.',{fx:['flash'],do:(S,G)=>{S.flags.ash=1;}})],
  epi:S=>['On Saturday the Magistrate writes: "The matter of the Sheriff of the Marrow Ward is closed."',S.flags.harrowArrested?'Harrow goes to prison. You don\'t get to see it.':'LANTERN takes a jar of ash to Washington. It isn\'t yours. It could have been.','Somewhere in a mailbox in the Rookery, a postcard from the sea goes unread.']});
ending('run',{t:'Fugitive',k:'Ending · Outrunning the sun',lines:[
  T('You break the ghouls\' grip and go up the stairs three at a time, past the vans, past the men in grey, into Ferrier Lane with the sky going white behind you.'),
  T('A drain. A pipe. A storm tunnel. A dark so deep it\'s nearly the freezer again.',{do:(S,G)=>{S.flags.fugitive=1;}}),
  L('tenant','Well. We\'re alive. If you can call it that. Which, admittedly, nobody can.')],
  epi:S=>['You live in the tunnels under Port Vellum for eleven years. The Court never stops hunting you.','The rats know your name, eventually. Mother Soot sends you newspapers.','On very bad nights you go up to the payphone on Ferrier Lane and dial a number that nobody answers.']});

/* ---------- the epilogue screen ---------- */
async function showEnding(id){const S=G.S;const e=END[id];S.chapter='end';S.flags.ending=id;G.cine(true);A.music('dawn');
  const fate=[];const f=S.flags;
  if(f.leoDead)fate.push(['Leo Pruitt','Dead in Room 3B. You know why.']);else if(f.leoGoneTown)fate.push(['Leo Pruitt','"Leon Pruette", open mics on the pier. He\'s getting good.']);else if(f.tedState==='thrall')fate.push(['Leo Pruitt','Your thrall. Devoted. Never quite himself again.']);else fate.push(['Leo Pruitt','Still in the Rookery, still doing five minutes on Tuesdays.']);
  fate.push(['Pemberton',f.lastCallDone==='sunrise'?'Watched the sunrise from the Rookery roof. Smiling, they say.':f.pemBound?'Drives for you now. Thirty more years, at least.':f.pemDead?'Gone.':'Polishes the car every evening at sunset.']);
  if(S.dos.tariq)fate.push(['Tariq',f.racketDone&&f.racketDone!=='left'?'Nobody collects from the Lucky Mart any more. He keeps a coffee warm for you.':'Still pays Dale and Pruitt every Wednesday.']);
  if(S.dos.miller)fate.push(['Det. Ines Miller',f.harrowArrested?'Got her man. Got Ray\'s killer. Reinstated.':f.millerAlly?'Knows what the night shift is now. Keeps your number.':'Still working the case. Always will be.']);
  if(f.met404)fate.push(['Mrs. Okafor',f.daniTold?'Knows what happened to Dani. Sleeps a little better.':'Still listens to the chimney at night.']);
  if(f.ezraAlly)fate.push(['Ezra','Home with the Wraiths. Learning to sleep in a bed.']);
  fate.push(['Dr. Elena Rostova',f.rostovaDead?(f.rostovaDone==='drunk'?'You drank her on the roof.':'She stepped off the roof of St. Jude\'s.'):f.rostovaSpoke?'Testified. The Court let her live. Nobody knows why.':f.rostovaFled?'Fled the city. A clinic in another country, they say.':'Unknown.']);
  fate.push(['Valko',f.valkoDead?'Inside you. Quiet now.':f.valkoAlly?'At your left hand. Good dog.':'Still hunting you.']);
  fate.push(['Lady Séverine',f.sevDead?'Ash on Platform 0.':f.side_court?'Keeper of Elysium. Owes you, and hates it.':'Keeper of Elysium. Waiting.']);
  fate.push(['Malakor',f.malakorDead?'Ash on Platform 0.':'Running the Syndicate. Rebuilding his face for the thirteenth time.']);
  (NL.Act.extraFates||[]).forEach(fn=>{try{fn(S).forEach(r=>fate.push(r.map(x=>typeof x==="string"&&NL.gtx?NL.gtx(x):x)));}catch(e){console.error(e);}});
  const rows=fate.map(r=>`<dt>${esc(r[0])}</dt><dd>${esc(r[1])}</dd>`).join('');
  const stats=[['Nights','5'],['Fed',String(S.feeds||0)],['Killed',S.kills>100?'Everyone':String(S.kills||0)],['Diablerie Sync',Math.round(S.sync)+'%'],['Name',f.knowName?'Casey Morrow':'Never remembered']];
  const ov=document.querySelector('#nightsum');
  ov.innerHTML=`<div class="ns end"><div class="mk">${esc(e.k)}</div><h2>${esc(e.t)}</h2>${e.epi(S).map(p=>`<p>${esc(p)}</p>`).join('')}<dl>${rows}</dl><dl>${stats.map(r=>`<dt>${esc(r[0])}</dt><dd>${esc(r[1])}</dd>`).join('')}</dl><p class="credits">THE NEW LORD · a Marrow Ward story · thank you for playing</p><button class="bigbtn" id="nsEnd">Return to title</button></div>`;
  ov.hidden=false;requestAnimationFrame(()=>ov.classList.add('in'));A.sfx('dawn');
  try{const k='newlord.endings';const seen=JSON.parse(localStorage.getItem(k)||'[]');if(!seen.includes(id))seen.push(id);localStorage.setItem(k,JSON.stringify(seen));}catch(e){}
  G.autosave();
  await new Promise(r=>{document.querySelector('#nsEnd').onclick=()=>{A.sfx('click');r();};});
  ov.classList.remove('in');ov.hidden=true;G.cine(false);G.showTitle();}
NL.Act.showEnding=showEnding;

/* =====================================================================
   SECRET · Dial 0 for Gehenna (Ferrier Lane payphone, Friday, 3 AM)
   ===================================================================== */
N['phone.0']&&N['phone.0'].opts&&N['phone.0'].opts.splice(N['phone.0'].opts.length-1,0,O('Dial 000-0414. It\'s three in the morning on Friday.','gh.0',{if:S=>S.night===5&&S.time>=355&&S.time<=385&&S.flags.code0414&&!S.flags.gehenna}));
N['gh.0']={lines:[T('Zero, zero, zero. Zero, four, one, four. The line clicks. Clicks. And then, for the first time, somebody picks up.'),
  T('Breathing. Slow, enormous, like a tide going out in a cave a mile long. And a voice that is not a voice, that is the floor of the world moving.'),
  T('*...LITTLE ONE. YOU HAVE THE BLOOD OF MY BLOOD OF MY BLOOD OF MY BLOOD. SEVENTEEN GENERATIONS. YOU ARE VERY FAR AWAY, AND VERY SMALL.*'),
  T('*I AM SLEEPING UNDER THE SEA. I WILL WAKE WHEN THE LAST CITY IS QUIET. PORT VELLUM IS NOT QUIET. GOOD. GOOD. KEEP IT LOUD.*'),
  L('tenant','Hang up. Hang up. Hang UP.'),
  T('Click.',{do:(S,G)=>{S.flags.gehenna=1;G.task('x_gehenna');G.task('x_gehenna','done');G.xp(60,'Dial 0 for Gehenna');G.sync(5,'Something old heard you');}}),
  L('sundial','...What was that. What WAS that.'),L('pedigree','The First. Or one of the Third. Sleeping. It doesn\'t matter. It isn\'t awake. Keep the Ward loud.')],next:'phone.0'};

/* ---------- the cistern at night five: set the Vessel in the dais ---------- */
const daisB=H.use.dais;H.use.dais=async(S,G)=>{if(S.night===5&&G.has('vessel')&&!S.flags.vesselSet)return G.talk('ds.0');return daisB?daisB(S,G):false;};
N['ds.0']={lines:[T('The brass socket on the sluice altar. The Vessel would fit it exactly.'),L('pedigree','Set here, it shines up through every grate on the platform when it opens. The whole Tribunal would be in it.',{pass:4})],
  opts:[O('Leave it in your coat.',null,{end:true,leave:true})]};
})();
