'use strict';
/* THE NEW LORD — late additions: hunting, the Butcher's Ledger (deepened), and four new side quests
   Night 3 · The Woman Who Locked the Door (Margo)
   Night 4 · No Relation (Officer Pruitt) · Dead Air (the pirate radio)
   Night 5 · Seven Candles (the vigil on Ferrier Lane) */
(function(){
const NL=window.NL,G=NL.G,A=NL.Audio;const {N,ENC,L,T,O,C,H,STORY}=NL.DSL;const {pushPop,pushNpc,pushEnter}=NL.Act;
const X=NL.EXTRAS;const Camp=NL.Camp;
const leoAlive=S=>!S.flags.leoDead;

Object.assign(NL.TASKS,{
  s_margo:{n:'The Woman Who Locked the Door',xp:50,cat:'side'},
  s_uncle:{n:'No Relation',xp:50,cat:'side'},
  s_radio:{n:'Dead Air',xp:50,cat:'side'},
  s_vigil:{n:'Seven Candles',xp:40,cat:'side'}
});
X.marek={n:'Marek Sowa',color:'#c0d890',role:'"Nightjar" · WDRK 88.1',spec:{face:{long:1.04,jaw:0.9,cheek:1.1},skin:[.86,.74,.64],hair:{style:'crop',color:[.35,.25,.15]},shirt:[.25,.3,.22],coat:{color:[.2,.24,.18],length:.45,collar:true},pants:[.15,.15,.14],height:1.02}};
X.kenpruitt={n:'Ken Pruitt',color:'#90a0c0',role:'Officer Pruitt, off duty',spec:{face:{long:1.06,jaw:0.8,nose:1.2},skin:[.9,.76,.68],hair:{style:'shaved',color:[.6,.5,.4]},shirt:[.35,.32,.3],coat:{color:[.18,.2,.16],length:.5,collar:true},pants:[.16,.16,.2]}};

/* =====================================================================
   SYSTEMS · waking hungry, and the Hunt
   ===================================================================== */
Camp.tickHooks.push((S,G)=>{if(S.flags.wokeStarved===S.night&&G.once('starved'+S.night))setTimeout(()=>G.toast('hurt','You wake on your last drops. The day took everything it could. Find blood: the map has a Hunt option.','Starving'),2500);});
const huntMin=S=>S.night===4?45:30;
const huntN=S=>S.flags['hunts'+S.night]||0;
const huntRes=S=>['sanguine','choleric','melancholic','phlegmatic'][(S.night+huntN(S))%4];
const hunted=(S,G)=>{S.flags['hunts'+S.night]=huntN(S)+1;G.tick(huntMin(S));};
N['hunt.0']={enter:S=>{delete S.checks.hunt_sip;delete S.checks.hunt_stop;},
  lines:[T(S=>S.night===4?'The floodlights sweep the crossings in slow white arcs. Hunting tonight means moving in the gaps between them.':S.night===5?'Friday. Every Kindred in the Ward is out tonight, and every one of them is hungry. You\'re not special.':'You let the night narrow until all you can hear is heartbeats.'),
  L('osmosis',S=>({sanguine:'Somebody two streets over is very, very happy. You can smell it from here, like oranges.',choleric:'Somebody close by is spoiling for a fight. It\'s in the air like hot metal.',melancholic:'Somewhere nearby, somebody is crying into a phone.',phlegmatic:'A night porter on his cigarette break, slow and calm as a cow in a field.'})[huntRes(S)],{pass:3})],
  opts:[
  C('stagecraft',8,'A sip, no more. Someone asleep at a bus stop. They\'ll wake with a headache and no story.','hunt.sip','hunt.sipBad',{id:'hunt_sip',repeat:true,mod:S=>(S.night===4?-2:0)+(S.clan==='wraiths'?1:0)}),
  O('Text the Reliquary\'s courier. $30, a wine glass on a doorstep, no questions.','hunt.courier',{if:S=>(S.cash||0)>=30&&!S.flags.bloodHunt&&!S.flags.sevDead}),
  O('Rats. There are always rats.','hunt.rat'),
  O('Take someone properly. You\'re so tired of being hungry.','hunt.deep'),
  O('Not tonight.',null,{end:true,leave:true})]};
N['hunt.sip']={lines:[T(S=>S.night===4?'A security guard asleep in his booth with the radio on, behind a floodlight that\'s pointed the wrong way. You\'re in and out between two sweeps.':'A man asleep on a bench with his tie round his forehead. You sit beside him like a friend. Thirty seconds. He says "Mom?" and doesn\'t wake.',{fx:['flash','sfx:drink'],do:(S,G)=>{hunted(S,G);G.feed(2,huntRes(S),'a stranger, sleeping',{kind:'mortal'});G.xp(10,'A clean feed');}}),
  L('pulse','His heart\'s fine. Slow, a bit thready. He\'ll eat a big breakfast and never know why.')],end:true};
N['hunt.sipBad']={lines:[T('He wakes up halfway through. He sees your face. He sees your *teeth*.',{fx:['shake:.6'],do:(S,G)=>{hunted(S,G);G.feed(2,huntRes(S),'a stranger, screaming',{kind:'mortal'});G.heat(1);G.comp(-1,'He saw you');}}),
  L('stagecraft','He runs. He\'ll tell someone. Nobody will believe him. Probably.')],end:true};
N['hunt.courier']={lines:[T('Eighteen minutes later, a boy on a bicycle leaves a wine glass with a coaster over it on the step and rides away without looking back. It\'s still warm.',{fx:['sfx:drink'],do:(S,G)=>{hunted(S,G);G.cash(-30,'The courier');G.feed(2,'sanguine','somebody\'s Saturday night',{kind:'donor'});}}),
  L('pedigree','Séverine\'s people keep a list of everyone who orders. Of course they do.',{pass:5})],end:true};
N['hunt.rat']={lines:[T('A storm drain, your hand, a long wait, and then something warm and furious in your fist.',{do:(S,G)=>{hunted(S,G);if(S.clan==='stray')S.flags.scavNow=1;G.feed(1,null,'a rat',{kind:'rat'});S.flags.scavNow=0;}}),
  L('pedigree','How the mighty, et cetera.',{if:S=>S.clan!=='stray'&&S.clan!=='sovereign'}),
  L('gutter','Good protein. Don\'t knock it.',{if:S=>S.clan==='stray'})],end:true};
N['hunt.deep']={lines:[T('A man coming out of a late bar on his own, looking for a cab. You walk with him. You turn down an alley with him, and he goes, because you make it seem like his idea.'),
  T('It is so good. It is the best thing that has happened to you all week. You can feel his heart doing what you tell it.',{fx:['flash','sfx:drink'],do:(S,G)=>{hunted(S,G);G.feed(4,huntRes(S),'a stranger, all at once',{kind:'mortal'});}}),
  L('frenzy','More. There\'s more in him. Take all of it.'),L('pulse','His heart\'s stuttering. Stop. STOP.')],
  opts:[C('rigor',9,'Stop.','hunt.stopped','hunt.killed',{id:'hunt_stop',repeat:true,noPush:false,mod:S=>(S.vitae>=6?1:0)-(G.hunger()>2?2:0)}),O('Don\'t stop.','hunt.killed')]};
N['hunt.stopped']={lines:[T('You stop. You lay him down in a doorway on his side, the way they teach you on first-aid courses, and call an ambulance from his own phone.',{do:(S,G)=>{G.comp(1,'You stopped');G.xp(15,'You stopped');}}),
  L('pulse','He\'ll make it. He\'ll need a transfusion. It\'s fine. You\'re fine.')],end:true};
N['hunt.killed']={lines:[T('You don\'t stop. Afterwards, the alley is very quiet, and you are very full, and there is a man in it who isn\'t anybody any more.',{fx:['shake:.8'],do:(S,G)=>{S.kills++;S.lethal[S.night]=(S.lethal[S.night]||0)+1;G.vitae(2);G.heat(1);G.comp(-2,'You didn\'t stop');}}),
  L('tenant','...We all do it once. It\'s the second time you have to watch for.',{if:S=>S.kills===1}),
  L('tenant','That\'s not the first time any more, child.',{if:S=>S.kills>1})],end:true};

/* =====================================================================
   THE BUTCHER'S LEDGER · deepened: decoding it opens the quest
   ===================================================================== */
N['led.ok']={lines:[T('You lay the manifests out on the floor in date order. Forty years of "units". Then the last two months: seven units. Seven dates. Each one the Wednesday after a disappearance. Signed for at the Gilded Court\'s service door. Counter-signed: E.R.'),
  L('web','Kowalski\'s has been disposing of bodies for the Gilded Court for forty years. And the seven missing came here, after the clinic, signed for by E.R. Elena Rostova.',{do:(S,G)=>{S.flags.ledgerDone=1;G.task('s_ledger');G.fact('margo','render');S.flags.knowSeven=1;G.xp(30,'The manifests');if(!G.has('manifest'))G.give('manifest');
    S.quests.note_s_ledger='Forty years of rendering for the Gilded Court; the seven missing among them, counter-signed E.R. Margo Kowalski kept these books, and Margo has run. Find her, or decide who should have the manifests: Mrs. Okafor, Malakor, or the Tribunal.';}}),
  L('nostalgia','Dani Okafor. Pete Sowa. Seven people. Rendered.',{if:S=>S.flags.met404}),
  L('pedigree','This is the kind of paper that ends a Court. Or buys one.',{pass:6})],next:'led.0'};
const ledgerDone=(G,why)=>{if(G.S.tasks.s_ledger==='active'){G.task('s_ledger','done');G.xp(20,why);}};
// Mrs. Okafor can be given the manifests
if(N['dn.0']&&N['dn.0'].opts)N['dn.0'].opts.splice(1,0,O('Give her the manifests. Let her read the dates herself.','dn.man',{if:(S,G)=>G.has('manifest')}));
N['dn.man']={lines:[T('She reads them at the kitchen table with her reading glasses on and a pencil, the way she must once have done Dani\'s homework. She finds the Wednesday. She underlines it.'),
  L('okafor','"Unit". She was a *unit*.'),
  L('okafor','I am going to keep these. And I am going to make copies at the library, and I am going to send one to every newspaper in this city, and one to that detective. The woman. Miller.',{do:(S,G)=>{G.take('manifest');S.flags.daniTold='manifest';S.flags.okaforPapers=1;G.keep('dani');G.comp(1,'For Dani');G.xp(30,'Dani');ledgerDone(G,'The Butcher\'s Ledger');G.heat(1);}}),
  L('stagecraft','Newspapers. Heat on the Court, heat on Kowalski\'s, heat on everyone. She doesn\'t care. Why should she?')],end:true};
// Malakor or the Tribunal also close it
Camp.tickHooks.push((S,G)=>{if(S.tasks.s_ledger==='active'&&(S.flags.side_syndicate==='manifests'||S.flags.tbMan||S.flags.ledgerBurned))ledgerDone(G,'The Butcher\'s Ledger');});

/* =====================================================================
   NIGHT 3 · THE WOMAN WHO LOCKED THE DOOR
   Margo Kowalski is hiding at Gideon's.
   ===================================================================== */
const margoHere=S=>(S.night===3||S.night===4)&&((S.tasks.s_margo==='active'&&!S.flags.margoOut)||S.flags.margoOut==='testify');
Camp.tickHooks.push((S,G)=>{if(S.night===3&&S.time>=40&&!S.flags.margoDead&&G.once('margoText')){
  G.text('Unknown','It\'s Margo. Kowalski. I\'m sorry about the door. I\'m at Gideon\'s, in the back with the coffins. Don\'t bring her. Please.');
  G.task('s_margo');G.meet('margo');S.quests.note_s_margo='Margo Kowalski, who locked you in the freezer on Monday morning, is hiding at the Pawn & Coffin. She\'s frightened of someone. "Her."';}});
pushPop('pawn',(S,G)=>{if(margoHere(S))G.addActor('margo',NL.CHARS.margo.spec,{x:5.5,z:1.45,ry:-0.5,breathes:true,pose:'sit'});});
pushNpc('pawn',(S,G)=>G.actor('margo')?{id:'margo',actor:'margo',label:'Margo'}:null);
H.use.margo=async(S,G)=>G.talk(S.seen['mg.0']?'mg.hub':'mg.0');
N['mg.0']={enter:(S,G)=>{G.focus(['you','margo'],.8);G.look('margo','you');},lines:[
  T('Behind the coffin showroom, sitting on a mahogany model called THE ETERNAL REST with a thermos and a carrier bag of everything she owns: a big grey woman in a butcher\'s apron she forgot to take off when she ran.'),
  L('margo','You look better. That\'s a terrible thing to say to someone. You look less dead.'),
  L('gideon','She\'s been here since Tuesday. She pays rent in pork chops. I\'m not complaining.',{if:S=>!!G.actor('gideon')}),
  L('pulse','Sixty-three. High blood pressure. Not sleeping. Terrified, and not of you. Not *only* of you.')],next:'mg.hub'};
N['mg.hub']={opts:[
  O('"Why did you lock me in?"','mg.door',{once:true}),
  O('"Who told you to fix the safety release?"','mg.who',{once:true,if:S=>S.seen['mg.door']}),
  O('"The manifests. Forty years of them."','mg.ledger',{once:true,if:(S,G)=>G.has('manifest')||S.flags.ledgerDone}),
  C('velvet',10,'"Testify. Friday, Platform 0. Tell the Magistrate who paid you."','mg.testify','mg.refuse',{id:'mg_vel',if:S=>S.seen['mg.who']&&!S.flags.margoOut,mod:S=>(S.rel.margo||0)+(S.flags.millerAlly?1:0)+(S.flags.ledgerBurned?2:0)}),
  O('"Get out of town. Tonight. Here\'s a hundred dollars."','mg.flee',{if:S=>(S.cash||0)>=100&&!S.flags.margoOut}),
  O('"Pemberton can drive you to the coast."','mg.pem',{if:S=>S.flags.carOK&&!S.flags.carGone&&!S.flags.pemDead&&!S.flags.margoOut}),
  O('Text Séverine where she is.','mg.sell',{if:S=>(S.flags.sevAlly||S.flags.side_court)&&!S.flags.sevDead&&!S.flags.margoOut}),
  O('Drink her. She locked you in the dark.','mg.drink',{if:S=>!S.flags.margoOut}),
  O('"I\'ll be back."',null,{end:true,leave:true})]};
N['mg.door']={lines:[
  L('margo','Quarter to five, Monday. I\'m in the shop doing the books because I can\'t sleep, because I know what\'s going to happen in my walk-in that night, because I *arranged* for it. And the back door goes, and it\'s Pemberton. The Sheriff\'s driver.'),
  L('margo','Carrying you. Smoking. Actually smoking, like a joint of meat. Wearing *his* coat. And he puts you in the walk-in and he looks at me and he says, "Lock it, Mrs. Kowalski. The sun." And he goes.'),
  L('margo','So I locked it. Because of the sun. And because I didn\'t know what you were going to be when you woke up, and Leo was asleep in the back.'),
  L('margo','Both. Mostly the second. I\'m sorry.',{do:(S,G)=>{G.fact('margo','lock');S.flags.margoDoor=1;}}),
  L('nostalgia','The cold. The dark. A latch going down outside. Someone on the other side of the door, breathing, not leaving for a long time.')],next:'mg.hub'};
N['mg.who']={lines:[
  L('margo','A courier. A note in that handwriting, that copperplate, you know whose. And an envelope. Five thousand dollars.'),
  L('margo','"The Sheriff visits the clinic Sunday and your shop Monday. Make sure the freezer holds whatever goes in." So I took the inside release off. My father put that knob in himself in 1961. I took it off with a screwdriver in five minutes.',{do:(S,G)=>{G.fact('margo','release');G.fact('margo','v');S.flags.margoNamedSev=1;}}),
  L('web','Séverine wanted Vane trapped in that freezer with whatever came for him. She didn\'t fire the lance. She just made sure he couldn\'t run from it.'),
  L('tenant','...Séverine. Oh, my dear. You always did like to keep your hands clean.',{if:S=>S.flags.knowSevHarrow}),
  L('margo','And now he\'s dead and she\'s tidying up. Tuesday night somebody came to my flat. I watched from the bus stop. They didn\'t knock.')],next:'mg.hub'};
N['mg.ledger']={lines:[
  L('margo','My father did it. Then me. "Units." You don\'t ask. They bring them in at the back, you render them, you sign. It\'s a trade. Like pork.'),
  L('margo','Then this summer the seven. They didn\'t come from the Court. They came in a Volvo, wrapped in hospital sheets, and the doctor signed. I knew that was different. They were *young*.'),
  L('margo','I took the money anyway. I\'m sixty-three. I don\'t know how to do anything else.')],
  opts:[O('"Burn them. Here, now, with me."','mg.burn',{if:(S,G)=>G.has('manifest')}),O('"They\'re evidence. They\'re staying with me."','mg.keep',{if:(S,G)=>G.has('manifest')}),O('Say nothing.','mg.hub')]};
N['mg.burn']={lines:[T('Gideon lends you a coal scuttle. Forty years of paper goes up in a cast-iron bucket in the back of a pawnshop, and Margo Kowalski watches every page and doesn\'t cry until the last one.',{do:(S,G)=>{G.take('manifest');S.flags.ledgerBurned=1;G.rel('margo',2);G.comp(1,'Ashes');}}),
  L('margo','My father would have hit me. ...Thank you.'),
  L('pedigree','That was the only proof the Court ever did it. Gone. Séverine would kiss you, if she knew.',{pass:5})],next:'mg.hub'};
N['mg.keep']={lines:[L('margo','...Yes. I suppose they are. Do one good thing with them. One.',{do:(S,G)=>G.rel('margo',1)})],next:'mg.hub'};
N['mg.testify']={lines:[T('She looks at the thermos for a long time.'),
  L('margo','Platform 0. In front of all of them. In front of *her*.'),
  L('margo','...All right. All right. I\'ll stand up and say it. Somebody in this city ought to say something true for once.',{do:(S,G)=>{S.flags.margoTestify=1;S.flags.margoOut='testify';G.task('s_margo','done');G.rel('margo',2);G.xp(50,'A witness');}}),
  L('gideon','She stays here till Friday. Nobody comes in my back room without an appointment.',{if:S=>!!G.actor('gideon')})],end:true};
N['mg.refuse']={lines:[L('margo','No. No. I\'m sorry. They\'ll put me in my own walk-in. I\'m not brave. I\'ve never once been brave.'),L('velvet','Not yet. She trusts you a little more each time you don\'t hurt her.')],next:'mg.hub'};
N['mg.flee']={lines:[T('You count it into her hand. She looks at it as if it\'s much more than it is.',{do:(S,G)=>{G.cash(-100,'Margo\'s bus fare');}}),
  L('margo','My sister\'s in Duluth. She hates me. She\'ll let me in.',{do:(S,G)=>{S.flags.margoOut='fled';G.task('s_margo','done');G.rel('margo',2);G.comp(1,'You let her go');}})],cs:async(G,S)=>{G.dlgHide();G.walk('margo',3.2,0.6);await G.wait(1.4);G.removeActor('margo');},end:true};
N['mg.pem']={lines:[L('margo','The Sheriff\'s car? Me? I\'ve been inside a Bentley once and it was a hearse.'),
  T('Twenty minutes later Pemberton holds the back door open for her like she\'s the Queen. She gets in with her carrier bag on her knees.',{do:(S,G)=>{S.flags.margoOut='fled';G.task('s_margo','done');G.rel('margo',2);G.rel('pemberton',1);G.comp(1,'You let her go');G.tick(20);}}),
  L('pemberton','Duluth, madam. A pleasant drive. I\'ll be back before sunrise, ‹sir›.',{if:S=>!!G.actor('pemberton')})],cs:async(G,S)=>{G.dlgHide();G.removeActor('margo');},end:true};
N['mg.sell']={lines:[T('You type it standing in front of her. She watches you do it. She knows exactly what you\'re doing.'),
  L('margo','...Of course. Of course you would. You\'re one of them.'),
  T('An answer in four seconds: *How thoughtful. Someone will collect her.*',{do:(S,G)=>{S.flags.margoOut='sold';G.task('s_margo','done');G.rel('severine',1);G.rel('margo',-3);G.comp(-2,'You sold her');G.cash(200,'An envelope, later, under your door');}}),
  L('tenant','I would have done exactly the same. That is not a compliment.')],end:true};
N['mg.drink']={lines:[T('She doesn\'t fight. She closes her eyes, the way you\'d close them in a dentist\'s chair.'),
  T('Butcher\'s blood: iron and sawdust and a lifetime of cold rooms.',{fx:['flash','sfx:drink'],do:(S,G)=>{S.flags.margoOut='dead';S.flags.margoDead=1;G.feed(4,'melancholic','Margo Kowalski',{kind:'mortal',kill:true});G.task('s_margo','done');G.comp(-2,'Margo');G.heat(1);}}),
  L('gideon','...I\'ll need help with the box. She\'s a big woman.',{if:S=>!!G.actor('gideon')})],cs:async(G,S)=>{G.dlgHide();G.removeActor('margo');},end:true};

/* =====================================================================
   NIGHT 4 · NO RELATION · Officer Ken Pruitt
   ===================================================================== */
const uncleOn=S=>S.night===4&&S.tasks.s_uncle==='active'&&!S.flags.uncleDone;
Camp.tickHooks.push((S,G)=>{if(S.night===4&&S.time>=30&&!S.flags.pruittDead&&G.once('uncleText')){
  G.text('K. Pruitt',S.flags.racketDone==='feed'?'This is Officer Pruitt. I didn\'t see anything. I swear I didn\'t see anything. But I need to talk to you about my nephew. Leo. Rookery, third floor. Please.':'This is Ken Pruitt. Officer Pruitt. Tariq gave me this number. You know my nephew, Leo. Rookery, third floor, tonight. Just talk. Nobody else.');
  G.task('s_uncle');S.quests.note_s_uncle='Officer Pruitt is waiting outside Room 3B at the Rookery. He says Leo is his nephew. Tariq said "no relation".';}});
pushPop('rookery',(S,G)=>{if(uncleOn(S))G.addActor('kenpruitt',X.kenpruitt.spec,{x:2.3,z:1.4,ry:2.4,breathes:true,pose:'arms'});});
pushNpc('rookery',(S,G)=>G.actor('kenpruitt')?{id:'kenpruitt',actor:'kenpruitt',label:'Officer Pruitt'}:null);
H.use.kenpruitt=async(S,G)=>G.talk(S.seen['un.0']?'un.hub':'un.0');
N['un.0']={enter:(S,G)=>{G.focus(['you','kenpruitt'],.8);G.look('kenpruitt','you');},lines:[
  T('Out of uniform he\'s smaller: a parka, a carrier bag of groceries he plainly doesn\'t know what to do with, standing outside 3B like he\'s been told off.'),
  L('kenpruitt',S=>S.flags.racketDone==='feed'?'Don\'t. Please. Stay over there. I just. I need to say something and then I\'ll go.':'You. From the Lucky Mart. Right. Okay.'),
  L('kenpruitt','He\'s my sister\'s kid. I told Tariq no relation. Fifty-two years old and ashamed to be related to a kid who does comedy.'),
  L('kenpruitt','...That\'s not true. I\'m ashamed he\'s related to *me*.'),
  L('kenpruitt','Tuesday, men in grey suits came to Precinct 9. Federal. Asking for Leonard Pruitt, "material witness". The Captain gave them his address. Then one of them takes me aside and offers me ten thousand dollars to bring him in quiet.'),
  L('kenpruitt','I\'ve taken a lot of money in my life. I took Harrow\'s money to lose seven missing-persons reports this summer. I\'m not taking that.',{do:(S,G)=>{S.flags.pruittConfessed=1;}}),
  L('web','LANTERN wants the boy who survived the freezer. Bitten, alive, with Vane\'s blood in the room. To Harrow, that\'s not a witness. That\'s a *sample*.',{pass:5}),
  L('web','"No relation, I asked." He lied to Tariq\'s face, because he was ashamed of a kid who tells jokes for free.',{pass:9})],next:'un.hub'};
const leoState=S=>S.flags.leoDead?'dead':S.flags.leoGoneTown?'gone':(S.flags.tedState==='thrall'||S.flags.leoGhoul)?'thrall':'here';
N['un.hub']={opts:[
  O('"Get him out. Tonight. You drive."','un.drive',{if:S=>leoState(S)==='here'&&!S.flags.uncleLeo}),
  O('"He\'s already gone. He\'s safe."','un.safe',{if:S=>leoState(S)==='gone'&&!S.flags.uncleLeo}),
  O('"He\'s with me now. He doesn\'t need you."','un.thrall',{if:S=>leoState(S)==='thrall'&&!S.flags.uncleLeo}),
  O('Tell him the truth. Leo\'s dead.','un.dead',{if:S=>leoState(S)==='dead'&&!S.flags.uncleLeo}),
  O('"Leo left town. He\'s fine. Stop looking."','un.lie',{if:S=>leoState(S)==='dead'&&!S.flags.uncleLeo}),
  C('velvet',9,'"You owe the Ward seven reports. Start paying."','un.turn','un.noturn',{id:'un_vel',if:S=>S.flags.uncleLeo&&!S.flags.pruittInside&&!S.flags.uncleWiped,mod:S=>(S.flags.uncleLeo==='drive'||S.flags.uncleLeo==='truth'?2:0)+(S.flags.racketDone==='feed'?-2:0)}),
  O('Kneel: "You have no nephew. You never did."','un.kneel',{ab:'kneel',if:S=>!S.flags.uncleLeo}),
  O('He lost seven reports for Harrow\'s money. Drink him.','un.drink'),
  O('"Go home, Ken."','un.bye',{if:S=>S.flags.uncleLeo}),
  O('"Give me a minute."',null,{end:true,leave:true,if:S=>!S.flags.uncleLeo})]};
const uncleSet=(S,G,k)=>{S.flags.uncleLeo=k;G.task('s_uncle','done');G.rel('leo',k==='lie'?0:1);};
N['un.drive']={lines:[L('kenpruitt','Me? He hasn\'t spoken to me since Christmas 2019. I said something about his act. ...I said it wasn\'t an act, it was a cry for help.'),
  T('You knock on 3B. There\'s a long conversation through the door that you politely don\'t listen to, and some shouting, and then Leo comes out in his coat with a cactus in a carrier bag.'),
  L('leo','Uncle Ken. Wow. Okay. This is the worst night of my life and it\'s only the *fourth* worst thing that\'s happened this week.',{if:S=>!S.flags.leoFogged}),
  T('They go down the stairs together, not quite side by side.',{do:(S,G)=>{uncleSet(S,G,'drive');S.flags.leoGoneTown=1;S.flags.uncleDrove=1;if(S.tasks.s_leo==='active')G.task('s_leo','done');G.xp(40,'No Relation');G.comp(1,'Family');}})],next:'un.hub'};
N['un.safe']={lines:[L('kenpruitt','...Gone. Gone where? No, don\'t tell me. Don\'t tell me. Good.',{do:(S,G)=>{uncleSet(S,G,'safe');G.xp(30,'No Relation');}}),
  T('He sets the groceries down outside 3B anyway. Then picks them back up. Then sets them down.')],next:'un.hub'};
N['un.thrall']={lines:[T('The door of 3B opens before you knock. Leo is standing there in a clean shirt, smiling at you, not at his uncle. He doesn\'t look at his uncle at all.'),
  L('leo','Hi, Uncle Ken. I\'m fine. I\'m really fine. I\'ve got work.'),
  L('kenpruitt','...What did you do to him. What did you *do* to him.',{do:(S,G)=>{uncleSet(S,G,'thrall');G.comp(-1,'His face');G.xp(20,'No Relation');}})],next:'un.hub'};
N['un.dead']={lines:[T('You tell him. Not how. Just that it was Tuesday, and it was quick, and it was in his own room with the cactus on the windowsill.'),
  L('kenpruitt','...Okay. Okay.'),T('He sits down on the stairs with the groceries on his knees and stays there.',{do:(S,G)=>{uncleSet(S,G,'truth');G.comp(1,'You told him');G.xp(30,'No Relation');}}),
  L('kenpruitt','I\'ll tell my sister. That should be me. That\'s the one thing I can do.')],next:'un.hub'};
N['un.lie']={lines:[L('kenpruitt','Left? ...Yeah. Yeah, that\'d be him. Never calls.',{do:(S,G)=>{uncleSet(S,G,'lie');G.xp(20,'No Relation');}}),
  L('pulse','He believes you because he wants to. Someone will open that door eventually. It won\'t be you.')],next:'un.hub'};
N['un.turn']={lines:[L('kenpruitt','...Friday. They\'ve got Precinct 9 on the cordon round the Switchyard. "Gas leak". Me and Dale on van three.'),
  L('kenpruitt','I don\'t know what\'s going on down there and I don\'t want to know. But I\'ll have a radio. If it goes wrong, I\'ll tell you where it\'s dark.',{do:(S,G)=>{S.flags.pruittInside=1;G.xp(30,'An inside man');S.quests.note_s_uncle='Ken Pruitt will be on the LANTERN cordon at Platform 0 on Friday, with a radio.';}})],next:'un.hub'};
N['un.noturn']={lines:[L('kenpruitt','I\'ve done my good deed for the decade. Don\'t push it.')],next:'un.hub'};
N['un.kneel']={lines:[T('You say it into him and it goes in like a key. He blinks. He looks at the door of 3B as if it were any door.',{do:(S,G)=>{uncleSet(S,G,'kneel');S.flags.uncleWiped=1;G.comp(-1,'You took his nephew');G.xp(20,'No Relation');}}),
  L('kenpruitt','...Sorry. Wrong floor. Wrong building, I think.')],cs:async(G,S)=>{S.flags.uncleDone=1;G.dlgHide();G.walk('kenpruitt',8.6,1.5);await G.wait(1.6);G.removeActor('kenpruitt');},end:true};
N['un.drink']={lines:[T('He sees it coming. He drops the groceries. Oranges roll down the corridor.'),
  T('Cop\'s blood: cheap coffee and old fear and something that might once have been decent.',{fx:['flash','sfx:drink'],do:(S,G)=>{S.flags.pruittDead=1;S.flags.uncleDone=1;G.feed(4,'choleric','Ken Pruitt',{kind:'mortal',kill:true});if(S.tasks.s_uncle==='active')G.task('s_uncle','done');G.heat(2);G.comp(-2,'Ken Pruitt');}}),
  L('stagecraft','A police officer, dead in a corridor, during martial law. The Court will clean it up. The Court will *bill* you for it.')],cs:async(G,S)=>{G.dlgHide();G.removeActor('kenpruitt');},end:true};
N['un.bye']={lines:[L('kenpruitt','Yeah. Yeah.')],cs:async(G,S)=>{S.flags.uncleDone=1;G.dlgHide();G.walk('kenpruitt',8.6,1.5);await G.wait(1.6);G.removeActor('kenpruitt');},end:true};

/* =====================================================================
   NIGHT 4 · DEAD AIR · a pirate station on the Rookery roof
   ===================================================================== */
const djOn=S=>S.night===4&&!S.flags.djDone;
if(N['roof.0']){
  N['roof.0'].lines.push(T('A cable runs from the TV aerials across the puddles to a tarp tent by the parapet. Inside it someone is talking, low and fast, into a microphone: "...floodlight on Halloran and Vine, swinging east. Grey van parked outside St. Jude\'s. Stay in. Stay *in*. This is Nightjar on 88.1, Dead Air..."',{if:djOn}));
  N['roof.0'].opts.splice(N['roof.0'].opts.length-1,0,O('Lift the tarp.','dj.0',{if:djOn}));}
Camp.tickHooks.push((S,G)=>{if(S.night===4&&S.time>=70&&!S.flags.djDone&&G.once('djHeard')){
  G.toast('task','A car radio somewhere is tuned to a pirate station: floodlight positions, van sightings, the Rookery roof mentioned twice.','88.1 FM');
  G.task('s_radio');S.quests.note_s_radio='Someone calling himself Nightjar is broadcasting the curfew\'s secrets on 88.1 from the Rookery roof. Somebody powerful will want him quiet.';
  setTimeout(()=>{if(!S.flags.sevDead&&!S.flags.bloodHunt)G.text('S.','There is a mortal on the Rookery roof with a radio transmitter, saying the word "pale" on air. Make him stop. Quietly, or otherwise.');},6000);}});
N['dj.0']={lines:[T('A camping lantern, a car battery, a transmitter held together with gaffer tape, and a thin man in a balaclava with headphones round his neck. He sees your eyes in the lantern light and doesn\'t scream. He reaches for a camera.'),
  L('marek','Don\'t. Don\'t, I\'ve got a dead-man switch, if I don\'t check in every hour it uploads everything. ...It doesn\'t. I haven\'t got one. I wish I had one.'),
  L('marek','Marek Sowa. Nightjar. My brother Pete went into St. Jude\'s in July for a free blood test and didn\'t come out. The police lost the report. So I started broadcasting where the grey vans go.'),
  L('marek','They\'re still picking people up. Under the curfew. Anyone out after midnight. Nobody\'s going to miss a homeless guy in a curfew, right? *I* miss them.'),
  L('nostalgia','Pete Sowa. One of the seven. A name on a poster in the lane.',{if:S=>S.flags.knowSeven||S.flags.met404}),
  L('web','Séverine wants him silent because he\'s getting close to the Court. Harrow wants him silent because he\'s getting close to LANTERN. Nobody wants him silent because he\'s wrong.',{pass:6})],next:'dj.hub'};
N['dj.hub']={opts:[
  O('Tell him what happened to Pete.','dj.pete',{once:true,if:S=>S.flags.knowSeven||S.flags.ledgerDone||S.flags.lanternRead||G.has('lanternfile')}),
  C('gutter',10,'"Read this on air: Friday, Platform 0, there are lamps in the grates. Everyone who can hear this, stay out of the dark under the Switchyard."','dj.warn','dj.warnBad',{id:'dj_gut',if:S=>S.flags.knowCode&&!S.flags.djWarned,mod:S=>(S.flags.side_soot?2:0)+(S.rel.marek||0)}),
  O('Smash the transmitter. Tell him to go home.','dj.smash'),
  O('Crown of Fog: there never was a radio station.','dj.fog',{ab:'fog'}),
  O('"Keep broadcasting. I\'ll make sure nobody comes up these stairs."','dj.guard'),
  O('He\'s seen your eyes. Drink him.','dj.drink'),
  O('Drop the tarp.',null,{end:true,leave:true})]};
N['dj.pete']={lines:[T('You tell him: the clinic, the basement, the trial, the seven cots. You tell him what "unit" means.'),
  L('marek','...I knew. I knew. You know you know a thing and you broadcast every night anyway so you don\'t have to know it.',{do:(S,G)=>{G.rel('marek',2);S.flags.marekKnows=1;}}),
  L('marek','I\'m going to read their names. All seven. Every hour until they find me.')],next:'dj.hub'};
N['dj.warn']={lines:[T('He reads it cold, twice, in a voice like a weather forecast. Somewhere below, all over the Marrow Ward, in crypts and chop-shops and drains, things that never listen to the radio are listening to the radio.'),
  L('soot','(from a rat on the parapet, very small) Mm. Mm. The pipes heard that. Everyone will know by morning.',{if:S=>!S.flags.sootDead}),
  L('web','Everyone who heard that will think twice before they stand on a grate tomorrow. Including Harrow, who now knows *you* know.')],end:true};
N['dj.warnBad']={lines:[L('marek','"Lamps in the grates"? Mate, I read out van plates. I don\'t do... whatever that is. Poetry.'),L('gutter','He doesn\'t trust you enough yet. Give him something true first.')],next:'dj.hub'};
N['dj.smash']={lines:[T('The transmitter goes off the parapet and lands in a skip six floors down with a noise like an expensive cymbal.'),
  L('marek','...That was two years of my life. Fine. Fine. You\'re one of them, then.',{do:(S,G)=>{S.flags.djDone='silenced';G.task('s_radio','done');G.rel('severine',1);G.rel('marek',-2);G.comp(-1,'Dead air');}}),
  T('He goes down the stairs. You hear him crying on the fourth floor landing.')],end:true};
N['dj.fog']={lines:[T('Fog in his head, soft and grey. He stands up, looks at the transmitter as if it were someone else\'s barbecue, and goes downstairs to bed.',{do:(S,G)=>{S.flags.djDone='fogged';G.task('s_radio','done');G.rel('severine',1);G.xp(20,'Dead Air');}}),
  L('nostalgia','He\'ll wake up tomorrow with a brother he can\'t quite remember losing. Is that kinder? You don\'t know.')],end:true};
N['dj.guard']={lines:[L('marek','You? Guard *me*? What are you going to do, bite them?'),L('marek','...Oh. Right. Yes. Okay.'),
  T('You sit on the fire-door stairs until four in the morning listening to him read van plates. Twice someone comes up. Twice they go back down very fast.',{do:(S,G)=>{S.flags.djDone='guarded';G.task('s_radio','done');G.rel('marek',2);G.rel('severine',-1);G.tick(60);G.xp(40,'Dead Air');G.comp(1,'Dead air, alive');}})],end:true};
N['dj.drink']={lines:[T('He gets the camera up. The flash goes off in your face. Then you\'re on him.'),
  T('Hungry, frightened, brave blood. It tastes like somebody who was going to do something.',{fx:['flash','sfx:drink'],do:(S,G)=>{S.flags.djDone='dead';S.flags.marekDead=1;G.feed(4,'choleric','Marek Sowa',{kind:'mortal',kill:true});G.task('s_radio','done');G.heat(1);G.comp(-2,'Nightjar');}}),
  L('stagecraft','The camera\'s still recording. Take the card. Take it.',{do:(S,G)=>{}})],end:true};

/* =====================================================================
   NIGHT 5 · SEVEN CANDLES · the vigil on Ferrier Lane
   ===================================================================== */
const vigilOn=S=>S.night===5&&S.tasks.s_vigil==='active'&&S.time>=90&&S.time<235&&!S.flags.vigilDone;
Camp.tickHooks.push((S,G)=>{if(S.night===5&&S.time>=20&&G.once('vigilText')&&(S.flags.met404||S.flags.marekKnows||S.flags.okaforPapers||S.flags.daniTold)){
  G.text(S.flags.met404&&!S.flags.daniLie?'Mrs. Okafor':'Tariq',S.flags.marekKnows&&!S.flags.marekDead?'They read the seven names on the radio last night. People are bringing candles to Ferrier Lane at half past ten. Come if you can. — 404':'Candles for the seven on Ferrier Lane tonight, half past ten until late. You don\'t have to come. I\'d like you to.');
  G.task('s_vigil');S.quests.note_s_vigil='A vigil for the seven missing, Ferrier Lane, from 10:30 PM until just before the Tribunal.';}});
pushPop('alley',(S,G)=>{if(!vigilOn(S))return;
  if(S.flags.met404)G.addActor('okafor',X.okafor.spec,{x:7.4,z:1.2,ry:-0.3,breathes:true,pose:'hold'});
  G.addActor('vtariq',NL.CHARS.tariq.spec,{x:8.3,z:1.6,ry:-0.9,breathes:true,pose:'hold'});
  if(S.flags.djDone&&S.flags.djDone!=='dead'&&S.flags.djDone!=='fogged')G.addActor('marek',X.marek.spec,{x:6.6,z:1.7,ry:0.4,breathes:true,pose:'arms'});
  if(!S.flags.harrowDead)G.addActor('harrow',NL.CHARS.harrow.spec,{x:4.6,z:1.3,ry:0.9,breathes:true,pose:'hold'});});
pushNpc('alley',(S,G)=>vigilOn(S)?[G.actor('okafor')?{id:'okafor',actor:'okafor',label:'Mrs. Okafor'}:null,G.actor('vtariq')?{id:'vtariq',actor:'vtariq',label:'Tariq'}:null,G.actor('marek')?{id:'marek',actor:'marek',label:'Marek'}:null,G.actor('harrow')?{id:'harrow',actor:'harrow',label:'Harrow'}:null].filter(Boolean):null);
pushEnter('alley',async(S,G)=>{if(vigilOn(S)&&G.once('vigilIn'))await G.talk('vg.0');});
const vigilUse=id=>{const prev=H.use[id];H.use[id]=async(S,G)=>{if(vigilOn(S)&&S.room==='alley')return G.talk(id==='harrow'?'vg.harrow':'vg.hub');return prev?prev(S,G):false;};};
['okafor','vtariq','marek','harrow'].forEach(vigilUse);
N['vg.0']={enter:(S,G)=>{G.focus(['you','vtariq'],.9);},lines:[
  T('Ferrier Lane, under the drizzle. Thirty people, maybe forty, holding candles in jam jars and paper cups along the wall where the MISSING posters are. Somebody\'s brought a thermos of tea. Somebody\'s brought a dog.'),
  T(S=>S.flags.marekKnows&&!S.flags.marekDead?'They heard the names on 88.1 last night. Some of them are wearing the badge of a radio station that doesn\'t exist.':'Word went round the Ward the old way: a payphone, a launderette, a woman in 404 who wouldn\'t stop asking.'),
  L('okafor','Dani Okafor. Peter Sowa. Luis Ferreira. Grace Mbeki. Tom Lund. Ahmed Riaz. And one more whose name we never learned. Number eight.',{if:S=>S.flags.met404}),
  L('tariq','Seven names. And somebody always has to say "and one more". Every time.',{if:S=>!S.flags.met404}),
  L('nostalgia','Number eight. Bitten nails. Nervous laugh. WITHDRAWN · RECRUITED BY SUBJECT V.',{if:S=>S.flags.frag_chart}),
  T('At the back of the crowd, holding a candle like everyone else, in a good raincoat: Special Agent Thomas Harrow.',{if:S=>!S.flags.harrowDead}),
  L('pulse','His heart rate\'s sixty-two. He\'s *calm*. He came to the vigil for the people he killed and he\'s calm.',{if:S=>!S.flags.harrowDead,pass:4})],next:'vg.hub'};
N['vg.hub']={opts:[
  O('Light a candle. Say nothing.','vg.candle',{once:true}),
  O('Stand with Mrs. Okafor.','vg.okafor',{once:true,if:S=>S.flags.met404}),
  O('Talk to Marek.','vg.marek',{once:true,if:S=>!!G.actor('marek')}),
  O('Walk over to Harrow.','vg.harrow',{if:S=>!!G.actor('harrow')&&!S.flags.vigilHarrow}),
  O('Leave them to it.',null,{end:true,leave:true})]};
const vigilDone=(S,G)=>{if(!S.flags.vigilDone){S.flags.vigilDone=1;G.task('s_vigil','done');G.xp(40,'Seven Candles');}};
N['vg.candle']={lines:[T('Somebody hands you a jam jar. Tariq lights it off his own. You stand in the drizzle with forty living people and, for ten whole minutes, nobody needs anything from you.',{do:(S,G)=>{G.comp(3,'Seven Candles');G.tick(10);vigilDone(S,G);}}),
  L('tenant','...I had forgotten this. That they do this. That they keep doing this.')],next:'vg.hub'};
N['vg.okafor']={lines:[L('okafor',S=>S.flags.daniTold?'You came. Of course you came. You\'re the one who told me.':'You came. People don\'t come.'),
  L('okafor','Whatever you are, whatever you\'re going to go and do tonight. Do it for them a little bit. Not all. A little.',{do:(S,G)=>{G.promise('okafor7','Do it for the seven, a little');G.rel('okafor',1);vigilDone(S,G);}})],next:'vg.hub'};
N['vg.marek']={lines:[L('marek',S=>S.flags.djDone==='guarded'?'My bodyguard! Everyone, this is my bodyguard. Don\'t ask.':'Forty people. Forty! I\'ve had six listeners for two years and one was my mom.'),
  L('marek','After tonight I\'m going to stop. Pete wouldn\'t want me on a roof forever.',{do:(S,G)=>{G.rel('marek',1);vigilDone(S,G);}})],next:'vg.hub'};
N['vg.harrow']={enter:(S,G)=>{G.focus(['you','harrow'],.8);G.look('harrow','you');},lines:[
  L('harrow','Subject Eight. Or do you prefer the name on your library card? I have that too.'),
  L('harrow','Don\'t look at me like that. I\'m here because I\'m sorry. I am. Seven American citizens. That weighs on me. It\'s supposed to.'),
  L('harrow','But do the arithmetic. There are four hundred of *you* in this city, and you eat us. Give me a daywalker, one, and I can make a thousand. Soldiers who don\'t burn. Then nobody\'s brother goes missing again.'),
  L('harrow','So here\'s an offer, one time, because you were the only one who ever lived. Walk out of tonight under my umbrella. Whatever happens on Platform 0 happens to them, not you.')],
  opts:[C('velvet',10,'Turn to the vigil. "This is the man who took them. Ask him about St. Jude\'s basement."','vg.shame','vg.shameBad',{id:'vg_vel',mod:S=>(S.flags.daniTold?2:0)+(S.flags.marekKnows&&!S.flags.marekDead?2:0)+(S.flags.okaforPapers?1:0)+(S.flags.millerAlly?1:0)}),
    O('"Your umbrella. Deal."','vg.deal'),
    O('"Get out of my Ward."','vg.out'),
    O('Walk away and let him hold his candle.','vg.leave')]};
N['vg.shame']={lines:[T('You don\'t raise your voice. You just say his name and the word *basement* and the word *seven*, and forty people turn round.'),
  T('Nobody touches him. Mrs. Okafor walks up to him and blows his candle out, very gently, the way you\'d blow out a child\'s. Then everybody else does it. One by one. Forty little breaths.',{do:(S,G)=>{S.flags.harrowShamed=1;S.flags.vigilHarrow='shamed';G.xp(40,'The vigil');vigilDone(S,G);}}),
  T('Harrow walks back to his van in the dark with an unlit candle in his hand. His men watch him come. Some of them heard.'),
  L('web','His own people heard it. Tonight, when he gives the order, some of them are going to hesitate.')],cs:async(G,S)=>{G.dlgHide();G.walk('harrow',0.6,2.6);await G.wait(1.8);G.removeActor('harrow');},next:'vg.hub'};
N['vg.shameBad']={lines:[L('harrow','(to the crowd, warmly) Federal Health. We\'re investigating a blood-borne illness at St. Jude\'s. This person is unwell, I\'m afraid. Please don\'t let them near you.'),
  T('Forty faces, uncertain. A few people step back from you. Only a few.',{do:(S,G)=>{S.flags.vigilHarrow='failed';G.comp(-1,'He\'s good at this');vigilDone(S,G);}})],next:'vg.hub'};
N['vg.deal']={lines:[L('harrow','Sensible. I\'ll have a man at the top of the Platform 0 stairs. When the lights come on, walk towards him.'),
  L('tenant','He will put you in a basement for the rest of your very long life. You know that. You *know* that.'),
  T('He presses something into your hand: a laminated card with a blue band. LANTERN · ESCORT · 8.',{do:(S,G)=>{S.flags.harrowDeal=1;S.flags.vigilHarrow='deal';G.comp(-2,'Under his umbrella');vigilDone(S,G);}})],cs:async(G,S)=>{G.dlgHide();G.walk('harrow',0.6,2.6);await G.wait(1.8);G.removeActor('harrow');},next:'vg.hub'};
N['vg.out']={lines:[L('harrow','Your Ward. Listen to you. See you at one.',{do:(S,G)=>{S.flags.vigilHarrow='out';vigilDone(S,G);}})],cs:async(G,S)=>{G.dlgHide();G.walk('harrow',0.6,2.6);await G.wait(1.8);G.removeActor('harrow');},next:'vg.hub'};
N['vg.leave']={lines:[T('He stays until the end. He sings the hymn. He knows all the words.',{do:(S,G)=>{S.flags.vigilHarrow='left';vigilDone(S,G);}})],next:'vg.hub'};

/* =====================================================================
   THE TRIBUNAL and the lamps: new testimony, new ways out
   ===================================================================== */
if(ENC.tribunal){
  const st0=ENC.tribunal.start;ENC.tribunal.start=function(S,G){const r=st0.call(this,S,G);if(S.flags.harrowShamed)r.threat=Math.max(0,r.threat-1);return r;};
  const mv0=ENC.tribunal.moves;ENC.tribunal.moves=function(st,S,G){const M=mv0.call(this,st,S,G);
    M.forEach(m=>{if(m.once==='tb_man'){const ok=m.ok;m.ok=(st,S,G)=>{S.flags.tbMan=1;return ok(st,S,G);};}});
    if(S.flags.margoTestify&&!S.flags.margoDead)M.push({t:'"Margo Kowalski. Tell them who paid you to break the freezer door."',once:'tb_margo',ok:(st,S)=>{st.prog+=2;if(S.flags.margoNamedSev&&!S.flags.side_court)st.prog+=1;return [
      T('She comes out of the crowd in her butcher\'s apron, a big grey woman among three hundred dead aristocrats, and stands in the chalk circle with her hands shaking.'),
      L('margo','A note in copperplate and five thousand dollars. "Make sure the freezer holds whatever goes in." I took the release off the door. She paid me. *Her*.'),
      L('severine','A *butcher*. You let a butcher speak in this court.',{if:S=>!S.flags.sevDead}),
      L('magistrate','I let anyone speak who has something true to say, Séverine. It is a novelty for this court. Sit down.')];}});
    if(S.flags.uncleLeo&&S.flags.pruittConfessed&&!S.flags.pruittDead&&S.flags.pruittInside)M.push({t:'"Precinct 9 lost seven missing-persons reports this summer. For Harrow\'s money. An officer told me so."',once:'tb_ken',ok:st=>{st.prog+=1;return [L('magistrate','The mortals\' own police, bought. By the same man who lit our grates. I begin to see the shape of it.')];}});
    if(S.flags.vigilHarrow==='shamed')M.push({t:'"Forty mortals on Ferrier Lane blew out Harrow\'s candle tonight. Even the living know who did this."',once:'tb_vigil',ok:st=>{st.prog+=1;return [T('A few of the older Kindred laugh, softly, surprised.')];}});
    return M;};}
if(N['pm.0']){N['pm.0'].lines.push(T('At the third van, a Precinct 9 uniform you know. Pruitt. He doesn\'t look at you. He taps the radio on his shoulder, twice.',{if:S=>S.flags.pruittInside&&!S.flags.pruittDead}));
  N['pm.0'].lines.push(T('Harrow\'s men at the vans won\'t meet each other\'s eyes. One of them is still holding an unlit candle.',{if:S=>S.flags.harrowShamed}));}
if(N['lamps.fire']&&N['lamps.fire'].opts){
  N['lamps.fire'].opts.unshift(O('Pruitt\'s voice in your burner, tinny: "Grate nine. It\'s dead, it\'s dark, GO."','lamps.ken',{if:S=>S.flags.pruittInside&&!S.flags.pruittDead}));
  N['lamps.fire'].opts.push(O('Walk towards the man at the top of the stairs. Harrow\'s umbrella.','lamps.deal',{if:S=>S.flags.harrowDeal}));}
N['lamps.ken']={lines:[T('Grate nine. A dark square in a floor of white fire. You go down through it into the cistern and you take as many of them with you as you can grab: a Court lady by the wrist, a Syndicate boy by his collar, and anyone who\'s close enough to follow your coat.',{fx:['flash','shake:1.2'],do:(S,G)=>{S.flags.lampsBurned=1;S.flags.massacre=1;S.flags.kenSaved=1;if(!S.flags.sevWarned)S.flags.sevDead=1;if(!S.flags.malakorWarned)S.flags.malakorDead=1;G.vitae(-1);G.xp(40,'Grate nine');}}),
  L('web','Ken Pruitt just saved a dozen vampires\' lives with a police radio, and he\'s never going to know it.')],next:'dawn.0'};
N['lamps.deal']={lines:[T('You walk through the light with your coat over your head towards a grey man holding a black umbrella at the top of the stairs. Behind you, Platform 0 screams.'),
  T('The umbrella is lined with something that drinks the glare. He walks you to the van like a valet. The door closes. It\'s very quiet in the van.',{fx:['flash'],do:(S,G)=>{S.flags.lampsBurned=1;S.flags.massacre=1;S.flags.sevDead=S.flags.sevWarned?0:1;S.flags.malakorDead=S.flags.malakorWarned?0:1;S.flags.lanternTook=1;G.comp(-3,'Subject Eight');}}),
  L('harrow','You\'ll be comfortable. You\'ll be *important*. Think of it as a career.')],next:'end.subject'};
NL.ENDINGS.subject={t:'Subject Eight',k:'Ending · Under the umbrella',epi:S=>['You spend the rest of the decade in a white room in Virginia with a window that shows a sunrise every morning on a screen. They take a little blood every Tuesday.',
  'In 2031, Project LANTERN graduates its first daywalker. She has your eyes. She doesn\'t know your name.',
  S.flags.knowName?'Sometimes they let you write letters. You write to your sister. You never find out if they\'re sent.':'Sometimes, at four in the morning, the Tenant says, very quietly, "I told you so."']};
N['end.subject']={lines:[T('The van drives all night and into a morning you watch through tinted glass that doesn\'t let the sun in. It\'s very beautiful. It\'s the first one in a week.')],next:'end.show.subject'};
N['end.show.subject']={cs:async(G,S)=>{await NL.Act.showEnding('subject');},end:true};

/* ---------- epilogue fates ---------- */
(NL.Act.extraFates=NL.Act.extraFates||[]).push(S=>{const f=S.flags;const out=[];
  if(S.tasks.s_margo||f.margoDead)out.push(['Margo Kowalski',f.margoOut==='testify'?(f.verdict==='win'?'Testified. Sold the shop. Opened a vegetarian café in Duluth, out of spite.':'Testified. The Court never forgave her. Gideon hid her for a year.'):f.margoOut==='fled'?'Duluth. Her sister still hates her. Lets her stay.':f.margoOut==='sold'?'Séverine\'s people collected her. Nobody saw her again.':f.margoDead?'You drank her in the back of a pawnshop.':'Still hiding in the coffin showroom.']);
  if(S.tasks.s_uncle||f.pruittDead)out.push(['Ken Pruitt',f.pruittDead?'Found dead in a stairwell during the curfew. "Heart attack."':f.kenSaved?'Resigned from Precinct 9 the following week. Never says why.':f.uncleLeo==='drive'?'Drove his nephew to the coast. Comes to every Tuesday open mic now.':f.uncleWiped?'Has no nephew. Feels, sometimes, as if he\'s lost something.':'Still on the beat. Stopped taking envelopes.']);
  if(S.tasks.s_radio||f.marekDead)out.push(['Marek "Nightjar" Sowa',f.marekDead?'His last broadcast ends mid-sentence.':f.djDone==='fogged'?'Doesn\'t remember having a brother. Sleeps well.':f.djDone==='silenced'?'Never broadcast again.':'Off the roof. Hosts a late show on real radio now. Reads seven names every July.']);
  if(f.harrowDeal&&f.lanternTook)out.push(['LANTERN','Has a vial of your blood in a freezer in Virginia. Think of that, now and then.']);
  if(f.vigilDone)out.push(['Ferrier Lane','There are seven candles on the wall by the Lucky Mart every Friday. Tariq lights them.']);
  return out;});
})();
