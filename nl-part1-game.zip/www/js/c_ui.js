'use strict';
/* THE NEW LORD — dressing the menus: a painted-night title screen, framed panels, voice cards.
   Drop-in art (all optional): NL.ART.title / .panel / .gameover / .dawn → image URLs. If present they replace the drawn versions. */
(function(){
const G=NL.G,A=NL.Audio,$=s=>document.querySelector(s);
NL.ART=NL.ART||{};
/* deterministic noise so the skyline is the same every time */
let seed=7;const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646;};

function skylineSVG(){seed=7;const W=1600,H=900;let o='';
  const bld=(x0,x1,base,hmin,hmax,fill,win,winP)=>{let x=x0,s='';while(x<x1){const w=40+rnd()*90,h=hmin+rnd()*(hmax-hmin),y=base-h;
      s+=`<rect x="${x.toFixed(0)}" y="${y.toFixed(0)}" width="${w.toFixed(0)}" height="${(h+4).toFixed(0)}" fill="${fill}"/>`;
      if(rnd()<.35)s+=`<rect x="${(x+w*.3).toFixed(0)}" y="${(y-14-rnd()*20).toFixed(0)}" width="${(w*.18).toFixed(0)}" height="40" fill="${fill}"/>`;
      if(win)for(let wy=y+12;wy<base-14;wy+=18)for(let wx=x+8;wx<x+w-10;wx+=14){if(rnd()<winP){const warm=rnd()<.8;const fl=rnd()<.08;
        s+=`<rect class="${fl?'wfl':''}" x="${wx.toFixed(0)}" y="${wy.toFixed(0)}" width="6" height="9" fill="${warm?'#f2b25c':'#9fc7e8'}" opacity="${(.35+rnd()*.55).toFixed(2)}"${fl?` style="animation-delay:${(rnd()*6).toFixed(1)}s"`:''}/>`;}}
      x+=w+2+rnd()*6;}return s;};
  o+=`<defs>
    <linearGradient id="tsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#07060c"/><stop offset=".45" stop-color="#151025"/><stop offset=".72" stop-color="#3a1424"/><stop offset="1" stop-color="#5a1a22"/></linearGradient>
    <radialGradient id="tmoon" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#f6efe0"/><stop offset=".7" stop-color="#e2d6bd"/><stop offset="1" stop-color="#c9b994"/></radialGradient>
    <radialGradient id="thalo" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#e8dcc0" stop-opacity=".45"/><stop offset="1" stop-color="#e8dcc0" stop-opacity="0"/></radialGradient>
    <radialGradient id="tlamp" cx=".5" cy="0" r="1"><stop offset="0" stop-color="#ffcf8a" stop-opacity=".55"/><stop offset="1" stop-color="#ffcf8a" stop-opacity="0"/></radialGradient>
    <linearGradient id="tstreet" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#140f16"/><stop offset="1" stop-color="#060508"/></linearGradient>
    <filter id="tblur" x="-20%" y="-50%" width="140%" height="200%"><feGaussianBlur stdDeviation="14"/></filter>
    <filter id="tglow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
  </defs>`;
  o+=`<rect width="${W}" height="${H}" fill="url(#tsky)"/>`;
  for(let i=0;i<70;i++)o+=`<circle cx="${(rnd()*W).toFixed(0)}" cy="${(rnd()*H*.45).toFixed(0)}" r="${(rnd()*1.2+.3).toFixed(1)}" fill="#fff" opacity="${(rnd()*.5+.1).toFixed(2)}"/>`;
  o+=`<g class="tl tl0"><circle cx="1060" cy="230" r="230" fill="url(#thalo)"/><circle cx="1060" cy="230" r="92" fill="url(#tmoon)"/>
     <circle cx="1032" cy="212" r="14" fill="#cdbf9e" opacity=".5"/><circle cx="1090" cy="262" r="9" fill="#cdbf9e" opacity=".45"/><circle cx="1070" cy="190" r="6" fill="#cdbf9e" opacity=".4"/></g>`;
  o+=`<g class="tl tcloud" filter="url(#tblur)" opacity=".85"><ellipse cx="820" cy="380" rx="260" ry="30" fill="#1b1424"/><ellipse cx="1420" cy="120" rx="220" ry="24" fill="#1d1526"/><ellipse cx="400" cy="200" rx="300" ry="30" fill="#1a1322"/></g>`;
  // the Heights: hill, the windowless house, cemetery crosses
  o+=`<g class="tl tl1"><path d="M0 610 C160 520 300 470 470 500 C560 515 620 560 700 610 Z" fill="#120d18"/>
     <path d="M250 470 h120 v-40 l-60 -42 l-60 42 z" fill="#0e0a13"/><rect x="292" y="400" width="10" height="34" fill="#0e0a13"/>
     ${[150,180,205,420,450].map(x=>`<path d="M${x} ${545-((x*7)%30)} v-22 M${x-7} ${533-((x*7)%30)} h14" stroke="#0e0a13" stroke-width="4"/>`).join('')}</g>`;
  // far city + the church spire of Club Reliquary + dock cranes
  o+=`<g class="tl tl2">${bld(560,1600,640,90,230,'#1a1220',true,.10)}
     <path d="M1010 640 V470 l18 -30 l18 30 V640 Z M1028 440 V330 l6 -6 l6 6 V440" fill="#1a1220"/><circle cx="1028" cy="480" r="10" fill="#d23246" opacity=".55"/>
     <path d="M1420 640 V380 M1420 390 H1560 M1540 390 V430 M1420 420 L1500 390" stroke="#1a1220" stroke-width="7" fill="none"/>
     <path d="M1300 640 V420 M1300 430 H1400 M1385 430 V470" stroke="#1a1220" stroke-width="6" fill="none"/></g>`;
  // the flyover
  o+=`<g class="tl tl3"><rect x="0" y="600" width="${W}" height="22" fill="#0f0b12"/>${Array.from({length:9},(_,i)=>`<rect x="${60+i*190}" y="620" width="18" height="120" fill="#0f0b12"/>`).join('')}
     ${Array.from({length:22},(_,i)=>`<circle cx="${30+i*76}" cy="598" r="2" fill="#ffb86b" opacity=".7"/>`).join('')}</g>`;
  // near buildings, lit
  o+=`<g class="tl tl4">${bld(-20,560,760,170,330,'#0b080d',true,.16)}${bld(1180,1640,760,160,300,'#0b080d',true,.14)}</g>`;
  // street, wet
  o+=`<g class="tl tl5"><rect x="0" y="740" width="${W}" height="${H-740}" fill="url(#tstreet)"/>
     <rect x="1140" y="760" width="14" height="130" fill="#e2d6bd" opacity=".07"/>
     <rect x="760" y="760" width="230" height="140" fill="#d23246" opacity=".08" filter="url(#tblur)"/>
     ${Array.from({length:40},()=>{const x=rnd()*W;return `<rect x="${x.toFixed(0)}" y="${(752+rnd()*40).toFixed(0)}" width="${(1+rnd()*2).toFixed(1)}" height="${(20+rnd()*80).toFixed(0)}" fill="#f2b25c" opacity="${(rnd()*.12+.03).toFixed(2)}"/>`;}).join('')}</g>`;
  // Kowalski's shopfront: neon, lit window, the alley
  o+=`<g class="tl tl6"><g transform="translate(130 0)"><rect x="700" y="560" width="330" height="200" fill="#0d0a10"/><rect x="730" y="640" width="160" height="90" fill="#3d2414" opacity=".85"/><rect x="730" y="640" width="160" height="90" fill="#f2b25c" opacity=".14"/>
     <rect x="920" y="650" width="70" height="110" fill="#070508"/>
     <g class="neon" filter="url(#tglow)"><text x="865" y="612" text-anchor="middle" font-family="Barlow Condensed,Arial Narrow,sans-serif" font-weight="700" font-size="34" letter-spacing="4" fill="#ff4a5e">KOWALSKI'S</text>
     <text x="865" y="636" text-anchor="middle" font-family="Barlow Condensed,Arial Narrow,sans-serif" font-weight="600" font-size="15" letter-spacing="6" fill="#ff8a96" class="nflk">24 HR MEATS</text></g></g></g>`;
  // the lamppost and the figure in the coat
  o+=`<g class="tl tl7"><g transform="translate(200 0)"><path d="M560 900 V560 q0 -26 30 -26 h40" stroke="#0a080b" stroke-width="10" fill="none"/><path d="M612 530 h46 l-8 14 h-30z" fill="#0a080b"/>
     <path d="M612 544 L520 900 H760 L656 544 Z" fill="url(#tlamp)" class="lampc"/>
     <g class="who"><path d="M600 900 L606 770 Q598 712 612 690 Q616 664 632 660 Q624 640 634 626 Q646 614 658 626 Q666 640 658 660 Q676 664 682 690 Q694 712 690 770 L700 900 Z" fill="#050406"/>
     <path d="M634 626 Q646 614 658 626 Q666 640 658 660" stroke="#d23246" stroke-width="2" fill="none" opacity=".55"/>
     <path d="M682 690 Q694 712 690 770 L700 900" stroke="#ffcf8a" stroke-width="2" fill="none" opacity=".35"/></g></g></g>`;
  return `<svg class="tsvg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMax slice" aria-hidden="true">${o}</svg>`;}

function buildTitle(){const t=$('#title');if(!t||t.dataset.v==='2')return;t.dataset.v='2';
  const cont=$('#bCont'),begin=$('#bBegin');
  t.innerHTML=`<div class="tbg${NL.ART.title?' painted':''}">${NL.ART.title?`<picture>${NL.ART.titleTall?`<source media="(orientation:portrait) and (max-width:900px)" srcset="${NL.ART.titleTall}">`:''}<img class="tart" src="${NL.ART.title}" alt=""></picture>`:skylineSVG()}</div><div class="train"></div><div class="tfog"></div><div class="tvig"></div>
    <div class="tmenu"><div class="k">A Port Vellum Story · Five Nights</div><h1>The New Lord</h1><div class="trule"><i></i><b>◆</b><i></i></div>
      <p class="sub">You wake in a butcher's freezer beside the ashes of the Sheriff, with his blood in your veins and sixteen voices in your head.</p>
      <nav class="tbtns"></nav>
      <p class="foot">Headphones recommended · Tap the floor to walk · Tap a marker to interact</p></div>`;
  const nav=t.querySelector('.tbtns');
  cont.className='tbtn primary';cont.innerHTML='<span>Continue</span><small id="tContMeta"></small>';
  begin.className='tbtn';begin.innerHTML='<span>New Game</span>';
  const load=document.createElement('button');load.className='tbtn';load.id='tLoad';load.innerHTML='<span>Load Game</span>';load.onclick=()=>{A.init&&A.init();A.sfx('click');NL.Saves.open('load');};
  const set=document.createElement('button');set.className='tbtn';set.id='tSet';set.innerHTML='<span>Settings</span>';set.onclick=()=>{A.init&&A.init();A.sfx('click');document.body.classList.add('overTitle');G.openPanel('settings');};
  nav.append(cont,begin,load,set);
  // parallax
  const layers=()=>t.querySelectorAll('.tl');let tx=0,ty=0,cx=0,cy=0;
  const mv=(x,y)=>{tx=x;ty=y;};
  t.addEventListener('pointermove',e=>{const r=t.getBoundingClientRect();mv((e.clientX-r.left)/r.width-.5,(e.clientY-r.top)/r.height-.5);});
  window.addEventListener('deviceorientation',e=>{if(e.gamma==null)return;mv(Math.max(-1,Math.min(1,e.gamma/30))*.5,Math.max(-1,Math.min(1,(e.beta-45)/30))*.5);});
  const L=Array.from(layers());if(!L.length){const pic=t.querySelector('.tart');if(pic)L.push(pic);}(function loop(){if(!t.hidden){cx+=(tx-cx)*.05;cy+=(ty-cy)*.05;L.forEach((l,i)=>{const d=(i+1)*4;l.style.transform=`translate(${(-cx*d).toFixed(1)}px,${(-cy*d*.5).toFixed(1)}px)`;});}requestAnimationFrame(loop);})();
}
function contMeta(){const el=$('#tContMeta');if(!el)return;let d=null;try{d=JSON.parse(localStorage.getItem('newlord.campaign.v1')||'null');}catch(e){}
  if(!d){el.textContent='';return;}const c=d.clan&&NL.CLANS[d.clan];const m=(d.time||0)+21*60;const clk=String(Math.floor(m/60)%24).padStart(2,'0')+':'+String(m%60).padStart(2,'0');
  el.textContent=`Night ${d.night||1} · ${clk}${c?' · '+c.name:''}`;}
buildTitle();
/* browsers only allow sound after a tap: the first touch on the title screen starts its music */
(function(){const go=()=>{const t=$('#title');if(t&&!t.hidden&&A.init){A.init();A.curMood=null;A.music('title');}document.removeEventListener('pointerdown',go,true);};document.addEventListener('pointerdown',go,true);})();
const _st=G.showTitle;G.showTitle=function(){_st.apply(this,arguments);buildTitle();contMeta();};
// settings over the title: lift the panel above it, then drop back
const _cp=G.closePanel;G.closePanel=function(){document.body.classList.remove('overTitle');return _cp.apply(this,arguments);};
document.addEventListener('click',e=>{if(e.target.closest('#pclose'))document.body.classList.remove('overTitle');},true);
setTimeout(contMeta,0);

/* panels and screens: optional painted backdrops */
function artVars(){const r=document.documentElement.style;['panel','gameover','dawn'].forEach(k=>{if(NL.ART[k])r.setProperty('--art-'+k,`url("${NL.ART[k]}")`);});}
artVars();

/* tab icons */
const TI={char:'<circle cx="12" cy="7.5" r="3.5"/><path d="M5 21c0-4.5 3-7.5 7-7.5s7 3 7 7.5"/>',inv:'<path d="M5 8h14l-1 13H6z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',thoughts:'<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',journal:'<path d="M6 3h11a1 1 0 0 1 1 1v17H7a2 2 0 0 1-2-2V4a1 1 0 0 1 1-1z"/><path d="M5 18a2 2 0 0 1 2-2h11M9 7h6M9 10h4"/>',settings:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>'};
document.querySelectorAll('#ptabs button').forEach(b=>{const ic=TI[b.dataset.t];if(ic&&!b.querySelector('svg'))b.insertAdjacentHTML('afterbegin',`<svg class="tic" viewBox="0 0 24 24">${ic}</svg>`);});
/* save + load from the Settings tab */
const _rp=G.openPanel;
document.addEventListener('click',e=>{const b=e.target.closest('#bSaveGame,#bLoadGame');if(!b)return;e.preventDefault();NL.Saves.open(b.id==='bSaveGame'?'save':'load');});
const mo=new MutationObserver(()=>{const acts=document.querySelector('#panelBody .set .acts');if(acts&&!acts.querySelector('#bSaveGame')){acts.insertAdjacentHTML('afterbegin','<button id="bSaveGame">Save game</button><button id="bLoadGame">Load game</button>');}});
const pb=$('#panelBody');if(pb)mo.observe(pb,{childList:true});
})();
