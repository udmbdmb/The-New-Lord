'use strict';
/* THE NEW LORD — game data */
(function(){
const NL=window.NL;

const ATTRS={
  sanguine:{name:'Sanguine',tag:'The Beast · Predation · Blood-craft',color:'#d23246',blurb:'How loud the parasite inside you speaks.'},
  masquerade:{name:'Masquerade',tag:'The Mask · Humanity · Manipulation',color:'#e2c27e',blurb:'Your fading ability to pass as a soul-bearing human.'},
  nocturne:{name:'Nocturne',tag:'Paranoia · Streetwise · Lore',color:'#a493f5',blurb:'How well you navigate the secret society of the undead.'},
  cadaver:{name:'Cadaver',tag:'The Dead Body · Logic · Occult',color:'#7fc3b1',blurb:'Your cold detachment as an animate corpse.'}
};
const SKILLS={
  parasite:{name:'Parasite',attr:'sanguine',d:'Sensory feeding. Hears heartbeats through walls, smells sickness, tastes what\'s in a bloodstream.',hi:'Too high: you can\'t hear what mortals say over their carotid arteries.'},
  apex:{name:'Apex',attr:'sanguine',d:'Dominance and intimidation. Your inner alpha predator. Refuses to bow.',hi:'Too high: picks suicidal fights with elders.'},
  frenzy:{name:'Frenzy',attr:'sanguine',d:'Raw violence and impulse. The red mist. Doors off hinges, tables flipped.',hi:'Too high: solves social puzzles with teeth.'},
  osmosis:{name:'Osmosis',attr:'sanguine',d:'Blood resonance. Drink or touch, and the victim\'s memories bleed into you.',hi:'Too high: you forget which memories are yours.'},
  nostalgia:{name:'Nostalgia',attr:'masquerade',d:'Mortal memory. Sunlight, diner coffee, small talk about the weather.',hi:'Too high: you mourn things that are standing right in front of you.'},
  pulse:{name:'Pulse-Check',attr:'masquerade',d:'Empathy and guilt. Reads body language and micro-expressions.',hi:'Too high: feeding on innocents wrecks your Composure.'},
  velvet:{name:'Velvet Tongue',attr:'masquerade',d:'Deception and seduction. Smooth lies, flattery, the Gothic tempter.',hi:'Too high: you lie when the truth would have worked.'},
  stagecraft:{name:'Stagecraft',attr:'masquerade',d:'Bluffing life. Blink. Fake a breath in cold air. Warm your hands.',hi:'Too high: you overact being alive.'},
  echo:{name:'Echolocation',attr:'nocturne',d:'Spatial awareness. Hidden cameras, rooftop snipers, concealed stakes, secret doors.',hi:'Too high: every shadow has a sniper in it.'},
  pedigree:{name:'Pedigree',attr:'nocturne',d:'Court etiquette and history. Every clan curse, blood-feud and proper title.',hi:'Too high: an insufferable snob in your head.'},
  web:{name:'Web-Spinner',attr:'nocturne',d:'Conspiracy and deduction. Connects clues, motives and political strings.',hi:'Too high: the convenience-store clerk is a Vatican assassin.'},
  gutter:{name:'Gutter-Sense',attr:'nocturne',d:'Underworld and neon. Gangs, night shifts, blood dealers, clanless strays.',hi:'Too high: you can\'t walk past a deal without taking a cut.'},
  rigor:{name:'Rigor Mortis',attr:'cadaver',d:'Endurance and stillness. Tank bullets, stand still for three hours, play dead.',hi:'Too high: you forget to move for days.'},
  autopsy:{name:'Autopsy',attr:'cadaver',d:'Cold forensics. Wounds, decay, crime scenes, with zero emotional investment.',hi:'Too high: you see people as future crime scenes.'},
  abattoir:{name:'Abattoir',attr:'cadaver',d:'Anatomical savvy. Nerves, bones and surgical precision.',hi:'Too high: you start pricing people by the pound.'},
  sundial:{name:'Sundial',attr:'cadaver',d:'Circadian anxiety. Counts the minutes until dawn and panics at fire and UV.',hi:'Too high: you can hear the sun coming.'}
};
const SKILL_ORDER={sanguine:['parasite','apex','frenzy','osmosis'],masquerade:['nostalgia','pulse','velvet','stagecraft'],nocturne:['echo','pedigree','web','gutter'],cadaver:['rigor','autopsy','abattoir','sundial']};
const GLYPH={
  parasite:'<path d="M24 6c6 9 11 15 11 21a11 11 0 0 1-22 0c0-6 5-12 11-21z"/><path d="M15 29h5l2-5 4 9 2-4h5"/>',
  apex:'<path d="M9 34l3-18 7 8 5-12 5 12 7-8 3 18z"/><path d="M18 34l2 6 2-6M26 34l2 6 2-6"/>',
  frenzy:'<path d="M12 8l8 30M21 6l6 34M31 8l5 28"/>',
  osmosis:'<path d="M24 6c6 9 11 15 11 21a11 11 0 0 1-22 0c0-6 5-12 11-21z"/><circle cx="24" cy="28" r="3"/><circle cx="24" cy="28" r="7"/>',
  nostalgia:'<path d="M12 22h20v8a8 8 0 0 1-8 8h-4a8 8 0 0 1-8-8z"/><path d="M32 24h3a4 4 0 0 1 0 8h-3"/><path d="M18 17c-2-3 2-4 0-8M24 17c-2-3 2-4 0-8"/>',
  pulse:'<path d="M5 26h9l3-8 5 16 4-12 3 4h14"/>',
  velvet:'<path d="M8 24c5-6 10-7 16-3 6-4 11-3 16 3-6 7-11 9-16 9s-10-2-16-9z"/><path d="M8 24h32"/>',
  stagecraft:'<path d="M10 10h28v12a14 14 0 0 1-28 0z"/><path d="M16 18h5M27 18h5"/><path d="M17 29c4 4 10 4 14 0"/>',
  echo:'<path d="M8 24c5-7 10-10 16-10s11 3 16 10c-5 7-10 10-16 10S13 31 8 24z"/><circle cx="24" cy="24" r="4"/><path d="M4 12l4 4M44 12l-4 4M24 4v5"/>',
  pedigree:'<path d="M24 6l14 5v11c0 9-6 15-14 20-8-5-14-11-14-20V11z"/><path d="M24 14v16M17 20h14"/>',
  web:'<path d="M24 4v40M4 24h40M10 10l28 28M38 10L10 38"/><path d="M24 12l9 3 3 9-3 9-9 3-9-3-3-9 3-9z"/>',
  gutter:'<circle cx="24" cy="24" r="17"/><path d="M14 17h20M11 24h26M14 31h20"/>',
  rigor:'<path d="M18 4h12l6 10-6 30H18l-6-30z"/><path d="M24 14v12M19 19h10"/>',
  autopsy:'<path d="M8 40L34 14l5 2-27 27z"/><path d="M34 14l6-8"/>',
  abattoir:'<path d="M8 12h24v16H14z"/><circle cx="27" cy="17" r="2"/><path d="M32 22l10 16-4 3-10-14"/>',
  sundial:'<path d="M6 34a18 18 0 0 1 36 0z"/><path d="M24 34l-10-14M24 34V20M24 34l10-14"/><path d="M4 38h40"/>',
  tenant:'<circle cx="24" cy="18" r="8"/><path d="M20 26l-4 16h16l-4-16"/><path d="M14 6l4 4M34 6l-4 4M24 2v4"/>'
};
const DIFF=[[6,'Trivial'],[8,'Easy'],[10,'Medium'],[12,'Challenging'],[13,'Formidable'],[14,'Legendary'],[15,'Heroic'],[16,'Godly']];
const diffName=dc=>{let n='Impossible';for(const d of DIFF){if(dc<=d[0]){n=d[1];break;}}return n;};

const CLANS={
  sovereign:{name:'The Sovereign',ep:'Old blood. Older debts.',d:'Tyrants in tailored coats. Their blood remembers kingdoms, and expects to be obeyed. Absalom Vane was one of them; now so, perhaps, are you.',
    mods:{apex:2,pedigree:2,gutter:-1},curse:'An insult to your station cannot go unanswered.',eye:[.9,.68,.22],glow:[.9,.55,.1],aura:'#d9a441',
    ab:{kneel:{n:'Kneel',c:1,d:'Speak, and a mortal obeys one command.'},crown:{n:'Crown of Thorns',c:2,d:'Your presence fills the room. Everyone in it remembers who is prey.'},ledger:{n:'Ledger of Debts',c:1,d:'Smell what a person owes, and to whom.'}}},
  glass:{name:'The Glass',ep:'Seers who see too much.',d:'Their minds are windows; most of them are cracked. They hear the thoughts people are loudest about not saying.',
    mods:{pulse:2,web:2,rigor:-1},curse:'Mirrors crack around you. Sometimes you can hear them do it.',eye:[.6,.85,1],glow:[.45,.75,1],aura:'#9fd3ff',
    ab:{coldread:{n:'Cold Reading',c:1,d:'Hear a person\'s loudest unvoiced regret.'},faultlines:{n:'Fault Lines',c:1,d:'See where a thing, or a person, will break.'},shatter:{n:'Shatter',c:2,d:'Pour someone\'s memories back into them, all at once.'}}},
  butchers:{name:'The Butchers',ep:'Surgeons of the self.',d:'They treat flesh like clay, their own included. A Butcher can close a wound with a thumb or open one with a look.',
    mods:{abattoir:2,autopsy:2,nostalgia:-1},curse:'Wounds itch until you fix them. Other people\'s, too.',eye:[.62,.06,.06],glow:[.55,.03,.03],aura:'#b23a3a',scars:true,
    ab:{carve:{n:'Carve',c:1,d:'Reshape flesh: close a wound, warm your skin, shift a face.'},bloodless:{n:'Bloodless Cut',c:1,d:'Feed without leaving a mark.'},puppet:{n:'Meat Puppet',c:2,d:'Seize a body\'s nerves for one long second.'}}},
  rot:{name:'The Rot',ep:'Kings of the sewer.',d:'Grey-skinned, patient, and very hard to kill twice. The vermin of the city count for them, and report back.',
    mods:{parasite:2,rigor:2,stagecraft:-1},curse:'Fresh flowers die in your hands. People notice.',eye:[.7,.8,.25],glow:[.55,.7,.12],aura:'#8aa63a',grey:true,
    ab:{miasma:{n:'Miasma',c:2,d:'Exhale a fog that smells like a gas leak and feels like a funeral.'},wither:{n:'Wither',c:1,d:'Age a thing a hundred years. Rust a lock, rot a hinge.'},census:{n:'Carrion Census',c:1,d:'Ask the vermin what they saw.'}}},
  wraiths:{name:'The Wraiths',ep:'Half here.',d:'Shadows that learned to walk. They do not show up in mirrors, photographs, or most people\'s memories.',
    mods:{echo:2,sundial:2,velvet:-1},curse:'No reflection. Ever.',eye:[.85,.82,1],glow:[.7,.65,1],aura:'#c9c3ff',ghost:true,ratsOk:true,
    ab:{unseen:{n:'Unseen',c:1,d:'Be ignored completely, until you speak.'},coldspot:{n:'Cold Spot',c:1,d:'Talk to the echo of someone who died nearby.'},wall:{n:'Through the Wall',c:2,d:'Pass through a thin barrier.'}}},
  stray:{name:'The Stray',ep:'Clanless and hungry.',d:'Mongrels of the night who owe nothing to anyone. No Court protects them. No Court has to.',
    mods:{gutter:2,frenzy:2,pedigree:-1},curse:'No one is coming to help you. Ever.',eye:[.85,.55,.15],glow:[.8,.45,.1],aura:'#d0915a',mismatch:[.35,.75,.35],ratsOk:true,
    ab:{mongrel:{n:'Mongrel Blood',c:1,d:'Borrow the gift of the last vampire you drank. (Crane: Kneel.)'},pack:{n:'Street Pack',c:1,d:'Whistle, and the city\'s dogs come running.'},secondwind:{n:'Second Wind',c:2,d:'Heal everything, right now.'}}},
  gilded:{name:'The Gilded',ep:'Beautiful, and they know it.',d:'Artists, seducers and patrons. Their blood is a perfume and their attention is a drug.',
    mods:{velvet:2,nostalgia:2,frenzy:-1},curse:'Ugliness physically pains you, your own included.',eye:[.65,.35,.9],glow:[.6,.3,.85],aura:'#d48cff',
    ab:{rapture:{n:'Rapture',c:1,d:'Everyone looking at you forgets to be suspicious.'},muse:{n:'Muse\'s Kiss',c:1,d:'Plant an inspired idea in a mortal\'s head.'},portrait:{n:'Portrait',c:2,d:'Borrow a face you have studied.'}}},
  choir:{name:'The Choir',ep:'Blood sings.',d:'Hymn-singing blood sorcerers who keep their rites in harmony. Every drop of blood is a note to them.',
    mods:{osmosis:2,stagecraft:2,apex:-1},curse:'You must hum, at least, every hour, or your blood curdles.',eye:[1,.25,.32],glow:[1,.15,.25],aura:'#ff5a6a',
    ab:{augury:{n:'Sanguine Augury',c:1,d:'Read the next minute in a drop of spilt blood.'},ward:{n:'Ward',c:1,d:'Seal a door with a sigil in your own blood.'},hymn:{n:'Hymn of Boiling',c:2,d:'Sing someone\'s blood to a simmer.'}}},
  hounds:{name:'The Hounds',ep:'Hunters of hunters.',d:'Fast, loyal, and never quite off the leash. The Court sends Hounds when it wants something found.',
    mods:{apex:2,echo:2,pulse:-1},curse:'Once you start chasing something, stopping hurts.',eye:[.95,.62,.12],glow:[.95,.5,.05],aura:'#e0802a',
    ab:{quicken:{n:'Quickening',c:2,d:'Move faster than eyes can follow.'},scent:{n:'Scent Trail',c:1,d:'Follow a blood trail across the city.'},throat:{n:'Throat',c:2,d:'One strike. That is all it takes.'}}},
  moths:{name:'The Moths',ep:'Drawn to the light.',d:'The youngest bloodline. They live in screens, feeds and neon, and they are always online.',
    mods:{web:2,echo:2,sundial:-1},curse:'Near screens you lose track of time. Badly.',eye:[.25,.95,.9],glow:[.1,.9,.85],aura:'#40e0d0',
    ab:{static:{n:'Static',c:1,d:'Kill every camera, phone and radio in the room.'},signal:{n:'Signal',c:1,d:'Listen in on the nearest phone call or radio.'},flicker:{n:'Flicker',c:2,d:'Step into a beam of light and out at its other end.'}}}
};
const CLAN_ORDER=['sovereign','glass','butchers','rot','wraiths','stray','gilded','choir','hounds','moths'];
const ABIL={};CLAN_ORDER.forEach(c=>{Object.keys(CLANS[c].ab).forEach(a=>{ABIL[a]=Object.assign({clan:c,id:a},CLANS[c].ab[a]);});});

const PASTS={
  nurse:{name:'Night-Shift Nurse',attrs:{cadaver:2,masquerade:1},mem:'Antiseptic. The three a.m. hush of a ward. Somebody\'s hand going cold in yours, and you, already reaching for the chart.'},
  grifter:{name:'Small-Time Grifter',attrs:{masquerade:2,nocturne:1},mem:'Three-card monte, rent checks that bounced, a smile that paid for dinner most nights.'},
  bouncer:{name:'Bouncer at the Lantern Room',attrs:{sanguine:2,cadaver:1},mem:'Doors. Fists. A clicker counting heads, and a hand-stamp that never quite washed off.'},
  theology:{name:'Lapsed Theology Student',attrs:{nocturne:2,sanguine:1},mem:'Latin declensions, a library carrel, and a crisis of faith you never got around to finishing.'}
};
const LOOKS={
  skin:[[.93,.84,.78],[.84,.68,.56],[.62,.45,.34],[.4,.28,.22],[.27,.19,.16]],
  skinNames:['Porcelain','Olive','Bronze','Umber','Ebony'],
  hair:['crop','slick','long','bun','curly','shaved'],
  hairNames:['Crop','Slick','Long','Bun','Curls','Shaved'],
  hairCol:[[.06,.05,.05],[.25,.15,.08],[.5,.32,.15],[.75,.6,.35],[.55,.12,.1],[.82,.82,.8]],
  hairColNames:['Raven','Chestnut','Copper','Ash blond','Oxblood','Silver']
};

const SLOTS=['head','face','coat','body','hands','acc1','acc2'];
const SLOT_NAMES={head:'Head',face:'Face',coat:'Coat',body:'Body',hands:'Hands',acc1:'Pocket',acc2:'Pocket'};
const ITEMS={
  greatcoat:{n:'Sheriff\'s Greatcoat',slot:'coat',mods:{apex:1,pedigree:1,stagecraft:-1},d:'Charcoal wool, Viennese tailoring, ash in every seam. The sleeves still remember someone else\'s arms.',sp:'Inner pocket holds a flip phone and a brass lighter. Mortals will notice the ash.',look:{coat:{color:[.16,.16,.2],length:.58,collar:true}}},
  apron:{n:'Blood-Stiff Apron',slot:'body',mods:{gutter:1,stagecraft:1},d:'Brooker\'s night-counter apron, stiff with old blood. It smells of bleach losing an argument.',sp:'"I just work here." Mortals expect staff to wear one.',look:{apron:{color:[.78,.76,.72],stain:[.45,.05,.08]}}},
  paperhat:{n:'Brooker\'s Paper Hat',slot:'head',mods:{stagecraft:1,apex:-1},d:'A folded paper cap with a red stripe. Nobody fears anyone in a paper hat.',sp:'Lowers a mortal\'s suspicion by 1.',look:{hat:{type:'paper'}}},
  widebrim:{n:'Sheriff\'s Hat',slot:'head',mods:{pedigree:1,echo:1,nostalgia:-1},d:'Wide-brimmed black felt with a small, neat hole through the brim. It fits. It should not fit.',sp:'Hides your eyes from anyone taller than you.',look:{hat:{type:'widebrim',color:[.12,.1,.1]}}},
  glasses:{n:'Margo\'s Reading Glasses',slot:'face',mods:{autopsy:1,web:1,apex:-1},d:'Tortoiseshell, plus two-and-a-half diopters. Everything up close becomes evidence.',look:{glasses:{type:'reading'}}},
  sunglasses:{n:'Aviator Sunglasses',slot:'face',mods:{apex:1,pulse:-1},d:'From the register\'s lost-and-found. Hides glowing eyes and advertises that you have something to hide.',sp:'Hides hunger-glow from mortals. Raises one eyebrow on everyone.',look:{glasses:{type:'sun'}}},
  gloves:{n:'Rubber Butcher Gloves',slot:'hands',mods:{abattoir:1,stagecraft:1},d:'Thick black rubber. Nobody will feel how cold your hands are.',sp:'Handshakes and pat-downs won\'t give you away.',look:{gloves:[.07,.07,.08]}},
  signet:{n:'Signet of Absalom Vane',slot:'acc',mods:{pedigree:2,nostalgia:-1},d:'Heavy gold. A crane on one leg over the motto NEC SOMNUS, "nor sleep".',sp:'Thralls and Court officials recognize it.'},
  watch:{n:'Stopped Pocket Watch',slot:'acc',mods:{sundial:1},d:'Silver, engraved "A.C. 1789". The hands stopped at 4:51.',sp:'Whatever happened in the freezer happened at 4:51 a.m.'},
  lighter:{n:'Brass Lighter',slot:'acc',mods:{apex:1,sundial:-1},d:'Brass, engraved A.C., faintly warm. You would like very much to stop thinking about fire.',sp:'Fire. Burns evidence. Costs Composure to use.'},
  knife:{n:'Boning Knife',slot:'acc',mods:{abattoir:1,frenzy:1,velvet:-1},d:'Six inches of flexible steel. It wants you to be the kind of person who carries it.',sp:'Unlocks threatening options.'},
  bloodbag:{n:'Blood Bag',type:'use',d:'One pint, vacuum-sealed and frosted. The label says PORK STOCK. The handwriting underneath says B-NEG.',sp:'Drink: +3 Vitae.'},
  thermometer:{n:'Meat Thermometer',type:'tool',d:'A steel probe thermometer. Long, thin, and exactly the shape of a door latch\'s worst nightmare.'},
  cuffkey:{n:'Handcuff Key',type:'tool',d:'Small, silver-plated, still warm from the ash.'},
  backkey:{n:'Padlock Key',type:'tool',d:'On a plastic fob: BACK · DON\'T LOSE (MARGO).'},
  phone:{n:'Sheriff\'s Flip Phone',type:'tool',d:'A battered flip phone. One contact, "Y.M." Twelve missed calls.'},
  notebook:{n:'Teddy\'s Joke Notebook',type:'read',d:'Spiral-bound, grease-stained. Title page: TIGHT FIVE (WORKING) · T. PRUITT.',read:['"My mom says I have a face for radio. My radio teacher says I have a voice for butchery. So here I am."','"Working nights at a 24-hour butcher. Who buys brisket at 3 a.m.? Insomniacs, cops, and one guy I am ninety percent sure is a vampire. He tips well though."','"I asked my boss why we\'re open 24 hours. She said, \'Meat doesn\'t sleep, Theodore.\' Neither does she. I\'m getting worried."','Crossed out, three times: "What do you call a vampire butcher?" No punchline.']},
  cash:{n:'Register Cash',type:'money',d:'$212 in small bills and one Canadian quarter.'},
  ledger:{n:'Margo\'s Ledger',type:'read',d:'Oxblood leather. Columns of dates, pints and prices, and initials where names should be.'}
};
const THOUGHTS={
  tenant:{n:'The Tenant\'s Lease',from:'pedigree',time:60,q:'Somebody else is living in your blood, and he has opinions about the furniture.',during:{nostalgia:-1},done:{pedigree:1,web:1},dt:'You sign the lease. Absalom Vane is a permanent resident now. He pays no rent, but he knows where every body in the Shambles is buried, some of them literally.'},
  coroner:{n:'Coroner\'s Calm',from:'autopsy',time:30,q:'Ash is just a very thorough kind of evidence.',during:{pulse:-1},done:{autopsy:1},bonus:'Remains no longer cost Composure.',dt:'You have looked at death and filed it under "Thursday". It doesn\'t hurt any more. You notice that this should worry you, and it doesn\'t.'},
  coffee:{n:'Cheap Coffee Liturgy',from:'nostalgia',time:45,q:'Burnt-pot diner coffee at two in the morning. A small sacrament for the very tired.',during:{},done:{nostalgia:1,frenzy:-1},bonus:'+1 maximum Composure.',compMax:1,dt:'You can\'t drink it any more. You can remember it, though, every detail, and when the Beast gets loud you recite it like a rosary: the chipped mug, the sugar packets, the waitress who called you "hon".'},
  darwin:{n:'Apex Darwinism',from:'apex',time:240,q:'Why bargain with cattle when you can command them?',during:{apex:1},done:{nostalgia:-2,pulse:-2},bonus:'Commands on mortals cost 0 Vitae.',dt:'They are cattle. You knew it in the freezer and you know it now. The voices that disagreed have gone very quiet.'},
  meat:{n:'Meat Is Meat',from:'abattoir',time:45,q:'Pig, cow, Teddy. It\'s all hanging from the same rail.',during:{pulse:-1},done:{abattoir:1,parasite:1,pulse:-1},bonus:'Feeding on mortals costs no Composure.',dt:'Pig, cow, person. You have stopped flinching at the difference. Something in you misses the flinch.'},
  tenpercent:{n:'Ten Percent Is Standard',from:'gutter',time:40,q:'Everyone in this city takes a cut. Even the Sheriff. Especially the Sheriff.',during:{pedigree:-1},done:{gutter:1,velvet:1,pedigree:-1},dt:'Every hand in Port Vellum is out, and every hand is dirty. That isn\'t a tragedy. It\'s a market, and you have just learned the prices.'},
  bratwurst:{n:'Nobody Checks the Bratwurst',from:'abattoir',time:30,q:'There is a meat grinder in the back and a world of problems in the front.',during:{},done:{abattoir:1,stagecraft:1},dt:'Evidence is just ingredients that haven\'t been processed yet. A horrible thought. A useful one. You keep it.'},
  fourfiftyone:{n:'Four Fifty-One',from:'sundial',time:35,q:'A silver watch stopped at 4:51 a.m. Nine minutes before sunrise, give or take.',during:{web:-1},done:{sundial:1,web:1},dt:'Whoever shut that door knew exactly when dawn was. They left you nine minutes. A margin that thin is not an accident. It\'s a message, or a mistake.'}
};
const RELS=[[-3,'Hostile'],[-2,'Afraid'],[-1,'Wary'],[0,'Neutral'],[1,'Warming'],[2,'Trusting'],[3,'Devoted']];
const relName=v=>{let n='Neutral';for(const r of RELS)if(v>=r[0])n=r[1];return n;};

const CHARS={
  tenant:{n:'The Tenant',full:'Absalom Vane',role:'Sheriff of the Marrow Ward · deceased (by you)',color:'#cdb2f0',
    spec:{face:{long:1.07,jaw:1.25,nose:1.35,cheek:1.5,brow:1.1,chin:1.1},skin:[.84,.8,.78],hair:{style:'slick',color:[.75,.72,.7]},eyes:[.85,.65,.2],eyeGlow:[.5,.35,.05],coat:{color:[.16,.16,.2],length:.6,collar:true},shirt:[.85,.84,.8],tie:[.35,.05,.08],hat:{type:'widebrim',color:[.12,.1,.1]},mustache:[.72,.7,.68],height:1.04},
    bio:'Three hundred years of Port Vellum, the last eighty of them as Sheriff of the Marrow Ward: keeper of the Ninth Ward peace, collector of the Court\'s tithes, and, according to Margo\'s ledger, collector of ten percent of everything else. You drank him. He is taking it surprisingly well.',
    sched:[['Monday, midnight','Was due at the Court with a report on the Shambles disappearances.'],['Always','Lives in your blood now. Comments on your choices.']],
    facts:{intro:'Introduced himself as "the Tenant". Came with the property.',name:'Absalom Vane, Sheriff of the Marrow Ward. Three-time Court fencing champion.',noMemory:'Doesn\'t remember who shut the freezer door, only the click of the latch.',cut:'Took a ten percent cut of Brooker\'s blood trade.',pemberton:'Pemberton drove him for forty-one years.',clan:'Was a Sovereign: old blood, older debts.'}},
  teddy:{n:'Teddy Pruitt',full:'Theodore "Teddy" Pruitt',role:'Night counter at Brooker\'s · aspiring stand-up',color:'#efc791',
    spec:{face:{wide:1.04,jaw:0.55,nose:0.8,cheek:0.5,long:0.97,chin:0.8},skin:[.9,.76,.66],hair:{style:'curly',color:[.35,.22,.12]},eyes:[.3,.25,.15],shirt:[.82,.82,.78],apron:{color:[.78,.76,.72],stain:[.5,.05,.08]},pants:[.2,.25,.4],shoes:[.3,.3,.32],height:.97},
    bio:'Twenty-four. Works the night counter Monday to Thursday so he can do open mics on Tuesdays. Has a sister, a mother who calls him Theodore, and two neat holes in his neck that he would like someone to explain.',
    sched:[['Mon–Thu, 8 PM–4 AM','Night counter at Brooker\'s.'],['Tuesday, 10 PM','Open mic at the Lantern Room, Ferrier Street.'],['Sunday','Dinner at his mother\'s. Attendance mandatory.']],
    facts:{name:'Name: Theodore Pruitt. Goes by Teddy.',standup:'Does stand-up on Tuesdays at the Lantern Room. Has no material about his sister.',saw:'Saw the Sheriff in the freezer with Margo\'s ledger before you arrived.',door:'Heard someone shut the freezer door from outside. Didn\'t see who.',sister:'His niece Bea turned nine today. He missed the party.',mom:'His mother reported him missing this morning.',margo:'Says Margo had the freezer safety release "fixed" last week.'}},
  calloway:{n:'Det. Ines Calloway',full:'Detective Ines Calloway',role:'Missing Persons · Port Vellum PD',color:'#c9d6e3',
    spec:{face:{jaw:0.85,nose:1.1,brow:1.25,cheek:1.2},skin:[.62,.45,.36],hair:{style:'bun',color:[.08,.06,.06]},eyes:[.2,.13,.08],coat:{color:[.52,.43,.3],length:.62,collar:true},shirt:[.3,.32,.36],pants:[.18,.18,.2],prop:'cup',height:.98},
    bio:'Forty-four. Missing Persons, twenty years on the job, two hours of sleep a night. Seven people have vanished from the Shambles in two months and she is the only one at the precinct who has noticed it is a pattern.',
    sched:[['Nights, officially off-duty','Knocking on doors in the Shambles anyway.'],['2 AM','Dot\'s Diner on Ferrier. Burnt-pot coffee, pie she never finishes.']],
    facts:{name:'Detective, Missing Persons. Twenty years on the job.',seven:'Seven people missing from the Shambles in two months.',coffee:'Drinks Dot\'s burnt-pot coffee at two in the morning.',brother:'Her brother Mateo went missing in the Shambles in 2011. Never found.',teddy:'Came looking for Teddy Pruitt after his mother called it in.',offclock:'Is working these cases off the clock. Her lieutenant doesn\'t know.'}},
  marchetti:{n:'Ysolde Marchetti',full:'Seneschal Ysolde Marchetti',role:'Seneschal of the Court of Port Vellum',color:'#e7a6b8',
    spec:{face:{long:1.04,jaw:1.3,nose:0.95,cheek:1.6,brow:0.75,chin:0.9},skin:[.92,.86,.82],hair:{style:'long',color:[.08,.05,.07]},eyes:[.3,.1,.15],eyeGlow:[.2,.02,.05],shirt:[.35,.05,.12],pants:[.1,.08,.1],lips:[.55,.1,.15],coat:{color:[.08,.06,.08],length:.7,collar:true}},
    bio:'The Regent\'s right hand and the keeper of the Court\'s calendar. Has, according to the Tenant, hated Absalom Vane "since the Coolidge administration, and with real devotion".',
    sched:[['Friday, midnight','The Court convenes. The Regent expects a culprit for the disappearances.'],['Any time','Calls at the worst possible moment.']],
    facts:{call:'Called the Sheriff\'s line looking for his report.',friday:'The Court convenes Friday at midnight. Bring a culprit, or be one.',feud:'Has feuded with Absalom Vane for a century.',car:'Was in a car during the call, with someone else breathing on the line.'}},
  pemberton:{n:'Pemberton',full:'Mr. Pemberton',role:'Chauffeur · the Sheriff\'s thrall',color:'#b9c4b0',
    spec:{face:{long:1.05,jaw:0.75,nose:1.5,brow:1.45,cheek:0.6,chin:1.35},skin:[.86,.76,.7],hair:{style:'fringe',color:[.85,.85,.84]},eyes:[.35,.4,.42],coat:{color:[.06,.06,.07],length:.7,collar:true},shirt:[.85,.85,.82],tie:[.05,.05,.06],hat:{type:'chauffeur',color:[.07,.07,.08]},mustache:[.9,.9,.88],prop:'umbrella',height:1.05,width:.92},
    bio:'Forty-one years in the Sheriff\'s service as driver, valet, keeper of the calendar and drinker of the occasional sacrament. He has outlived two wives and three cars. He seems determined to outlive you.',
    sched:[['Wherever the car is','Waiting. Always waiting.']],
    facts:{name:'Forty-one years in Absalom Vane\'s service.',bond:'Blood-bound. "The blood decides who I serve."',relief:'Looked relieved, not surprised, that you were the one who walked out of the freezer.',car:'Drives a long black 1971 Continental.'}},
  margo:{n:'Margo Brooker',full:'Marguerite "Margo" Brooker',role:'Owner, Brooker\'s 24-Hour Meats',color:'#d9a07a',
    spec:{face:{wide:1.08,jaw:0.35,nose:1.15,long:0.95,cheek:0.8,chin:1.2},skin:[.88,.78,.7],hair:{style:'bun',color:[.7,.7,.7]},glasses:{type:'reading'},apron:{color:[.78,.76,.72]},shirt:[.4,.2,.2],height:.94,width:1.08},
    bio:'Sixty-three. Third-generation butcher. Never seen, constantly mentioned. Her shop sells pork chops at the front and something else entirely out of the walk-in.',
    sched:[['Tuesday','Deliveries. St. Ada\'s Hospital, back entrance.'],['Thursday','Deliveries. The Gilded House.']],
    facts:{owner:'Owns Brooker\'s. Third-generation butcher.',trade:'Runs a black-market blood trade out of the freezer, labelled as pork stock.',release:'Had the freezer\'s safety release "fixed" last week.',v:'A new ledger entry, dated today: "New arrangement. V. says the Sheriff is a problem."'}}
};

const TASKS={
  freezer:{n:'Get out of the freezer',xp:20},
  what:{n:'Work out what happened in here',xp:20},
  mirror:{n:'Find a mirror',xp:20},
  remains:{n:'Deal with the Sheriff\'s remains',xp:20},
  teddy:{n:'Decide what to do about Teddy',xp:25},
  phone:{n:'Answer the telephone',xp:15},
  front:{n:'Deal with whoever is at the front',xp:30},
  leave:{n:'Leave before anyone else arrives',xp:20},
  friday:{n:'Friday, midnight: bring the Court a culprit',xp:0}
};

Object.assign(NL,{ATTRS,SKILLS,SKILL_ORDER,GLYPH,DIFF,diffName,CLANS,CLAN_ORDER,ABIL,PASTS,LOOKS,SLOTS,SLOT_NAMES,ITEMS,THOUGHTS,relName,CHARS,TASKS});
})();
