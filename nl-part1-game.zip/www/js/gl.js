'use strict';
/* THE NEW LORD — tiny WebGL2 engine: math, geometry, shaders, painterly bake pipeline */
(function(){
const NL = window.NL = window.NL || {};

/* ---------------- math ---------------- */
const V3 = {
  sub:(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],
  add:(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]],
  mul:(a,s)=>[a[0]*s,a[1]*s,a[2]*s],
  dot:(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],
  cross:(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],
  len:a=>Math.hypot(a[0],a[1],a[2]),
  norm:a=>{const l=Math.hypot(a[0],a[1],a[2])||1;return [a[0]/l,a[1]/l,a[2]/l];},
  lerp:(a,b,t)=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t]
};
const M4 = {
  ident(o){o=o||new Float32Array(16);o.fill(0);o[0]=o[5]=o[10]=o[15]=1;return o;},
  mulInto(o,a,b){
    const t=M4._t;
    for(let c=0;c<4;c++){const b0=b[c*4],b1=b[c*4+1],b2=b[c*4+2],b3=b[c*4+3];
      t[c*4]=a[0]*b0+a[4]*b1+a[8]*b2+a[12]*b3; t[c*4+1]=a[1]*b0+a[5]*b1+a[9]*b2+a[13]*b3;
      t[c*4+2]=a[2]*b0+a[6]*b1+a[10]*b2+a[14]*b3; t[c*4+3]=a[3]*b0+a[7]*b1+a[11]*b2+a[15]*b3;}
    o.set(t);return o;
  },
  mul(a,b){return M4.mulInto(new Float32Array(16),a,b);},
  ortho(l,r,b,t,n,f){const o=new Float32Array(16);o[0]=2/(r-l);o[5]=2/(t-b);o[10]=-2/(f-n);o[12]=-(r+l)/(r-l);o[13]=-(t+b)/(t-b);o[14]=-(f+n)/(f-n);o[15]=1;return o;},
  persp(fovy,asp,n,f){const o=new Float32Array(16),q=1/Math.tan(fovy/2);o[0]=q/asp;o[5]=q;o[10]=(f+n)/(n-f);o[11]=-1;o[14]=2*f*n/(n-f);return o;},
  lookAt(e,c,up){
    const z=V3.norm(V3.sub(e,c)); let x=V3.cross(up,z); if(V3.len(x)<1e-5) x=V3.cross([0,0,1],z); x=V3.norm(x); const y=V3.cross(z,x);
    const o=new Float32Array(16);
    o[0]=x[0];o[1]=y[0];o[2]=z[0];o[4]=x[1];o[5]=y[1];o[6]=z[1];o[8]=x[2];o[9]=y[2];o[10]=z[2];
    o[12]=-V3.dot(x,e);o[13]=-V3.dot(y,e);o[14]=-V3.dot(z,e);o[15]=1;return o;
  },
  trsInto(o,t,r,s){
    const cx=Math.cos(r[0]),sx=Math.sin(r[0]),cy=Math.cos(r[1]),sy=Math.sin(r[1]),cz=Math.cos(r[2]),sz=Math.sin(r[2]);
    const r00=cy*cz+sy*sx*sz, r01=-cy*sz+sy*sx*cz, r02=sy*cx;
    const r10=cx*sz, r11=cx*cz, r12=-sx;
    const r20=-sy*cz+cy*sx*sz, r21=sy*sz+cy*sx*cz, r22=cy*cx;
    o[0]=r00*s[0];o[1]=r10*s[0];o[2]=r20*s[0];o[3]=0;
    o[4]=r01*s[1];o[5]=r11*s[1];o[6]=r21*s[1];o[7]=0;
    o[8]=r02*s[2];o[9]=r12*s[2];o[10]=r22*s[2];o[11]=0;
    o[12]=t[0];o[13]=t[1];o[14]=t[2];o[15]=1;return o;
  },
  trs(t,r,s){return M4.trsInto(new Float32Array(16),t,r||[0,0,0],s||[1,1,1]);},
  invert(a){
    const o=new Float32Array(16);
    const a00=a[0],a01=a[1],a02=a[2],a03=a[3],a10=a[4],a11=a[5],a12=a[6],a13=a[7],a20=a[8],a21=a[9],a22=a[10],a23=a[11],a30=a[12],a31=a[13],a32=a[14],a33=a[15];
    const b00=a00*a11-a01*a10,b01=a00*a12-a02*a10,b02=a00*a13-a03*a10,b03=a01*a12-a02*a11,b04=a01*a13-a03*a11,b05=a02*a13-a03*a12,
      b06=a20*a31-a21*a30,b07=a20*a32-a22*a30,b08=a20*a33-a23*a30,b09=a21*a32-a22*a31,b10=a21*a33-a23*a31,b11=a22*a33-a23*a32;
    let det=b00*b11-b01*b10+b02*b09+b03*b08-b04*b07+b05*b06; if(!det) return M4.ident(); det=1/det;
    o[0]=(a11*b11-a12*b10+a13*b09)*det;o[1]=(a02*b10-a01*b11-a03*b09)*det;o[2]=(a31*b05-a32*b04+a33*b03)*det;o[3]=(a22*b04-a21*b05-a23*b03)*det;
    o[4]=(a12*b08-a10*b11-a13*b07)*det;o[5]=(a00*b11-a02*b08+a03*b07)*det;o[6]=(a32*b02-a30*b05-a33*b01)*det;o[7]=(a20*b05-a22*b02+a23*b01)*det;
    o[8]=(a10*b10-a11*b08+a13*b06)*det;o[9]=(a01*b08-a00*b10-a03*b06)*det;o[10]=(a30*b04-a31*b02+a33*b00)*det;o[11]=(a21*b02-a20*b04-a23*b00)*det;
    o[12]=(a11*b07-a10*b09-a12*b06)*det;o[13]=(a00*b09-a01*b07+a02*b06)*det;o[14]=(a31*b01-a30*b03-a32*b00)*det;o[15]=(a20*b03-a21*b01+a22*b00)*det;
    return o;
  },
  normalInto(o,a){
    const a00=a[0],a01=a[1],a02=a[2],a03=a[3],a10=a[4],a11=a[5],a12=a[6],a13=a[7],a20=a[8],a21=a[9],a22=a[10],a23=a[11],a30=a[12],a31=a[13],a32=a[14],a33=a[15];
    const b00=a00*a11-a01*a10,b01=a00*a12-a02*a10,b02=a00*a13-a03*a10,b03=a01*a12-a02*a11,b04=a01*a13-a03*a11,b05=a02*a13-a03*a12,
      b06=a20*a31-a21*a30,b07=a20*a32-a22*a30,b08=a20*a33-a23*a30,b09=a21*a32-a22*a31,b10=a21*a33-a23*a31,b11=a22*a33-a23*a32;
    let det=b00*b11-b01*b10+b02*b09+b03*b08-b04*b07+b05*b06; if(!det) det=1e-6; det=1/det;
    o[0]=(a11*b11-a12*b10+a13*b09)*det;o[1]=(a12*b08-a10*b11-a13*b07)*det;o[2]=(a10*b10-a11*b08+a13*b06)*det;
    o[3]=(a02*b10-a01*b11-a03*b09)*det;o[4]=(a00*b11-a02*b08+a03*b07)*det;o[5]=(a01*b08-a00*b10-a03*b06)*det;
    o[6]=(a31*b05-a32*b04+a33*b03)*det;o[7]=(a32*b02-a30*b05-a33*b01)*det;o[8]=(a30*b04-a31*b02+a33*b00)*det;return o;
  },
  xf(m,p){const x=p[0],y=p[1],z=p[2];const w=m[3]*x+m[7]*y+m[11]*z+m[15]||1;
    return [(m[0]*x+m[4]*y+m[8]*z+m[12])/w,(m[1]*x+m[5]*y+m[9]*z+m[13])/w,(m[2]*x+m[6]*y+m[10]*z+m[14])/w];},
  xfDir(m,d){return [m[0]*d[0]+m[4]*d[1]+m[8]*d[2],m[1]*d[0]+m[5]*d[1]+m[9]*d[2],m[2]*d[0]+m[6]*d[1]+m[10]*d[2]];}
};
M4._t=new Float32Array(16);

/* ---------------- geometry ---------------- */
class GeoB{
  constructor(){this.p=[];this.n=[];this.u=[];this.i=[];}
  v(p,n,u){this.p.push(p[0],p[1],p[2]);this.n.push(n[0],n[1],n[2]);this.u.push(u[0],u[1]);return this.p.length/3-1;}
  quadPts(c0,du,dv,n,uvf){
    const a=c0,b=V3.add(c0,du),c=V3.add(b,dv),d=V3.add(c0,dv);
    const i0=this.v(a,n,uvf(a,0,0)),i1=this.v(b,n,uvf(b,1,0)),i2=this.v(c,n,uvf(c,1,1)),i3=this.v(d,n,uvf(d,0,1));
    this.i.push(i0,i1,i2,i0,i2,i3);
  }
  append(g,m){
    const base=this.p.length/3, nm=m?M4.normalInto(new Float32Array(9),m):null;
    for(let k=0;k<g.pos.length;k+=3){
      let p=[g.pos[k],g.pos[k+1],g.pos[k+2]], n=[g.nor[k],g.nor[k+1],g.nor[k+2]];
      if(m){p=M4.xf(m,p); n=V3.norm([nm[0]*n[0]+nm[3]*n[1]+nm[6]*n[2],nm[1]*n[0]+nm[4]*n[1]+nm[7]*n[2],nm[2]*n[0]+nm[5]*n[1]+nm[8]*n[2]]);}
      this.p.push(p[0],p[1],p[2]);this.n.push(n[0],n[1],n[2]);
    }
    for(let k=0;k<g.uv.length;k++) this.u.push(g.uv[k]);
    for(let k=0;k<g.idx.length;k++) this.i.push(g.idx[k]+base);
  }
  build(){return {pos:new Float32Array(this.p),nor:new Float32Array(this.n),uv:new Float32Array(this.u),idx:new Uint32Array(this.i)};}
  get empty(){return this.i.length===0;}
}
const worldUV=(axis)=>(p)=> axis==='x'?[p[2],p[1]]: axis==='z'?[p[0],p[1]]:[p[0],p[2]];
const Geo = {
  // world-space axis-aligned box, faces optional mask {px,nx,py,ny,pz,nz}
  boxInto(b,mn,mx,skip){
    skip=skip||{};
    const [x0,y0,z0]=mn,[x1,y1,z1]=mx,dx=x1-x0,dy=y1-y0,dz=z1-z0;
    if(!skip.px) b.quadPts([x1,y0,z1],[0,0,-dz],[0,dy,0],[1,0,0],worldUV('x'));
    if(!skip.nx) b.quadPts([x0,y0,z0],[0,0,dz],[0,dy,0],[-1,0,0],worldUV('x'));
    if(!skip.pz) b.quadPts([x0,y0,z1],[dx,0,0],[0,dy,0],[0,0,1],worldUV('z'));
    if(!skip.nz) b.quadPts([x1,y0,z0],[-dx,0,0],[0,dy,0],[0,0,-1],worldUV('z'));
    if(!skip.py) b.quadPts([x0,y1,z1],[dx,0,0],[0,0,-dz],[0,1,0],worldUV('y'));
    if(!skip.ny) b.quadPts([x0,y0,z0],[dx,0,0],[0,0,dz],[0,-1,0],worldUV('y'));
  },
  box(w,h,d){const b=new GeoB();Geo.boxInto(b,[-w/2,-h/2,-d/2],[w/2,h/2,d/2]);return b.build();},
  lathe(pts,seg,arc,start){
    seg=seg||16; arc=arc||Math.PI*2; start=start||0;
    const b=new GeoB(), n=pts.length, nrm=[];
    const same=(a,q)=>Math.abs(a[0]-q[0])<1e-6&&Math.abs(a[1]-q[1])<1e-6;
    const dir=(a,q)=>{const d=[q[0]-a[0],q[1]-a[1]],l=Math.hypot(d[0],d[1])||1;return [d[0]/l,d[1]/l];};
    for(let i=0;i<n;i++){
      const p=pts[i];
      const tp=(i>0&&!same(pts[i-1],p))?dir(pts[i-1],p):null;
      const tn=(i<n-1&&!same(pts[i+1],p))?dir(p,pts[i+1]):null;
      let t;
      if(i>0&&same(pts[i-1],p)) t=tn||tp;
      else if(i<n-1&&same(pts[i+1],p)) t=tp||tn;
      else if(tp&&tn) t=[tp[0]+tn[0],tp[1]+tn[1]];
      else t=tp||tn||[0,1];
      const l=Math.hypot(t[0],t[1])||1; nrm.push([t[1]/l,-t[0]/l]);
    }
    for(let i=0;i<n;i++)for(let j=0;j<=seg;j++){
      const th=start+j/seg*arc,c=Math.cos(th),s=Math.sin(th),p=pts[i],q=nrm[i];
      b.v([p[0]*c,p[1],-p[0]*s],[q[0]*c,q[1],-q[0]*s],[j/seg,i/(n-1)]);
    }
    for(let i=0;i<n-1;i++)for(let j=0;j<seg;j++){
      const a=i*(seg+1)+j,bb=a+1,cc=a+seg+2,d=a+seg+1; b.i.push(a,bb,cc,a,cc,d);
    }
    return b.build();
  },
  sphere(r,seg,rings){seg=seg||16;rings=rings||10;const pts=[];for(let i=0;i<=rings;i++){const a=-Math.PI/2+i/rings*Math.PI;pts.push([Math.max(0,Math.cos(a))*r,Math.sin(a)*r]);}pts[0][0]=0;pts[rings][0]=0;return Geo.lathe(pts,seg);},
  hemi(r,seg,rings,from){seg=seg||16;rings=rings||6;from=from==null?0:from;const pts=[];for(let i=0;i<=rings;i++){const a=from+i/rings*(Math.PI/2-from);pts.push([Math.cos(a)*r,Math.sin(a)*r]);}pts[rings][0]=0;return Geo.lathe(pts,seg);},
  capsule(r1,r2,len,seg){
    const pts=[];
    for(let k=0;k<=4;k++){const a=-Math.PI/2+k/4*Math.PI/2;pts.push([r2*Math.cos(a),-len+r2*Math.sin(a)]);}
    for(let k=0;k<=4;k++){const a=k/4*Math.PI/2;pts.push([r1*Math.cos(a),r1*Math.sin(a)]);}
    pts[0][0]=0;pts[pts.length-1][0]=0;
    return Geo.lathe(pts,seg||12);
  },
  cyl(rt,rb,h,seg,caps){
    const pts=caps===false?[[rb,0],[rt,h]]:[[0,0],[rb,0],[rb,0],[rt,h],[rt,h],[0,h]];
    return Geo.lathe(pts,seg||16);
  },
  quad(w,h){const b=new GeoB();b.quadPts([-w/2,-h/2,0],[w,0,0],[0,h,0],[0,0,1],(p,u,v)=>[u,v]);return b.build();},
  floorQuad(w,d){const b=new GeoB();b.quadPts([-w/2,0,d/2],[w,0,0],[0,0,-d],[0,1,0],(p,u,v)=>[u,v]);return b.build();},
  // parametric surface f(u,v)->[x,y,z], u wraps (0..1), v 0..1; smooth normals recomputed and welded across seams/poles
  param(f,nu,nv,flip){
    const pos=[],uv=[],idx=[];
    for(let j=0;j<=nv;j++)for(let i=0;i<=nu;i++){const p=f(i/nu,j/nv);pos.push(p[0],p[1],p[2]);uv.push(i/nu,j/nv);}
    for(let j=0;j<nv;j++)for(let i=0;i<nu;i++){const a=j*(nu+1)+i,b=a+1,c=a+nu+2,d=a+nu+1;if(flip)idx.push(a,b,c,a,c,d);else idx.push(a,c,b,a,d,c);}
    return Geo.smooth({pos:new Float32Array(pos),uv:new Float32Array(uv),idx:new Uint32Array(idx)});
  },
  smooth(g){
    const n=g.pos.length/3,acc=new Float32Array(n*3),P=g.pos;
    for(let k=0;k<g.idx.length;k+=3){const a=g.idx[k]*3,b=g.idx[k+1]*3,c=g.idx[k+2]*3;
      const ux=P[b]-P[a],uy=P[b+1]-P[a+1],uz=P[b+2]-P[a+2],vx=P[c]-P[a],vy=P[c+1]-P[a+1],vz=P[c+2]-P[a+2];
      const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
      for(const q of [a,b,c]){acc[q]+=nx;acc[q+1]+=ny;acc[q+2]+=nz;}}
    const key=i=>Math.round(P[i*3]*2e4)+','+Math.round(P[i*3+1]*2e4)+','+Math.round(P[i*3+2]*2e4);
    const groups=new Map();for(let i=0;i<n;i++){const k=key(i);let g2=groups.get(k);if(!g2){g2=[0,0,0,[]];groups.set(k,g2);}g2[0]+=acc[i*3];g2[1]+=acc[i*3+1];g2[2]+=acc[i*3+2];g2[3].push(i);}
    const nor=new Float32Array(n*3);
    groups.forEach(g2=>{const l=Math.hypot(g2[0],g2[1],g2[2])||1;for(const i of g2[3]){nor[i*3]=g2[0]/l;nor[i*3+1]=g2[1]/l;nor[i*3+2]=g2[2]/l;}});
    return {pos:g.pos,nor,uv:g.uv,idx:g.idx};
  }
};

/* ---------------- shaders ---------------- */
const NOISE = `
float hash12(vec2 p){vec3 p3=fract(vec3(p.xyx)*.1031);p3+=dot(p3,p3.yzx+33.33);return fract((p3.x+p3.y)*p3.z);}
float vnoise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
  return mix(mix(hash12(i),hash12(i+vec2(1,0)),f.x),mix(hash12(i+vec2(0,1)),hash12(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float s=0.,a=.5;for(int i=0;i<4;i++){s+=a*vnoise(p);p=p*2.03+17.1;a*=.5;}return s;}
float hash13(vec3 p3){p3=fract(p3*.1031);p3+=dot(p3,p3.zyx+31.32);return fract((p3.x+p3.y)*p3.z);}
float vnoise3(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);
  return mix(mix(mix(hash13(i),hash13(i+vec3(1,0,0)),f.x),mix(hash13(i+vec3(0,1,0)),hash13(i+vec3(1,1,0)),f.x),f.y),
             mix(mix(hash13(i+vec3(0,0,1)),hash13(i+vec3(1,0,1)),f.x),mix(hash13(i+vec3(0,1,1)),hash13(i+vec3(1,1,1)),f.x),f.y),f.z);}
`;
const TONE = `
vec3 tone(vec3 c){vec3 k=max(c-.78,0.);return min(c,.78)+.22*(1.-exp(-k/.22));}
`;
const LIGHTS = `
uniform vec3 uSky; uniform vec3 uGround; uniform int uNL; uniform vec4 uLP[8]; uniform vec4 uLC[8];
`;
const SH = {
ENV_VS:`#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNor; layout(location=2) in vec2 aUv;
uniform mat4 uVP; uniform mat4 uShVP;
out vec3 vW; out vec3 vN; out vec2 vUv; out vec4 vSh;
void main(){vW=aPos;vN=aNor;vUv=aUv;vSh=uShVP*vec4(aPos,1.);gl_Position=uVP*vec4(aPos,1.);}`,
ENV_FS:`#version 300 es
precision highp float;
in vec3 vW; in vec3 vN; in vec2 vUv; in vec4 vSh;
uniform vec3 uColor; uniform vec3 uEmis; uniform float uEmisK; uniform sampler2D uTex; uniform float uHasTex; uniform float uTexScale;
uniform sampler2D uShadow; uniform float uShOn; uniform int uShIdx; uniform float uShTexel;
uniform vec3 uCamDir; uniform float uSpec; uniform float uMottle; uniform float uAlpha; uniform float uDecal;
${LIGHTS}
${TONE}
out vec4 o;
${NOISE}
float shadowF(){vec3 p=vSh.xyz/vSh.w*.5+.5; if(vSh.w<=0.||p.x<0.||p.x>1.||p.y<0.||p.y>1.||p.z>1.) return 1.;
  float s=0.; for(int x=-2;x<=2;x++)for(int y=-2;y<=2;y++){float d=texture(uShadow,p.xy+vec2(x,y)*uShTexel*1.2).r; s+=(p.z-0.0018>d)?0.:1.;} return s/25.;}
void main(){
  vec4 tx=uHasTex>.5?texture(uTex,uDecal>.5?vUv:vUv*uTexScale):vec4(1.);
  vec3 base=uColor*tx.rgb;
  float m=vnoise3(vW*2.1)*.55+vnoise3(vW*6.3)*.3+vnoise3(vW*17.)*.15; base*=1.+(m-.5)*uMottle;
  vec3 N=normalize(vN);
  vec3 col=base*mix(uGround,uSky,N.y*.5+.5);
  float sh=uShOn>.5?shadowF():1.;
  for(int i=0;i<8;i++){ if(i>=uNL) break;
    vec3 L=uLP[i].xyz-vW; float d=length(L); L/=max(d,1e-4);
    float att=clamp(1.-d/uLP[i].w,0.,1.); att*=att;
    float ndl=dot(N,L); float dif=max(ndl,0.)*.82+.18*clamp(ndl*.5+.5,0.,1.);
    float s=(i==uShIdx)?mix(.06,1.,sh):1.;
    vec3 H=normalize(L+uCamDir); float sp=pow(max(dot(N,H),0.),28.)*uSpec;
    col+=(base*dif+sp)*uLC[i].rgb*att*s;
  }
  col+=base*uEmisK+uEmis;
  o=vec4(tone(col),uAlpha*tx.a);
}`,
DEPTH_VS:`#version 300 es
layout(location=0) in vec3 aPos; uniform mat4 uVP; void main(){gl_Position=uVP*vec4(aPos,1.);}`,
DEPTH_FS:`#version 300 es
precision mediump float; out vec4 o; void main(){o=vec4(1.);}`,
TOON_VS:`#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNor;
uniform mat4 uVP; uniform mat4 uM; uniform mat3 uNM; uniform float uOutline;
out vec3 vW; out vec3 vN;
void main(){vec3 n=normalize(uNM*aNor);vec4 w=uM*vec4(aPos,1.);w.xyz+=n*uOutline;vW=w.xyz;vN=n;gl_Position=uVP*w;}`,
TOON_FS:`#version 300 es
precision highp float;
in vec3 vW; in vec3 vN;
uniform vec3 uColor; uniform vec3 uEmis; uniform float uIsOutline; uniform vec3 uInk; uniform vec3 uCamDir; uniform vec3 uRim; uniform float uAlpha; uniform float uFlash; uniform float uBright; uniform vec3 uKeyDir; uniform vec3 uKeyCol; uniform float uMat;
${LIGHTS}
${TONE}
${NOISE}
out vec4 o;
// materials: 0 cloth, 1 skin, 2 hair, 3 eye/wet, 4 leather/polished
void main(){
  if(uIsOutline>.5){o=vec4(uInk,uAlpha);return;}
  vec3 N=normalize(vN); float inner=1.; if(!gl_FrontFacing){N=-N;inner=.45;}
  vec3 V=normalize(uCamDir);
  bool skin=uMat>.5&&uMat<1.5, hair=uMat>1.5&&uMat<2.5, eye=uMat>2.5&&uMat<3.5, lea=uMat>3.5;
  float softK=skin?.6:hair?.45:.38;
  vec3 lit=mix(uGround,uSky,N.y*.5+.5)*1.7+vec3(.05,.045,.05);
  vec3 K=normalize(uKeyDir);float kd=dot(N,K);
  lit+=uKeyCol*mix(smoothstep(-.05,.05,kd)*.55+smoothstep(.45,.55,kd)*.45,clamp(kd*.5+.5,0.,1.),softK);
  vec3 spec=vec3(0.),sss=vec3(0.);
  for(int i=0;i<8;i++){ if(i>=uNL) break;
    vec3 L=uLP[i].xyz-vW; float d=length(L); L/=max(d,1e-4);
    float att=clamp(1.-d/(uLP[i].w*1.25),0.,1.); att*=att;
    float ndl=dot(N,L);
    float hard=smoothstep(-.02,.06,ndl)*.6+smoothstep(.42,.5,ndl)*.4;
    float soft=clamp(ndl*.55+.45,0.,1.);soft*=soft;
    lit+=uLC[i].rgb*att*mix(hard,soft*1.08,softK)*.62;
    if(skin) sss+=uLC[i].rgb*att*smoothstep(-.4,0.,ndl)*(1.-smoothstep(0.,.45,ndl))*.55;
    vec3 H=normalize(L+V); float nh=max(dot(N,H),0.); float lf=step(0.,ndl)*att;
    if(skin) spec+=uLC[i].rgb*lf*pow(nh,38.)*.1;
    else if(hair) spec+=uLC[i].rgb*lf*smoothstep(.78,.93,nh)*(.12+.1*vnoise(vec2(vW.x*240.+vW.z*240.,vW.y*30.)));
    else if(eye) spec+=uLC[i].rgb*lf*smoothstep(.975,.99,nh)*1.4;
    else if(lea) spec+=uLC[i].rgb*lf*pow(nh,55.)*.4;
  }
  float ndv=max(dot(N,V),0.);
  float rim=smoothstep(.55,.75,1.-ndv);
  float micro=vnoise3(vW*(hair?140.:skin?55.:110.));
  vec3 base=uColor*(skin?(.975+.05*micro):hair?(.86+.22*micro):eye?1.:(.975+.05*vnoise3(vW*260.)));
  if(skin) sss*=vec3(.62,.16,.1);
  vec3 col=(base*lit*uBright+base*sss+spec+uRim*rim*(skin?.42:.55)+(uMat<.5?base*rim*.08:vec3(0.)))*inner+uEmis;
  col=mix(tone(col),vec3(1.,.96,.92),uFlash);
  o=vec4(col,uAlpha);
}`,
FS_VS:`#version 300 es
out vec2 vUv; void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));vUv=p;gl_Position=vec4(p*2.-1.,0.,1.);}`,
KUWA_FS:`#version 300 es
precision highp float; in vec2 vUv; uniform sampler2D uSrc; uniform vec2 uTexel; uniform int uR; out vec4 o;
void main(){
  vec3 m0=vec3(0),m1=vec3(0),m2=vec3(0),m3=vec3(0),s0=vec3(0),s1=vec3(0),s2=vec3(0),s3=vec3(0); float a0=0.,a1=0.,a2=0.,a3=0.;
  for(int j=-uR;j<=uR;j++)for(int i=-uR;i<=uR;i++){
    vec4 c=texture(uSrc,vUv+vec2(float(i),float(j))*uTexel); vec3 c2=c.rgb*c.rgb;
    if(i<=0&&j<=0){m0+=c.rgb;s0+=c2;a0+=c.a;} if(i>=0&&j<=0){m1+=c.rgb;s1+=c2;a1+=c.a;}
    if(i<=0&&j>=0){m2+=c.rgb;s2+=c2;a2+=c.a;} if(i>=0&&j>=0){m3+=c.rgb;s3+=c2;a3+=c.a;}
  }
  float n=float((uR+1)*(uR+1));
  m0/=n;m1/=n;m2/=n;m3/=n;
  vec3 v0=abs(s0/n-m0*m0),v1=abs(s1/n-m1*m1),v2=abs(s2/n-m2*m2),v3=abs(s3/n-m3*m3);
  float q0=v0.r+v0.g+v0.b,q1=v1.r+v1.g+v1.b,q2=v2.r+v2.g+v2.b,q3=v3.r+v3.g+v3.b;
  vec4 r=vec4(m0,a0/n); float mn=q0;
  if(q1<mn){mn=q1;r=vec4(m1,a1/n);} if(q2<mn){mn=q2;r=vec4(m2,a2/n);} if(q3<mn){mn=q3;r=vec4(m3,a3/n);}
  o=r;
}`,
PAINT_FS:`#version 300 es
precision highp float; in vec2 vUv;
uniform sampler2D uK; uniform sampler2D uC; uniform sampler2D uD; uniform vec2 uTexel; uniform vec2 uRes;
uniform vec3 uShTint; uniform vec3 uHiTint; uniform vec3 uInk; uniform float uSat; uniform float uSeed;
out vec4 o;
${NOISE}
float dep(vec2 uv){return texture(uD,uv).r;}
void main(){
  vec2 p=vUv*uRes;
  // brush-stroke field
  float ang=fbm(p*.0035+uSeed)*6.2831;
  mat2 R=mat2(cos(ang),-sin(ang),sin(ang),cos(ang));
  vec2 q=R*p;
  float stroke=vnoise(vec2(q.x*.045,q.y*.42))*.65+vnoise(vec2(q.x*.11,q.y*.9))*.35;
  // wobble sample for hand-painted edges
  vec2 wob=(vec2(fbm(p*.012+3.1),fbm(p*.012+9.7))-.5)*uTexel*7.;
  vec2 gk=vec2(dot(texture(uK,vUv+vec2(uTexel.x*2.,0.)).rgb-texture(uK,vUv-vec2(uTexel.x*2.,0.)).rgb,vec3(.333)),
               dot(texture(uK,vUv+vec2(0.,uTexel.y*2.)).rgb-texture(uK,vUv-vec2(0.,uTexel.y*2.)).rgb,vec3(.333)));
  float gm=length(gk);
  vec2 nd=vec2(cos(ang),sin(ang));
  vec2 pd=gm>1e-4?vec2(-gk.y,gk.x)/gm:nd;
  vec2 fd=normalize(mix(nd,pd,smoothstep(.01,.07,gm))+1e-4);
  vec4 k=vec4(0.);float ws=0.;
  float sl=mix(.3,1.35,smoothstep(.01,.07,gm));
  for(int i=-6;i<=6;i++){float w=exp(-float(i*i)/18.);k+=texture(uK,vUv+wob+fd*float(i)*uTexel*sl)*w;ws+=w;}
  k/=ws;
  vec4 c0=texture(uC,vUv+wob*.5);
  vec3 c=mix(k.rgb,c0.rgb,.18);
  // depth + color edges
  float dc=dep(vUv);
  float ex=0.;
  for(int i=-1;i<=1;i++)for(int j=-1;j<=1;j++){ if(i==0&&j==0) continue; float d2=dep(vUv+vec2(i,j)*uTexel*1.5); ex=max(ex,abs(d2-dc)); }
  float lum=dot(k.rgb,vec3(.299,.587,.114));
  float lx=dot(texture(uK,vUv+vec2(uTexel.x*2.,0.)).rgb,vec3(.333))-dot(texture(uK,vUv-vec2(uTexel.x*2.,0.)).rgb,vec3(.333));
  float ly=dot(texture(uK,vUv+vec2(0.,uTexel.y*2.)).rgb,vec3(.333))-dot(texture(uK,vUv-vec2(0.,uTexel.y*2.)).rgb,vec3(.333));
  float ce=length(vec2(lx,ly));
  float inkMask=smoothstep(.0015,.008,ex)*.75+smoothstep(.10,.28,ce)*.35;
  inkMask*=.55+.45*vnoise(p*.25);
  // stroke texture & grain
  c*=.89+.22*stroke;
  c+=(vnoise(p*.006+7.)-.5)*vec3(.05,.0,-.05);
  float grain=vnoise(p*.8)*.6+vnoise(p*2.3)*.4;
  c+=(grain-.5)*.045;
  // grading
  float L=dot(c,vec3(.299,.587,.114));
  c=mix(c,c*uShTint*1.6,smoothstep(.5,.0,L)*.55);
  c=mix(c,c*uHiTint*1.2,smoothstep(.35,.95,L)*.45);
  c=mix(vec3(L),c,uSat);
  c=mix(c,uInk,clamp(inkMask,0.,1.)*.6);
  // pigment pooling in darks
  c*=1.-.08*smoothstep(.2,.0,L)*vnoise(p*.05);
  float a=k.a;
  float ragged=fbm(p*.02+5.);
  a=smoothstep(.35,.65,a+(ragged-.5)*.55*(1.-abs(a*2.-1.)));
  o=vec4(clamp(c,0.,1.),a);
}`,
BACK_FS:`#version 300 es
precision highp float; in vec2 vUv;
uniform sampler2D uBake; uniform sampler2D uBake2; uniform float uMix; uniform vec4 uXf; uniform float uT; uniform float uBright; uniform float uHunger; uniform float uDawn; uniform float uHurt;
uniform vec3 uWash1; uniform vec3 uWash2; uniform vec2 uRes; uniform float uAspect; uniform float uFade;
out vec4 o;
${NOISE}
void main(){
  vec2 uv=vUv*uXf.xy+uXf.zw;
  vec4 b=vec4(0.);
  if(uv.x>0.&&uv.x<1.&&uv.y>0.&&uv.y<1.) b=mix(texture(uBake2,uv),texture(uBake,uv),uMix);
  vec3 c=b.rgb*uBright;
  if(b.a<.995){
    vec2 wp=vec2(uv.x*uAspect,uv.y);
    float w=fbm(wp*2.4+vec2(0.,uT*.004))*.7+vnoise(wp*9.)*.3;
    vec3 wash=mix(uWash1,uWash2,smoothstep(.25,.85,w));
    wash*=.8+.4*vnoise(wp*40.);
    c=mix(wash,c,b.a);
  }
  vec2 sp=vUv-.5; sp.x*=uRes.x/uRes.y;
  float r=length(sp);
  c*=1.-smoothstep(.45,1.15,r)*.55;
  // hunger: arterial veins creeping from the edges
  if(uHunger>0.){
    float ang=atan(sp.y,sp.x);
    float vein=fbm(vec2(ang*3.,r*6.-uT*.08))*.8+vnoise(vec2(ang*24.,r*30.))*.2;
    float edge=smoothstep(.55-uHunger*.18,1.05,r+vein*.18);
    float pulse=.75+.25*pow(.5+.5*sin(uT*5.2),6.);
    c=mix(c,vec3(.35,.01,.04)+c*vec3(.6,.1,.1),edge*uHunger*pulse*.85);
  }
  if(uDawn>0.){
    float edge=smoothstep(.35,1.1,r+fbm(sp*4.+uT*.05)*.15);
    c=mix(c,vec3(1.,.55,.2),edge*uDawn*.7); c+=vec3(.25,.1,0.)*uDawn*edge;
  }
  if(uHurt>0.){c=mix(c,vec3(.6,.02,.05),uHurt*smoothstep(.2,1.,r)*.8);}
  float g=hash12(vUv*uRes+fract(uT*13.)*91.);
  c+=(g-.5)*.035;
  c*=1.-uFade;
  o=vec4(c,1.);
}`,
BLOB_FS:`#version 300 es
precision mediump float; in vec2 vUv2; uniform float uA; out vec4 o;
void main(){float d=length(vUv2-.5)*2.; o=vec4(0.02,0.0,0.03,uA*smoothstep(1.,.15,d));}`,
BLOB_VS:`#version 300 es
layout(location=0) in vec3 aPos; layout(location=2) in vec2 aUv; uniform mat4 uVP; uniform mat4 uM; out vec2 vUv2;
void main(){vUv2=aUv;gl_Position=uVP*uM*vec4(aPos,1.);}`,
PART_VS:`#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in vec4 aCol; layout(location=2) in float aSize;
uniform mat4 uVP; uniform float uPx; out vec4 vCol;
void main(){vCol=aCol;gl_Position=uVP*vec4(aPos,1.);gl_PointSize=max(1.,aSize*uPx);}`,
PART_FS:`#version 300 es
precision mediump float; in vec4 vCol; out vec4 o;
void main(){vec2 p=gl_PointCoord-.5;float d=length(p)*2.;if(d>1.)discard;o=vec4(vCol.rgb,vCol.a*smoothstep(1.,.0,d));}`
};

/* ---------------- GL wrapper ---------------- */
class GLX{
  constructor(canvas,opts){
    opts=opts||{};
    const gl=canvas.getContext('webgl2',{antialias:opts.antialias!==false,alpha:!!opts.alpha,premultipliedAlpha:false,preserveDrawingBuffer:!!opts.preserve,powerPreference:'high-performance'});
    if(!gl) throw new Error('WebGL2 unavailable');
    this.gl=gl; this.canvas=canvas; this.progs={}; this.meshCache=new Map(); this.emptyVao=gl.createVertexArray();
    this.aniso=gl.getExtension('EXT_texture_filter_anisotropic');
  }
  prog(name,vs,fs){
    if(this.progs[name]) return this.progs[name];
    const gl=this.gl, mk=(t,s)=>{const sh=gl.createShader(t);gl.shaderSource(sh,s);gl.compileShader(sh);
      if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS)){const e=gl.getShaderInfoLog(sh);console.error(name,e);throw new Error('Shader '+name+': '+e);}return sh;};
    const p=gl.createProgram();gl.attachShader(p,mk(gl.VERTEX_SHADER,vs));gl.attachShader(p,mk(gl.FRAGMENT_SHADER,fs));gl.linkProgram(p);
    if(!gl.getProgramParameter(p,gl.LINK_STATUS)) throw new Error('Link '+name+': '+gl.getProgramInfoLog(p));
    const P={p,u:{}};const n=gl.getProgramParameter(p,gl.ACTIVE_UNIFORMS);
    for(let i=0;i<n;i++){const info=gl.getActiveUniform(p,i);const nm=info.name.replace(/\[0\]$/,'');P.u[nm]=gl.getUniformLocation(p,info.name);}
    return this.progs[name]=P;
  }
  mesh(g,key){
    if(key&&this.meshCache.has(key)) return this.meshCache.get(key);
    const gl=this.gl,vao=gl.createVertexArray();gl.bindVertexArray(vao);
    const buf=(data,loc,size)=>{const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,data,gl.STATIC_DRAW);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,gl.FLOAT,false,0,0);return b;};
    const bufs=[buf(g.pos,0,3),buf(g.nor,1,3),buf(g.uv,2,2)];
    const ib=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,g.idx,gl.STATIC_DRAW);
    gl.bindVertexArray(null);
    const m={vao,count:g.idx.length,bufs:bufs.concat([ib])};
    if(key) this.meshCache.set(key,m);
    return m;
  }
  meshFor(g){if(!this.wm)this.wm=new WeakMap();let m=this.wm.get(g);if(!m){m=this.mesh(g);this.wm.set(g,m);}return m;}
  freeMesh(m){const gl=this.gl;m.bufs.forEach(b=>gl.deleteBuffer(b));gl.deleteVertexArray(m.vao);}
  tex(canvas,opts){
    opts=opts||{};const gl=this.gl,t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,canvas);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);
    const wrap=opts.clamp?gl.CLAMP_TO_EDGE:gl.REPEAT;
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,wrap);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,wrap);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    if(this.aniso) gl.texParameterf(gl.TEXTURE_2D,this.aniso.TEXTURE_MAX_ANISOTROPY_EXT,4);
    return t;
  }
  target(w,h,depth){
    const gl=this.gl,fb=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,fb);
    const c=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,c);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA8,w,h,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,c,0);
    let d=null;
    if(depth){d=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,d);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.DEPTH_COMPONENT24,w,h,0,gl.DEPTH_COMPONENT,gl.UNSIGNED_INT,null);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
      gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,d,0);}
    gl.bindFramebuffer(gl.FRAMEBUFFER,null);
    return {fb,color:c,depth:d,w,h};
  }
  freeTarget(t){if(!t)return;const gl=this.gl;gl.deleteFramebuffer(t.fb);gl.deleteTexture(t.color);if(t.depth)gl.deleteTexture(t.depth);}
  setLights(P,lights,bright){
    const gl=this.gl,n=Math.min(8,lights.length),lp=new Float32Array(32),lc=new Float32Array(32);
    for(let i=0;i<n;i++){const L=lights[i];lp.set([L.pos[0],L.pos[1],L.pos[2],L.range],i*4);const k=(L.intensity||1)*(bright==null?1:bright);lc.set([L.color[0]*k,L.color[1]*k,L.color[2]*k,0],i*4);}
    gl.uniform1i(P.u.uNL,n); if(P.u.uLP) gl.uniform4fv(P.u.uLP,lp); if(P.u.uLC) gl.uniform4fv(P.u.uLC,lc);
  }
}

NL.V3=V3; NL.M4=M4; NL.GeoB=GeoB; NL.Geo=Geo; NL.SH=SH; NL.GLX=GLX;
})();
