'use strict';
/* THE NEW LORD — Night Three personal arcs, part two: Séverine, Malakor, Soot, Rostova, Miller; new faces at the Reliquary (Lisette, Coral, Lord Ashby); the side quest "The Girl in the Fur Coat" */
(function(){
const X=NL.EXTRAS;
X.lisette={n:'Lisette',color:'#e04050',role:'Hostess of the Gilded Court',spec:{face:{long:1.04,cheek:1.4,jaw:1.1},skin:[.9,.82,.8],hair:{style:'fringe',color:[.05,.04,.05]},shirt:[.6,.05,.08],pants:[.5,.04,.06],lips:[.75,.08,.12],eyeGlow:[.4,.05,.08]}};
X.winter={n:'Winter',color:'#d8e0f0',role:'A Wraith, very still',spec:{face:{long:1.1,cheek:1.7,jaw:1.3},skin:[.62,.64,.7],hair:{style:'long',color:[.85,.85,.9]},mask:'porcelain',coat:{color:[.42,.32,.26],length:.9,collar:true},shirt:[.2,.18,.2],eyes:[.85,.9,1],eyeGlow:[.3,.35,.45],height:.92,alpha:.92}};
const S_=NL.Script;
S_.npc({id:'lisette',room:'reliquary',at:[5.6,3.6,-0.8],pose:'arms',label:'Lisette',if:'night>=2&night<=4&!flag:lisetteGone',node:{first:'ls.0',again:'ls.hub'}});
S_.npc({id:'coral',room:'reliquary',at:[3.0,4.8,0.6],pose:'idle',label:'Coral',if:'night>=2&night<=4',node:{first:'co.0',again:'co.hub'}});
S_.npc({id:'ashby',room:'vip',at:[5.7,3.3,-1.2],pose:'arms',label:'Lord Ashby',if:'night>=3&night<=4&!flag:ashbyDead&!flag:ashbyGone',node:{first:'ab.0',again:'ab.hub'}});
S_.npc({id:'winter',room:'cistern',at:[3.2,3.6,0.4],pose:'idle',label:'A figure under the water',if:'task:s_winter=active&flag:winterFound&!flag:winterDone',node:'wi.0'});
Object.assign(NL.TASKS,{s_mateo:{n:'Halloran Street, 2011',xp:60,cat:'side'},s_coral:{n:'The Understudy',xp:50,cat:'side'},s_duel:{n:'A Matter of Honour',xp:60,cat:'side'}});
NL.ITEMS.wintermask={n:'A Smiling Porcelain Mask',slot:'face',cover:true,look:{mask:'porcelain'},mods:{stagecraft:1,nostalgia:1},d:'Cracked down the middle and mended with gold. The painted mouth is smiling. It has been at the bottom of the Vellum since 1983.',sp:'Winter\'s.'};
})();
NL.Script.add(String.raw`
// =====================================================================
// SÉVERINE · Night Three
// =====================================================================
# sx3.0 arc=severine night=3 label="\"You wanted to see me, my lady?\"" if=room:vip&alive:sev
@focus severine
> Tonight there is no gramophone. Séverine is sitting very straight on the edge of a stone sarcophagus with her hands folded, the way women sat for photographs when photographs took a minute.
severine: I didn't want to see you. I wanted you to come. There's a difference. One is desire. The other is policy.
severine: You've been to the morgue. Don't. Don't lie. You smell of formalin and old water. You've been somewhere you weren't invited, and you've come back changed.
pulse(5): She isn't looking at your face. She's looking at your coat. At the pocket.
@gate has:vessel ? sx3.vessel : sx3.novessel

# sx3.vessel
severine: And you're carrying something that hums.
severine: I can hear it. All the Choir can, if they listen. It sings at the edge of hearing, like a glass when you run a wet finger round the rim. It's singing *noon*.
* "It's mine. It was his, and he's in me."  -> sx3.mine {do lean:pride+1}
* "What would the Court do with it?"  -> sx3.court
? stagecraft 12 "It's a thermos. For blood."  -> sx3.thermos | sx3.thermosno {id sx3_lie}
* Offer it to her.  -> sx3.offer

# sx3.mine
severine: By the law of salvage. Yes. That's what the Magistrate will call it on Friday if you're lucky.
severine: If you're unlucky he'll call it "evidence".
{do mem:severine:mine}
@next sx3.hub

# sx3.court
severine: The Court would do what the Court does with everything dangerous. Put it in a vault, and never speak of it, and hold the key over everyone else's heads for a thousand years.
severine: That is called "keeping the peace". It's what Absalom was supposed to do. It's what he was doing very badly, before he went shopping for sunshine.
web(5): She knows Vane wanted the cure. She's known for some time.
{do mem:severine:courtvault}
@next sx3.hub

# sx3.thermos
severine: ...A thermos. For blood. You walked into Elysium and told the Keeper of Elysium that the most dangerous object in Port Vellum is a *thermos*.
> And then, astonishingly, she laughs. A real laugh, the kind that hurts.
severine: Oh, I've missed that. Nobody's lied to me *badly* on purpose since the Kaiser. Keep your thermos. I'll know where it is.
{do mem:severine:thermos; rel:severine+1}
@next sx3.hub

# sx3.thermosno
severine: Don't insult me in my own crypt. I've been lied to by Popes.
{do rel:severine-1}
@next sx3.hub

# sx3.offer
> She looks at the brass thing in your hand for a long time. She doesn't take it.
severine: You'd just. Give it to me.
severine: Nobody gives me anything. People *pay* me. They *tithe*. They trade. Nobody has ever simply held out their hand.
* "Take it."  -> sx3.gave
* Close your hand again. "I wanted to see your face."  -> sx3.tease {do lean:candour-1}

# sx3.gave
severine: No.
severine: No. If I take it tonight, they'll come for me tomorrow. Malakor, the grey men, all of them. Keep it until Friday. Bring it to the Tribunal. Give it to me *there*, in front of everyone. Then it's not theft. Then it's *tribute*.
{do flag:sevVesselOffered=1; mem:severine:offered; rel:severine+2; lean:loyalty+1}
@next sx3.hub

# sx3.tease
severine: ...Cruel. Good. You're learning.
{do mem:severine:teased}
@next sx3.hub

# sx3.novessel
severine: You've been to the morgue and come back with nothing in your pockets. Either you're cleverer than you look or stupider. I can't decide. I'll let you know on Friday.
@next sx3.hub

# sx3.hub
* "Tell me why you hired a federal agent."  -> sx3.harrow {once} {if flag:knowSevHarrow|flag:tinySawHarrow}
* "You paid Margo Kowalski to break the freezer door."  -> sx3.margo {once} {if flag:margoNamedSev|flag:knowMargoDoor}
* "What happens to me on Friday?"  -> sx3.friday {once}
* "Who is Lisette?"  -> sx3.lisette {once} {if flag:knowLisette|met:lisette|seen:ls.0}
* "Goodnight, my lady."  -> sx3.bye

# sx3.harrow
> The candles in the bone chandelier go out. All of them. At once. Then, one by one, they come back on.
severine: Who told you that.
* "It doesn't matter."  -> sx3.harrowprotect {do lean:loyalty+1}
* "Tiny. On the door."  -> sx3.harrowtiny {if flag:tinySawHarrow} {do lean:loyalty-2}

# sx3.harrowprotect
severine: Everything matters. But fine.
severine: I didn't hire him. He came to me. He said: "Lady Séverine, the Sheriff is about to bring something to your Prince that will end the Court. I can make sure he doesn't." He was very polite. He wore sunglasses in my crypt.
severine: I said I would not raise a hand against Absalom. And I didn't. I fixed a *door*. Doors are not hands.
web(6): She thought Harrow meant to arrest Vane. Or scare him. She didn't ask how. She didn't want to know.
* "You didn't know about the lance."  -> sx3.nolance
* "You knew exactly what he'd do."  -> sx3.knew {do lean:candour+1}

# sx3.nolance
severine: I knew there would be... something. I imagined a scandal. A file. A disgrace. Not a light.
severine: When I heard, on Monday, what had been done to him, I went into the chapel and sat with Brother Anselm for four hours. I don't know why. I hated Absalom. I am told that's not the same as wanting him to burn.
{do mem:severine:confessed; flag:sevConfessed=1}
@next sx3.hub

# sx3.knew
severine: Knew. Suspected. Hoped. Feared. Those are different verbs, child, and in my Court they carry different sentences. Choose carefully which one you say to the Magistrate.
{do mem:severine:accused; flag:sevConfessed=1; rel:severine-1}
@next sx3.hub

# sx3.harrowtiny
severine: Tiny. My Tiny. Nine years on my door.
severine: Thank you. I'll see to it.
tenant: You've just killed a man, child. Slower than with your teeth. But you've done it.
{do flag:tinyBetrayed=1; mem:tiny:betrayed; mem:severine:soldtiny}
@next sx3.hub

# sx3.margo
severine: Mrs. Kowalski. Of course. She would talk. Butchers have no discretion: everything is meat to them.
severine: Yes. I sent five thousand dollars and a note. I am a creature of business. Kowalski's has rendered for the Court for forty years. It was not an unusual request. "Make sure the freezer holds."
severine: I didn't specify what it would hold. That was my genius, and my mistake.
{do mem:severine:margo; flag:sevAdmitMargo=1}
@next sx3.hub

# sx3.friday
severine: On Friday the Prince's Magistrate will come down from the Heights and sit in judgment on you for the death of Absalom Vane. I will accuse you. I am obliged to.
severine: How hard I accuse you depends on what you do between now and then. I could make it a formality. Or I could make it a funeral.
@gate like:severine>=3 ? sx3.fridaygood : sx3.fridaybad

# sx3.fridaygood
severine: As it stands, I'm inclined to a formality. You've been... entertaining. And you've been discreet, which is rarer. Don't spoil it.
{do flag:sevInclined=1}
@next sx3.hub

# sx3.fridaybad
severine: As it stands, I'm undecided. That's dangerous for you. I'm never undecided for long.
@next sx3.hub

# sx3.lisette
severine: My hostess. My hands, when I'd rather not use my own. I found her in Paris in 1931, a year after her painter drowned, lifting a wallet from a Bishop. I admired her technique.
severine: If she's been following you, it's because I asked her to. If she's been *talking* to you, it's because she's decided to, and that's a different matter. Lisette has ambitions.
{do mem:severine:lisette}
@next sx3.hub

# sx3.bye
severine: Go. Be careful on the stairs. The third one is loose. I keep it that way. It reminds people that this is a place where one can fall.
@end

// =====================================================================
// MALAKOR · Night Three
// =====================================================================
# mx3.0 arc=malakor night=3 label="\"Malakor. A word.\"" if=room:switchyard&flag:malakorTalked&alive:malakor
@focus malakor
> Malakor is building a generator. It's taller than he is: copper coils, a flywheel off a locomotive, a glass tube full of something that isn't quite gas and isn't quite light. He's wearing welder's goggles pushed up on his forehead.
malakor: A word. One word? Good. I like a budget. Here is mine: *tomorrow*.
malakor: Tomorrow the Court counts its Kindred, and anyone who isn't counted is hunted. And on Friday the Magistrate comes, and the Ward gets a new Sheriff or a fresh pile of ash. I would like to know which side of the ash you'll be on.
@gate flag:mk_lance|flag:malakorAdmitLance ? mx3.lanceknown : mx3.ask

# mx3.lanceknown
malakor: You know I built the light. You've known since Tuesday. You haven't told the Lady, or she'd have been down here with her ghouls and her opinions.
malakor: Why not?
* "Because you told me the truth."  -> mx3.truth {do lean:candour+1; lean:loyalty+1}
* "Because I'm saving it."  -> mx3.saving {do lean:candour-1}
* "Because I haven't decided what to do with you."  -> mx3.undecided

# mx3.truth
malakor: The truth is a terrible currency. It doesn't keep. But I accept it.
{do mem:malakor:truthkept; rel:malakor+1}
@next mx3.ask

# mx3.saving
malakor: For Friday. Of course. A good Butcher keeps the best cuts for the feast. I'd do the same. I'd respect you less if you didn't.
{do mem:malakor:saving}
@next mx3.ask

# mx3.undecided
malakor: Undecided. The most dangerous state for a knife. Fine. Decide soon. I'm not good at waiting. I've had a hundred years of practice and I'm still bad at it.
@next mx3.ask

# mx3.ask
* "What's the generator for?"  -> mx3.gen {once}
* "Who's R.? The buyer."  -> mx3.r {once}
* "What do you want on Friday?"  -> mx3.want {once}
* "Tell me about the woman. The one who couldn't look at the ninth face."  -> mx3.woman {once} {if mem:malakor.hope|seen:mx2.face}
* "I'll see you."  -> mx3.bye

# mx3.gen
malakor: Light. For Platform 0. The Court has electricity from the city. The Syndicate has had candles and barrels since 1977, when the Court had our cables cut.
malakor: With this, Platform 0 has its own light. Its own power. Nobody can switch us off.
web(5): And nobody can switch on anything else that's wired to Platform 0's lines without passing through his generator. He's thought about the lamps. Or someone told him to.
? autopsy 10 "That tube isn't for light. It's tuned. 4.14 megahertz."  -> mx3.gentuned | mx3.genno {id mx3_gen}

# mx3.gentuned
> He stops. Takes the goggles off. Looks at you with his schoolteacher's face.
malakor: ...Yes. It hums at 4.14. It talks to the lamps. If the lamps are on Platform 0, and if they turn on, my generator will *hear* them. And then, if I choose, it can shout louder.
malakor: I don't trust the grey men. I built their light. I'm building its antidote. Insurance. Like a man who sells guns and wears a vest.
{do flag:malakorAntidote=1; mem:malakor:antidote}
@next mx3.ask

# mx3.genno
malakor: Light. Just light. Don't look so clever, it doesn't suit you yet.
@next mx3.ask

# mx3.r
malakor: R. paid in gold. Krugerrands. A woman, small, dark coat, frightened of me in the way that people who've read too much are frightened. She knew exactly what she was asking for. She corrected my wiring diagram. She was right.
web(6): Rostova. Small, dark coat, a doctor who corrects wiring diagrams.
{do flag:knowRBuyer=1; mem:malakor:r}
@next mx3.ask

# mx3.want
malakor: On Friday I want the Syndicate to have a seat at the table that isn't a folding chair. For a hundred years the Court has ruled the Ward and the Syndicate has *run* it. I want the ruling to match the running.
malakor: And I want whoever wears the Sheriff's coat to owe me. Not like you owe Séverine, in manners. Like you owe a bank.
* "I won't owe anyone."  -> mx3.noowe {do lean:pride+1}
* "What would it cost me?"  -> mx3.cost
* "You'll have your seat."  -> mx3.seat {do promise:malakorseat:Give the Syndicate a real seat if you take the Ward}

# mx3.noowe
malakor: Then you'll stand alone on Friday. That's a very short stand.
@next mx3.ask

# mx3.cost
malakor: A tithe. Ten percent. Like Absalom took. Only you'd be paying it to *me*, for protection from everyone you've annoyed this week. Which is everyone.
@next mx3.ask

# mx3.seat
malakor: Said aloud. In my shop. I'll remember. Butchers have excellent memories for debts. We write them on the inside of our eyelids.
{do mem:malakor:seat; rel:malakor+1}
@next mx3.ask

# mx3.woman
> For a moment the schoolteacher's face goes very still, like a pond freezing.
malakor: Her name was Ilse. Berlin, 1938. A violinist. Mortal. She said my ninth face was "the face of a man who has done a terrible thing and enjoyed it". She was right. So I made a tenth.
malakor: She looked at the tenth and said, "That's worse. Now you're hiding it." She was right again. She was always right. It was insufferable.
malakor: 1943. A Gestapo officer who wanted a new face of his own. She was the price. I didn't know. I found out afterwards.
malakor: I made the eleventh face the next night. Then I went to the officer and took his face back. Slowly. It was the best work I've ever done.
pulse(5): He tells it in the same mild voice he uses for prices. His hands have stopped moving on the generator.
* "I'm sorry."  -> mx3.sorry {do lean:mercy+1}
* "Good."  -> mx3.good {do lean:mercy-1}
* Say nothing.  -> mx3.silent

# mx3.sorry
malakor: Sorry. Hmm. You know, nobody has said that to me in eighty years. They say "how awful", or they say nothing, or they ask how I took the face. Nobody says sorry.
{do mem:malakor:ilse; rel:malakor+2}
@next mx3.ask

# mx3.good
malakor: Yes. Good. You understand. Most people pretend not to.
{do mem:malakor:ilse; rel:malakor+1}
@next mx3.ask

# mx3.silent
> You stand with him in the hum of the generator. After a while he puts the goggles back on.
malakor: Thank you. That was the right thing to say.
{do mem:malakor:ilse; rel:malakor+1}
@next mx3.ask

# mx3.bye
malakor: Tomorrow, then. Don't get counted.
@end

// =====================================================================
// MOTHER SOOT · Night Three · and Winter
// =====================================================================
# ux3.0 arc=soot night=3 label="\"Mother. I need to buy something.\"" if=room:shrine&flag:metSoot
@focus soot
soot: Buy. Buy, buy, buy. Everyone wants to buy on Wednesdays. It's because Thursday is coming, and Thursday is when you find out what you can't afford.
* "A girl called Winter. Fur coat, porcelain mask. 1983."  -> ux3.winter {if task:s_winter=active&!flag:winterFound}
* "The name the Sheriff said on the telephone."  -> ux3.name {if flag:sootHasName&!flag:knowName}
* "Malakor's first face. The photograph."  -> ux3.photo {if flag:knowMalakorPhoto}
* "What's going to happen on Friday?"  -> ux3.friday

# ux3.winter
> Soot goes very still. Even the candles go still.
soot: Oh. Oh, little Winter. Nobody's said that name down here in forty years.
soot: She was mine. One of my children. A Wraith, newly made, so ashamed of her face she made a new one out of porcelain. Gideon gave her a bed every winter. She loved him for it. She'd never say so. Wraiths don't.
soot: 1983. Somebody broke her mask, in the street, for a joke. A Court boy, drunk. They laughed at her real face. She walked away from them, all the way down here, past me, and into the still water.
soot: The Vellum keeps what falls in it. She's still there. Standing at the bottom. In her coat.
* "What will you take for telling me?"  -> ux3.winterprice
* "Is she dead?"  -> ux3.winterdead

# ux3.winterdead
soot: Dead? We're all dead, greedy. She's *stopped*. Like a clock. Torpor. Forty years of it. Wraiths can sleep forever if nothing wakes them.
@next ux3.winterprice

# ux3.winterprice
soot: For Winter? Nothing. I'm not selling Winter. Winter's not for sale.
soot: Go and look. The cistern, the deep end, past the third candle-raft. Take a light. Don't wake her unless you mean it.
{do flag:winterFound=1; note:s_winter|Winter walked into the still water of the Vellum Cistern in 1983 and never came out. She's standing at the bottom, in torpor, past the third candle-raft. Don't wake her unless you mean it.; mem:soot:winter; rel:soot+1}
@end

# ux3.name
soot: The name. Yes. I said I'd keep it warm. It's warm. It's very warm.
soot: A big secret for it. Or a big favour. Or a little bit of you. Your choice, greedy.
* Give her a big secret: what the Sheriff's letter said.  -> ux3.nameletter {if flag:readVaneLetter}
* "A favour. Name it."  -> ux3.namefavour
* "A little bit of me?"  -> ux3.nameblood
* "Not tonight."  -> ux3.hubend

# ux3.nameletter
> You tell her. The cure, the seven, the eighth, LANTERN, the Prince on Friday. She listens with her ear pressed to your sleeve as if you were a pipe.
soot: Ohhh. Oh. Oh, that's the best thing I've heard since 1945. That's a JAR. That's a big jar all of its own.
@next ux3.nameplay

# ux3.namefavour
soot: A favour. On Friday, when the Magistrate asks who heard what, I want you to let me speak first. Before the Lady. Before anyone. Mm. That's all. That's all.
{do flag:sootSpeaksFirst=1; promise:sootfirst:Let Mother Soot speak first at the Tribunal}
@next ux3.nameplay

# ux3.nameblood
soot: A drop. Just a drop. On my tongue. I'd like to know what you taste like, little house full of people.
> She doesn't wait for an answer. Her tongue is very cold. When she pulls back her eyes are wide and full of other people's faces.
soot: Oh. Oh, there's so many of you in there.
{do vitae-1; flag:sootTasted=1; mem:soot:tasted}
@next ux3.nameplay

# ux3.nameplay
> She takes down a jar from a high shelf. It's very old. She pulls the cork. Out of it, faint, crackling, like a telephone call from the bottom of the sea, the Sheriff's voice:
> *"...I'll pick them up outside St. Jude's at nine. Yes. Casey. Casey Morrow. They've asked to be called Casey. Don't make a fuss about it, Pemberton, it's the twenty-first century..."*
nostalgia: Casey. Casey Morrow. It goes into you like a key into a lock you'd forgotten was a lock.
{do flag:knowName=1; flag:trueName=1; flag:frag_jar=1; mem:soot:name; xp:50:Your name; comp+2:Casey}
tenant: ...Casey. Yes. That's right. I'm sorry I didn't tell you. I didn't know it was gone. I thought you were keeping it from me.
@end

# ux3.photo
soot: Malakor's first face. Odessa, 1922. A boy of twenty with a crooked nose and ears like a jug. Very ugly. Very kind-looking. Mm.
soot: For that, a favour. A small one. Carry a bone-microphone into Malakor's shop and leave it under the dentist's chair. That's all. That's all.
* "Done."  -> ux3.photodo {do flag:sootMalakorBug=1; lean:loyalty-1}
* "No. I won't spy on him."  -> ux3.photono {do lean:loyalty+1}

# ux3.photodo
> She gives you a little bone thing, like a knuckle with a wire in it, and a photograph, brown and soft as a leaf. A jug-eared boy squinting at the sun.
soot: Give him that. Or don't. It's yours now. Mm.
{do give:bug; flag:haveMalakorPhoto=1}
@end

# ux3.photono
soot: Loyal. To a butcher. Mm. How unusual. Here. Take it anyway. Loyalty's a secret too, and I've just learned yours.
{do flag:haveMalakorPhoto=1; mem:soot:loyal}
@end

# ux3.friday
soot: On Friday everyone will say what they know. Most of them will lie. I won't. I never lie. I just choose which truth to whisper.
soot: The Lady will accuse. The butcher will bargain. The grey men will be listening from the street, through my own pipes. And you will stand in a chalk circle with the whole Ward looking at you, and they will all, every one of them, be deciding what you taste like.
@end

# ux3.hubend
soot: Then go, greedy. The name will keep. Names always keep. It's people who don't.
@end

// =====================================================================
// THE GIRL IN THE FUR COAT · the cistern
// =====================================================================
# wi.0
@focus winter
> Past the third candle-raft, where the water is deepest and darkest, a shape stands at the bottom of the cistern. You can see it through the black water by the candlelight: a woman in a long mink coat, standing upright on the old river bed, hands at her sides, perfectly still. Her hair floats around her like weed.
> On the bottom, beside her feet, two halves of a porcelain mask with a painted smile.
echo(4): No movement. No current. Nothing has disturbed this water in forty years. Not a bubble.
tenant: Winter. Good God. I knew her. I *knew* her. She used to sit on the Courthouse steps at three and count the stars. I never asked her name. I never asked anyone's name.
* Go down. Bring up the mask.  -> wi.mask
* Go down. Wake her.  -> wi.wake {blood 2}
* Leave her be. Tell Gideon where she is.  -> wi.leave {do lean:mercy+1}

# wi.mask
> The water is so cold it feels like a sound. You go down through it with your eyes open, past the candle-light, into the dark, and pick up the two halves of the mask from beside her feet. Her face, up close, is grey and sunken and peaceful. She looks asleep. She looks like someone who finally stopped being looked at.
> You come up. The mask is in your hands, dripping.
{do give:wintermask; flag:winterDone=mask; xp:30:Winter's mask; note:s_winter|You brought Winter's broken mask up from the bottom of the Vellum. She's still sleeping. Take the mask to Gideon.}
@end

# wi.wake
> You go down and take her face in your hands and open your own wrist against her mouth, and the black water goes red, and for a long time nothing happens.
> Then her eyes open. Pale, pale blue. She looks at you through the water. She looks *up*, at the candlelight above, and you can see her remember: the street, the laughter, the mask breaking.
> You bring her up. She lies on the stone at the edge of the cistern in her soaking coat with her hands over her face, shaking.
winter: ...Don't look. Don't. Please.
* Give her your coat to hide her face.  -> wi.coat {do lean:mercy+1}
* "Your face is fine. Let them look."  -> wi.face {do lean:candour+1}
* Hand her the broken mask.  -> wi.handmask

# wi.coat
> You put the Sheriff's coat over her head like a tent. Inside it, very small, she stops shaking.
winter: ...What year is it?
> You tell her. A long silence from inside the coat.
winter: Gideon. Is Gideon alive? The man with the boxes. Is he alive?
* "He's alive. He kept your box."  -> wi.gideon

# wi.face
winter: Fine. FINE. You don't know. You've got a face that still looks like a face.
winter: ...Is it true? That it's fine?
pulse(4): Her face is grey and sunken and the skin is pulled tight over the bones like wet paper. It's a Wraith's face. It's not fine. It's hers.
* "It's yours. That's better than fine."  -> wi.gideon {do rel:winter+1}
* "No. But I'm not afraid of it."  -> wi.gideon

# wi.handmask
> She holds the two halves of the smile together over her real mouth with trembling hands.
winter: Broken. It's broken. He laughed. The boy with the ring. He laughed so hard he fell over.
winter: Do you know who he was? He had a crown on his ring. A little crown.
pedigree(5): A Court signet. A drunk Court boy in 1983. You could find out who. Ashby would know. Ashby knows everyone who was young and stupid in the eighties.
{do flag:winterAskCulprit=1}
@next wi.gideon

# wi.gideon
winter: He kept my box. Forty years.
> She laughs, or sobs. With Wraiths, as with Hounds, it's the same sound.
winter: Take me to him. Not now. I can't. Tell him... tell him the first frost. Tell him I'm coming at the first frost. Like always.
{do flag:winterDone=woken; flag:winterAwake=1; xp:60:Winter; note:s_winter|Winter is awake. She asked you to tell Gideon she's coming "at the first frost, like always".; mem:winter:woke}
@leave winter

# wi.leave
> You stand at the edge of the water a long time. She doesn't move. She looks very peaceful down there, in her coat, with her face turned to nobody at all.
{do flag:winterDone=left; note:s_winter|Winter is standing at the bottom of the Vellum Cistern, asleep. You left her there. Tell Gideon.}
@end

# gx3w.0 arc=gideon night=3,4,5 label="\"Gideon. I found Winter.\"" if=room:pawn&task:s_winter=active&flag:winterDone prio=5
@focus gideon
gideon: Found her. You found her.
> He takes his loupe out of his eye. He puts it down on the counter. He doesn't look up.
@gate flag:winterDone=woken ? gw.woke : gw.next

# gw.next
@gate flag:winterDone=mask ? gw.mask : gw.left

# gw.woke
> You tell him. The water, the coat, the blue eyes opening. *Tell him the first frost. Like always.*
gideon: ...The first frost. That's November. That's three weeks.
gideon: I'll air the box out. The lid sticks. I'll fix the lid. Fifty years I've been meaning to fix the lid.
> He goes into the back. You hear him moving things for a while. When he comes out his eyes are red and he's carrying a small velvet case.
@next gw.reward

# gw.mask
> You put the two halves of the porcelain smile on his counter, still damp from the Vellum.
gideon: That's hers. That's her face. The one she wanted.
gideon: Is she... no. Don't tell me. If you brought the mask and not her, she's still down there. Sleeping. Fine. Fine. Let her sleep.
> He fits the halves together with his jeweller's fingers. Then he takes out a tube of gold lacquer and a fine brush and begins, very slowly, to mend the crack.
gideon: Kintsugi. The Japanese do it. Gold in the broken place. It's worth more after. Come back tomorrow. I'll have it done.
{do take:wintermask}
@next gw.reward

# gw.left
> You tell him where she is. The still water, the coat, the hands at her sides. Peaceful.
gideon: Peaceful. Good. She was never peaceful up here. Not once in eleven years.
gideon: I'll go down. Before I die. I'll go down and sit with her. Soot will let me, if I bring the watch.
@next gw.reward

# gw.reward
gideon: I said I'd pay. Not money. Here.
> The velvet case. Inside, on a bed of old satin, a key. Brass, heavy, worn smooth.
gideon: Box eleven. Séverine's box. The one she sits in on Christmas Eve. I've always had a spare key. I've never used it. If you ever need to put something somewhere the Lady will never look, because she can't imagine anyone would dare: there.
gideon: And this. My father's rule, which I've never told a customer. *Sunrise guaranteed* means I've had a man on the roof every dawn since 1971 with a tarpaulin and a mirror. If anyone ever comes for you here, in the day, he'll see them first.
{do task:s_winter=done; flag:box11Key=1; flag:gideonWatchman=1; rel:gideon+2; lean:loyalty+1; xp:40:The Girl in the Fur Coat; mem:gideon:winterfound}
@end

// =====================================================================
// DR. ROSTOVA · Night Three · after the Tuesday room
// =====================================================================
# rx3.0 arc=rostova night=3 label="\"I've seen the basement, doctor.\"" if=room:stjude&alive:rostova&seen:tr.0
@focus rostova
> Rostova is in the supply room with the door open, counting saline bags on a clipboard she isn't writing on. She hears you and doesn't turn round.
rostova: I know. The cots. The names on the cards. Number eight.
rostova: You were number eight.
* "You did it to me."  -> rx3.you
* "Why?"  -> rx3.why
* "Seven people are dead."  -> rx3.dead

# rx3.you
rostova: Yes.
rostova: You came in in October with a cough and no insurance. I said, there's a trial, it pays, it's blood work. You signed. You were a good subject. You never complained. You read Russian novels on the cot. You told me I looked like I needed a holiday.
rostova: Then one night the Sheriff walked through my basement like a ghost through a wall and stopped at your cot and talked to you for an hour. And you left with him. You withdrew. I let you. I told myself it was one less on my conscience.
nostalgia(6): A cot. A Russian novel, *The Idiot*, broken-spined. A tall man in a grey coat sitting on the next cot, asking you what you were reading.
{do mem:rostova:eight; flag:rostovaAdmitEight=1}
@next rx3.hub

# rx3.why
rostova: Because his blood worked. Do you understand? I put the Sheriff's blood in a mortal and the mortal could stand in sunlight for six minutes. SIX MINUTES. Then twelve. Then the seizures started.
rostova: Dani Okafor stood in the sunlight on the roof for twenty-two minutes and laughed and then she bled from her eyes and I held her head while she died.
rostova: I could have stopped then. I should have stopped then. Harrow said: "Twenty-two minutes, doctor. Imagine what you'll do with the next one."
{do mem:rostova:why; flag:knowDaniDeath=1}
@next rx3.hub

# rx3.dead
rostova: Seven. I know. I know their blood types. I know their middle names. I know who was allergic to latex. I know that Pete Sowa wanted to be buried at sea and Luis Ferreira wanted his mother to have his watch.
rostova: They didn't get any of that. They went to Kowalski's in sheets.
pulse(5): She's not crying. She's past crying. She's somewhere the other side of it, where people go very calm and start making plans.
{do mem:rostova:dead}
@next rx3.hub

# rx3.hub
* "Did you fire the lance?"  -> rx3.lance {once}
* "Testify. Friday. Tell the Magistrate."  -> rx3.testify {once}
* "Run. Tonight. I won't stop you."  -> rx3.run {once} {if !flag:rostovaRun}
* "I'm going to kill you, doctor."  -> rx3.kill {once}
* Leave her with her saline.  -> rx3.bye

# rx3.lance
> She puts the clipboard down.
rostova: Ask me tomorrow. On the roof. Midnight. I'll tell you everything on the roof. I can't say it in here. In here it's a hospital. In here I'm still a doctor.
{do flag:rostovaRoofDate=1; mem:rostova:roof}
@next rx3.hub

# rx3.testify
rostova: In front of a room of your kind. Who'll eat me afterwards.
rostova: ...Maybe. Maybe that's fair. Ask me on the roof.
{do mem:rostova:askedtestify}
@next rx3.hub

# rx3.run
rostova: Run where? Harrow owns my passport. He owns my licence. He owns the Volvo, technically, it's leased through the program.
rostova: But thank you. That's the second time a monster's been kinder to me than my own government.
{do flag:rostovaRun=1; mem:rostova:offeredrun; lean:mercy+1}
@next rx3.hub

# rx3.kill
rostova: Yes. Probably. I've thought about that, too. I'd prefer the roof. It has a better view.
tenant: Don't, child. Not here. Not like this. If she dies in a supply cupboard, all she knew dies with her.
{do mem:rostova:threatened; lean:mercy-1}
@next rx3.hub

# rx3.bye
rostova: Tomorrow. The roof. Bring whatever you need to bring.
@end

// =====================================================================
// MILLER · Night Three · in the morgue
// =====================================================================
# ix3.0 arc=miller night=3 label="\"What are you doing down here, Ines?\"" if=room:morgue&actor:miller
@focus miller
miller: Ines. Nobody calls me Ines. My mother calls me Ines when she wants money.
miller: I'm doing what I do. Looking. I followed the shipping dates from Kowalski's. The bodies come here first. This is where the paper starts.
pulse(4): She's been here an hour. She's cold, she's scared, and she's in a room full of drawers with a vampire. Her hand is on her holster and she's pretending it's on her hip.
* "It's not safe down here for you."  -> ix3.unsafe
* "Help me with drawer B-14."  -> ix3.help {if !flag:drawerOpened}
* "Your brother. Mateo. 2011."  -> ix3.mateo {if fact:miller:brother}

# ix3.unsafe
miller: It's not safe anywhere for me. I'm a detective in Precinct 9 who asks questions. Do you know how many of us there are? One. There's one.
{do mem:miller:unsafe}
@end

# ix3.help
miller: Help you. Open a morgue drawer. Without a warrant, in the middle of the night, for a... person... who doesn't blink.
miller: Sure. Why not. It's been that kind of week.
{do flag:millerHelpsDrawer=1; mem:miller:drawer; rel:miller+1}
@end

# ix3.mateo
> Her hand comes off the holster.
miller: How do you know about Mateo.
* "Your file. At the precinct. I've been reading."  -> ix3.mateofile {do lean:candour-1}
* "I'm not sure. I just know."  -> ix3.mateoknow
* "Tell me about him."  -> ix3.mateotell

# ix3.mateofile
miller: My file. Christ. Fine. Everyone's read my file.
@next ix3.mateotell

# ix3.mateoknow
miller: You "just know". Like a psychic. Like the woman on Channel 9 who finds dogs.
@next ix3.mateotell

# ix3.mateotell
miller: Mateo. My little brother. Nineteen. He went out to buy cigarettes in 2011 on Halloran Street and didn't come back. Nobody found anything. The case is still open. I keep it open. I sign it out every year so it doesn't go to archive.
miller: That's why Missing Persons. That's why the Marrow Ward. That's why I can't stop. You understand? Seven is just the latest seven.
nostalgia(4): Halloran Street, 2011. Mother Soot's pipes would know. Soot knows every street.
{do mem:miller:mateo; flag:knowMateo=1; task:s_mateo; note:s_mateo|Detective Miller's brother Mateo went missing on Halloran Street in 2011 at nineteen. She has kept his case open for thirteen years. Someone in the Ward knows what happened.}
@end

// =====================================================================
// LISETTE · the Court's hostess
// =====================================================================
# ls.0
@focus lisette
> A woman in red leaning on a pillar, watching the dancefloor the way a cat watches a fishtank. Black hair cut sharp at the jaw. A ring with a little crown. She sees you see her and smiles with all of her teeth.
lisette: Ah. *Le nouveau.* The one everybody is counting doors for. I'm Lisette. I arrange things for Madame.
lisette: You want to know why I've been following you. Everybody does, after a while. It's very flattering.
* "Why have you been following me?"  -> ls.why
* "You booked Leo for Thursday."  -> ls.leo {if flag:knowLisette|flag:leoGig}
* "What do you want?"  -> ls.want

# ls.why
lisette: Because Madame asked me to. And because I wanted to see what kind of creature eats a Sheriff and then goes home and *apologizes* to the boy it bit. Yes. I listen at windows. It's my best quality.
{do mem:lisette:why}
@next ls.hub

# ls.leo
lisette: The little comedian! Yes. He's very good. Madame wants him downstairs on Thursday, in front of the whole Court, telling jokes about the freezer. She thinks it'll be amusing to see who laughs. She thinks it'll be *informative* to see who doesn't.
lisette: She also wants him where she can find him. He saw something on Monday. She'd like to know what before anyone else does.
web(5): A gig as an interrogation. Leo telling his freezer story to a room full of Kindred, and Séverine watching faces.
* "Cancel it."  -> ls.cancel
* "If anyone touches him, I'll come for you first."  -> ls.threat {do lean:pride+1}
* "What would it take for you to look after him?"  -> ls.deal

# ls.cancel
lisette: Cancel. I can't cancel Madame. I can only... misplace things. Calendars. Comedians.
? velvet 10 "Then misplace him."  -> ls.misplace | ls.nomisplace {id ls_vel} {mod like:lisette}

# ls.misplace
lisette: Hm. For you? Why not. It would annoy her. I like annoying her a little, carefully, like stroking a cat the wrong way.
lisette: The boy will get a call on Thursday saying the gig has been "postponed". He'll be sad. He'll live. Those are both good outcomes.
{do flag:leoGigCancelled=1; mem:lisette:misplaced; rel:lisette+1}
@next ls.hub

# ls.nomisplace
lisette: Oh, no. You don't know me well enough to ask me to disobey. Come back when you do.
@next ls.hub

# ls.threat
lisette: First. Lovely. I'll put it in my diary. "Thursday: threatened by somebody cute."
{do mem:lisette:threatened}
@next ls.hub

# ls.deal
lisette: Look after him? Like a nanny? I'm not a nanny. I'm a *hostess*.
lisette: ...But I'd watch him. Downstairs. If you did something for me. A small thing. I want to know what the Sheriff kept in his study. The real one, not the one in your head. His rooms above the Courthouse. Madame has never been allowed in. Nor have I. I'm *dying* to know.
{do flag:lisetteWantsStudy=1; mem:lisette:deal}
@next ls.hub

# ls.want
lisette: Want? Madame's chair. Eventually. Not now. Now I want to be the person standing behind it when it changes hands.
lisette: And I think, *mon chou*, that might be you. Or someone you choose. So I'd like to be near you. Close enough to see which way you'll jump.
pedigree(5): She just told you she's planning to betray Séverine. Out loud, on the dancefloor. Either she trusts you, or she wants you to think she does.
{do mem:lisette:ambition; flag:lisetteAmbition=1}
@next ls.hub

# ls.hub
* "Who in the Court wears a crown ring and laughs at Wraiths?"  -> ls.crown {once} {if flag:winterAskCulprit}
* "Goodbye, Lisette."  -> ls.bye

# ls.crown
lisette: Half of them. But laughing at Wraiths, in the eighties? Ashby's set. The Sovereign boys. Ashby himself was very funny in 1983, I hear. He's been very sorry ever since. It's his favorite feeling.
{do flag:knowAshbyWinter=1}
@next ls.hub

# ls.bye
lisette: *À bientôt.* I'll be watching your doors.
@end

// =====================================================================
// CORAL · a dancer at the Reliquary
// =====================================================================
# co.0
@focus coral
> A dancer in a pink slip dress sitting on the edge of the stage with her shoes off, rubbing her feet, with the professional exhaustion of someone who has danced for eight hours for people who don't sweat.
coral: You're not here to dance. Nobody who looks like that is here to dance.
coral: Coral. Don't ask what my real name is, it's worse.
pulse(4): Mortal. Warm. Tired. Two old bite marks on the inside of her elbow, healed white. Somebody downstairs uses her regularly.
* "Who downstairs feeds on you?"  -> co.who
* "You look exhausted."  -> co.tired
* "What do the mortals up here know?"  -> co.know

# co.who
coral: Wow. Straight in. Okay.
coral: Lord Ashby, Thursdays. He's very polite. He brings flowers. He tips. He says "thank you, my dear" like I'm a waiter. It's fine. It's a job. It pays my sister's college.
coral: Except last week he didn't stop when I said stop. Not long. Just a second. Two. Like he forgot I was there.
* "That's not fine."  -> co.notfine {do lean:mercy+1}
* "Do you want me to talk to him?"  -> co.talk
* "That's the deal you made."  -> co.deal {do lean:mercy-1}

# co.notfine
coral: No. I know. But it's two grand a month and the alternative is the waitress job at the Lucky Mart, and Tariq can't afford me.
{do mem:coral:notfine}
@next co.quest

# co.talk
coral: Talk to Lord Ashby. You. A new... whatever you are. To a Sovereign. They don't *talk* to people like you. They duel them. In the crypt. With swords. It's ridiculous. It's very ridiculous and people die.
{do mem:coral:talk}
@next co.quest

# co.deal
coral: Yeah. It is. Thanks for the reminder.
{do mem:coral:deal; rel:coral-1}
@end

# co.quest
coral: If you could get him to remember I'm a person. Just that. Not stop. Just remember.
{do task:s_coral; note:s_coral|Coral, a dancer at the Reliquary, lets Lord Ashby feed on her on Thursdays. Last week he didn't stop when she said stop. She wants him to remember she's a person.}
@end

# co.tired
coral: Eight hours. Pink slip. Cold floor. Men who look at me like a menu, and things that look at me like a meal. It's very different. You get to know the difference.
coral: You look at me like... I don't know. Like a person at a bus stop. That's new.
{do mem:coral:busstop; rel:coral+1}
@end

# co.know
coral: Up here? We know there's a downstairs. We know they're rich and old and weird and they pay double for O-negative girls. We know not to ask. Half of us think it's a cult. Half of us think it's vampires. The smart half doesn't care.
@end

# co.hub
* "How are you, Coral?"  -> co.how
* "I talked to Ashby."  -> co.done {if flag:ashbyCoral}
* "See you."  -> end

# co.how
coral: Same. Feet hurt. Sister's doing well. She got a B in organic chemistry. I don't know what organic chemistry is. I'm paying for it with my elbows.
@end

# co.done
@gate flag:ashbyCoral=promised ? co.done1 : co.done2

# co.done1
coral: He sent flowers. With a card. It said "My apologies, Miss Coral. I forgot myself. It will not recur." He spelled my name right. He's never spelled my name right.
coral: Thank you. I don't know what you said. I don't want to know. Thank you.
{do task:s_coral=done; rel:coral+2; lean:mercy+1; xp:40:The Understudy}
@end

# co.done2
coral: He doesn't come up any more. He sends a car for me instead. Another girl says he asked for "someone who won't make a fuss".
coral: So that's that, I suppose. Someone else's elbows now.
{do task:s_coral=done; rel:coral-1}
@end

// =====================================================================
// LORD ASHBY · a Sovereign in the crypt · A Matter of Honour
// =====================================================================
# ab.0
@focus ashby
> A tall Sovereign in a white tie and a velvet jacket the color of old claret, examining the bone chandelier through a quizzing glass as if he were thinking of buying it. He has the face of a man who has been painted by somebody important.
ashby: Ah! The diablerist! The *notorious* diablerist. Edmund Ashby, at your service. Ninth Baronet of nothing whatsoever, since my estates went to the National Trust in 1951.
ashby: I've wanted to meet you all week. One so rarely meets anyone new in Elysium. Everyone here has been dead for so long they've started to repeat themselves. I know I have.
* "What do you want with me, my lord?"  -> ab.want
* "Coral. The dancer upstairs."  -> ab.coral {if task:s_coral=active}
* "A Wraith in a fur coat. 1983. You laughed."  -> ab.winter {if flag:knowAshbyWinter|flag:winterAskCulprit}

# ab.want
ashby: Want? Only to look at you. And to ask: did you enjoy it? Absalom? Everyone wants to know and nobody's vulgar enough to ask. I'm famously vulgar. It's my only distinction.
* "Yes."  -> ab.yes {do lean:candour+1}
* "That's none of your business."  -> ab.business {do lean:pride+1}
* "I'm told you're very good with a sword."  -> ab.sword

# ab.yes
ashby: Ha! Wonderful. Honest! Absalom was never honest about anything except money.
{do mem:ashby:honest; rel:ashby+1}
@next ab.hub

# ab.business
ashby: Quite right. Quite right. Forgive me. I was raised by a nanny and a pack of foxhounds and I've never been sure which taught me less.
@next ab.hub

# ab.sword
ashby: Good? I'm *superb*. Fencing master to the Prince's household, 1910 to 1923. I've fought forty-one duels in Elysium and lost one, to a woman, in 1931, which is a story for another time.
ashby: Are you challenging me? Please say yes. Please. I'm so terribly bored.
{do flag:ashbyDuelOffer=1}
@next ab.hub

# ab.coral
ashby: Miss Coral? Charming girl. Very sweet blood, Sanguine, like drinking a peach. Why?
* "She said stop and you didn't."  -> ab.coralstop
? pedigree 10 "A gentleman never takes more than is offered, my lord."  -> ab.coralgent | ab.coralno {id ab_ped}
* "I challenge you. For her."  -> ab.duel

# ab.coralstop
ashby: I...
> For a moment the painted face goes slack, like a puppet with its strings cut.
ashby: Did I? Last Thursday? I. I was distracted. My tontine. Bad news from the lawyers. I suppose I. Good God. Did I hurt her?
* "You frightened her. You forgot she was a person."  -> ab.coralremind {do lean:candour+1}
* "Make it right."  -> ab.coralright

# ab.coralremind
ashby: Forgot she was a person. Yes. That's the vice, isn't it. One starts as a gentleman who drinks and ends as a drink with a gentleman attached.
ashby: I'll send flowers. And a card. Spelled correctly. And I'll not touch her again unless she asks me twice.
{do flag:ashbyCoral=promised; mem:ashby:coral; rel:ashby+1}
@next ab.hub

# ab.coralright
ashby: Right. Yes. Yes, of course.
{do flag:ashbyCoral=promised; mem:ashby:coral}
@next ab.hub

# ab.coralgent
ashby: ...Touché. Touché, damn you. You've drawn blood. Proverbially.
ashby: You're right. I'll make amends. Flowers. A card. Restraint. Restraint is so dreadfully unfashionable these days.
{do flag:ashbyCoral=promised; mem:ashby:coral; rel:ashby+1}
@next ab.hub

# ab.coralno
ashby: Don't quote etiquette at me, young thing. I *wrote* half of it.
@next ab.hub

# ab.winter
> The quizzing glass drops on its ribbon. He doesn't catch it.
ashby: Oh. Oh, God. The little Wraith. On Reliquary Row. With the mask.
ashby: I was drunk. We were all drunk. Freddie Carstairs knocked it off her face for a bet and it broke on the curb and she looked at us and her face was... and I laughed. I laughed because Freddie laughed. I laughed and I *fell over*.
ashby: I've thought about her face every night for forty years. I went looking for her, in '84. Nobody would tell me anything. I thought she'd met the sun.
* "She walked into the cistern and stopped."  -> ab.wintertell
* "Freddie Carstairs. Where is he now?"  -> ab.freddie

# ab.wintertell
ashby: The cistern. The still water. Forty years.
> He sits down on a sarcophagus very heavily, the way old men sit, though he looks thirty.
ashby: Is there anything... can anything be done? I have money. I have nothing but money. Tell me what to do with it.
* "Pay for her box at Gideon's. Forever."  -> ab.winterpay {do flag:ashbyPaysWinter=1; rel:ashby+1}
* "Apologize to her. In person. When she wakes."  -> ab.winterapol {do flag:ashbyApologise=1}
* "Nothing. Live with it."  -> ab.winterlive {do lean:mercy-1}

# ab.winterpay
ashby: Forever. Yes. I'll set up a trust. In perpetuity. The Winter Trust. With a stipend for a man with a tarpaulin.
{do mem:ashby:winter}
@next ab.hub

# ab.winterapol
ashby: In person. Yes. On my knees, if she'll have it. I'll be very bad at it. I've never apologized properly in my life.
{do mem:ashby:winter}
@next ab.hub

# ab.winterlive
ashby: Live with it. I've been doing that. It's the only thing I'm good at apart from swords.
{do mem:ashby:winter}
@next ab.hub

# ab.freddie
ashby: Freddie met the sun in 1999 on a yacht in Monaco. Fell asleep on deck. Nobody liked him very much. There was a small party.
@next ab.hub

# ab.duel
ashby: A challenge! For a lady's honour! Oh, you *darling*. Oh, it's 1910 again.
ashby: First blood, in the chapel, tonight. If you win, I'll do as you say about Miss Coral. If I win, you'll owe me a dinner and a confession: what Absalom tasted like. In detail. With adjectives.
@next ab.duelgo

# ab.hub
* "I challenge you, my lord. First blood."  -> ab.duelgo {if flag:ashbyDuelOffer&!flag:ashbyDueled}
* "Good night, my lord."  -> ab.bye

# ab.duelgo
> He hands you a sword from a rack behind the sarcophagi. It's a real sword. Old, light, terrifyingly sharp. He takes another. He salutes. Séverine, from her seat across the crypt, puts down her book to watch.
? rigor 12 "Hold your ground. Let him come to you. Wait for the opening."  -> ab.duelwin | ab.duellose {id ab_duel} {mod flag:steadyHands?2,clan:hounds?1,clan:butchers?1}
* Cheat. Use your Beast.  -> ab.duelcheat {blood 1}
* "On second thoughts, no."  -> ab.bye

# ab.duelwin
> He's fast. He's beautiful. He's been doing this since before your grandparents were born. And he's showing off, every pass, every flourish, and on the ninth pass he flourishes once too often and you put the tip of the sword through the claret velvet of his sleeve and into the arm underneath.
> One drop of blood on the flagstones. Then a little round of applause from somewhere in the shadows.
ashby: First blood. FIRST BLOOD. Oh, magnificent. Oh, I haven't lost since 1931.
ashby: Name your terms, sir, madam, whichever. I'm yours.
{do flag:ashbyDueled=win; flag:ashbyCoral=promised; rel:ashby+2; lean:pride+1; xp:50:First blood; task:s_duel; task:s_duel=done}
severine: (from across the crypt) Well. Well, well.
@next ab.hub

# ab.duellose
> He disarms you on the fourth pass with a twist that you don't even see. Your sword skitters across the crypt and fetches up against Brother Anselm.
ashby: First blood is mine, I think. Just a nick. There. On your cheek. Lovely. It'll heal by morning.
ashby: Dinner, then. And a confession. I'll send a card.
{do flag:ashbyDueled=lose; flag:ashbyDinner=1; rel:ashby+1; task:s_duel; task:s_duel=done; comp-1:Disarmed}
ashby: ...And you were right about Miss Coral, you know. I'll mind myself. One can lose and still be correct. I've done it all my life.
{do flag:ashbyCoral=promised}
@next ab.hub

# ab.duelcheat
> You let the Beast in for a second. Just one. It's enough. You're on him before his sword comes round, and your teeth are at his throat, and the whole crypt goes silent.
> You stop. You have to stop. His blood is in your mouth. It tastes of three centuries of claret.
ashby: ...That. That was not a duel.
severine: No. It was a *disgrace*. In Elysium. In my crypt.
{do flag:ashbyDueled=cheat; rel:ashby-3; rel:severine-2; lean:pride-2; heat+1; task:s_duel; task:s_duel=done}
@end

# ab.bye
ashby: Good night! Good night. Do come back. You're the most interesting thing that's happened to me since the Abdication.
@end
`,'c_n3b');
