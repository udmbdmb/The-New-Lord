'use strict';
/* THE NEW LORD — Act II locations: the Rookery, apartments, Platform 0, Mother Soot's shrine */
(function(){
const NL=window.NL;const {Geo,M4}=NL;const PI=Math.PI;const ROOMS=NL.ROOMS,M=NL.M,mats=NL.mats,TX=NL.Tex,P=NL.PROPS,xm=NL.xm;
function sign(txt,o){o=o||{};return()=>{const w=o.w||512,h=o.h||128,c=TX.cv(w,h),x=c.getContext('2d');if(o.bg){x.fillStyle=o.bg;x.fillRect(0,0,w,h);}if(o.frame){x.strokeStyle=o.frame;x.lineWidth=6;x.strokeRect(5,5,w-10,h-10);}
  x.font=o.font||'800 64px "Barlow Condensed",sans-serif';x.textAlign='center';x.textBaseline='middle';if(o.glow){x.shadowColor=o.glow;x.shadowBlur=o.blur||20;}x.fillStyle=o.fg||'#fff';
  (Array.isArray(txt)?txt:[txt]).forEach((t,i,a)=>x.fillText(t,w/2,h/2+(i-(a.length-1)/2)*(o.lh||70)));return c;};}
TX.add('wallpaper',()=>{const c=TX.cv(512),x=c.getContext('2d'),R=TX.rng(401);x.fillStyle='#6d5a48';x.fillRect(0,0,512,512);for(let i=0;i<16;i++){x.fillStyle=i%2?'rgba(90,70,52,.6)':'rgba(130,110,80,.35)';x.fillRect(i*32,0,16,512);}
  for(let i=0;i<60;i++){x.fillStyle='rgba(160,140,100,.25)';const px=R()*512,py=R()*512;x.beginPath();x.arc(px,py,6,0,7);x.fill();}
  TX.blotch(x,512,512,R,26,(R,a)=>`rgba(40,30,20,${a})`,.3,30,110);x.fillStyle='rgba(30,22,14,.5)';for(let i=0;i<5;i++){const px=R()*512;x.fillRect(px,R()*200,3,200+R()*300);}return c;});
TX.add('carpet',()=>{const c=TX.cv(256),x=c.getContext('2d'),R=TX.rng(411);x.fillStyle='#4a1a1c';x.fillRect(0,0,256,256);x.strokeStyle='rgba(200,160,90,.35)';x.lineWidth=4;x.strokeRect(14,0,228,256);
  for(let j=0;j<8;j++){x.beginPath();x.moveTo(128,j*32);x.lineTo(150,j*32+16);x.lineTo(128,j*32+32);x.lineTo(106,j*32+16);x.closePath();x.stroke();}TX.blotch(x,256,256,R,14,(R,a)=>`rgba(20,8,8,${a})`,.35,20,60);return c;});
TX.add('tileStation',()=>{const c=TX.cv(512),x=c.getContext('2d'),R=TX.rng(421);x.fillStyle='#2a2a26';x.fillRect(0,0,512,512);for(let j=0;j<16;j++)for(let i=0;i<8;i++){const v=R();x.fillStyle=j>11?`rgb(${120+v*20},${40+v*10},${30+v*8})`:`rgb(${190+v*25},${185+v*25},${165+v*20})`;x.fillRect(i*64+2,j*32+2,60,28);}
  TX.blotch(x,512,512,R,30,(R,a)=>`rgba(30,25,15,${a})`,.35,20,100);x.fillStyle='rgba(20,18,10,.6)';for(let i=0;i<9;i++)x.fillRect(R()*512,R()*512,2,60+R()*160);return c;});
TX.add('sPlat',sign(['PLATFORM','0'],{w:512,h:256,bg:'#1e2a3a',fg:'#e8e0c8',frame:'#e8e0c8',font:'800 86px "Barlow Condensed",sans-serif',lh:92}));
TX.add('sRook',sign(['THE ROOKERY','EST. 1909'],{w:512,h:192,bg:'#2a2018',fg:'#d8c08a',frame:'#8a6a30',font:'italic 700 60px "Bodoni Moda",serif',lh:66}));
TX.add('sRedSyn',sign('RED SYNDICATE · NO ENTRY',{w:512,h:96,bg:'#3a0808',fg:'#ffb0a0',font:'800 44px "Barlow Condensed",sans-serif'}));
TX.add('mailbox',()=>{const c=TX.cv(256),x=c.getContext('2d');x.fillStyle='#6a5a3a';x.fillRect(0,0,256,256);for(let j=0;j<4;j++)for(let i=0;i<4;i++){x.fillStyle='#a8945a';x.fillRect(8+i*62,8+j*62,54,54);x.fillStyle='#3a3020';x.fillRect(14+i*62,40+j*62,42,6);x.fillStyle='#222';x.font='700 14px "Barlow Condensed",sans-serif';x.fillText(['1A','1B','1C','1D','2A','2B','2C','2D','3A','3B','3C','3D','4A','4B','4C','404'][j*4+i],16+i*62,28+j*62);}return c;});
TX.add('water',()=>{const c=TX.cv(256),x=c.getContext('2d'),R=TX.rng(431);x.fillStyle='#0c1418';x.fillRect(0,0,256,256);for(let i=0;i<60;i++){x.strokeStyle=`rgba(120,160,170,${.05+R()*.12})`;x.lineWidth=1+R()*2;x.beginPath();const y=R()*256;x.moveTo(0,y);x.bezierCurveTo(80,y+(R()-.5)*20,170,y+(R()-.5)*20,256,y);x.stroke();}return c;});
TX.add('bonewire',()=>{const c=TX.cv(512,256),x=c.getContext('2d'),R=TX.rng(441);x.clearRect(0,0,512,256);for(let i=0;i<14;i++){x.strokeStyle=`rgba(${120+R()*60},${100+R()*40},60,.8)`;x.lineWidth=1.5;x.beginPath();let px=0,py=R()*256;x.moveTo(px,py);while(px<512){px+=20+R()*40;py+=(R()-.5)*30;x.lineTo(px,py);}x.stroke();}
  for(let i=0;i<22;i++){x.fillStyle='#d8cfb4';const px=R()*512,py=R()*256;x.beginPath();x.ellipse(px,py,5,9,R(),0,7);x.fill();}return c;});

const XM={};function x3(){if(XM.ready)return XM;const m=mats();Object.assign(XM,{
  wallpaper:M([1,1,1],{tex:'wallpaper',texScale:.5,spec:.05}),carpet:M([1,1,1],{tex:'carpet',decal:true,mottle:.2,spec:.05}),station:M([1,1,1],{tex:'tileStation',texScale:.5,spec:.35}),
  sPlat:M([1,1,1],{tex:'sPlat',decal:true,mottle:0,emisK:.15}),sRook:M([1,1,1],{tex:'sRook',decal:true,mottle:0,emisK:.1}),sRedSyn:M([1,1,1],{tex:'sRedSyn',decal:true,mottle:0,emisK:.5}),mailbox:M([1,1,1],{tex:'mailbox',decal:true,mottle:0,spec:.6}),
  water:M([1,1,1],{tex:'water',decal:true,mottle:0,spec:2.4,emisK:.12}),bonewire:M([1,1,1],{tex:'bonewire',decal:true,mottle:0,spec:.3}),
  rust:M([.42,.22,.12],{spec:.4,mottle:.6}),oil:M([.12,.12,.11],{spec:1.4,mottle:.4}),yellow:M([.85,.65,.1],{spec:.5}),couch:M([.32,.22,.18],{spec:.1,mottle:.4}),
  sodium:m.sodium,redwarn:M([1,1,1],{emis:[1,.12,.08],mottle:0}),blue:M([1,1,1],{emis:[.3,.5,1],mottle:0})});XM.ready=true;return XM;}

/* ---------- The Rookery: stair landing and corridor ---------- */
ROOMS.rookery={id:'rookery',name:'The Rookery',sub:'Block C · a tenement off Halloran Street',W:10,D:6,H:3.2,ambience:'street',map:true,
  sky:[.16,.14,.12],ground:[.05,.04,.03],
  grade:{sh:[.8,.66,.52],hi:[1.08,.96,.8],ink:[.04,.03,.02],sat:.8,wash1:[.025,.018,.01],wash2:[.08,.06,.04]},
  shadow:{pos:[5,3.0,2.6],target:[5,0,2.6],fov:2.2,far:11,idx:0},
  lights(S){return [{pos:[5,2.9,2.6],color:[1,.8,.5],intensity:1.4,range:8},{pos:[1.2,2.6,4.4],color:[1,.7,.4],intensity:.9,range:4.5},{pos:[8.8,2.2,0.6],color:[.6,.7,1],intensity:.8,range:4},{pos:[9.6,1.3,5.5],color:[1,.5,.3],intensity:.6,range:3}];},
  flicker(t){return 1-0.25*(Math.sin(t*17)>0.85&&Math.sin(t*.7)>0?1:0);},
  build(rb,S){const m=mats(),X=xm(),Y=x3();
    rb.shell(10,6,3.2,m.woodDark,Y.wallpaper,Y.wallpaper,m.cap,{lowerH:0.9,lowerL:X.mahog,lowerR:X.mahog});
    rb.floor(5,2.2,9.2,1.4,Y.carpet);
    // doors on the back wall: 3B, 404, roof stairs
    P.door(rb,1.0,1.9,0,2.2,m.woodDark);P.door(rb,4.2,5.1,0,2.2,m.woodDark);rb.box([4.55,1.7,0.1],[4.75,1.8,0.12],m.gold,{noDepth:true});rb.box([1.35,1.7,0.1],[1.55,1.8,0.12],m.gold,{noDepth:true});
    rb.floor(4.65,0.3,0.4,0.3,M([.05,.04,.04],{decal:true,mottle:.5}));
    for(let i=0;i<6;i++)rb.box([7.6+i*0.0,i*0.3,0],[9.6,i*0.3+0.3,0.9-i*0.0],m.woodDark);rb.box([7.6,1.8,0],[9.6,3.2,0.1],M([.03,.03,.04]),{noDepth:true});rb.box([7.55,0,0.9],[7.65,1.9,1.0],X.mahog);
    rb.wallZ(8.6,2.6,1.0,0.38,M([1,1,1],{tex:'sExit',decal:true,mottle:0,emisK:.5}));
    // mailboxes + 2C, the stair down on the left wall
    rb.decal([0.02,1.35,2.2],[0,0,-1.1],[0,1.1,0],[1,0,0],Y.mailbox);rb.box([0,0.75,1.6],[0.12,0.8,2.8],m.steelDark,{noDepth:true});
    rb.wallX(4.0,1.9,1.4,0.52,Y.sRook);
    for(let i=0;i<5;i++)rb.box([0,0,4.8+i*0.24],[0.9-i*0.0,0.9-i*0.18,5.04+i*0.24],m.woodDark,{block:i===0});
    rb.box([0.9,0,4.7],[0.96,1.1,6],X.mahog,{noDepth:true});
    // radiator, a pram, rubbish bags
    rb.box([2.6,0.1,0],[3.6,0.8,0.18],m.steelDark,{block:true});for(let i=0;i<8;i++)rb.box([2.65+i*0.12,0.12,0.18],[2.7+i*0.12,0.78,0.2],m.steel,{noDepth:true});
    rb.sph([6.95,0.32,0.45],[0.35,0.32,0.3],m.black,{block:true});rb.sph([7.3,0.25,0.4],[0.26,0.25,0.25],m.black);P.door(rb,5.5,6.3,0,2.2,m.woodDark);rb.box([5.8,1.7,0.1],[6.0,1.8,0.12],m.gold,{noDepth:true});
    P.tube(rb,3,6,3.1,3.0);
  },
  spawn:{x:1.2,z:4.4,ry:0.6},
  exits:[{id:'rookOut',label:'Halloran Street',at:[0.45,0.8,5.4],box:[0,0,4.8,0.95,0.9,6],stand:[1.5,5.1],face:[0.4,5.4],map:true},
    {id:'to3B',label:'Room 3B',at:[1.45,1.4,0.1],box:[1.0,0,0,1.9,2.2,0.2],stand:[1.45,0.9],face:[1.45,0],to:'apt',spawn:{x:5.2,z:4.2,ry:-2.4}},
    {id:'to404',label:'Room 404',at:[4.65,1.4,0.1],box:[4.2,0,0,5.1,2.2,0.2],stand:[4.65,0.9],face:[4.65,0],to:'apt',spawn:{x:5.2,z:4.2,ry:-2.4}},
    {id:'toRoof',label:'Roof',at:[8.6,2.2,0.4],box:[7.6,0,0,9.6,1.8,0.9],stand:[8.6,1.5],face:[8.6,0]}],
  inter:[{id:'mailboxes',label:'Mailboxes',at:[0.05,1.4,2.2],box:[0,0.75,1.6,0.15,1.95,2.8],stand:[0.9,2.2],face:[0,2.2]}],
  particles:[{type:'motes',n:30,area:[0.5,9.5,0.5,5.5],y:[0.3,2.8],col:[1,.85,.6]}]
};

/* ---------- an apartment (dressed per occupant) ---------- */
ROOMS.apt={id:'apt',name:'Apartment',sub:'The Rookery',W:6,D:5,H:2.8,ambience:'backroom',
  sky:[.16,.14,.14],ground:[.05,.04,.04],
  grade:{sh:[.8,.65,.6],hi:[1.08,.95,.85],ink:[.04,.02,.03],sat:.85,wash1:[.02,.015,.012],wash2:[.07,.05,.05]},
  shadow:{pos:[3,2.7,2.6],target:[3,0,2.2],fov:2.1,far:9,idx:0},
  lights(S){const who=S.aptWho||'leo';const warm=who==='404'?[1,.6,.35]:who==='bath'?[.6,.9,1]:[1,.78,.55];return [{pos:[3,2.6,2.4],color:warm,intensity:1.3,range:7},{pos:[5.4,1.6,0.3],color:[.4,.5,1],intensity:.8,range:3},{pos:[0.6,1.2,1.2],color:[1,.6,.4],intensity:.5,range:2.5}];},
  flicker(t){return 1-0.06*Math.max(0,Math.sin(t*7));},
  build(rb,S){const m=mats(),X=xm(),Y=x3();const who=S.aptWho||'leo';
    rb.shell(6,5,2.8,m.wood,Y.wallpaper,m.plaster,m.cap,{lowerH:0.8,lowerL:Y.wallpaper,lowerR:m.plaster});
    rb.floor(2.8,2.6,2.6,1.8,M([1,1,1],{tex:'carpet',decal:true,mottle:.3,spec:.05}));
    // window with blinds on the back wall
    rb.box([4.4,1.0,0],[5.8,2.3,0.05],M([.2,.3,.6],{emis:[.15,.22,.45],mottle:0}),{noDepth:true});for(let i=0;i<10;i++)rb.box([4.4,1.0+i*0.13,0.05],[5.8,1.06+i*0.13,0.08],m.white,{noDepth:true});
    // kitchenette, back-left
    rb.box([0.2,0,0],[2.0,0.9,0.6],m.white,{block:true});rb.box([0.2,0.9,0],[2.0,0.94,0.62],m.steelBright);rb.box([0.3,1.5,0],[1.9,2.1,0.35],m.woodDark);
    // couch + coffee table + tv
    rb.box([1.0,0,3.4],[3.4,0.45,4.3],Y.couch,{block:true});rb.box([1.0,0.45,4.05],[3.4,1.0,4.3],Y.couch);rb.box([0.9,0,3.4],[1.1,0.75,4.3],Y.couch);rb.box([3.3,0,3.4],[3.5,0.75,4.3],Y.couch);
    rb.box([1.6,0,2.4],[2.8,0.4,3.0],m.woodDark,{block:true});rb.box([2.4,0,0.2],[3.4,0.5,0.6],m.black,{block:true});rb.box([2.5,0.5,0.25],[3.3,1.05,0.4],m.black);rb.box([2.55,0.55,0.41],[3.25,1.0,0.42],M([.2,.3,.4],{emis:[.1,.16,.22]}),{noDepth:true});
    // chimney breast on the left wall (the crying wall)
    rb.box([0,0,1.6],[0.45,2.8,2.6],m.brick,{block:true});rb.box([0.45,0,1.75],[0.5,0.7,2.45],m.black,{noDepth:true});
    if(who==='404'){rb.box([0.45,0.9,1.9],[0.48,1.3,2.3],M([.25,.05,.05],{mottle:.6}),{noDepth:true});P.candle(rb,3.0,0.4,2.7);P.candle(rb,2.0,0.4,2.6);}
    if(who==='leo'){rb.cyl([1.4,0.94,0.3],0.06,0.07,0.16,M([.3,.6,.3],{spec:.3}));rb.sph([1.4,1.16,0.3],[0.06,0.1,0.06],M([.25,.55,.25],{spec:.3}));rb.wallZ(4.0,1.8,0.4,0.52,M([1,1,1],{tex:'flyer',decal:true,mottle:0}));}
    if(who==='bath'){rb.box([3.8,0,2.8],[5.6,0.6,3.6],m.porcelain,{block:true});rb.box([3.9,0.5,2.9],[5.5,0.56,3.5],M([.5,.8,.95],{alpha:.6,spec:2,mottle:0}),{noDepth:true});}
    if(who==='5A'){rb.box([3.8,0,2.6],[5.4,0.75,3.6],X.mahog,{block:true});P.candle(rb,4.2,0.75,3.0);P.candle(rb,5.0,0.75,3.2);rb.wallZ(4.8,1.9,0.9,0.9,M([1,1,1],{tex:'clock',decal:true,mottle:0}));}
    // door back out
    P.doorX(rb,3.8,4.7,0,2.1,m.woodDark);
  },
  spawn:{x:1.2,z:4.2,ry:0.8},
  exits:[{id:'aptOut',label:'The corridor',at:[0.1,1.3,4.25],box:[0,0,3.8,0.2,2.1,4.7],stand:[0.9,4.25],face:[0,4.25],to:'rookery',spawn:{x:2.8,z:1.4,ry:0.4}}],
  inter:[{id:'chimney',label:'The chimney breast',at:[0.48,1.3,2.1],box:[0,0,1.6,0.5,2.8,2.6],stand:[1.3,2.1],face:[0,2.1]},
    {id:'aptwin',label:'Window',at:[5.1,1.6,0.08],box:[4.4,1,0,5.8,2.3,0.1],stand:[5.1,1.0],face:[5.1,0]}],
  particles:[{type:'motes',n:25,area:[0.5,5.5,0.5,4.5],y:[0.3,2.4],col:[1,.85,.6]}]
};

/* ---------- Platform 0 and Malakor's chop-shop ---------- */
ROOMS.switchyard={id:'switchyard',name:'Platform 0',sub:'Block D · the Sunken Switchyard',W:12,D:7,H:4.6,ambience:'tunnel',map:true,
  sky:[.12,.12,.14],ground:[.04,.04,.04],
  grade:{sh:[.72,.75,.9],hi:[1.1,.94,.78],ink:[.03,.03,.04],sat:.82,wash1:[.015,.015,.02],wash2:[.07,.06,.06]},
  shadow:{pos:[6,4.2,2.8],target:[6,0,3],fov:2.2,far:13,idx:0},
  lights(S){const L=[{pos:[6,4.2,2.8],color:[1,.66,.3],intensity:1.8,range:11},{pos:[9.6,2.2,1.4],color:[1,.25,.15],intensity:1.1,range:5},{pos:[2.2,2.6,2.2],color:[.6,.7,1],intensity:.8,range:5},{pos:[6,1.0,6.4],color:[.4,.5,.7],intensity:.6,range:5}];if(S.flags.genDead)L[1].intensity=.15;return L;},
  flicker(t){return 0.9+0.1*Math.sin(t*30)*Math.sin(t*.9);},
  build(rb,S){const m=mats(),X=xm(),Y=x3();
    rb.shell(12,7,4.6,m.concCold,Y.station,Y.station,m.cap);
    rb.decal([4.2,3.2,0.012],[2.0,0,0],[0,1.0,0],[0,0,1],Y.sPlat);
    // tracks along the front, below the platform edge
    rb.box([0,-0.6,5.5],[12,-0.55,7],m.asphalt,{noDepth:true});rb.box([0,0,5.4],[12,0.06,5.5],Y.yellow,{noDepth:true});
    [5.9,6.6].forEach(z=>rb.box([0,-0.5,z-0.04],[12,-0.42,z+0.04],m.steelBright,{noDepth:true}));for(let i=0;i<24;i++)rb.box([0.2+i*0.5,-0.55,5.7],[0.36+i*0.5,-0.5,6.8],X.mahog,{noDepth:true});
    rb.block(0,5.45,12,7);
    // the old subway car (bricked up) on the left
    rb.box([0,0,1.2],[0.9,2.6,5.2],M([.35,.38,.32],{spec:.6,mottle:.6}),{block:true});for(let i=0;i<4;i++)rb.box([0.9,1.2,1.5+i*0.95],[0.92,1.9,2.2+i*0.95],M([.15,.2,.18],{spec:1.6,mottle:.2}),{noDepth:true});rb.box([0.9,0.2,4.5],[0.95,2.2,5.1],m.brick,{noDepth:true});
    // Malakor's chop-shop: car on a lift, workbench, chains, generator
    rb.box([6.8,0,0.6],[10.8,0.15,2.6],m.steelDark);[[7,0.8],[10.6,0.8],[7,2.4],[10.6,2.4]].forEach(p=>rb.cyl([p[0],0,p[1]],0.08,0.08,1.2,Y.yellow));
    rb.box([7.2,1.2,0.9],[10.4,1.75,2.3],M([.5,.06,.06],{spec:1.4,mottle:.2}),{block:true});rb.box([8.0,1.75,1.0],[9.6,2.2,2.2],M([.5,.06,.06],{spec:1.4,mottle:.2}));
    rb.block(6.8,0.6,10.8,2.6);
    rb.box([3.6,0,0],[6.2,0.95,0.8],m.woodDark,{block:true});rb.box([3.55,0.95,0],[6.25,1.0,0.85],m.steelDark);
    rb.cylX(3.8,4.6,1.05,0.4,0.035,m.chrome);rb.box([4.8,1.0,0.25],[5.6,1.08,0.55],m.black);rb.cyl([5.9,1.0,0.4],0.08,0.08,0.3,X.cyan,{noDepth:true});
    for(let i=0;i<4;i++)rb.cyl([2.8+i*0.25,2.6,2.2+i*0.3],0.012,0.012,2.0,m.steelDark,{noDepth:true});rb.box([2.6,2.0,2.0],[3.8,2.05,3.4],m.steelDark,{noDepth:true});
    if(!S.flags.genDead){rb.box([10.9,0,3.0],[12,1.4,4.6],Y.yellow,{block:true});rb.box([11.2,1.4,3.4],[11.6,2.6,3.7],m.steelDark);rb.box([10.88,0.8,3.4],[10.9,1.1,3.7],Y.redwarn,{noDepth:true});}
    else{rb.box([10.9,0,3.0],[12,1.4,4.6],M([.2,.18,.12],{mottle:.7}),{block:true});rb.floor(10.4,3.8,1.6,1.8,M([1,1,1],{tex:'ash',decal:true,mottle:0}));}
    rb.wallZ(8.8,3.6,2.2,0.42,Y.sRedSyn);
    // stair down to the sewers (front left), drums, a fire barrel
    rb.box([1.6,-0.02,4.4],[2.6,0.02,5.3],m.black,{noDepth:true});rb.box([1.55,0,4.35],[1.6,1.0,5.35],m.steelDark,{noDepth:true});
    rb.cyl([5.0,0,4.6],0.3,0.3,0.9,Y.rust,{noDepth:false});rb.sph([5.0,1.0,4.6],[0.18,0.14,0.18],m.sodium,{noDepth:true});rb.block(4.7,4.3,5.3,4.9);
    for(let i=0;i<3;i++)rb.cyl([11.3,0,1.0+i*0.7],0.28,0.28,0.95,i%2?Y.rust:m.green);rb.block(11,0.7,11.6,2.6);
  },
  spawn:{x:3.0,z:3.4,ry:0.8},
  exits:[{id:'yardOut',label:'Up to the street',at:[6.2,1.6,0.1],box:[6.25,0,0,6.8,2.6,0.2],stand:[6.5,1.2],face:[6.5,0],map:true},
    {id:'toShrine',label:'Down into the sewers',at:[2.1,0.5,4.85],box:[1.6,0,4.4,2.6,0.6,5.3],stand:[2.6,3.9],face:[2.1,4.85],to:'shrine',spawn:{x:6.6,z:1.2,ry:-2.4}}],
  inter:[{id:'generator',label:'Diesel generator',at:[11.4,1.6,3.8],box:[10.9,0,3.0,12,1.4,4.6],stand:[10.2,3.8],face:[11.4,3.8]},
    {id:'workbench',label:'Workbench',at:[4.9,1.3,0.4],box:[3.6,0,0,6.2,1.1,0.85],stand:[4.9,1.6],face:[4.9,0.3]},
    {id:'subwaycar',label:'Bricked-up subway car',at:[0.9,1.6,3.3],box:[0,0,1.2,0.95,2.6,5.2],stand:[1.8,3.3],face:[0.9,3.3]},
    {id:'firebarrel',label:'Fire barrel',at:[5.0,1.2,4.6],box:[4.7,0,4.3,5.3,1.1,4.9],stand:[5.0,3.7],face:[5.0,4.6]}],
  particles:[{type:'motes',n:40,area:[0.5,11.5,0.5,5.3],y:[0.3,4],col:[1,.75,.5]},{type:'spark',n:20,center:[5.0,1.05,4.6]}]
};

/* ---------- Mother Soot's shrine ---------- */
ROOMS.shrine={id:'shrine',name:'The Shrine of Mother Soot',sub:'Block D · beneath Platform 0',W:8,D:6,H:3.4,ambience:'sewer',
  sky:[.12,.12,.14],ground:[.04,.04,.05],
  grade:{sh:[.66,.72,.85],hi:[1.12,.95,.78],ink:[.03,.03,.04],sat:.78,wash1:[.012,.014,.02],wash2:[.06,.06,.07]},
  shadow:{pos:[3.6,3.1,2.4],target:[3.4,0,2.4],fov:2.1,far:10,idx:0},
  lights(S){return [{pos:[3.6,2.4,1.6],color:[1,.66,.32],intensity:1.6,range:7},{pos:[1.2,1.2,1.0],color:[1,.6,.3],intensity:.9,range:3},{pos:[6.6,1.4,0.8],color:[1,.6,.3],intensity:.8,range:3},{pos:[4,0.4,5],color:[.4,.6,.7],intensity:.5,range:4}];},
  flicker(t){return 0.88+0.12*Math.sin(t*5.7)*Math.sin(t*1.9+2);},
  build(rb,S){const m=mats(),X=xm(),Y=x3();
    rb.shell(8,6,3.4,m.brick,m.brick,m.brick,m.cap);
    rb.floor(4,4.9,8,2.0,Y.water);rb.box([0,-0.25,3.9],[8,-0.2,6],M([.05,.07,.08],{spec:2,mottle:0}),{noDepth:true});rb.block(0,4.2,8,6);
    rb.decal([4,2.2,0.012],[7.6,0,0],[0,2.0,0],[0,0,1],Y.bonewire);rb.decal([0.012,2.2,2.2],[0,0,-3.6],[0,2.0,0],[1,0,0],Y.bonewire);
    // throne of pipes
    for(let i=0;i<7;i++){const x=2.6+i*0.4,h=1.6+Math.sin(i*1.3)*0.3+(3-Math.abs(i-3))*0.25;rb.cyl([x,0,0.3],0.07,0.07,h,Y.rust);}
    rb.box([3.2,0,0.4],[4.6,0.5,1.2],Y.rust,{block:true});rb.box([3.2,0.5,0.35],[4.6,1.4,0.55],Y.rust);
    // candles everywhere
    const R=TX.rng(77);for(let i=0;i<40;i++){const x=0.4+R()*7.2,z=0.2+R()*3.6;if(x>3&&x<4.8&&z<1.4)continue;P.candle(rb,x,0,z);}
    for(let i=0;i<8;i++)P.candle(rb,0.3,0.8+R()*1.2,0.6+i*0.4);
    // stair back up, the bone-microphone switchboard
    for(let i=0;i<5;i++)rb.box([6.2,i*0.2,0],[7.6,i*0.2+0.2,1.0-i*0.0],m.concCold,{block:i===0});
    rb.box([0,0.6,3.0],[0.5,1.8,3.8],X.mahog,{block:true});for(let i=0;i<12;i++)rb.box([0.5,0.7+Math.floor(i/4)*0.35,3.05+(i%4)*0.18],[0.52,0.85+Math.floor(i/4)*0.35,3.15+(i%4)*0.18],X.bone,{noDepth:true});
  },
  spawn:{x:6.6,z:1.4,ry:-2.4},
  exits:[{id:'shrineUp',label:'Back up to Platform 0',at:[6.9,1.2,0.4],box:[6.2,0,0,7.6,1.0,1.0],stand:[6.6,1.6],face:[6.9,0.4],to:'switchyard',spawn:{x:2.6,z:3.9,ry:0.6}}],
  inter:[{id:'switchboard',label:'Bone switchboard',at:[0.5,1.4,3.4],box:[0,0.6,3.0,0.55,1.8,3.8],stand:[1.3,3.4],face:[0,3.4]},
    {id:'water',label:'Black water',at:[4,0.1,4.6],box:[0,-0.3,4.2,8,0.1,6],stand:[4,3.6],face:[4,4.6]}],
  particles:[{type:'motes',n:50,area:[0.5,7.5,0.5,4],y:[0.2,2.8],col:[1,.75,.45]},{type:'mist',n:16,area:[0,8,4,6],y:[0,.3]}]
};
})();
