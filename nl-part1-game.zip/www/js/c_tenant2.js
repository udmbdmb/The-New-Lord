'use strict';
/* THE NEW LORD — the Tenant's stories: ask him about the two hundred years before the freezer */
NL.Script.add(String.raw`
# tnS.cors arc=tenant night=2,3,4,5 label="Ask him where he was born." if=!seen:tnS.cors prio=-2
@focus tenant
tenant: Ajaccio. Corsica. 1761. A house on the harbour with a fig tree in the yard that my mother loved more than any of her children.
tenant: My father was a notary. I was going to be a notary. I'd have been very good at it: pedantic, punctual, slightly corrupt. Then a man in a black coat came to dinner when I was twenty-six, and stayed for a hundred years.
* "Do you miss it? Being mortal?"  -> tnS.cors1
* "Who was the man in the black coat?"  -> tnS.cors2

# tnS.cors1
tenant: I miss figs. That's all, really. I've tried to miss more. It's been too long. You can't miss a room you can't remember the shape of.
tenant: You'll find that out. Not soon. But you will. One day you'll try to remember the taste of something and it'll be gone.
* "Then I'll write it down. Everything. Before it goes."  -> tnS.cors3
* "That's the saddest thing you've said."  -> tnS.cors4

# tnS.cors3
tenant: Write it down. Yes. Agnes said that. "Write down what toast tastes like, Absalom, before you forget." I didn't. I wish I had.
{do mem:tenant:figs; comp+1}
@end

# tnS.cors4
tenant: It's not. I've said far sadder. I'm saving them.
{do mem:tenant:figs}
@end

# tnS.cors2
tenant: His name was Gaspard. He was a Sovereign, from Genoa, and he wanted a notary. He needed someone to keep his accounts who couldn't die and wouldn't steal.
tenant: I stole from him for sixty years. A little. Every year. Out of principle. When I finally killed him, in 1849, he said "I always knew," and I believed him.
{do mem:tenant:gaspard}
@end

# tnS.mars arc=tenant night=3,4,5 label="Ask him about Marseille." if=seen:dm.abs_heavy|mem:tenant.figs prio=-2
@focus tenant
tenant: Marseille. 1720. The plague year.
tenant: The city was dying. A hundred thousand people. The streets full of carts. And the Church decided, in its wisdom, that the plague was our fault. It wasn't. We were the only things in Marseille that couldn't catch it.
tenant: They caught three of us. A Gilded girl, a Butcher, and a Hound called Ilse who'd come down to the docks to feed the dying because they were dying anyway and she thought it was kinder. They burned them in the square at noon.
tenant: I watched from a cellar grating. I didn't do anything. I could have done something.
* "What could you have done?"  -> tnS.mars1
* "You were afraid."  -> tnS.mars2

# tnS.mars1
tenant: Gone out. At noon. Into the square. Stood with them. I'd have burned too, of course. But they wouldn't have burned alone.
tenant: That's the only thing I've ever really wanted to have done. And I didn't.
{do mem:tenant:marseille; lean:mercy+0}
@end

# tnS.mars2
tenant: Yes. I was afraid. I've been afraid for two hundred and sixty years. It's the one thing I've been absolutely faithful to.
{do mem:tenant:marseille}
@end

# tnS.lyon arc=tenant night=3,4,5 label="Ask him about Séverine. Before." if=alive:sev&met:severine prio=-2
@focus tenant
tenant: Séverine. Lyon. 1793. Before she was the Keeper. Before she was anything but a frightened girl with a priest in her cellar and the Terror on the stairs.
tenant: I was in Lyon on business. Gaspard's business. She came to me because I was the only Sovereign in the city who wasn't on the Committee's list. She asked me to get her priest out.
tenant: I said I'd try. I didn't try very hard. I had papers to sign.
* "And the priest went to the window."  -> tnS.lyon1 {if mem:severine.lyon}
* "Does she know?"  -> tnS.lyon2

# tnS.lyon1
tenant: He went to the window. You know. She told you. She never told me. She never once in two hundred years said a word about it to my face.
tenant: She's punished me every night since. In a hundred little ways. I've let her. It seemed fair.
{do mem:tenant:lyon; sync+1}
@end

# tnS.lyon2
tenant: She knows I said I'd try. She doesn't know I didn't. Or she does, and she's been kind enough, or cruel enough, never to ask.
{do mem:tenant:lyon}
@end

# tnS.1888 arc=tenant night=3,4,5 label="Ask him about 1888. The wrist." if=flag:sevBond|flag:sevRefusedBond|flag:sevFakeBond|seen:bS.offer prio=-2
@focus tenant
tenant: 1888. She offered me her wrist the night before I was made Sheriff of the Ward. She said: one taste, for luck. I drank. I'd been drinking for a week. Everything was lucky that week.
tenant: For nine years I loved her. Not love. The blood's version. A leash with a pretty collar. I'd wake up thinking about her wrist. I'd dream about the jasmine.
tenant: In 1897 I went to a Butcher in Vienna who boiled it out of me. It took a month. It was the worst month of my life, and I've died twice.
* "Why didn't you tell me before she offered?"  -> tnS.18881
* "Do you still think about it?"  -> tnS.18882

# tnS.18881
tenant: I did. I told you she did it to me. I didn't tell you how it felt. I wanted you to choose without my hand on your shoulder.
@end

# tnS.18882
tenant: Every dawn. For about four minutes. Nobody's business.
tenant: ...Oh. Oh, God. Four minutes. Her too. She cries for four minutes. I never put that together.
{do mem:tenant:1888; sync+1}
@end

# tnS.1946 arc=tenant night=3,4,5 label="Ask him about being Sheriff." if=!seen:tnS.1946 prio=-2
@focus tenant
tenant: Eighty years. 1888 to Monday. Well, I took a sabbatical in the twenties. Paris. It was terribly fashionable.
tenant: Three laws, on the first night. Every Sheriff makes three. Mine were: no feeding in the Heights, ten percent tithe, and nobody touches my car.
tenant: The third one was a joke. Everybody kept it. Nobody ever kept the first two.
* "Were you a good Sheriff?"  -> tnS.19461
* "What would you do differently?"  -> tnS.19462

# tnS.19461
tenant: I was an effective Sheriff. The Ward was quiet. The Prince was pleased. Nobody starved who I liked, and nobody I disliked lasted.
tenant: Good? No. Good would have meant coming down to Platform 0 once in eighty years to ask Local 0 what they needed. I never did. I sent Pemberton with envelopes.
@end

# tnS.19462
tenant: Everything. Nothing. I'd have gone to the Lucky Mart. Once. Just once, at five in the morning, to see what the coffee was like.
tenant: You've been eleven times. I've been counting.
{do comp+1}
@end

# tnS.wat arc=tenant night=4,5 label="Ask him about the Waterloo bet." if=flag:magistrateKnowsVane|flag:magHeardVane prio=-2
@focus tenant
tenant: Waterloo. 1815. Ambrose bet me forty guineas that Wellington would lose. I said Wellington would win because the Duke was the only man in Europe more stubborn than Ambrose.
tenant: Wellington won. Ambrose refused to pay because, he said, the Prussians did most of the work, and a bet on Wellington was not a bet on Blücher.
tenant: We've argued about it for two hundred and ten years. Every Christmas Eve. It's the best argument I've ever had.
* "And the goat?"  -> tnS.wat1 {if mem:magistrate.goat}
* "Who's right?"  -> tnS.wat2

# tnS.wat1
tenant: The goat is a separate matter. The goat is forty francs, and I owe him that, and I'll never pay it. If I pay it there's nothing left to talk about.
{do sync+1}
@end

# tnS.wat2
tenant: I am. Obviously. The Duke said "hard pounding, gentlemen", and it was. The Prussians were late. Blücher was seventy-two and had fallen off his horse. Write that down. Tell Ambrose I said so.
@end

# tnS.pier arc=tenant night=3,4,5 label="Ask him about Pier Nine." if=flag:valkoAlly|done:s_rask|mem:tenant.rask prio=-2
@focus tenant
tenant: Pier Nine. 1977. Rask. Valko's sire, in the way Hounds have sires. The biggest Hound I ever saw. He laughed like a door being kicked in.
tenant: He'd gone strange. Hounds do, if they're alone too long, and he'd been alone since 1940. He was killing. Dockers. Three of them. The Prince sent me.
tenant: I went to the pier and he was sitting on a bollard looking at the sea and he said: "Why does nobody ask, Mister? Seventy years. Why does nobody ever ask what's wrong?" And I didn't ask. I did what the Prince sent me to do.
tenant: And afterwards Harrow's people, who were someone else's people then, came and took what was left in a steel box. I didn't stop them. I didn't know what they wanted it for.
* "You know now."  -> tnS.pier1
* "Valko forgave you."  -> tnS.pier2 {if flag:valkoAlly}

# tnS.pier1
tenant: I know now. The first lamp. They made the first lamp from him. And the first lamp made the others. And the others are under Platform 0.
tenant: Everything comes back. Everything you don't ask about comes back.
{do mem:tenant:rask; sync+1}
@end

# tnS.pier2
tenant: He didn't forgive me. He forgave *you*. He thinks you're a different person. He's right, mostly. That's the kindest thing about you, child: you're not me.
{do mem:tenant:rask}
@end

# tnS.calls arc=tenant night=3,4,5 label="Ask him about the phone calls in 1998." if=flag:hcN2 prio=-2
@focus tenant
tenant: The silent calls. 1998. Every Tuesday, two in the morning, the telephone in the study would ring and nobody would speak. I'd pick up and listen. For a year.
tenant: I thought it was a Rot with a crush. There was one, in Bayside, who wrote me poetry. I thought it was her.
tenant: It was Tom Harrow. Listening to me not breathe. For a year. Learning me. And I sat there every Tuesday and listened back, and I thought: how sweet, somebody wants to hear me.
* "You were lonely."  -> tnS.calls1
* "He's lonely too."  -> tnS.calls2

# tnS.calls1
tenant: Yes. For eighty years. You'd think I'd have noticed.
@end

# tnS.calls2
tenant: ...Yes. I suppose he is. Two lonely men on either end of a telephone in 1998, saying nothing, and one of them is going to kill the other. That's the history of the twentieth century, really.
{do mem:tenant:calls}
@end

# tnS.agnes2 arc=tenant night=4,5 label="Ask him how he met Agnes." if=mem:tenant.agnesstory|flag:readAgnes prio=-2
@focus tenant
tenant: How. You want to know how. Not who. That's very nosy. Fine.
tenant: December 23rd, 1924. The Courthouse. She was a typist on the night shift, filing for the Assizes. I came in to read a file I wasn't supposed to read. She caught me. She said: "Sir, that drawer is locked, and you've broken it, and I'm going to need you to sign for that."
tenant: Nobody had told me off since 1787. I signed for it. I signed my real name. Two years later, I showed her what I was, and she asked if it hurt. That first night, though, I just took her for a cup of tea at a café on the Heights that's a bank now, and we talked until four, and at the door she threw a snowball at my car because, she said, it looked smug.
tenant: Thirty-seven years. Letters, mostly. She married Albert in 1931 because he was kind and alive and I was neither. She was right. I'd have done the same.
* "Did you love her?"  -> tnS.agnes3
* "Did she love you?"  -> tnS.agnes4

# tnS.agnes3
tenant: I don't know. I don't think I'm capable of it in the way you mean. But I've never stopped writing her letters. In my head. Every night. Thirty-seven years and sixty-four more.
{do sync+1; comp+1}
@end

# tnS.agnes4
tenant: She wrote, in her last letter: "I loved you exactly the right amount, Absalom. Not too much. You'd have hated too much." I think that's the most accurate thing anyone ever said about me.
{do sync+2}
@end

# tnS.fear arc=tenant night=5 label="Ask him if he's afraid of tonight." if=time<230 prio=-2
@focus tenant
tenant: Afraid. Of tonight. Of the chalk, and Ambrose, and three hundred faces, and the lamps under the platform.
tenant: Yes. Of course. I've been afraid of everything for two hundred and sixty years. It's never once stopped anything happening.
tenant: But I'll tell you something, child, since it's the last night and there's nobody else listening. I'm less afraid tonight than I've ever been. Because I'm not the one who has to stand in the circle. You are. And I trust you more than I ever trusted myself.
* "That's terrifying."  -> tnS.fear1
* "Thank you, Absalom."  -> tnS.fear2

# tnS.fear1
tenant: Yes. Isn't it? Welcome to being trusted. It's the worst thing that can happen to anyone.
@end

# tnS.fear2
> Silence. A long one. You've never called him by his name before.
tenant: ...Nobody's called me that and meant it since 1961.
{do sync+2; comp+2}
@end
`,'c_tenant2');
