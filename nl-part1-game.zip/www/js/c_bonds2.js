'use strict';
/* THE NEW LORD — bonds, part two: Miller at the diner, Tiny's door, Gideon's will, and Mother Soot's last request */
NL.Script.add(String.raw`
// =====================================================================
// MILLER · the diner
// =====================================================================
# b2M.0 arc=miller night=4,5 label="\"Ines. Have you eaten?\"" if=alive:miller&rel:miller>=4 prio=4
@focus miller
miller: Have I eaten. You're asking me if I've eaten. You.
miller: ...No. No, I haven't. Since Tuesday, probably. A granola bar. Half a granola bar.
miller: There's a diner on Kerr Street that does pancakes the size of a hubcap. Come and watch me eat. That's a weird thing to ask. Come anyway.
* Go.  -> b2M.diner
* "Another time."  -> b2M.no

# b2M.no
miller: Another time. Sure. That's what Ray always said.
@end

# b2M.diner
> The diner on Kerr Street. A booth by the window, red vinyl, a jukebox nobody's fed since 1998. Miller orders pancakes and coffee and eggs and bacon and, after a moment's thought, more coffee. You order a glass of water you won't drink.
> She eats like someone who forgot she had a body. You watch. She doesn't seem to mind.
miller: This is nice. Isn't that stupid? I'm sitting in a diner at three in the morning with a dead person and it's the nicest night I've had in five years.
* "Tell me about Ray."  -> b2M.ray
* "Tell me about you. Not the case. You."  -> b2M.you
* "Why haven't you arrested me?"  -> b2M.arrest

# b2M.ray
miller: Ray. Ray Dunleavy. Twenty-two years on the job. Irish. Ate cookies like they were going out of fashion. Called me "kid" until I was forty and then called me "old kid".
miller: He'd have liked you. That's the worst thing. He'd have sat here and asked you about a hundred things and written them all down in a notebook and never once been scared.
{do mem:miller:ray}
@next b2M.hub

# b2M.you
> She puts her fork down. Nobody's asked her that in a long time. You can see her try to remember the answer.
miller: Me. God. Ines Teresa Miller. Forty-four. Divorced, no kids, a sister with a dog. A brother who went missing in 2011.
miller: I wanted to be a marine biologist when I was nine. I got seasick on a ferry and that was the end of that. So I became a cop, because my dad was a cop, and I'm good at it, and I hate it, and I'd never do anything else.
* "I wanted to be a lighthouse keeper."  -> b2M.light {if flag:pcLibrary}
* "Thank you for telling me."  -> b2M.hub

# b2M.light
miller: A lighthouse keeper. Of course you did. Of course. You'd be terrible at it. You'd keep inviting the ships in.
> She laughs. You've never heard her laugh properly. It's loud and it turns into a cough and she doesn't care.
{do rel:miller+1; comp+1}
@next b2M.hub

# b2M.arrest
miller: Because what would I charge you with? "Being dead without a permit"?
miller: ...Because you're the only person on this case who's never lied to me about the important things. Because Ray would have liked you. Because I'm tired, and you're the first thing in five years that's made me not tired.
@next b2M.hub

# b2M.hub
* "After Friday, what happens to us? The detective and the... whatever I am."  -> b2M.after {once}
* "You should go home and sleep, Ines."  -> b2M.sleep {once}
* Pay for her breakfast.  -> b2M.pay {once} {if cash>=20}
* "Thank you. For this."  -> b2M.end

# b2M.after
miller: Us. Huh.
miller: I don't know. I've never... I've never had a friend I couldn't introduce to anyone. I'm not sure there's a word for what this is.
* "Partners."  -> b2M.partners
* "Friends."  -> b2M.friends
* "There doesn't need to be a word."  -> b2M.noword

# b2M.partners
miller: Partners. Like Ray. Okay. Okay. I can do partners. Partners don't have to explain anything to anyone. Partners just turn up.
{do flag:millerBond=partners; rel:miller+2}
@next b2M.hub

# b2M.friends
miller: Friends. God. A vampire friend. My sister's going to... no, I'm never telling my sister.
miller: Friends. Fine. Yes. Don't make it weird.
{do flag:millerBond=friends; rel:miller+2}
@next b2M.hub

# b2M.noword
miller: No. No, there doesn't. That's the most sensible thing anyone's said to me all week.
{do flag:millerBond=noword; rel:miller+2}
@next b2M.hub

# b2M.sleep
miller: Sleep. I've forgotten how. Ray used to say I slept like a cat: twenty minutes at a time, in odd places, with one eye open.
miller: ...After Friday. I'll sleep after Friday. If you're still here, I'll sleep for a week.
@next b2M.hub

# b2M.pay
> You put twenty dollars on the table. She looks at it.
miller: You're paying. For my breakfast. With money you got from... where do you even get money?
miller: Don't tell me. Thank you. Nobody's bought me breakfast since my divorce.
{do cash-20; rel:miller+1}
@next b2M.hub

# b2M.end
> She finishes the last pancake. She sits back. She looks out of the window at Kerr Street in the rain, and for the first time since you met her, her face is completely still.
miller: Thank you. For sitting with me. I didn't know I needed somebody to sit with me.
{do comp+2; flag:millerDiner=1; tick:40}
@end

// =====================================================================
// TINY · the door
// =====================================================================
# b2T.0 arc=tiny night=4,5 label="\"Tiny. What will you do after?\"" if=!flag:tinyBetrayed&!flag:tinyGone&rel:tiny>=4 prio=3
@focus tiny
tiny: After. Same as before. The door. The rope. "Not tonight, mate." Nine years, it'll be ten.
tiny: Why?
* "If I'm Sheriff, I need someone on my door. A real door. The study."  -> b2T.job
* "Because you could do anything, Tiny. You don't have to be a rope."  -> b2T.anything
* "No reason."  -> b2T.no

# b2T.no
tiny: No reason. Sure. Everyone's got a reason.
@end

# b2T.job
tiny: Your door. The Sheriff's door. Behind the bone wall.
tiny: ...Who's on it now?
* "Pemberton. When he's not driving."  -> b2T.pem {if alive:pemberton}
* "Nobody. Absalom never had anyone."  -> b2T.nobody

# b2T.pem
tiny: Pemberton. He's sixty-four and he looks forty and he's never once raised his voice in his life. Nobody's getting past him by being scary. They're getting past him by being polite.
tiny: Yeah. Okay. I'll do it. Me and the old man. Bad cop, polite cop.
{do flag:tinyDoor=1; rel:tiny+2}
@end

# b2T.nobody
tiny: Nobody. Eighty years and the Sheriff of the Marrow Ward had nobody on his door. No wonder they got him.
tiny: Yeah. Yeah, I'll do it. Someone has to. You'd only let anyone in.
{do flag:tinyDoor=1; rel:tiny+2}
@end

# b2T.anything
tiny: Anything. Like what? I'm thirty-eight. I've got no GCSEs... no diploma, whatever you call it here. I've got a criminal record from when I was seventeen and a bad knee.
tiny: I can stand still in the rain for eleven hours. I can tell from someone's walk if they're going to start something. I can stop a fight with my face.
* "That's a security firm. You'd run your own."  -> b2T.firm
* "That's a youth worker. Kids like Marcus need someone like you."  -> b2T.youth {if flag:fightDone}

# b2T.firm
tiny: My own... like, with a van? With my name on the van?
tiny: ..."Tiny's." Just "Tiny's". In big letters. Marcus could drive.
{do flag:tinyFirm=1; rel:tiny+2}
@end

# b2T.youth
> He goes very quiet.
tiny: Kids like Marc. Yeah. Kids who think four grand in a cellar is the only way out.
tiny: There's a gym on Kerr Street. The one Marc goes to. The guy who runs it is seventy and he keeps saying he wants to retire.
tiny: ...Yeah. Yeah. Maybe.
{do flag:tinyGym=1; rel:tiny+2}
@end

// =====================================================================
// GIDEON · the will
// =====================================================================
# b2G.0 arc=gideon night=4,5 label="\"Gideon. What's that envelope?\"" if=alive:gideon&rel:gideon>=4 prio=3
@focus gideon
> A long cream envelope on the counter, propped against the till, addressed in his best copperplate: *TO BE OPENED BY THE SHERIFF'S CHILD, AFTER.*
gideon: My will. Don't look like that. I'm seventy-four. I've had it drawn up since 1998. I just changed one line this afternoon.
gideon: The shop. The boxes. The ledger. When I go, somebody has to keep them. Somebody who knows what a box is for. My son's in Florida. He sells boats. He'd turn it into a vape shop.
gideon: I've left it to you.
* "Me? Gideon, I'm five days old."  -> b2G.young
* "Thank you. I'll keep every box."  -> b2G.yes {do promise:boxes:Keep Gideon's boxes after he's gone}
* "Leave it to someone alive."  -> b2G.alive

# b2G.young
gideon: Five days old and you've filled three of my boxes with people who needed them. Absalom never filled one in forty years.
gideon: Age isn't the point. Knowing what a box is for is the point.
@next b2G.0b

# b2G.0b
* "Thank you. I'll keep every box."  -> b2G.yes {do promise:boxes:Keep Gideon's boxes after he's gone}
* "Leave it to someone alive."  -> b2G.alive

# b2G.yes
gideon: Good. Good. Rule one: the lid on three sticks. Rule two: box seven is Mary-Ellen's, forever, whether she comes or not. Rule three: nobody pays in money if they can pay in kindness.
gideon: And keep the ledger. Every name. Every one. That's the job. That's the only job.
{do flag:gideonWill=1; rel:gideon+2; comp+1}
@end

# b2G.alive
gideon: Someone alive. Someone alive will die too. Then what? Then the boxes go to someone who doesn't know.
gideon: ...Think about it. The envelope will be here. I'm not going anywhere this week, if I'm careful on the stairs.
@end

// =====================================================================
// SOOT · the light
// =====================================================================
# b2S.0 arc=soot night=4,5 label="\"Mother. You wanted to ask me something.\"" if=alive:soot&rel:soot>=4 prio=3
@focus soot
soot: Ask. Ask, ask. Mm. Nobody asks Soot for anything except secrets. Soot asks for nothing.
soot: ...Soot asks for one thing.
> She holds out her hands. They're grey and thin as twigs and they're shaking.
soot: One day. Not tonight. Mm. Not this year. One day I'll be tired. Very tired. Tired of the pipes and the jars and the dark. When I'm tired, I want to see the windows again. The big house. The sun on the floor. Once.
soot: Nobody would carry me up. Everyone would say: no, Mother, you're needed, stay in the pipes. You won't say that. You'll carry me up. Promise.
tenant: Child. She's asking you to help her die. When she's ready. In the light.
* "I promise, Mother. When you're ready. I'll carry you up."  -> b2S.yes {do promise:sootlight:Carry Mother Soot into the light when she is ready}
* "I can't promise that."  -> b2S.no
* "Why me?"  -> b2S.why

# b2S.why
soot: Because you came back. Mm. You always come back. And because you'll be sad. Soot wants someone to be sad. Nobody's ever been sad about Soot.
@next b2S.0b

# b2S.0b
* "I promise, Mother. When you're ready. I'll carry you up."  -> b2S.yes {do promise:sootlight:Carry Mother Soot into the light when she is ready}
* "I can't promise that."  -> b2S.no

# b2S.yes
> She takes your hand in both of hers. They're cold. Colder than yours.
soot: Good. Good. Mm. Not soon. Not for a long time. But good.
soot: The rats will tell you. When it's time. They'll come up the pipes and sit on your bed and you'll know.
{do flag:sootLight=1; rel:soot+3; comp+1}
@end

# b2S.no
soot: No. No. Mm. Nobody can. It's all right. It's all right. I'll ask the rats.
{do rel:soot-1}
@end
`,'c_bonds2');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.millerBond==='partners')o.push(['Ines Miller and you','Partners. You turn up. She turns up. Neither of you explains anything to anybody. Precinct 3 calls you "Miller\'s night consultant" and doesn\'t ask what you consult on.']);
  else if(f.millerBond==='friends')o.push(['Ines Miller and you','Friends. She never told her sister. She tells the dog. The dog\'s called Ray.']);
  else if(f.millerDiner)o.push(['The diner on Kerr Street','Has a booth by the window that a detective and a person who never eats take every Thursday at three. The waitress has stopped asking the second one if they want anything.']);
  if(f.tinyDoor)o.push(['The Sheriff\'s door','Is kept by a very large man and a very polite one. Nobody gets past either. They argue about tea.']);
  else if(f.tinyFirm)o.push(['Tiny\'s','A van with TINY\'S on the side in big letters. Marcus drives. They do clubs, weddings, and one very confused bar mitzvah.']);
  else if(f.tinyGym)o.push(['The gym on Kerr Street','Is run by a doorman now. He teaches kids to skip, and to stand still, and never to fight for money. Marcus helps on Saturdays.']);
  if(f.gideonWill)o.push(['The Pawn & Coffin','Has a will in the till addressed to the Sheriff\'s child. Gideon is still alive, and very careful on the stairs.']);
  if(f.sootLight)o.push(['Mother Soot','Is not tired yet. When she is, the rats will tell you.']);
  return o;});
