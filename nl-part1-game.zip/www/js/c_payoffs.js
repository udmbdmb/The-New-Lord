'use strict';
/* THE NEW LORD — payoffs: things you set in motion earlier in the week come back to you */
NL.Script.add(String.raw`
# po.knock arc=severine night=4,5 label="\"My lady. Leo has something he'd like to say to you.\"" if=flag:leoKnockKnock&alive:leo&alive:sev&!flag:leoGoneTown prio=2
@focus severine
> Leo, behind you, makes a noise like a kettle realizing it's been switched on.
leo: I... no. I didn't... okay. Okay. Hi. Hello. Lady. Your Highness. Ma'am. Knock knock.
> Silence. The fan stops. Three Court Kindred at the next table stop talking. Somewhere upstairs, the bass of the dancefloor goes on, very faint, like a heart.
severine: ...I beg your pardon?
leo: You have to say "who's there". That's... that's how it works. It's a format.
> Séverine Marchetti, Keeper of Elysium, two hundred and fifty years dead, looks at you. You nod. She looks back at Leo.
severine: (with tremendous dignity) Who is there.
leo: Interrupting cow.
severine: Interrupting c—
leo: MOO.
> Nobody breathes. Nobody, in this room, has breathed for a long time anyway.
> Then, behind the fan, very faintly, a sound. It might be a cough. It is not a cough.
severine: Get out. Both of you. Get out before I have you killed. Come back on Saturday. Bring another one.
{do flag:leoMoo=1; rel:severine+1; rel:leo+2; comp+2; xp:25:Moo}
@end

# po.goose arc=malakor night=4,5 label="Hum him the lullaby. The one about the goose." if=flag:knowGooseSong&!flag:malakorDead prio=2
@focus malakor
> You hum it. You don't know the words. You only know the tune Soot hummed you through a bone microphone: up, up, down, a long note, a sad little turn at the end.
> Malakor puts down the saw. He doesn't turn round.
malakor: Where did you...
malakor: *Szła gąska do miasta.* The goose went to the city. My mother sang it. Kraków, 1809. I was four. She sang it every night and then the goose got eaten and I cried, every night, and she'd say "Mikołaj, it's only a goose," and I'd say "but it went to the city", and she'd sing it again.
malakor: Soot. Soot told you. The old rat's been listening to me in the shower.
* "She said it's the only true thing about you."  -> po.goose1
* "I won't tell anyone."  -> po.goose2

# po.goose1
> He laughs. It's a terrible laugh. He wipes his eyes with the back of a hand that's had eleven faces' worth of blood on it.
malakor: The only true thing. Yes. That's right. That's exactly right. Two hundred years, twelve faces, and the only true thing about me is a goose.
{do rel:malakor+2; comp+1}
@end

# po.goose2
malakor: No. You won't. You keep things. I've noticed.
{do rel:malakor+1}
@end

# po.tarMil arc=miller night=3,4,5 label="\"Tariq wants to tell you something.\"" if=flag:tariqTellsMiller&alive:tariq&!flag:millerDead prio=2
@focus miller
> Two a.m. The Lucky Mart. Burnt coffee. A cruller. Tariq comes round the counter, which he never does, and stands in front of Miller with his hands at his sides like a boy outside the principal's office.
tariq: I saw three of the seven. Luis, on the 9, every night. The girl with the braids. The old man in the bus jacket. And Danielle Okafor, twice, buying Tylenol, the week before she went. I saw them all and I said no, and I lied, because the two in the unmarked car would have shut me down.
tariq: I'm sorry. I'm sorry. My father would be ashamed.
> Miller puts the coffee down.
miller: Your father would be proud, Tariq. You told me. That's the part he'd be proud of.
miller: Sit down. Sit down, I'm going to need dates. Get me a cruller. I'm going to finish it this time.
{do flag:tariqToldMiller=1; rel:tariq+1; rel:miller+1; comp+1}
@end

# po.pemLeo arc=pemberton night=4,5 label="\"Did Leo ask you anything, Pemberton?\"" if=flag:leoAsksPem&alive:leo prio=1
@focus pemberton
pemberton: He did, ‹sir›. On Wednesday. In the car. He asked what I liked.
pemberton: I didn't know what to say. I said "driving, ‹sir›". He said "no, but what do you *like*". He made me think about it all the way to the Rookery.
pemberton: I like Patsy Cline. I like a fried-egg sandwich with too much pepper. I like the marine forecast on the radio at five in the morning, from when I was at sea, because it's the only thing in the world that's never changed. I like birds. Small ones. I didn't know any of that until he asked.
pemberton: He's a very irritating young man, ‹sir›. I've grown quite fond of him.
{do rel:pemberton+1; rel:leo+1; comp+1}
@end

# po.watch arc=leo night=3,4,5 label="Give Leo his grandfather's watch." if=flag:leoWatch&alive:leo&!flag:leoWatchGiven prio=3
@focus leo
> You put the tissue paper in his hand. He unwraps it. He knows before it's open. You can see it in his hands.
leo: That's... that's Grandpa's. L.P. 1958. I pawned it. I pawned it for the Boston thing, the competition, and then Mom got sick and I never...
leo: Gideon kept it. He kept it. Under the counter. For a year.
> He puts it on. The strap's cracked. He fastens it on the last hole and holds his wrist up to the light, the way his grandfather probably did.
leo: Forty dollars. I owe him forty dollars.
* "He says you can pay in jokes."  -> po.watch1

# po.watch1
leo: Jokes. Okay. Okay. I've got forty dollars of jokes. I've got, like, three dollars of jokes. I'll write more.
{do flag:leoWatchGiven=1; rel:leo+2; rel:gideon+1; comp+2}
@end

# po.ashby arc=ashby night=4,5 label="\"Ashby. 'Make sure the Magistrate sees the lance.' I heard you.\"" if=flag:heardAshby&!flag:ashbyDead&!flag:ashbyGone prio=4
@focus ashby
> Lord Ashby goes very still. Then he laughs, a little too loudly, the way he laughs at everything.
ashby: Darling. I say a great many things in cars. I'm a terrible gossip. I'm famous for it.
* "You were going to frame Malakor. For Séverine."  -> po.ashby1
* "You were going to frame me."  -> po.ashby2
? web 11 "You weren't going to frame anyone. You were warning someone. Who was in the car with you?"  -> po.ashby3 | po.ashby2 {id po_ash}

# po.ashby1
ashby: Malakor. For Séverine. Oh, you clever, clever child. You've got it almost exactly wrong.
@next po.ashby3

# po.ashby2
ashby: You. Darling, if I were going to frame you, you'd already be ash. I'm vulgar, not incompetent.
@next po.ashby3

# po.ashby3
ashby: (very quietly, not laughing) I was on the phone to Ottilie. She'd told me Harrow wanted the lance shown at the Tribunal. Shown, you understand. Brought out. Waved about. So that every Kindred in the room would see a working sun-weapon in Malakor's workmanship and panic and run for the stairs.
ashby: And at the top of the stairs, my dear, would be the lamps.
ashby: I was telling her: make sure the Magistrate sees it *first*. Privately. Before anyone else. So he'd know, and he wouldn't let it be waved about. That's all. That's all I could think of.
* "Why didn't you tell anyone?"  -> po.ashby4

# po.ashby4
ashby: Because I'm Edmund Ashby and nobody believes a word I say. That's my whole talent. It's very useful, usually. This week it's been a curse.
ashby: You believe me. Don't you. God. How horrible. How wonderful. Tell the Magistrate. He'll believe you. He'd never believe me.
{do flag:ashbyLance=1; rel:ashby+2; xp:30:In Cars}
@end

# po.valHunt arc=valko night=4,5 label="\"Valko. Did you find a scent?\"" if=flag:valkoHunts&!flag:valkoDead prio=3
@focus valko
valko: I found three. I ran all Wednesday night. From the Switchyard to St. Jude's to the river and back. My feet are bleeding. I feel wonderful.
valko: One: the lance. It went in a van from the Switchyard to St. Jude's, Sunday night, and back again Monday at six, in the same van. Grey. No plates. It smells of peppermint.
valko: Two: the doctor. She walks to work the same way every night and stops on the bridge for four minutes and looks at the water. Every night. Four minutes. Like she's deciding something.
valko: Three: something under the Switchyard. Under the platform. Fresh concrete, fresh cable, and that hum. They've been putting something in. Weeks. I don't know what. It smells like a hospital.
* "The lamps. They've wired the platform."  -> po.valHunt1

# po.valHunt1
valko: Lamps. Under the platform. Under all of us. On Friday.
> He goes very quiet. Then, for the first time since you've known him, Valko grins. It isn't a nice grin. It's a Hound's.
valko: Then I know where to dig.
{do flag:valkoDug=1; rel:valko+1; xp:30:Three Scents}
@end

# po.member arc=dutch night=5 label="Show Dutch your union card." if=flag:local0Member&flag:side_union prio=2
@focus dutch
> You take the beer-stained coaster out of the Sheriff's coat. *L0 · 1 wk · paid.*
dutch: You kept it. In *that* coat. Next to... what's in there? A flip phone. A lighter. And our card.
dutch: Dues are due again tonight, member sixty-four. Week two. A dollar.
* Pay the dollar.  -> po.member1 {if cash>=1}
* "I'm a dollar short, brother. Put it on my tab."  -> po.member2

# po.member1
dutch: Paid. In full. On time. You know how rare that is? Little Sal hasn't paid since 2019.
> He writes it on the back of the same coaster. *L0 · 2 wk · paid.* The writing's getting smaller to fit.
{do cash-1; rel:dutch+1; comp+1}
@end

# po.member2
dutch: A tab. Ha. Now you're a real member. Everyone's got a tab. The tab is the union.
{do rel:dutch+1}
@end

# po.sevSoot arc=soot night=5 label="\"Has the Keeper been down to see you, Mother?\"" if=flag:sevToSoot&alive:sev prio=2
@focus soot
soot: Been. Hm. She came. Last night. Three in the morning. In evening dress and rubber rain boots. Somebody must have told her about the stairs.
soot: She sat on my step. She didn't say anything for an hour. I didn't say anything back. Then she said, "Thank you, Mother." Just that. And went.
soot: Fifty-eight years. Fifty-eight years of listening to her through the pipes, and the first thing she says to my face is thank you.
soot: I've put it in a jar. On the top shelf. Next to the Sheriff's lullaby.
{do rel:soot+1; rel:severine+1; comp+1}
@end

# po.carve arc=tenant night=4,5 label="Look at the scar on your palm." if=flag:carveScar prio=-1
@focus tenant
> A raised pink seam across your lifeline, from Malakor's thumbnail, closed crooked. It hasn't faded. It won't.
tenant: The first scar you ever made yourself. He's right, you know. Keep it. Every Butcher I've ever known has one they keep.
tenant: Mine's the eyebrow. Corsica. A man called Orsini and a goat. I could have closed it any time in two hundred years. I never did. I liked the goat.
{do sync+1}
@end

# po.photo arc=pemberton night=4,5 label="Show Pemberton the photograph of Agnes. On your phone." if=flag:agnesPhoto prio=2
@focus pemberton
> The scanned photograph. The Courthouse steps, 1928. Third row, fourth from the left.
pemberton: ...Mrs. Dunmore.
pemberton: I never met her, ‹sir›. She died in 1961. He kept a photograph in the study, in the drawer with the pistols. I dusted round it for forty years and never looked at it properly. It seemed like his.
pemberton: She's almost smiling. He used to say that about her. "Almost smiling, Pemberton. Always almost."
* "Can you print it? For the study?"  -> po.photo1

# po.photo1
pemberton: Print it. Yes, ‹sir›. There's a place on Kerr Street. I'll have it framed. Silver. Not too much silver. She wouldn't have liked too much silver.
{do flag:agnesFramed=1; rel:pemberton+1; sync+2}
tenant: Not too much silver. He's right. How does he know that? He never met her. Forty years of dusting round her, and he knows.
@end

# po.hymn arc=severine night=5 label="\"My lady. The third line of the Dies Irae.\"" if=flag:choirHymn&alive:sev prio=2
@focus severine
severine: Not here, darling. Not on the platform. Not in front of all of them.
> But she hums it. The third line. Very quietly. You hum it back.
> And somewhere on Platform 0, a Choir fledgling you've never met picks it up. Then another. Then a dozen. Under the noise of three hundred Kindred waiting for a Tribunal, the oldest hymn in the Choir, in harmony, so quiet you'd only hear it if you were listening for it.
severine: ...Well. That's never happened before.
{do comp+2; rel:severine+1}
@end

# po.kitchen arc=tenant night=4,5 label="\"I can smell lemons. All the time.\"" if=flag:tenantKitchen prio=-1
@focus tenant
tenant: Can you? Lemons and charcoal and fish. My mother's kitchen. I gave it to you on Wednesday. Do you mind?
* "No. I like it."  -> po.kitchen1
* "It's not mine, though."  -> po.kitchen2

# po.kitchen1
tenant: Good. Good. She'd have liked you. She'd have fed you until you were sick and then told you you were too thin.
{do sync+1; comp+1}
@end

# po.kitchen2
tenant: No. It's not. But it's the closest thing to a mother's kitchen you've got now. Borrow it. I'm not using it. I've got the memory of it; you've got the smell. Between us, it's whole.
{do sync+1}
@end

# po.rosH arc=harrow night=4,5 label="\"Rostova says you sign everything twice.\"" if=flag:rosHarrow&!flag:harrowDead prio=2
@focus harrow
harrow: She... what?
> He looks at his own hand. At the pen in it. He's been signing something on the hood of the van when you came up. He's signed it twice. Once in the box. Once in the margin, very small.
harrow: I didn't... I've never noticed. Twenty-two years. I didn't notice.
harrow: My father did that. On cheques. He said the bank needed to know he meant it.
* "Do you mean it? Any of it?"  -> po.rosH1

# po.rosH1
> He doesn't answer for a long time. A train goes over the bridge above you, empty, lit, three in the morning.
harrow: I used to. I used to mean all of it.
> He tears the form in half. Not dramatically. Like a man tearing up a parking ticket he's decided not to pay. He puts both halves in his pocket.
harrow: That doesn't mean anything. That was a requisition for batteries.
harrow: ...It was a requisition for batteries for the lamps.
{do flag:harrowDoubt=1; rel:harrow+1; xp:30:Twice}
@end
`,'c_payoffs');
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);const f=S.flags;
  if(f.ashbyLance&&!f.ashbyDead)M.push({t:'"Magistrate. Before anyone shows you a lance tonight: Lord Ashby has something to tell you. Privately. He was right, and nobody believed him."',once:'tb_ashlance',ok:st=>{st.prog+=1;st.threat=Math.max(0,st.threat-2);return [T('Ashby rises, for once not smiling, and crosses the chalk, and bends to the Magistrate\'s ear. It takes thirty seconds.'),L('magistrate','...Thank you, Lord Ashby. Sit down.'),L('magistrate','No weapon will be shown in this circle tonight. Anyone who produces one will answer to me. Personally.'),T('On the Court benches, somebody in grey pearls puts something back in her bag very slowly.')];}});
  if(f.valkoDug&&!f.valkoDead)M.push({t:'"Valko. Show them what you found under the platform."',once:'tb_dug',ok:st=>{st.prog+=2;return [T('Valko vaults the edge of the platform onto the tracks, and with his bare hands lifts a square of fresh concrete as if it were a manhole cover. Underneath: cable. New cable. Running east.'),L('magistrate','...What is that.'),L('valko','Lamps. Under us. All of us. Somebody wired the Tribunal.'),T('Three hundred Kindred look down at the floor they\'re standing on.')];}});
  if(f.leoMoo&&!f.sevDead)M.push({t:'Catch Séverine\'s eye. Mouth, silently: "Moo."',once:'tb_moo',ok:st=>{st.threat=Math.max(0,st.threat-1);return [T('The Accuser\'s next sentence goes slightly wrong in the middle. She covers it with the fan. She doesn\'t look at you again for nearly a minute.')];}});
  return M;};})();
