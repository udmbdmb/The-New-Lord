'use strict';
/* THE NEW LORD — "The Bottled Dawn": where the Sun-Vessel came from, and whose morning is inside it */
(function(){NL.TASKS.s_dawnbottle={n:'The Bottled Dawn',xp:60,cat:'side'};})();
NL.Script.add(String.raw`
# vz.0 arc=ottoline night=3,4,5 label="\"Ottoline. Look at this.\" (The Vessel.)" if=has:vessel&room:apt prio=6
@focus ottoline
> You hold it out. Brass and quartz, warm as a wrist, noon moving slowly inside it like honey.
> Ottoline goes very still. Then she takes off her glasses, and puts on another pair from her pocket, thicker, with a little jeweller's loupe clipped to one lens.
ottoline: Oh. Oh, my. Oh, Grandmère.
ottoline: This is Vass work. My grandmother's. Look at the seal, the little spiral in the brass. That's her mark. Lyon. The Terror. She made three of these. I thought they were all lost.
{do task:s_dawnbottle; note:s_dawnbottle|Ottoline recognizes the Sun-Vessel: Vass work, made by her grandmother in Lyon during the Terror.}
* "What is it? Really?"  -> vz.what
* "Who did she make it for?"  -> vz.who

# vz.what
ottoline: A morning. One morning. Caught at the moment the sun clears the horizon and held. Alchemy, of the old sort. You promise the dawn something, and the dawn keeps its side.
ottoline: It's not a weapon. People make it a weapon. It's a cure. Turned gently, a quarter-inch, it can give one of us the morning back. Once. For good. Turned all the way, it's just a sun in a small space, and everything near it burns.
@next vz.who

# vz.who
ottoline: For whom. Hm. She never said. She kept a ledger, though. We always keep ledgers. "Third vessel. Commissioned by a lady of the Lyon court. Contents: the morning of the 14th of October, 1793, as seen from the window of a house on the Rue Mercière."
ottoline: October 1793. The week the Republic took Lyon back, and started taking heads.
web(7): A lady of the Lyon court. A house with a window. A morning. Séverine's priest went to the window to watch the sunrise. "Mercy goes to the window."
* "It's the morning her priest died. Séverine's."  -> vz.sev {if mem:severine.lyon}
* "Who was the lady?"  -> vz.lady

# vz.lady
ottoline: The ledger doesn't say. Grandmère was discreet. She only wrote: "The lady wept and paid in pearls. She said: I want the morning he saw. I want to be able to see it, too, one day, when I'm brave enough."
@next vz.end

# vz.sev
> Ottoline looks at you for a long moment over the loupe.
ottoline: You know who. Of course you do. You've been collecting everybody's secrets all week like a magpie.
ottoline: Then you're holding the morning a priest called Antoine walked to the window to see, in 1793, a few hours before they took his head. And a lady paid my grandmother in pearls to bottle it, so that one day she could see it too.
ottoline: She's had two hundred years to be brave enough. She never was. And then it sank with a ship in 1911, on its way to her, and she thought it was gone.
{do flag:knowVesselOrigin=1; xp:30:The bottled morning}
@next vz.end

# vz.end
ottoline: Be careful with it. It's not a lamp. It's somebody's morning. Somebody's last one.
@end

# vzS.0 arc=severine night=4,5 label="\"My lady. I know whose morning is in the Vessel.\"" if=flag:knowVesselOrigin&alive:sev&!flag:vzTold prio=7
@focus severine
> She doesn't ask what you mean. She goes white. Whiter.
severine: Who told you.
* "Ottoline Vass. It's her grandmother's work."  -> vzS.1

# vzS.1
severine: Vass. The Alchemist's granddaughter. In the Ward. Of course. Everything comes back this week.
> She sits down. Not on her chair. On the cold stone step of the ossuary, in her evening dress, like a girl on a doorstep.
severine: Rue Mercière. A house with a window over the river. October. He'd been in my cellar three weeks. He said he missed the sun. He said, "Séverine, I'd give anything to see it once more." I said, "Don't. Please." He went anyway. Up the stairs. To the window.
severine: I paid a woman in pearls to bottle that morning, because I couldn't bear that he'd seen it and I hadn't. I thought one day I'd open it, gently, a quarter-inch, and see what he saw, and go into it with him.
severine: Then it went down with the *Corvina* in 1911 and I thought: good. Good. Now I'll never have to decide.
* "You still could. When this is over. A quarter-inch."  -> vzS.offer
* "It's yours. When Friday's done, I'll bring it to you."  -> vzS.give {do promise:vesselsev:Give Séverine the Vessel after Friday}
* "It's going to save the Ward on Friday. Whatever happens to it."  -> vzS.ward

# vzS.offer
severine: A quarter-inch. And then what? Then I'm a woman who can walk in the morning, two hundred years too late, with nobody left who knew me when I couldn't.
severine: ...Let me think about it. For a century or so.
{do flag:vzTold=1; rel:severine+2}
@end

# vzS.give
> She looks at you. Her face does something you've never seen it do. It falls open, like a door.
severine: Mine. After. You'd do that.
severine: Then I'll stand behind you on Friday, darling, and not because it's policy. Because I want to be alive on Saturday to find out what I'd do with it.
{do flag:vzTold=1; flag:side_court=dawn; flag:sevPardon=1; rel:severine+4}
@end

# vzS.ward
severine: Save the Ward. With his morning. With Antoine's sun.
severine: ...Yes. Yes. He'd have liked that. He was always going on about the poor. Use it. Use it well. Don't you dare waste it.
{do flag:vzTold=1; rel:severine+2}
@end
`,'c_vessel');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];if(f.vzTold&&!f.sevDead){if(S.promises&&S.promises.vesselsev&&S.promises.vesselsev.kept!==false&&f.vesselHeld)o.push(['The third Vass vessel','Sits in a safe in a coffin behind the ossuary, a quarter-inch from open. Séverine looks at it every dawn, for about four minutes. She hasn\'t turned it yet. She says she\'s waiting until she\'s brave enough. She says it\'s nearer.']);else o.push(['Lady Séverine','Knows that somebody else knows about the morning on the Rue Mercière. It has made her, by every account, very slightly kinder. Nobody in the Court can work out why.']);}return o;});
