'use strict';
/* THE NEW LORD — the world changes: walking back into places after you've changed them */
(function(){const E=NL.Act.pushEnter,C=NL.Script.cond;
const on=(room,id,cond)=>{const c=C(cond);E(room,async(S,G)=>{if(S.flags['wd_'+id])return;if(!c(S,G))return;S.flags['wd_'+id]=1;await G.talk('wd.'+id);});};
on('luckymart','nosign','flag:tariqStays&night>=4');
on('luckymart','calendar','flag:racketDone=calendar&night>=4');
on('luckymart','light','night:5&flag:job_tariq=shop');
on('pawn','boxes','flag:cohortGideon&night>=4');
on('pawn','priya','flag:newbSafe=gideon&night>=4');
on('pawn','box7','flag:box7Open&night>=4');
on('reliquary','coral','flag:coralFree&night>=4');
on('reliquary','painting','flag:lisettePaint');
on('vip','gramophone','flag:sixcSev');
on('vip','rose','flag:sevApologisedWinter&night>=4');
on('rookery','empty','flag:doorsDone');
on('rookery','cats','flag:door302');
on('shrine','rafts','done:s_rafts');
on('stjude','blinds','flag:cohortRos&night>=4');
on('alley','scrubbed','night>=4&flag:cablesCut');
on('switchyard','banner','night:5&flag:side_union&time<200');
})();
NL.Script.add(String.raw`
# wd.nosign
> The For Sale sign is gone from the Lucky Mart window. There's a pale rectangle on the glass where the tape was, and a new sign in Tariq's careful marker: OPEN ALL NIGHT. AS USUAL.
@end

# wd.calendar
> Behind the till, the 2014 calendar, back on its nail. Under it, taped to the wall, a Mars bar wrapper, flattened, with a date on it in biro. Tariq doesn't explain it. You don't ask.
@end

# wd.light
> Every light in the Lucky Mart is on. Every single one, even the broken strip over the freezers, which somebody has fixed. The kettle's on. There are six people in here you've never seen before, standing by the magazines with cups of terrible coffee, not buying anything, not saying anything. Waiting it out somewhere bright.
pulse(4): Six heartbeats, all a little fast. Not frightened. Just not alone.
@end

# wd.boxes
> At the back of the Pawn & Coffin, boxes twelve and fourteen have little cardboard labels on them now, in Gideon's copperplate. Not names. Just: *OCCUPIED. KNOCK.* From inside twelve, very faintly, someone is reading out loud.
@end

# wd.priya
> Box nine is open. Priya is sitting up in it with *Middlemarch* on her knees, a pencil in her teeth, underlining. She waves without looking up. Gideon, at the counter, gives you a look that says: she's on chapter thirty, and she's arguing with it.
@end

# wd.box7
> On the counter, beside the till, propped against the cash register: a photograph in a cheap frame. A red-haired girl, a woman in a cardigan, and a much younger Gideon, laughing at something outside the frame. Christmas, 1982.
@end

# wd.coral
> At the bar, on the customer side, in jeans, with a coffee: Coral. She sees you and raises the cup. Behind the rope, Tiny catches your eye and very nearly smiles.
@end

# wd.painting
> Behind the bar at the Reliquary, where the mirror used to be: a painting of a girl in red on a chair by a window. Hamburg, 1919. The mouth, almost a smile, almost not. Lisette, across the room, counting, keeps glancing at it, and losing count, and starting again.
@end

# wd.gramophone
> The gramophone in the ossuary is silent tonight. The Caruso record is in its sleeve on top of it. Séverine, on her sarcophagus, is humming the aria very quietly, slightly out of tune, slower than the record. The way an old man sings it in a bath on the sixth floor.
@end

# wd.rose
> On the cracked skull of Brother Anselm, on the ossuary wall, somebody has left a single white rose, and propped against it, a small card in purple ink: *1983. For the Wraith girl. — The Court.*
@end

# wd.empty
> The Rookery is dark. Every flat. Not a radio, not a television, not a baby. Somebody has left a note taped to the inside of the front door in Doreen Finch's handwriting: *EVACUATED. GAS LEAK. ALL RESIDENTS ACCOUNTED FOR. — T.A.*
> In the stairwell, very faintly, you can smell bath salts and cat food and jollof.
@end

# wd.cats
> The yard behind the bins is empty. No cats. Not one. For the first time in six years, nobody's rattling a bag at eleven. Somewhere in Bayside, in a laundry basket at Maureen's sister's, thirty-one cats are being very offended about it.
@end

# wd.rafts
> On the black water of the cistern, among Soot's hundred candles, the rafts you lit are still burning. Ray's. Rask's, a little apart from the others. They haven't moved. Mother Soot says they never do. She says that's the point of the cistern: it's the one water in the city that doesn't take anything away.
@end

# wd.blinds
> On the fourth floor, the blinds in Rostova's office are up. Through the glass, in the corridor light, two people sit on plastic chairs with their sleeves rolled up while she takes blood: a woman in a blanket and a big man with grey at his temples. She's talking to them. They're laughing at something she said. You didn't know she could make anyone laugh.
@end

# wd.scrubbed
> On Ferrier Lane, the junction box on the wall by the manhole has been opened and left hanging. Three men in grey overalls are standing round it with flashlights, looking at a neatly cut cable, and arguing. One of them is saying "rats" in a voice that doesn't believe it.
@end

# wd.banner
> At the far end of Platform 0, by the east tunnel, sixty-three clanless Kindred in their least-ripped jeans, with thermoses. And above them, tied between two pillars with string, a bedsheet painted in house paint: WE ARE ALSO THE WARD.
> Every Gilded courtier who comes down the stairs looks at it. None of them say anything. A few of them look at it for longer than they mean to.
@end
`,'c_world');
