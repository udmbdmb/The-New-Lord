'use strict';
/* THE NEW LORD — the Tenant's stories, part two */
NL.Script.add(String.raw`
# tnT.gasp arc=tenant night=3,4,5 label="Ask him how Gaspard died." if=mem:tenant.gaspard prio=-2
@focus tenant
tenant: 1849. Genoa. Cholera in the city, revolution in the streets, and Gaspard in his palazzo counting what I'd stolen from him for sixty years.
tenant: He called me into the study. He said, "Absalom, I always knew." I said, "I know you knew." He said, "Then why haven't you killed me?" I said, "Because you never asked me to stop."
tenant: Then he asked me to stop. So I killed him. It seemed to be what he wanted. He thanked me.
* "Did you drink him? Like I drank you?"  -> tnT.g1
* "That's horrible."  -> tnT.g2

# tnT.g1
tenant: No. No. I staked him and left him for the sun on his own balcony, facing the sea. Diablerie is... it was a crime even then. I was a coward even then.
tenant: You were braver than me in that freezer. You didn't stake me. You took me in.
{do sync+1}
@end

# tnT.g2
tenant: It was. It was. Two hundred years and I still dream about his face when he said thank you.
@end

# tnT.paris arc=tenant night=3,4,5 label="Ask him about his sabbatical in Paris." if=seen:tnS.1946 prio=-2
@focus tenant
tenant: 1921 to 1924. Paris. I told the Prince I was ill. I wasn't ill. I was bored. Eighty years of Sheriff-ing and I wanted to sit in a café in Montparnasse and be ignored by painters.
tenant: I was ignored by some very famous painters. I won't say who. One of them asked me to sit for a portrait. I said no. He said I had "an interesting absence where the face should be". I've always thought that was the best review I ever got.
tenant: I came back in the autumn of 1924 because the Prince wrote and said the Ward was falling apart. It wasn't. She was lonely. Three months later I broke a drawer at the Courthouse.
@end

# tnT.lisbon arc=tenant night=4,5 label="Ask him about the Gilded boy in Lisbon." if=seen:am.fair2|seen:fy.sit prio=-2
@focus tenant
tenant: Ah. The Lisbon boy. Everyone tells that story. Ambrose tells it as a lesson in fairness. Freddie told it as a joke.
tenant: The truth is: he was nineteen in his face and two hundred in his teeth, and he'd eaten his sire's ghoul's wife because she was dying of tuberculosis and begged him to. He did it gently. He held her hand.
tenant: Ambrose burned him fairly at dawn. And held his hand too. I was there. I've never seen Ambrose cry before or since. He did it with his face perfectly still.
@end

# tnT.hamburg arc=tenant night=4,5 label="Ask him if he knew Lisette's painter." if=mem:lisette.hamburg prio=-2
@focus tenant
tenant: Konrad. Konrad Esser. Yes. 1923. I bought a sketch from him in Hamburg on my way back from Paris. Charcoal. A girl's hand. Just the hand.
tenant: He said he was painting a girl in red and couldn't get the mouth. He'd been at it four years. I said: "Konrad, perhaps the mouth is the one thing about her that doesn't sit still." He laughed and said that was the most useless advice he'd ever had.
tenant: Seven years later he walked into the Elbe. I've always wondered if I said the wrong thing.
* "You said the right thing. He just didn't hear it."  -> tnT.h1

# tnT.h1
tenant: ...Perhaps. Perhaps. The sketch is in the study. Behind the brown rug, where I hid the things I didn't want Pemberton to dust. A girl's hand. It's Lisette's. I never knew.
{do flag:knowSketch=1}
@end

# tnT.car arc=tenant night=3,4,5 label="Ask him about the car." if=flag:carOK prio=-2
@focus tenant
tenant: The Continental. 1971. Bought new, from a dealer on the Heights who was very surprised to be paid in gold at midnight.
tenant: Fifty-three years. It's had four engines, three sets of seats, two owners who weren't me for a week each in 1977 and 1999, and one Pemberton.
tenant: "Nobody touches my car." It was my third law. A joke. It's the only one they all kept. I think that tells you everything about the Court. They'll ignore anything that matters, and obey anything that's funny.
@end

# tnT.mayor arc=tenant night=4,5 label="Ask him what the worst thing he ever did as Sheriff was." if=rep:candour>=2 prio=-2
@focus tenant
tenant: The worst thing. Not the most violent. The worst.
tenant: 1958. The Mayor of Port Vellum found out. About us. A photograph, a ghoul who talked. He was going to go to the newspapers. He was a good man. He had four children.
tenant: I went to his house at three in the morning and sat on the end of his bed and took it out of his head. All of it. The photograph, the ghoul, the week. And because I was tired and careless, I took a little more. His wife's birthday. His youngest daughter's name.
tenant: He spent the rest of his life knowing he'd forgotten something important and not knowing what. His daughter never forgave him. I did that. To keep the Masquerade. I'd do it again, probably. That's the worst thing.
* "Would you? Do it again?"  -> tnT.m1
* "Don't ever ask me to do that."  -> tnT.m2

# tnT.m1
tenant: ...I don't know any more. You've made me not know. A week ago I'd have said yes.
@end

# tnT.m2
tenant: I won't. I promise. On Agnes. I won't.
{do sync+1}
@end

# tnT.duel arc=tenant night=4,5 label="Ask him to tell you about Corsica. The duel." if=mem:magistrate.goat|seen:fc.wrong prio=-2
@focus tenant
tenant: Count Orsini. A woman neither of us liked. Dusk, 1790, on a hillside above Ajaccio, the last light gone, both of us very newly dead and very stupid, with Ambrose holding the handkerchief and a goat watching.
tenant: I was a dreadful swordsman then. The three Court championships came later, out of spite, because of what happened next. He cut my eyebrow in the first pass, the left one, and I fell over backwards into the goat pen. The goat was furious.
tenant: Orsini came to finish me and slipped in what the goat had been doing all night, and I got up, and stuck him in the arm, not hard, and he yielded. Ambrose laughed so hard he dropped the handkerchief in the goat pen. That's why he says I owe him forty francs. For the handkerchief.
tenant: He kept it, you know. The handkerchief. With my blood on it. I didn't know until this week.
{do sync+1; comp+1}
@end
`,'c_tenant4');
