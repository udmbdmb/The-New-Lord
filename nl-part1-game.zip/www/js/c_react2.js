'use strict';
/* THE NEW LORD — reputation reactions, part two: the edges of the Ward have opinions too, and so does the man in your blood */
NL.Script.add(String.raw`
// =====================================================================
// THE TENANT · on what you're becoming
// =====================================================================
# rTn.merc arc=tenant night=3,4,5 label="Ask him what he thinks of your mercy." if=rep:mercy>=4 prio=-1
@focus tenant
tenant: Your mercy. You want my opinion of it. Very well.
tenant: In 1946 I had a man in my study who'd fed on a child. I let him live, because his sire was useful. He fed on two more before the Prince had him burned. I was merciful, child, and three families paid for it.
tenant: I'm not saying you're wrong. I'm saying mercy is a loan. Someone always repays it. Make sure it's you.
* "Then I'll repay it."  -> rTn.merc1
* "You're telling me to be harder."  -> rTn.merc2

# rTn.merc1
tenant: Good. That's the only kind of mercy worth having: the kind that sends you the bill.
{do sync+1}
@end

# rTn.merc2
tenant: No. I'm telling you to be awake. Mercy with your eyes shut is just laziness in a nicer coat.
@end

# rTn.ruth arc=tenant night=3,4,5 label="He's been quiet since the last one. Ask him why." if=rep:mercy<=-4 prio=-1
@focus tenant
tenant: Quiet. Yes. I've been counting.
tenant: I killed eleven people in eighty years as Sheriff. Every one I can tell you the name of, the date, the reason. I thought the reasons mattered. I still think so.
tenant: You're catching me up, child. Faster than I'd like. And I don't think you know all their names.
* "I don't."  -> rTn.ruth1 {do lean:candour+1}
* "Their names don't matter."  -> rTn.ruth2
* "Then stop me."  -> rTn.ruth3

# rTn.ruth1
tenant: No. Then learn one. Just one. Go back to wherever it happened and find out who they were. It won't help them. It will help you stay a person.
{do flag:tenantNames=1}
@end

# rTn.ruth2
> A long silence in your blood.
tenant: That is the most frightening thing anyone has said to me since 1720.
{do sync-2; comp-1}
@end

# rTn.ruth3
tenant: I can't. I live here. I can only watch. And remember. Someone has to.
@end

# rTn.honest arc=tenant night=3,4,5 label="Ask him if he minds that you tell everyone everything." if=rep:candour>=4 prio=-1
@focus tenant
tenant: Mind? I'm appalled. I'm delighted. I'm both.
tenant: I lied for eighty years. To the Court, to the Prince, to Pemberton, to myself. The only person I ever told the whole truth to was a typist in 1926, and she asked if it hurt.
tenant: One honest person in eighty years. That's my record. You've beaten it by Wednesday.
tenant: Go on telling the truth. It saves so much time.
{do sync+1; comp+1}
@end

# rTn.liar arc=tenant night=3,4,5 label="Ask him what he thinks of your lies." if=rep:candour<=-4 prio=-1
@focus tenant
tenant: Your lies are very good. Better than mine. I'm almost proud.
tenant: But you've started lying to me, child. Inside. About what you want. I can feel it. It's like someone moving the furniture in a house you're both living in.
* "I'm not lying to you."  -> rTn.liar1
* "...What do I want?"  -> rTn.liar2

# rTn.liar1
tenant: There. Like that.
@end

# rTn.liar2
tenant: You want somebody to forgive you without having to ask. Everybody does. Nobody gets it.
{do comp+1}
@end

# rTn.court arc=tenant night=4,5 label="He says you walked into Elysium like him tonight." if=rep:pride>=4 prio=-1
@focus tenant
tenant: You walked into Elysium tonight like me. The chin. The pause at the door. The "I see." I watched Lisette count you and lose her place.
tenant: I don't know if I'm flattered or frightened. I spent forty years building that walk. You've borrowed it in a week, and you wear it better.
* "Should I stop?"  -> rTn.court1
* "It's ours now."  -> rTn.court2

# rTn.court1
tenant: No. Use it. Just remember it's a coat, not a skin. Take it off when you go home.
@end

# rTn.court2
tenant: Ours. Yes. God help the Court.
{do sync+2}
@end

# rTn.street arc=tenant night=4,5 label="He wants to talk about the Lucky Mart." if=rep:pride<=-4 prio=-1
@focus tenant
tenant: You spent forty minutes tonight on the floor of a corner shop eating chips you can't digest with a man who sells scratch cards. Potato chips. Whatever.
tenant: I never once in eighty years sat on a floor. I had a man to carry chairs.
tenant: ...It was rather nice. Don't tell anyone I said so.
{do sync+1; comp+1}
@end

# rTn.faith arc=tenant night=4,5 label="Ask him why he's angry." if=rep:loyalty<=-3 prio=-1
@focus tenant
tenant: Angry. I'm not angry. I'm a Sovereign. Sovereigns don't get angry. They get *disappointed*, and then somebody's estates go to the Crown.
tenant: You break your word. Not often. Enough. A promise is the only thing a creature like us has that the sun can't take.
* "I'll keep the next one."  -> rTn.faith1
* "Promises are for people with time."  -> rTn.faith2

# rTn.faith1
tenant: Then make it a small one. Keep it. Make another. That's how you build it back. Brick by brick.
@end

# rTn.faith2
tenant: We have nothing BUT time, child. That's exactly why they matter.
{do sync-1}
@end

// =====================================================================
// LISETTE · station
// =====================================================================
# rLs.court arc=lisette night=3,4 label="\"Lisette. You stopped counting me.\"" if=room:reliquary&!flag:lisetteGone&rep:pride>=3 prio=-1
@focus lisette
lisette: Did I? Hm. I suppose I did.
lisette: One counts the people one might have to remove. One stops counting the people one might have to *obey*. It's a small change. You'd be amazed how few people notice.
* "And which am I?"  -> rLs.court1

# rLs.court1
lisette: Ask me on Saturday.
{do rel:lisette+1}
@end

# rLs.street arc=lisette night=3,4 label="\"Lisette.\"" if=room:reliquary&!flag:lisetteGone&rep:pride<=-3 prio=-1
@focus lisette
lisette: Darling. You've got sawdust on your coat. And something on your shoe that I very much hope is mud.
lisette: The Court has a book running on how long you'll last. I put twenty on Friday. Out of affection.
* "Friday?"  -> rLs.street1
* "Change your bet."  -> rLs.street2

# rLs.street1
lisette: Dawn on Friday. Up the Switchyard stairs. It's nothing personal. You just look like someone who'll get burned for being nice.
@end

# rLs.street2
lisette: To what? Saturday? Don't be absurd. I'd need a reason.
? velvet 11 "Because you like me, and you hate losing money."  -> rLs.street3 | rLs.street4 {id rLs_bet}

# rLs.street3
> She laughs, a real one, sharp and short like glass breaking.
lisette: Both true. Fine. Fifty on Saturday. Don't make me look stupid.
{do rel:lisette+2; flag:lisetteBet=1}
@end

# rLs.street4
lisette: I like nobody, darling. Twenty on Friday stands.
@end

// =====================================================================
// CORAL · mercy
// =====================================================================
# rCo.merc arc=coral night=3,4 label="\"Coral. The girls are looking at me.\"" if=room:reliquary&rep:mercy>=3&!flag:coralFree prio=-1
@focus coral
coral: Yeah. They talk about you in the dressing room. "The one who doesn't bite." "The one who asks your name."
coral: Mia said you sat with her on the fire escape while she had a panic attack and you didn't touch her once. She said it was the first time in a year somebody from downstairs didn't want anything.
coral: You're going to get a reputation. The kind that's dangerous down here.
* "What kind?"  -> rCo.merc1

# rCo.merc1
coral: Kind. The dangerous kind is kind. Everyone downstairs knows how to handle cruel. Nobody knows what to do with kind. They'll either worship you or kill you.
{do rel:coral+1}
@end

// =====================================================================
// ASHBY · candour
// =====================================================================
# rAb.true arc=ashby night=3,4 label="\"Lord Ashby. You're sober.\"" if=room:vip&rep:candour>=3&!flag:ashbyDead&!flag:ashbyGone prio=-1
@focus ashby
ashby: I am! It's appalling. I haven't been sober since the Coronation. The first one.
ashby: It's your fault. You keep telling people the truth and it's catching. I told Lisette her hat was ridiculous. She agreed! We had a lovely conversation!
ashby: Is this what it's like? Being honest? Everyone's so much less tiring.
* "It gets worse. You start meaning things."  -> rAb.true1

# rAb.true1
ashby: Meaning things. God. No. Pass me that glass.
> He doesn't drink it.
{do rel:ashby+1}
@end

// =====================================================================
// DUTCH · station
// =====================================================================
# rDu.street arc=dutch night=3,4 label="\"Dutch.\"" if=room:switchyard&rep:pride<=-3&!flag:local0Done prio=-1
@focus dutch
dutch: Brother, sister, whatever. The membership's been talking. Vote of the floor, Tuesday, unanimous.
dutch: Honorary member. Local 0. You've got no clan worth the name, no Court ring, and you sat on the floor of the Lucky Mart. That's three of the five requirements.
* "What are the other two?"  -> rDu.street1

# rDu.street1
dutch: Four: you have to have been told you're nothing by somebody in a velvet coat. Five: you have to have kept going anyway.
dutch: I'm told you've done both.
> He gives you a badge. Enamel, chipped, from 1987. A screwdriver crossed with a candle. LOCAL 0.
{do rel:dutch+2; flag:local0Badge=1}
@end

# rDu.court arc=dutch night=3,4 label="\"Dutch. You're not looking at me.\"" if=room:switchyard&rep:pride>=4&!flag:local0Done prio=-1
@focus dutch
dutch: Not looking. No. You've got the walk now. His walk. The velvet walk.
dutch: Nothing personal. Every Sheriff's had it. Absalom had it. Absalom was all right, as Sheriffs go. He still never once came down here.
* "I'm down here now."  -> rDu.court1
* "I'll come down when I'm Sheriff."  -> rDu.court2

# rDu.court1
dutch: You are. Yeah. With the walk. It's confusing for the membership.
{do rel:dutch+1}
@end

# rDu.court2
dutch: That's what they all say.
{do rel:dutch-1}
@end

// =====================================================================
// JUNIE · mercy, candour
// =====================================================================
# rJu.0 arc=junie night=5 label="\"Junie. Leo told you about me.\"" if=room:rookery&!flag:junieDone&rep:candour>=3 prio=-1
@focus junie
junie: He told me everything. Two in the morning, on the phone, crying. "Junie, my best mate's a vampire and they're honest about it." That's what got him. Not the vampire part. The honest part.
junie: I'm a nurse. Nights. I've seen everything. I've seen a man with a lightbulb in... never mind. I've never seen anyone be honest with Leo. Not Dad, not his exes. Not me, half the time.
* "He deserves it."  -> rJu.0a

# rJu.0a
junie: He does. Look after him. If you're going to be in his life, be in it properly. He's not good at half.
{do rel:junie+1; rel:leo+1}
@end

// =====================================================================
// GIDEON · mercy
// =====================================================================
# rGi.merc arc=gideon night=3,4,5 label="\"Gideon. You've put a box by the door.\"" if=alive:gideon&rep:mercy>=4 prio=-1
@focus gideon
gideon: Box twelve. By the door. With a sign. I wrote it this afternoon.
> The sign, in his best copperplate: *FOR WHOEVER NEEDS IT. NO CHARGE. ASK FOR NOTHING. — By order of the Sheriff's child.*
gideon: I hope you don't mind me using your name. Well. Not your name. Your title. You'd started doing it anyway, from what I hear. Finding people boxes.
{do rel:gideon+1; comp+1}
@end

// =====================================================================
// MARGO · faith
// =====================================================================
# rMg.faith arc=margo night=4,5 label="\"Margo. You look disappointed.\"" if=!flag:margoDead&rep:loyalty<=-3 prio=-1
@focus margo
margo: I'm seventy-one. I always look disappointed. It's my resting face.
margo: ...But yes. I heard about the promises. The broken ones. People talk on Platform 0. It's all they do.
margo: I ran Kowalski's for forty years. Every Friday I promised Mrs. Pell her mince would be lean. Every Friday it was. She never once checked. She didn't have to. That's what a promise is. It's the thing nobody has to check.
* "I'll do better, Margo."  -> rMg.faith1

# rMg.faith1
margo: Don't tell me. Show Mrs. Pell.
@end

// =====================================================================
// TEO · candour
// =====================================================================
# rTe.0 arc=teo night=5 label="\"Teo. You're looking at me like Ines does.\"" if=room:switchyard&rep:candour>=3&!flag:teoGone prio=-1
@focus teo
teo: Do I? That's... she looks at people like she's taking notes. Mom used to say it. "Ines, stop interviewing the guests."
teo: I've been lying to her for thirteen years. Just by not being there. You've been telling her the truth for five days, and she trusts you more than me.
teo: How do you do it? Tell the truth, I mean. When it costs?
* "You open your mouth before you can stop yourself."  -> rTe.0a
* "You decide the truth is cheaper in the long run."  -> rTe.0b

# rTe.0a
teo: Before I can stop myself. Okay. I can do that. I'm nineteen. I'm good at not stopping myself.
{do rel:teo+1}
@end

# rTe.0b
teo: The long run. I've got a really long run.
{do rel:teo+1}
@end
`,'c_react2');
