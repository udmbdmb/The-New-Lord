'use strict';
/* THE NEW LORD — Night Five, part two: Séverine, Malakor and Soot before the Tribunal; and at dawn, before the last choice, a word with whoever is still standing */
NL.Script.add(String.raw`
// =====================================================================
// BEFORE ONE O'CLOCK
// =====================================================================
# sx5.0 arc=severine night=5 label="\"My lady. Before the Tribunal.\"" if=room:vip&alive:sev
@focus severine
> The crypt is empty. Everyone's gone down to Platform 0 already. Séverine is alone on her sarcophagus with a hand mirror she isn't looking into, and a single sheet of paper folded very small.
severine: You came here. Not down there. Here. To me. Two hours before I stand up in front of the Prince's Magistrate and accuse you of murder.
severine: Either you're very stupid or you want something. Sit. Tell me which.
* "I wanted to ask you not to."  -> sx5.ask
* "I wanted to know what's on the paper."  -> sx5.paper
* "I wanted to give you something."  -> sx5.give {if flag:sevBoxSecret|has:vessel|flag:knowSevSire}

# sx5.ask
severine: Not to accuse you. Oh, child. I *must*. It's the law. The Keeper of Elysium accuses the diablerist. It's been the law since before Lyon.
severine: But there's accusing, and there's *accusing*. I can say the words and sit down. Or I can say the words and keep talking.
@gate like:severine>=3 ? sx5.soft : sx5.hard

# sx5.soft
severine: I'll say the words and sit down. You've been... you've been the most interesting week I've had in a hundred years. I'd hate for it to end in a bonfire.
{do flag:sevSoft=1; mem:severine:soft}
@next sx5.hub

# sx5.hard
severine: I haven't decided. You'll know when I stand up. Watch my hands. If they're folded, you have a chance.
@next sx5.hub

# sx5.paper
> She unfolds it. A letter. Old paper, a seamstress's hand, French.
severine: The twenty-seventh letter. My mother's. I never opened it. It came in 1920, the week after my sire died on the quay. I've carried it for a hundred and four years because I knew what it would say and I couldn't bear to read it.
severine: Read it to me. You. Now. I can't.
* Read it.  -> sx5.read {do lean:mercy+1}
* "It's yours to read, my lady."  -> sx5.dont

# sx5.read
> You read it. Your French comes from somewhere: a classroom, a textbook, a life you don't remember having.
> *Ma petite. I am very old now and the doctor says the winter will be my last. I don't need you to come home. I have understood for a long time that you cannot. I only want you to know that every night I leave the lamp on in the window, the way I did when you sang late at the Opéra. It's on now. It will be on until it isn't. Your Maman.*
> Séverine doesn't move. Then, very slowly, the candles in the bone chandelier lean toward her, all of them, like flowers to a window.
severine: ...A lamp in a window. Of course. Of course she did.
{do flag:sevLetterRead=1; rel:severine+3; mem:severine:mother; lean:pride-1}
severine: Get out. Please. Get out before I do something unforgivable, like thank you.
@end

# sx5.dont
severine: Mine to read. Yes. One day. Not tonight.
@next sx5.hub

# sx5.give
severine: Give me something. On Tribunal night. How very irregular. What?
* Kneel, and offer her the Vessel. "Tribute."  -> sx5.vessel {if has:vessel&flag:sevVesselOffered}
* "Your secret's still safe. I told no one about the letters."  -> sx5.secret {if flag:sevBoxSecret&!flag:sevSecretSold}
* "Tonight, if the lamps come on, it's Harrow on the street. If you want him, he's yours. I won't take that from you."  -> sx5.harrow {if flag:knowSevSire}

# sx5.vessel
severine: Here? Not in front of the Court?
severine: ...No. You're right. Here. Where nobody sees. So that when I stand up down there, I'm not a woman who's been given something. I'm a woman who has something.
> She takes it. She holds it in both hands like a lamp.
{do take:vessel; flag:vesselGiven=court; flag:side_court=tribute; rel:severine+3; mem:severine:tribute}
severine: Thank you. I won't forget. I've never forgotten anything in my life. It's my great curse.
@end

# sx5.secret
severine: Still safe. After a week. In a city that sells secrets by the jar.
severine: You know, I think you're the first person in Port Vellum who's ever kept one of mine for free.
{do rel:severine+2; mem:severine:kept}
@next sx5.hub

# sx5.harrow
> She looks at you for a very long time. Absalom took her revenge from her once, on a quay, at dawn, and waved.
severine: You'd... leave him to me. The grey man. If it comes to it.
severine: Absalom never once gave me anything I wanted. Not in a hundred years. You're giving me the one thing.
{do flag:sevGetsHarrow=1; rel:severine+3; mem:severine:harrow}
@next sx5.hub

# sx5.hub
* "See you on the platform, my lady."  -> sx5.bye

# sx5.bye
severine: Watch my hands.
@end

# mx5.0 arc=malakor night=5 label="\"Malakor. Last price.\"" if=room:switchyard&alive:malakor&time<235
@focus malakor
> Platform 0 is filling. Malakor stands at the steel curtain of his shop in the twelfth face and a black suit, watching the Court arrive with the expression of a man watching rain he's sold umbrellas for.
malakor: Last price. Ha. Nothing's ever last with me. But tonight, yes. Tonight the price is whatever it costs to see tomorrow.
@gate mem:malakor.grigori ? mx5.grig : mx5.plain

# mx5.grig
> He touches the breast pocket of his apron under the suit jacket. The photograph is still there.
malakor: I took the photograph to the river last night. To feed it to the water like the first face. I couldn't. I stood there for an hour with it in my hand.
malakor: That's your fault. You've made me sentimental. It's very bad for business.
@next mx5.plain

# mx5.plain
* "Will the Syndicate stand with me?"  -> mx5.stand
* "If it goes wrong, run. East tunnel."  -> mx5.run {if mem:malakor.warned}
* "Thank you. For telling me the truth all week."  -> mx5.thanks

# mx5.stand
@gate flag:side_syndicate ? mx5.yes : mx5.maybe

# mx5.yes
malakor: We've made a deal. A Butcher keeps his deals. It's the only thing we keep.
@end

# mx5.maybe
malakor: The Syndicate stands where the weight is. Show me weight in the chalk circle, and we'll lean.
@end

# mx5.run
malakor: The east tunnel. Yes. I've had my guys clear it. If you hear me whistle, it means the generator's singing and I don't like the tune.
@end

# mx5.thanks
malakor: Truth. Ha. You're the only customer in a hundred years who came for the truth and paid for it with more truth. I've made a note. Inside the eyelids.
{do rel:malakor+1}
@end

# ux5.0 arc=soot night=5 label="\"Mother. Will you come up?\"" if=room:shrine&flag:metSoot
@focus soot
soot: Up. Up, up. To the platform. Me. I haven't been up to the platform since 1977. The light's too loud.
soot: But tonight. Yes. Tonight I'll come up. I want to see their faces when they find out what the pipes heard. Mm. Mm. I've been waiting forty years to see a Court lady's face fall.
@gate flag:ratsDied ? ux5.dead : ux5.alive

# ux5.dead
soot: My little ones are dead. The almond smell. All of them. Every grate. Mm. I can hear the pipes, but nobody's in them.
soot: You should have stopped the yellow man. I told you. I always tell you. Nobody listens to the dead.
{do rel:soot-1}
@end

# ux5.alive
@gate flag:pikeDone ? ux5.saved : ux5.plain

# ux5.saved
soot: The yellow man didn't come. My little ones are all in their grates, chewing. Mm. Because of you. You'll find, greedy, that I'm very bad at thank you. I'll show you instead. Watch the grates.
{do rel:soot+1}
@end

# ux5.plain
soot: Go on. Go on up. I'll be right behind you, very slowly, with a candle.
@end

// =====================================================================
// AT DAWN · before the last choice
// =====================================================================
# dw.talk
> Twenty minutes. The sky through the skylight grate is going the color of a healing bruise. There's time for one more word with someone. Maybe two.
* Pemberton, at the back wall.  -> dw.pem {once} {if !flag:pemDead&flag:pemAtTribunal}
* Valko, at your left hand.  -> dw.valko {once} {if flag:valkoAlly&!flag:valkoDead}
* Séverine, on her chair.  -> dw.sev {once} {if !flag:sevDead&!flag:massacre&!flag:purge}
* Malakor, by the east tunnel.  -> dw.mal {once} {if !flag:malakorDead&!flag:massacre&!flag:purge}
* Mother Soot, with her candle.  -> dw.soot {once} {if !flag:sootDead&!flag:purge}
* Miller, coming down the stairs.  -> dw.miller {once} {if flag:side_miller&!flag:purge}
* The Tenant.  -> dw.tenant {once}
* Enough. Decide.  -> dawn.hub

# dw.pem
@focus pemberton
pemberton: ‹Sir›. Whatever you're about to do, I'd like to say: the car's outside, with the engine running and the blinds down. If you need to be somewhere dark by six, I'll have you there by five past.
pemberton: And if you don't need to be anywhere dark. If you've decided on the other thing.
> He looks at the brass bottle, wherever it is. He looks at the skylight.
pemberton: Then I'd consider it an honour to drive you somewhere with a view.
@next dw.talk

# dw.valko
@focus valko
valko: It's nearly morning. I've never seen a morning. Seventy years. I'm told they're very bright.
valko: Whatever you choose, I'll be on your left. Even if that's into the light. Especially if that's into the light. I'd like to see what he wanted to see.
* "No. Not you. If I go up, you stay in the dark."  -> dw.valko2
* "Thank you, Mr. Valko."  -> dw.valko3

# dw.valko2
valko: ...You're giving me an order. A real one.
valko: All right. All right. I'll stay. Left hand. In the dark.
{do flag:valkoStaysDark=1}
@next dw.talk

# dw.valko3
> He shuts his eyes when you say it. He doesn't open them for a while.
{do rel:valko+1}
@next dw.talk

# dw.sev
@focus severine
severine: Twenty minutes. Isn't it strange: three hundred Kindred on a platform and not one of us has watched a sunrise in our lives. We all know exactly how many minutes it takes. We count it like a debt.
@gate flag:sevLetterRead ? dw.sev2 : dw.sev3

# dw.sev2
severine: I read it again. My mother's letter. In the car, on the way down. I'm going to read it every night now. I'm going to be insufferable about it.
severine: A lamp in a window. That's all anybody wants, isn't it. A lamp in a window, on until it isn't.
@next dw.talk

# dw.sev3
severine: Whatever you decide: decide it beautifully. That's all I ask. Ugly decisions are the only truly unforgivable thing.
@next dw.talk

# dw.mal
@focus malakor
malakor: Dawn. I've rebuilt my face twelve times and I've never once seen it in daylight. Isn't that strange? Twelve faces and not one of them has had a sunburn.
malakor: If you're going up the stairs, I want to say: it's been very good business knowing you. Terrible for the margins. Very good for the soul. I didn't know I had one. I'm still not sure. I'll let you know.
@next dw.talk

# dw.soot
@focus soot
soot: The pipes are very quiet. Everyone's listening. Mm. Mm. The whole Ward is holding its breath. Even the drains.
soot: You know what I've got, little house full of people? Your name. In a jar. I'm going to keep it. When you're gone, whichever way you go, I'll play it sometimes, for company. Casey. Casey. Mm.
@next dw.talk

# dw.miller
@focus miller
miller: I've got Harrow in the back of a car, or I've got a burnt-out van and a lot of explaining, or I've got nothing at all, depending on how the last hour went. I've lost track. I've been awake for thirty hours.
miller: Whatever happens now. Thank you. For the coffee. For Mateo. For not eating me. For making me feel less crazy.
@gate flag:millerMetMateo|flag:millerLetter ? dw.miller2 : dw.talk

# dw.miller2
miller: He's coming to dinner. Sunday. Midnight. I'm going to cook. He's not going to eat. I don't care.
@next dw.talk

# dw.tenant
tenant: Here we are, then. The last decision. I've been watching you make them all week and I've been wrong about every single one.
@gate flag:seizure=surrender|sync>=80 ? dw.ten2 : dw.ten3

# dw.ten2
tenant: You know what I want. I've never hidden it, not since the cistern. I want the hands. I'd be good with them. Better than before. Kinder. Odder.
tenant: But it's your choice. It's always been your choice. That's the thing I didn't understand on Monday.
@next dw.talk

# dw.ten3
tenant: Whatever you choose, I'll be with you, or I'll be ash with you, or I'll be quiet. I've done all three. None of them are as bad as you'd think.
tenant: Go on, Casey. Decide.
@next dw.talk
`,'c_n5b');
// at dawn, before the last choice: one more word with whoever is still standing
(function(){const N=NL.STORY.nodes;const d=N['dawn.0'];if(d)d.next='dw.talk';})();
