'use strict';
/* THE NEW LORD — Acts III–V locations: the morgue under St. Jude's, the clinic roof, the cistern under Platform 0 */
(function(){
const NL=window.NL;const PI=Math.PI;const ROOMS=NL.ROOMS,M=NL.M,mats=NL.mats,TX=NL.Tex,P=NL.PROPS,xm=NL.xm;
TX.add('drawers',()=>{const c=TX.cv(1024,512),x=c.getContext('2d'),R=TX.rng(501);x.fillStyle='#7d8486';x.fillRect(0,0,1024,512);
  const rows=['A','B','C'];for(let j=0;j<3;j++)for(let i=0;i<8;i++){const px=8+i*127,py=8+j*168;const g=x.createLinearGradient(px,py,px,py+160);g.addColorStop(0,'#b8bfc0');g.addColorStop(1,'#8a9294');x.fillStyle=g;x.fillRect(px,py,119,160);
    x.fillStyle='#3a3e40';x.fillRect(px+30,py+70,60,14);x.fillStyle='#e8e2c8';x.fillRect(px+36,py+18,48,24);x.fillStyle='#222';x.font='700 18px "Barlow Condensed",sans-serif';x.textAlign='center';x.fillText(rows[j]+'-'+(9+i),px+60,py+36);}
  TX.blotch(x,1024,512,R,30,(R,a)=>`rgba(40,36,30,${a})`,.25,20,80);return c;});
TX.add('tileMorgue',()=>{const c=TX.cv(512),x=c.getContext('2d'),R=TX.rng(511);x.fillStyle='#9aa49c';x.fillRect(0,0,512,512);for(let j=0;j<16;j++)for(let i=0;i<16;i++){const v=R();x.fillStyle=`rgb(${180+v*30},${192+v*28},${182+v*26})`;x.fillRect(i*32+1,j*32+1,30,30);}
  TX.blotch(x,512,512,R,24,(R,a)=>`rgba(60,70,50,${a})`,.3,20,90);x.fillStyle='rgba(80,40,30,.18)';for(let i=0;i<8;i++){x.beginPath();x.ellipse(R()*512,400+R()*112,30+R()*40,10,0,0,7);x.fill();}return c;});
TX.add('tarRoof',()=>{const c=TX.cv(512),x=c.getContext('2d'),R=TX.rng(521);x.fillStyle='#2a2a2c';x.fillRect(0,0,512,512);for(let i=0;i<14;i++){x.fillStyle=`rgba(${50+R()*20},${50+R()*20},${55+R()*20},.6)`;x.fillRect(0,i*37,512,2);}
  TX.blotch(x,512,512,R,40,(R,a)=>`rgba(${R()>.5?10:70},${R()>.5?10:72},${R()>.5?12:80},${a})`,.4,20,120);return c;});
TX.add('helipad',()=>{const c=TX.cv(512),x=c.getContext('2d');x.clearRect(0,0,512,512);x.strokeStyle='rgba(230,220,180,.75)';x.lineWidth=18;x.beginPath();x.arc(256,256,220,0,7);x.stroke();x.fillStyle='rgba(230,220,180,.75)';x.fillRect(150,130,40,252);x.fillRect(322,130,40,252);x.fillRect(150,236,212,40);return c;});
TX.add('brickVault',()=>{const c=TX.cv(512),x=c.getContext('2d'),R=TX.rng(531);x.fillStyle='#2a1a14';x.fillRect(0,0,512,512);for(let j=0;j<24;j++)for(let i=0;i<9;i++){const v=R();x.fillStyle=`rgb(${78+v*36},${42+v*18},${30+v*12})`;x.fillRect(i*60+(j%2)*30-30,j*22,56,19);}
  TX.blotch(x,512,512,R,40,(R,a)=>`rgba(10,14,12,${a})`,.45,20,120);x.fillStyle='rgba(180,190,170,.12)';for(let i=0;i<20;i++)x.fillRect(R()*512,R()*512,2,30+R()*80);return c;});
TX.add('sMorgue',()=>{const c=TX.cv(512,96),x=c.getContext('2d');x.fillStyle='#e8e4d8';x.fillRect(0,0,512,96);x.fillStyle='#1a1a1a';x.font='800 50px "Barlow Condensed",sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText('MORGUE · B1 · AUTHORISED ONLY',256,50);return c;});
TX.add('sLab',()=>{const c=TX.cv(512,96),x=c.getContext('2d');x.fillStyle='#1d2e2a';x.fillRect(0,0,512,96);x.fillStyle='#bfe8d8';x.font='italic 700 40px "Bodoni Moda",serif';x.textAlign='center';x.textBaseline='middle';x.fillText('Free Clinic · Tuesday Trials',256,50);return c;});
const XM={};function x4(){if(XM.ready)return XM;Object.assign(XM,{
  drawers:M([1,1,1],{tex:'drawers',decal:true,mottle:0,spec:1.1}),tile:M([1,1,1],{tex:'tileMorgue',texScale:.5,spec:.5}),tar:M([1,1,1],{tex:'tarRoof',texScale:.4,spec:.6}),
  heli:M([1,1,1],{tex:'helipad',decal:true,mottle:0,spec:.2}),brick:M([1,1,1],{tex:'brickVault',texScale:.45,spec:.3}),sMorgue:M([1,1,1],{tex:'sMorgue',decal:true,mottle:0,emisK:.2}),sLab:M([1,1,1],{tex:'sLab',decal:true,mottle:0,emisK:.4}),
  uv:M([1,1,1],{emis:[.55,.25,1],mottle:0}),brass:M([.75,.55,.25],{spec:2.2,mottle:.2}),sunGlow:M([1,1,1],{emis:[1,.85,.45],mottle:0}),cot:M([.65,.7,.68],{spec:.3}),blanket:M([.3,.38,.42],{spec:.05,mottle:.5}),
  parapet:M([.38,.36,.33],{spec:.2,mottle:.6}),hvac:M([.55,.58,.58],{spec:.9,mottle:.3}),blackwater:M([1,1,1],{tex:'water',decal:true,mottle:0,spec:2.6,emisK:.06})});XM.ready=true;return XM;}

/* ---------- St. Jude's basement: the morgue and Rostova's Tuesday room ---------- */
ROOMS.morgue={id:'morgue',name:'St. Jude\'s Morgue',sub:'Block C · Basement B1',W:10,D:6,H:2.8,ambience:'clinic',bright:true,
  sky:[.16,.2,.2],ground:[.06,.08,.08],
  grade:{sh:[.66,.86,.84],hi:[1.02,1.06,1.0],ink:[.02,.04,.05],sat:.7,wash1:[.015,.03,.03],wash2:[.05,.08,.08]},
  shadow:{pos:[4,2.7,3],target:[4,0,2.6],fov:2.3,far:12,idx:0},
  lights(S){const L=[{pos:[3.6,2.7,2.8],color:[.8,1,.95],intensity:S.flags.morguePower===0?0.25:1.5,range:9},{pos:[8.2,2.4,2.8],color:S.flags.labLit?[.6,.4,1]:[.5,.9,.8],intensity:.9,range:5}];
    if(S.flags.vesselOut)L.push({pos:[3.6,1.3,3.0],color:[1,.85,.5],intensity:2.2,range:5});if(S.flags.morguePower===0)L.push({pos:[0.6,2.4,4.8],color:[1,.2,.1],intensity:.8,range:4});return L;},
  flicker(t){return 1-0.12*(Math.sin(t*41)>0.9?1:0);},
  build(rb,S){const m=mats(),X=xm(),Y=x4();
    rb.shell(10,6,2.8,Y.tile,X.clinic,X.clinic,m.cap,{lowerH:1.2,lowerL:Y.tile,lowerR:m.steel});
    // the drawer wall (back, x 0.8-6.4)
    rb.box([0.8,0.1,0],[6.4,2.5,0.32],m.steel,{block:true});rb.decal([3.6,1.3,0.335],[5.4,0,0],[0,2.25,0],[0,0,1],Y.drawers);
    if(S.flags.drawerOpen){rb.box([4.32,0.98,0.32],[4.98,1.48,2.1],m.steelBright,{block:true});rb.box([4.38,1.48,0.5],[4.92,1.66,2.0],M([.85,.84,.8],{spec:.1,mottle:.4}));}
    rb.wallZ(3.6,2.62,2.4,0.22,Y.sMorgue,0.33);
    // autopsy table + lamp
    rb.box([2.8,0,2.6],[4.4,0.85,3.4],m.steelBright,{block:true});rb.box([2.85,0.85,2.65],[4.35,0.9,3.35],m.steel);rb.cyl([3.6,0.4,3.0],0.08,0.12,0.8,m.steelDark);
    rb.cyl([3.6,2.45,3.0],0.32,0.42,0.18,m.steelDark);rb.cyl([3.6,2.36,3.0],0.3,0.3,0.02,m.bulbCold,{noDepth:true});
    if(S.flags.vesselOut){rb.cylX(3.0,4.2,1.02,3.0,0.12,Y.brass);rb.cylX(3.15,4.05,1.02,3.0,0.13,Y.sunGlow,{noDepth:true});}
    // trolley, sink, scales
    rb.box([0.6,0,1.3],[1.4,0.85,1.8],m.steelBright,{block:true});rb.box([5.6,0.8,1.0],[6.3,0.95,1.5],m.steelBright,{block:true});rb.box([5.6,0,1.0],[6.3,0.8,1.5],m.steelDark);
    // elevator on the left wall
    rb.box([0,0,4.2],[0.08,2.4,5.4],m.steelBright);rb.box([0.08,0,4.3],[0.1,2.3,4.78],m.steel,{noDepth:true});rb.box([0.08,0,4.82],[0.1,2.3,5.3],m.steel,{noDepth:true});
    // the Tuesday room (right): seven cots behind a plastic curtain
    rb.wallZ(8.2,2.45,2.4,0.42,Y.sLab,0.02);rb.box([6.8,0,0],[6.84,2.6,3.8],M([.8,.92,.9],{alpha:.35,spec:1.4,mottle:0}),{noDepth:true});
    for(let i=0;i<4;i++){const z=0.5+i*0.9;rb.box([7.2,0,z],[9.4,0.45,z+0.6],Y.cot,{block:i<3});rb.box([7.25,0.45,z+0.02],[9.35,0.55,z+0.58],Y.blanket);}
    for(let i=0;i<3;i++){rb.cyl([9.7,0.9,0.8+i*1.1],0.03,0.03,1.8,m.steel);rb.box([9.55,1.5,0.7+i*1.1],[9.85,1.75,0.9+i*1.1],M([.85,.2,.2],{alpha:.7,spec:1.2}),{noDepth:true});}
    rb.box([7.4,0,4.2],[9.2,0.9,4.9],m.steelBright,{block:true});rb.box([7.6,0.9,4.3],[8.2,1.2,4.7],m.black);rb.box([8.4,0.9,4.4],[8.6,1.25,4.6],Y.uv);
    P.tube(rb,1.5,6,2.75,2.0);P.tube(rb,1.5,6,2.75,4.0);
  },
  spawn:{x:0.95,z:4.8,ry:1.6},
  exits:[{id:'morgueUp',label:'Elevator up',at:[0.1,1.4,4.8],box:[0,0,4.2,0.15,2.4,5.4],stand:[0.95,4.8],face:[0,4.8],to:'stjude',spawn:{x:0.95,z:4.8,ry:1.6}}],
  inter:[{id:'drawer14',label:'Drawer B-14',at:[4.65,1.25,0.35],box:[4.32,0.95,0,4.98,1.5,0.4],stand:[4.65,1.3],face:[4.65,0]},
    {id:'slab',label:'Autopsy table',at:[3.6,1.0,3.0],box:[2.8,0,2.6,4.4,1.0,3.4],stand:[3.6,4.0],face:[3.6,3.0]},
    {id:'cots',label:'The Tuesday room',at:[8.2,0.7,1.8],box:[7.2,0,0.5,9.4,0.7,3.6],stand:[6.4,2.0],face:[8.2,1.8]},
    {id:'labdesk',label:'Rostova\'s desk',at:[8.0,1.1,4.5],box:[7.4,0,4.2,9.2,1.2,4.9],stand:[8.0,3.8],face:[8.0,4.5]}],
  particles:[{type:'motes',n:14,area:[0.5,9.5,0.5,5.5],y:[0.3,2.4],col:[.85,1,.95]}]
};
const sjOld=ROOMS.stjude.exits;sjOld.push({id:'toMorgue',label:'Elevator down',at:[0.1,1.4,4.8],box:[0,0,4.2,0.15,2.4,5.4],stand:[0.95,4.8],face:[0,4.8],to:'morgue',spawn:{x:0.95,z:4.8,ry:1.6},if:S=>S.flags.morgueOK});
ROOMS.stjude.exits.push({id:'toJudeRoof',label:'Roof stairs',at:[9.6,1.3,5.4],box:[9.2,0,5.0,10,2.2,6],stand:[8.9,5.2],face:[9.6,5.4],to:'sjroof',spawn:{x:1.2,z:4.6,ry:0.6},if:S=>S.night>=4});

/* ---------- St. Jude's roof: the frequencies ---------- */
ROOMS.sjroof={id:'sjroof',name:'St. Jude\'s Roof',sub:'Block C · above the Ward',W:10,D:6,H:1.1,ambience:'roof',map:false,
  sky:[.12,.1,.14],ground:[.04,.04,.05],
  grade:{sh:[.62,.62,.82],hi:[1.04,.98,1.04],ink:[.03,.02,.05],sat:.75,wash1:[.02,.015,.03],wash2:[.07,.05,.09]},
  shadow:{pos:[5,3.2,3],target:[5,0,3],fov:2.4,far:12,idx:0},
  lights(S){return [{pos:[5,3.4,3],color:[.6,.6,.9],intensity:.9,range:10},{pos:[8.6,2.6,1.0],color:[1,.15,.1],intensity:Math.sin(performance.now()/400)>0?1.1:.3,range:3},{pos:[2,0.6,5.8],color:[1,.6,.3],intensity:.7,range:4},
    S.flags.uvArmed?{pos:[5,1.6,3],color:[.6,.3,1],intensity:2.2,range:6}:{pos:[5,1.6,3],color:[.4,.4,.5],intensity:.2,range:2}];},
  flicker(t){return 1;},
  build(rb,S){const m=mats(),X=xm(),Y=x4();
    rb.shell(10,6,1.1,Y.tar,Y.parapet,Y.parapet,m.cap);
    rb.floor(5,3,4,4,Y.heli);
    // HVAC units, vents, the radio mast with three dishes
    rb.box([0.6,0,0.4],[2.6,1.3,1.6],Y.hvac,{block:true});for(let i=0;i<2;i++)rb.cyl([1.1+i*1.0,1.32,1.0],0.38,0.38,0.06,m.steelDark,{noDepth:true});
    rb.box([7.6,0,0.3],[8.0,0.2,0.7],m.steelDark,{block:true});rb.cyl([7.8,1.6,0.5],0.05,0.08,3.2,m.steel);rb.cyl([8.6,2.4,1.0],0.03,0.03,0.08,m.redLamp,{noDepth:true});
    for(let i=0;i<3;i++)rb.sph([7.8+(i-1)*0.36,1.4+i*0.5,0.62],[0.22,0.22,0.06],m.steelBright);
    rb.box([3.6,0,4.8],[4.4,0.9,5.4],m.steelDark,{block:true});rb.box([0.2,0,5.2],[1.4,2.2,6],m.concCold,{block:true});
    // the lamp rig: Rostova's array
    rb.box([4.6,0,2.6],[5.4,0.6,3.4],m.steelDark,{block:true});rb.cyl([5,1.0,3],0.05,0.05,0.8,m.steel);rb.cyl([5,1.5,3],0.32,0.22,0.3,m.steelBright);rb.cyl([5,1.66,3],0.3,0.3,0.02,S.flags.uvArmed?Y.uv:m.glass,{noDepth:true});
    for(let i=0;i<6;i++)rb.cylX(0.4+i*1.6,1.2+i*1.6,0.03,3.6+(i%2)*0.6,0.02,m.black);
  },
  spawn:{x:1.2,z:4.6,ry:0.6},
  exits:[{id:'roofDown',label:'Stairs down',at:[0.8,1.1,5.6],box:[0.2,0,5.2,1.4,2.2,6],stand:[1.4,4.6],face:[0.8,5.6],to:'stjude',spawn:{x:8.9,z:5.2,ry:-2.4}}],
  inter:[{id:'mast',label:'Radio mast',at:[7.8,1.6,0.5],box:[7.5,0,0.2,8.1,3.2,0.8],stand:[7.4,1.6],face:[7.8,0.5]},
    {id:'uvrig',label:'The lamp array',at:[5,1.4,3],box:[4.6,0,2.6,5.4,1.7,3.4],stand:[5,4.2],face:[5,3]},
    {id:'parapet',label:'The edge',at:[9.8,0.9,3],box:[9.6,0,1,10,1.2,5],stand:[9.0,3],face:[9.9,3]}],
  particles:[{type:'rain',n:60,area:[0,10,0,6],y:[0,4],col:[.7,.75,.9]}]
};

/* ---------- The Vellum cistern under Platform 0 ---------- */
ROOMS.cistern={id:'cistern',name:'The Vellum Cistern',sub:'Block D · beneath Platform 0',W:10,D:6,H:3.6,ambience:'cistern',
  sky:[.06,.08,.08],ground:[.02,.03,.03],
  grade:{sh:[.6,.72,.7],hi:[1.06,.98,.86],ink:[.02,.03,.03],sat:.72,wash1:[.01,.02,.02],wash2:[.04,.06,.06]},
  shadow:{pos:[5,3.4,2.4],target:[5,0,2.6],fov:2.3,far:12,idx:0},
  lights(S){const L=[{pos:[2,2.6,1.4],color:[1,.6,.3],intensity:1.4,range:6},{pos:[8,2.6,1.4],color:[1,.6,.3],intensity:1.4,range:6},{pos:[5,0.4,4.6],color:[.4,.7,.8],intensity:.7,range:6}];
    if(S.flags.vesselSet)L.push({pos:[5,1.7,2.0],color:[1,.85,.45],intensity:S.flags.vesselOpen?6:2,range:S.flags.vesselOpen?14:5});return L;},
  flicker(t){return 1-0.06*Math.max(0,Math.sin(t*7.3));},
  build(rb,S){const m=mats(),X=xm(),Y=x4();
    rb.shell(10,6,3.6,m.concCold,Y.brick,Y.brick,m.cap);
    // black water across the front, a brick causeway to a dais
    rb.box([0,-0.4,3.6],[10,-0.05,6],m.black);rb.floor(5,4.8,10,2.4,Y.blackwater,-0.04);rb.block(0,3.6,10,6);
    rb.box([4.2,-0.1,2.6],[5.8,0.05,6],Y.brick);rb.block(0,3.6,4.2,6);rb.block(5.8,3.6,10,6);
    // pillars and arches
    for(const x of [1.6,8.4]){rb.box([x-0.35,0,0.9],[x+0.35,3.6,1.6],Y.brick,{block:true});}
    for(const x of [1.6,8.4])rb.box([x-0.6,0,3.4],[x+0.6,3.6,3.6],Y.brick);
    // the dais: an old sluice gate turned altar
    rb.box([3.9,0,1.4],[6.1,0.4,2.6],m.concCold,{block:true});rb.box([4.6,0.4,1.8],[5.4,1.2,2.2],Y.brass);
    if(S.flags.vesselSet){rb.cyl([5,1.6,2.0],0.13,0.13,0.8,Y.brass,{rot:[0,0,0]});rb.cyl([5,1.6,2.0],0.14,0.14,0.5,Y.sunGlow,{noDepth:true});}
    // candles everywhere (Wraith offerings)
    for(let i=0;i<14;i++)P.candle(rb,0.4+i*0.68,0.0,0.25+(i%3)*0.12);
    rb.box([0.2,0,0.2],[1.2,0.4,0.6],m.woodDark,{block:true});rb.box([8.8,0,0.2],[9.8,0.4,0.6],m.woodDark,{block:true});
    // the iron ladder up to Platform 0
    for(let i=0;i<9;i++)rb.box([9.3,0.2+i*0.35,0.02],[9.8,0.24+i*0.35,0.08],m.steelDark);rb.box([9.28,0,0],[9.32,3.4,0.1],m.steelDark);rb.box([9.78,0,0],[9.82,3.4,0.1],m.steelDark);
  },
  spawn:{x:9.0,z:1.0,ry:-2.6},
  exits:[{id:'cisternUp',label:'Ladder to Platform 0',at:[9.55,1.6,0.1],box:[9.2,0,0,9.9,3.4,0.2],stand:[9.0,1.0],face:[9.55,0],to:'switchyard',spawn:{x:6.5,z:1.4,ry:2.6}}],
  inter:[{id:'dais',label:'The sluice altar',at:[5,1.2,2.0],box:[3.9,0,1.4,6.1,1.4,2.6],stand:[5,3.1],face:[5,2.0]},
    {id:'cwater',label:'Still water',at:[5,0,4.8],box:[0,-0.1,3.8,10,0.1,6],stand:[5,3.4],face:[5,4.8]}],
  particles:[{type:'motes',n:24,area:[0.5,9.5,0.5,3.5],y:[0.3,3.2],col:[1,.8,.5]}]
};
})();
