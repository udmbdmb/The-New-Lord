'use strict';
/* THE NEW LORD — tooltips, one-time hints, glossary. Kept short on purpose: one idea per card, shown the first time it matters. */
(function(){
const NL=window.NL, G=NL.G;
const GL={
  explore:['Getting around','Tap the floor to walk. Tap a ◇ marker to look at or use something. The eye button shows every label in the room.'],
  voices:['Voices','Your 16 skills are voices in your head. They speak up on their own when they notice something. The higher the skill, the more it notices.'],
  white:['White check','Roll two dice plus a skill against a difficulty. The % is your chance. If you fail, the option locks until that skill goes up.'],
  red:['Red check','A one-time chance. Two dice plus a skill. Whatever happens, happens.'],
  push:['Rouse the Blood','A failed check can be forced to succeed by burning 1 Vitae. You can never spend your last drop.'],
  ability:['Clan abilities','Powers from your blood, marked ◆. They cost Vitae and often skip the roll entirely.'],
  enc:['Encounters','Fights happen in dialogue. Fill the top meter before the bottom one fills. Each turn the other side acts, then you choose a move.'],
  mask:['Mask','Your composure: the human face you wear. Shocks and failed social checks wear it down. At zero it slips and your fangs show. Mortals who see it raise Heat.'],
  vitae:['Vitae','Stolen blood. It powers abilities and forced checks. Each day\'s sleep costs one, but you always wake with at least two. Run low and you get Hungry: Hunt from the map.'],
  hunger:['Hunger','Low Vitae wakes the Beast. Parasite, Apex and Frenzy get louder and stronger. At 2 Vitae or less it talks over your manners too: Masquerade skills −1. Feed to quiet it.'],
  heat:['Heat','How much the mortal world has noticed. Breaches, violence and witnesses raise it.'],
  dawn:['The clock','Choices take a minute, long conversations a few more, and travel more again. The map lets you Wait if you\'re early for something. The sun rises at 5:00 AM. Be out of the light by then.'],
  thought:['Thought Cabinet','An idea you can dwell on. Put it in a slot and it develops over in-game time, then pays off for good.'],
  wardrobe:['Wardrobe','Clothes and accessories change your skills (▲ ▼) and what people see. Equip them from Inventory.'],
  dossier:['Dossiers','Everyone you get to know gets a page in the Journal: schedule, how they feel about you, what you have learned.'],
  resonance:['Blood resonance','Blood carries the mood of whoever it came from. Until dawn, the last blood you drank nudges a few skills up or down. Tap the chip to see which.'],
  level:['Skill points','You have a point to spend. Open the Character sheet and press + next to a skill.']
};
NL.GLOSSARY=GL;
const ORDER=['voices','resonance','white','red','push','ability','enc','mask','vitae','hunger','heat','dawn','thought','wardrobe','dossier','level','explore'];
const $=s=>document.querySelector(s), esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

/* ---------- one-time hints ---------- */
let seen={};try{seen=JSON.parse(localStorage.getItem('newlord.hints')||'{}')||{};}catch(e){}
const save=()=>{try{localStorage.setItem('newlord.hints',JSON.stringify(seen));}catch(e){}};
const q=[];let cur=null,tm=null,lastHide=0;
const box=document.createElement('div');box.id='hint';box.hidden=true;box.setAttribute('role','status');document.getElementById('app').appendChild(box);
// tips about the choice on screen jump the queue; background ones wait their turn so the first minutes aren't a lecture
const NOW=new Set(['resonance','voices','white','red','push','ability','enc']);
function hint(k){if(G.settings.hints===false||seen[k]||!GL[k]||q.includes(k)||cur===k)return;seen[k]=1;save();if(NOW.has(k))q.unshift(k);else q.push(k);pump();}
let pt=null;function pump(){if(cur||!q.length)return;clearTimeout(pt);const gap=NOW.has(q[0])?1400:20000;const wait=Math.max(0,gap-(performance.now()-lastHide));pt=setTimeout(()=>{if(document.body.classList.contains('cine')||document.body.classList.contains('coldopen')&&!NOW.has(q[0])){pt=null;setTimeout(pump,1500);return;}show();},wait);}
function show(){if(cur||!q.length)return;const k=q.shift();cur=k;const [t,d]=GL[k];
  box.innerHTML=`<div class="hk">Tip</div><b>${esc(t)}</b><p>${esc(d)}</p><div class="ha"><button class="hok">Got it</button><button class="hoff">No more tips</button></div>`;
  box.hidden=false;requestAnimationFrame(()=>box.classList.add('in'));document.body.classList.add('hinting');
  box.querySelector('.hok').onclick=e=>{e.stopPropagation();hide();};
  box.querySelector('.hoff').onclick=e=>{e.stopPropagation();G.settings.hints=false;try{localStorage.setItem('newlord.settings',JSON.stringify(G.settings));}catch(_){}q.length=0;hide();};
  clearTimeout(tm);tm=setTimeout(hide,16000);}
function hide(){if(!cur)return;cur=null;clearTimeout(tm);box.classList.remove('in');document.body.classList.remove('hinting');lastHide=performance.now();setTimeout(()=>{if(!cur)box.hidden=true;},300);pump();}
box.addEventListener('pointerdown',e=>e.stopPropagation());

/* ---------- tooltips ---------- */
const tip=document.createElement('div');tip.id='tip';tip.hidden=true;document.getElementById('app').appendChild(tip);
function tipContent(key){
  const [a,b,c]=key.split(':');
  if(a==='sk'){const s=NL.SKILLS[b];if(!s)return null;return [s.name,`${NL.ATTRS[s.attr].name} · ${s.d}`];}
  if(a==='ck'){const s=NL.SKILLS[c];const g=GL[b];return [g[0]+(s?' · '+s.name:''),g[1]+(s?` Your ${s.name} is ${G.skill(c)}.`:'')];}
  if(a==='ab'){const ab=NL.ABIL[b];if(!ab)return null;const tr=G.abTier?G.abTier(b):1;return [ab.n,`${ab.d} Costs ${G.abilityCost?G.abilityCost(b):ab.c} Vitae.${ab.t2?` Tier 2 (${ab.t2.n}): ${ab.t2.d}${tr>=2?'':' Not yet mutated.'}`:''}${ab.t3?` Tier 3 (${ab.t3.n}): ${ab.t3.d}${tr>=3?'':' Not yet ascended.'}`:''}`];}
  if(a==='resonance'&&G.S&&G.S.res&&NL.RES[G.S.res.type]){const r=NL.RES[G.S.res.type];return [r.n+' blood',r.d+(G.S.res.src?' From: '+G.S.res.src+'.':'')+' Lasts until dawn.'];}
  if(GL[a])return GL[a];return null;}
let tipFor=null,press=null,suppress=false;
function showTip(el){const c=tipContent(el.dataset.tip);if(!c)return;tipFor=el;
  tip.innerHTML=`<b>${esc(c[0])}</b><p>${esc(c[1])}</p>`;tip.hidden=false;tip.classList.remove('in');
  const r=el.getBoundingClientRect(),app=$('#app').getBoundingClientRect(),tw=Math.min(300,app.width-24);tip.style.width=tw+'px';
  const th=tip.offsetHeight;let x=r.left+r.width/2-tw/2-app.left;x=Math.max(12,Math.min(app.width-tw-12,x));
  let y=r.bottom-app.top+8;if(y+th>app.height-8)y=r.top-app.top-th-8;y=Math.max(8,y);
  tip.style.transform=`translate(${x}px,${y}px)`;requestAnimationFrame(()=>tip.classList.add('in'));}
function hideTip(){tipFor=null;tip.classList.remove('in');tip.hidden=true;}
let hov=null;
document.addEventListener('pointerover',e=>{if(e.pointerType!=='mouse')return;const el=e.target.closest('[data-tip]');if(el===tipFor)return;clearTimeout(hov);if(!el){hideTip();return;}hov=setTimeout(()=>showTip(el),320);});
document.addEventListener('pointerout',e=>{if(e.pointerType!=='mouse')return;const el=e.target.closest('[data-tip]');if(el&&!el.contains(e.relatedTarget)){clearTimeout(hov);if(tipFor===el)hideTip();}});
document.addEventListener('pointerdown',e=>{const el=e.target.closest('[data-tip]');if(!el){if(tipFor&&e.pointerType!=='mouse')hideTip();return;}
  if(e.pointerType==='mouse')return;
  // plain info elements show on tap; tips inside buttons need a long-press so the tap still chooses the option
  if(!el.closest('button')){e.stopPropagation();if(tipFor===el)hideTip();else showTip(el);return;}
  clearTimeout(press);press=setTimeout(()=>{suppress=true;showTip(el);if(navigator.vibrate)try{navigator.vibrate(8);}catch(_){}},420);},true);
['pointerup','pointercancel','pointermove'].forEach(t=>document.addEventListener(t,e=>{if(t==='pointermove'&&Math.abs(e.movementX)+Math.abs(e.movementY)<6)return;clearTimeout(press);},true));
document.addEventListener('click',e=>{if(suppress){suppress=false;e.stopPropagation();e.preventDefault();}},true);
document.addEventListener('contextmenu',e=>{if(e.target.closest('[data-tip]'))e.preventDefault();});

/* ---------- glossary (Journal) ---------- */
function glossaryHTML(){return `<div class="gloss"><h4>How it works</h4>${ORDER.map(k=>`<details><summary>${esc(GL[k][0])}</summary><p>${esc(GL[k][1])}</p></details>`).join('')}<p class="empty">Hover, tap or long-press most labels for a reminder.</p></div>`;}

NL.Help={hint,glossaryHTML,hideTip,reset(){seen={};save();}};
})();
