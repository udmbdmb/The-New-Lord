'use strict';
/* THE NEW LORD — follow-ups: the people you met this week come back, and what you did to them comes with them */
NL.Script.opt('dm.hub','* "Father. The man in dark glasses. His name was Absalom Vane. He wanted you to know."  -> fu.dom {once} {if flag:wantTellDominic|mem:tenant.dominicvane&night:5}','start');
NL.Script.add(String.raw`
# fu.dom
> Father Dominic puts down his pen. He takes off his glasses.
dominic: Absalom Vane. Absalom. Like the son of David, who hung by his hair in an oak tree.
dominic: Nineteen Decembers, and I never knew what to call him in my prayers. I called him "the tall one". God must have been very confused.
tenant: (through your mouth, very quietly) Tell him... tell him thank you for the chapel. And that the radiator has been broken since 1994 and he should complain to the bishop.
> Dominic laughs, startled, a real laugh, the first one you've heard from him.
dominic: Since 1994. He noticed the radiator. Of course he did.
{do comp+2; sync+1; rel:dominic+1; flag:dominicKnowsName=1}
@next dm.hub

// --- Tiny and Marcus, Night 5 ---
# fuT.0 arc=tiny night=5 label="\"How's Marcus, Tiny?\"" if=flag:fightDone&!flag:tinyBetrayed&!flag:tinyGone prio=4
@focus tiny
@gate flag:marcusGhoul ? fuT.ghoul : fuT.ok

# fuT.ghoul
tiny: He can't sleep. He hears everyone's hearts. He keeps asking me where you are. Not in a bad way. In the way a dog asks where the owner is.
tiny: He doesn't remember what it was like before. Not properly. He says it's like remembering being cold after you've had a hot bath.
* "I'll see him. After Friday. I'll teach him how to live with it."  -> fuT.teach {do promise:marcus:Teach Marcus to live with the blood}
* "Keep him away from me, Tiny. It's the only way he gets better."  -> fuT.away {do lean:restraint+1}

# fuT.teach
tiny: After Friday. Okay. If there's an after Friday for you, there's one for him. That's how it works now, isn't it.
{do rel:tiny+1}
@end

# fuT.away
tiny: Away. Yeah. Yeah, I figured you'd say that. It's going to be bad for a month. Then less bad.
tiny: ...Thanks. I mean it. That's the hard thing. You did the hard thing.
{do rel:tiny+2; flag:marcusWeaning=1}
@end

# fuT.ok
tiny: Mom's got her windows. He's been round there every day measuring for curtains. He's never measured anything in his life. He used a shoelace.
@gate flag:marcusHurt ? fuT.hurt : fuT.fine

# fuT.hurt
tiny: He gets headaches. Bad ones. He sits in the dark and Mom puts a cold flannel on his head like when he was six. He says it's worth it. I don't know if it's worth it.
{do rel:tiny+1}
@end

# fuT.fine
tiny: He said to say thanks. He said to say it to "the scary one". I said that narrows it down to everyone I work with.
{do rel:tiny+1; comp+1}
@end

// --- Priya ---
# fuP.0 arc=tenant night=4,5 label="Look in on Priya." if=flag:priya&flag:newbSafe prio=1
@focus tenant
> You find her where you left her.
@gate flag:newbSafe=gideon ? fuP.gid : fuP.b

# fuP.b
@gate flag:newbSafe=soot ? fuP.soot : fuP.margo

# fuP.gid
> Box nine at the Pawn & Coffin. She's sitting up in it with a library book, reading by the light of Gideon's green lamp. He's doing the crossword. They look like a grandfather and a granddaughter waiting for a bus.
priya: He makes me read. He says if I'm going to live forever I have to finish *Middlemarch* at least once. It's very long.
gideon: It's very good. Read it.
{do comp+1}
@end

# fuP.soot
> In the shrine, among the rats. Priya is sitting cross-legged in the middle of a ring of candles with a jar in her lap, listening to it, very seriously.
priya: She lets me listen. I've heard a man propose. In 1952. She said yes. Can you believe it? Someone said yes in 1952 and Soot's still got it.
soot: Mm. Mm. She's a good listener. Better than you.
{do comp+1}
@end

# fuP.margo
> At Margo's, in the back of the butcher's. Margo has given her a coat and a cardigan and a cup of tea she can't drink, and is teaching her gin rummy.
margo: She cheats. I love her.
priya: I don't cheat. I just remember every card. I can't help it. I remember everything now.
{do comp+1}
@end

// --- Margaret, if you made the deal ---
# fuM.0 arc=tenant night=4,5 label="Go back to the vestry. Tell Margaret what you found." if=flag:lampDeal&flag:danielKnown&!flag:margaretTold prio=5
@focus tenant
> St. Agatha's vestry, two in the morning. The beige computer. The kettle. The photograph of the boy in a graduation gown. Margaret, in her cardigan, typing nothing, waiting.
margaret: You came back. I didn't think you'd come back. Nobody ever comes back with anything.
* Tell her. Freddie Carstairs. And what happened to him.  -> fuM.tell {do lean:candour+1}
* Tell her the man who did it is gone, and leave it there.  -> fuM.gone

# fuM.tell
> You tell her. A yellow-haired Englishman in a beautiful coat who liked graduates because they "still tasted of optimism". Petersburg. A pediatrician. A fur hat.
@gate flag:freddieDead ? fuM.dead : fuM.alive

# fuM.dead
> And that he's ash. On a hospital floor, or in a velvet booth. Gone.
margaret: ...Ash.
> She looks at the photograph of her son for a long time.
margaret: I thought I'd want to see it. I thought I'd want to be there. I don't. I just want Daniel to have been the one who came home.
{do flag:margaretTold=1; keep:daniel; comp+1}
@next fuM.end

# fuM.alive
> And that he's in Lisbon, or somewhere, in a beautiful coat, still singing *Daisy Bell*.
margaret: Alive. He's alive. In Portugal.
margaret: ...You know what? I'm sixty-one. I've got a passport. I've never been to Portugal.
pulse(6): Her heart doesn't speed up. It slows down. She's decided something.
* "Margaret. Don't."  -> fuM.dont
* Say nothing.  -> fuM.nothing

# fuM.dont
margaret: Don't. A vampire telling me don't.
margaret: ...No. No, you're right. I'm not going to Portugal. I'm going to bed. I haven't been to bed properly since 2014.
{do flag:margaretTold=1; keep:daniel; lean:mercy+1}
@next fuM.end

# fuM.nothing
> She writes something on a Post-it and sticks it to the monitor. *LISBON.* Then she turns the computer off.
{do flag:margaretTold=1; flag:margaretLisbon=1; keep:daniel}
@next fuM.end

# fuM.gone
margaret: Gone. That's what the police said. That's what everyone says. "Gone." Like he caught a bus.
margaret: ...Fine. Gone. I'll take gone. I've waited eleven years for anyone to say anything at all.
{do flag:margaretTold=1; keep:daniel}
@next fuM.end

# fuM.end
margaret: Thank you. I don't know what you are. You kept your promise. That's more than Daniel's father ever did.
@end

// --- Hollis, Night 5, if she kept the plates ---
# fuH.0 arc=tenant night=5 label="Dr. Hollis left a message at the Lucky Mart." if=flag:scopeKeep&!flag:hollisMsg prio=2
@focus tenant
> A note, pinned to the Lucky Mart noticeboard under the lost cats and the guitar lessons. Small, precise handwriting, addressed to *The Gap*.
> *"Last night's plate shows a new one. Two gaps, walking together along the roofline from the Rookery to Kerr Street at 3:40 AM. One is yours, I think; I recognize the gait. The other is taller, with a long coat. I didn't know they came in pairs. — J.H."*
tenant: ...She's seen me. Not you. Me. Walking beside you. On a photographic plate.
tenant: I'm on a plate. In a box. On the Heights. I exist. I'd like a copy.
{do flag:hollisMsg=1; comp+1; sync+1}
@end

// --- Rosa and Ken, Night 4 ---
# fuR.0 arc=kenpruitt night=4,5 label="\"Ken. Your sister's in town.\"" if=flag:rosaStays|flag:rosaInn&!flag:pruittDead prio=5
@focus kenpruitt
kenpruitt: My... Rosa? Rosa's HERE? In the Ward?
kenpruitt: She hasn't spoken to me since Christmas 2019. Since I... since I told Leo comedy was for people who couldn't hold down a job. She threw a gravy boat.
* "She's at Leo's. With a stew. Go and see her."  -> fuR.go
* "She doesn't know you work with Dale."  -> fuR.dale {if flag:racketDone}

# fuR.go
kenpruitt: With a stew. She's always got a stew.
kenpruitt: ...I'll go. I'll go. I'll bring a gravy boat. A new one. As a joke. She'll either laugh or throw it.
{do flag:kenRosa=1; rel:kenpruitt+1}
@end

# fuR.dale
> He goes grey.
kenpruitt: She doesn't. She can't. If she found out I'd been taking money off a corner shop for nine years she'd... she'd look at me the way Leo does. Worse.
* "Then tell her yourself. Before someone else does."  -> fuR.tell
* "I won't tell her."  -> fuR.secret

# fuR.tell
kenpruitt: Tell her. Myself.
kenpruitt: ...Yeah. Yeah. She'll throw something. Probably the stew. I deserve the stew.
{do flag:kenConfessRosa=1; rel:kenpruitt+1; lean:candour+1}
@end

# fuR.secret
kenpruitt: Thanks. I mean... thanks. I don't deserve that. You know I don't.
{do rel:kenpruitt+1}
@end
`,'c_followups');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.kenConfessRosa)o.push(['Ken and Rosa Pruitt','She threw the stew. Then she made another one. He comes for Sunday dinner now. Leo says it\'s the most uncomfortable meal in the state and he wouldn\'t miss it.']);
  else if(f.kenRosa)o.push(['Ken and Rosa Pruitt','He brought a gravy boat. She laughed. Then she threw it. It didn\'t break. She kept it.']);
  if(f.margaretLisbon)o.push(['Margaret','In March, a sixty-one-year-old woman from the Marrow Ward was seen at a fado bar in the Alfama, sitting at the front, watching a man with yellow hair sing. She didn\'t do anything. She just watched him, every night, for a week, until he stopped coming.']);
  if(f.dominicKnowsName)o.push(['Father Dominic','Says a Mass every December 23rd for "Absalom, who sat at the back". The radiator was fixed in January. He complained to the bishop.']);
  return o;});
