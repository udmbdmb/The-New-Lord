'use strict';
/* THE NEW LORD — side quests, set seven: "The Long Exposure" (an astronomer on the Heights), "Ink" (a tattooist who works on the dead), "Choir Practice" (St. Agatha's, midnight) */
(function(){const X=NL.EXTRAS,S_=NL.Script;
X.hollis={n:'Dr. June Hollis',color:'#b8c8e0',role:'Retired astronomer, the Heights',spec:{face:{long:1.04,cheek:1.1,jaw:.9},skin:[.82,.7,.64],hair:{style:'crop',color:[.8,.8,.82]},coat:{color:[.3,.32,.4],length:.7,collar:true},shirt:[.5,.5,.55],glasses:{type:'round'},height:.94}};
X.nadia={n:'Nadia Okonjo',color:'#e0b090',role:'Tattooist, Halloran Street',spec:{face:{long:1.0,cheek:1.3,jaw:1.0},skin:[.38,.26,.2],hair:{style:'shaved',color:[.06,.05,.04]},shirt:[.12,.12,.14],pants:[.15,.15,.18]}};
X.cantor={n:'Brother Lucan',color:'#e8d8a0',role:'Cantor of the Choir',spec:{face:{long:1.12,cheek:1.3,jaw:1.1},skin:[.86,.8,.78],hair:{style:'shaved',color:[.5,.5,.5]},coat:{color:[.9,.88,.84],length:1,collar:true},shirt:[.9,.88,.85],eyeGlow:[.4,.3,.1]}};
Object.assign(NL.TASKS,{s_scope:{n:'The Long Exposure',xp:60,cat:'side'},s_ink:{n:'Ink',xp:40,cat:'side'},s_choirp:{n:'Choir Practice',xp:60,cat:'side'}});
Object.assign(NL.ITEMS,{
  plates:{n:'A Box of Photographic Plates',type:'read',d:'Glass plates, long exposures of the night sky over the Ward. On eleven of them, between the stars, walking along the rooftops: a gap shaped like a person.'},
  tattoo_fish:{n:'A Tattoo: a Fish',slot:'acc',mods:{nostalgia:1,rigor:1},d:'A small blue fish on the inside of your wrist, in Nadia\'s silver-free ink. Wonky, on purpose. It won\'t fade. Nothing on you fades now.'},
  tattoo_crane:{n:'A Tattoo: a Crane on One Leg',slot:'acc',mods:{pedigree:1,stagecraft:1},d:'The Sheriff\'s crest, small, behind your ear. NEC SOMNUS. Nor sleep.'},
  tattoo_local:{n:'A Tattoo: a Screwdriver and a Candle',slot:'acc',mods:{gutter:1,velvet:1},d:'Local 0\'s mark, on your shoulder. Dutch cried when he saw it.'},
  tattoo_lighthouse:{n:'A Tattoo: a Lighthouse',slot:'acc',mods:{echo:1,sundial:1},d:'A small lighthouse on your forearm, its beam pointing up your arm. A light you can look at.'}
});
S_.place({id:'observatory',name:'The Old Observatory, the Heights',block:'C',sub:'A copper dome behind the cemetery. Someone has been taking photographs of the sky every night for forty years.',if:'night>=2&night<=4&flag:mapOK&!flag:scopeDone',node:'ob.0',min:16});
S_.place({id:'tattoo',name:'Nadia\'s, Halloran Street',block:'A',sub:'A tattoo parlour open till four. A hand-painted sign: WE DO THE DEAD. ASK INSIDE.',if:'night>=2&night<=5&flag:mapOK&!flag:inkDone',node:'tt.0',min:6});
S_.place({id:'choir',name:'St. Agatha\'s, Midnight',block:'B',sub:'Above the Reliquary. Somebody is singing in the nave, and it isn\'t a hymn anyone mortal knows.',if:'night>=3&night<=4&flag:mapOK&!flag:choirDone&!clan:choir',node:'cp.0',min:8});
})();
NL.Script.add(String.raw`
// =====================================================================
// THE LONG EXPOSURE
// =====================================================================
# ob.0
> Behind Heights Cemetery, a copper dome on a brick drum, green with age, its slit open to the cloudy sky. A brass plaque: HALLORAN OBSERVATORY, 1888. Through the slit, a telescope the length of a canoe.
> At its foot, a small woman in her seventies with cropped white hair is loading a glass plate into a camera bolted to the eyepiece. She doesn't look round.
hollis: If you're from the council about the rates, I've paid them. If you're from the university about the telescope, it's not for sale. If you're one of the people on my plates, come in and shut the door, there's a draught.
* "One of the people on your plates?"  -> ob.plates
* Come in. Shut the door.  -> ob.plates

# ob.plates
> She hands you a glass plate without looking. A long exposure of the sky over the Ward, eight hours, the stars smeared into arcs. And across the rooftops, faint, like a fingerprint on the glass: a gap. A person-shaped absence where the stars behind should be, and aren't, as if something walked along the roofline that the light went round.
hollis: Eleven of those since 1984. Always the same rooftops. Always between two and five in the morning. Always a gap, never a figure. I wrote to *Sky & Telescope*. They said it was a fault in my plates.
hollis: It's not a fault in my plates. My plates are perfect. I make them myself.
pulse(5): Her heart is calm. Interested. Seventy-three years old and she has just looked at a dead thing in her observatory the way you'd look at a comet.
{do task:s_scope; note:s_scope|Dr. June Hollis has eleven photographic plates of the Ward's rooftops showing person-shaped gaps where the stars should be. She's been photographing you, or things like you, since 1984.}
* "What do you think they are?"  -> ob.think
* "Who else have you shown?"  -> ob.who

# ob.think
hollis: I think they're people who don't interact with light the way the rest of us do. I'm a physicist. I don't do ghosts. I do photons.
hollis: I think you're one of them. You've been standing in the draught for two minutes and the frost on the window hasn't fogged.
@next ob.hub

# ob.who
hollis: Nobody who listened. The magazine. A man from the Department of Health in September with peppermints, who said he was "interested in atmospheric anomalies". I didn't like him. I gave him the wrong box.
web(7): Harrow. Already here. Already asking. And she gave him the wrong box.
@next ob.hub

# ob.hub
* "Will you destroy the plates?"  -> ob.destroy {once}
* "Give them to me."  -> ob.give {once}
* "Keep taking them. But don't show anyone."  -> ob.keep {once}
* "What's it like, looking at the sky every night?"  -> ob.sky {once}
* Make her forget she ever took them.  -> ob.fog {once}
* Leave.  -> ob.bye

# ob.destroy
hollis: Destroy forty years of data. Because a dead person in my observatory asked me nicely.
hollis: No. I don't destroy data. Data is the only thing that's ever been honest with me.
@next ob.hub

# ob.give
hollis: Give them to you. Hm.
? velvet 11 "The man with the peppermints will come back for the right box. Better I have them than him."  -> ob.giveok | ob.giveno {id ob_give} {mod rep:candour}

# ob.giveok
hollis: ...He will, won't he. He had that look. The look of a man who's been told no once and has decided it was a clerical error.
> She takes a wooden box from under the bench. Eleven plates in felt.
hollis: Take them. I've got copies. Of course I've got copies. I'm a scientist.
hollis: The copies are in a safe deposit box at the bank and the key is in my cat. Don't ask.
{do give:plates; flag:scopePlates=1; task:s_scope=done; xp:60:The Long Exposure; flag:scopeDone=1}
@end

# ob.giveno
hollis: No. They're mine. I took them. Nobody takes my data.
@next ob.hub

# ob.keep
hollis: Keep taking them. Don't show anyone. That's what I've done for forty years. You're not asking me anything new.
hollis: ...But I will add a note in my log, under tonight. "Visited by one of the gaps. Polite. Didn't fog the window."
{do flag:scopeKeep=1; task:s_scope=done; xp:50:The Long Exposure; flag:scopeDone=1}
@end

# ob.sky
> She stops. She actually looks at you.
hollis: Nobody's asked me that since my husband died.
hollis: It's like being very small and not minding. It's like... you look at Andromeda, and the light hitting your eye left it two and a half million years ago, before there were people. You're seeing something older than everything. And it's beautiful, and it doesn't care about you at all, and that's the most restful thing in the world.
hollis: Would you like to look? The cloud's breaking.
* Look.  -> ob.look

# ob.look
> You put your eye to the eyepiece. The cold brass against your face. And there, in the dark, a smudge of light like a thumbprint of milk: a galaxy. Older than the Tenant. Older than the Magistrate. Older than Old Wen and his seven hundred years.
tenant: (very quietly) ...Oh. I never looked up. Eighty years on the rooftops of this city and I never once looked up.
{do comp+3; sync+1}
@next ob.hub

# ob.fog
? velvet 9 "Look at me. There was nothing on the plates. A fault. Just a fault."  -> ob.fogok | ob.fogno {id ob_fog}

# ob.fogok
> Her eyes go soft. She looks at the plate in her hand, frowns, and puts it back in the box.
hollis: Faulty batch. Damn. Forty years and I'm still getting faulty batches. I'll have to make a new emulsion.
> She won't remember you. She'll make a new emulsion. The gaps will still be on the plates, and she'll throw them away.
{do flag:scopeFog=1; flag:scopeDone=1; task:s_scope=done; xp:30:The Long Exposure; lean:candour-1}
@end

# ob.fogno
hollis: Are you trying to hypnotise me? Your pupils are doing something. Stop it. I've had cataract surgery. It won't work.
@next ob.hub

# ob.bye
hollis: Shut the door. Draught.
@end

// =====================================================================
// INK
// =====================================================================
# tt.0
> Nadia's, Halloran Street. A narrow shop with flash sheets on every wall: roses, skulls, swallows, anchors, a whole wall of grinning cats. Behind the counter, a woman with a shaved head and both arms sleeved in black ink, cleaning a needle.
nadia: You read the sign. Good. People usually just stand in the doorway and stare at it.
nadia: Your skin heals. All of it. Ink, scars, everything, gone by the next night. Except with mine. Mine stays. Silver-free, iron-free, and a little something I'm not telling you about from a woman in Lagos. Thirty years I've been doing the dead. Nobody's complained.
nadia: What do you want?
{do task:s_ink}
* A fish. Small. Wonky. Blue.  -> tt.fish
* A crane on one leg. The Sheriff's crest.  -> tt.crane
* A screwdriver and a candle.  -> tt.local {if flag:local0Badge|rel:dutch>=2}
* A lighthouse.  -> tt.light {if flag:pcLibrary}
* "Why do the dead want tattoos?"  -> tt.why
* "Nothing. I was just looking."  -> tt.no

# tt.why
nadia: Because nothing on you changes any more. You'll look exactly like this in a hundred years. Same scar on your thumb. Same chipped tooth. You're a photograph.
nadia: A tattoo is the only thing you can *add*. The only way to say: this happened to me after. I'm still happening.
@next tt.0b

# tt.0b
* A fish. Small. Wonky. Blue.  -> tt.fish
* A crane on one leg. The Sheriff's crest.  -> tt.crane
* A screwdriver and a candle.  -> tt.local {if flag:local0Badge|rel:dutch>=2}
* A lighthouse.  -> tt.light {if flag:pcLibrary}
* "Nothing. Not yet."  -> tt.no

# tt.fish
nadia: A fish. Wonky on purpose? Okay. I can do wonky. Wonky's harder than straight, nobody believes me.
> It takes forty minutes. It doesn't hurt the way it should. When it's done, there's a small blue fish on the inside of your left wrist, slightly lopsided, like something drawn in marker on a mailbox by a nine-year-old.
nostalgia(5): Robin's hand holding your wrist very gently so it won't smudge.
{do give:tattoo_fish; flag:inkDone=1; task:s_ink=done; xp:40:Ink; comp+2}
@end

# tt.crane
nadia: The crane. NEC SOMNUS. I did that one for him, you know. Behind his ear. 1979. He sat in that chair and didn't say a word for two hours and tipped me fifty dollars.
tenant: ...I'd forgotten. She was twenty-one. She had green hair.
nadia: I had green hair.
> Behind your ear. Small. Exact. A crane on one leg over a motto nobody alive can translate without looking it up.
{do give:tattoo_crane; flag:inkDone=1; task:s_ink=done; xp:40:Ink; sync+2}
@end

# tt.local
nadia: Local 0. Ha. I've done about thirty of those. Dutch sends them all to me. He's got one on his backside, did you know? Don't tell him I told you.
> On your shoulder. A screwdriver crossed with a candle. Slightly faded on purpose, so it looks like it's been there for years.
{do give:tattoo_local; flag:inkDone=1; task:s_ink=done; xp:40:Ink; rel:dutch+2}
@end

# tt.light
nadia: A lighthouse. Okay. Which one? They're all different. The stripes, the lamp room. People don't know that.
* "Bell Rock."  -> tt.light2
* "Eddystone."  -> tt.light2
* "Any one. The one you'd draw."  -> tt.light2

# tt.light2
> She draws it freehand. A white tower with a lamp at the top, its beam drawn as two lines spreading up your forearm toward your elbow. A light you can look at.
{do give:tattoo_lighthouse; flag:inkDone=1; task:s_ink=done; xp:40:Ink; comp+2}
@end

# tt.no
nadia: Fair enough. Come back when something's happened that you want to keep.
@end

// =====================================================================
// CHOIR PRACTICE
// =====================================================================
# cp.0
> St. Agatha's at midnight. The nave in darkness except for a ring of tall candles in the choir stalls, and in the ring, seven figures in white, singing.
> It isn't a hymn. It isn't in Latin. It's in no language at all: seven voices weaving round one note, and the note is so low you feel it in the floor before you hear it. The candle flames lean toward it. The puddles of rainwater in the aisle ripple in time.
> The tallest of them stops singing and turns. The others don't stop. He walks down the aisle toward you with his hands folded in his sleeves.
cantor: The two-voiced one. We heard you from the street. You're very out of tune. Both of you.
{do task:s_choirp; note:s_choirp|The Choir practises in St. Agatha's at midnight. Their cantor says you and the Tenant are singing out of tune.}
* "What are you singing?"  -> cp.what
* "Can you help us?"  -> cp.help
* "Stay out of my head."  -> cp.out

# cp.out
cantor: We're not in your head, child. You're in our nave. With a Sovereign in your throat, singing flat.
@next cp.what

# cp.what
cantor: The Ward. We sing the Ward. Every heartbeat in it, every Kindred's hunger, every rat in the pipes. It's one chord, if you listen. Mostly. We sing it so we know when it changes.
cantor: It changed on Monday at 4:14. A note went out. A very old, very proud note. And a new one came in, small and frightened and doubled.
@next cp.help

# cp.help
cantor: Help. Hm. We can't make two voices one. Nobody can, without killing one of them. But we can teach you to sing together. In harmony. If you'll stand in the ring.
* Stand in the ring.  -> cp.ring
* "Not tonight."  -> cp.bye

# cp.ring
> You step into the ring of candles. The six who are still singing open their circle to let you in, without stopping, without looking at you.
cantor: Hum. Any note. Yours.
> You hum. It comes out thin and wavering. The Choir bends their chord toward it, softly, the way you'd cup a match against the wind.
cantor: Now let him sing.
> You let go. A second note comes out of the same throat, under yours, deeper, rough, two hundred years old and furious about being asked.
? echo 11 "Don't fight it. Find the space between his note and yours. Sit there."  -> cp.third | cp.clash {id cp_echo} {mod flag:choirThird|flag:wenWater}

# cp.third
> And there it is. Between your note and his, an interval. A third. The sweetest interval there is. Your two voices, sitting in it together, not one and not fighting. The Choir closes round it like hands round a candle. The whole nave rings.
> For about a minute, the oldest and the youngest thing in your body sing the same chord as the Ward.
cantor: ...There. There. Oh, that's beautiful. Do you hear it? Do you hear what you sound like when you're not at war?
tenant: (after, very quietly) I didn't know I could sing. I thought I was tone deaf. Agnes always said I was tone deaf.
{do flag:choirDone=1; flag:choirHarmony=1; task:s_choirp=done; xp:60:Choir Practice; comp+3; sync+2}
@end

# cp.clash
> The two notes grind against each other like stones. The candles gutter. One of the Choir winces and stops singing for a beat.
cantor: No. No, you're fighting him. Or he's fighting you. It's the same thing from out here.
cantor: Come back. Any midnight. It took me forty years to learn to sing with my own sire, and she'd been dead a century.
{do comp+1; flag:choirTried=1}
@end

# cp.bye
cantor: Go well. Try not to shout. It carries.
@end
`,'c_sq7');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.scopePlates)o.push(['Dr. June Hollis','Still takes a plate every night. In March she sent a paper to a journal on "anomalous occultation of starlight by unresolved terrestrial objects". It was rejected. She framed the rejection letter.']);
  if(f.choirHarmony)o.push(['St. Agatha\'s','The Choir still sings the Ward at midnight. Since November there\'s a new interval in the chord, a third, two notes from one throat. The cantor says it\'s the best thing that\'s happened to the music since 1650.']);
  return o;});
