'use strict';
/* THE NEW LORD — save slots: eight manual slots plus the autosave, from the title screen and in game.
   Slots live in localStorage as newlord.slot.N = {meta, state}. Export/import as a .json file for backups. */
(function(){
const G=NL.G,A=NL.Audio,$=s=>document.querySelector(s),esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const AUTO='newlord.campaign.v1',N=8,key=i=>'newlord.slot.'+i;
const get=k=>{try{return JSON.parse(localStorage.getItem(k)||'null');}catch(e){return null;}};
const put=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true;}catch(e){return false;}};
const del=k=>{try{localStorage.removeItem(k);}catch(e){}};
function placeName(S){const P=(NL.PLACES||[]).find(p=>p.room===S.room||(p.rooms||[]).includes(S.room));const R=NL.ROOMS&&NL.ROOMS[S.room];return R&&R.name?(P&&P.name&&P.name!==R.name?P.name+' · '+R.name:R.name):(P?P.name:'Somewhere in the Ward');}
function clock(S){const m=(S.time||0)+21*60;const h=Math.floor(m/60)%24,mm=m%60;return String(h).padStart(2,'0')+':'+String(mm).padStart(2,'0');}
function metaOf(S){const c=S.clan&&NL.CLANS[S.clan],p=S.past&&NL.PASTS[S.past];const pm=S.clan&&NL.premadeFor?NL.premadeFor(S.clan,S.gender||'m'):null;
  return {night:S.night||1,clock:clock(S),place:placeName(S),clan:c?c.name:'',clanKey:S.clan||'',gender:S.gender||'',past:p?p.name:'',look:pm?pm.t:'',name:S.flags&&S.flags.knowName?'Casey Morrow':'',at:Date.now()};}
function canSave(){const S=G.S;const W=G.Wd||{};return !G.busy&&S&&S.chapter!=='cold'&&S.chapter!=='end'&&S.clan;}
function saveTo(i){if(!canSave())return false;G.autosave();const st=get(AUTO);if(!st)return false;return put(key(i),{v:1,meta:metaOf(st),state:st});}
async function loadFrom(k){const d=get(k);const st=d&&d.state?d.state:d;if(!st)return;if(k!==AUTO)put(AUTO,st);close(true);if(!$('#panel').hidden)G.closePanel();await G.loadGame();G.toast&&G.toast('xp','Loaded: Night '+(st.night||1)+', '+clock(st),'The Ward remembers');}
const when=t=>{if(!t)return '';const d=new Date(t),now=new Date();const same=d.toDateString()===now.toDateString();return same?'Today '+d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):d.toLocaleDateString([],{month:'short',day:'numeric'})+' '+d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});};
function thumb(m){const k=m&&m.clanKey?('you_'+m.clanKey+'_'+(m.gender==='f'?'f':'m')):'';const url=k&&NL.PAINTED&&NL.PAINTED[k];const c=m&&m.clanKey&&NL.CLANS[m.clanKey];
  return url?`<img class="sth" src="${url}" alt="">`:`<span class="sth sig" style="--c:${c?c.aura:'#6b6f80'}"><b>${m&&m.night?['I','II','III','IV','V'][m.night-1]||m.night:'—'}</b></span>`;}
let mode='load',armed=null,note='';
function row(k,label,d,isAuto){const m=d&&(d.meta||(d.night?metaOf(d):null));
  const empty=!m;const canS=mode==='save'&&!isAuto&&canSave();
  const btn=(act,txt,cls)=>`<button class="sbtn ${cls||''}" data-sact="${act}" data-sk="${k}">${txt}</button>`;
  let acts='';
  if(mode==='save'&&!isAuto)acts+=btn('save',armed===k+':save'?'Tap again to overwrite':empty?'Save here':'Overwrite',armed===k+':save'?'warn':'');
  if(mode==='load'&&!empty)acts+=btn('load','Load');
  if(!empty&&!isAuto)acts+=btn('export','Export','ghost')+btn('del',armed===k+':del'?'Tap again to delete':'Delete',armed===k+':del'?'warn ghost':'ghost');
  return `<div class="srow ${empty?'empty':''} ${isAuto?'auto':''}">${thumb(m)}<div class="sinfo"><div class="sk">${esc(label)}${m?' · '+esc(when(m.at)):''}</div>${m?`<b>Night ${m.night} · ${esc(m.clock)}</b><span>${esc(m.place)}</span><small>${esc([m.name,m.clan,m.look,m.past].filter(Boolean).join(' · '))}</small>`:`<b class="nil">Empty</b>`}</div><div class="sacts">${canS||mode==='load'||!empty?acts:''}</div></div>`;}
function render(){const el=$('#saves');const inGame=!$('#title')||$('#title').hidden;
  const auto=get(AUTO);let html=`<div class="sv"><header><div><div class="mk">${inGame?'The Ledger':'Port Vellum remembers'}</div><h2>${mode==='save'?'Save your night':'Pick up where you left off'}</h2></div><button class="sx" data-sact="close" aria-label="Close">✕</button></header>`;
  if(inGame)html+=`<div class="stabs"><button class="${mode==='save'?'on':''}" data-sact="mode" data-sk="save">Save</button><button class="${mode==='load'?'on':''}" data-sact="mode" data-sk="load">Load</button></div>`;
  if(mode==='save'&&!canSave())html+=`<p class="snote">You can only save between conversations, once you've looked in the mirror. Finish what you're doing and try again.</p>`;
  if(note)html+=`<p class="snote ok">${esc(note)}</p>`;
  html+='<div class="slist">';
  if(mode==='load')html+=row(AUTO,'Autosave',auto,true);
  for(let i=1;i<=N;i++)html+=row(key(i),'Slot '+i,get(key(i)),false);
  html+=`</div><div class="sfoot"><label class="sbtn ghost imp">Import a save file<input type="file" accept=".json,application/json" id="sImport" hidden></label><span>Saves live in this browser. Export the ones you care about.</span></div></div>`;
  el.innerHTML=html;}
function open(m){mode=m||'load';armed=null;note='';let el=$('#saves');if(!el){el=document.createElement('div');el.id='saves';el.className='screen';el.hidden=true;$('#app').appendChild(el);
    el.addEventListener('click',onClick);el.addEventListener('change',onImport);}
  render();el.hidden=false;requestAnimationFrame(()=>el.classList.add('in'));A&&A.sfx&&A.sfx('open');}
function close(quiet){const el=$('#saves');if(!el)return;el.classList.remove('in');setTimeout(()=>{if(!el.classList.contains('in'))el.hidden=true;},400);if(!quiet&&A&&A.sfx)A.sfx('close');}
function exportSlot(k){const d=get(k);if(!d)return;const m=d.meta||{};const blob=new Blob([JSON.stringify(d)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`new-lord-night${m.night||''}-${(m.clock||'').replace(':','')}.json`;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},500);}
function onImport(e){if(e.target.id!=='sImport')return;const f=e.target.files&&e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{let d=JSON.parse(r.result);if(!d.state&&d.night)d={v:1,meta:metaOf(d),state:d};if(!d.state)throw 0;let i=1;while(i<N&&get(key(i)))i++;put(key(i),d);note='Imported into slot '+i+'.';}catch(_){note='That file isn\'t a New Lord save.';}render();};r.readAsText(f);}
function onClick(e){const b=e.target.closest('[data-sact]');if(!b)return;const act=b.dataset.sact,k=b.dataset.sk;note='';
  if(act==='close'){close();return;}
  if(act==='mode'){mode=k;armed=null;A.sfx('page');render();return;}
  if(act==='load'){A.sfx('click');loadFrom(k);return;}
  if(act==='export'){exportSlot(k);return;}
  if(act==='del'){if(armed!==k+':del'){armed=k+':del';render();return;}del(k);armed=null;A.sfx('close');render();return;}
  if(act==='save'){const has=!!get(k);if(has&&armed!==k+':save'){armed=k+':save';render();return;}const i=+k.split('.').pop();armed=null;if(saveTo(i)){A.sfx('level');note='Saved to slot '+i+'.';}else note='Couldn\'t save here right now.';render();return;}}
NL.Saves={open,close,saveTo,list:()=>Array.from({length:N},(_,i)=>get(key(i+1)))};
/* in game: a Save/Load button in the tool rail and in Settings */
document.addEventListener('DOMContentLoaded',()=>{});
function addTool(){const t=$('#tools');if(!t||t.querySelector('[data-p="saves"]'))return;const b=document.createElement('button');b.className='tb';b.dataset.p='saves';b.setAttribute('aria-label','Save and load');b.title='Save and load';
  b.innerHTML='<svg viewBox="0 0 24 24"><path d="M5 3h11l3 3v15H5z"/><path d="M8 3v5h7V3M8 21v-7h8v7"/></svg>';t.insertBefore(b,t.querySelector('[data-p="settings"]'));
  t.addEventListener('click',e=>{const x=e.target.closest('[data-p="saves"]');if(!x)return;e.stopImmediatePropagation();open(canSave()?'save':'load');},true);}
addTool();
})();
