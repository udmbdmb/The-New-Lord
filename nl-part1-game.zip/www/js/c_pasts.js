'use strict';
/* THE NEW LORD — who you were: a personal quest for each past (the paramedic, the litigator, the promoter, the evidence clerk) */
(function(){
const S_=NL.Script,X=NL.EXTRAS;
NL.ITEMS.lanternpay={n:'LANTERN\'s Payment Schedule',type:'read',d:'Photocopies in triplicate, your initials on every page: "Volunteer honoraria · 7 × $500 · Disposal (Kowalski\'s) · $4,000."'};
Object.assign(NL.TASKS,{p_paramedic:{n:'Stay With Me',xp:80,cat:'secret'},p_litigator:{n:'The Exact Wording',xp:80,cat:'secret'},p_promoter:{n:'The Velvet Hour',xp:80,cat:'secret'},p_clerk:{n:'Chain of Custody',xp:80,cat:'secret'}});
X.ruth={n:'Ruth Okoro',color:'#90c0e0',role:'Paramedic, Station 4',spec:{skin:[.34,.24,.2],hair:{style:'crop',color:[.06,.05,.05]},shirt:[.15,.3,.2],coat:{color:[.12,.28,.2],length:.4,collar:true},pants:[.12,.15,.2]}};
X.shaw={n:'Harriet Shaw',color:'#d0c0e0',role:'Senior partner, Dunmore & Shaw',spec:{face:{long:1.06,jaw:0.8},skin:[.88,.78,.72],hair:{style:'bun',color:[.7,.66,.62]},glasses:{type:'reading'},shirt:[.85,.85,.88],coat:{color:[.15,.15,.2],length:.6,collar:true},height:.95}};
X.rook={n:'Rook',color:'#e0a0e0',role:'DJ · used to run the Velvet Hour with you',spec:{skin:[.55,.4,.32],hair:{style:'fringe',color:[.85,.2,.6]},shirt:[.1,.1,.12],coat:{color:[.25,.1,.3],length:.5,collar:true},glasses:{type:'aviator'}}};
X.okeefe={n:'Sgt. O\'Keefe',color:'#a0a8b8',role:'Evidence room, Precinct 9',spec:{face:{wide:1.06,jaw:0.6,cheek:1.0},skin:[.88,.72,.66],hair:{style:'shaved',color:[.7,.6,.5]},shirt:[.12,.16,.28],pants:[.1,.12,.2],height:1.0,width:1.1}};
S_.place({id:'station4',name:'Ambulance Station 4',block:'C',sub:'Behind St. Jude\'s. The diesel smell is familiar.',if:'past:paramedic&night>=2&night<=5&!flag:pastDone',node:'pp.0',min:10});
S_.place({id:'dunmore',name:'Dunmore & Shaw, Attorneys',block:'B',sub:'Reliquary Row, second floor. A light still on.',if:'past:litigator&night>=2&night<=5&!flag:pastDone',node:'pl.0',min:10});
S_.place({id:'velvet',name:'The Velvet Hour (closed)',block:'A',sub:'A shuttered club on Dock Road. The sign still says VELVET.',if:'past:promoter&night>=2&night<=5&!flag:pastDone',node:'pv.0',min:14});
S_.place({id:'precinct',name:'Precinct 9',block:'C',sub:'The basement entrance. The evidence cage.',if:'past:clerk&night>=2&night<=5&!flag:pastDone',node:'pc.0',min:14});
})();
NL.Script.add(String.raw`
// =====================================================================
// THE PARAMEDIC · Stay With Me
// =====================================================================
# pp.0
> Behind St. Jude's, a low brick shed with two ambulances nosed into the bays and a strip light over a door marked STATION 4 · NO PUBLIC. Diesel. Disinfectant. A gurney's wheels on wet asphalt.
> You know this place with your body before you know it with your head. Your hands go to a pocket that isn't there for a pair of gloves that aren't there.
nostalgia(2): *Stay with me.* Your own voice, in the back of a rig, at four in the morning, more times than you can count.
> A woman in green is restocking a jump bag on the bumper of the second ambulance. She looks up. She drops a roll of tape.
ruth: No. No no no. You're dead. You died. Two weeks ago. They told us you'd gone off sick and then they told us you'd... they had a collection. I put twenty bucks in.
{do task:p_paramedic; meet:ruth}
* "Ruth."  -> pp.name
* "I'm sorry. I don't remember you."  -> pp.forget {do lean:candour+1}
* "I'm not dead. Not exactly."  -> pp.notdead

# pp.name
> You don't know how you know her name. It comes out of your mouth before you've decided to say it, the way you'd say "pass the salt" to someone you'd eaten a thousand meals with.
ruth: Ruth. Yeah. Yeah, it's Ruth. You always said it like that. Like it had two syllables. Ru-uth.
@next pp.story

# pp.forget
ruth: Don't remember. You don't remember me. Six years. Six years in the back of a rig with you, and you don't...
> She sits down on the bumper.
ruth: What happened to you?
@next pp.story

# pp.notdead
ruth: Not exactly. You're grey. You're grey like a two-day stiff. You're not breathing unless you talk. I've done this job eleven years, love, I know dead.
ruth: ...And I know you. What happened?
@next pp.story

# pp.story
ruth: This summer you got sick. Anemic. Tired all the time. You couldn't do the lifting. They put you on light duties. Then a doctor at St. Jude's said there was a trial. Paid. A cure, maybe. You said, "Ruth, it's a free checkup, I'll be back by Christmas."
ruth: You never came back. In August the station manager said you'd withdrawn from the trial and gone travelling. Then two weeks ago he said you'd died. Abroad. No funeral. No body. Just a collection.
web(5): Rostova's trial took you when you were sick. Then the Sheriff took you out. Then LANTERN or someone wrote you off as dead.
* "Tell me who I was. On the job."  -> pp.who
* "I've got your twenty bucks somewhere."  -> pp.joke
* "Did anyone else ask about me?"  -> pp.ask

# pp.who
ruth: Who you were. Christ.
ruth: You were the one who talked. To everyone. Drunks, junkies, the old ladies who'd fallen in the bath. You'd hold their hand and talk about nothing all the way to the ER. The weather. Baseball. Russian novels, for God's sake. You told a man with a stab wound the whole plot of *Anna Karenina* once to keep him awake. He lived. He sent a card. "Tell your mate I hated the ending."
ruth: You had this thing you said. Every call. "Stay with me." Like a prayer. Even when they were long gone. You'd say it to them all the way in.
nostalgia: Stay with me. Stay with me. You said it to the Sheriff in the freezer. Your teeth in his throat and the light coming, and you said it.
{do mem:ruth:who; flag:pastMemory=1; comp+2:Stay with me}
@next pp.end

# pp.joke
ruth: Twenty bucks. You owe me twenty bucks for your own funeral. That's the most you thing I've ever heard.
> She laughs, and cries, and laughs.
@next pp.who

# pp.ask
ruth: A man. Sunglasses. In August. Said he was from the Department of Health. Asked if you'd had "any unusual contacts" before you got sick. Asked for your next of kin.
ruth: I gave him your sister's address. On the coast. I thought he was from the insurance. I'm sorry. I'm so sorry.
web(6): Harrow has your sister's address. He's had it since August.
{do flag:harrowHasSister=1; mem:ruth:harrow}
@next pp.who

# pp.end
ruth: What are you going to do? Are you... are you going to be okay? Is there someone I can call? A doctor? A priest? I don't know what you call for this.
* "Keep my secret, Ruth. That's all."  -> pp.secret {do lean:loyalty+1}
* Give her something: your blood, so she'll heal fast for a week.  -> pp.blood {blood 1}
* "There's nobody to call. Go back to work."  -> pp.work

# pp.secret
ruth: Your secret. Love, nobody would believe me. "Hi, Station Manager, my dead partner came round and they're a vampire." I'd be on light duties for the rest of my life.
ruth: But yeah. Course. Course I will. Six years.
{do task:p_paramedic=done; flag:pastDone=1; xp:80:Stay With Me; rel:ruth+2; flag:frag_past=1}
@end

# pp.blood
> She looks at your wrist and then at you, very steadily, the way paramedics look at things.
ruth: You're offering me... no. No. Thanks. I've got a bad back and two kids and a mortgage, and none of those are things you can fix with that.
ruth: But that was kind. That was a very you thing to do. Six years and you're still trying to fix everyone in the back of the rig.
{do task:p_paramedic=done; flag:pastDone=1; xp:80:Stay With Me; rel:ruth+2; flag:frag_past=1}
@end

# pp.work
ruth: Back to work. Yeah. There's a cardiac arrest on Halloran in ten minutes, probably. There always is.
ruth: Stay with me, yeah? Whatever you are. Stay with me.
{do task:p_paramedic=done; flag:pastDone=1; xp:80:Stay With Me; flag:frag_past=1}
@end

// =====================================================================
// THE LITIGATOR · The Exact Wording
// =====================================================================
# pl.0
> Reliquary Row, second floor, above a tailor's. A brass plate: DUNMORE & SHAW · ATTORNEYS AT LAW · EST. 1952. A light on in the corner office at two in the morning. You climb the stairs without deciding to. Your hand finds the light switch in the dark of the landing on the first try.
> In the corner office, a woman of seventy in a cardigan, reading a deposition with a red pen. She doesn't look up.
shaw: If you're from the cleaners, you're four hours early. If you're from the Bar Association, you're three years late.
> She looks up. The red pen stops.
shaw: ...Oh. Oh, it's you.
{do task:p_litigator; meet:shaw}
* "You know me."  -> pl.know
* "Dunmore. Like Agnes Dunmore."  -> pl.agnes {if flag:knowAgnesGrave|mem:tenant.agnesstory}
* "Why did they take my licence?"  -> pl.why

# pl.know
shaw: Know you? I trained you. Junior associate, 2014. You were the best I ever had and the most annoying. You argued with the judges. You argued with *me*. You argued with the coffee machine.
shaw: Harriet Shaw. You used to call me Harry when you thought I couldn't hear.
@next pl.why

# pl.agnes
shaw: Agnes Dunmore. Albert's wife. Albert founded the firm. He drove buses for thirty years and studied law at night and opened this office in 1952 with his pension. His wife was a typist at the Courthouse.
shaw: Their grandson's my partner. Was. He retired. How on earth do you know about Agnes?
tenant: Albert. Albert founded a *law firm*. The bus driver. Good God. Good for him.
{do mem:shaw:agnes}
@next pl.know

# pl.why
shaw: The exact wording, you mean. You always did want the exact wording.
> She takes a folder out of the drawer without having to look for it. She's kept it near.
shaw: *Disbarred for breach of client confidentiality, having disclosed to the press privileged material concerning the client's financial relationship with a federal agency.*
shaw: The client was a medical research company called LANTERN RESEARCH LLC. You were doing their leases. You found a payment schedule for "volunteer honoraria", seven names, five hundred each, and a line item for "disposal". You sent it to the Port Vellum Herald.
shaw: The Herald never printed it. Somebody rang the editor. And three weeks later you were disbarred, and broke, and ill, and the next thing I heard, you'd signed up for a paid medical trial.
web(6): You found LANTERN before any of this. You blew the whistle. They took your licence and then they took you.
* "Did I volunteer? Or did they take me?"  -> pl.volunteer
* "Have you still got the papers?"  -> pl.papers

# pl.volunteer
shaw: You told me you volunteered. "To see from the inside, Harry. If I can't get it into a newspaper, I'll get it into a courtroom with my own blood as Exhibit A." I told you you were insane.
shaw: You said, "Insane is a legal term. I prefer 'committed'."
{do mem:shaw:volunteer; flag:pastMemory=1}
@next pl.papers

# pl.papers
shaw: The papers. Of course I've still got the papers. I've got copies of everything. You taught me that, actually, in your second year. "Always make a copy, Harry. The day you don't is the day they take the original."
> She hands you a manila envelope. Inside: LANTERN RESEARCH LLC's payment schedule, in triplicate, with your initials on every page.
shaw: Exhibit A. Go and get it into a courtroom.
{do give:lanternpay; task:p_litigator=done; flag:pastDone=1; xp:80:The Exact Wording; flag:frag_past=1; rel:shaw+2}
tenant: That's two copies of the same truth now, child. Mine and yours. You were investigating the same thing I was. We'd have met at the Prince's court on Friday regardless.
@end

// =====================================================================
// THE PROMOTER · The Velvet Hour
// =====================================================================
# pv.0
> Dock Road. A shuttered warehouse with a neon sign that's been switched off for a year: VELVET, in pink script, the HOUR fallen off and leaning against the wall. A side door with a keypad.
> Your fingers type four numbers before you've thought about it. The door opens.
> Inside: a dark dancefloor, a dead disco ball, a DJ booth with someone in it. A figure with pink hair, headphones round the neck, playing records to an empty room.
rook: We're closed. We've been closed since you left. Who gave you the... oh. Oh. *Oh.*
{do task:p_promoter; meet:rook}
* "Rook."  -> pv.name
* "What is this place?"  -> pv.place

# pv.name
rook: Rook. Yeah. You named me. You said "every DJ needs a bird name" and I said "what about crow" and you said "crows are overrated, rooks are clever and nobody notices them". You were right.
@next pv.story

# pv.place
rook: The Velvet Hour. Our club. Yours, mostly. I just played the records. You ran the door, the list, the money, the bar, the bribes. You knew everybody. You could get anybody in. Anyone, for a price.
@next pv.story

# pv.story
rook: Last summer some people from the Reliquary started coming. Pale. Rich. Polite. They'd pay double for the back room and they'd always leave with someone. The someones didn't always come back to the club.
rook: You noticed. You always noticed. You started a list. Who went with who. Who didn't come back. Seven names, by September. You took it to the police. The police took you off the street for a "wellness check".
rook: Then you got sick. You said you were going to do a trial at St. Jude's for the money, to keep the club open. Then you just... didn't come back. I kept the club. I've been playing records to nobody for a year in case you walked in.
pulse(4): Pink hair, headphones, very thin. Hasn't eaten properly in a while. Has kept a dead club open for a year out of faith.
* "Play me something. Something we used to play."  -> pv.play
* "The list. Have you still got it?"  -> pv.list
* "Close the club, Rook. Go and live."  -> pv.close

# pv.play
> Rook puts on a record. A track you don't know and know completely: a slow, aching house record with a woman singing in Portuguese. The disco ball doesn't turn. You stand on the empty floor and your body moves before your head can stop it.
rook: You always did this one at four. Last song. You'd stand in the middle of the floor and put your arms up and everybody would just... stop and watch you. Then we'd turn the lights on.
nostalgia(2): Arms up, eyes closed, the last song, four in the morning. You were happy. You remember being happy.
{do comp+3:The last song; flag:pastMemory=1; mem:rook:song}
@next pv.end

# pv.list
rook: The list. Yeah. Under the till. You made me promise never to throw it out.
> A page from a guest-list pad, your handwriting, seven names, dates, and next to each one: *left w/ Lisette (R.)* or *left w/ Ashby*. And at the bottom: *Ask the doctor at St. J's. She's buying.*
web(6): The Court was taking people from your club and selling them on. To Rostova. To the trial. You saw it and you went in after them.
{do flag:velvetList=1; mem:rook:list}
@next pv.end

# pv.close
rook: Close it. Yeah. Yeah, I know. I've been waiting for someone to say it. I've been waiting for you to say it.
@next pv.end

# pv.end
rook: Are you going to come back? To the club? We could open it again. I don't care what you are. We'd do nights. Obviously.
* "Maybe. After Friday."  -> pv.maybe {do promise:velvet:Reopen the Velvet Hour with Rook}
* "No. But keep the records."  -> pv.no

# pv.maybe
rook: After Friday. Okay. I'll fix the disco ball. It only needs a new motor.
{do task:p_promoter=done; flag:pastDone=1; xp:80:The Velvet Hour; flag:frag_past=1; rel:rook+2}
@end

# pv.no
rook: Keep the records. Yeah. I'll keep them. I'll play the last song at four every night, for you, wherever you are.
{do task:p_promoter=done; flag:pastDone=1; xp:80:The Velvet Hour; flag:frag_past=1; rel:rook+1}
@end

// =====================================================================
// THE EVIDENCE CLERK · Chain of Custody
// =====================================================================
# pc.0
> Precinct 9's basement door is round the back by the bins, propped open with a fire extinguisher for the smokers. You know exactly where the camera is and exactly how to stand so it can't see you. You go down.
> The evidence cage. Numbered boxes on steel shelves, floor to ceiling. A desk with a sign-in sheet and a mug that says WORLD'S OKAYEST CLERK. A big sergeant in shirtsleeves, eating a sandwich.
okeefe: Cage is closed after midnight unless you've got a... oh, my Christ. It's you.
{do task:p_clerk; meet:okeefe}
* "Sergeant O'Keefe."  -> pc.name
* "That's my mug."  -> pc.mug

# pc.name
okeefe: Sergeant O'Keefe. Yeah. You always said the apostrophe like it was a separate word. O-apostrophe-Keefe.
@next pc.story

# pc.mug
okeefe: It's your mug. I kept it. Nobody else is allowed to use it. Detective Miller tried once and I made her wash it twice.
@next pc.story

# pc.story
okeefe: You were the clerk. Eight years. Best clerk this basement ever had. You could find any box in the cage blind. You knew the chain of custody on every exhibit back to 2006.
okeefe: Then last summer you came to me white as a sheet and said seven Missing Persons files had been signed out by the Captain and never signed back in. You said "Sarge, there's no such thing as a file that doesn't come back."
okeefe: Two weeks later you were transferred to traffic. Then you got sick. Then you were gone.
web(6): You found the seven files missing before anyone. Miller came looking later. You were first. They moved you, and then they moved you again.
* "Where are the files now?"  -> pc.files
* "Did Miller know? That I found them first?"  -> pc.miller

# pc.files
okeefe: Where? Nobody knows. The Captain's office. A shredder. Virginia.
okeefe: Except. You made copies. You always made copies. You said, "Sarge, the day you don't make a copy is the day they take the original." You put them somewhere. You never told me where.
? web 9 Think. Where would an evidence clerk hide copies in an evidence cage?  -> pc.found | pc.notfound {id pc_web}

# pc.found
> In plain sight. Of course. You walk to the shelves without thinking, row K, box 2011-0414, a closed case from thirteen years ago: MILLER, MATEO · MISSING. Nobody would ever open a box that Detective Miller signs out every year and never reads.
> Inside, under a photograph of a boy with a gap in his teeth: seven photocopied files, each with the Captain's signature on the sign-out sheet and none on the return.
okeefe: In her brother's box. You put them in her brother's box. You knew she'd never look, and you knew she'd never let it go to archive.
{do give:casefile; flag:sevenFilesFound=1; task:p_clerk=done; flag:pastDone=1; xp:80:Chain of Custody; flag:frag_past=1; flag:pastMemory=1}
tenant: 0414. Even then. You and your numbers.
@end

# pc.notfound
okeefe: You'll remember. You always did. It'll come to you at three in the morning like everything else.
@end

# pc.miller
okeefe: Miller? No. She thinks she's the only one who noticed. You told me not to tell her. You said she'd get herself killed. You said you'd hand it to her yourself when you had all seven.
okeefe: She used to bring you coffee every Thursday when she came down for her brother's box. Two cups. Black, burnt, no sugar, both of them, because she never once asked how you took yours. You drank it anyway. Eight years.
nostalgia(4): Thursday. A detective at the cage window, a coffee in each hand. "Morning, clerk." The best ten minutes of the week.
{do mem:okeefe:miller; flag:millerKnewYou=1}
@next pc.files
`,'c_pasts');
// the past fragment counts toward your name
NL.Camp.tickHooks.push((S,G)=>{if(S.flags.frag_past&&!S.flags.frag_pastNoted){S.flags.frag_pastNoted=1;setTimeout(()=>G.toast('task','A piece of who you were, put back.','The 18th Voice'),1500);}});
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
  ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
    if(G.has('lanternpay'))M.push({t:'"My own Exhibit A, from before I was this: LANTERN\'s payment schedule. Seven honoraria. And four thousand dollars for disposal."',once:'tb_lpay',ok:st=>{st.prog+=2;return [L('magistrate','Disposal. Four thousand dollars, to a butcher. That is what they thought seven lives cost.')];}});
    if(S.flags.sevenFilesFound)M.push({t:'"Seven Missing Persons files. Signed out by Precinct 9\'s Captain. Never returned. I was the clerk who noticed."',once:'tb_files7',ok:st=>{st.prog+=2;return [L('magistrate','Even their own records. Hidden in a dead boy\'s box. How very thorough of you.')];}});
    if(S.flags.velvetList)M.push({t:'"And this list, from my own club. Seven names. \'Left with Lisette\'. \'Left with Ashby\'. The Court sold them to the doctor."',once:'tb_velvet',ok:(st,S)=>{st.prog+=1;st.threat+=S.flags.side_court?1:0;return [L('ashby','I... I didn\'t know where they went after. I swear I didn\'t know.',{if:S=>!S.flags.ashbyDead}),L('magistrate','Nobody in this court ever knows where anything goes after. That is rather the problem.')];}});
    return M;};})();
