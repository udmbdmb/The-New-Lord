'use strict';
/* THE NEW LORD — side quests, set six: "The Ferryman" (a Wraith who rows the dead across the Vellum), "Box Seven" (Gideon's lost tenant), "Daybreak" (the man on the forum who sends mortals to kill you) */
(function(){const X=NL.EXTRAS,S_=NL.Script;
X.ferryman={n:'The Ferryman',color:'#90a8b8',role:'A Wraith with a rowing boat',spec:{face:{long:1.15,cheek:1.6,jaw:1.3},skin:[.6,.62,.66],hair:{style:'long',color:[.5,.5,.55]},coat:{color:[.18,.2,.22],length:1,collar:true},shirt:[.15,.15,.17],eyes:[.75,.85,.95],eyeGlow:[.2,.25,.3],alpha:.9,hat:{type:'widebrim',color:[.12,.12,.14]}}};
X.maryellen={n:'Mary-Ellen',color:'#e0b8c8',role:'Box Seven, 1983',spec:{face:{long:1.0,cheek:1.3,jaw:.95},skin:[.84,.74,.72],hair:{style:'curly',color:[.6,.25,.12]},coat:{color:[.5,.2,.3],length:.6,collar:true},shirt:[.85,.8,.75],eyeGlow:[.3,.05,.08],height:.92}};
X.gerry={n:'Gerry',color:'#a0b0c0',role:'A docker, seventy-three',spec:{face:{long:1.05,cheek:1.0,jaw:1.4},skin:[.8,.68,.6],hair:{style:'short',color:[.85,.85,.85]},shirt:[.4,.3,.25],coat:{color:[.3,.35,.4],length:.5,collar:false},bulk:1.2}};
X.margaret={n:'Margaret',color:'#c8c890',role:'"Daybreak"',spec:{face:{long:1.0,cheek:.9,jaw:1.0},skin:[.88,.78,.7],hair:{style:'crop',color:[.6,.5,.35]},shirt:[.3,.32,.35],glasses:{type:'round'},height:.95}};
Object.assign(NL.TASKS,{s_ferry:{n:'The Ferryman',xp:60,cat:'side'},s_box7:{n:'Box Seven',xp:70,cat:'side'},s_lamp:{n:'Daybreak',xp:80,cat:'side'}});
Object.assign(NL.ITEMS,{
  obol:{n:'A Silver Coin',type:'read',d:'Greek. Very worn. An owl on one side. The Ferryman says it\'s the fare. He says everyone has one, somewhere, and most people never find out where they kept it.'},
  me_letter:{n:'Mary-Ellen\'s Letter',type:'read',d:'Pink notepaper, 1983, a heart over the i. "Gideon — paid in kindness. I\'ll be back for my coat. Don\'t let anyone else have box seven. — M-E."'},
  forumlog:{n:'A Printout from the Forum',type:'read',d:'Forty pages of a website called NIGHTWATCH. Photographs of the Ward. Addresses. A thread titled "CONFIRMED NEST — PAWN & COFFIN, RELIQUARY ROW." Posted by Daybreak.'}
});
S_.place({id:'vellumsteps',name:'The Vellum Steps',block:'D',sub:'Stone steps down into the river at the end of Kerr Street. On some nights there\'s a boat.',if:'night>=2&night<=4&flag:mapOK&!flag:ferryDone',node:'fe.0',min:12});
S_.place({id:'marek',name:'Marek\'s Van, the Viaduct',block:'D',sub:'The pirate radio man. He knows his way round a computer, and owes you a favour.',if:'night>=3&night<=5&flag:mapOK&task:s_lamp=active&!flag:lampDone&!flag:marekDead',node:'lp.marek',min:12});
})();
NL.Script.add(String.raw`
// =====================================================================
// THE FERRYMAN
// =====================================================================
# fe.0
> The Vellum Steps go down into the black river at the end of Kerr Street, slick with weed. Nobody comes here at night. The water doesn't reflect the lights of the city. It doesn't reflect anything.
> At the bottom step, tied to an iron ring, a rowing boat. In it, a tall figure in a wide-brimmed hat and a long grey coat, with the oars across his knees. He's waiting. He's always waiting.
ferryman: Not you. Not yet. You've no coin and you're not finished. But sit, if you like. It's a long night on the river and nobody ever talks to the boatman.
* Sit on the step.  -> fe.sit
* "Who do you row?"  -> fe.who
* Leave. This place is wrong.  -> fe.leave

# fe.leave
ferryman: Wise. Most of the living run. Most of the dead run too, as it happens, right up until they don't.
@end

# fe.who
ferryman: The ones who die in the Ward and don't know where to go. Drowned, mostly. Some from the hospital. Some from the alleys. They come down these steps not knowing why, and I take them across.
ferryman: Across to what, you'll ask. I don't know. I've never got out of the boat on the other side. I just row.
@next fe.sit

# fe.sit
> You sit on the cold step. The boat creaks. The river goes by without a sound.
ferryman: There's one waiting now. Up there, at the top of the steps, too frightened to come down. She's been there since Tuesday. I can't go up to her. The boatman stays in the boat. That's the rule.
> At the top of the steps, under the last streetlamp, a girl in a nurse's tunic, holding her own elbows, looking at the water. You can see through her, slightly. You can see the lamp through her.
{do task:s_ferry; note:s_ferry|There's a ghost at the top of the Vellum Steps who won't come down to the Ferryman's boat.}
* Go up to her.  -> fe.girl
* "Why won't she come down?"  -> fe.why

# fe.why
ferryman: Because she doesn't know she's dead. They never do, at first. And because somebody's still holding onto her. Up there. In the living. It's like a rope round the ankle.
@next fe.girl

# fe.girl
> You climb the steps. Up close she's young, twenty-five, with a name badge: AISLING, STAFF NURSE, ST. JUDE'S. There's a smell of formalin around her. Very faint.
aisling: Oh. Hi. Sorry. Do you know what time it is? I'm meant to be on shift. Ward 4. Sister's going to kill me.
autopsy(6): The fourth floor. Rostova's study floor. One of the nurses on the LANTERN ward. Died this week. Nobody's listed her. Nobody's noticed.
* "Aisling. I think you've already finished your shift."  -> fe.tell {do lean:candour+1}
* "Who are you waiting for?"  -> fe.wait
* "Come down to the boat. He's kind."  -> fe.boat

# fe.tell
aisling: Finished? No, I've only just... I was in the lift. I was taking bloods down to B1, and the lift stopped, and the light...
> She looks at her hands. You watch her see the streetlamp through them.
aisling: ...Oh. Oh no. Oh no, no. My mam. My mam's in Dublin. Nobody's told my mam.
@next fe.mam

# fe.wait
aisling: My mam. She rings on Thursdays. I always pick up. If I'm not there when she rings, she'll worry.
@next fe.mam

# fe.boat
aisling: A boat? I'm not getting in a boat with a stranger. Are you mad? I'm a nurse. I've seen what happens to people who get in boats with strangers.
@next fe.wait

# fe.mam
ferryman: (from the boat, very quietly) There's the rope.
* "I'll tell your mam. I promise."  -> fe.promise {do promise:aisling:Tell Aisling's mother}
* "Your mam would want you to go where it's warm."  -> fe.warm
* "What happened in the lift, Aisling?"  -> fe.lift

# fe.lift
aisling: There was a man. In grey overalls. He was in the lift with a trolley with a big metal case on it. He said "sorry, love, going down." The doors shut. The case got hot. Really hot. And the light came out of the cracks in it.
web(7): A lamp. A LANTERN lamp, being moved to B1 in a staff lift. It failed, or it was tested. And a nurse who happened to be in the lift got eleven seconds of noon.
{do flag:knowLift=1; mem:aisling:lift}
@next fe.mam

# fe.promise
> She looks at you. She believes you. The dead believe everything; it's the only thing that makes it bearable.
aisling: You promise? You'll ring her? She's Bridget. Bridget Kearney. Ballyfermot. She's in the book. Tell her... tell her I didn't feel it. Even if I did.
> She goes down the steps. One at a time. At the bottom, the Ferryman holds out his hand, and she takes it, and gets into the boat, and sits down in the stern like a passenger on a bus.
ferryman: Thank you. That's three this year somebody's helped down. It used to be none.
> He pushes off. The boat goes out onto the black water without a ripple and you lose it about thirty yards out, the way you lose a thought.
{do task:s_ferry=done; xp:60:The Ferryman; comp+2; flag:ferryDone=1; flag:aislingPromise=1}
@end

# fe.warm
aisling: Warm. It's so cold out here. Is it warm, over there?
ferryman: I've never been. I'm told so.
aisling: ...Okay. Okay. If my mam rings, tell her I've gone somewhere warm.
> She goes down. She gets in the boat. The Ferryman pushes off.
{do task:s_ferry=done; xp:50:The Ferryman; comp+1; flag:ferryDone=1}
@end

// Aisling's mother · from the payphone
# feM.0 arc=tenant night=3,4,5 label="Aisling's mother is waiting for a call." if=flag:aislingPromise&!flag:aislingCalled prio=4
@focus tenant
tenant: You made the girl on the steps a promise. Bridget Kearney. Ballyfermot. It will cost you a fortune in coins from that payphone and it will be the worst call you ever make.
tenant: I never made those calls. In eighty years. I let the police make them. I let the hospitals. I'd like, once, to have been the one.
{do flag:aislingRemind=1}
@end

# feM.call
> It takes two dollars in quarters and an international operator. It's nine in the morning in Dublin. A woman picks up with the radio on behind her.
> You tell her. You tell her Aisling was a good nurse. You tell her there was an accident in a lift. You tell her she didn't feel it. You tell her she went somewhere warm.
> Bridget Kearney doesn't scream. She says "oh" very softly, three times. Then she asks if Aisling had her coat on, because it's November, and she always forgot her coat.
* "Yes. She had her coat on."  -> feM.coat

# feM.coat
> It's a lie. It's the best lie you've ever told.
{do flag:aislingCalled=1; keep:aisling; comp+2; xp:30:Bridget Kearney; lean:mercy+1}
@end

// =====================================================================
// BOX SEVEN
// =====================================================================
# b7.0 arc=gideon night=3,4 label="\"Gideon. Box Seven's always locked. Why?\"" if=alive:gideon&rel:gideon>=2 prio=1
@focus gideon
> Box seven, against the back wall of the Pawn & Coffin, under a sheet. The only box with a padlock. The padlock is brass and old and polished.
gideon: Because it's taken. Since 1983.
gideon: Mary-Ellen. A Gilded girl. Red hair. Laughed like a fire alarm. Slept in box seven for eleven months and paid me in kindness. You know what kindness is, as a currency? It's when someone sits with your wife while you go to the bank.
gideon: One night in October 1983 she went out for a party at Elysium and didn't come back. Left her coat on the hook. Left a letter. I've kept the box locked for forty-one years.
{do task:s_box7; note:s_box7|Mary-Ellen, a Gilded Court Kindred, slept in Gideon's box seven in 1983 and vanished after a party at Elysium. Gideon has kept her box locked for forty-one years.}
* "Do you think she's dead?"  -> b7.dead
* "Let me look for her."  -> b7.look
* "Forty-one years is a long time to keep a box."  -> b7.long

# b7.dead
gideon: Probably. Your kind die like candles. One draught.
gideon: But nobody ever said. Nobody ever came to tell me. That's what I mind. Not the box. The not being told.
@next b7.look

# b7.long
gideon: My wife used to say I'd keep a sandwich forty years if somebody told me they'd be back for it.
@next b7.look

# b7.look
gideon: Look for her. All right. Here.
> He gives you the letter. Pink notepaper, a heart over the i.
{do give:me_letter}
gideon: She'd know you were from me if you showed her that. If there's anything left to show it to.
@end

# b7S.0 arc=severine night=3,4 label="\"My lady. Mary-Ellen. 1983.\"" if=task:s_box7=active&!flag:knowME&alive:sev prio=6
@focus severine
> Séverine's face does nothing. Then, slowly, it does something.
severine: Mary-Ellen Fitch. Red hair. A laugh like a burglar alarm.
severine: She was mine. My childe. The only one I ever made. I sent her away in 1983.
* "Sent her away?"  -> b7S.away

# b7S.away
severine: She fell in love with a mortal. A dockworker. She wanted to *tell* him. Everything. She wanted to bring him to Elysium, at the party, and introduce him to me, like a girl bringing a boy home to her mother.
severine: I had the Masquerade to keep. I told her: give him up or leave the city. She chose the city. She chose to leave it, I mean. She went to... I don't know. I didn't ask. I made a point of not asking.
web(6): She knows. Of course she knows where. She's kept herself from knowing for forty years, which is a different thing.
? velvet 12 "You know where she went. You've always known."  -> b7S.know | b7S.no {id b7_sev} {mod like:severine}

# b7S.know
> A very long silence.
severine: ...Halcyon Lane. In Bayside. A terraced house with a blue door. She lives with him. He's seventy-three. She's twenty-four forever. They have a cat. I had a ghoul go and look in 2009. I told him never to tell me what he saw. He told me anyway. They were dancing in the kitchen.
severine: Don't tell her I know. Don't tell her anything about me. Just... tell the old man at the pawnshop she's alive. That's all.
{do flag:knowME=1; mem:severine:maryellen; rel:severine+1; note:s_box7|Mary-Ellen lives in Bayside, on Halcyon Lane, with a mortal who's seventy-three. Séverine was her sire, and sent her away.}
@end

# b7S.no
severine: No. I don't. And I'd thank you not to ask again.
@end

# b7.bay arc=gideon night=3,4,5 label="\"Gideon. She's alive.\"" if=flag:knowME&task:s_box7=active prio=8
@focus gideon
> You tell him. Bayside. Halcyon Lane. A blue door. A dockworker who's seventy-three. Dancing in the kitchen.
> He takes off his half-moon glasses and puts them on the counter. He sits down on his stool, which he never does when there's a customer.
gideon: Alive. And happy. And she never came back for her coat.
gideon: ...Well. Well. Why would you? Why would you, if you were happy.
* "Do you want me to go to her? Take her the coat?"  -> b7.coat
* "Do you want to unlock the box?"  -> b7.unlock

# b7.coat
gideon: The coat. Yes. No. Yes.
> He takes it off the hook behind the counter, where it's hung since 1983. A green velvet coat, out of fashion for four decades. He folds it over his arm.
gideon: Tell her: box seven. Tell her it's still hers. If she ever wants it. If he dies, and she needs somewhere to sleep, and she doesn't want to be alone. Tell her Gideon kept it.
{do flag:me_coat=1}
@end

# b7.unlock
gideon: Unlock it.
> He gets out a key. It's on a ribbon round his neck. You didn't know it was there. He's worn it under his shirt for forty-one years.
> He unlocks the padlock. He lifts the lid. Inside: velvet, a little dusty. A paperback with a broken spine. A hair slide. A dried rose. A photograph of a red-haired girl with her arm round a much younger Gideon and a woman in a cardigan, all three of them laughing at something outside the frame.
gideon: My Miriam. And Mary-Ellen. And me. Christmas, 1982.
gideon: I'd forgotten I was in it.
{do task:s_box7=done; xp:70:Box Seven; rel:gideon+3; comp+2; flag:box7Open=1}
@end

# b7.go arc=gideon night=4,5 label="\"I'll take the coat to Bayside.\"" if=flag:me_coat&!flag:me_met prio=7
@focus gideon
gideon: Bayside's forty minutes on the 9. The night driver will wait if you ask nicely. Nobody ever asks nicely.
@next b7.halcyon

# b7.halcyon
> Halcyon Lane, Bayside. A terrace of narrow houses facing the docks. The cranes on the skyline like herons. A blue door. Through the front window, with the curtains not quite closed: an old man in a cardigan at a kitchen table, and a red-haired girl sitting on the table itself, swinging her legs, reading him the racing results.
> You knock. She opens the door. She sees what you are before you've opened your mouth.
maryellen: ...Oh. Oh, no. Is it her? Has she sent you? Tell her no. Tell her whatever it is, no.
* Hold out the green coat.  -> b7.mecoat
* "Séverine didn't send me. Gideon did."  -> b7.megid

# b7.mecoat
> She stares at it. Her hand goes to her mouth.
maryellen: My coat. My COAT. Oh my God. I left it on the hook. I left it on the hook at Gideon's in... oh my God. He kept it?
@next b7.megid

# b7.megid
maryellen: Gideon. Gideon Ash. Is he... he must be...
* "Seventy-four. Still behind the counter. Still keeping box seven for you."  -> b7.me2

# b7.me2
> She sits down on her own doorstep in her slippers, in the cold, with the coat in her lap.
maryellen: Forty-one years. He kept my box. I thought... I thought nobody would even notice I'd gone. I thought she'd tell everyone I was ash.
maryellen: Gerry. Gerry, come here. Come and meet... come and meet a friend of a friend.
> The old man comes to the door. He looks at you. He's a docker, seventy-three, enormous hands. He knows what you are. He's known what she is for forty years.
gerry: Evening. You'll be wanting a cup of tea, then. Or not. She never does, but I always offer.
* "Tell me about the forty years."  -> b7.me3
* "Will you come and see Gideon? Before he's gone?"  -> b7.me4

# b7.me3
maryellen: Forty years. I've watched him get old. I've sat by his bed with pneumonia, twice. I've done his tax returns. We've been to the shore every August. He's going to die soon, and I'm going to be twenty-four in a house full of his things.
maryellen: And I'd do it all again. Every day. Don't tell her that. Don't tell her anything.
gerry: She tells everyone that. She told the milkman.
@next b7.me4

# b7.me4
maryellen: See Gideon. At the shop. Where she could find me.
? velvet 10 "Séverine's known where you are since 2009. She's never come. She never will. She sent a ghoul to look, and he saw you dancing."  -> b7.me5 | b7.me6 {id b7_me}

# b7.me5
> She stares at you. Then she puts her face in the green velvet coat and laughs and cries at the same time, horribly, wonderfully.
maryellen: Dancing. She saw us dancing. She KNEW. Oh, the old cow. The old, proud, ridiculous...
maryellen: Sunday. Tell Gideon. Sunday, after dark. Gerry'll drive. I'm bringing him a cake.
{do flag:me_met=1; flag:me_visit=1; task:s_box7=done; xp:70:Box Seven; rel:gideon+3; comp+3}
@end

# b7.me6
maryellen: I can't. I can't risk it. Tell him... tell him thank you. Tell him I'm happy. That'll do. That has to do.
{do flag:me_met=1; task:s_box7=done; xp:60:Box Seven; rel:gideon+2; comp+1}
@end

// =====================================================================
// LAMPLIGHTER
// =====================================================================
# lp.0 arc=tenant night=3,4 label="The man on the forum. Daybreak." if=flag:knowDaybreak&!task:s_lamp prio=4
@focus tenant
tenant: The crossbow man said a name. Daybreak. A website where they post our havens and our faces and send their sons and cousins out with sports-shop crossbows.
tenant: Harrow didn't build that. Harrow uses it. Someone else built it, someone who believes. Believers are worse. You can't bargain with them.
tenant: The radio man. Marek. He knows computers. He owes you.
{do task:s_lamp; note:s_lamp|"Daybreak" posts the Ward's havens on a forum called NIGHTWATCH and sends mortals out to kill. Marek the pirate DJ might be able to find out who.}
@end

# lp.marek
@focus marek
> Marek's van under the viaduct: a camping lantern, a car battery, three laptops held together with gaffer tape, and a man in a balaclava eating cold noodles.
@gate seen:dj.0 ? lp.marek2 : lp.marek1

# lp.marek1
marek: Who... oh. Oh, no. Your eyes. You're one of the ones I talk about on the radio. Please don't eat me. I have noodles. You can't eat noodles. Sorry.
? velvet 8 "I'm not here to eat you. I need someone who knows computers."  -> lp.find | lp.marekno {id lp_mv}

# lp.marekno
marek: No. No, no. I don't help monsters. I broadcast about them. Go away.
@end

# lp.marek2
marek: You. The one who didn't eat me. Hello. What do you want? I have noodles. You can't eat noodles. Sorry.
* "A website. NIGHTWATCH. A user called Daybreak."  -> lp.find

# lp.find
marek: NIGHTWATCH. Yes. I know it. Is horrible. Is full of people who think they are in a film. I post there sometimes to make them angry.
> He types. Fast. The laptops hum. Green text scrolls past his balaclava.
marek: Daybreak... posts from same IP since 2019... a library? No. A church. St. Agatha's. The one over the club. Has a computer in the vestry for the parish newsletter.
marek: Daybreak is someone at St. Agatha's. Is not priest. Priest is ninety-one and thinks the internet is a kind of fish. Someone else. Someone who sits in the vestry at night.
{do give:forumlog; note:s_lamp|Daybreak posts from the vestry computer at St. Agatha's, above the Reliquary. It isn't the priest.}
* "And the pawnshop thread? 'Confirmed nest'?"  -> lp.pawn
* "Thank you, Marek."  -> lp.thanks

# lp.pawn
marek: Posted Tuesday. Has forty replies. People say they will "go Thursday with fire". Thursday is tonight or tomorrow, I lose track.
web(7): Gideon. Box three. Box seven. Forty years of the Ward's sleeping dead. And somebody's coming with gas.
{do flag:pawnThreat=1}
@next lp.thanks

# lp.thanks
marek: Is nothing. Is fun. I like making them angry. Go. Go to the church.
{do flag:lpChurch=1}
@end

# lp.ch arc=tenant night=3,4,5 label="Go up to the vestry at St. Agatha's." if=flag:lpChurch&!flag:lampDone prio=7
@focus tenant
> St. Agatha's is above Club Reliquary, on the corner of the Row. The bell tower, the nave, and at the back, a door marked VESTRY with a light under it at two in the morning.
> Inside: a desk, an old beige computer, a kettle, and a woman of about sixty in a cardigan and reading glasses, typing with two fingers. She has a wooden cross round her neck and a photograph taped to the side of the monitor: a young man in a graduation gown.
margaret: The church is closed. If you need the shelter, it's round the side.
> Then she looks up. She sees your face in the light of the screen. Her hand goes to the cross.
margaret: You. You're the one on the forum. The one from the multi... from the parking garage. Kowalski's. I posted you.
* "Why?"  -> lp.why
* "Who's the boy in the photograph?"  -> lp.boy
* Take the computer. Smash it.  -> lp.smash

# lp.boy
margaret: My son. Daniel. He'd be thirty-one. He went to a club on Reliquary Row in 2014 and they found him in the river three days later with no blood in him and two holes in his neck and the police said a dog.
margaret: The police said a dog. A DOG. I sat in this vestry for a year after. I started reading. I started finding people who'd lost people. I started a website.
@next lp.why

# lp.why
margaret: Because nobody else will. Because the police won't. Because there are a thousand of you living in our city and drinking our children and nobody stops you.
margaret: I don't hurt anyone. I just post. Facts. Addresses. Faces. What people do with the facts is up to them.
* "A man with a crossbow nearly killed a five-day-old, Margaret. They're sending their sons."  -> lp.sons
* "Someone's going to burn the pawnshop. There's an old man who sleeps there. He's mortal."  -> lp.gideon {if flag:pawnThreat}
* "I didn't kill your son. But I know the kind of thing that did."  -> lp.kind

# lp.sons
margaret: My name's not... how do you know my name?
* "It's on your cardigan. A name tag. From the soup kitchen."  -> lp.name

# lp.name
> She looks down. MARGARET, VOLUNTEER. She laughs, terribly.
margaret: Of course. Of course it is.
@next lp.choice

# lp.gideon
margaret: An old man. Mortal. In the pawnshop.
margaret: ...No. No, I didn't know that. They said it was a nest. They said it was only them.
pulse(6): Her heart has gone very fast. She didn't know. She's a woman who posts facts, and she's just found out she didn't have them.
@next lp.choice

# lp.kind
margaret: You know.
margaret: Then tell me. Tell me who. That's all I want. Tell me who, and I'll take the website down tomorrow.
@next lp.choice

# lp.choice
* "Take the website down tonight. In front of me."  -> lp.down
* "I'll find out who killed Daniel. If you call off the pawnshop."  -> lp.deal {do promise:daniel:Find out who killed Daniel}
* "Daybreak's done. One way or another." Close the door behind you.  -> lp.threat
? stagecraft 11 "Post this: the pawnshop's a trap. Federal agents. Anyone who goes will be arrested."  -> lp.trap | lp.trapno {id lp_trap}

# lp.down
margaret: Down. Tonight. Eleven years.
? velvet 11 "Eleven years, and it hasn't brought Daniel back. It's just made more mothers."  -> lp.downok | lp.downno {id lp_down} {mod rep:mercy}

# lp.downok
> She sits for a long time looking at the screen. Then she types something. Clicks. Types again. The forum goes white. *This site has been suspended by its administrator.*
margaret: There. There. It's gone.
margaret: ...He'd have hated it. Daniel. He'd have hated what I did with him.
{do flag:lampDone=1; flag:forumDown=1; flag:pawnThreat=0; task:s_lamp=done; xp:80:Daybreak; lean:mercy+1}
@end

# lp.downno
margaret: No. No. You'd say anything. You'd say anything to keep feeding.
@next lp.choice

# lp.deal
margaret: You'll find out. A vampire. Will find out who killed my son.
margaret: ...All right. All right. I'll post that the pawnshop's off. That I got bad information. That's true, isn't it. I got bad information.
{do flag:lampDone=1; flag:pawnThreat=0; flag:lampDeal=1; task:s_lamp=done; xp:70:Daybreak; note:s_lamp|You promised Margaret, Daybreak, that you'd find out who killed her son Daniel in 2014. A club on Reliquary Row. The river.}
@end

# lp.threat
> You close the door behind you. She hears it click. She sees your face change in the light of the monitor.
> You don't touch her. You don't need to. You stand there and let her see, for one long second, what the forum has been talking about.
> She types with shaking fingers. *Account deleted.* She doesn't look at you again.
{do flag:lampDone=1; flag:forumDown=1; flag:pawnThreat=0; task:s_lamp=done; xp:50:Daybreak; lean:mercy-1; heat+1}
@end

# lp.trap
> She thinks about it. Then she types: *URGENT: PAWNSHOP IS A FED TRAP. DO NOT GO. REPEAT DO NOT GO.* Forty replies in a minute. *THANKS L.* *GOOD LOOKING OUT.*
margaret: There. Your old man's safe. Your nest is safe. Everyone's very grateful to me.
margaret: The forum's still up. I'm still Daybreak. I'll still be here tomorrow night.
{do flag:lampDone=1; flag:pawnThreat=0; task:s_lamp=done; xp:60:Daybreak}
@end

# lp.trapno
margaret: Feds. At the pawnshop. Do you think I'm stupid?
@next lp.choice

# lp.smash
> You put your fist through the monitor. It goes with a bang and a smell of burning dust. She screams. You pull the tower out of the wall and it comes apart in your hands.
margaret: It's on the SERVER. It's not in the BOX, you... it's on a server in Ohio. You've broken a parish computer. Father Kieran's going to kill me.
{do lean:restraint-1; heat+1}
@next lp.choice

// Daniel · if you made the deal
# lpD.0 arc=lisette night=4,5 label="\"Lisette. A boy called Daniel. 2014. The river.\"" if=flag:lampDeal&!flag:danielKnown prio=6
@focus lisette
lisette: Daniel. 2014. Do you know how many boys called Daniel there were in 2014? It was a very popular name.
* Show her the forum printout. The photograph from the monitor.  -> lpD.photo {if has:forumlog}
* "A graduation photo. A mother at St. Agatha's who hasn't stopped."  -> lpD.photo

# lpD.photo
> She looks. Her face goes still in the way faces go still in Elysium when they've decided not to do something.
lisette: ...Freddie. That's one of Freddie's. Freddie liked graduates. He said they still tasted of optimism.
@gate flag:freddieDead|flag:freddieExiled ? lpD.done : lpD.alive

# lpD.done
lisette: And Freddie's... well. You know where Freddie is. You'd know better than me.
{do flag:danielKnown=1; keep:daniel}
@end

# lpD.alive
lisette: He's upstairs. The Champagne Room. Third booth. He always is.
{do flag:danielKnown=1; flag:knowFreddie=1; keep:daniel}
@end
`,'c_sq6');

/* the call to Aisling's mother from the payphone, and the threat to the pawnshop */
NL.Script.opt('phone.0','* Call Bridget Kearney, Ballyfermot, Dublin.  -> feM.call {if flag:aislingPromise&!flag:aislingCalled}','start');
NL.Script.add(String.raw`
# lpF.0 street=4 if=flag:pawnThreat&!flag:lampDone w=5
> On Reliquary Row, outside the Pawn & Coffin, four men with jerry cans and a phone held up to film. One of them is reading from the screen: "Confirmed nest. Confirmed."
* Get between them and the door.  -> lpF.between
? apex 10 "Let them see you. Just your eyes. Let them run."  -> lpF.run | lpF.fight {id lpF_ap}

# lpF.between
> You stand in the doorway of the Pawn & Coffin. Behind you, through the glass, Gideon in his cardigan, putting down his crossword, reaching for the shotgun under the counter.
> The men stop. One of them laughs. One of them doesn't.
@next lpF.fight

# lpF.run
> You let them see. The phone drops on the cobbles, still recording. Gas everywhere. They run so hard one of them loses a shoe.
> Gideon opens the door. He looks at the jerry cans and the shoe and you.
gideon: Thank you. I'd have shot one, I expect, and then there'd be paperwork.
{do flag:pawnThreat=0; rel:gideon+2; heat+1}
@end

# lpF.fight
> It's short. It's ugly. It's four mortals with gas and lighters and one of you. Nobody burns. Two of them go to St. Jude's with broken arms. One of them will tell the forum that the thing at the pawnshop is real, and is very, very fast.
{do flag:pawnThreat=0; rel:gideon+1; heat+2; vitae-1}
@end
`,'c_sq6b');

NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.aislingCalled)o.push(['Bridget Kearney','Lit a candle for her daughter in a church in Ballyfermot on the first Thursday of every month. She told the priest a stranger had rung from America to say Aisling had her coat on. She said it was the only thing anyone told her that she believed.']);
  if(f.me_visit)o.push(['Mary-Ellen Fitch','Came to the Pawn & Coffin on Sunday with a red velvet cake and a seventy-three-year-old docker. Gideon cried. Gerry cried. Mary-Ellen did a dance in the aisle between the coffins. She took her coat home. She left box seven locked.']);
  else if(f.box7Open)o.push(['Box Seven','Open, at last. Gideon keeps the photograph from Christmas 1982 on the counter now, next to the till.']);
  if(f.forumDown)o.push(['NIGHTWATCH','Went offline on a Thursday in November. Three hundred users posted "WHERE IS L??" for a month. Nobody ever found out. Margaret volunteers at the soup kitchen on Tuesdays, and on Wednesdays sits in St. Agatha\'s with a photograph and doesn\'t type anything at all.']);
  else if(f.lampDeal&&f.danielKnown)o.push(['Margaret','You told her a name. Freddie. She asked if he was still alive. You told her the truth. She took the website down the next morning.']);
  return o;});
