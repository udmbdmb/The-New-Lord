'use strict';
/* THE NEW LORD — "Petersburg, 1993": Dr. Rostova's father was taken by one of you when she was twelve. Thirty years later, the one who did it is drinking champagne in the Gilded Court. */
(function(){const X=NL.EXTRAS,S_=NL.Script;
X.freddie={n:'Freddie Carstairs',color:'#c0a0d0',role:'Of the Gilded Court',spec:{face:{long:1.0,cheek:1.2,jaw:1.0},skin:[.92,.86,.84],hair:{style:'slick',color:[.85,.75,.55]},coat:{color:[.25,.05,.2],length:.7,collar:true},shirt:[.95,.92,.9],eyes:[.5,.7,.8],eyeGlow:[.35,.05,.1]}};
NL.TASKS.s_pyotr={n:'Petersburg, 1993',xp:90,cat:'side'};
NL.ITEMS.pyotrphoto={n:'A Photograph, Leningrad 1979',type:'read',d:'A young man in a fur hat and enormous glasses, laughing in the snow outside a hospital, holding up a stethoscope like a fish he\'s caught. On the back, in Cyrillic, in a child\'s hand: "Papa, the day he qualified."'};
S_.place({id:'freddie',name:'The Champagne Room, Club Reliquary',block:'B',sub:'Upstairs at the Reliquary. A private booth. Freddie Carstairs is holding court.',if:'night>=3&night<=4&flag:mapOK&task:s_pyotr=active&flag:knowFreddie&!flag:freddieDone',node:'fy.0',min:6});
})();
NL.Script.add(String.raw`
# py.0 arc=rostova night=3,4 label="\"You look at every Kindred like you're searching for one face, Doctor.\"" if=alive:rostova&flag:hcN3|alive:rostova&rel:rostova>=3 prio=2
@focus rostova
> She's in her office on the fourth floor with the lights off, eating yoghurt with a plastic spoon. She doesn't turn round.
@gate flag:hcN3 ? py.harrow : py.trust

# py.harrow
rostova: Harrow. Of course he did. He tells everyone. It's his favorite story about me. The tragic orphan in the white coat.
@next py.tell

# py.trust
rostova: You've stopped looking at me like I'm the woman who killed your Sheriff. I've noticed. So I'll tell you. Since you're going to hear it from someone eventually.
@next py.tell

# py.tell
rostova: Pyotr Rostov. My father. Papa. He was a pediatrician at the Rauchfuss in St. Petersburg. He wore glasses like the bottom of jam jars and he laughed at his own jokes before he'd finished telling them. I was twelve. My brother Pasha was six.
rostova: In February 1993 he went out to buy cigarettes at eleven at night and didn't come back. They found him in the Fontanka three days later. Under the ice. No blood in him. Two holes in his throat that the police said were a dog.
> She puts the yoghurt down.
rostova: I became a doctor because of him. Then Pasha got sick, and I knew everything and it didn't help, and after Pasha I had nothing left but the question of what took Papa. Six years ago Harrow found me and gave me a lab, and here I am. Killing Sheriffs. Because a man went out for cigarettes.
* "Do you know who it was?"  -> py.who
* "I'm sorry."  -> py.sorry
* "Is that why you fired the lance?"  -> py.lance

# py.sorry
rostova: Don't be. You weren't born. I was twelve. I was doing my homework at the kitchen table. I waited up.
@next py.who

# py.lance
rostova: No. I fired the lance because Harrow said it would end the war. I believed him. I wanted to. I wanted someone to have a plan.
@next py.who

# py.who
rostova: No. There was a witness. A drunk on the Anichkov Bridge. He said a man in a beautiful coat with yellow hair was walking with Papa, arm in arm, laughing. Like old friends. English, he said. The man was speaking English. He sang something. A song about a girl called Daisy.
rostova: That's all I have. A yellow-haired Englishman in a beautiful coat who knew the words to *Daisy Bell*. For thirty years I have looked at every Kindred I could find for that face.
web(6): A yellow-haired Englishman. The Gilded Court travels. Séverine sends her courtiers on errands, to Paris, to Vienna, to Petersburg in the chaos of 1993, when a Kindred could do anything in that city and nobody would ever ask.
* "Let me look. I can go where you can't."  -> py.take
* "Some things are better not found, Doctor."  -> py.leave

# py.take
rostova: Why? Why would you do that for me? I killed your Sheriff.
* "Because you're still asking."  -> py.take2
* "Because you owe me, and I want you to owe me more."  -> py.take3 {do lean:pride+1}

# py.take2
> She looks at you for a long time. Then she opens a drawer and takes out a photograph, very creased, in a plastic sleeve.
rostova: Papa. The day he qualified, before I was born. You'll want to show it to people. Bring it back.
{do give:pyotrphoto; task:s_pyotr; note:s_pyotr|Dr. Rostova's father Pyotr was killed in St. Petersburg in 1993 by a yellow-haired Englishman in a beautiful coat who sang "Daisy Bell". Someone in the Gilded Court might know who.; rel:rostova+2}
@end

# py.take3
rostova: Honest. All right. Then I'll owe you. I've owed worse.
{do give:pyotrphoto; task:s_pyotr; note:s_pyotr|Dr. Rostova's father Pyotr was killed in St. Petersburg in 1993 by a yellow-haired Englishman in a beautiful coat who sang "Daisy Bell". Someone in the Gilded Court might know who.; rel:rostova+1}
@end

# py.leave
rostova: Better not found. Yes. That's what the police said. That's what my mother said. That's what I say to myself every night at four.
> She picks up the yoghurt again. She doesn't eat it.
@end

// --- the search ---
# pyA.0 arc=ashby night=3,4 label="\"Lord Ashby. Do you know the words to 'Daisy Bell'?\"" if=task:s_pyotr=active&!flag:knowFreddie prio=6
@focus ashby
ashby: *Daisy, Daisy, give me your answer do...* Of course. Every Englishman of a certain age knows it. Why?
* Show him the photograph.  -> pyA.photo {if has:pyotrphoto}
* "A yellow-haired Englishman sang it in St. Petersburg in 1993."  -> pyA.peter

# pyA.photo
> He looks at the young man in the fur hat for a long time. His face does something complicated.
ashby: Who's this?
* "A pediatrician. He went out for cigarettes in February 1993."  -> pyA.peter

# pyA.peter
ashby: ...Petersburg. 1993.
> He puts his glass down. It's the first time you've seen him put a glass down without finishing it.
ashby: Séverine sent three of us. To buy a Fabergé egg off a Choir cantor who was selling everything to pay his debts. Me, Lisette, and Freddie Carstairs.
ashby: Freddie. Yellow hair. Beautiful coats. Sings *Daisy Bell* when he's drunk, which is always. He used to go out at night "making friends". He came back one night in February singing and laughing with blood on his cuffs and said he'd met the nicest doctor.
* "Where's Freddie now?"  -> pyA.where
* "And you said nothing."  -> pyA.nothing

# pyA.nothing
ashby: What would I have said? To whom? We're the Gilded Court. We were in a city where the police were for sale by the hour. One doctor. One.
ashby: ...I'm sorry. That's not good enough, is it. I've been saying "one" for thirty years, about a lot of people. Coral. The Wraith girl. It's not good enough.
{do lean:candour+0}
@next pyA.where

# pyA.where
ashby: Upstairs. He's always upstairs. The Champagne Room. Third booth. He's there every night that he isn't somewhere worse.
ashby: Please be careful. Freddie is charming. Freddie is the most charming person I have ever met. That's what makes him so very dangerous.
{do flag:knowFreddie=1; note:s_pyotr|Freddie Carstairs, of the Gilded Court, was in Petersburg in 1993. He sings "Daisy Bell". He's in the Champagne Room upstairs at the Reliquary most nights.}
@end

# pyL.0 arc=lisette night=3,4 label="\"Lisette. Petersburg, 1993.\"" if=task:s_pyotr=active&!flag:knowFreddie prio=6
@focus lisette
lisette: Petersburg. Ugh. Cold. Dirty. Everyone was selling their grandmother's teeth. Why?
* "Who sang 'Daisy Bell'?"  -> pyL.daisy

# pyL.daisy
lisette: ...Freddie. Freddie Carstairs. He sang it the whole trip. I wanted to put a stake through his tongue.
> She looks at you narrowly.
lisette: Why are you asking about Freddie? Freddie is Séverine's favorite. Freddie is very, very protected. I'm telling you that as a friend, if I had friends.
{do flag:knowFreddie=1; note:s_pyotr|Freddie Carstairs, of the Gilded Court, sang "Daisy Bell" all through the Petersburg trip in 1993. He's Séverine's favorite. He drinks upstairs at the Reliquary.}
@end

// --- Freddie ---
# fy.0
> The Champagne Room is up a spiral staircase behind the Reliquary's bar: red velvet booths, gold mirrors, a pianist who has been dead since 1955 playing Cole Porter without any enthusiasm.
> In the third booth, with his arm along the back of the seat and a mortal girl asleep against his shoulder like a fur stole: a man with yellow hair and a coat the color of a bruise. He's singing along with the piano, very slightly flat.
freddie: *...it won't be a stylish marriage, I can't afford a carriage...* Oh, hello! It's the diablerist! Sit, sit, sit. Have a glass. Have Tamsin, she's lovely, she's had four bottles.
pulse(5): The girl's heart is slow and drunk. She's fine. She's been sipped from, not drunk. He's careful. He's been careful for a long time.
* Sit.  -> fy.sit
* "Freddie Carstairs. Petersburg. February 1993."  -> fy.direct

# fy.sit
> You sit. He pours you a glass of champagne you won't drink. He tells you three funny stories about Séverine, two about the Prince, and one about a Gilded boy in Lisbon who ate his sire's ghoul's wife, which is the same story the Magistrate tells, but funnier.
> He's wonderful company. That's the worst thing. He's the best company you've had all week.
stagecraft(6): He's watching you the whole time he's being charming. He knows you didn't come up here for the piano.
freddie: So. What do you want, darling? Everyone wants something from me. I'm a very wantable person.
@next fy.direct

# fy.direct
* Put the photograph on the table.  -> fy.photo {if has:pyotrphoto}
* "A pediatrician on the Anichkov Bridge."  -> fy.bridge

# fy.photo
> He looks down at it. The young man in the fur hat, laughing, holding a stethoscope like a fish.
> For a moment, just a moment, Freddie Carstairs' face doesn't know what to do.
freddie: ...Oh. Oh, Pyotr. Petya. Look at him. Look at his silly glasses. He was older when I knew him. The glasses were the same.
@next fy.remember

# fy.bridge
> He goes still. Then he smiles, slowly.
freddie: Oh, I remember the bridge. Petya. A pediatrician. He was lovely. He wanted to show me the Hermitage at night. He knew a guard.
@next fy.remember

# fy.remember
freddie: I didn't mean to, you know. I want you to know that. I liked him so much. We sang all the way along the Fontanka. He taught me a Russian one, I taught him *Daisy*. And then I got hungry, and he was right there, and he was so warm, and I just... kept going. It was the Nineties. Everyone kept going.
freddie: I cried. I cried for a week. I bought a fur hat, in his memory. I still have it.
* "His daughter has spent thirty years looking for you."  -> fy.wife
* "You're going to come with me."  -> fy.come
* "Do you ever think about him?"  -> fy.think

# fy.think
freddie: Every February. I light a candle. I sing the Russian one, badly. I can't remember all the words any more. I can only remember the tune.
> He hums it. It's beautiful. He hums it in a voice like warm milk, and you want, for a horrible moment, to forgive him.
@next fy.wife

# fy.wife
freddie: His daughter. Oh. He mentioned a daughter. Twelve. Very serious. Going to be a doctor too. He said she never laughed at his jokes, which was how he knew she'd be a good one.
freddie: She's here, isn't she? In the Ward. Is she the... oh, my GOD. Is SHE Harrow's doctor? The little girl? Is she the one who fired the lance at Absalom? Oh, that's PERFECT. That's Greek. Séverine will DIE.
> He's delighted. He's genuinely, childishly delighted.
@next fy.choice

# fy.come
freddie: Come with you? Where? To Elena? Darling, she'll kill me. She'll put a stake through my heart and a scalpel through everything else.
freddie: ...Which, I suppose, is the point.
@next fy.choice

# fy.choice
tenant: Child. Whatever you do now, do it knowing what he is. He's not wicked. He's worse. He's thoughtless. He'll be thoughtless for a thousand years if somebody lets him.
* "Come downstairs. Face her. Tell her what you told me."  -> fy.face
* "I'll tell her. You'll be gone by morning, or I'll tell Séverine you've been talking to Harrow."  -> fy.exile
* Kill him. Here, in his booth.  -> fy.kill {blood}
* "Give me the fur hat. And forget I came."  -> fy.hat
* "Get up. We're going to see the Magistrate."  -> fy.magistrate {if flag:petitionDone|night:4}

# fy.face
freddie: Face her. Oh, darling. You're very sweet.
? velvet 13 "You cried for a week. Cry in front of her. It's the only thing you've got that's worth anything."  -> fy.faceok | fy.faceno {id fy_face} {mod like:freddie}
? apex 11 "That wasn't a request, Freddie."  -> fy.faceok | fy.faceno {id fy_apex} {red}

# fy.faceok
> He looks at you for a long time. Then he gently moves the sleeping girl off his shoulder onto a velvet cushion, and stands up, and straightens his bruise-colored coat.
freddie: Very well. Very well. I've always wanted to do something brave. I've never once managed it.
{do flag:freddieFace=1; flag:freddieDone=1}
@next fy.walk

# fy.faceno
freddie: No. No, I don't think so. I think I'll stay here with Tamsin and the piano, and you'll go and tell her, and she'll come for me with a lance, and that'll be that. That's more poetic anyway.
{do flag:freddieDone=1; flag:freddieWaits=1}
@next fy.tell

# fy.walk
> You walk him through the Ward at three in the morning: down the spiral stair, through the club, out past Tiny, along Reliquary Row, across the parking lot of St. Jude's, up in the staff lift. He sings *Daisy Bell* under his breath the whole way. He's terrified. He's never once in four hundred years been terrified.
> Fourth floor. Her office. The light under the door.
@next fy.meet

# fy.meet
> She opens the door. She sees you. She sees him. She sees the yellow hair and the coat.
> You watch her know. You watch thirty years arrive in her face all at once.
rostova: ...
freddie: Dr. Rostova. My name is Frederick Carstairs. In February 1993 I walked with your father along the Fontanka and I killed him. I was hungry and he was kind and I didn't stop. I'm sorry. I have been sorry for thirty years. It has done him no good whatsoever.
> She doesn't say anything. She goes back into her office. She comes out again with something in her hand. A steel cylinder with a crank. A small, hospital version of the thing that killed the Sheriff.
* Step between them.  -> fy.between
* Let her.  -> fy.let
* "Elena. He came. He came on his own legs. Does that count for anything?"  -> fy.count

# fy.between
rostova: Get out of the way.
* "No. Not like this. Not you."  -> fy.betno
* Step aside.  -> fy.let

# fy.betno
> She holds the cylinder up to your chest. Her hand is perfectly steady. Her face is wet.
rostova: You think I'll stop. Because I stopped on Monday? I didn't stop on Monday. I fired. I always fire.
* "Then fire."  -> fy.betfire
? velvet 12 "Your father wouldn't have. He was a pediatrician. He'd have given this one a lollipop and a lecture."  -> fy.lolly | fy.betfire {id fy_lolly}

# fy.betfire
> She doesn't. Her hand drops. The cylinder hangs from her fingers like a handbag.
rostova: ...I can't. I can't. Not with you there. Not with you looking at me like that.
@next fy.count

# fy.lolly
> And she laughs. Out of nowhere. A terrible, cracked, astonished laugh, the first you've heard from her all week.
rostova: A lollipop. Yes. And a lecture about sugar. He kept them in his coat for the children. For me. He'd have given this... *creature*... a lollipop.
> The cylinder goes down on the floor of the corridor. She sits down next to it, with her back to the wall, and puts her face in her hands.
{do rel:rostova+2; flag:freddieSpared=1}
@next fy.after

# fy.count
rostova: Count. You want me to count.
> She looks at Freddie, who is standing in a hospital corridor in a coat the color of a bruise with his hands clasped like a schoolboy.
rostova: He came. Yes. He came on his own legs, which is more than Papa did.
rostova: Get out. Leave the city. Leave tonight. If I ever see your face again, I won't need a lance. I'll use my hands.
freddie: Yes. Yes. Of course. Thank you. Thank you, Doctor.
{do flag:freddieExiled=1; flag:freddieSpared=1; rel:rostova+1}
@next fy.after

# fy.let
> You step back.
> It's very quick. A whine like a kettle, a white line in the air, a smell like a struck match. Freddie Carstairs doesn't scream. He looks surprised, mostly. He looks down at the hole in his chest as if he's spilled something on his good coat.
freddie: ...Oh. Oh, Petya.
> And then there's ash on the lino, and a bruise-colored coat, and a fur hat in its pocket, and Dr. Elena Rostova standing over it with a steel cylinder, very still, in the light from her office door.
{do flag:freddieDead=1; flag:rostovaRevenge=1; lean:mercy-1; heat+1}
@next fy.after

# fy.after
> Much later, you sit with her on the floor of the corridor on the fourth floor. Neither of you says anything for a long time. A porter goes past with a trolley and doesn't look.
rostova: Thirty years. I thought it would feel like something.
rostova: It feels like four in the morning. It always feels like four in the morning.
@gate flag:freddieDead ? fy.afterdead : fy.afterlive

# fy.afterdead
rostova: I've killed two of you now. A Sheriff and a fool. Neither of them was the thing I was looking for. There was never a thing. There was a man who went out for cigarettes and a man who was hungry.
* "What will you do now?"  -> fy.afternow

# fy.afterlive
rostova: He's going to go on being charming. In Lisbon, or Vienna. For a thousand years. I let him.
rostova: Papa would have. That's the only reason. Papa would have let him go, and been insufferable about it at dinner for a month.
* "What will you do now?"  -> fy.afternow

# fy.afternow
rostova: Friday. Then I'll see.
> She takes the photograph back from you, if you still have it. She looks at it for a long time and puts it in the pocket of her white coat, over her heart.
{do take:pyotrphoto; task:s_pyotr=done; xp:90:Petersburg, 1993; rel:rostova+2; flag:pyotrDone=1}
@end

# fy.exile
freddie: Gone by morning. Or Séverine hears I've been chatting with LANTERN. Which I haven't, which doesn't matter, because she'll believe you.
freddie: ...You're quite frightening, you know. Absalom never had the knack. He was too good at being liked.
freddie: Gone by morning. Lisbon, I think. I've always liked Lisbon. They have a Magistrate there with no sense of humour.
{do flag:freddieExiled=1; flag:freddieDone=1}
@next fy.tell

# fy.tell
> You go to the fourth floor of St. Jude's and tell her. A name. A coat. A song. Where he drinks, or where he's gone.
@gate flag:freddieExiled ? fy.tellgone : fy.tellstays

# fy.tellgone
rostova: Lisbon. He's gone to Lisbon. He gets to go to Lisbon.
rostova: ...Good. Good. I don't have to decide anything. I'm so tired of deciding things.
{do take:pyotrphoto; task:s_pyotr=done; xp:70:Petersburg, 1993; rel:rostova+1; flag:pyotrDone=1}
@end

# fy.tellstays
rostova: Upstairs at the Reliquary. Third booth. Every night.
> She takes off her white coat and folds it over the back of her chair. She opens a drawer and takes out a steel cylinder with a crank.
rostova: Thank you. Go home. You don't want to see what I do next.
{do take:pyotrphoto; task:s_pyotr=done; xp:70:Petersburg, 1993; flag:pyotrDone=1; flag:rostovaHunts=1}
@end

# fy.kill
> He sees it in your face before you move. He doesn't run. He puts his glass down, carefully, so it won't spill on Tamsin.
freddie: Ah. Yes. I suppose that's fair.
> It's very quick. He's old, but he's soft, and he doesn't fight. He hums the Russian song the whole time, very quietly, until he can't.
> Afterwards, the pianist is still playing Cole Porter. Nobody in the Champagne Room has looked up. In the pocket of the bruise-colored coat: a fur hat, very old, very carefully kept.
{do kill; flag:freddieDead=1; flag:freddieDone=1; feed:4:Sanguine:Freddie Carstairs:kindred; lean:mercy-1; heat+1; flag:sevAngryFreddie=1}
tenant: Séverine's favorite. She will know by dawn. She'll know whose hand it was.
@next fy.tell2

# fy.tell2
> You take the fur hat to the fourth floor of St. Jude's and put it on her desk.
rostova: What's this?
* Tell her.  -> fy.tell2a

# fy.tell2a
> She holds the hat in her lap. She doesn't cry. She smells it, once, the way you'd smell a letter.
rostova: You did it for me. You took it off me. The deciding.
rostova: ...I don't know whether to thank you or hate you. I think I'll do both. For a long time.
{do take:pyotrphoto; task:s_pyotr=done; xp:80:Petersburg, 1993; rel:rostova+1; flag:pyotrDone=1}
@end

# fy.hat
freddie: The hat? Petya's... my hat? The one I bought?
freddie: ...Yes. All right. Take it. I've been carrying it for thirty years. It's very heavy for a hat.
> He takes it out of his coat pocket. Grey fur, moth-bitten, carefully mended.
freddie: And you'll forget. You'll forget you came up here. Darling, you're an angel.
* Take it to Rostova, and tell her everything.  -> fy.hattell
* Take it to Rostova, and tell her you found it in Petersburg.  -> fy.hatlie {do lean:candour-1}

# fy.hattell
{do flag:freddieDone=1}
@next fy.tell

# fy.hatlie
> You put the fur hat on her desk on the fourth floor. You tell her a story: an old contact in Petersburg, a box of effects, a name that leads nowhere, a man who died in 1998 in a fire. A dead end. A full stop.
> She believes you. She wants to. She holds the hat in her lap and thanks you, and you watch thirty years leave her shoulders, and you know it's a lie, and you'd do it again.
{do take:pyotrphoto; task:s_pyotr=done; xp:60:Petersburg, 1993; rel:rostova+2; flag:pyotrDone=1; flag:freddieDone=1; flag:pyotrLie=1}
@end

# fy.magistrate
freddie: The Magistrate. Ambrose. For a mortal. In 1993. In Russia.
freddie: Darling, there's no law against it. You know that. Mortals aren't covered. Ambrose would laugh. Well, Ambrose doesn't laugh. Ambrose would do the thing he does instead of laughing.
tenant: He's right. The old law doesn't care for them. It never did. That's the thing I spent forty years trying to change, and never did.
@next fy.choice
`,'c_pyotr');

NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.freddieDead&&f.rostovaRevenge)o.push(['Freddie Carstairs','Ash on the lino of the fourth floor at St. Jude\'s. A porter swept him up in the morning and put him in the clinical waste. The fur hat is in Elena Rostova\'s desk drawer.']);
  else if(f.freddieDead)o.push(['Freddie Carstairs','Ash in a velvet booth in the Champagne Room. The pianist played Cole Porter over him until dawn.']);
  else if(f.freddieExiled)o.push(['Freddie Carstairs','Lisbon. Still charming. Every February he lights a candle and hums a Russian song he can\'t remember the words to.']);
  else if(f.freddieSpared)o.push(['Freddie Carstairs','Was given a lollipop and a lecture by a woman in a hospital corridor, in a sense. He left the city in a taxi. He sends Dr. Rostova a postcard every February. She doesn\'t read them. She doesn\'t throw them away.']);
  if(f.pyotrLie)o.push(['A fur hat','Sits on a shelf in Dr. Rostova\'s office, above the light box, next to a photograph of a man in jam-jar glasses. She believes he was killed by a man who died in a fire in 1998. She sleeps better than she has in thirty years.']);
  return o;});
