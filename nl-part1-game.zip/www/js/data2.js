'use strict';
/* THE NEW LORD — campaign data: clans, scars, wardrobe, ideologies, cast, quests (supersedes the prologue tables in data.js) */
(function(){
const NL=window.NL;

/* ---------- the ten clans: three abilities each, every one with a Tier-2 mutation ---------- */
const CLANS={
  sovereign:{name:'The Sovereign',ep:'Old blood. Older debts.',d:'Tyrants in tailored coats. Their blood remembers kingdoms and expects to be obeyed. Absalom Vane was one of them. Now, perhaps, so are you.',
    mods:{apex:1,pedigree:1,gutter:-1},curse:'Rarefied Palate. Rats, blood bags and the gutter-poor make you vomit: −2 Mask, no Vitae.',eye:[.9,.68,.22],glow:[.9,.55,.1],aura:'#d9a441',
    ab:{kneel:{n:'Kneel',c:1,d:'Speak one word, and a mortal\'s body obeys it.',t2:{n:'Royal Decree',d:'Command up to three at once, or turn a target on their ally.'}},
        fog:{n:'Crown of Fog',c:1,d:'Erase the last fifteen minutes of a mortal\'s memory.',t2:{n:'Tabula Rasa',d:'Write a false memory into the space you cleared.'}},
        blueblood:{n:'Blue Blood',c:1,d:'Feel the pecking order and the hidden debts in a room.',t2:{n:'Kingmaker',d:'Call in a vampire\'s secret debt and make them pay it to you.'}}}},
  wraiths:{name:'The Wraiths',ep:'The dead who kept walking.',d:'Grey, gaunt and patient. The city looks through them, and they have learned to like it. Mother Soot is the oldest of them in the Ward.',
    mods:{echo:1,gutter:1,velvet:-1},curse:'Walking Cadaver. Bright light shows what you are: Stagecraft fails and mortals recoil, unless your face is covered.',eye:[.75,.78,.85],glow:[.5,.55,.7],aura:'#9aa3b8',grey:true,
    ab:{veil:{n:'Veil of Dust',c:1,d:'Stand still in shadow and stop being seen.',t2:{n:'Phantom Walk',d:'Stay unseen while you move, even across lit floors.'}},
        carrion:{n:'Carrion Whisper',c:1,d:'Question rats and insects about what they saw.',t2:{n:'Swarm Host',d:'Call up a tide of rats to distract, or to eat the evidence.'}},
        mark:{n:'Unseen Mark',c:1,d:'Read or leave the psychic graffiti of the Wraiths.',t2:{n:'Panopticon',d:'Listen through Mother Soot\'s network into the next room.'}}}},
  glass:{name:'The Glass',ep:'Seers who see too much.',d:'Their minds are windows, and most of them are cracked. They hear the thoughts people are loudest about not saying.',
    mods:{osmosis:1,web:1,rigor:-1},curse:'Shattered Mind. Fail a red check and one voice gets far too loud for an hour.',eye:[.6,.85,1],glow:[.45,.75,1],aura:'#9fd3ff',
    ab:{dejavu:{n:'Déjà Vu',c:1,d:'Live a failed moment, then rewind it. Once per scene.',t2:{n:'Cassandra\'s Loop',d:'See where every choice leads before you make one.'}},
        splinter:{n:'Splinter',c:1,d:'Drive a sudden phobia or obsession into someone\'s head.',t2:{n:'Glass Delusion',d:'Crack them completely: they flee, or confess everything.'}},
        coldread:{n:'Cold Reading',c:1,d:'Hear a person\'s loudest unvoiced regret.',t2:{n:'Soul Mirror',d:'Make them live through your diablerie. Even Elders reel.'}}}},
  choir:{name:'The Choir',ep:'Blood sings.',d:'Singers, players and patrons of the night\'s art. Their voices are instruments and their attention is a drug. Lady Séverine leads them in the Ward.',
    mods:{velvet:1,nostalgia:1,autopsy:-1},curse:'Aesthetic Rapture. Music, neon and art drag at you: −2 Nocturne until you stop and admire it.',eye:[1,.3,.45],glow:[1,.2,.35],aura:'#ff6a8a',
    ab:{siren:{n:'Siren\'s Pitch',c:1,d:'Your voice makes someone answer one question truthfully.',t2:{n:'Aria of Glass',d:'Shatter every glass and bulb in the room and deafen the hostile.'}},
        touch:{n:'Touch of Velvet',c:1,d:'Read the emotional residue on an object or a stain.',t2:{n:'Symphony of Scars',d:'Leave a hypnotic compulsion in an object for the next hand that holds it.'}},
        encore:{n:'Encore',c:1,d:'Lock someone into repeating their last five seconds.',t2:{n:'Danse Macabre',d:'Play an entranced body like a puppet through a whole conversation.'}}}},
  butchers:{name:'The Butchers',ep:'Surgeons of the self.',d:'They treat flesh like clay, their own included. Malakor of the Red Syndicate is one; the Ward\'s chop-shops run on their skill.',
    mods:{abattoir:1,rigor:1,pulse:-1},curse:'Uncanny Valley. Talk to a mortal for too long and they feel it: −1 Masquerade after five exchanges.',eye:[.62,.06,.06],glow:[.55,.03,.03],aura:'#b23a3a',scars:true,
    ab:{bonekey:{n:'Bone-Key',c:1,d:'Dislocate your own fingers and ribs: pick a lock, slip a vent.',t2:{n:'Ribcage Arsenal',d:'Bone spurs through the knuckles. +3 Frenzy and Abattoir in a fight.'}},
        borrowed:{n:'Borrowed Face',c:1,d:'Wear the face of the last mortal you fed on.',t2:{n:'Flesh-Sculpt',d:'Rework someone else\'s face for good: heal it, or erase it.'}},
        nerve:{n:'Nerve-Pinch',c:1,d:'Numb, paralyse or wake a limb with one touch.',t2:{n:'Autonomic Override',d:'Stop or restart a mortal\'s heart by touch.'}}}},
  hounds:{name:'The Hounds',ep:'Hunters of hunters.',d:'Fast, loyal and never quite off the leash. The Court sends a Hound when it wants something found. Valko is Vane\'s.',
    mods:{parasite:1,frenzy:1,pedigree:-1},curse:'Hair-Trigger Beast. You go Hungry at 4 Vitae, not 3.',eye:[.95,.62,.12],glow:[.95,.5,.05],aura:'#e0802a',
    ab:{scent:{n:'Blood-Scent',c:1,d:'See a scent trail, glowing, across the city.',t2:{n:'Predator\'s Pulse',d:'See heartbeats and sightlines through brick.'}},
        claws:{n:'Iron Claws',c:1,d:'Tear open padlocks, grates and steel doors.',t2:{n:'Jugular Leap',d:'A ten-metre lunge. Most things do not get up.'}},
        pack:{n:'Eye of the Pack',c:1,d:'See in perfect dark. Traps light up.',t2:{n:'Alpha Howl',d:'Call the street dogs to hold a door or run someone down.'}}}},
  alchemists:{name:'The Alchemists',ep:'Every drop has a price.',d:'Contract-makers and blood-chemists. Their word is a physical law; their curse is that it binds them too.',
    mods:{autopsy:1,osmosis:1,frenzy:-1},curse:'Contract Bound. Break a promise you made in dialogue and your blood boils: −3 Vitae.',eye:[.35,.85,.55],glow:[.2,.8,.45],aura:'#5fd38f',
    ab:{boil:{n:'Boil the Vein',c:1,d:'Heat someone\'s blood until they would say anything.',t2:{n:'Crucible Rupture',d:'Detonate spilled blood into a flash of fire.'}},
        ward:{n:'Crimson Ward',c:1,d:'Seal a door or a box with a lock of your own blood.',t2:{n:'Sanguine Glyph',d:'A doorway that drains any vampire who crosses it, and calls your phone.'}},
        vintage:{n:'Taste the Vintage',c:1,d:'A drop of blood tells you when, how and what was in it.',t2:{n:'Distill Vitae',d:'Render ash or a bag into a +2 Vitae elixir.'}}}},
  hollow:{name:'The Hollow',ep:'Where the light doesn\'t go.',d:'Shadows that learned to walk. Cameras and mirrors cannot find them, and nobody who has seen one in a mirror forgets it.',
    mods:{stagecraft:1,echo:1,nostalgia:-1},curse:'Zero Reflection. No mirror, no camera. A mortal who sees you missing from a mirror panics: −2 Mask, +1 Heat.',eye:[.5,.42,.9],glow:[.4,.3,.85],aura:'#8a78e8',ghost:true,
    ab:{shadowstep:{n:'Shadow-Step',c:1,d:'Go into one patch of dark and out of another, past whatever is between.',t2:{n:'Abyssal Pocket',d:'Fold a body or evidence into your own shadow.'}},
        snuff:{n:'Snuff',c:1,d:'Kill every light and electronic in the room.',t2:{n:'Blackout Curtain',d:'Black out a whole city block for ten minutes.'}},
        strings:{n:'Puppet Strings',c:1,d:'Pin someone\'s shadow to the floor. They stop.',t2:{n:'Shadow Strangle',d:'Choke or disarm someone across the room by their shadow.'}}}},
  rot:{name:'The Rot',ep:'Kings of the sewer.',d:'Grey-skinned, slow and very hard to kill twice. The dead talk to them, and they listen.',
    mods:{rigor:1,autopsy:1,stagecraft:-1},curse:'Graveyard Chill. Healthy mortal blood gives half. Corpses, bags and the sick give full.',eye:[.7,.8,.25],glow:[.55,.7,.12],aura:'#8aa63a',grey:true,
    ab:{corpse:{n:'Corpse-Speak',c:1,d:'Ask a dead body\'s nerves three questions.',t2:{n:'Lazarus Twitch',d:'Walk a corpse for sixty seconds.'}},
        miasma:{n:'Miasma',c:1,d:'Breathe out spores that calm and dull mortals.',t2:{n:'Plague Cloud',d:'A cloud that eats locks, blinds guards and rots evidence.'}},
        stillheart:{n:'Stillheart',c:1,d:'Drop every vital sign to nothing. Pass for a dead thing.',t2:{n:'Grave Liquefaction',d:'Slide through a floor drain as sludge.'}}}},
  stray:{name:'The Stray',ep:'Clanless and hungry.',d:'Mongrels who owe nothing to anyone. No Court protects them. No Court has to.',
    mods:{gutter:1,sundial:1,pedigree:-1},curse:'Bad Blood. Elders can smell it: −2 to every social check inside Elysium.',eye:[.85,.55,.15],glow:[.8,.45,.1],aura:'#d0915a',mismatch:[.35,.75,.35],ratsOk:true,
    ab:{scavenger:{n:'Scavenger\'s Gut',c:1,d:'Rats and spoiled blood feed you fully, and toughen you (+1 Rigor Mortis tonight).',t2:{n:'Chameleon Vitae',d:'Taste a vampire\'s blood or ash and borrow one of their gifts.'}},
        spark:{n:'Spark-Jump',c:1,d:'Short out keypads, phones and cameras with a touch.',t2:{n:'Neon Surge',d:'Drink a transformer dry: heal, or stun a room.'}},
        badluck:{n:'Bad Luck Charm',c:1,d:'Make an enemy fumble the one thing they\'re trying to do.',t2:{n:'Murphy\'s Law',d:'Jam the guns, burst the pipes, crash the car.'}}}}
};
const CLAN_ORDER=['sovereign','wraiths','glass','choir','butchers','hounds','alchemists','hollow','rot','stray'];
const ABIL={};CLAN_ORDER.forEach(c=>{Object.keys(CLANS[c].ab).forEach(a=>{ABIL[a]=Object.assign({clan:c,id:a},CLANS[c].ab[a]);});});

/* ---------- mortal scars (backgrounds) ---------- */
const PASTS={
  paramedic:{name:'Night-Shift Paramedic',skill:{abattoir:1},item:'keycard',perk:'St. Jude\'s Triage Keycard. Medical dialogue.',mem:'Diesel and disinfectant. A gurney\'s wheels on wet asphalt. Somebody\'s pulse under two of your fingers, slowing, and your voice saying "stay with me" like a prayer you didn\'t believe.'},
  litigator:{name:'Disgraced Litigator',skill:{pedigree:1},cash:200,perk:'$200 cash. Warrant and contract loopholes.',mem:'Mahogany, subpoenas, the smell of a courtroom in August. A bar card they took away, and the exact wording of the reason.'},
  promoter:{name:'Underground Club Promoter',skill:{velvet:1},item:'aviators',perk:'Tinted aviators. VIP recognition at Club Reliquary.',mem:'Wristbands, guest lists, a phone that never stopped buzzing. Bass through the soles of your shoes and a door you could open for anyone, for a price.'},
  clerk:{name:'Ex-Precinct 9 Evidence Clerk',skill:{web:1},item:'tape',perk:'Evidence tape. You know Detective Miller.',mem:'A cage of numbered boxes in a precinct basement. Chain-of-custody forms in triplicate, and a detective who brought you coffee every Thursday and never once got your order wrong.'}
};

/* ---------- wardrobe: four slots ---------- */
const SLOTS=['face','torso','hands','pocket'];
const SLOT_NAMES={face:'Face',torso:'Torso',hands:'Hands',pocket:'Pocket'};
const ITEMS={
  // face
  aviators:{n:'Tinted Designer Aviators',slot:'face',mods:{stagecraft:1,echo:-1},d:'Gold wire and smoke-grey lenses. Hide glowing eyes and stop bright light from showing what you are.',sp:'Negates bright-light penalties. A Wraith\'s face stays covered.',look:{glasses:{type:'sun'}},cover:true},
  triagemask:{n:'Surgical Triage Mask',slot:'face',mods:{autopsy:1},d:'Pale blue, pleated, elastic behind the ears. In a hospital it makes you invisible. Everywhere else it makes you a nurse.',sp:'Covers a Wraith\'s face in public.',look:{mask:'surgical'},cover:true},
  porcelain:{n:'Porcelain Court Half-Mask',slot:'face',mods:{pedigree:2,gutter:-2},d:'White glaze, a gold seam where it was mended. Lady Séverine\'s gift, and her leash.',sp:'+2 Pedigree in Elysium. The street will laugh at you.',look:{mask:'porcelain'},cover:true},
  uvgoggles:{n:'Welder\'s UV Goggles',slot:'face',mods:{sundial:2,velvet:-1},d:'Black glass in rubber cups. The world goes green and safe.',sp:'Protects you from UV lances and flashbangs.',look:{glasses:{type:'sun'}}},
  widebrim:{n:'Sheriff\'s Hat',slot:'face',mods:{pedigree:1,echo:1,nostalgia:-1},d:'Wide-brimmed black felt with a small, neat hole through the brim. It fits. It should not fit.',sp:'Hides your eyes from anyone taller than you. Court vampires know whose it was.',look:{hat:{type:'widebrim',color:[.12,.1,.1]}}},
  glasses:{n:'Margo\'s Reading Glasses',slot:'face',mods:{autopsy:1,web:1,apex:-1},d:'Tortoiseshell, plus two-and-a-half diopters. Everything up close becomes evidence.',look:{glasses:{type:'reading'}}},
  paperhat:{n:'Kowalski\'s Paper Hat',slot:'face',mods:{stagecraft:1,apex:-1},d:'A folded paper cap with a red stripe. Nobody fears anyone in a paper hat.',sp:'Lowers a mortal\'s suspicion.',look:{hat:{type:'paper'}}},
  // torso
  greatcoat:{n:'Sheriff\'s Greatcoat',slot:'torso',mods:{apex:1,pedigree:1,stagecraft:-1},d:'Charcoal wool, Viennese tailoring, ash in every seam. The sleeves still remember someone else\'s arms.',sp:'Court vampires recognize it. Mortals notice the ash.',look:{coat:{color:[.16,.16,.2],length:.58,collar:true}}},
  apron:{n:'Bloodstained Butcher Apron',slot:'torso',mods:{apex:1,stagecraft:-2},d:'Kowalski\'s night-counter apron, stiff with blood that isn\'t all pig. Wash it in the back-room sink and it becomes a costume instead of a confession.',sp:'Wash it (back-room sink) to turn it into a Damp Apron.',look:{apron:{color:[.78,.76,.72],stain:[.45,.05,.08]}}},
  dampapron:{n:'Damp Apron',slot:'torso',mods:{stagecraft:1,gutter:1},d:'Still wet, faintly pink at the seams. You look like you work here, because tonight you do.',sp:'"I just work here." Mortals expect staff to wear one.',look:{apron:{color:[.82,.8,.77]}}},
  dinnerjacket:{n:'Velvet Elysium Dinner Jacket',slot:'torso',mods:{velvet:1,pedigree:1,rigor:-1},d:'Midnight velvet, satin lapels, a lining the color of an artery. Somebody died in it in 1981, beautifully.',sp:'Court dress. Opens doors in Elysium.',look:{coat:{color:[.12,.06,.16],length:.18,collar:true}}},
  kevlar:{n:'Kevlar Courier Trenchcoat',slot:'torso',mods:{rigor:2,echo:-1},d:'Heavy, olive, bike-messenger ugly. There are ceramic plates sewn into the lining.',sp:'Absorbs one gunshot a night.',look:{coat:{color:[.25,.27,.18],length:.62,collar:true}}},
  smock:{n:'Hazmat Morgue Smock',slot:'torso',mods:{abattoir:1,autopsy:1},d:'Yellow, rubberised, wipe-clean. Blood doesn\'t stick to it and nobody looks twice at it.',sp:'Bloodstains no longer threaten the Masquerade.',look:{apron:{color:[.85,.75,.2]}}},
  // hands
  latex:{n:'Latex Forensics Gloves',slot:'hands',mods:{autopsy:1},d:'Powder-free, a box of a hundred. No fingerprints, no DNA, no cold hands in a handshake.',sp:'Touching a crime scene no longer raises Heat.',look:{gloves:[.75,.82,.9]}},
  knuckles:{n:'Weighted Brass Knuckles',slot:'hands',mods:{frenzy:2,pulse:-1},d:'Rookery-gang brass with a lead core. They weigh what an argument weighs.',look:{gloves:[.6,.5,.25]}},
  signet:{n:'Signet Ring of House Vane',slot:'hands',mods:{apex:2,nostalgia:-1},d:'Heavy gold. A crane on one leg over the motto NEC SOMNUS, "nor sleep". It was inside the ash.',sp:'+2 Apex with Court vampires. The Tenant speaks far more often. Valko can smell it.'},
  lineman:{n:'Insulated Lineman Gloves',slot:'hands',mods:{abattoir:1},d:'Orange rubber to the elbow, rated for twenty thousand volts.',sp:'Lets you touch high-voltage boxes safely.',look:{gloves:[.85,.45,.1]}},
  // pocket
  burner:{n:'Sheriff Vane\'s Burner Phone',type:'tool',d:'A battered flip phone. One contact, "S.", and a lot of missed calls.',sp:'Receives texts. Read it from the inventory.'},
  ashvial:{n:'Vial of Ancient Ash',slot:'pocket',mods:{osmosis:1},d:'A spice jar from the back room, filled with Absalom Vane. It is warm.',sp:'Swallow it once in an emergency: +2 Vitae, +20% Diablerie Sync.',use:'Swallow'},
  shield:{n:'Precinct 9 Gold Shield',slot:'pocket',mods:{stagecraft:2},d:'A detective\'s badge in a worn leather wallet. Not yours.',sp:'+2 Stagecraft when bluffing guards and cops.'},
  walkman:{n:'Cassette Walkman ("89 BPM")',slot:'pocket',mods:{rigor:1},d:'Yellow plastic, foam headphones, a tape labelled 89 BPM in a child\'s handwriting. It plays a heartbeat.',sp:'Hunger penalties are halved.'},
  watch:{n:'Stopped Pocket Watch',slot:'pocket',mods:{sundial:1},d:'Silver, engraved "A.V. 1789". The hands stopped at 4:51.',sp:'Whatever happened in the freezer finished at 4:51 a.m.'},
  lighter:{n:'Brass Lighter',slot:'pocket',mods:{apex:1,sundial:-1},d:'Brass, engraved A.V., faintly warm. You would very much like to stop thinking about fire.',sp:'Fire. Burns evidence. Costs Mask to use.'},
  knife:{n:'Boning Knife',slot:'pocket',mods:{abattoir:1,frenzy:1,velvet:-1},d:'Six inches of flexible steel. It wants you to be the kind of person who carries it.',sp:'Unlocks threatening options.'},
  // consumables, tools, evidence
  bloodbag:{n:'Blood Bag',type:'use',d:'One pint, vacuum-sealed. The label says PORK STOCK. The handwriting underneath says O-NEG.',sp:'Drink: +3 Vitae.',use:'Drink'},
  coffee:{n:'Lucky Mart Coffee',type:'use',d:'Styrofoam, lid, sleeve. You cannot drink it. You can hold it, and smell it, and remember.',sp:'Hold it: +1 Mask. Encore Mortal loves this.',use:'Hold it'},
  thermometer:{n:'Meat Thermometer',type:'tool',d:'A steel probe thermometer. Long, thin, and exactly the shape of a door latch\'s worst nightmare.'},
  cuffkey:{n:'Handcuff Key',type:'tool',d:'Small, silver-plated, still warm from the ash.'},
  backkey:{n:'Padlock Key',type:'tool',d:'On a plastic fob: BACK · DON\'T LOSE (MARGO).'},
  keycard:{n:'St. Jude\'s Triage Keycard',type:'tool',d:'Your old staff card. The photo is you, alive, squinting. It still opens the clinic side door.'},
  tape:{n:'Master Evidence Tape Roll',type:'tool',d:'Red-and-white EVIDENCE · DO NOT TAMPER. Anything you wrap in it becomes official.'},
  notebook:{n:'Leo\'s Joke Notebook',type:'read',d:'Spiral-bound, grease-stained. Title page: TIGHT FIVE (WORKING) · L. PRUITT.',read:['"My mom says I have a face for radio. My radio teacher says I have a voice for butchery. So here I am."','"Working nights at a 24-hour butcher. Who buys brisket at 3 a.m.? Insomniacs, cops, and one guy I am ninety percent sure is a vampire. He tips well though."','"I asked my boss why we\'re open 24 hours. She said, \'Meat doesn\'t sleep, Leonard.\' Neither does she. I\'m getting worried."','Crossed out, three times: "What do you call a vampire butcher?" No punchline.']},
  ledger:{n:'Kowalski\'s Ledger',type:'read',d:'Oxblood leather. Columns of dates, pints and prices, and initials where names should be.'},
  lockerkey:{n:'Morgue Locker Key #14',type:'tool',d:'A flat brass key on a twist of red string, sticky with blood-wax. You gave it away on Monday morning. Now you have it back.'},
  vessel:{n:'The Sun-Vessel',type:'relic',d:'Brass and quartz, the length of a forearm, warm as a living wrist. Inside, something the color of noon moves slowly, like honey.',sp:'Carrying it: −1 Sundial, +2 Apex with vampires.'},
  casefile:{n:'Miller\'s Case File',type:'read',d:'A manila folder, coffee-ringed: MARROW WARD · MISSING · 7 (8?).'},
  bug:{n:'Bone Microphone',type:'tool',d:'A sliver of carved vertebra wired to a hearing-aid battery. Mother Soot\'s ears.'},
  polaroids:{n:'The 1978 Polaroids',type:'read',d:'Six Polaroids from Gideon\'s river safe. Lady Séverine, younger in a way that has nothing to do with age, in a room that is not supposed to exist.'},
  passport:{n:'Forged Passport',type:'tool',d:'Gideon\'s work. A good likeness of Leo Pruitt under a different name.'},
  invoice:{n:'UV Lance Invoice',type:'read',d:'Red Syndicate letterhead. "One (1) surgical UV lance, custom. Paid in full. Collected Sunday 11 PM." The buyer\'s line reads only: R.'},
  dialysis:{n:'Dialysis Kit',type:'tool',d:'Tubing, a filter cartridge, saline. Stolen, with love.'},
  vegancard:{n:'Hematology Vault Card',type:'tool',d:'A white swipe card: HEMATOLOGY · AUTHORISED ONLY.'},
  manifest:{n:'Kowalski Shipping Manifests',type:'read',d:'Carbon copies, 1984 to last week. "Rendering. Gilded Court. 1 unit." Over and over.'},
  grave:{n:'Grave-Dust Baggie',type:'tool',d:'A clip-seal bag of grey powder that glitters faintly. Vampire ash, cut with something worse.'},
  wristwatch:{n:'Your Cracked Wristwatch',type:'read',d:'A cheap steel watch with a cracked face, from Gideon\'s window. Engraved on the back: a name. Yours.'},
  chart:{n:'Your Medical Chart',type:'read',d:'St. Jude\'s, three years old. A patient name, a date of birth, a blood type. You remember none of it, and all of it is you.'},
  letter:{n:'Mail From Your Old Mailbox',type:'read',d:'A final notice, a postcard from a sister, a catalogue. Addressed to you, at the Rookery, Room 2C.'},
  cash:{n:'Cash',type:'money',d:'Money. It still works.'}
};

/* ---------- ideologies (Thought Cabinet) ---------- */
const THOUGHTS={
  // from the prologue
  tenant:{n:'The Tenant\'s Lease',from:'pedigree',time:60,q:'Somebody else is living in your blood, and he has opinions about the furniture.',during:{nostalgia:-1},done:{pedigree:1,web:1},dt:'You sign the lease. Absalom Vane is a permanent resident. He pays no rent, but he knows where every body in the Marrow Ward is buried, some of them literally.'},
  coroner:{n:'Coroner\'s Calm',from:'autopsy',time:30,q:'Ash is just a very thorough kind of evidence.',during:{pulse:-1},done:{autopsy:1},bonus:'Remains no longer cost Mask.',dt:'You have looked at death and filed it under "Thursday". It doesn\'t hurt any more. You notice that this should worry you, and it doesn\'t.'},
  meat:{n:'Meat Is Meat',from:'abattoir',time:45,q:'Pig, cow, Leo. It\'s all hanging from the same rail.',during:{pulse:-1},done:{abattoir:1,parasite:1,pulse:-1},bonus:'Feeding on mortals costs no Mask.',dt:'Pig, cow, person. You have stopped flinching at the difference. Something in you misses the flinch.'},
  tenpercent:{n:'Ten Percent Is Standard',from:'gutter',time:40,q:'Everyone in this city takes a cut. Even the Sheriff. Especially the Sheriff.',during:{pedigree:-1},done:{gutter:1,velvet:1,pedigree:-1},dt:'Every hand in Port Vellum is out and every hand is dirty. That isn\'t a tragedy. It\'s a market, and you have just learned the prices.'},
  bratwurst:{n:'Nobody Checks the Bratwurst',from:'abattoir',time:30,q:'There is a meat grinder in the back and a world of problems in the front.',during:{},done:{abattoir:1,stagecraft:1},dt:'Evidence is just ingredients that haven\'t been processed yet. A horrible thought. A useful one. You keep it.'},
  fourfiftyone:{n:'Four Fifty-One',from:'sundial',time:35,q:'A silver watch stopped at 4:51 a.m. Nine minutes before the sky goes grey.',during:{web:-1},done:{sundial:1,web:1},dt:'Whoever shut that door knew exactly when dawn was. A margin that thin is not an accident. It\'s a message, or a mistake.'},
  // the twenty
  vegan:{n:'Vegan Predator',from:'pulse',time:180,q:'You could just... not. Bags, the willing, the already-dying. Nobody has to be prey.',during:{parasite:-1,apex:-1,frenzy:-1,osmosis:-1},done:{pulse:2,stagecraft:2},bonus:'Abilities cost 1 extra Vitae unless your last blood was a bag or freely given.',dt:'You decide the Beast eats what you put in front of it, and nothing else. It sulks. It will sulk for a century. Let it.'},
  shepherd:{n:'The Shepherd\'s Burden',from:'nostalgia',time:150,q:'Every mortal who saw you tonight is now your responsibility. Every single one.',during:{apex:-1},done:{nostalgia:2},bonus:'Mortals trust you on instinct.',dt:'You count them like a shepherd counts at dusk: Leo, Tariq, the detective, the doctor. All present. All still breathing. Keep it that way.'},
  darwin:{n:'Apex Darwinism',from:'apex',time:180,q:'Why bargain with cattle when you can command them?',during:{apex:1},done:{apex:1},bonus:'Violence never costs Mask. Pulse-Check falls silent: set to 0.',zero:['pulse'],dt:'They are cattle. You knew it in the freezer and you know it now. The voice that disagreed has stopped talking to you.'},
  encore:{n:'Encore Mortal',from:'nostalgia',time:120,q:'Keep the habits. Hold the coffee. Do the crossword. Pretend until it\'s true again.',during:{},done:{pedigree:-1},bonus:'Dawn panic is halved. Elders find you embarrassing.',dt:'You buy a coffee you can\'t drink every night at the same time, from the same clerk, and say "thanks, man" like you mean it. You do mean it.'},
  grief:{n:'Grief Eater',from:'osmosis',time:150,q:'Sorrow has a taste. It\'s the only thing that still tastes like anything.',during:{nostalgia:-1},done:{osmosis:1},bonus:'Melancholic blood also restores +2 Mask.',dt:'You learn to drink sadness the way some people drink whisky: slowly, with your eyes closed, grateful.'},
  leash:{n:'Gilded Leash',from:'pedigree',time:150,q:'Order is a collar. Wear it well and they let you hold the leash, too.',during:{gutter:-1},done:{pedigree:2},bonus:'Unlocks cover-up options with the Court.',faction:'court',dt:'You choose the Court: its etiquette, its masks, its quiet executions. In return, the Court will one day choose you.'},
  guillotine:{n:'Guillotine Fangs',from:'gutter',time:150,q:'Every Elder is just a neonate who got lucky for four hundred years.',during:{pedigree:-1},done:{gutter:2,apex:2},bonus:'+2 against Elders.',faction:'anarch',dt:'Heads, crowns, the difference is a single clean stroke. You have stopped bowing. You may start cutting.'},
  union:{n:'Union of the Night',from:'gutter',time:120,q:'Night clerks, nurses, cabbies, cleaners, ghouls. The night shift is the biggest workforce in the city.',during:{},done:{gutter:1,nostalgia:1},bonus:'Bonus to recruiting mortal night workers and ghouls.',dt:'You start noticing them: Tariq, Tiny, the woman who mops the morgue. Nobody organizes the night shift. Somebody should.'},
  absolutist:{n:'The Masquerade Absolutist',from:'stagecraft',time:150,q:'The secret is the only thing keeping every one of us out of a bonfire.',during:{osmosis:-1},done:{stagecraft:2},bonus:'Heat falls twice as fast when you clean up.',dt:'You become a fanatic of the lie. Every breath you fake, every blink, every warm hand is a stone in the wall that keeps the torches out.'},
  autarkis:{n:'Autarkis',from:'echo',time:150,q:'Court, Syndicate, sewer. All three want a leash on you. Wear none.',during:{pedigree:-1},done:{echo:1,rigor:1},bonus:'−2 with every faction leader.',dt:'A lone wolf can\'t be betrayed. It also can\'t be saved. You find you can live with that, in the technical sense.'},
  firstmurder:{n:'Children of the First Murder',from:'osmosis',time:180,q:'The first vampire killed his brother in a field. Every drop since has been that same blood.',during:{nostalgia:-1},done:{osmosis:1},bonus:'Unlocks occult and scriptural dialogue.',dt:'Cain\'s mark, Enoch\'s walls, the long dark mythology. You don\'t believe it. You don\'t have to. It believes you.'},
  materialism:{n:'Hematological Materialism',from:'autopsy',time:150,q:'It\'s not a curse. It\'s an infection. Infections have cures.',during:{pedigree:-1},done:{autopsy:2},bonus:'Treats vampirism as a disease. Opens science options with Dr. Rostova.',dt:'A parasite in the blood, photophobic, haemophagic, transmissible by exchange. You write it out like a chart and feel, for the first time, slightly less damned.'},
  golconda:{n:'The Golconda Delusion',from:'pulse',time:240,q:'There is a state of grace where the Beast lies down. Vane believed in it. Maybe he was right.',during:{frenzy:-1},done:{},bonus:'+1 Mask at the start of each night if you killed no one the night before.',dt:'Grace is a rumour told by the very old to the very tired. You are both now. You choose to believe it.'},
  nihilist:{n:'Nihilist Immortal',from:'rigor',time:150,q:'Nothing matters for long enough to matter.',during:{},done:{nostalgia:-1},bonus:'+2 maximum Mask.',compMax:2,dt:'Empires, lovers, cities: dust on a long enough clock. You are the long clock. Nothing can embarrass a clock.'},
  hedonist:{n:'Blood-Drunk Hedonist',from:'parasite',time:120,q:'Why drink sad blood when you could drink a rave?',during:{sundial:-1},done:{parasite:1},bonus:'Resonance bonuses are doubled.',dt:'Champagne blood, adrenaline blood, the blood of someone falling in love. You become a sommelier of the human condition, and a drunk.'},
  capitalism:{n:'Nocturnal Capitalism',from:'gutter',time:120,q:'Immortality is just compound interest with teeth.',during:{nostalgia:-1},done:{gutter:1},bonus:'Cash found or taken is doubled. Unlocks bribes.',dt:'You think in centuries now, and centuries are what interest is for. Every coin you keep tonight will be a building in 2126.'},
  sungazer:{n:'Sun-Gazer',from:'sundial',time:150,q:'You have to look at it eventually. Why not on your own terms?',during:{},done:{apex:2,sundial:-1},bonus:'The Sundial screams constantly.',dt:'You stand at the grate at 4:59 every morning and watch the grey come up, until the last second. The fear never leaves. It just stops being in charge.'},
  relic:{n:'The Relic Collector',from:'pedigree',time:120,q:'Things remember. Rings, watches, bullets. Collect enough and you own a little history.',during:{},done:{},bonus:'Pocket items give +1 to each of their bonuses.',dt:'You start carrying the past in your pockets like loose change, and it starts paying.'},
  thrallmaster:{n:'Thrall-Master',from:'apex',time:150,q:'A mortal who drinks from you loves you. It is efficient. It is horrible. It is efficient.',during:{pulse:-1},done:{apex:1},bonus:'Binding one mortal costs no Vitae.',dt:'A drop, a kiss on the wrist, and a lifetime of devotion. You stop thinking of it as cruelty and start thinking of it as staffing.'},
  amnesiac:{n:'Amnesiac Fledgling',from:'rigor',time:120,q:'Whoever you were is gone. Don\'t dig them up.',during:{web:-1},done:{rigor:1},bonus:'The Tenant can no longer hijack you. Your old life stays buried.',dt:'You close the door on the person you were before the freezer. It is quieter in here now. It is also very much smaller.'}
};

const RELS=[[-3,'Hostile'],[-2,'Afraid'],[-1,'Wary'],[0,'Neutral'],[1,'Warming'],[2,'Trusting'],[3,'Devoted']];
const relName=v=>{let n='Neutral';for(const r of RELS)if(v>=r[0])n=r[1];return n;};

/* ---------- the cast ---------- */
const CHARS={
  tenant:{n:'The Tenant',full:'Sheriff Absalom Vane',role:'Sheriff of the Marrow Ward · deceased (by you)',color:'#cdb2f0',
    spec:{face:{long:1.07,jaw:1.25,nose:1.35,cheek:1.5,brow:1.1,chin:1.1},skin:[.84,.8,.78],hair:{style:'slick',color:[.75,.72,.7]},eyes:[.85,.65,.2],eyeGlow:[.5,.35,.05],coat:{color:[.16,.16,.2],length:.6,collar:true},shirt:[.85,.84,.8],tie:[.35,.05,.08],hat:{type:'widebrim',color:[.12,.1,.1]},mustache:[.72,.7,.68],height:1.04},
    bio:'Three hundred years in Port Vellum, the last eighty as Sheriff of the Marrow Ward: keeper of the peace, collector of the Court\'s tithes, and, according to Kowalski\'s ledger, collector of ten percent of everything else. You drank him. He lives in your blood now as a voice the others call the Tenant.',
    sched:[['Always','Lives in your blood. Comments on your choices.'],['Monday, 4:14 AM','Was shot in the freezer with a UV lance.']],
    facts:{intro:'Introduced himself as "the Tenant". Came with the property.',name:'Absalom Vane, Sheriff of the Marrow Ward. Three-time Court fencing champion.',noMemory:'Doesn\'t remember who shut the freezer door, only the click of the latch.',cut:'Took a ten percent cut of Kowalski\'s blood trade.',pemberton:'Pemberton drove him for forty-one years.',clan:'Was a Sovereign: old blood, older debts.',tired:'Was tired. Three hundred years tired. He wanted out.',vessel:'Brought the Sun-Vessel to the Ward to cure himself.',chose:'Chose you. Recruited you off the books, a year ago.',order:'Ordered you to drink him, so Séverine and Malakor wouldn\'t get him.'}},
  leo:{n:'Leo Pruitt',full:'Leonard "Leo" Pruitt',role:'Night counter at Kowalski\'s · aspiring stand-up',color:'#efc791',
    spec:{face:{wide:1.04,jaw:0.55,nose:0.8,cheek:0.5,long:0.97,chin:0.8},skin:[.9,.76,.66],hair:{style:'curly',color:[.35,.22,.12]},eyes:[.3,.25,.15],shirt:[.82,.82,.78],apron:{color:[.78,.76,.72],stain:[.5,.05,.08]},pants:[.2,.25,.4],shoes:[.3,.3,.32],height:.97},
    bio:'Twenty-four. Washes dishes and works the night counter at Kowalski\'s Monday to Thursday so he can do open mics on Tuesdays. Has a sister, a mother who calls him Leonard, and two neat holes in his neck that he would like someone to explain.',
    sched:[['Mon–Thu, 8 PM–4 AM','Night counter at Kowalski\'s.'],['Tuesday, 10 PM','Open mic at the Lantern Room on Reliquary Row.'],['Home','Rookery, Room 3B. Lives with a cactus called Gerald.']],
    facts:{name:'Name: Leonard Pruitt. Goes by Leo.',standup:'Does stand-up on Tuesdays. Has no material about his sister.',saw:'Saw the Sheriff in the freezer with Kowalski\'s ledger before you arrived.',door:'Heard someone shut the freezer door from outside. Didn\'t see who.',sister:'His niece Bea, his sister Junie\'s daughter, turned nine on Monday. He missed the party.',mom:'His mother reported him missing.',margo:'Says Margo had the freezer safety release "fixed" last week.',chained:'You chained him to the hook. Malakor saw you do it.',apartment:'Lives in the Rookery, Room 3B.'}},
  miller:{n:'Det. Ines Miller',full:'Detective Ines Miller',role:'Missing Persons · Precinct 9',color:'#c9d6e3',
    spec:{face:{jaw:0.85,nose:1.1,brow:1.25,cheek:1.2},skin:[.62,.45,.36],hair:{style:'bun',color:[.08,.06,.06]},eyes:[.2,.13,.08],coat:{color:[.52,.43,.3],length:.62,collar:true},shirt:[.3,.32,.36],pants:[.18,.18,.2],prop:'cup',height:.98},
    bio:'Forty-four. Missing Persons, Precinct 9, twenty years on the job, two hours of sleep a night. Seven people have vanished from the Marrow Ward in two months and she is the only one at the precinct who has noticed it is a pattern.',
    sched:[['Nights, officially off-duty','Knocking on doors in the Marrow Ward anyway.'],['2 AM','Lucky Mart. Burnt coffee, a cruller she never finishes.'],['Precinct 9','Desk by the radiator. Case files in a banker\'s box.']],
    facts:{name:'Detective, Missing Persons. Twenty years on the job.',seven:'Seven people missing from the Marrow Ward in two months.',coffee:'Buys burnt coffee at the Lucky Mart at two in the morning.',brother:'Her brother Mateo went missing in the Marrow Ward in 2011. Never found.',leo:'Came looking for Leo Pruitt after his mother called it in.',offclock:'Is working these cases off the clock. Her lieutenant doesn\'t know.',partner:'Her old partner, Ray Dunleavy, was killed in 2019. Officially: a mugging. She doesn\'t believe it.',handler:'Has a "liaison" from a federal task force: Agent Harrow. She doesn\'t like him.',clerk:'You worked the evidence cage at Precinct 9. She brought you coffee on Thursdays.'}},
  severine:{n:'Lady Séverine',full:'Lady Séverine Marchetti',role:'Keeper of Elysium · The Choir · The Gilded Court',color:'#e7a6b8',
    spec:{face:{long:1.04,jaw:1.3,nose:0.95,cheek:1.6,brow:0.75,chin:0.9},skin:[.92,.86,.82],hair:{style:'long',color:[.08,.05,.07]},eyes:[.3,.1,.15],eyeGlow:[.2,.02,.05],shirt:[.35,.05,.12],pants:[.1,.08,.1],lips:[.55,.1,.15],coat:{color:[.32,.04,.1],length:.9,collar:true}},
    bio:'Keeper of Elysium and voice of the Gilded Court in the Marrow Ward. She holds court in the VIP crypt beneath Club Reliquary and has, according to the Tenant, hated Absalom Vane "since the Coolidge administration, with real devotion".',
    sched:[['Nightly from 11 PM','The VIP Crypt, Club Reliquary.'],['Friday','The Tribunal. She expects a culprit.']],
    facts:{call:'Called the Sheriff\'s line looking for his report.',friday:'Friday: the Tribunal. Bring a culprit, or be one.',feud:'Has feuded with Absalom Vane for a century.',car:'Was in a car during the call, with someone else breathing on the line.',lance:'Is terrified you know about the UV lance.',hired:'Paid Malakor\'s syndicate for the lance.',funded:'Funded Dr. Rostova\'s "research" through a shell charity.',polaroids:'Was photographed in 1978 in a room under the Prince\'s tower.'}},
  pemberton:{n:'Pemberton',full:'Mr. Pemberton',role:'Chauffeur · the Sheriff\'s ghoul',color:'#b9c4b0',
    spec:{face:{long:1.05,jaw:0.75,nose:1.5,brow:1.45,cheek:0.6,chin:1.35},skin:[.86,.76,.7],hair:{style:'fringe',color:[.85,.85,.84]},eyes:[.35,.4,.42],coat:{color:[.06,.06,.07],length:.7,collar:true},shirt:[.85,.85,.82],tie:[.05,.05,.06],hat:{type:'chauffeur',color:[.07,.07,.08]},mustache:[.9,.9,.88],prop:'umbrella',height:1.05,width:.92},
    bio:'Forty-one years in the Sheriff\'s service as driver, valet, keeper of the calendar and drinker of the occasional sacrament. He has outlived two wives and three cars. He seems determined to outlive you.',
    sched:[['Wherever the car is','Waiting. Always waiting.']],
    facts:{name:'Forty-one years in Absalom Vane\'s service.',bond:'Blood-bound. "The blood decides who I serve."',relief:'Looked relieved, not surprised, that you were the one who walked out of the freezer.',car:'Drives a long black 1971 Continental.',knew:'Knew about you before Monday. Drove you, twice, with the partition up.'}},
  margo:{n:'Margo Kowalski',full:'Marguerite "Margo" Kowalski',role:'Owner, Kowalski\'s 24-Hour Meats',color:'#d9a07a',
    spec:{face:{wide:1.08,jaw:0.35,nose:1.15,long:0.95,cheek:0.8,chin:1.2},skin:[.88,.78,.7],hair:{style:'bun',color:[.7,.7,.7]},glasses:{type:'reading'},apron:{color:[.78,.76,.72]},shirt:[.4,.2,.2],height:.94,width:1.08},
    bio:'Sixty-three. Third-generation butcher. Her shop sells pork chops at the front and something else entirely out of the walk-in. Her father rendered bodies for the Gilded Court; so does she.',
    sched:[['Tuesday','Deliveries. St. Jude\'s, back entrance.'],['Thursday','Deliveries. The Gilded Court.']],
    facts:{owner:'Owns Kowalski\'s. Third-generation butcher.',trade:'Runs a black-market blood trade out of the freezer, labelled as pork stock.',release:'Had the freezer\'s safety release "fixed" last week.',v:'A new ledger entry: "New arrangement. S. says the Sheriff is a problem."',lock:'Told Leo to lock the walk-in. She never says that.',render:'The shop has rendered bodies for the Gilded Court for forty years.'}},
  tariq:{n:'Tariq',full:'Tariq Haddad',role:'Night clerk, the Midnight Lucky Mart',color:'#a8d8a0',
    spec:{face:{jaw:0.9,nose:1.2,brow:1.15,cheek:0.9,long:1.02},skin:[.66,.5,.4],hair:{style:'crop',color:[.08,.07,.07]},eyes:[.2,.13,.08],shirt:[.2,.42,.3],pants:[.18,.17,.2],mustache:[.1,.08,.08],height:1.0},
    bio:'Thirty-one. Has not slept properly since 2019. Owns a quarter of the Lucky Mart, which he thinks is a joke, and knows everyone on the Abattoir Strip by their order.',
    sched:[['Nightly, 8 PM–6 AM','Behind the Lucky Mart counter.'],['Wednesdays, 3 AM','The "collection". Two cops in an unmarked car.']],
    facts:{name:'Tariq Haddad. Co-owns the Lucky Mart. Insomniac.',racket:'Two cops from Precinct 9 collect "protection" from him every Wednesday.',sees:'Sees everything on the Strip after midnight. Writes it in a notebook.',monday:'Saw two people carry a third into Kowalski\'s at four on Monday morning.'}},
  tiny:{n:'Tiny',full:'Desmond "Tiny" Obi',role:'Head of door, Club Reliquary',color:'#c0a0ff',
    spec:{face:{wide:1.12,jaw:0.3,nose:1.1,brow:1.4,chin:1.3},skin:[.32,.22,.18],hair:{style:'shaved',color:[.05,.04,.04]},eyes:[.15,.1,.08],shirt:[.06,.06,.07],pants:[.06,.06,.07],coat:{color:[.08,.08,.1],length:.25,collar:true},height:1.1,width:1.35},
    bio:'Six-foot-six, soft-spoken, an encyclopaedic memory for faces. Has run the Reliquary door for nine years. His kidneys are failing and he hasn\'t told anyone.',
    sched:[['Nightly','The Reliquary door.'],['Mon, Wed, Fri, 10 AM','Dialysis he can\'t afford, at St. Jude\'s.']],
    facts:{name:'Desmond Obi. Everyone calls him Tiny. His little brother is Marcus.',kidney:'His kidneys are failing. He\'s missing dialysis to keep the job.',faces:'Never forgets a face. Remembers yours, from before.'}},
  gideon:{n:'Gideon',full:'Gideon Ash',role:'Owner, the Pawn & Coffin',color:'#d6c08a',
    spec:{face:{long:1.05,jaw:0.9,nose:1.4,brow:1.3,cheek:0.6,chin:1.0},skin:[.82,.7,.6],hair:{style:'fringe',color:[.85,.85,.82]},glasses:{type:'reading'},eyes:[.3,.3,.32],shirt:[.45,.32,.2],pants:[.2,.18,.16],height:.95},
    bio:'Seventy-four, mortal, knows exactly what his customers are. Sells pocket watches at the front and rents coffin-boxes at the back, cash, no questions, sunrise guaranteed.',
    sched:[['Nightly','Behind the counter of the Pawn & Coffin.']],
    facts:{name:'Gideon Ash. Pawnbroker and undertaker to the undead.',safe:'Fished a locked safe out of the river. Won\'t say whose.',forger:'Forges papers, for the right price.',watch:'Has a cracked wristwatch in the window with your name on the back.'}},
  rostova:{n:'Dr. Rostova',full:'Dr. Elena Rostova',role:'Night physician, St. Jude\'s Clinic',color:'#9ed0e0',
    spec:{face:{long:1.03,jaw:1.1,nose:1.0,cheek:1.2,brow:0.9},skin:[.9,.8,.74],hair:{style:'bun',color:[.35,.25,.15]},eyes:[.25,.35,.4],shirt:[.2,.45,.48],pants:[.2,.45,.48],coat:{color:[.88,.88,.86],length:.55,collar:true},height:.99},
    bio:'Forty-three. Runs St. Jude\'s night clinic on four hours\' sleep and a grudge against God. Sells expired O-negative to vampires out of the back fridge, cash only. She says it pays for the free clinic. That isn\'t the whole truth.',
    sched:[['Nightly, 9 PM–6 AM','St. Jude\'s night clinic.'],['Tuesdays','"Research" in the basement.']],
    facts:{name:'Dr. Elena Rostova, night physician.',bags:'Sells expired O-negative to vampires.',log:'Her entry log shows a John Doe admitted to the morgue at 4:31 a.m. Monday, by someone who looks like you.',drive:'The morgue\'s security drive was wiped Monday morning.',shooter:'Fired the UV lance that killed Vane.',why:'Believes vampires are a disease. Wants to cure the city, or burn it clean.',frequencies:'Knows how to set the Sun-Vessel: Alpha, Omega, Charlie.'}},
  malakor:{n:'Malakor',full:'Malakor of the Red Syndicate',role:'Butcher · boss of the Red Syndicate · Platform 0',color:'#e06050',
    spec:{face:{wide:1.1,jaw:0.4,nose:1.3,brow:1.5,cheek:0.7,chin:1.3},skin:[.74,.6,.58],hair:{style:'shaved',color:[.1,.08,.08]},eyes:[.6,.06,.06],eyeGlow:[.4,.02,.02],shirt:[.25,.2,.2],pants:[.12,.1,.1],apron:{color:[.22,.12,.1]},height:1.08,width:1.25,scars:true},
    bio:'A Butcher who rebuilt his own face eleven times and kept the twelfth. Runs the Red Syndicate\'s chop-shop under the Sunken Switchyard: stolen cars, stolen organs, custom weapons for vampires who need someone gone.',
    sched:[['Nightly','The chop-shop on Platform 0.']],
    facts:{name:'Malakor. Boss of the Red Syndicate.',lance:'Built the UV lance. Swears he didn\'t fire it.',buyer:'Sold it to a masked buyer who came in with you and Vane.',leo:'Saw you chain Leo to the meat hook.',generator:'His whole operation runs on one diesel generator.'}},
  soot:{n:'Mother Soot',full:'Mother Soot',role:'Eldest of the Wraiths · the Whisper Broker',color:'#b0b8c8',
    spec:{face:{long:1.1,jaw:1.3,nose:1.3,cheek:1.6,brow:1.2,chin:1.2},skin:[.68,.7,.72],hair:{style:'long',color:[.85,.86,.88]},eyes:[.85,.88,.95],eyeGlow:[.3,.32,.4],shirt:[.2,.2,.22],pants:[.15,.15,.17],coat:{color:[.18,.18,.2],length:.95,collar:false},height:.92},
    bio:'Nobody knows how old she is, including her. Lives in a shrine of candles and bone-microphones under the old cistern, and listens to the whole Ward through its pipes. Information is her blood. She trades it by the drop.',
    sched:[['Always','The sewer shrine, below Platform 0.']],
    facts:{name:'Mother Soot. The Whisper Broker.',key:'Holds the key to Morgue Locker #14. You gave it to her on Monday, under a blood contract.',contract:'Her contract: "Do not return this key until I know which of the three snakes I serve."',heists:'Wants three things: Séverine\'s booth bugged, Miller\'s case file, Malakor\'s generator dead.'}},
  valko:{n:'Valko',full:'Valko Drăgan',role:'The Sheriff\'s Hound',color:'#e0a050',
    spec:{face:{long:1.08,jaw:0.8,nose:1.3,brow:1.35,cheek:1.3,chin:1.1},skin:[.8,.66,.56],hair:{style:'slick',color:[.15,.1,.08]},eyes:[.95,.62,.12],eyeGlow:[.8,.45,.05],shirt:[.2,.15,.12],pants:[.12,.1,.1],coat:{color:[.35,.22,.12],length:.7,collar:true},height:1.06,width:.95},
    bio:'Vane\'s blood-tracker for sixty years, and the closest thing a Hound has to a son. He has been in another city on the Sheriff\'s business. Lady Séverine has just told him his master is dead, and who is wearing his master\'s coat.',
    sched:[['From Night 3','Hunting you. Everywhere.']],
    facts:{name:'Valko Drăgan. Vane\'s Hound.',loyal:'Would die for Vane. Would kill for him much more easily.',scent:'Can smell Vane\'s blood in you, stronger when you\'re hungry or wearing the signet.'}},
  harrow:{n:'Agent Harrow',full:'Special Agent Thomas Harrow',role:'Federal task-force "liaison"',color:'#9aa0a8',
    spec:{face:{long:1.02,jaw:1.0,nose:1.0,brow:1.1},skin:[.86,.74,.66],hair:{style:'crop',color:[.5,.48,.45]},glasses:{type:'sun'},shirt:[.85,.85,.85],tie:[.12,.12,.2],coat:{color:[.14,.14,.16],length:.35,collar:true},pants:[.14,.14,.16],height:1.03},
    bio:'Attached to Precinct 9 by a federal task force that doesn\'t appear on any org chart. Wears sunglasses at night for reasons that are, for once, entirely rational.',
    sched:[['Anywhere Miller is','Watching her.']],
    facts:{name:'Special Agent Harrow. Federal.',lantern:'Runs Project LANTERN: an extermination program with a budget.',rostova:'Is Dr. Rostova\'s handler.'}}
};

/* ---------- quests ---------- */
const TASKS={
  // prologue
  freezer:{n:'Get out of the freezer',xp:20,cat:'main'},what:{n:'Work out what happened in here',xp:20,cat:'main'},mirror:{n:'Find a mirror',xp:20,cat:'main'},
  remains:{n:'Deal with the Sheriff\'s remains',xp:20,cat:'main'},leo:{n:'Decide what to do about Leo',xp:25,cat:'main'},phone:{n:'Answer the telephone',xp:15,cat:'main'},
  front:{n:'Deal with whoever is at the front',xp:30,cat:'main'},leave:{n:'Leave before anyone else arrives',xp:20,cat:'main'},
  friday:{n:'Friday: survive the Tribunal at Platform 0',xp:0,cat:'main'},
  // night 1
  reliquary:{n:'Report to Lady Séverine at Club Reliquary',xp:40,cat:'main'},
  clinic:{n:'Find out who came to St. Jude\'s on Monday morning',xp:40,cat:'main'},
  haven:{n:'Find somewhere to sleep before dawn',xp:20,cat:'main'},
  // night 2
  crimescene:{n:'See what Detective Miller has found',xp:40,cat:'main'},
  malakor:{n:'Confront Malakor on Platform 0',xp:50,cat:'main'},
  soot:{n:'Get the locker key back from Mother Soot',xp:60,cat:'main'},
  // night 3
  locker:{n:'Open Morgue Locker #14',xp:60,cat:'main'},
  seizure:{n:'Decide who rules your skull',xp:80,cat:'main'},
  valko:{n:'Survive the Hound',xp:40,cat:'main'},
  // night 4
  rostova:{n:'Confront Dr. Rostova on the roof',xp:60,cat:'main'},
  chess:{n:'Set the board for Friday',xp:80,cat:'main'},
  // night 5
  tribunal:{n:'The Tribunal at Platform 0',xp:0,cat:'main'},
  // side
  s_tariq:{n:'The Insomniac of Lucky Mart',xp:40,cat:'side'},s_leo:{n:'The Dishwasher\'s Alibi',xp:40,cat:'side'},s_safe:{n:'Pawnshop Reliquary',xp:40,cat:'side'},
  s_tiny:{n:'Velvet Rope Blues',xp:40,cat:'side'},s_vault:{n:'The Midnight Triage Heist',xp:40,cat:'side'},s_404:{n:'The Crying Wall at Room 404',xp:50,cat:'side'},
  s_batch:{n:'The Bad Batch',xp:50,cat:'side'},s_cold:{n:'Detective Miller\'s Cold Case',xp:50,cat:'side'},s_ledger:{n:'The Butcher\'s Ledger',xp:40,cat:'side'},
  s_choir:{n:'Rats in the Choir Loft',xp:40,cat:'side'},s_prophet:{n:'The Third Rail Prophet',xp:40,cat:'side'},s_last:{n:'Last Call Before Dawn',xp:40,cat:'side'},
  // clan (one per playthrough)
  c_sovereign:{n:'A Debt of Vintage',xp:100,cat:'clan'},c_wraiths:{n:'The Face in the Drain',xp:100,cat:'clan'},c_glass:{n:'The Mirror Maze at Reliquary',xp:100,cat:'clan'},
  c_choir:{n:'The Cello of Bone',xp:100,cat:'clan'},c_butchers:{n:'The Ship of Theseus',xp:100,cat:'clan'},c_hounds:{n:'Stray Dog Strut',xp:100,cat:'clan'},
  c_alchemists:{n:'The Broken Clause',xp:100,cat:'clan'},c_hollow:{n:'Where the Shadows Go',xp:100,cat:'clan'},c_rot:{n:'Patient Zero in Ward 4',xp:100,cat:'clan'},c_stray:{n:'King of the Trash Heap',xp:100,cat:'clan'},
  // secret
  x_name:{n:'The 18th Voice',xp:80,cat:'secret'},x_golconda:{n:'The Golconda Protocol',xp:0,cat:'secret'},x_gehenna:{n:'Dial 0 for Gehenna',xp:60,cat:'secret'},
  x_banquet:{n:'The Cannibal\'s Banquet',xp:0,cat:'secret'},x_glass:{n:'The Ghost in the Glass',xp:60,cat:'secret'}
};

Object.assign(NL,{CLANS,CLAN_ORDER,ABIL,PASTS,SLOTS,SLOT_NAMES,ITEMS,THOUGHTS,relName,CHARS,TASKS});
})();
