'use strict';
/* THE NEW LORD — more ways to feed, and what each of them makes you */
(function(){const O=NL.Script.opt;
O('hunt.0','* The Velvet Hour crowd on Vine Street. Someone there always wants to be bitten.  -> hx.willing {if night>=2}',3);
O('hunt.0','* A man in an alley with his fist raised over someone on the ground.  -> hx.brute {if night>=3&!flag:hxBrute}',3);
O('hunt.0','* St. Jude\'s. Ask Rostova for a bag.  -> hx.bag {if alive:rostova&rel:rostova>=2&!flag:hxBag}',3);
O('hunt.0','* A sleeping man on a bench. A child\'s backpack beside him.  -> hx.dad {if night>=2&!flag:hxDad}',3);
O('hunt.0','* Ask Leo. He offered.  -> hx.leo {if alive:leo&rel:leo>=4&!flag:leoThrall&!flag:leoEmbraced&!flag:hxLeo}',3);
})();
NL.Script.add(String.raw`
# hx.willing
> Vine Street at two in the morning, outside a basement club with no sign. Black lipstick, fishnets, a queue of the young and pale and very serious. They've all read the books. They all want to be chosen.
> A girl with silver rings on every finger sees your eyes and stops talking mid-sentence.
pulse(5): Her heart speeds up. Not fear. Hope. She has been waiting for this her whole life.
* "Do you know what I am?"  -> hx.w1
* Just take her wrist. She's offering.  -> hx.w2 {blood}

# hx.w1
> She nods. She's trembling.
* "It'll hurt. And you'll want it again. And I won't be here to give it."  -> hx.w3 {do lean:candour+1}
* "Then come with me."  -> hx.w2 {blood}

# hx.w3
> She thinks about it. You watch her actually think, which almost nobody does.
* She holds out her wrist anyway. Take it. Gently.  -> hx.w4 {blood}
* Shake your head. Walk away.  -> hx.w5

# hx.w2
> In a doorway, under a broken streetlight, she holds out her wrist with her eyes shut and her lips moving, saying something to herself, maybe a prayer, maybe a lyric. You drink. She gasps, and then she laughs, and then she cries. You stop before she's dizzy. Just.
> Afterwards she holds her wrist against her chest like a gift and says thank you, and you don't know what to say back.
{do feed:2:Sanguine:a willing stranger:mortal; tick:20; lean:restraint-1}
@end

# hx.w4
> You take it gently. You stop early. She stands in the doorway holding her wrist, and she doesn't cry. She says: "Is that it?" And then: "Okay. Okay." And she goes back into the club like someone who has just been told the truth about Santa.
{do feed:2:Sanguine:someone who asked:mortal; tick:20}
@end

# hx.w5
> She watches you go. She doesn't follow. You hear one of her friends say "what did they say?" and her say "they said no" in a voice like a door closing very softly.
{do comp+1; lean:mercy+1}
@end

# hx.brute
> An alley off Kerr Street. A man in a work jacket, big, drunk, with his fist raised over a younger man on the ground who has his arms over his face. Blood on the cobbles. The man on the ground is saying "please" over and over.
frenzy(5): He's a monster. He's HUNTING. Nobody would miss him. Nobody would blame you. Eat him.
* Pull him off. Feed. He's earned it.  -> hx.b1 {blood}
* Pull him off. Hold him. Call it in.  -> hx.b2
* Pull him off. Let the boy decide.  -> hx.b3

# hx.b1
> You take him by the jacket and throw him against the wall, and then you're on his throat, and he's not big any more. The boy on the ground crawls away. You don't see where to.
* Stop when his heart slows.  -> hx.b1a
* Don't stop.  -> hx.b1b

# hx.b1a
> You stop. You leave him sitting in the alley, grey, alive, sober for the first time in years. When he looks up at you his eyes are a child's.
{do feed:3:Choleric:a brute in an alley:mortal; flag:hxBrute=1; tick:20}
@end

# hx.b1b
> You don't stop. You tell yourself he deserved it. Afterwards, standing over him, you notice his phone lighting up in his pocket. *Lisa ❤️*. It rings and rings.
{do feed:5:Choleric:a brute in an alley:mortal; kill; flag:hxBrute=1; lean:mercy-2; tick:20}
tenant: That's how it starts. "He deserved it." I said that in 1891. I said it about forty people after.
@end

# hx.b2
> You hold him against the wall with one hand while he swings at you and misses and swings again. With the other, you dial. The police come in eleven minutes, which is good for Kerr Street. You're gone by the time the light hits the alley.
{do flag:hxBrute=1; lean:mercy+1; comp+1; tick:20}
@end

# hx.b3
> The boy gets up. His face is a mess. He looks at the big man, pinned against the wall by something that isn't human. He looks at you.
* "What do you want me to do with him?"  -> hx.b4

# hx.b4
> He thinks about it for a long time.
> "Let him go," he says. "He's my dad."
> You let him go. The big man slides down the wall and sits there, crying. The boy goes and sits next to him. You walk away and you don't understand anything at all.
{do flag:hxBrute=1; comp+0; tick:20}
@end

# hx.bag
> The fourth floor. Her office. She looks at you over the top of a stack of files.
rostova: A bag. You want a bag from my fridge.
rostova: ...I've got three O-negative due to expire at six. They'd go in the incinerator. Take one. Take two. Better you than the incinerator.
> She hands them to you without looking, the way you'd hand someone a sandwich you weren't going to eat.
rostova: Don't tell anyone. Especially not me.
{do feed:3:Phlegmatic:a hospital bag:bag; flag:hxBag=1; rel:rostova+1; tick:15}
@end

# hx.dad
> A bench in Halloran Park. A man in his thirties asleep sitting up, chin on his chest. Beside him, a child's backpack with a dinosaur on it. No child. You look round. There, under the slide, curled in a sleeping bag: a girl of about seven, asleep.
pulse(5): Two hearts. One slow, exhausted. One fast, dreaming. They're not homeless by choice. The dinosaur backpack is new. Somebody bought it with the last money.
* Feed on him. A sip. He won't notice.  -> hx.d1 {blood}
* Leave them. Leave money.  -> hx.d2 {if cash>=20}
* Wake him. Tell him about Gideon's box twelve. Or the shelter.  -> hx.d3
* Walk on.  -> hx.d4

# hx.d1
> You sit beside him like a stranger on a bench. Thirty seconds. He mumbles "Ellie?" and doesn't wake.
> Under the slide, the girl turns over in her sleeping bag. You stop.
{do feed:2:Melancholic:a sleeping father:mortal; flag:hxDad=1; lean:mercy-1; tick:15}
@end

# hx.d2
> You leave twenty dollars folded in the front pocket of the dinosaur backpack. It isn't enough. It's what you've got.
{do cash-20; flag:hxDad=1; lean:mercy+1; comp+1}
@end

# hx.d3
> He wakes with a start, sees your face, and puts himself between you and the slide before he's even properly awake.
> You tell him. Box twelve at the Pawn & Coffin on Reliquary Row. No charge. Ask for Gideon. Or the Kerr Street Shelter, where the blood donors don't come any more.
> He doesn't trust you. He goes anyway, at four in the morning, with the girl asleep on his shoulder and the dinosaur backpack in his hand.
{do flag:hxDad=1; flag:hxDadGideon=1; lean:mercy+1; comp+2; tick:20}
@end

# hx.d4
> You walk on. At the gate you look back. The man has woken up. He's sitting very still on the bench, watching the slide, the way people watch something they're afraid will be taken.
@end

# hx.leo
> Room 3B. Leo opens the door and sees your face and knows.
leo: Oh. Oh, you're hungry. You've got the... the hungry face. Come in. Come in. It's okay. I said. I offered. I meant it.
> He sits on the edge of the bed and rolls up his sleeve like he's giving blood at the Red Cross. His hand is shaking.
* Take his wrist. Gently. A little.  -> hx.l1 {blood}
* "No, Leo. Not you. Not like this."  -> hx.l2 {do lean:restraint+1}

# hx.l1
> He watches the whole time. He doesn't look away. When you stop, he looks at the two small marks on his wrist with a kind of wonder, like someone looking at a first tattoo.
leo: That's... huh. That's not what I thought. I thought it'd be like a needle. It's more like... like being hugged by something very cold that really, really needs a hug.
leo: Are you okay? Was it okay? Did I taste okay? Is that a weird question? That's a weird question.
{do feed:2:Sanguine:Leo:mortal; flag:hxLeo=1; rel:leo+1; tick:15}
tenant: He'll want you to do it again. Not because of the blood. Because of the being needed. Be careful, child. That's how my Pemberton started.
@end

# hx.l2
leo: Not me. Okay. Okay. Yeah. Probably smart. My blood's probably like ninety percent Red Bull.
> He rolls his sleeve down. He looks relieved, and hurt, and relieved.
{do flag:hxLeo=1; rel:leo+1; comp+1}
@end
`,'c_hunt2');
