'use strict';
/* THE NEW LORD — street events, part four */
(function(){const X=NL.EXTRAS;const P=(n,role,skin,hair,shirt,coat,o)=>Object.assign({n,role,color:'#c8c0b0',spec:Object.assign({skin,hair:{style:hair[0],color:hair[1]},shirt,coat:coat?{color:coat,length:.5,collar:true}:null},o||{})});
Object.assign(X,{
  donor:P('A man with a cooler box','Kerr Street, 2 AM',[.8,.68,.6],['slick',[.2,.15,.1]],[.7,.7,.72],[.25,.25,.28]),
  teen:P('A girl on a bike','Delivery app, last order',[.62,.46,.36],['bun',[.08,.06,.05]],[.9,.4,.1],[.15,.15,.2]),
  pianist:P('A man at a piano','In the window of a closed bar',[.84,.72,.66],['fringe',[.6,.6,.6]],[.95,.95,.95],[.08,.08,.08]),
  drunkcop:P('An off-duty cop','The Anchor, closing time',[.88,.7,.62],['crop',[.4,.3,.2]],[.4,.45,.6],[.2,.2,.25]),
  oldwoman:P('An old woman at a bus stop','Waiting for no bus',[.76,.6,.54],['bun',[.9,.9,.9]],[.4,.25,.3],[.3,.2,.25],{height:.86}),
  courier:P('A Syndicate courier','Red Syndicate',[.7,.6,.56],['shaved',[.2,.2,.2]],[.2,.05,.05],[.15,.15,.15],{eyeGlow:[.3,.05,.05]}),
  dancer:P('A man dancing alone','Vine Street',[.5,.36,.3],['curly',[.1,.08,.06]],[.9,.8,.2],null),
  priestess:P('A woman with a censer','The Choir',[.86,.8,.78],['long',[.15,.1,.08]],[.9,.88,.85],[.85,.8,.75],{eyeGlow:[.4,.3,.1]})
});})();
NL.Script.add(String.raw`
// =====================================================================
// THE COOLER BOX
// =====================================================================
# ev.cooler street=2,3,4 w=2
> A man in a good suit on the corner of Kerr Street, two in the morning, with a blue picnic cooler at his feet. He sees your eyes and smiles like a salesman who's spotted a customer.
donor: Evening. You look thirsty. I can tell. I've got a nose for it.
> He taps the cooler with his shoe.
donor: Fresh. Tonight's. Type O, mostly. A pint for forty, three for a hundred. No questions, no hunting, no mess.
osmosis(5): Through the plastic: blood. Real blood, cold, a lot of it. And something else. Fear. Whoever gave it didn't give it.
* "Where's it from?"  -> ev.cx1
* Buy a pint.  -> ev.cx2 {if cash>=40}
* Open the cooler.  -> ev.cx3

# ev.cx1
donor: From donors. Willing donors. Well. Donors.
> His smile doesn't move. His eyes do. Just once, to a van parked across the street with its engine running.
@next ev.cx3

# ev.cx2
> You pay. He hands you a bag, cold, with a hospital label on it that someone has tried to peel off. *ST. JUDE'S — NOT FOR TRANSFUSION.*
> Rostova's blood fridge. The one somebody emptied at sunset.
{do cash-40; vitae+2; flag:boughtCooler=1}
* "This is from St. Jude's."  -> ev.cx3
* Walk away. Drink it later.  -> ev.cx4

# ev.cx3
> You open the cooler before he can stop you. Bags. Twenty, thirty, all with St. Jude's labels half-peeled. Under them, a clipboard. A list of names: *Kerr Street Shelter. Bed 4. Bed 7. Bed 11.*
web(7): Not just the hospital fridge. The shelter on Kerr Street. People who sleep there are waking up dizzy and nobody asks why.
* Take the cooler. Take it to Rostova.  -> ev.cx5
? apex 10 "Who's in the van?"  -> ev.cx6 | ev.cx7 {id ev_cx}
* Shut it. Not your business.  -> ev.cx4 {do lean:mercy-1}

# ev.cx4
donor: Pleasure. I'm here Thursdays.
@end

# ev.cx5
> He grabs for it. He's mortal. It's not a contest.
> You carry thirty bags of stolen blood through the Ward to St. Jude's at three in the morning, and put them on Rostova's desk, and she looks at them, and at the clipboard, and puts her face in her hands.
rostova: The shelter. They've been bleeding the shelter. Under my nose. With my labels.
{do flag:coolerStopped=1; rel:rostova+2; xp:30:The cooler; tick:20; lean:mercy+1}
@end

# ev.cx6
> He breaks. They always break.
donor: My brother-in-law! He's a phlebotomist! He goes into the shelter on Tuesdays with a clipboard and says it's a health survey! It's not hurting anybody! They're homeless!
> The van across the street pulls away without him.
* Let him go. He'll never come back to Kerr Street.  -> ev.cx8
* Take the cooler to Rostova.  -> ev.cx5

# ev.cx7
donor: Nobody. Nobody's in the van. Have a nice night.
> He's gone, cooler and all, before you can stop him.
@end

# ev.cx8
> He runs. He leaves the cooler. You leave it at the door of the Kerr Street Shelter with a note: *Yours.* It's a stupid thing to do with thirty bags of blood. It's the only thing that seems right.
{do flag:coolerStopped=1; lean:mercy+1; comp+1}
@end

// =====================================================================
// THE LAST ORDER
// =====================================================================
# ev.bike street=2,3,4,5
> A girl on a bike with a delivery box on her back, sixteen maybe, stopped under a streetlamp, staring at her phone and crying. Her front tire's flat. A bag of food from the Golden Dragon is hanging off the handlebars.
teen: It's fine. It's FINE. It's my last order and the app says I've got four minutes and it's two miles and if it's late I get a strike and three strikes and I'm off and Mom needs... it's fine.
* "Where's it going?"  -> ev.bk1
* Walk on.  -> ev.bk2

# ev.bk1
teen: The Rookery. Halloran Street. Flat 302. It's a sweet and sour chicken and a can of Fanta for a Mr. Halloran.
* "I'll take it. You'll make it."  -> ev.bk3
* Pick up the bike. Carry it, and her, the two miles.  -> ev.bk4
* "Tell the app the tyre burst."  -> ev.bk5

# ev.bk2
> Behind you she kicks the bike, hard, and then sits down on the curb next to it.
@end

# ev.bk3
> You take the bag. You go. You're at the Rookery before the app's clock ticks over, up three flights, knocking on 302. Mr. Halloran opens it in his cardigan and looks at you, and at the bag, and at the empty stairwell behind you.
halloran: You're not the usual girl.
* "She had a flat. She sends her apologies."  -> ev.bk6

# ev.bk6
halloran: Course she did. That's the second time this month. Here. Give her this.
> He gives you a ten-dollar tip, folded small. You take it back to the girl under the streetlamp. Her app says *DELIVERED. 5 STARS.*
teen: How did you... that's two MILES. How did you DO that?
* "I run."  -> ev.bk7

# ev.bk7
teen: You RUN? Nobody runs that fast. Nobody...
> She looks at your face properly for the first time. She goes very still. Then she takes the ten dollars and says "thank you" very quietly and walks her bike away without looking back.
{do comp+1; lean:mercy+1}
@end

# ev.bk4
> You pick up the bike in one hand and her in the other. She screams. You run. Two miles in ninety seconds with a sixteen-year-old under one arm and a Raleigh under the other and a bag of sweet and sour chicken in your teeth.
> She makes the delivery with ten seconds to spare. She's shaking. She doesn't say anything. She just stares.
{do comp+1; heat+1; lean:restraint-1}
@end

# ev.bk5
teen: Tell the app. You can't tell the app anything. The app doesn't care.
> She's right. The app doesn't care. You sit on the curb with her until the four minutes run out, and the strike comes, and she says "okay" and wipes her face on her sleeve and gets up.
{do comp+0}
@end

// =====================================================================
// THE PIANO
// =====================================================================
# ev.piano street=3,4,5
> Through the window of a bar that closed an hour ago, a man in a white dinner jacket is playing the piano. Nobody else is in there. The chairs are up on the tables. He's very good.
pulse(4): No heartbeat. One of you. Playing to an empty room.
* Knock on the glass.  -> ev.pi1
* Stand outside and listen.  -> ev.pi2

# ev.pi1
> He looks up. He doesn't stop playing. He nods at the door. It's unlocked.
pianist: Come in. Sit. I play here every night at three. The owner doesn't know. Well, he does, but he thinks it's the radio.
pianist: Request?
* "Something he'd like." (The Tenant.)  -> ev.pi3
* "Something sad."  -> ev.pi4
* "Do you know Caruso?"  -> ev.pi5

# ev.pi2
> You stand in the rain on Vine Street with your hands in your pockets and listen. He plays Chopin, then something you don't know, then *Moon River*. When he finishes, he looks at the window and raises a hand, as if he knew you were there all along.
{do comp+2}
@end

# ev.pi3
> He listens to something you didn't say out loud. Then he plays a waltz. Old. Corsican, maybe, or Genoese. Your hands, on your knees, start to move with it without asking.
tenant: Oh. Oh, that's... I danced to that in Ajaccio in 1789 with a girl called Paola. I'd forgotten. How did he know?
pianist: The Glass in me. A little. I hear what people want to hear. It's not as useful as it sounds.
{do sync+2; comp+2}
@end

# ev.pi4
> He plays something sad. It's so sad you don't recognize it as music for a while. It's just the shape of the week, put into chords.
pianist: That one's mine. I wrote it in 1944. I've never played it for anyone. You looked like you'd understand.
{do comp+2}
@end

# ev.pi5
pianist: Caruso. The aria from the Lady's gramophone. Ha. Yes. Everyone in Elysium knows that one, whether they want to or not.
> He plays it. Halfway through, you realize he's playing it slower than the record, and sadder, and that it's better.
{do comp+1; mem:severine:pianist}
@end

// =====================================================================
// CLOSING TIME
// =====================================================================
# ev.cop street=3,4,5
> Outside the Anchor at closing time: an off-duty cop, very drunk, sitting on a bollard, crying into his sleeve. Precinct 9 badge clipped to his belt. You know the face. You've seen him with Dale.
drunkcop: I didn't... I didn't want to... Dale said it's just sixty a week. Just sixty. Everyone does it. Everyone does it.
* Sit down next to him.  -> ev.cp1
* Take his badge. Throw it in the river.  -> ev.cp2
* Feed. He's a crooked cop, and he's drunk, and nobody will believe him.  -> ev.cp3 {blood}

# ev.cp1
drunkcop: Who're you? You're... you're cold. Why are you so cold?
drunkcop: I've got a kid. I've got a kid and I take sixty dollars a week off a man who sells scratch cards. My kid thinks I'm a hero. She drew me. In a cape.
* "Then stop. Tomorrow. Be the one in the drawing."  -> ev.cp4
* "Tell Detective Miller. Everything. Dale, the money, the lot."  -> ev.cp5 {if alive:miller}

# ev.cp2
> You unclip it and throw it. It goes into the Vellum without a splash, the way everything does.
drunkcop: ...That was my badge.
> He looks at the water. Then he laughs, horribly.
drunkcop: Good. Good. Good riddance.
{do lean:pride+1}
@end

# ev.cp3
> He doesn't even notice. He's so drunk that he thinks it's a hug. He says "thanks, mate" while you're doing it.
> His blood tastes of lager and shame. It goes down easily. That's the worst part.
{do feed:3:Phlegmatic:a crooked cop:mortal; lean:restraint-1}
@end

# ev.cp4
drunkcop: The drawing. In a cape.
> He wipes his face on his sleeve. He stands up, unsteadily.
drunkcop: Yeah. Yeah. I'll... yeah.
{do lean:mercy+1; comp+1}
@end

# ev.cp5
drunkcop: Miller. Missing Persons Miller. She'd... she'd eat me alive.
drunkcop: ...Good. Good. Somebody should.
> He gets out his phone. He scrolls. He doesn't call. But he doesn't put it away either.
{do flag:copToMiller=1; rel:miller+1}
@end

// =====================================================================
// THE BUS STOP
// =====================================================================
# ev.stop street=2,3,4,5 w=2
> An old woman at the bus stop on Halloran Street, in a good coat and a hat with a pin in it, sitting very upright with her handbag on her knees. The timetable says the last bus was at 12:10. It's nearly three.
oldwoman: It's late again. It's always late. I've told them.
pulse(5): Her heart is slow and a little uneven. She's cold. She's been sitting here a long time.
* "The last bus went at ten past twelve."  -> ev.st1
* Sit and wait with her.  -> ev.st2
* "Where are you trying to go?"  -> ev.st3

# ev.st1
oldwoman: No, no. There's one at three. There's always one at three. For the night shift. My husband gets it home from the docks.
> She checks her watch. It's stopped.
@next ev.st3

# ev.st2
> You sit. She talks. About the docks, about her husband, about the price of bread, which she quotes in a currency nobody uses any more. About a dance hall that burned down in 1971. She's very happy to have company.
@next ev.st3

# ev.st3
oldwoman: Home. Thirty-one Pelham Terrace. Ernie'll be home at half three and wanting his tea.
web(6): Pelham Terrace was knocked down for the beltway. Ernie, whoever he was, has been gone a long time.
* "I'll walk you home."  -> ev.st4
* Call St. Jude's. Someone should come for her.  -> ev.st5
* "Ernie's not coming, love."  -> ev.st6

# ev.st4
> You walk her. Not to Pelham Terrace. You walk her slowly, arm in arm, to the only address you can think of where somebody will be awake and kind at three in the morning: the Lucky Mart. Tariq looks at her, and at you, and puts the kettle on without a word.
tariq: Mrs. Eileen Ward. She lives above the launderette. Her daughter's in Ohio. This happens. I'll ring the daughter. Sit, Mrs. Ward. Sit. Tea.
{do comp+2; rel:tariq+1; lean:mercy+1; tick:15}
@end

# ev.st5
> You call from the payphone. A nurse with a Glasgow accent says they'll send someone. They do: an ambulance, quietly, no siren. The old woman gets in and says "is this the three o'clock?" and the paramedic says "yes, love, it is."
{do comp+1; tick:10}
@end

# ev.st6
> She looks at you for a long time.
oldwoman: ...No. No, I don't suppose he is.
> She doesn't cry. She opens her handbag and takes out a photograph of a man in a flat cap, and looks at it, and puts it back.
oldwoman: Will you sit with me a bit longer, then? Since there's no bus.
* Sit with her until it starts to get light.  -> ev.st7
* Walk her somewhere warm.  -> ev.st4

# ev.st7
> You sit with her until the sky is going grey and you have to go. She thanks you. She says you remind her of someone. She doesn't say who. When you look back from the corner she's still sitting very upright with her handbag on her knees, waiting for the three o'clock, and the first real bus of the morning is coming down Halloran Street with its lights on.
{do comp+1; tick:40}
@end

// =====================================================================
// THE COURIER
// =====================================================================
# ev.courier street=3,4
> A Syndicate courier steps out of a doorway on Ferrier Lane: shaved head, red leather, a small steel case handcuffed to his wrist. He's Kindred. He's nervous. He's very, very young.
courier: You. The Sheriff-eater. Malakor said if I see you, give you a message. He said, and I quote, "Tell my favorite customer the price of everything has just gone up."
courier: That's it. That's the message. Can I go?
* "What's in the case?"  -> ev.cu1
* "Go."  -> ev.cu2

# ev.cu1
courier: I don't know. I never know. I'm not allowed to know. If I know, Malakor takes my face.
courier: ...It's heavy. It's warm. It ticks.
osmosis(6): Quartz and copper and federal paint. A lamp. A small one. Somebody in the Syndicate is selling LANTERN's own lamps back to the Ward.
* Let him go. Tell Malakor you know.  -> ev.cu3
* Take the case.  -> ev.cu4

# ev.cu2
courier: Thank you. Thank you. He said you'd be nice.
@end

# ev.cu3
courier: Tell him you... no. No, please. You tell him. Not me. I'm just the arm.
{do flag:knowSyndLamps=1}
@end

# ev.cu4
> The handcuff breaks like a paperclip. The boy stares at his empty wrist.
courier: He's going to take my face. He's going to take my FACE.
* "Tell him the Sheriff-eater took it. He'll understand."  -> ev.cu5
* Give it back. "Never mind."  -> ev.cu2

# ev.cu5
> Inside: a quartz cylinder, the size of a thermos, with a dial and a federal serial number. A portable lamp. Six seconds of noon in a box.
{do give:minilamp; flag:knowSyndLamps=1; rel:malakor-1}
@end

// =====================================================================
// VINE STREET, DANCING
// =====================================================================
# ev.dance street=2,3,4,5
> On Vine Street, under the railway bridge, a man in a yellow shirt is dancing on his own to music from his phone. Not drunk. Just dancing. Joyfully, badly, with his eyes shut.
* Watch.  -> ev.dn1
* Dance with him.  -> ev.dn2
* Walk past. It's none of your business.  -> ev.dn3

# ev.dn1
> He dances to three songs. On the fourth he opens his eyes and sees you watching and doesn't stop or look embarrassed. He waves you in.
dancer: Come on! Nobody's looking! That's the whole point of three in the morning!
* Dance.  -> ev.dn2
* "I'm all right here."  -> ev.dn3

# ev.dn2
> You dance. Under a railway bridge, at three in the morning, with a stranger in a yellow shirt, to a song you've never heard. Your body knows how. Somewhere, back behind the freezer door, you used to do this. You used to do this a lot.
dancer: THERE you go! There you go! You're good! You're actually good!
nostalgia(5): A club. Lights. Sweat. Somebody shouting your name over the music. You were happy there. You'd forgotten you were ever happy anywhere.
{do comp+3; sync-1}
@end

# ev.dn3
dancer: Suit yourself!
@end

// =====================================================================
// THE CENSER
// =====================================================================
# ev.choir street=3,4,5 if=!clan:choir
> A woman in white, swinging a brass censer, walking very slowly down the middle of Reliquary Row, singing in Latin. The smoke smells of myrrh and something copper. Behind her, the puddles on the cobbles ripple in time.
priestess: Little thief. The Choir has been listening to you. Your blood sings off-key. Two voices, out of tune. Do you know how loud that is, to us?
* "Can you fix it?"  -> ev.cz1
* "Leave me alone."  -> ev.cz2

# ev.cz1
priestess: Fix it. Harmony isn't fixing. It's choosing. One note, or both, sung together.
priestess: Hum. Any note. Let me hear which one you choose.
* Hum low. Your own note.  -> ev.cz3
* Hum high. His.  -> ev.cz4
* Try to hum both.  -> ev.cz5

# ev.cz2
priestess: Alone. As you like. But you're never alone, are you. Not any more.
@end

# ev.cz3
priestess: Yours. Low. Plain. Mortal, almost. You'd keep yourself.
{do sync-3:Your own note; comp+1}
@end

# ev.cz4
priestess: His. High. Old. Sovereign. You'd give yourself away for it.
{do sync+3:His note}
@end

# ev.cz5
> You try. It's impossible. Two notes from one throat. And then, for a moment, it isn't. Something in your chest finds the interval between you and him, and sits in it, and holds.
priestess: ...Oh. Oh, that's rare. That's a third. That's the sweetest interval there is.
{do sync+1; comp+2; flag:choirThird=1}
@end
`,'c_street4');
NL.ITEMS.minilamp=NL.ITEMS.minilamp||{n:'A Portable Quartz Lamp',type:'tool',d:'Federal issue. A dial, a serial number, six seconds of noon. Stolen from LANTERN and sold by the Syndicate. Never, ever point it at yourself.'};
