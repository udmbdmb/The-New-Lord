'use strict';
/* THE NEW LORD — "The Nine": the night bus, the driver who is in love with a woman at the Kerr Street stop, and the starving girl who rides it to stay warm */
(function(){const S_=NL.Script,X=NL.EXTRAS;
NL.TASKS.s_nine={n:'The Nine',xp:70,cat:'side'};
X.earl={n:'Earl',color:'#c8b890',role:'Driver, the 9 bus · nights',spec:{face:{wide:1.08,jaw:0.8,cheek:1.1},skin:[.42,.3,.24],hair:{style:'shaved',color:[.7,.7,.68]},shirt:[.25,.32,.45],coat:{color:[.2,.25,.38],length:.45,collar:true},height:.98,bulk:1.15}};
X.nell={n:'Nell',color:'#e8b0c8',role:'Three weeks dead · rides the 9',spec:{face:{long:1.02,cheek:1.0},skin:[.9,.82,.8],hair:{style:'long',color:[.75,.6,.35]},shirt:[.5,.15,.25],coat:{color:[.1,.08,.1],length:.75,collar:true},eyeGlow:[.6,.3,.85],height:.92}};
X.dolores={n:'Dolores',color:'#d8b8a0',role:'Night cleaner · the Kerr Street stop',spec:{face:{long:1.0,jaw:0.9},skin:[.6,.45,.36],hair:{style:'bun',color:[.2,.15,.12]},shirt:[.6,.55,.7],coat:{color:[.35,.3,.4],length:.6,collar:true},height:.9}};
NL.Script.opt('pf.hub','* Nell, from the 9, standing by a pillar in somebody else\'s coat.  -> n9P.0 {once} {if flag:nell=taught|flag:nell=fed|flag:nell=gideon}');
S_.place({id:'the9',name:'The 9, Night Service',block:'B',sub:'The last bus up Vine Street, half past two. Always late. Always one passenger who never gets off.',if:'night>=3&night<=4&flag:mapOK&!flag:nineDone',node:'n9.0',min:8});
})();
NL.Script.add(String.raw`
# n9.0
> The 9 comes in late, as the old man on the bus shelter said it would. Lit up, warm, empty except for one passenger on the back seat with her knees up and her hood over her face.
> The driver's a big man in his sixties with a Port Vellum Transit jacket and a photograph of somebody's grandchildren taped to the dashboard. He looks at you, at the coat, at the grey of you, and he doesn't blink.
earl: Evening. Fare's two-fifty. Or don't pay. I don't care much after two. Sit anywhere except the back. She likes the back.
{do task:s_nine; note:s_nine|The 9 bus. A driver called Earl, a girl on the back seat, and something wrong.}
* Pay the fare. Sit near the front.  -> n9.front {if cash>=3}
* Walk to the back. Sit next to her.  -> n9.back
* "Who is she?"  -> n9.who

# n9.who
earl: Couldn't tell you her name. She's ridden every night for three weeks. End to end, Vine to the depot and back, till I clock off at five. Never pays. Never talks. I don't mind. It's warm in here. Some people need warm.
earl: She looks a bit like you, actually. No offence. The grey.
@next n9.0b

# n9.0b
* Sit near the front.  -> n9.front
* Walk to the back. Sit next to her.  -> n9.back

# n9.front
> You sit behind Earl. The bus pulls away up Vine Street. Rain on the windows. The engine humming. In the mirror over the windshield, you can see the back seat. The girl hasn't moved. Her eyes, under the hood, are fixed on the back of Earl's neck.
pulse: Earl's heart. Steady, slow, a little tired. Hers isn't beating at all. She's listening to his.
earl: Big night for you lot, Friday, I hear. Don't look at me like that. I've been driving nights for thirty years. You hear things. You see who gets on at the Switchyard.
* "You know what I am."  -> n9.earl1
* "What do you hear?"  -> n9.earl2

# n9.earl1
earl: I know you're cold, and you don't breathe unless you're talking, and you don't show up in the mirror. My grandmother was from Port-au-Prince. She'd have had a word for it. I just call you passengers.
@next n9.stop

# n9.earl2
earl: That the old Sheriff got himself killed. That the new one's younger. That there's a party under the station on Friday that nobody gets invited to twice.
earl: That's all. I don't ask. Asking's not the job. Driving's the job.
@next n9.stop

# n9.back
> You sit next to her. She flinches all the way to the window.
> Up close, she's nineteen, maybe. A Gilded coat cut for someone taller. Fingernails bitten to nothing. Her lips are grey. Her eyes are a hungry, glassy violet, and they keep going to the front of the bus. To the driver.
nell: Go away. Go away. I'm not doing anything. I'm just riding.
pulse: She hasn't fed in days. Maybe a week. She's riding the 9 because it's warm and because he's kind and because if she gets off she'll have to find someone, and she doesn't know how.
* "How long since you ate?"  -> n9.nell1
* "Who made you?"  -> n9.nell2
* "You're looking at him like food."  -> n9.nell3

# n9.nell1
nell: Ate. You mean... I had a rat. On Tuesday. Behind the Golden Dragon. I was sick. I had a man on the... no. No. I didn't. I nearly did. On Sunday. A man asleep on this seat. I put my mouth on his wrist and he woke up and I ran off at the depot.
nell: I'm so hungry. I'm so hungry all the time. And he's so... he says goodnight to me. Every night. "Goodnight, sweetheart, mind the step." I can hear his heart from the back seat.
@next n9.nhub

# n9.nell2
nell: A man at a party. In the Heights. I don't remember his face. I remember a ring. A little silver bird.
nell: He said I was beautiful. Then I woke up in a dumpster with this coat on. It's not even mine. It's somebody's. There's a name in it. Sophie. I don't know who Sophie is.
pulse: The hummingbird ring. Valentin Roux. {if seen:hb.0|flag:rouxMet}
@next n9.nhub

# n9.nell3
> She goes rigid. Then her whole face crumples.
nell: I know. I know I am. I know. That's why I'm on the bus. If I'm on the bus I can see him. If I can see him I know I haven't done it yet.
@next n9.nhub

# n9.nhub
* "I'll teach you how to eat without killing anyone. Tonight."  -> n9.teach
* "There's a man called Gideon. He'll give you a box and a bag of blood. Come with me."  -> n9.gideon {if alive:gideon}
* "Lady Séverine will want to know about you. She'll take you in."  -> n9.court {if alive:sev}
* Let her drink from you.  -> n9.feed {blood 1}
? apex 12 "Look at me. You don't touch him. You don't touch anyone on this bus. Ever."  -> n9.command | n9.commandNo {id n9_cmd} {red}
* End it. Quickly. Before she kills him.  -> n9.end {red}

# n9.stop
> Kerr Street. The bus pulls in to a shelter where a woman in a cleaner's smock is waiting, with a plastic bag and a flask, the way someone waits who's done it every night for years.
> Earl's whole posture changes. He sits up. He straightens his cap. He opens the doors.
earl: Evening, Dolores.
dolores: Evening, Earl. Late again.
earl: Always late. You'd worry if I wasn't.
> She sits in the seat opposite his. She doesn't sit anywhere else. In the mirror, you can see the back seat. The girl's hood has come down. She's watching Earl's neck the way a dog watches a door.
* Go to the back. Now.  -> n9.back
* Stay where you are. Watch.  -> n9.watch

# n9.watch
> You watch. Earl and Dolores talk about the weather, about her son in the Navy, about a pothole on Halloran Street that's been there since 2009. Neither of them says anything else. Both of them want to.
> In the back, the girl's hand is on the seat-back in front of her. Her fingers have gone through the vinyl.
* Go to the back.  -> n9.back

# n9.teach
> You teach her. On the 9, at three in the morning, between Kerr Street and the depot.
> You show her how to listen for the sleepers. How to sit beside one, gently, like a friend. How to take only a little, from the inside of the wrist, and how to close it after with the tongue, and how to say "you nodded off, you're fine" if they wake. How to stop. Mostly, how to stop.
> She takes it from a night-shift porter asleep with his head against the window. Two mouthfuls. Her hands stop shaking. He doesn't wake.
nell: Oh. Oh. Oh, that's... that's it? That's all? I thought it had to be... I thought you had to...
* "It doesn't. Not ever. Not if you're careful."  -> n9.teach1

# n9.teach1
nell: Not ever. Okay. Okay.
> She looks at the front of the bus. At Earl. Her eyes are blue now. Just blue. She looks at him like he's a man.
{do flag:nineDone=1; flag:nell=taught; task:s_nine=done; xp:70:The Nine; lean:mercy+1; comp+2}
@next n9.dolo

# n9.gideon
nell: A box. And a bag. Like... a bed? Somewhere to sleep that isn't a dumpster?
> She starts crying. Not the hungry kind.
> You get off at Reliquary Row with her. Earl waves. "Mind the step, sweetheart." At the Pawn & Coffin, Gideon takes one look at her, says nothing at all, and goes to the fridge.
gideon: Box six. The lid sticks a bit. Here. Drink this. Slowly. You'll be sick if you go fast.
{do flag:nineDone=1; flag:nell=gideon; task:s_nine=done; xp:70:The Nine; rel:gideon+1; comp+2}
@next n9.dolo

# n9.court
nell: The Court. The... the people with the ring.
nell: No. No no no. That's who did this. They'll... no.
> She's up and at the doors before you can stop her, and the doors are shut, and Earl looks round, and she's looking at him, and her eyes are violet, and—
* Get between them. Now.  -> n9.between

# n9.between
> You're between them before you've decided to be. She hits you instead. Her teeth go into your shoulder through the Sheriff's coat. She drinks. A mouthful. Two. Then she tastes what you are, and what's in you, two hundred years of Sovereign, and she lets go and falls back on the floor of the bus, gasping like she's been punched.
earl: Jesus. Jesus Christ. Are you... is she...
nell: I'm sorry. I'm sorry. I'm sorry.
* Take her to Gideon.  -> n9.gideon {if alive:gideon}
* Hold her. Teach her. Here.  -> n9.teach

# n9.feed
> You roll up your sleeve. She stares at your wrist like it's a trick.
nell: From you? You'd... why would you...
> She drinks. It's clumsy. It hurts. She drinks much too much and then she stops by herself, all at once, and sits back, and looks at you with eyes that have gone from violet to an ordinary, startled blue.
nell: You taste like... like an old house. Like a library. Who *are* you?
tenant: She's taken some of me too. Not much. A taste. She'll dream of Corsica tonight and not know why.
{do flag:nineDone=1; flag:nell=fed; task:s_nine=done; xp:70:The Nine; vitae-1; lean:mercy+2; comp+1}
@next n9.dolo

# n9.command
> You let her see what's behind your eyes. The weight of it. The crown. She goes still. Not frightened. Emptied.
nell: I won't. I won't touch him. I won't touch anyone on the bus. I won't.
> She says it like a prayer she's been given. She'll keep it. She'll keep it until she starves.
* "And find someone who isn't on the bus. A sleeper. Gently."  -> n9.command1
* Leave it at that.  -> n9.command2

# n9.command1
nell: A sleeper. Gently.
> She gets off at the next stop and walks toward the all-night laundromat on Vine, where a man is asleep on the bench by the dryers. She'll be all right. Probably.
{do flag:nineDone=1; flag:nell=commanded; task:s_nine=done; xp:60:The Nine; lean:pride+1}
@next n9.dolo

# n9.command2
> She stays on the back seat, hands in her sleeves, not looking at anyone. Earl says goodnight to her at the depot. She doesn't answer. She'll ride tomorrow. She'll ride every night until the hunger takes the command apart, or her.
{do flag:nineDone=1; flag:nell=starving; task:s_nine=done; xp:40:The Nine; lean:pride+1; comp-1}
@end

# n9.commandNo
nell: Don't. Don't do that voice. The man with the ring did that voice.
> She's at the doors. They're shut. She turns toward Earl.
* Get between them. Now.  -> n9.between

# n9.end
> It's very quick. She doesn't have time to be afraid. You make sure of that. It's the one kindness left.
> Ash on the back seat of the 9. A coat with SOPHIE written in the collar. Earl, in the mirror, not stopping the bus. He drives to the depot. He parks. He sits for a long time with his hands on the wheel.
earl: She used to say goodnight. Not out loud. She'd lift her hand. Like this.
earl: Get off my bus. Please. Get off my bus.
{do flag:nineDone=1; flag:nell=dead; task:s_nine=done; xp:40:The Nine; kill; lean:mercy-2; comp-3:Nell}
@end

# n9.dolo
> Kerr Street, on the way back. Dolores at her stop with her flask. Earl straightening his cap. In the back, Nell, with her hood down, watching them both with the glassy patience of the very young dead. {if flag:nell=taught|flag:nell=fed}
> Kerr Street, on the way back. Dolores at her stop with her flask. Earl straightening his cap. {if flag:nell=gideon|flag:nell=commanded}
> They're going to talk about the pothole on Halloran Street again. You can see it coming. Thirty years of potholes.
* Say something. To both of them.  -> n9.dolo1
? velvet 10 "Lean forward. Say to Earl, quietly: "Ask her. Tonight. I'll mind the bus.""  -> n9.dolo2 | n9.dolo3 {id n9_dolo}
* Leave them to it.  -> n9.dolo4

# n9.dolo1
> "Earl's been driving this route thirty years," you say, to nobody in particular. "He's late every night at Kerr Street. He's never once been late anywhere else."
> Silence on the 9. Dolores looks at Earl. Earl looks at the road.
dolores: ...Is that right, Earl?
earl: (after a very long time) That's right.
> She doesn't say anything. She moves seats. One seat. To the one right behind him.
{do flag:earlDolores=1; comp+2}
@end

# n9.dolo2
earl: Ask... ask her what?
> But he's already pulling over. He's already turning round in his seat, cap in his hands, sixty-three years old, in a Port Vellum Transit jacket at three in the morning.
earl: Dolores. Would you... there's a diner. On Kerr. Pancakes the size of a hubcap. Saturday. If you're not... if you'd...
dolores: Earl Mabry. I've been waiting eleven years for you to say "pancakes".
> She takes his hand. Nell, in the back seat, makes a small noise and puts both hands over her face. {if flag:nell=taught|flag:nell=fed}
{do flag:earlDolores=2; comp+3; xp:20:Pancakes}
@end

# n9.dolo3
earl: I can't. I can't. Thirty years. What if she says no. Then where am I? Then I'm a man who drives past her stop every night knowing.
> He talks about the pothole instead. Dolores laughs at something he says about it, a real laugh, and he looks like a man who's been given something.
@end

# n9.dolo4
> You leave them to it. The pothole on Halloran Street. Her son in the Navy. The rain. It's a kind of love. It's lasted thirty years. Perhaps it doesn't need you.
@end

# n9P.0
nell: You came. I mean, I came. I came to see. Everyone else came to see you burn. I came to see you not.
nell: I haven't touched anyone on the bus. I take the sleepers at the laundromat. Two mouthfuls. Like you said. I say "you nodded off". One of them said "thanks, love" and went back to sleep.
nell: Earl asked about you. He said, "your friend in the long coat, are they all right?" I said I didn't know. Are you?
* "Ask me at dawn."  -> n9P.1

# n9P.1
nell: At dawn. Okay. I'll be on the bus. He says goodnight to me at five. "Mind the step, sweetheart." I'll tell you what he says.
{do comp+1}
@next pf.hub
`,'c_nightbus');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  const n=f.nell;
  if(n==='taught'||n==='fed')o.push(['Nell','Still rides the 9, end to end, every night. She takes the sleepers at the laundromat, two mouthfuls, and says "you nodded off". At five, Earl says goodnight to her. She lifts her hand.']);
  else if(n==='gideon')o.push(['Box six, the Pawn & Coffin','Has a girl in it now, reading. Gideon has given her a job on the counter. She is very good at telling which customers are dead. She is learning which ones are kind.']);
  else if(n==='commanded')o.push(['Nell','Keeps the command. Nobody on the bus. She grows thin and careful and very polite, and in the spring she leaves the city for somewhere with longer nights.']);
  else if(n==='starving')o.push(['The back seat of the 9','Was empty by November. Earl says she got off at the depot one night and didn\'t get back on. He still says goodnight to the back seat at five.']);
  else if(n==='dead')o.push(['The 9','Earl Mabry put in for a day route in November. He doesn\'t drive nights any more. He doesn\'t say why.']);
  if(f.earlDolores===2)o.push(['A diner on Kerr Street','Saturday mornings: a bus driver and a night cleaner, pancakes the size of hubcaps. Thirty years late. Neither of them minds.']);
  return o;});
