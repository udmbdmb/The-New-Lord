'use strict';
/* THE NEW LORD — procedural 3D toon characters + portrait renderer */
(function(){
const NL=window.NL; const {M4,Geo,GLX,SH}=NL;
const PI=Math.PI;
const GEO=new Map();
function geo(key,fn){if(!GEO.has(key))GEO.set(key,fn());return GEO.get(key);}

class Node{
  constructor(name,pos){this.name=name;this.pos=pos||[0,0,0];this.rot=[0,0,0];this.scl=[1,1,1];this.kids=[];this.items=[];this.local=M4.ident();this.world=M4.ident();this.base=this.pos.slice();}
  add(n){this.kids.push(n);n.parent=this;return n;}
  item(key,fn,color,o){o=o||{};this.items.push({key,fn,color,two:!!o.two,emis:o.emis||null,mat:M4.trs(o.t||[0,0,0],o.r||[0,0,0],o.s||[1,1,1]),outline:o.outline!==false,tag:o.tag||null,alpha:o.alpha==null?1:o.alpha,M:new Float32Array(16)});return this;}
  update(pw){M4.trsInto(this.local,this.pos,this.rot,this.scl);if(pw)M4.mulInto(this.world,pw,this.local);else this.world.set(this.local);for(const k of this.kids)k.update(this.world);}
}

/* shared part geometry */
const G={
  sph:()=>geo('sph',()=>Geo.sphere(1,18,12)),
  sphLo:()=>geo('sphLo',()=>Geo.sphere(1,10,7)),
  hemi:()=>geo('hemi',()=>Geo.hemi(1,18,7)),
  box:()=>geo('box',()=>Geo.box(1,1,1)),
  cyl:()=>geo('cyl',()=>Geo.cyl(1,1,1,16)),
  cone:()=>geo('cone',()=>Geo.lathe([[0,0],[1,0],[1,0],[0.02,1],[0,1]],18)),
  torso:()=>geo('torso3',()=>Geo.lathe([[0,-0.03],[0.13,-0.01],[0.132,0.08],[0.127,0.17],[0.143,0.27],[0.168,0.37],[0.178,0.44],[0.166,0.5],[0.118,0.546],[0.052,0.571],[0,0.578]],24)),
  pelvis:()=>geo('pelvis',()=>Geo.lathe([[0,-0.13],[0.08,-0.12],[0.14,-0.06],[0.15,0.02],[0.13,0.07],[0,0.08]],18)),
  skirt:(len)=>geo('skirt'+len,()=>Geo.lathe([[0.152,0.1],[0.165,-0.04],[0.2,-0.3],[0.245,-len],[0.235,-len-0.012],[0.215,-len+0.02]],18,Math.PI*2-0.7,Math.PI*1.5+0.35)),
  limb:(r1,r2,len)=>geo('limb'+r1+'_'+r2+'_'+len,()=>Geo.capsule(r1,r2,len,12)),
  neck:()=>geo('neck2',()=>Geo.cyl(0.049,0.058,0.13,14,false)),
  brim:()=>geo('brim',()=>Geo.cyl(1,1,1,24)),
  canopy:()=>geo('canopy',()=>Geo.lathe([[0,-0.02],[0.98,-0.02],[1,0],[0.7,0.16],[0.3,0.27],[0,0.3]],16)),
  apronTop:()=>geo('apronTop',()=>Geo.lathe([[0.137,0.02],[0.145,0.2],[0.163,0.33],[0.176,0.41]],14,1.7,PI*1.5-0.85)),
  apronLow:()=>geo('apronLow',()=>Geo.lathe([[0.215,-0.56],[0.19,-0.3],[0.162,-0.05],[0.156,0.06]],16,2.3,PI*1.5-1.15)),
  shoe:()=>geo('shoe2',()=>Geo.param((u,v)=>{const th=u*PI*2,ph=v*PI;let x=Math.sin(ph)*Math.sin(th),y=Math.cos(ph),z=Math.sin(ph)*Math.cos(th);
    if(z>0){x*=1-0.3*z;y*=1-0.35*Math.max(0,z-0.2);}else{x*=1-0.08*(-z);}
    if(y<-0.35)y=-0.35+(y+0.35)*0.12;if(y>0&&z>-0.2)y*=0.8;return [x,y,z];},28,18)),
  // tapered tube with cloth folds that bunch toward the joints (u = around, v = top→bottom)
  limbF:(r1,r2,len,amp,k)=>geo('limbF2'+r1+'_'+r2+'_'+len+'_'+amp+'_'+k,()=>Geo.param((u,v)=>{const th=u*PI*2;
    const y=-v*len,cap=Math.sqrt(Math.max(0,Math.min(1,v/0.07,(1-v)/0.07)));let r=(r1+(r2-r1)*v)*(0.55+0.45*cap);
    const bunch=0.35*Math.exp(-((v-0.5)*(v-0.5))/0.012)+0.9*Math.exp(-((v-0.9)*(v-0.9))/0.008)+0.25;
    r*=1+amp*bunch*(Math.sin(th*k+v*9.0)*0.6+Math.sin(th*(k+3)-v*14.0+1.3)*0.4);
    return [r*Math.cos(th),y,-r*Math.sin(th)];},20,26)),
  skirtF:(len)=>geo('skirtF'+len,()=>{const a0=PI*1.5+0.35,arc=PI*2-0.7;return Geo.param((u,v)=>{const th=a0+u*arc;
    const y=0.1-v*(len+0.1),r0=0.152+(0.245-0.152)*Math.pow(v,0.9);const pleat=0.07*v*v*(0.6*Math.sin(u*arc*7)+0.4*Math.sin(u*arc*13+2.1));
    return [r0*(1+pleat)*Math.cos(th),y,-r0*(1+pleat)*Math.sin(th)];},40,16,true);}),
  collar:()=>geo('collar2',()=>Geo.lathe([[0.068,-0.07],[0.074,-0.01],[0.088,0.045],[0.104,0.07]],18,PI*2-1.2,PI*1.5+0.6)),
  beard:(st)=>{const f=CF;return ()=>geo('beard3_'+st+'_'+fkey(f),()=>withF(f,()=>{const B={full:[1.6,1.82,2.98,0.04],goatee:[0.5,2.08,2.98,0.03],stubble:[1.55,1.86,2.95,0.004],chinstrap:[1.6,2.3,2.98,0.02]}[st]||[1.6,1.82,2.98,0.04];
    return Geo.param((u,v)=>{const th=(u*2-1)*B[0],ph=B[1]+v*(B[2]-B[1]);const q=headDef(headUnit(th,ph));
      let o=1+B[3]*(0.55+0.45*v)+(st==='stubble'?0:0.006*Math.sin(th*21+ph*9));
      if(Math.abs(q[0])<0.024&&q[1]>0.055&&q[1]<0.083&&q[2]>0)o=0.97; // keep the mouth clear
      return [HC[0]+(q[0]-HC[0])*o,HC[1]+(q[1]-HC[1])*o,HC[2]+(q[2]-HC[2])*o];},30,14,false);}));},
  ring:()=>geo('ring',()=>Geo.param((u,v)=>{const a=u*PI*2,b=v*PI*2,R=1,r=0.12;return [(R+r*Math.cos(b))*Math.cos(a),(R+r*Math.cos(b))*Math.sin(a),r*Math.sin(b)];},28,8)),
  trap:()=>geo('trap',()=>Geo.sphere(1,14,9)),
  head:(f)=>()=>geo('head8_'+fkey(f),()=>withF(f,()=>Geo.param((u,v)=>headDef(headUnit(u*PI*2,v*PI)),72,52))),
  hair:(st)=>{const P={crop:[0.95,1.6,2.05,1.07,0.02],slick:[0.84,1.52,1.95,1.045,0],bun:[0.84,1.52,1.95,1.045,0],long:[0.88,1.72,2.25,1.06,0.015],fringe:[1.12,1.62,2.1,1.08,0.02],curly:[0.9,1.6,2.05,1.1,0.03],shaved:[0.98,1.62,2.2,1.012,0]}[st]||[0.95,1.6,2.05,1.07,0.02];
    const f=CF;return ()=>geo('hair4_'+st+'_'+fkey(f),()=>withF(f,()=>{const [pf,ps,pb,off,vol]=P;return Geo.param((u,v)=>{const th=u*PI*2,c=Math.cos(th),w=Math.pow(Math.abs(c),1.3);
      const cut=(c>0?ps+(pf-ps)*w:ps+(pb-ps)*w)+(st==='shaved'?0:0.05*Math.sin(th*17)+0.03*Math.sin(th*31+1)),ph=Math.max(0,v*cut);const q=headDef(headUnit(th,ph)),rid=st==='shaved'?0:0.012*(0.55+0.45*Math.sin(th*23+ph*5))*(0.4+0.6*Math.sin(ph*1.7)),o=off+vol*Math.cos(ph)+rid;
      return [HC[0]+(q[0]-HC[0])*o,HC[1]+(q[1]-HC[1])*o,HC[2]+(q[2]-HC[2])*o];},30,12);}));}
};
/* head: a sphere with a narrower jaw, forward chin and flatter face */
const HC=[0,0.118,0.004],HS=[0.088,0.118,0.104];
function headUnit(th,ph){return [Math.sin(ph)*Math.sin(th),Math.cos(ph),Math.sin(ph)*Math.cos(th)];}
const DEFF={jaw:1,nose:1,brow:1,cheek:1,chin:1,wide:1,long:1,noseW:1,lips:1,socket:1,hollow:0,crown:1};let CF=DEFF;
const fkey=f=>['jaw','nose','brow','cheek','chin','wide','long','noseW','lips','socket','hollow','crown'].map(k=>(f[k]==null?1:f[k]).toFixed(2)).join('_');
function withF(f,fn){const o=CF;CF=f;try{return fn();}finally{CF=o;}}
function faceBump(X,Y){const e=Math.exp;let b=0;
  b+=0.045*CF.brow*e(-((Y-0.27)*(Y-0.27))/0.004)*e(-(X*X)/0.35);                       // brow ridge
  b-=0.05*CF.socket*(e(-((X-0.37)*(X-0.37)+(Y-0.1)*(Y-0.1)*1.6)/0.018)+e(-((X+0.37)*(X+0.37)+(Y-0.1)*(Y-0.1)*1.6)/0.018)); // sockets
  b-=0.03*CF.hollow*(e(-((X-0.45)*(X-0.45)+(Y+0.32)*(Y+0.32))/0.02)+e(-((X+0.45)*(X+0.45)+(Y+0.32)*(Y+0.32))/0.02)); // hollow cheeks
  if(Y<0.24&&Y>-0.3){const ny=Math.min(1,Math.max(0,(0.2-Y)/0.36));b+=(0.035+0.2*ny*ny)*CF.nose*e(-(X*X)/((0.005+0.012*ny)*CF.noseW*CF.noseW))*(Y<-0.16?e(-((Y+0.16)*(Y+0.16))/0.0016):1);} // nose
  {const nx=0.1*CF.noseW;b+=0.028*(e(-((X-nx)*(X-nx)+(Y+0.15)*(Y+0.15))/0.004)+e(-((X+nx)*(X+nx)+(Y+0.15)*(Y+0.15))/0.004));} // nostril wings
  b+=CF.lips*(0.034*e(-(X*X)/0.06-((Y+0.37)*(Y+0.37))/0.004)+0.03*e(-(X*X)/0.05-((Y+0.46)*(Y+0.46))/0.004)); // lips
  b-=0.012*e(-(X*X)/0.08-((Y+0.415)*(Y+0.415))/0.0006);                          // lip parting
  b+=0.034*CF.chin*e(-(X*X)/0.05-((Y+0.78)*(Y+0.78))/0.012);                             // chin
  b+=0.02*CF.cheek*(e(-((X-0.5)*(X-0.5)+(Y+0.08)*(Y+0.08))/0.03)+e(-((X+0.5)*(X+0.5)+(Y+0.08)*(Y+0.08))/0.03)); // cheekbones
  return b;}
function headDef(p){let x=p[0],y=p[1],z=p[2];const t=y<0?-y:0;const fw=Math.max(0,z),fb=faceBump(x,y)*fw*fw;
  x*=(1-0.2*CF.jaw*Math.pow(t,1.3))*CF.wide;y*=CF.long;if(y>0)y*=CF.crown;
  if(z<0)z*=1-0.3*t+(y>0?0.07*y:0);else z*=1+0.05*t;
  if(y<0)y*=1.07;
  if(z>0.5)z=0.5+(z-0.5)*0.8;
  x*=1+0.05*Math.exp(-((y+0.05)*(y+0.05))/0.02)*Math.max(0,z);
  z+=fb;
  return [HC[0]+x*HS[0],HC[1]+y*HS[1],HC[2]+z*HS[2]];}
const ZC=new Map();
function faceZ(x,y){const k=fkey(CF)+'|'+x.toFixed(4)+','+y.toFixed(4);if(ZC.has(k))return ZC.get(k);let best=1e9,bz=0;
  for(let i=0;i<=90;i++)for(let j=0;j<=90;j++){const q=headDef(headUnit(-1.3+i/90*2.6,0.35+j/90*2.3));if(q[2]<0)continue;const d=(q[0]-x)*(q[0]-x)+(q[1]-y)*(q[1]-y);if(d<best){best=d;bz=q[2];}}
  ZC.set(k,bz);return bz;}

const DEF={skin:[.86,.72,.62],hair:{style:'crop',color:[.12,.09,.08]},eyes:[.12,.1,.09],eyeGlow:[0,0,0],height:1,width:1,
  shirt:[.2,.2,.24],pants:[.13,.13,.16],shoes:[.08,.07,.07],coat:null,apron:null,hat:null,glasses:null,gloves:null,tie:null,mustache:null,prop:null,alpha:1,brows:null,lips:[.55,.3,.3],scars:false};

/* every character gets a face of their own: a stable hash of their id nudges anything their spec leaves unset */
function hash01(str,k){let h=2166136261^k;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619);}h^=h>>>13;h=Math.imul(h,0x5bd1e995);h^=h>>>15;return ((h>>>0)%10000)/10000;}
function vary(id,spec){if(!id||!spec||spec.noVary)return spec;id=String(id).replace(/^x:/,'');if(id.startsWith('mirror_'))id='you';const r=k=>hash01(String(id),k)*2-1,f=Object.assign({},spec.face||{});
  // a face archetype first, then individual jitter on top
  const ARCH=[{wide:1.08,long:.95,jaw:.5,chin:.7,cheek:1.35},{wide:.93,long:1.08,jaw:1.15,chin:1.35},{wide:1.05,jaw:.4,chin:1.5,brow:1.35},
    {wide:1.02,jaw:1.45,chin:.75,cheek:1.5},{wide:.95,long:1.05,hollow:.9,cheek:1.6,socket:1.45},{},{nose:1.5,noseW:1.3,brow:1.3},{wide:.97,nose:.75,lips:1.4,chin:.9}];
  const A=ARCH[Math.floor(hash01(String(id),99)*ARCH.length)];
  const set=(k,amt,i)=>{if(f[k]==null)f[k]=(A[k]==null?1:A[k])*(1+amt*r(i));};
  set('jaw',0.18,1);set('nose',0.28,2);set('brow',0.3,3);set('cheek',0.2,4);set('chin',0.25,5);set('wide',0.035,6);set('long',0.035,7);set('noseW',0.22,8);set('lips',0.3,9);set('socket',0.2,10);set('crown',0.05,11);
  if(f.hollow==null)f.hollow=A.hollow!=null?A.hollow:Math.max(0,r(12))*0.5;
  if(spec.eyeGap==null)spec=Object.assign({},spec,{eyeGap:1+0.1*r(20)});
  const o=Object.assign({},spec,{face:f});
  if(spec.height==null)o.height=1+0.045*r(13);if(spec.width==null)o.width=1+0.06*r(14);
  if(spec.eyeSize==null)o.eyeSize=1+0.14*r(15);if(spec.eyeTilt==null)o.eyeTilt=0.12*r(16);if(spec.mouthW==null)o.mouthW=1+0.18*r(17);if(spec.earSize==null)o.earSize=1+0.15*r(18);
  if(spec.age==null){const hc=spec.hair&&spec.hair.color;o.age=hc&&hc[0]>0.6&&hc[1]>0.6&&hc[2]>0.6?0.85:0.25+0.35*(r(19)*0.5+0.5);}
  return o;}
function build(specIn){const prevF=CF;CF=Object.assign({},DEFF,specIn&&specIn.face||{});try{return buildInner(specIn);}finally{CF=prevF;}}
function buildInner(specIn){const hc0=()=>s.hair&&s.hair.color||[.1,.08,.07];
  const s=Object.assign({},DEF,specIn||{}); s.hair=Object.assign({},DEF.hair,specIn&&specIn.hair||{});
  const h=s.height*(s.fem?0.965:1), w0=s.width*(s.bulk||1), w=w0*(s.fem?0.9:1), wH=w0*(s.fem?1.04:1), skin=s.skin, A=s.alpha;
  const top=s.coat?s.coat.color:s.shirt;
  const root=new Node('root'); const body=root.add(new Node('body'));
  const hips=body.add(new Node('hips',[0,0.94*h,0]));
  hips.item('pelvis',G.pelvis,s.pants,{s:[wH,1,0.72]});
  if(s.coat){const tail=hips.add(new Node('tail',[0,0.1,0]));tail.item('skirtF',()=>G.skirtF(s.coat.length||0.56),s.coat.color,{t:[0,-0.1,0],s:[w,1,0.8],two:true});}
  hips.item('cyl',G.cyl,[.07,.055,.05],{t:[0,0.062,0],s:[0.151*w,0.026,0.111]});
  if(s.apron) hips.item('apronLow',G.apronLow,s.apron.color,{s:[w*1.04,1,0.8],two:true});
  const spine=hips.add(new Node('spine',[0,0.04,0]));
  spine.item('torso',G.torso,top,{s:[w,h,0.64]});
  // chest planes and shoulder blades break up the lathe so the silhouette reads as a ribcage, not a bottle
  for(const sd of [1,-1]){
    spine.item('sphLo',G.sphLo,top,{t:[0.058*sd*w,0.385*h,0.07],r:[0.2,0.2*sd,0],s:[0.084*w,0.058*h,0.03],outline:false});
    spine.item('sphLo',G.sphLo,top,{t:[0.064*sd*w,0.415*h,-0.074],r:[-0.12,-0.2*sd,0.1*sd],s:[0.07*w,0.08*h,0.04],outline:false});
    spine.item('sphLo',G.sphLo,top,{t:[0.134*sd*w,0.455*h,-0.008],s:[0.046*w,0.04*h,0.058],outline:false});}
  spine.item('sphLo',G.sphLo,top,{t:[0,0.17*h,-0.06],s:[0.11*w,0.12*h,0.04],outline:false});
  if(s.fem)for(const sd of [1,-1])spine.item('sphLo',G.sphLo,s.apron&&!s.coat?s.apron.color:top,{t:[0.05*sd*w,0.365*h,0.076],r:[0.3,0.15*sd,0],s:[0.05*w,0.044*h,0.034],outline:false});
  for(const sd of [1,-1])spine.item('trap',G.trap,top,{t:[0.098*sd*w,0.49*h,-0.01],r:[0,0,-0.38*sd],s:[0.098*w,0.034*h,0.066],outline:false});
  if(s.coat){ // lapels / collar
    spine.item('box',G.box,s.shirt,{t:[0,0.42,0.1],r:[-0.18,0,0],s:[0.075,0.16,0.02]});
    const lap=s.coat.color.map(v=>v*0.82),edge=s.coat.color.map(v=>Math.min(1,v*1.18+0.02));
    for(const sd of [1,-1]){
      // lower lapel: wide at the notch, tapering to the button
      spine.item('box',G.box,lap,{t:[0.058*sd,0.405,0.104],r:[-0.2,0.16*sd,0.36*sd],s:[0.052,0.22,0.016]});
      // rolled edge catching the light
      spine.item('box',G.box,edge,{t:[0.083*sd,0.41,0.112],r:[-0.2,0.16*sd,0.36*sd],s:[0.008,0.2,0.012],outline:false});
      // upper collar piece above the notch
      spine.item('box',G.box,lap,{t:[0.066*sd,0.5,0.078],r:[-0.5,0.3*sd,-0.25*sd],s:[0.032,0.048,0.012]});
    }
    // buttons
    for(let i=0;i<2;i++)spine.item('sphLo',G.sphLo,[.05,.045,.04],{t:[0.018,0.2-i*0.09,0.118],s:[0.009,0.009,0.005],outline:false});
  }
  if(s.tie) spine.item('box',G.box,s.tie,{t:[0,0.36,0.118],r:[-0.12,0,0],s:[0.035,0.2,0.012]});
  if(s.apron){spine.item('apronTop',G.apronTop,s.apron.color,{s:[w*1.06,h,0.64*1.12],two:true});
    if(s.apron.stain) spine.item('sphLo',G.sphLo,s.apron.stain,{t:[0.04,0.17*h,0.104],s:[0.05,0.04,0.006],outline:false});}
  const neck=spine.add(new Node('neck',[0,0.54*h,0]));
  neck.item('neck',G.neck,skin,{t:[0,-0.02,0]});
  if(s.coat&&s.coat.collar) neck.item('collar',G.collar,s.coat.color,{t:[0,-0.02,-0.012],s:[1.05,1,0.95],two:true});
  const head=neck.add(new Node('head',[0,0.063,0.004]));head.scl=[1.0,1.0,1.0];
  head.item('head',G.head(CF),skin,{tag:'skin'});
  const es=s.earSize||1;head.item('sphLo',G.sphLo,skin,{t:[0.086,0.112,-0.006],s:[0.014*es,0.029*es,0.012*es]});
  head.item('sphLo',G.sphLo,skin,{t:[-0.086,0.112,-0.006],s:[0.014*es,0.029*es,0.012*es]});
  const eyeCol=s.eyes, glow=s.eyeGlow, ez=faceZ(0.033*(s.eyeGap||1),0.128);
  const egx=0.033*(s.eyeGap||1);const eyeL=head.add(new Node('eyeL',[egx,0.128,ez-0.0035])), eyeR=head.add(new Node('eyeR',[-egx,0.128,ez-0.0035]));
  const esz=s.eyeSize||1;eyeL.rot=[0,0,(s.eyeTilt||0)];eyeR.rot=[0,0,-(s.eyeTilt||0)];
  const scl=[.5+skin[0]*.25,.48+skin[1]*.25,.46+skin[2]*.25];[eyeL,eyeR].forEach((e,i)=>{e.item('sph',G.sph,scl,{s:[0.0145,0.0088,0.006],outline:false});e.item('sph',G.sph,(i===1&&s.eyes2)?s.eyes2:eyeCol,{t:[0,-0.0005,0.005],s:[0.009,0.009,0.0045],emis:glow,outline:false,tag:'iris'});e.item('sph',G.sph,[.03,.02,.03],{t:[0,-0.0005,0.0075],s:[0.0038,0.0038,0.002],outline:false});
    e.item('box',G.box,[skin[0]*.78,skin[1]*.66,skin[2]*.66],{t:[0,0.0095,0.003],r:[0.25,0,0],s:[0.035,0.006,0.012],outline:false});});
  const brow=s.brows||s.hair.color, bz=faceZ(0.037,0.152);
  // brows: a soft base and tapering strands along an arch, thick at the inner end, wispy at the tail
  const bw=CF.brow||1;
  for(const sd of [1,-1]){
    head.item('box',G.box,[brow[0]*.7+skin[0]*.3,brow[1]*.7+skin[1]*.3,brow[2]*.7+skin[2]*.3],{t:[0.034*sd,0.1515,faceZ(0.034,0.1515)+0.0005],r:[0,0.25*sd,-0.1*sd],s:[0.036,0.0062*bw,0.004],outline:false,tag:sd>0?'browL':'browR'});
    const NS=7;for(let i=0;i<NS;i++){const u=i/(NS-1),x=0.016+u*0.036,y=0.1495+Math.sin(Math.min(1,u*1.35)*PI*0.5)*0.0045-Math.max(0,u-0.75)*0.012,
      th=(0.0042-u*0.0026)*bw,ang=(u<0.2?0.55:u<0.7?0.12:-0.32)-0.05;
      const c=[brow[0]*(0.9-0.15*(1-u)),brow[1]*(0.9-0.15*(1-u)),brow[2]*(0.9-0.15*(1-u))];
      head.item('box',G.box,c,{t:[x*sd,y,faceZ(x,y)+0.0012],r:[0,0.28*sd*(0.6+u*0.7),ang*sd],s:[0.0105,th,0.0035],outline:false});}}
  const mz=faceZ(0,0.0695);
  const mouth=head.add(new Node('mouth',[0,0.0695,mz]));
  mouth.item('box',G.box,[s.lips[0]*.45+skin[0]*.2,s.lips[1]*.4+skin[1]*.15,s.lips[2]*.4+skin[2]*.15],{t:[0,0,-0.002],s:[0.026*(s.mouthW||1),0.0028,0.006],outline:false});
  mouth.item('sph',G.sph,[s.lips[0]*.6+skin[0]*.4,s.lips[1]*.55+skin[1]*.45,s.lips[2]*.55+skin[2]*.45],{t:[0,-0.004,-0.0035],s:[0.019*(s.mouthW||1),0.0075*(CF.lips||1),0.005],outline:false,tag:'skin'});
  if(s.beard){const bc=s.beard==='stubble'?[hc0()[0]*.5+skin[0]*.42,hc0()[1]*.5+skin[1]*.38,hc0()[2]*.5+skin[2]*.38]:(s.beardColor||hc0());
    head.item('beard_'+s.beard,G.beard(s.beard),bc,{outline:s.beard!=='stubble',two:s.beard!=='stubble'});}
  if(s.mustache){[1,-1].forEach(k=>head.item('sph',G.sph,s.mustache,{t:[0.013*k,0.08,faceZ(0.013,0.08)-0.002],r:[0,0.25*k,0.3*k],s:[0.018,0.0068,0.007],outline:false}));}
  if(s.mask==='surgical'){head.item('sph',G.sph,[.62,.78,.88],{t:[0,0.072,faceZ(0,0.075)-0.03],s:[0.074,0.042,0.05],outline:false});[1,-1].forEach(k=>head.item('box',G.box,[.85,.88,.9],{t:[0.07*k,0.1,0.0],s:[0.004,0.004,0.12],outline:false}));}
  if(s.mask==='porcelain'){const mz=faceZ(0,0.13);head.item('sph',G.sph,[.95,.94,.9],{t:[0,0.132,mz-0.03],s:[0.088,0.033,0.05],outline:false});
    [0.033,-0.033].forEach(x=>head.item('sph',G.sph,[.05,.03,.05],{t:[x,0.129,faceZ(x,0.129)+0.008],s:[0.013,0.009,0.004],outline:false}));head.item('box',G.box,[.85,.68,.25],{t:[0.02,0.14,mz+0.02],r:[0,0,0.6],s:[0.003,0.05,0.004],outline:false});}
  if((s.age||0)>0.45){const ag=Math.min(1,(s.age-0.45)/0.45),ln=[skin[0]*.72,skin[1]*.6,skin[2]*.6];
    for(const sd of [1,-1]){// nasolabial folds
      head.item('box',G.box,ln,{t:[0.026*sd,0.085,faceZ(0.026,0.085)+0.0004],r:[0.15,0.22*sd,0.38*sd],s:[0.0022,0.03,0.003],outline:false,alpha:0.5+0.5*ag});
      if(ag>0.3)for(let i=0;i<2;i++)head.item('box',G.box,ln,{t:[0.061*sd,0.13-i*0.007,faceZ(0.061,0.13)-0.001],r:[0,0.6*sd,(0.35-i*0.5)*sd],s:[0.0016,0.011,0.003],outline:false});}
    if(ag>0.5)for(let i=0;i<2;i++)head.item('box',G.box,ln,{t:[0,0.172+i*0.009,faceZ(0,0.172+i*0.009)+0.0004],s:[0.04-i*0.008,0.0016,0.003],outline:false});}
  if(s.scars) head.item('box',G.box,[.55,.25,.25],{t:[0.05,0.1,faceZ(0.05,0.1)],r:[0,0.3,0.6],s:[0.006,0.06,0.004],outline:false});
  // hair: a shell fitted to the head, cut at a hairline that varies front to back
  const hc=s.hair.color, st=s.hair.style;
  if(st!=='bald'){
    if(st==='shaved') head.item('hshaved',G.hair('shaved'),[hc[0]*.55+skin[0]*.45,hc[1]*.55+skin[1]*.45,hc[2]*.55+skin[2]*.45],{outline:false});
    else head.item('h'+st,G.hair(st),hc);
    if(st==='long'){head.item('limbF',()=>G.limbF(0.06,0.07,0.24,0.06,7),hc,{t:[0,0.17,-0.05],s:[1.45,1,0.75]});[1,-1].forEach(k=>head.item('limbF',()=>G.limbF(0.026,0.02,0.2,0.08,5),hc,{t:[0.074*k,0.155,-0.012],r:[0.1,0,0.08*k],s:[0.75,1,1.6]}));}
    if(st==='bun'){head.item('sph',G.sph,hc,{t:[0,0.2,-0.1],s:[0.05,0.048,0.048]});}
    if(st==='curly'){let n=0;for(let r=0;r<4;r++){const ph=0.18+r*0.32,cnt=[5,9,12,13][r];for(let i=0;i<cnt;i++){const th=i/cnt*PI*2+r*0.4,c=Math.cos(th);if(r>=2&&c>0.45)continue;
      const q=headDef(headUnit(th,ph)),o=1.06;const sz=0.019+0.004*Math.sin(n*2.3);n++;
      head.item('sphLo',G.sphLo,[hc[0]*(0.94+0.12*Math.sin(n*1.7)),hc[1]*(0.94+0.12*Math.sin(n*1.7)),hc[2]*(0.94+0.12*Math.sin(n*1.7))],{t:[HC[0]+(q[0]-HC[0])*o,HC[1]+(q[1]-HC[1])*o,HC[2]+(q[2]-HC[2])*o],s:[sz,sz*0.9,sz],outline:false});}}}
  }
  // hats
  if(s.hat){const hcol=s.hat.color||[.15,.13,.12],t=s.hat.type;
    if(t==='fedora'||t==='widebrim'){const br=t==='widebrim'?0.172:0.15;
      head.item('cyl',G.cyl,hcol,{t:[0,0.19,-0.005],s:[0.096,0.095,0.108]});
      head.item('brim',G.brim,hcol,{t:[0,0.19,-0.005],s:[br,0.01,br*1.05]});
      head.item('cyl',G.cyl,s.hat.band||[.08,.06,.06],{t:[0,0.2,-0.005],s:[0.098,0.022,0.11],outline:false});}
    if(t==='paper'){head.item('box',G.box,[.94,.93,.9],{t:[0,0.225,-0.005],s:[0.2,0.07,0.12]});head.item('box',G.box,[.7,.15,.15],{t:[0,0.205,-0.005],s:[0.202,0.012,0.122],outline:false});}
    if(t==='chauffeur'){head.item('cyl',G.cyl,hcol,{t:[0,0.185,-0.005],s:[0.098,0.055,0.108]});head.item('brim',G.brim,hcol,{t:[0,0.24,-0.01],s:[0.112,0.014,0.118]});head.item('box',G.box,[.05,.05,.05],{t:[0,0.18,0.1],r:[0.4,0,0],s:[0.16,0.008,0.07]});}
  }
  if(s.glasses){const t=s.glasses.type,gz=faceZ(0.033,0.128);
    if(t==='sun'){[0.033,-0.033].forEach(x=>head.item('sph',G.sph,[.04,.04,.05],{t:[x,0.128,gz+0.007],s:[0.027,0.019,0.006],outline:false}));head.item('box',G.box,[.1,.1,.1],{t:[0,0.135,gz+0.01],s:[0.026,0.005,0.005],outline:false});}
    else{[0.033,-0.033].forEach(x=>{head.item('ring',G.ring,[.32,.26,.16],{t:[x,0.128,gz+0.009],s:[0.019,0.016,0.02],outline:false});});head.item('box',G.box,[.32,.26,.16],{t:[0,0.13,gz+0.012],s:[0.026,0.003,0.003],outline:false});[1,-1].forEach(k=>head.item('box',G.box,[.32,.26,.16],{t:[0.054*k,0.13,gz-0.02],r:[0,0.5*k,0],s:[0.002,0.003,0.05],outline:false}));}
  }
  // arms
  const sleeve=s.coat?s.coat.color:s.shirt, hand=s.gloves||skin;
  const mkArm=(side)=>{const sx=side==='L'?1:-1;
    const sh=spine.add(new Node('sh'+side,[0.158*sx*w,0.458*h,0]));
    sh.item('sph',G.sph,sleeve,{t:[0.002*sx,-0.016,0],s:[0.046,0.056,0.05]});
    sh.item('limbF',()=>G.limbF(0.052,0.046,0.285,s.coat?0.05:0.035,5),sleeve,{s:[1,h,1]});
    const el=sh.add(new Node('el'+side,[0,-0.28*h,0]));
    el.item('limbF',()=>G.limbF(0.046,0.038,0.26,s.coat?0.06:0.04,6),sleeve,{s:[1,h,1]});
    if(s.coat) el.item('cyl',G.cyl,s.shirt,{t:[0,-0.25*h,0],s:[0.04,0.025,0.04],outline:false});
    const hd=el.add(new Node('hand'+side,[0,-0.27*h,0]));
    hd.item('sph',G.sph,hand,{t:[0,-0.04,0.004],s:[0.028,0.046,0.02]});
    hd.item('limb',()=>G.limb(0.0085,0.007,0.03),hand,{t:[-0.024*sx,-0.02,0.016],r:[0.35,0,0.55*sx],outline:false});
    [-0.017,-0.006,0.005,0.0155].forEach((fx,i)=>hd.item('limb',()=>G.limb(0.0068,0.0058,0.038-Math.abs(i-1.3)*0.004),hand,{t:[fx*sx,-0.078,0.002],r:[0.28+i*0.04,0,-fx*sx*1.5],outline:false}));
    return {sh,el,hd};};
  const aL=mkArm('L'),aR=mkArm('R');
  const mkLeg=(side)=>{const sx=side==='L'?1:-1;
    const hp=hips.add(new Node('hip'+side,[0.092*sx*w,-0.03,0]));
    hp.item('limbF',()=>G.limbF(0.074,0.056,0.45,0.035,5),s.pants,{s:[w,h,w]});
    const kn=hp.add(new Node('kn'+side,[0,-0.44*h,0]));
    kn.item('limbF',()=>G.limbF(0.058,0.043,0.44,0.05,6),s.pants,{s:[1,h,1]});
    const an=kn.add(new Node('an'+side,[0,-0.44*h,0]));
    an.item('shoe',G.shoe,s.shoes,{t:[0,-0.002,0.045],s:[0.052,0.062,0.12]});
    an.item('box',G.box,[s.shoes[0]*.45,s.shoes[1]*.42,s.shoes[2]*.42],{t:[0,-0.033,0.045],s:[0.09,0.011,0.225],outline:false});
    return {hp,kn,an};};
  const lL=mkLeg('L'),lR=mkLeg('R');
  // props
  if(s.prop==='cup'){aR.hd.item('cyl',G.cyl,[.93,.9,.84],{t:[0,-0.11,0.03],s:[0.034,0.11,0.034]});aR.hd.item('cyl',G.cyl,[.3,.2,.15],{t:[0,-0.02,0.03],s:[0.036,0.012,0.036],outline:false});}
  if(s.prop==='umbrella'){aR.hd.item('cyl',G.cyl,[.12,.1,.1],{t:[0,-0.08,0.0],s:[0.009,0.95,0.009]});aR.hd.item('canopy',G.canopy,[.06,.06,.08],{t:[0,0.74,0],s:[0.5,0.48,0.5]});}
  if(s.prop==='flashlight'){aR.hd.item('cyl',G.cyl,[.15,.15,.17],{t:[0,-0.06,0.02],r:[PI/2,0,0],s:[0.022,0.17,0.022]});}
  const items=[];(function walk(n){n.items.forEach(it=>items.push({node:n,it}));n.kids.forEach(walk);})(root);
  // material per part: skin, hair, wet eyes, polished leather; everything else is cloth
  const near=(c,d)=>c&&d&&Math.abs(c[0]-d[0])+Math.abs(c[1]-d[1])+Math.abs(c[2]-d[2])<0.12;
  items.forEach(({node,it})=>{if(it.mt!=null)return;const nm=node.name;
    if(nm==='eyeL'||nm==='eyeR')it.mt=it.key==='box'?1:3;
    else if(it.key==='head'||it.tag==='skin'||near(it.color,skin)&&!(s.gloves&&nm.startsWith('hand')))it.mt=1;
    else if(it.key.startsWith('h')&&it.key!=='head'||it.color===s.hair.color)it.mt=2;
    else if(it.color===s.shoes||(s.gloves&&it.color===s.gloves))it.mt=4;
    else it.mt=0;});
  return {root,body,hips,tail:hips.kids.find(k=>k.name==='tail')||null,spine,neck,head,mouth,eyeL,eyeR,aL,aR,lL,lR,items,spec:s};
}

/* ---------------- poses ---------------- */
const K=['body.rx','body.y','hips.y','hips.rx','hips.ry','hips.rz','spine.rx','spine.ry','spine.rz','neck.rx','neck.ry','head.rx','head.ry','head.rz',
 'shL.rx','shL.ry','shL.rz','elL.rx','shR.rx','shR.ry','shR.rz','elR.rx','hipL.rx','hipL.rz','knL.rx','anL.rx','hipR.rx','hipR.rz','knR.rx','anR.rx'];
function zero(){const o={};K.forEach(k=>o[k]=0);o['shL.rz']=0.045;o['shR.rz']=-0.045;o['shL.rx']=0.04;o['shR.rx']=0.04;o['elL.rx']=-0.2;o['elR.rx']=-0.2;return o;}
const POSES={
  idle(a,t){const o=zero();const b=a.breathes?Math.sin(t*(a.panic?5:1.7)):0;o['spine.rx']=b*0.012;o['shL.rz']+=b*0.01;o['shR.rz']-=b*0.01;
    // weight on one leg: the other knee eases, the hips tip, the shoulders answer
    const side=a.weight||1,sway=Math.sin(t*0.6+a.seed)*0.015;
    o['hips.rz']=0.045*side+sway;o['spine.rz']=-0.03*side-sway*0.6;o['neck.rx']=0.04;o['head.rz']=0.02*side;
    o['hipL.rz']=-0.045*side-sway;o['hipR.rz']=-0.045*side-sway;
    if(side>0){o['knR.rx']=0.16;o['hipR.rx']=-0.06;o['anR.rx']=-0.08;}else{o['knL.rx']=0.16;o['hipL.rx']=-0.06;o['anL.rx']=-0.08;}
    // some people keep their hands in their pockets
    const pv=a.idleVar||0;
    if(pv>=1){o['shR.rx']=0.18;o['shR.rz']=-0.1;o['shR.ry']=0.25;o['elR.rx']=-0.62;}
    if(pv>=2){o['shL.rx']=0.18;o['shL.rz']=0.1;o['shL.ry']=-0.25;o['elL.rx']=-0.62;}
    if(!a.breathes){o['hips.rz']*=0.5;o['spine.rz']*=0.5;}return o;},
  walk(a,t){const o=zero();const p=a.phase;
    o['hipL.rx']=-Math.sin(p)*0.48;o['hipR.rx']=Math.sin(p)*0.48;
    o['knL.rx']=0.12+Math.max(0,Math.sin(p+1.3))*0.85;o['knR.rx']=0.12+Math.max(0,Math.sin(p+1.3+PI))*0.85;
    o['anL.rx']=-0.1;o['anR.rx']=-0.1;
    o['shL.rx']=Math.sin(p)*0.38;o['shR.rx']=-Math.sin(p)*0.38;o['elL.rx']=-0.3;o['elR.rx']=-0.3;
    o['hips.y']=-Math.abs(Math.cos(p))*0.035+0.01;o['spine.ry']=Math.sin(p)*0.08;o['hips.ry']=-Math.sin(p)*0.06;o['spine.rx']=0.04;return o;},
  lie(a,t){const o=zero();o['body.rx']=-PI/2;o['body.y']=0.13;o['shL.rz']=0.35;o['shR.rz']=-0.35;o['head.ry']=0.4;o['hipL.rz']=0.05;o['hipR.rz']=-0.08;o['knL.rx']=0.25;return o;},
  crouch(a,t){const o=zero();o['hips.y']=-0.4;o['hipL.rx']=-1.3;o['hipR.rx']=-1.1;o['knL.rx']=2.1;o['knR.rx']=1.9;o['anL.rx']=-0.75;o['anR.rx']=-0.75;
    o['spine.rx']=0.45;o['neck.rx']=0.15;o['head.rx']=0.25;o['shL.rx']=-0.7;o['elL.rx']=-0.6;o['shR.rx']=-0.9;o['elR.rx']=-0.4;o['hipL.rz']=0.15;o['hipR.rz']=-0.15;return o;},
  sit(a,t){const o=POSES.idle(a,t);o['hips.y']=-0.47;o['hipL.rx']=-1.5;o['hipR.rx']=-1.45;o['knL.rx']=1.5;o['knR.rx']=1.6;o['hipL.rz']=0.08;o['hipR.rz']=-0.08;
    o['spine.rx']=0.22;o['head.rx']=0.25;o['shL.rx']=-0.45;o['elL.rx']=-0.9;o['shR.rx']=-0.4;o['elR.rx']=-1.0;return o;},
  hang(a,t){const o=zero();const sw=Math.sin(t*0.9)*0.05;o['body.y']=0.06;o['hips.rz']=sw;o['spine.rz']=sw*0.5;
    o['shL.rx']=-2.95;o['shL.rz']=-0.18;o['elL.rx']=-0.15;o['shR.rx']=-2.95;o['shR.rz']=0.18;o['elR.rx']=-0.15;
    o['head.rx']=0.4+Math.sin(t*0.5)*0.05;o['neck.rx']=0.1;o['knL.rx']=0.2;o['knR.rx']=0.12;o['anL.rx']=0.4;o['anR.rx']=0.45;
    const b=Math.sin(t*4.5);o['spine.rx']=b*0.015;return o;},
  phone(a,t){const o=POSES.idle(a,t);o['shR.rx']=-0.35;o['shR.rz']=-0.55;o['shR.ry']=0.6;o['elR.rx']=-2.4;o['head.rz']=-0.12;return o;},
  hold(a,t){const o=POSES.idle(a,t);o['shR.rx']=-0.2;o['elR.rx']=-1.35;return o;},
  umbrella(a,t){const o=POSES.idle(a,t);o['shR.rx']=-0.3;o['elR.rx']=-1.25;o['shR.rz']=-0.12;return o;},
  arms(a,t){const o=POSES.idle(a,t);o['shL.rx']=-0.5;o['elL.rx']=-1.6;o['shR.rx']=-0.5;o['elR.rx']=-1.6;o['shL.ry']=-0.5;o['shR.ry']=0.5;return o;},
  reach(a,t){const o=POSES.idle(a,t);o['shR.rx']=-1.3;o['elR.rx']=-0.2;o['spine.rx']=0.12;return o;},
  hunch(a,t){const o=POSES.idle(a,t);o['spine.rx']=0.3;o['neck.rx']=0.2;o['head.rx']=0.2;o['shL.rx']=-0.4;o['elL.rx']=-1.5;o['shR.rx']=-0.4;o['elR.rx']=-1.5;o['shL.ry']=-0.5;o['shR.ry']=0.5;return o;},
  lunge(a,t){const o=zero();o['spine.rx']=0.35;o['hipL.rx']=-0.7;o['knL.rx']=0.8;o['hipR.rx']=0.4;o['knR.rx']=0.3;o['shL.rx']=-1.3;o['shR.rx']=-1.4;o['elL.rx']=-0.4;o['elR.rx']=-0.3;o['hips.y']=-0.12;o['head.rx']=-0.2;return o;},
  slump(a,t){const o=zero();o['body.rx']=-0.05;o['hips.y']=-0.62;o['hipL.rx']=-1.45;o['hipR.rx']=-1.35;o['knL.rx']=0.4;o['knR.rx']=0.6;o['spine.rx']=0.5;o['head.rx']=0.6;o['shL.rz']=0.3;o['shR.rz']=-0.3;o['elL.rx']=-0.4;return o;}
};

class Actor{
  constructor(id,spec,o){
    o=o||{};this.id=id;this.spec=spec;this.seed=Math.random()*10;this.weight=Math.random()<.5?1:-1;this.idleVar=String(id)==='you'||String(id).startsWith('mirror_')?0:(Math.random()<.45?0:Math.random()<.6?1:2);this.breathes=!!o.breathes;this.m=build(vary(id,spec));this.x=o.x||0;this.z=o.z||0;this.ry=o.ry||0;this.y=0;
    this.pose=o.pose||'idle';this.cur=POSES[this.pose](this,0);this.blendK=8;this.phase=0;this.speed=0;
    this.panic=false;this.talking=false;this.look=null;this.shiver=0;this.flash=0;this.blink=0;this.nextBlink=2+Math.random()*3;
    this.visible=true;this.path=null;this.walkSpeed=o.walkSpeed||1.9;this.onArrive=null;this.alpha=spec.alpha==null?1:spec.alpha;this.shadow=o.shadow!==false;this.blinks=o.blinks!==false;
  }
  rebuild(spec){this.spec=spec;this.m=build(vary(this.id,spec));this.alpha=spec.alpha==null?1:spec.alpha;}
  setPose(p,k){if(!POSES[p])return;this.pose=p;this.blendK=k||8;}
  update(dt,t){
    // movement
    if(this.path&&this.path.length){
      const tgt=this.path[0],dx=tgt[0]-this.x,dz=tgt[1]-this.z,d=Math.hypot(dx,dz),step=this.walkSpeed*dt;
      if(d<=step){this.x=tgt[0];this.z=tgt[1];this.path.shift();if(!this.path.length){this.path=null;this.speed=0;const cb=this.onArrive;this.onArrive=null;if(cb)cb();}}
      else{this.x+=dx/d*step;this.z+=dz/d*step;const want=Math.atan2(dx,dz);this.ry=angLerp(this.ry,want,1-Math.exp(-dt*12));this.speed=this.walkSpeed;}
    } else this.speed=0;
    if(this.faceTo&&!this.path){const want=Math.atan2(this.faceTo[0]-this.x,this.faceTo[1]-this.z);this.ry=angLerp(this.ry,want,1-Math.exp(-dt*7));if(Math.abs(angDiff(this.ry,want))<0.02)this.faceTo=null;}
    this.phase+=dt*this.speed/1.25*PI*2;
    const pname=this.speed>0?'walk':this.pose;
    const tgt=POSES[pname](this,t);
    const k=1-Math.exp(-dt*(this.speed>0?12:this.blendK));
    for(const key of K){this.cur[key]+=(tgt[key]-this.cur[key])*k;}
    const c=this.cur,m=this.m;
    // look-at
    let lookY=0,lookX=0;
    const lk=typeof this.look==='function'?this.look():this.look;
    if(lk&&this.pose!=='lie'&&this.pose!=='hang'&&this.pose!=='slump'){
      const dx=lk[0]-this.x,dz=lk[2]-this.z;let a=Math.atan2(dx,dz)-this.ry;a=angDiff(0,a);
      lookY=Math.max(-1.0,Math.min(1.0,a));const dist=Math.hypot(dx,dz)||1;lookX=Math.max(-0.4,Math.min(0.4,-Math.atan2((lk[1]||1.6)-1.6,dist)));
    }
    this.lookCur=this.lookCur||[0,0];this.lookCur[0]+=(lookY-this.lookCur[0])*Math.min(1,dt*6);this.lookCur[1]+=(lookX-this.lookCur[1])*Math.min(1,dt*6);
    const talkNod=this.talking?Math.sin(t*7.3)*0.035+Math.sin(t*3.1)*0.02:0;
    const sh=this.shiver>0?(Math.random()-.5)*0.03*this.shiver:0;
    m.root.pos=[this.x,this.y,this.z];m.root.rot=[0,this.ry,0];
    m.body.rot=[c['body.rx'],0,0];m.body.pos=[0,c['body.y'],0];
    m.hips.pos=[0,m.hips.base[1]+c['hips.y'],0];m.hips.rot=[c['hips.rx'],c['hips.ry'],c['hips.rz']+sh];
    m.spine.rot=[c['spine.rx'],c['spine.ry'],c['spine.rz']];
    if(m.tail){// coat tails lag behind the stride and swing when you stop
      const seated=this.pose==='sit'||this.pose==='slump'||this.pose==='crouch';
      const want=seated?-0.25:this.speed>0?0.17+Math.sin(this.phase*2)*0.045:0;
      this.tailV=(this.tailV||0)+((want-(this.tailA||0))*60-(this.tailV||0)*9)*Math.min(dt,0.05);this.tailA=(this.tailA||0)+this.tailV*Math.min(dt,0.05);
      m.tail.rot=[this.tailA,0,-c['hips.rz']*0.6+(this.speed>0?Math.sin(this.phase)*0.03:0)];}
    m.neck.rot=[c['neck.rx']+this.lookCur[1]*0.4,c['neck.ry']+this.lookCur[0]*0.45,0];
    m.head.rot=[c['head.rx']+this.lookCur[1]*0.6+talkNod,c['head.ry']+this.lookCur[0]*0.55,c['head.rz']+sh];
    m.aL.sh.rot=[c['shL.rx'],c['shL.ry'],c['shL.rz']];m.aL.el.rot=[c['elL.rx'],0,0];
    m.aR.sh.rot=[c['shR.rx'],c['shR.ry'],c['shR.rz']];m.aR.el.rot=[c['elR.rx'],0,0];
    m.lL.hp.rot=[c['hipL.rx'],0,c['hipL.rz']];m.lL.kn.rot=[c['knL.rx'],0,0];m.lL.an.rot=[c['anL.rx'],0,0];
    m.lR.hp.rot=[c['hipR.rx'],0,c['hipR.rz']];m.lR.kn.rot=[c['knR.rx'],0,0];m.lR.an.rot=[c['anR.rx'],0,0];
    // face
    if(this.blinks){this.nextBlink-=dt;if(this.nextBlink<=0){this.blink=0.14;this.nextBlink=(this.breathes?2.5:7)+Math.random()*4;}}
    if(this.blink>0)this.blink-=dt;const ey=this.blink>0?0.12:1;
    const ez2=m.spec.eyeSize||1;m.eyeL.scl=[ez2,ey*ez2,1];m.eyeR.scl=[ez2,ey*ez2,1];
    m.mouth.scl=[1,this.talking?1+Math.abs(Math.sin(t*14))*2.6*(0.5+0.5*Math.sin(t*3.3)):1,1];
    if(this.flash>0)this.flash=Math.max(0,this.flash-dt*2);
    m.root.update(null);
    for(const e of m.items) M4.mulInto(e.it.M,e.node.world,e.it.mat);
  }
  headPos(){const w=this.m.head.world;return [w[12],w[13]+0.12,w[14]];}
  facePos(){const w=this.m.head.world;return M4.xf(w,[0,0.11,0.12]);}
}
function angDiff(a,b){let d=b-a;while(d>PI)d-=PI*2;while(d<-PI)d+=PI*2;return d;}
function angLerp(a,b,t){return a+angDiff(a,b)*t;}

/* ---------------- toon draw (shared) ---------------- */
const _nm=new Float32Array(9);
function drawActors(glx,actors,VP,cam){
  const gl=glx.gl,P=glx.prog('toon',SH.TOON_VS,SH.TOON_FS);
  gl.useProgram(P.p);
  gl.uniformMatrix4fv(P.u.uVP,false,VP);
  gl.uniform3fv(P.u.uCamDir,cam.dir);gl.uniform3fv(P.u.uSky,cam.sky);gl.uniform3fv(P.u.uGround,cam.ground);
  gl.uniform3fv(P.u.uInk,cam.ink||[0.05,0.03,0.06]);gl.uniform3fv(P.u.uKeyDir,cam.keyDir||[0.3,1,0.5]);gl.uniform3fv(P.u.uKeyCol,cam.keyCol||[0.15,0.15,0.15]);
  gl.uniform1f(P.u.uBright,cam.bright==null?1:cam.bright);
  gl.uniform3fv(P.u.uShT,cam.shT||[.93,.95,1.04]);gl.uniform3fv(P.u.uHiT,cam.hiT||[1.04,1.,.95]);gl.uniform1f(P.u.uSatA,cam.sat==null?.9:cam.sat);gl.uniform1f(P.u.uFloorY,cam.floorY||0);
  glx.setLights(P,cam.lights||[],cam.bright);
  gl.enable(gl.CULL_FACE);
  for(const a of actors){ if(!a.visible) continue;
    const alpha=a.alpha;
    if(alpha<1){gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);} else gl.disable(gl.BLEND);
    gl.uniform3fv(P.u.uRim,a.rim||cam.rim||[0.25,0.3,0.4]);gl.uniform1f(P.u.uFlash,a.flash||0);
    for(const pass of [0,1]){
      gl.cullFace(pass===0?gl.BACK:gl.FRONT);
      gl.uniform1f(P.u.uIsOutline,pass);
      for(const e of a.m.items){const it=e.it; if(pass===1&&!it.outline) continue;
        if(it.two){if(pass===0)gl.disable(gl.CULL_FACE);else gl.enable(gl.CULL_FACE);} else gl.enable(gl.CULL_FACE);
        const mesh=glx.meshFor(it.fn());
        gl.uniformMatrix4fv(P.u.uM,false,it.M);M4.normalInto(_nm,it.M);gl.uniformMatrix3fv(P.u.uNM,false,_nm);
        gl.uniform1f(P.u.uOutline,pass===1?(cam.outline||0.012):0);
        gl.uniform3fv(P.u.uColor,it.color);gl.uniform1f(P.u.uMat,it.mt||0);gl.uniform3fv(P.u.uEmis,it.emis||[0,0,0]);gl.uniform1f(P.u.uAlpha,alpha*it.alpha);
        gl.bindVertexArray(mesh.vao);gl.drawElements(gl.TRIANGLES,mesh.count,gl.UNSIGNED_INT,0);
      }
    }
  }
  gl.bindVertexArray(null);gl.cullFace(gl.BACK);gl.disable(gl.BLEND);
}

/* ---------------- portrait renderer ---------------- */
class Portrait{
  constructor(canvas){this.canvas=canvas;this.glx=new GLX(canvas,{alpha:true,preserve:true,antialias:true});this.actor=null;this.mode='head';this.rim=[0.5,0.25,0.3];this.key=[1,0.86,0.72];this.zoom=1;this.sway=true;}
  set(id,spec,o){o=o||{};if((o.mode||'head')==='head'&&spec&&spec.prop==='umbrella')spec=Object.assign({},spec,{prop:null});this.actor=new Actor(id,spec,{breathes:!!o.breathes,pose:o.pose||'idle'});this.actor.ry=o.ry||0.18;this.actor.talking=false;if(o.rim)this.rim=o.rim;if(o.key)this.key=o.key;}
  resize(){const r=this.canvas.getBoundingClientRect(),d=Math.min(2,window.devicePixelRatio||1);const w=Math.max(2,Math.round(r.width*d)),h=Math.max(2,Math.round(r.height*d));if(this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;}}
  render(dt,t){
    if(!this.actor) return; this.resize();
    const gl=this.glx.gl,a=this.actor,W=this.canvas.width,H=this.canvas.height;
    a.update(dt,t);
    gl.viewport(0,0,W,H);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);
    if(this.mode==='iso'){this.renderIso(dt,t,gl,a,W,H);return;}
    const head=a.headPos(),full=this.mode==='full';
    const tgt=full?[a.x,0.92,a.z]:[head[0],head[1]-0.05,head[2]];
    const ang=a.ry+(full?0.35:0.5)+(this.sway?Math.sin(t*0.3)*0.04:0), dist=full?4.6:1.35/this.zoom;
    const eye=[tgt[0]+Math.sin(ang)*dist,tgt[1]+(full?0.35:0.06),tgt[2]+Math.cos(ang)*dist];
    const V=M4.lookAt(eye,tgt,[0,1,0]),Pm=M4.persp(full?0.42:0.42,W/H,0.1,20),VP=M4.mul(Pm,V);
    const fwd=NL.V3.norm(NL.V3.sub(eye,tgt));
    const side=[Math.cos(ang),0,-Math.sin(ang)];
    const lights=[{pos:NL.V3.add(eye,NL.V3.add(NL.V3.mul(side,1.4),[0,1.2,0])),color:this.key,intensity:1.1,range:8},
                  {pos:NL.V3.add(eye,NL.V3.add(NL.V3.mul(side,-1.6),[0,-0.2,0])),color:[0.55,0.6,0.75],intensity:0.38,range:7},
                  {pos:NL.V3.add(tgt,[0,-0.9,0.3*fwd[2]]),color:[0.6,0.42,0.36],intensity:0.22,range:3},
                  {pos:NL.V3.add(tgt,NL.V3.add(NL.V3.mul(fwd,-2),[-1.2*side[0],0.6,-1.2*side[2]])),color:this.rim,intensity:1.6,range:6}];
    drawActors(this.glx,[a],VP,{dir:fwd,sky:[0.2,0.19,0.24],ground:[0.07,0.05,0.07],lights,rim:this.rim,outline:full?0.009:0.0035,ink:[0.04,0.02,0.05],keyDir:[side[0]+fwd[0],0.8,side[2]+fwd[2]],keyCol:[0.12,0.1,0.1]});
  }
  /* the gameplay camera: same isometric angle and orthographic lens as the rooms, pulled back, with the painted-figure brush.
     Feet land at 76% down the frame so the CSS floor and shadow under .doll.iso line up. */
  renderIso(dt,t,gl,a,W,H){
    const SH=NL.SH,dir=NL.V3.norm([1,1.08,1]),cosE=Math.sqrt(1-dir[1]*dir[1]);
    a.ry=0.785+(this.turn||0)+Math.sin(t*0.25)*0.12;
    const fig=1.8*cosE,hh=fig/(2*(this.figFrac||0.43)),hw=hh*W/H,feetY=0.76;
    const tgt=[a.x,(feetY-0.5)*2*hh/cosE,a.z],eye=NL.V3.add(tgt,NL.V3.mul(dir,30));
    const VP=M4.mul(M4.ortho(-hw,hw,-hh,hh,1,60),M4.lookAt(eye,tgt,[0,1,0]));
    const g=this.grade||{},side=[0.7,0,-0.7];
    const lights=[{pos:[a.x+1.6,2.6,a.z+2.2],color:g.key||[1,0.86,0.72],intensity:1.25,range:7},
                  {pos:[a.x-2.2,1.4,a.z+0.6],color:[0.5,0.56,0.72],intensity:0.4,range:6},
                  {pos:[a.x-1.2,2.2,a.z-1.8],color:this.rim,intensity:1.2,range:5}];
    const cam={dir,sky:g.sky||[0.2,0.19,0.24],ground:g.ground||[0.08,0.06,0.07],lights,rim:this.rim,outline:0.0062,ink:[0.04,0.02,0.05],
      shT:g.shT||[.86,.88,.96],hiT:g.hiT||[1,.96,.9],sat:g.sat==null?.9:g.sat,keyDir:[0.55,1,0.75],keyCol:[0.14,0.13,0.14]};
    const glx=this.glx,figPx=fig/(2*hh)*H;
    if(NL.paintActors===false||!SH||!SH.KUWA_FS){drawActors(glx,[a],VP,cam);return;}
    if(!this.rt||this.rt.w!==W||this.rt.h!==H){this.rt=glx.target(W,H,true);this.rt.w=W;this.rt.h=H;}
    gl.bindFramebuffer(gl.FRAMEBUFFER,this.rt.fb);gl.viewport(0,0,W,H);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);
    drawActors(glx,[a],VP,cam);
    gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,W,H);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);gl.disable(gl.DEPTH_TEST);gl.bindVertexArray(glx.emptyVao);
    const K=glx.prog('kuwa',SH.FS_VS,SH.KUWA_FS);gl.useProgram(K.p);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.rt.color);gl.uniform1i(K.u.uSrc,0);
    gl.uniform2f(K.u.uTexel,1/W,1/H);gl.uniform1i(K.u.uR,figPx<150?1:figPx<280?2:3);
    gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);gl.drawArrays(gl.TRIANGLES,0,3);gl.disable(gl.BLEND);gl.enable(gl.DEPTH_TEST);gl.bindVertexArray(null);
  }
}

NL.Actor=Actor; NL.Portrait=Portrait; NL.drawActors=drawActors; NL.POSES=POSES; NL.buildHuman=build; NL.angDiff=angDiff;
})();
