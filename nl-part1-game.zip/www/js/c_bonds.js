'use strict';
/* THE NEW LORD — bonds: the big personal questions, the ones people only ask once. Leo asks to be made like you. Séverine offers her wrist. Tariq wants to sell the shop. Valko offers a pack. Pemberton asks to be let go. */
NL.Script.add(String.raw`
// =====================================================================
// LEO · "Make me like you"
// =====================================================================
# bL.0 arc=leo night=4,5 label="\"Leo. You've been quiet all night.\"" if=alive:leo&!flag:leoGoneTown&!flag:leoThrall&!flag:leoForgot&rel:leo>=4 prio=4
@focus leo
> He's sitting on the end of his bed with his joke notebook open on his knees. He hasn't written anything. He's been drawing the same box over and over in the margin until the paper's gone through.
leo: Can I ask you something? And you have to promise not to laugh. Or do the eyes. Or say "Leo" in that voice.
* "I promise."  -> bL.ask
* "That depends what it is."  -> bL.ask

# bL.ask
leo: Make me like you.
> He says it to the notebook.
leo: I've thought about it. I have. Since Tuesday. I'm thirty-four. I do twenty minutes about the bus to rooms of nine people. I live in a studio apartment with a cactus. Nobody's going to miss me except Mom and Junie, and Junie's got her night shifts and Mom's got the WhatsApp group.
leo: And you're going to be on your own. Forever. With *him* in your head. And on Friday you might be ash, and if you're not, you'll be up there with them, with the Court, and I'll be down here getting old, and you'll come and see me less and less and then you'll stop.
leo: I don't want you to stop. I don't want to get old while you don't. So. Make me like you.
tenant: Child. Think. Think very hard. I made one childe in two hundred years and she walked into the sea off Marseille in 1801 to get away from me.
* "Leo. No."  -> bL.no
* "Why do you really want this?"  -> bL.why
* "Are you sure? Are you completely sure?"  -> bL.sure
* "Not like me. But I can give you something. A little of my blood. You'll live longer. You'll be stronger."  -> bL.ghoul

# bL.why
leo: Really? Really really?
leo: ...Because it's the only interesting thing that's ever happened to me. Because for four days I've been the guy who knows. The guy in the room with the monster. And I've been funnier. I have. I did ten minutes at the Lantern Room and they LAUGHED.
leo: And I'm scared that if you go, I'll go back to being the guy with the cactus. And I'm scared that if I ask you, you'll say yes. And I'm more scared you'll say no.
* "That's not a reason to die, Leo."  -> bL.die
* "Okay. Okay. If that's what you want."  -> bL.sure

# bL.die
leo: Is that what it is? Dying?
leo: You don't look dead. You look tired. You look like someone who works nights.
* "I died in a freezer on Monday morning. I'm still dead. It doesn't stop."  -> bL.no

# bL.no
> He nods. He keeps nodding. He doesn't look up from the notebook.
leo: Yeah. Yeah. Course. No. I knew you'd say that. That's... no, that's the right answer. That's the answer a good one gives. You're a good one.
* "I'm not saying no because you're not worth it. I'm saying no because you are."  -> bL.noworth {do lean:mercy+1}
* "Because I need someone who's still alive. Someone to remember me as I was."  -> bL.noremember
* Say nothing. Sit beside him.  -> bL.nosit

# bL.noworth
> He makes a sound like a laugh with a hole in it.
leo: That's a good line. That's a really good line. Can I have it? For the act?
* "It's yours."  -> bL.noend

# bL.noremember
leo: Remember you. As you were. I didn't know you as you were. I met you dead.
leo: ...But okay. I'll remember you as you are now. Tonight. On the end of my bed. That's the one I'll keep.
@next bL.noend

# bL.nosit
> You sit on the end of his bed. The springs go. He leans on your shoulder. He's very warm and you're very cold and he doesn't move away.
leo: You're freezing. You know that? You're always freezing.
@next bL.noend

# bL.noend
{do flag:leoAskedTurn=no; rel:leo+2; comp+2:Leo asked; mem:leo:asked}
leo: If you change your mind. In fifty years. When I'm eighty-four and I've got a hip. Come and ask me again. I'll probably say yes.
@end

# bL.sure
leo: I'm sure. I've never been sure about anything. I wasn't sure about Tash. I wasn't sure about comedy. I'm sure about this.
pulse(6): His heart is very fast and very steady. Both. You didn't know a heart could do both.
tenant: If you do this, he will be yours. Not your friend. Your *childe*. He'll feel what you feel. He'll come when you call. He'll never be able to say no to you again, not really, not all the way down. That is what it means.
* Do it.  -> bL.turn {blood}
* "I can't. I'm sorry. I can't do that to you."  -> bL.no
* "Not tonight. Ask me after Friday. If there's an after."  -> bL.after

# bL.after
leo: After Friday. Okay. Okay. That's not a no.
leo: That's a "not tonight". That's what Tash used to say. That always meant no.
* "It doesn't mean no."  -> bL.afterpromise {do promise:leoafter:Answer Leo properly after Friday}
* "...It might."  -> bL.noend

# bL.afterpromise
leo: Okay. After Friday. I'm holding you to that. I'm writing it down.
> He writes it in the notebook, in big letters: *AFTER FRIDAY.* He underlines it twice.
{do flag:leoAskedTurn=after; rel:leo+2}
@end

# bL.turn
> You do it in the dark, in a studio apartment on the third floor of the Rookery, with the cactus on the windowsill and the rain on the glass.
> It's not like the films. It's not like Monday. It's slow. You drink until his heart stumbles and then you open your wrist and hold it to his mouth and he drinks like a man coming up from deep water. Somewhere in the middle of it he says your name, the real one, the one you didn't know you'd told him.
> And then his heart stops.
> And then, after a long time, after the longest silence of your very long week, it doesn't start again. And he opens his eyes.
leo: ...Oh. Oh, wow. Oh, it's so LOUD. Everything's so loud. I can hear Kenny downstairs. I can hear Kenny's *fridge*.
leo: I'm so hungry. Why didn't you tell me how hungry.
{do flag:leoEmbraced=1; flag:leoAskedTurn=yes; vitae-3; lean:restraint-1; sync-2; heat+1; mem:leo:turned}
tenant: There. It's done. God help you both. God help him, most of all; he still has to tell his mother.
* Feed him. Take him out. Show him how.  -> bL.feed
* Hold him. Wait for the first dawn together.  -> bL.hold

# bL.feed
> You take him out into the Ward and show him. The drunk, the sleeping, the willing. Never the same one twice in a week. Never a child. Never to the end.
> He's terrible at it. He apologizes to the first one. He cries after the second. On the third he gets it right, and stops, and looks at you with red eyes, so proud of himself.
leo: I stopped. Did you see? I stopped.
{do comp+1; tick:60; rel:leo+2}
@end

# bL.hold
> You sit with him on the floor of his bedsit until the window starts to go grey, and then you pull the mattress into the bathroom and the two of you lie in the bath under it like children building a fort, and he holds on to your coat, and he says "is it always like this?" and you say "yes" and he says "okay" and he goes to sleep.
{do comp+2; rel:leo+3}
@end

# bL.ghoul
leo: Something. A little. Like... like Tiny's brother? Like a ghoul?
leo: I'd live longer. I'd be stronger. And I'd... need it. I'd need you. Every week. Like a drug.
leo: ...That's the deal, isn't it. That's always the deal.
* "Yes. That's the deal."  -> bL.ghoulyes {do lean:candour+1}
* "No. Forget I said it."  -> bL.no

# bL.ghoulyes
leo: Okay. Okay. Better than nothing. Better than the cactus.
> He holds out his wrist, like you're going to take blood from it. You laugh, for the first time all night. You hold your wrist out instead.
{do flag:leoGhoul=1; flag:leoAskedTurn=ghoul; vitae-2; rel:leo+1; mem:leo:ghoul}
leo: Oh. Oh. That's... oh, that's like Christmas. That's like Christmas in my mouth.
@end

// Leo on Night 5, after the turn
# bL5.0 arc=leo night=5 label="\"How are you, Leo? Really?\"" if=flag:leoEmbraced prio=9
@focus leo
> He's on the roof of the Rookery, sitting on the parapet in the rain, which doesn't bother him now. He's wearing his parka over a T-shirt that says I SURVIVED THE LANTERN ROOM OPEN MIC.
leo: I'm... I don't know. I can hear everything. Mom rang. I couldn't talk to her. I could hear her heart through the phone. I could hear her *heart*.
leo: She asked if I was eating. I said yes. I wasn't lying. Was I lying?
* "You'll learn to talk to her. It takes time."  -> bL5.time
* "Do you regret it?"  -> bL5.regret

# bL5.time
leo: Time. I've got loads of that now. Loads and loads.
leo: That's the bit nobody tells you, isn't it. It's not the blood. It's the time. All of it. Forever.
{do comp+1}
@end

# bL5.regret
> He thinks about it. Properly. He takes so long you start to be afraid.
leo: No. Yes. Both. I regret the cactus. Who's going to water the cactus?
leo: I don't regret you. I'll never regret you. I can't, now, can I? That's the thing. I literally can't.
tenant: He's right. He can't. And he knows it. And he's still smiling. I didn't have that much courage in two hundred years.
{do comp+2; rel:leo+1}
@end

// =====================================================================
// SÉVERINE · the wrist
// =====================================================================
# bS.0 arc=severine night=4 label="\"You sent for me, my lady.\"" if=alive:sev&!flag:sevEnemy&like:severine>=2 prio=5
@focus severine
> The Gilded Court's private room behind the ossuary: one candle, one chair, one woman. She's taken off her gloves. Her wrists are very white.
severine: I did. Sit. Not there. Here. At my feet. Like the old days. Indulge me.
* Sit at her feet.  -> bS.feet {do lean:pride-1}
* Stand.  -> bS.stand {do lean:pride+1}

# bS.feet
severine: There. Good. You can be so biddable when you want something. It's very fetching.
@next bS.offer

# bS.stand
severine: Stand, then. Stand, like Absalom. You've even got his chin. It's very irritating.
@next bS.offer

# bS.offer
severine: Tomorrow I stand in the chalk circle as your Accuser. I can be soft. I can be hard. I can be so very, very hard.
severine: Or I can be your friend. In front of three hundred Kindred and the Magistrate, I can stand up and say: "I withdraw. The neonate is mine. I vouch for it." And you walk free, and nobody argues, because nobody argues with me.
> She turns her wrist over. The blue vein under the white skin.
severine: Drink. Once. Tonight. It's only a taste. It doesn't make you mine. It only makes you... fond.
pedigree(8): The first step of a blood bond. Three drinks, on three nights, and you would love her like a dog loves a hand. One drink is a leash with a lot of slack in it. But it's still a leash.
tenant: She did this to me in 1888. One drink. I spent forty years getting the taste out of my mouth.
* Drink.  -> bS.drink {blood}
* "No."  -> bS.no
* "Swear first. In front of witnesses."  -> bS.swear
? stagecraft 12 "Of course, my lady." Take her wrist. Pretend to drink. Swallow nothing.  -> bS.fake | bS.caught {id bS_fake}

# bS.drink
> Old blood. Jasmine, and dust, and a ballroom in Lyon before the Terror. It goes down like a word you can't take back.
> And then, God help you, you love her. A little. Not much. Just enough to want her to be pleased with you. Just enough to notice that she's beautiful, which you'd always known, and to mind that she's sad, which you hadn't.
severine: There. Was that so terrible? Look at you. Look how you're looking at me. Oh, darling. Absalom never once looked at me like that.
{do flag:sevBond=1; flag:sevVouch=1; feed:2:Sanguine:Séverine:kindred; lean:restraint-1; rel:severine+3; sync-2}
tenant: Child. I can taste her in you. I can taste her. Don't go back tomorrow. Don't go back for the second.
@end

# bS.no
severine: No. Hm. No.
> She pulls her glove back on, finger by finger.
severine: Then tomorrow I'll be hard. Not out of spite, darling. Out of policy. You understand.
{do rel:severine-1; flag:sevRefusedBond=1}
@end

# bS.swear
severine: Witnesses. To a Gilded Court promise. You want me to swear, in front of my own ghouls, that I'll vouch for you.
severine: ...Absalom asked that, in 1888. I said no and he drank anyway. You're cleverer than him. Or less in love. Fine.
? velvet 13 "Swear it, or I'll stand in the circle tomorrow and tell them about Harrow's car on Ferrier Lane."  -> bS.swearok | bS.swearno {id bS_swear} {if flag:knowSevHarrow}
? velvet 14 "Swear it. You want me to win. You'd rather I owed you than Malakor."  -> bS.swearok | bS.swearno {id bS_swear2} {if !flag:knowSevHarrow}

# bS.swearok
> She calls in two ghouls in livery. She swears, in old French, with her hand on the cracked skull of Brother Anselm. It's very beautiful and you only understand half of it.
severine: There. Sworn. I'll vouch for you tomorrow, and you'll owe me, and that's a debt with no blood in it. Happy?
severine: You're the first in a hundred years to get my word without my wrist. I'll hate you for it, quietly, for decades.
{do flag:sevVouch=1; rel:severine+1; lean:pride+1}
@end

# bS.swearno
severine: No. No, I don't think so. I think you'll drink, or you'll take your chances. Choose.
* Drink.  -> bS.drink {blood}
* "I'll take my chances."  -> bS.no

# bS.fake
> You take her wrist. You put your mouth to it. You let her feel teeth. You swallow nothing, and you shut your eyes, and you make your face do the thing faces do when they love someone a little.
> She watches you very closely. She's watched three hundred years of people pretending. She smiles.
severine: There. Look at you. Look how you're looking at me.
stagecraft(8): She bought it. Possibly. Or she knows, and she's letting you think she bought it, because now you owe her for that too.
{do flag:sevVouch=1; flag:sevFakeBond=1; rel:severine+2; lean:candour-1}
@end

# bS.caught
> You take her wrist. You put your mouth to it. She pulls it away before you can pretend.
severine: Don't. Darling. I was faking things in the court of Louis XVI. You're an amateur.
severine: Tomorrow I'll be hard. Very.
{do flag:sevCaughtFake=1; rel:severine-2}
@end

// =====================================================================
// TARIQ · the shop
// =====================================================================
# bT.0 arc=tariq night=4,5 label="\"Tariq. What's the For Sale sign?\"" if=alive:tariq&rel:tariq>=2 prio=3
@focus tariq
> A hand-written sign taped in the window of the Lucky Mart, under the lottery stickers: BUSINESS FOR SALE. ENQUIRE WITHIN.
tariq: My wife. After Friday, she says, we go. To her brother's in Buffalo. He has a garage. She says this street is going to eat us. She says she's been saying it for eleven years, and now she's sure.
tariq: She's right. I know she's right. I've been doing the sums all week. But the shop... my father's shop. I'd be selling my father.
* "Then don't sell it."  -> bT.stay
* "Sell it to me."  -> bT.buy {if cash>=300}
* "Go. Buffalo's safe. You've done enough."  -> bT.go {do lean:mercy+1}
* "What would your father say?"  -> bT.father

# bT.father
tariq: My father? My father would say: "Tariq, a shop is a box with things in it. A family is not a box." He used to say that to my mother when she cried about the rent.
tariq: He'd say go. He'd say go and he'd be heartbroken. He always said the right thing and was heartbroken about it.
@next bT.0b

# bT.0b
* "Then don't sell it."  -> bT.stay
* "Sell it to me."  -> bT.buy {if cash>=300}
* "Go. Buffalo's safe. You've done enough."  -> bT.go {do lean:mercy+1}

# bT.stay
tariq: Don't sell it. Stay. With the vans on Ferrier Lane and your kind in the drains.
? velvet 11 "If I'm Sheriff on Saturday, nobody on this street will ever be afraid of the drains again. That's a promise."  -> bT.stayok | bT.stayno {id bT_stay} {mod like:tariq}

# bT.stayok
> He looks at the sign for a long time. Then he takes it down and folds it into four and puts it in the till, under the drawer, where he keeps the important things.
tariq: A promise. From a vampire. My wife will kill me.
tariq: ...My father would have believed you. He believed everybody. All right. All right. One year. I'll give you one year.
{do flag:tariqStays=1; promise:tariqyear:Keep Halloran Street safe for a year; rel:tariq+2}
@end

# bT.stayno
tariq: You can't promise that. Nobody can promise that. Not even you.
tariq: The sign stays up. I'm sorry.
{do flag:tariqLeaves=1}
@end

# bT.buy
tariq: You? Buy the Lucky Mart? What would a... what would you do with a corner shop?
* "Keep it open. Keep the lights on. Keep the coffee warm at five."  -> bT.buy2
* "Give it to someone who needs it."  -> bT.buy3

# bT.buy2
> He laughs. Then he stops laughing. Then he holds out his hand across the counter, over the scratch cards.
tariq: Three hundred now. The rest when you have it. There's no rush. I know where you live. Well. I know where you don't live.
tariq: My father's shop, owned by a ghost. He'd have found that very funny. He loved a ghost story.
{do cash-300; flag:ownMart=1; flag:tariqLeaves=1; rel:tariq+2; xp:30:The Lucky Mart}
@end

# bT.buy3
tariq: Someone who needs it. Who?
* "Luis. From the night bus. He needs somewhere to stand still."  -> bT.giveluis {if flag:metLuis|task:s_bus}
* "Coral. She's done with the Court."  -> bT.givecoral {if flag:coralFree|task:s_coral=done}
* "Mrs. Okafor."  -> bT.giveokafor {if !flag:okaforDead&flag:met404}
* "I'll think of someone."  -> bT.buy2

# bT.giveluis
tariq: The young man from the night bus. Yes. He came in on Tuesday and stood in front of the soup for an hour. He said he was trying to remember what his mother bought. It was caldo verde. I don't stock it. I'll stock it.
{do cash-300; flag:ownMart=1; flag:martLuis=1; flag:tariqLeaves=1; rel:tariq+2}
@end

# bT.givecoral
tariq: The girl from the club? With the... ah. Yes. She came in on Tuesday and bought a newspaper and read the jobs page at my counter for an hour.
{do cash-300; flag:ownMart=1; flag:martCoral=1; flag:tariqLeaves=1; rel:tariq+2}
@end

# bT.giveokafor
tariq: Mrs. Okafor. Behind my counter. She'd terrify the schoolboys. They'd never steal a Twix again.
{do cash-300; flag:ownMart=1; flag:martOkafor=1; flag:tariqLeaves=1; rel:tariq+2}
@end

# bT.go
tariq: Go. Yes. Yes.
> He looks round the shop. The coffee machine. The fridges. The calendar from 2014 that he never took down because his father had written a phone number on it.
tariq: I'll keep the calendar. Everything else, the bank can have.
tariq: Will you come to Buffalo? Ever? There's a lot of night in Buffalo.
* "If I can."  -> bT.goif

# bT.goif
tariq: If you can. Good. I'll leave the light on. Out of habit.
{do flag:tariqLeaves=1; flag:tariqLeicester=1; rel:tariq+1}
@end

// =====================================================================
// VALKO · the pack
// =====================================================================
# bV.0 arc=valko night=4,5 label="\"Valko. Why are you sitting like that?\"" if=flag:valkoAlly&!flag:valkoDead&rel:valko>=4 prio=4
@focus valko
> He's kneeling on the wet cobbles. Not crouching. Kneeling, very straight, with his hands open on his thighs.
valko: This is how it's done. In the old way. A Hound kneels and asks.
valko: I've had no pack since Rask. Forty-seven years alone. A Hound alone goes strange. I've been strange. You've seen it.
valko: I'm asking you to be my pack. Not my master. Hounds have no masters. My... first. The one I run behind. The one I'd die in front of.
tenant: Hounds don't ask this lightly. If you say yes, he'll be yours until one of you is ash. If you say yes and then fail him, he'll never ask anyone again.
* "Yes."  -> bV.yes
* "I can't promise to be what Rask was."  -> bV.rask
* "Valko. Get up. You don't kneel to anyone."  -> bV.up

# bV.yes
valko: Then cut your hand. And I cut mine. And we hold them.
> You do. His blood is hot as a dog's mouth. It hisses where it meets yours, like rain on a stove.
> He throws back his head and howls, once, down Ferrier Lane. Somewhere across the river, very faint, another Hound answers.
valko: There. Pack. Two is a pack. Two is enough.
{do flag:valkoPack=1; promise:valkopack:Run first for Valko; rel:valko+3; vitae-1; lean:loyalty+1}
@end

# bV.rask
valko: I don't want Rask. Rask is ash in a lamp. I want you.
valko: I don't need you to be anything. Just be first. Just be there, in front, so I know which way to run.
* "Then yes."  -> bV.yes
* "I'm sorry, Valko. Not yet."  -> bV.notyet

# bV.notyet
> He gets up. He brushes his knees. He doesn't look at you.
valko: Not yet. Yes. Hounds can wait. Hounds are very good at waiting.
{do rel:valko-1; flag:valkoWait=1}
@end

# bV.up
valko: I don't kneel. No. Except once. This was the once.
> He gets up slowly.
valko: ...You didn't answer.
* "Yes. Get up and be my pack. Standing."  -> bV.yes
* "Not yet."  -> bV.notyet

// =====================================================================
// PEMBERTON · notice
// =====================================================================
# bP.0 arc=pemberton night=4,5 label="\"Pemberton. You've written a letter.\"" if=alive:pemberton&!flag:pembertonGone&rel:pemberton>=3 prio=3
@focus pemberton
> He hands it to you on a silver salver, as if it were a calling card. Cream paper. Fountain pen. His handwriting is better than the Prince's.
> *"I hereby respectfully tender my resignation from the service of the Sheriff of the Marrow Ward, effective at the conclusion of the Tribunal. I have served for forty-one years. I find I am tired. — A. J. Pemberton."*
pemberton: I wished to give it to you in person. Before. In case there is no after.
pemberton: I came into the Sheriff's service at twenty-three, from the merchant navy. I drove him to forty-one Tribunals in forty-one years. I have drunk from his wrist every Sunday since. That is why I look forty at sixty-four. If I stop, I shall be sixty-four quite quickly.
* "Accept it. Thank him."  -> bP.accept {do lean:mercy+1}
* "Tear it up. I need you."  -> bP.tear
* "Stay. But as a free man. No more Sundays."  -> bP.free
* "What would you do? After?"  -> bP.after

# bP.after
pemberton: After. I hadn't thought. One doesn't, in service.
pemberton: ...I should like to see the sea. In daylight. I have only ever seen it at night, from the car. I should like to go to the cottage in Galway my sister left me, and sit on the harbour wall and eat chips out of paper and watch the sun on the water, and get sunburnt, and complain about it.
@next bP.0b

# bP.0b
* "Accept it. Thank him."  -> bP.accept {do lean:mercy+1}
* "Tear it up. I need you."  -> bP.tear
* "Stay. But as a free man. No more Sundays."  -> bP.free

# bP.accept
> You fold the letter and put it in your coat. You tell him thank you. You tell him the Sheriff would have said thank you, if the Sheriff had ever thought to.
pemberton: He did, as it happens. Once. In 1974. I've never forgotten it.
pemberton: Thank you. After Friday, then. Galway.
{do flag:pemResigns=1; rel:pemberton+2; comp+1}
@end

# bP.tear
> You tear it in two. He watches without expression.
pemberton: Very well. As you wish.
pemberton: The Sheriff tore up four of those. In 1987, 1994, 2003 and 2016. I keep writing them. It's a sort of hobby.
{do flag:pemStays=1; rel:pemberton-1; lean:pride+1}
@end

# bP.free
pemberton: Free. And no Sundays.
pemberton: Then I would grow older. Properly. Twenty years in a season, the Sheriff's Butcher once told me, and then at the ordinary rate. I should be sixty-four by Easter. In your service, by choice, with the cottage in Galway for my holidays.
pemberton: ...Do you know, I think I'd like that very much.
{do flag:pemFree=1; rel:pemberton+3; comp+1}
@end
`,'c_bonds');

/* consequences */
(function(){const {L,T,ENC}=NL.DSL;
if(ENC.tribunal){const st0=ENC.tribunal.start;ENC.tribunal.start=function(S,G){const r=st0.call(this,S,G);if(S.flags.sevCaughtFake)r.threat+=1;if(S.flags.sevRefusedBond&&!S.flags.side_court)r.threat+=1;return r;};
  const mv=ENC.tribunal.moves;ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);
  if(S.flags.sevVouch&&!S.flags.sevDead&&!S.flags.accuserLied)M.push({t:'Look at Séverine. "My lady. You gave me your word."',once:'tb_sevvouch',ok:(st,S)=>{st.prog+=4;st.threat=Math.max(0,st.threat-2);return [T('Séverine rises from the Accuser\'s bench. She doesn\'t look at you. She looks at the Magistrate.'),L('severine','Magistrate. I withdraw. I have examined the neonate privately and I find it... acceptable. I vouch for it. The Gilded Court vouches for it.'),T('A rustle along the tracks like wind in dead leaves. Nobody argues with Séverine.'),L('severine',S.flags.sevBond?'(low, to you, as she sits) You taste of me now, darling. Remember that.':'(low, to you, as she sits) That\'s my word spent. Don\'t waste it.')];}});
  if(S.flags.valkoPack&&!S.flags.valkoDead)M.push({t:'"Valko. Pack."',once:'tb_pack',ok:st=>{st.threat=Math.max(0,st.threat-2);return [T('From the shadows at the edge of the platform, a grey shape that is nearly a man and nearly a wolf comes and stands at your left hand. He doesn\'t speak. He doesn\'t need to. Every Kindred on Platform 0 has heard what happens to people who threaten a Hound\'s pack.')];}});
  if(S.flags.leoEmbraced)M.push({t:'"There\'s one more thing. I made a childe. On Wednesday. Without permission. Judge me for that too."',once:'tb_childe',ok:(st,S)=>{st.threat+=2;st.prog+=1;return [L('magistrate','...An unsanctioned Embrace. In the week of your trial. You are either very brave or very stupid.'),L('tenant','(through you) Both, Ambrose. Always both. Like me.'),T('At the back of the platform, a young man in a parka over a T-shirt raises his hand and gives a very small wave.')];}});
  return M;};}
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.leoEmbraced)o.push(['Leo Pruitt','Kindred. Your childe. Does twenty minutes every Tuesday at the Lantern Room about being dead, and the mortals think it\'s a bit, and the Kindred at the back laugh so hard they cry blood. His mom thinks he\'s working nights. The cactus died in December. He bought a plastic one.']);
  else if(f.leoAskedTurn==='after'&&!f.leoDead)o.push(['Leo Pruitt','Has AFTER FRIDAY written in his notebook, underlined twice. He hasn\'t asked again. He\'s waiting for you to.']);
  if(f.sevBond)o.push(['Lady Séverine (and you)','You went back to her room behind the ossuary on Saturday night. You told yourself it was to thank her. You didn\'t drink. You wanted to. You still want to. You think about her wrist more than you think about the sun.']);
  if(f.ownMart)o.push(['The Lucky Mart',f.martLuis?'Run by Luis Ferreira, who has stopped riding the night bus. He plays Portuguese radio and keeps tins of caldo verde behind the counter, and on Sundays his mother comes in and tells him he\'s doing it all wrong.':f.martCoral?'Run by Coral, who reads the jobs page every morning out of habit and never applies for any of them.':f.martOkafor?'Run by Mrs. Okafor, who terrifies the schoolboys and puts a missing poster in the window every August.':'Yours. You keep the lights on. Somebody leaves a coffee on the counter at five. Nobody knows who.']);
  if(f.tariqStays)o.push(['Tariq','Took the sign down. Kept the shop. His wife has not forgiven him. Every night at five he pours a coffee and puts it on the counter, and every morning it\'s gone, and he never asks.']);
  else if(f.tariqLeicester)o.push(['Tariq','Buffalo. His brother-in-law\'s garage. He keeps the 2014 calendar on the office wall. He leaves the light on.']);
  if(f.valkoPack&&!f.valkoDead)o.push(['Valko','Runs behind you. Always half a step behind, to the left. Two is a pack. Two is enough.']);
  if(f.pemResigns&&!f.pemDead)o.push(['Pemberton','Galway. The harbour wall. Chips out of paper. He got sunburnt in March and complained about it to everybody, and was, by every account, the happiest man in Connacht. He grew old very quickly. He didn\'t mind.']);
  else if(f.pemFree&&!f.pemDead)o.push(['Pemberton','Serves you, by choice, without Sundays. He has grey in his hair now that wasn\'t there in October. Twice a year he flies to Galway.']);
  return o;});
})();
