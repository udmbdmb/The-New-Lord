'use strict';
/* THE NEW LORD — Act I systems glue: character creation, items, travel, the turn of the night */
(function(){
const NL=window.NL,G=NL.G,A=NL.Audio;const {N,ENC,L,T,O,C,H,STORY}=NL.DSL;
const $=s=>document.querySelector(s),esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const Wd=()=>G.Wd;

/* ---------- walk-on characters (no dossier) ---------- */
NL.EXTRAS={
  drifter:{n:'Drifter',color:'#d0a080',role:'Ferrier Lane',spec:{face:{jaw:0.7,nose:1.3,brow:1.3,wide:1.04},skin:[.78,.6,.5],hair:{style:'crop',color:[.3,.22,.15]},mustache:[.3,.22,.15],shirt:[.35,.3,.25],coat:{color:[.25,.22,.18],length:.5,collar:true},pants:[.2,.2,.22]}},
  bartender:{n:'Bartender',color:'#c8a0e0',role:'Club Reliquary',spec:{face:{long:1.03,cheek:1.3},skin:[.85,.7,.62],hair:{style:'bun',color:[.6,.1,.3]},shirt:[.06,.06,.08],pants:[.06,.06,.08],lips:[.5,.1,.2]}},
  dancer:{n:'Dancer',color:'#e0a0d0',role:'Club Reliquary',spec:{skin:[.8,.62,.52],hair:{style:'long',color:[.1,.08,.1]},shirt:[.6,.1,.4],pants:[.08,.08,.1]}},
  nurse:{n:'Night Nurse',color:'#a0d0d0',role:'St. Jude\'s',spec:{skin:[.7,.52,.42],hair:{style:'bun',color:[.12,.08,.06]},shirt:[.2,.45,.48],pants:[.2,.45,.48]}},
  voice:{n:'Voice on the line',color:'#bbb',role:'',spec:null}
};
NL.STORY.gameovers.sunrise={k:'5:09 AM',t:'Sunrise',d:'The sky goes grey, then white, then gold, and you are standing in it. It does not hurt for very long.',a:'Rewind, and find a haven before dawn.'};
NL.STORY.gameovers.staked={k:'Final death',t:'The Hound\'s Teeth',d:'Valko finds you, as he finds everything. He is very quick and very sorry, in that order.',a:'Rewind to your last save.'};

/* ---------- item uses ---------- */
const TASTES=['Tastes of: a night nurse on a double shift. Coffee, nicotine, quiet despair.','Tastes of: a marathon runner. Iron, salt, smugness.','Tastes of: a student who donated for the free pizza. Pepperoni. Optimism.','Tastes of: a retired priest. Communion wine, and a secret he never told.','Tastes of: a man who cried at a wedding. Champagne. Relief.'];
NL.ItemUse={
  bloodbag(S,G){G.take('bloodbag');S.flags.drankBag=(S.flags.drankBag||0)+1;G.feed(3,STORY.bagRes(S),'blood bag',{kind:'bag'});if(S.clan!=='sovereign')G.toast('vitae',TASTES[(S.flags.drankBag-1)%TASTES.length],'Parasite');},
  ashvial(S,G){G.take('ashvial');G.vitae(2);G.sync(20,'You swallowed him');G.toast('rel','He goes down like hot dust. For a second you are three hundred years old.','The Tenant');S.flags.ateAsh=1;},
  coffee(S,G){G.take('coffee');G.comp(1,'You hold it. You smell it. You remember.');S.flags.heldCoffee=(S.flags.heldCoffee||0)+1;if(S.flags.heldCoffee>=1)G.offer('encore');}
};
NL.ItemActs={
  apron:[{n:'Wash it in the sink',if:S=>S.room==='backroom',do:async(S,G)=>{await G.say([T('You run the hot tap until it steams, and work the apron under it until the water runs pink, then clear. It comes out damp and almost respectable.')]);const wasOn=G.equipped('apron');G.take('apron');S.inv.dampapron=1;if(wasOn){S.eq.torso='dampapron';delete S.inv.dampapron;G.updateLook&&G.updateLook();}G.toast('item','<b>Damp Apron</b>','Washed');}}],
  burner:[{n:'Reply to S.',if:S=>S.flags.sevTexted&&!S.flags.sevReplied,do:(S,G)=>G.talk('sev.reply')}]
};

/* ---------- character creation: the bathroom mirror ---------- */
function hex(c){const n=parseInt(c.slice(1),16);return [(n>>16&255)/255,(n>>8&255)/255,(n&255)/255];}
function openCreation(G,S){return new Promise(resolve=>{
  const m=$('#mirror');m.hidden=false;A.music('mirror');requestAnimationFrame(()=>m.classList.add('in'));
  let step=0;const pick={past:S.past||null,clan:S.clan||null,gender:S.gender||null,look:Object.assign({},S.look),attrs:{sanguine:3,masquerade:3,nocturne:3,cadaver:3},sig:null};
  const used=()=>Object.values(pick.attrs).reduce((a,b)=>a+b,0),left=()=>12-used();
  const preview=()=>{const save={clan:S.clan,look:S.look,gender:S.gender};S.clan=pick.clan;S.look=pick.look;S.gender=pick.gender;const spec=G.playerSpec(true);
    const c=pick.clan?NL.CLANS[pick.clan]:null;if(c){spec.eyeGlow=c.glow.map(v=>v*.9);if(c.mismatch)spec.eyes2=c.mismatch;if(c.ghost)spec.alpha=.08;}
    S.clan=save.clan;S.look=save.look;S.gender=save.gender;return spec;};
  const host=$('#miCan');
  const refresh=()=>{const c=pick.clan?NL.CLANS[pick.clan]:null;m.style.setProperty('--aura',c?c.aura:'#6b6f80');m.dataset.clan=pick.clan||'';
    G._portraitInto(host,'mirror_'+(pick.clan||'x')+'_'+(pick.gender||'x')+'_'+JSON.stringify(pick.look),preview(),{rim:c?hex(c.aura):[.5,.5,.6],zoom:.78});
    const url=pick.clan&&pick.gender?NL.PAINTED['you_'+pick.clan+'_'+pick.gender]:null;let im=host.querySelector('img.painted');
    if(url){if(!im){im=document.createElement('img');im.className='painted';im.alt='';host.appendChild(im);}if(im.getAttribute('src')!==url)im.src=url;im.hidden=false;G._pCanvas().style.visibility='hidden';}
    else if(im)im.hidden=true;
    render();};
  const render=()=>{const box=$('#miStep');let html='';
    if(step===0){html=`<div class="mk">I · The Scar</div><h2>Who were you, before?</h2><p class="mlede">The face in the glass is smeared with somebody else's years. Underneath, something of yours is still there. Reach for it.</p><div class="mgrid">`+
      Object.entries(NL.PASTS).map(([k,p])=>`<button class="mcard ${pick.past===k?'sel':''}" data-past="${k}"><b>${esc(p.name)}</b><span>${Object.entries(p.skill).map(([s,v])=>`<em style="--c:${NL.ATTRS[NL.SKILLS[s].attr].color}">${esc(NL.SKILLS[s].name)} +${v}</em>`).join(' ')} <em style="--c:var(--paper-dim)">${esc(p.perk)}</em></span><small>${esc(p.mem)}</small></button>`).join('')+'</div>';}
    if(step===1){html=`<div class="mk">II · The Voices</div><h2>Which of them are loudest?</h2><p class="mlede">Twelve points across four attributes. Each score is where its four voices start, and how far you can ever teach them.</p><div class="alloc">`+
      Object.keys(NL.ATTRS).map(a=>{const A_=NL.ATTRS[a];return `<div class="al" style="--c:${A_.color}"><div><b>${esc(A_.name)}</b><small>${esc(A_.tag)}</small><small class="sk">${NL.SKILL_ORDER[a].map(k=>esc(NL.SKILLS[k].name)).join(' · ')}</small></div><button data-am="${a}" ${pick.attrs[a]<=1?'disabled':''} aria-label="Lower">−</button><span>${pick.attrs[a]}</span><button data-ap="${a}" ${pick.attrs[a]>=5||left()<=0?'disabled':''} aria-label="Raise">+</button></div>`;}).join('')+
      `</div><p class="left">${left()?`${left()} point${left()>1?'s':''} left`:'All twelve spent.'} · Mask ${5+pick.attrs.masquerade} · Vitae ${Math.min(10,5+pick.attrs.cadaver)}</p><h5>Signature voice <small>+1 to that skill, and +1 to how far its attribute can grow</small></h5><div class="sigs">`+
      Object.keys(NL.ATTRS).map(a=>NL.SKILL_ORDER[a].map(k=>`<button class="chip ${pick.sig===k?'sel':''}" data-sig="${k}" style="--c:${NL.ATTRS[a].color}">${esc(NL.SKILLS[k].name)}</button>`).join('')).join('')+'</div>'+
      (pick.sig?`<p class="sigd"><b>${esc(NL.SKILLS[pick.sig].name)}.</b> ${esc(NL.SKILLS[pick.sig].d)}</p>`:'');}
    if(step===2){const c=pick.clan?NL.CLANS[pick.clan]:null;
      html=`<div class="mk">III · The Blood</div><h2>Examine your fangs, your eyes, your aura.</h2><div class="clist">`+NL.CLAN_ORDER.map(k=>{const cc=NL.CLANS[k];return `<button class="cl ${pick.clan===k?'sel':''}" data-clan="${k}" style="--c:${cc.aura}"><b>${esc(cc.name)}</b><span>${esc(cc.ep)}</span></button>`;}).join('')+'</div>';
      if(c)html+=`<div class="cdet" style="--c:${c.aura}"><p>${esc(c.d)}</p><div class="cmods">${Object.entries(c.mods).map(([k,v])=>`<span class="${v>0?'up':'dn'}">${esc(NL.SKILLS[k].name)} ${v>0?'+':''}${v}</span>`).join('')}</div><div class="cabs">${Object.values(c.ab).map(a=>`<div><b>◆ ${esc(a.n)}</b> <em>${a.c} Vitae</em><small>${esc(a.d)}</small><small class="t2">Mutates into <b>${esc(a.t2.n)}</b>: ${esc(a.t2.d)}</small></div>`).join('')}</div><p class="curse"><b>Curse.</b> ${esc(c.curse)}</p></div>`;}
    if(step===3){const pm=g=>NL.premadeFor(pick.clan,g);const holl=pick.clan==='hollow';
      html=`<div class="mk">IV · The Face</div><h2>${holl?'The glass is empty.':'Lean closer.'}</h2><p class="mlede">${holl?'There is nobody in it. You will have to remember yourself some other way.':'Paler than it was. It will get paler. But it is still yours.'}</p><div class="mgrid">`+
        ['m','f'].map(g=>{const p=pm(g);return p?`<button class="mcard ${pick.gender===g?'sel':''}" data-g="${g}"><b>${esc(p.t)}</b><span><em style="--c:var(--paper-dim)">${g==='m'?'Him':'Her'}</em></span><small>${esc(p.d)}</small></button>`:'';}).join('')+'</div>';}
    box.innerHTML=html;
    box.querySelectorAll('[data-past]').forEach(b=>b.onclick=()=>{pick.past=b.dataset.past;A.sfx('click');render();});
    box.querySelectorAll('[data-look]').forEach(b=>b.onclick=()=>{pick.look[b.dataset.look]=+b.dataset.i;A.sfx('click');refresh();});
    box.querySelectorAll('[data-g]').forEach(b=>b.onclick=()=>{const g=b.dataset.g,p=NL.premadeFor(pick.clan,g);pick.gender=g;if(p)pick.look={skin:p.skin,hair:p.hair,hairCol:p.hairCol};A.sfx('thought');refresh();});
    box.querySelectorAll('[data-ap]').forEach(b=>b.onclick=()=>{const a=b.dataset.ap;if(pick.attrs[a]<5&&left()>0){pick.attrs[a]++;A.sfx('click');render();}});
    box.querySelectorAll('[data-am]').forEach(b=>b.onclick=()=>{const a=b.dataset.am;if(pick.attrs[a]>1){pick.attrs[a]--;A.sfx('click');render();}});
    box.querySelectorAll('[data-sig]').forEach(b=>b.onclick=()=>{pick.sig=b.dataset.sig;A.sfx('thought');render();});
    box.querySelectorAll('[data-clan]').forEach(b=>b.onclick=()=>{pick.clan=b.dataset.clan;if(pick.gender){const p=NL.premadeFor(pick.clan,pick.gender);if(p)pick.look={skin:p.skin,hair:p.hair,hairCol:p.hairCol};}A.sfx('thought');refresh();const d=box.querySelector('.cdet');if(d)d.scrollIntoView({block:'nearest'});});
    $('#miBack').hidden=step===0;const nx=$('#miNext');nx.textContent=step===3?'This is what I am':'Next';
    nx.disabled=(step===0&&!pick.past)||(step===1&&(left()!==0||!pick.sig))||(step===2&&!pick.clan)||(step===3&&!pick.gender);};
  $('#miBack').onclick=()=>{step=Math.max(0,step-1);A.sfx('page');render();};
  $('#miNext').onclick=()=>{if(step<3){step++;A.sfx('page');render();return;}
    S.past=pick.past;S.look=pick.look;S.clan=pick.clan;S.gender=pick.gender||'m';S.flags.female=S.gender==='f'?1:0;S.attrs=Object.assign({},pick.attrs);S.sig=pick.sig;
    const P_=NL.PASTS[pick.past];if(P_.item&&!G.has(P_.item))G.give(P_.item);if(P_.cash)G.cash(P_.cash,'What you had on you');
    S.comp=G.compMax();A.sfx('level');G.updateLook();G.refresh();m.classList.remove('in');
    setTimeout(()=>{m.hidden=true;const im=host.querySelector('img.painted');if(im)im.hidden=true;G._pCanvas().style.visibility='';$('#snapHost').appendChild(G._pCanvas());resolve();},600);A.music('night');};
  refresh();});}
STORY.mirror=async(G,S)=>{await openCreation(G,S);};

/* ---------- places on the map ---------- */
NL.PLACES.push(
  {id:'lane',name:'Ferrier Lane',block:'A',room:'alley',rooms:['luckymart','freezer','backroom','front'],spawn:{x:3.5,z:2.2,ry:0.6},sub:'Kowalski\'s back door, the Lucky Mart, the payphone'},
  {id:'reliquary',name:'Club Reliquary',block:'B',room:'reliquary',rooms:['vip'],spawn:{x:1.3,z:1.0,ry:0.6},sub:'A deconsecrated church with a bass problem. Lady Séverine holds court below.'},
  {id:'pawn',name:'The Pawn & Coffin',block:'B',room:'pawn',spawn:{x:3.1,z:0.95,ry:0.2},sub:'Gideon\'s. Loans, boxes, no questions.'},
  {id:'stjude',name:'St. Jude\'s Night Clinic',block:'C',room:'stjude',spawn:{x:1.6,z:0.9,ry:0.4},sub:'Triage, a blood fridge, and a basement morgue.'}
);

/* ---------- populate & NPC hooks ---------- */
const pushPop=(room,f)=>{(H.populate[room]=H.populate[room]||[]).push(f);};
const pushNpc=(room,f)=>{(H.npc[room]=H.npc[room]||[]).push(f);};
const pushEnter=(room,f)=>{(H.enter[room]=H.enter[room]||[]).push(f);};
NL.Act={pushPop,pushNpc,pushEnter};
})();
