'use strict';
/* THE NEW LORD — blood tells, part two: Stray, Gilded, Choir, Hounds, Moths; and Tiny on Saturday */
(function(){const O=NL.Script.opt;
O('sat.hub','* St. Jude\'s, a side room. Tiny, on a trolley, waiting for your thumbs.  -> sat4.carve {once} {if flag:tinyCarve&!flag:tinyGone&!flag:tinyBetrayed&!flag:satVisit3}','start');
})();
NL.Script.add(String.raw`
# sat4.carve
> A side room on the second floor of St. Jude's with the blinds down and the door locked. Tiny, on a trolley, in a hospital gown that would fit a smaller man twice. Rostova by the crash cart with her notebook. {if flag:rostovaCarve}
> A side room on the second floor of St. Jude's, borrowed from a night porter for forty dollars. Tiny, on a trolley, in a gown that would fit a smaller man twice. {if !flag:rostovaCarve}
tiny: I read the last chapter of the last O'Brian book this morning. In the chair. I thought: if this goes wrong, at least I know how it ends.
* Lay your hands on him. Begin.  -> sat4.c1
* "We don't have to. Say the word."  -> sat4.c0

# sat4.c0
tiny: I've said the word. I said it on Wednesday. Do it before I say a different one.
@next sat4.c1

# sat4.c1
> You put your hands flat on his back, low, either side of the spine. Under the skin, under the muscle, two tired things the size of fists, working like old men climbing stairs.
> You think about clay. You think about Malakor's thumb on your palm. You think about what they were when he was nine years old in Lagos, kicking a ball against a wall.
? abattoir 12 "Make them new."  -> sat4.c2 | sat4.c3 {id sat4_c} {mod flag:carveLesson?2}

# sat4.c2
> It takes eleven minutes. Afterwards you'll remember almost none of it. Heat. The smell of copper. Rostova saying "pressure's holding, pressure's holding" over and over like a rosary. {if flag:rostovaCarve}
> It takes eleven minutes. Afterwards you'll remember almost none of it. Heat. The smell of copper. Tiny's breath going in and out, very slow, the way he breathes at the rope when a fight's about to start. {if !flag:rostovaCarve}
> Then he sits up. He sits up on the trolley like a man getting out of a bath.
tiny: I need to pee.
> He says it in wonder. Like a man saying he can see the sea.
rostova: (very quietly, writing) Patient reports urinary urgency. Twenty-one hundred hours. God help us all. {if flag:rostovaCarve}
{do flag:tinyHealed=1; keep:tinycarve; rel:tiny+3; xp:60:Clay; comp+2}
@next sat.count

# sat4.c3
> Halfway through, something goes wrong. A wet heat that's the wrong kind. Tiny's breath catches.
> You stop. You don't push. You close what you've opened, carefully, the way Malakor showed you, and you take your hands away.
tiny: ...Did it work?
* "Half. Maybe. They're better. They're not new."  -> sat4.c4

# sat4.c4
tiny: Better. Better's fine. Better's two mornings a week instead of three. That's another eight books a year.
> He laughs. It hurts him. He laughs anyway.
{do flag:tinyBetter=1; keep:tinycarve; rel:tiny+2; xp:30:Clay}
@next sat.count

# bl.str arc=tenant night=2,3,4,5 label="\"You think the Stray is beneath you.\"" if=clan:stray prio=1
@focus tenant
tenant: I think the Stray is beneath *the Court*. Which is different. The Court has a very high floor and a very low ceiling and most of the interesting people are under the floorboards.
tenant: Two hundred years of Sovereign blood and it came out mongrel. No clan. No protector. No Elder to write to. I'd find it funny if it weren't so terribly *free*.
* "Free. You make it sound like a disease."  -> bl.str1
* "Nobody's coming to help me. I know."  -> bl.str2
* "I've got you. That's a sort of clan."  -> bl.str3

# bl.str1
tenant: It is a disease. It's the one we all caught in 1787 and spent the rest of our lives trying to cure with titles.
tenant: You haven't got a title. You've got a coat that doesn't fit and a dead man in your head. Do you know, I think you might be the first vampire in this city who got to choose what they are.
{do sync+1; lean:pride-1}
@end

# bl.str2
tenant: No one is coming. Yes. That's the Stray curse. And the strange thing is, child, nobody came for me either. I had a clan and a Prince and a Court and forty years of a ghoul's loyalty and I died alone in a freezer with a meat hook for company.
tenant: Nobody's ever coming. The Stray just aren't lied to about it.
{do comp-1; sync+1; lean:candour+1}
@end

# bl.str3
tenant: A clan of two, one of whom is dead. Yes. Very Stray of you.
tenant: ...I'll take it. Don't tell the Court. They'd think I'd gone soft. I have gone soft. It's your fault.
{do sync+2}
@end

# bl.strd arc=dutch night=3,4,5 label="\"Local 0. Do the clanless take members?\"" if=clan:stray prio=2
@focus dutch
dutch: Members. You. The Sheriff's coat, the Sheriff's car, the Sheriff's blood, and you want a union card.
dutch: ...Ha. No. Wait. You mean it. You came out Stray. I can smell it now. Same as me. Same as the sixty-three. Nobody's dog.
dutch: Dues are a dollar a week. We meet Thursdays behind the bins at the Switchyard. Little Sal brings soup. Big Sal's boy. Big Sal brought soup for thirty years, God rest him, and nobody ate it then either. It's not about the soup.
* Pay the dollar.  -> bl.strd1 {if cash>=1}
* "I can't. Not while I'm wearing the coat."  -> bl.strd2
* "I'll be the Sheriff who has a union card. Imagine their faces."  -> bl.strd3 {if cash>=1}

# bl.strd1
> He takes the dollar. He writes you a receipt on the back of a bar coaster in pencil: *L0 · 1 wk · paid.* He writes your name. He spells it wrong. You keep it.
dutch: Member number sixty-four. Welcome to nothing, brother. Welcome to nothing at all.
{do cash-1; flag:local0Member=1; rel:dutch+2; lean:pride-1; flag:side_union=1}
@end

# bl.strd2
dutch: No. Course not. Coat's heavy. I get it.
dutch: The offer's there. It's always there. That's the thing about nothing: it doesn't close.
{do rel:dutch+1}
@end

# bl.strd3
dutch: Their faces. Séverine's face. Oh, God. Oh, sweet God. Give me the dollar.
> He laughs so hard he has to sit down on an upturned crate. He writes the receipt with his hands shaking. *L0 · 1 wk · paid · THE SHERIFF.* In capitals.
{do cash-1; flag:local0Member=1; flag:local0Sheriff=1; rel:dutch+3; flag:side_union=1; xp:20:Member 64}
@end

# bl.gld arc=tenant night=2,3,4,5 label="Ask him why every ugly thing in the Ward hurts now." if=clan:gilded prio=1
@focus tenant
tenant: Because the blood came out Gilded, and the Gilded feel ugliness in their teeth. The strip lights at Kowalski's. That man's polyester trousers at the bus stop. The new block on Halloran Street with the cladding.
tenant: I used to think they were being precious. Valentin Roux winces at a badly folded napkin. Ashby once left a dinner because the soup was beige. I thought: such affectation.
tenant: It isn't. I can feel it in you. It's like a dentist's drill. They live in a world that hurts them nearly all the time and they've decided to be charming about it.
* "How do they stand it?"  -> bl.gld1
* "I'll make the Ward less ugly, then."  -> bl.gld2
* "The ugly things are the honest ones. I'll learn to love them."  -> bl.gld3

# bl.gld1
tenant: By surrounding themselves with beautiful things and pretending the rest doesn't exist. That's what Elysium is. A crypt full of nice furniture so that two hundred people never have to look at the bus station.
tenant: You can't do that. You've been to the bus station. You've been in the freezer. I don't think you'll ever be able to pretend.
{do sync+1}
@end

# bl.gld2
tenant: The Ward. Less ugly. With a Sheriff's budget and four nights.
tenant: Start with the strip light at Kowalski's. That one's been hurting me since Monday.
{do lean:pride+1; flag:gildedFix=1}
@end

# bl.gld3
tenant: Love them. The polyester trousers.
tenant: ...That's the most Gilded thing I've ever heard. They all say that eventually. Usually about a lover. Usually about a lover in polyester.
{do lean:pride-1; comp+1; sync+1}
@end

# bl.gla arc=ashby night=3,4,5 label="\"Ashby. Why does the Court keep sending me flowers?\"" if=clan:gilded prio=2
@focus ashby
ashby: Because you're *ours*, darling. Didn't anyone tell you? The blood came out Gilded. You walked into the Reliquary on Tuesday and every one of us felt it like a tuning fork. A new voice in the choir. Well. Not the Choir. The other choir.
ashby: Absalom Vane's murderer, Absalom Vane's coat, and *our* blood. Séverine's beside herself. She can't decide whether to have you staked or adopted.
* "Tell her to decide quickly. I've got a Tribunal on Friday."  -> bl.gla1
* "I'm not yours. I'm nobody's."  -> bl.gla2
? stagecraft 10 "Adopted, obviously. Tell her I want the room with the good mirror."  -> bl.gla3 | bl.gla4 {id bl_gla}

# bl.gla1
ashby: Oh, she *has* decided. She decided on Tuesday. She just hasn't told herself yet. That's how she does everything.
{do rel:ashby+1}
@end

# bl.gla2
ashby: Nobody's. How *Stray* of you. You'll get over it. We all said that once. I said it in 1888 in a gin palace in Whitechapel and I've been someone's ever since.
{do rel:ashby-1; lean:pride-1}
@end

# bl.gla3
ashby: The room with the good... you don't have a reflection, darling. Oh. Oh, that's *wonderful*. That's the best joke anyone's made in the Court since the Abdication.
> He laughs so loudly a waiter drops a tray.
ashby: I'm going to tell everyone you said that. I'm going to tell it at your funeral or your coronation, whichever comes first.
{do rel:ashby+2; lean:pride+1; flag:gildedJoke=1; xp:20}
@end

# bl.gla4
ashby: The good mirror. Yes. Very funny. Darling, you can't land a joke in this Court until you've been dead at least fifty years. Practise. On the cattle.
@end

# bl.glle arc=lisette night=3,4,5 label="\"Lisette. The painting. Konrad was Gilded too, wasn't he?\"" if=clan:gilded&mem:lisette.hamburg prio=2
@focus lisette
lisette: Was. Is. Was. He walked into the Elbe in 1930. The water doesn't care what clan you are.
lisette: He used to say the world hurt him so much he had to paint it beautiful or go mad. He painted me for four years. He never got the mouth. He said my mouth was the only ugly thing about me, and he couldn't bear to paint it ugly, and he couldn't bear to lie.
lisette: You feel it too now, don't you. The drill. In your teeth.
* "Your mouth isn't ugly, Lisette."  -> bl.glle1
* "He should have painted it ugly. That was the lie."  -> bl.glle2

# bl.glle1
lisette: No. It's not. It's just a mouth. It took me ninety years to decide that. One, two, three...
> She's counting again. She's smiling. The almost-smile. All the way, this time. Nearly.
{do rel:lisette+2; mem:lisette:mouth}
@end

# bl.glle2
lisette: ...Yes. Yes. That's exactly it. That's what I've been trying to say since 1923. Nobody ever said it back.
{do rel:lisette+2; lean:candour+1; mem:lisette:mouth}
@end

# bl.chr arc=severine night=2,3,4,5 label="\"My lady. I keep humming. I can't stop.\"" if=clan:choir prio=2
@focus severine
severine: No. You can't. Every hour, or the blood curdles in your veins like old cream. Welcome to the Choir, Sheriff.
severine: Do you know what you're humming? I've been listening all night. It's the second line of the *Dies Irae*, in the old mode. Very badly. Very flat. It's the first thing every fledgling hums. Nobody knows why.
severine: I hummed it in 1791 in my cellar in Lyon for a priest who was hiding under the floor. It was the only thing I knew that he'd recognize.
* "Teach me the rest of it."  -> bl.chr1
* "What happened to the priest?"  -> bl.chr2 {if !flag:lyonDone}
* "I'd rather hum something cheerful."  -> bl.chr3

# bl.chr1
severine: The rest of it. All nineteen verses. You'll be a hundred and four before you can sing the twelfth.
> But she hums the third line, softly, behind her fan. You hum it back. Badly. Flat. In the crypt beneath Club Reliquary, the Keeper of Elysium and the dead Sheriff's murderer sing a funeral hymn together in very quiet harmony, and nobody in the room dares look.
{do rel:severine+2; xp:25:Dies Irae; flag:choirHymn=1}
@end

# bl.chr2
severine: The Committee took him in the spring of '93. My Prince could have stopped it. One word. He didn't say it. I've never forgiven him.
severine: He walked into the sun that summer. Everyone saw. I've never forgiven him for that, either.
{do mem:severine:priest}
@end

# bl.chr3
severine: Something cheerful. In the Choir. Darling, our idea of a cheerful hymn is the *Stabat Mater*. It's about a mother watching her son die. We consider the tune quite jaunty.
{do rel:severine+1}
@end

# bl.chrt arc=tenant night=2,3,4,5 label="\"Do you mind the humming?\"" if=clan:choir prio=1
@focus tenant
tenant: Mind it. It's the only part of this I like.
tenant: I had no music, child. Sovereigns don't. We have speeches. Two hundred years of speeches. I tried to learn the violin in 1840 and the teacher wept, and not in the good way.
tenant: Now every hour, in your throat, there's a tune. I can feel it in the bones of your face. It's like living in a house where somebody's always just put the kettle on.
* Hum something for him on purpose.  -> bl.chrt1
* "I'll try to keep it down."  -> bl.chrt2

# bl.chrt1
> You hum the only song you know all the way through. It isn't a hymn. It's the jingle from an ad for a carpet warehouse off the interstate, from when you were six.
tenant: ...
tenant: What *was* that?
tenant: Do it again.
{do sync+2; comp+1}
@end

# bl.chrt2
tenant: Don't. Please. It's the only thing in here that isn't me.
{do sync+1}
@end

# bl.hnd arc=valko night=3,4,5 label="\"Valko. You've stopped chasing me.\"" if=clan:hounds&!flag:valkoDead prio=2
@focus valko
valko: I haven't stopped. I'm standing still. It's different. It hurts more.
valko: You came out Hound. You know that? Of all the things. You drank the Sheriff dry and the blood came out *mine*. You run like me. You turn your head like me when a car door shuts two streets away.
valko: I can't hunt you. You understand? It's like hunting your own shadow. My legs won't do it. Sixty years he had me on a leash, and now my own legs have put me on another one.
* "Then stop hunting. Hunt with me."  -> bl.hnd1
* "That's not my problem, Valko."  -> bl.hnd2
? echo 10 "You've been following me for three nights. Not hunting. Following. Like a dog that's lost its owner."  -> bl.hnd3 | bl.hnd4 {id bl_hnd}

# bl.hnd1
valko: Hunt with... what is there to hunt?
* "Whoever fired the lance."  -> bl.hnd5
* "LANTERN."  -> bl.hnd5

# bl.hnd5
> He goes very quiet. His nostrils flare.
valko: Yes. Yes. Give me a scent. Give me something to chase that isn't you. I'll run till my feet come off.
{do rel:valko+2; flag:valkoHunts=1; lean:loyalty+1}
@end

# bl.hnd2
valko: No. It's mine. I'll carry it.
> He walks away. He gets to the end of the platform and stops, and stands there, very still, with his back to you, shaking like a dog in the rain.
{do rel:valko-1}
@end

# bl.hnd3
> He flinches as if you'd hit him. Then his shoulders drop.
valko: ...Yes. Yes. A dog. You smell like him and you walk like me and I don't know where else to go.
valko: Don't laugh. Please.
* "I'm not laughing. Walk with me."  -> bl.hnd6

# bl.hnd6
> He falls in beside you. Half a pace behind, the way he walked behind Vane for sixty years. You slow down until he's level. He looks at you, startled. He doesn't drop back.
{do rel:valko+3; flag:valkoWalks=1; xp:30:Heel; sync+1}
tenant: (very quietly) I never once let him walk beside me. Not once in sixty years. I didn't think he'd want to.
@end

# bl.hnd4
valko: Following. I don't follow. I *track*. Don't put words in my mouth, little thief.
@end

# bl.hndt arc=tenant night=2,3,4,5 label="\"Why can't I stop chasing things?\"" if=clan:hounds prio=1
@focus tenant
tenant: The Hound curse. Once you start, stopping hurts. Like holding your breath.
tenant: Valko told me once it's like an itch in the backs of the knees. He chased a pickpocket from the Strip to the river in 1977 for a wallet with nine dollars in it. He couldn't stop. He swam. He brought back the wallet. The pickpocket's still in therapy.
tenant: You chased a pigeon down Kerr Street tonight. Thirty yards. In the Sheriff's coat. I saw it through your eyes. I've never been so embarrassed in my life, and I've been dead.
* "I didn't mean to."  -> bl.hndt1
* "It was a very fast pigeon."  -> bl.hndt2

# bl.hndt1
tenant: No. Nobody ever means to. That's the trouble with all our curses: they're the one part of us that doesn't lie.
{do sync+1}
@end

# bl.hndt2
tenant: It was a very fast pigeon. I'll give it that. It went into a laundromat. You nearly followed it in.
{do sync+1; comp+1}
@end

# bl.mth arc=tenant night=2,3,4,5 label="\"Why do I keep losing time near screens?\"" if=clan:moths prio=1
@focus tenant
tenant: Because the blood came out Moth. The newest line. Barely forty years old. The Court still doesn't know whether to invite them or report them.
tenant: Do you know what it's like for me? I'm a man who regarded the telephone as a vulgar novelty. And now, every time you pass a shop window full of televisions, I feel us *lean*. Like a plant. Toward the light.
tenant: You lost eleven minutes outside the phone shop on Kerr Street tonight. I counted. You were watching an ad for a phone. On a phone. In a window.
* "It was a really good ad."  -> bl.mth1
* "Help me. Count for me. Pull me back."  -> bl.mth2
* "There's a whole world in there. You'd like it, if you let yourself."  -> bl.mth3

# bl.mth1
tenant: It was an ad. For a rectangle.
{do sync-1; comp+1}
@end

# bl.mth2
tenant: Count for you. Yes. I can do that. I've nothing else to do in here but count and regret.
tenant: When we pass a screen, I'll say "Agnes". Just her name. If you hear it, look away. It works for me, too. It's always worked for me.
{do sync+2; flag:mothCount=1; mem:tenant:mothcount}
@end

# bl.mth3
tenant: A whole world. Of rectangles.
tenant: ...Show me, then. One thing. Not an ad. Something real, from in there, that you think I'd like.
* Show him a video of the sea at Ajaccio, filmed last summer by a tourist.  -> bl.mth4
* Show him the Port Vellum Public Library's scanned archive of the Courthouse staff photo, 1928.  -> bl.mth5

# bl.mth4
> A shaky phone video. The harbour at Ajaccio, last August. Blue, white, a ferry, gulls, somebody's child shouting in French. The citadel on the point, exactly where it was in 1761.
tenant: ...
tenant: It's still there. The citadel. It's still there and they let children shout at it.
> He doesn't say anything else for a long time. You watch it four times.
{do sync+3; comp+1; xp:20}
@end

# bl.mth5
> A scanned photograph. Grainy, sepia, a hundred and one faces on the Courthouse steps. Third row, fourth from the left: a young woman with a typist's posture, not smiling, almost smiling.
tenant: Agnes.
tenant: Agnes. That's Agnes. In a rectangle. Anyone in the world could look at her. Anyone.
tenant: Save it. Can you save it? Is that a thing you can do? Save her.
{do sync+3; flag:agnesPhoto=1; xp:20}
@end

# bl.mthl arc=leo night=2,3,4,5 label="\"Leo. Give me your phone. Thirty seconds.\"" if=clan:moths&alive:leo prio=1
@focus leo
leo: My phone. Sure. Why... oh my God, your eyes are doing the thing. The blue thing. Like a screensaver.
> You hold it. The cracked screen lights up under your thumb, and the whole of it opens like a door: every app, every message, every search he deleted, every voice note he never sent his mother.
> There are forty-one drafts to *Mom*. All unsent. The newest is from Tuesday. *I'm ok. I'm with a friend. Don't call the police again. I love you. I'll explain.*
* Send it.  -> bl.mthl1
* Give him the phone back. Don't say anything.  -> bl.mthl2
* "Leo. You've got forty-one drafts to your mom."  -> bl.mthl3

# bl.mthl1
> *Sent.* Two ticks. Thirty seconds later, three dots. Then: *Thank God. Thank God. Come home when you can. I made lasagne. It's in the freezer.*
> You hand him the phone. He reads it. He reads it again. He sits down on the curb.
leo: You sent... she made lasagne. She... it's in the freezer. Of course it's in the freezer. Everything in my life is in a freezer.
> He laughs. Then he doesn't.
{do rel:leo+1; flag:leoMomText=1; lean:candour-1}
leo: Don't do that again. Ever. Don't do it again. ...Thank you.
@end

# bl.mthl2
> You hand it back. He looks at your face, and at the phone, and you can see him decide not to ask.
{do lean:restraint+1; rel:leo+1}
@end

# bl.mthl3
leo: You... read my... okay. Okay. Yes. I have forty-one drafts to my mom. I'm a grown man and I can't text my mother "I'm alive".
leo: Every time I write it, I think: what if she asks where I am. And I'd have to say "in a crypt with a vampire who owes me a knee". So I don't send it.
* "Send it. Don't explain. Just send it."  -> bl.mthl4

# bl.mthl4
> He looks at the screen. His thumb hovers. Then, very fast, before he can think, he sends it.
leo: Oh God. Oh God oh God oh God.
> Three dots. *Thank God. Thank God. Come home when you can. I made lasagne.*
leo: ...She made lasagne.
{do rel:leo+2; flag:leoMomText=1; lean:candour+1; comp+1}
@end

# bl.mthh arc=harrow night=3,4 label="\"Your phone's lying to you, Agent Harrow.\"" if=clan:moths&!flag:harrowDead prio=2
@focus harrow
harrow: My phone.
harrow: My phone is a government device on an encrypted network that the National Security Agency can't read.
> His phone is in your head like a radio. Every message. Every photo. A thread called LANTERN — OPS. A thread called M. A thread called DAUGHTER — DON'T. The last message in DAUGHTER — DON'T is from him, three weeks ago, unanswered. *Happy 19th, kiddo. I'm sorry about the recital.*
* "Your daughter didn't answer because you sent it at four in the morning. She was asleep. Try at a normal hour."  -> bl.mthh1
* Read him the LANTERN thread instead. Every line.  -> bl.mthh2

# bl.mthh1
> He goes white. Then something else. He takes his sunglasses off. It's the first time you've seen his eyes. They're ordinary. Brown. Tired.
harrow: ...How do you know about the recital.
harrow: Don't answer that. Don't. I don't want to know.
> He puts the sunglasses back on. His hand is not quite steady.
{do rel:harrow+1; flag:harrowDaughter=1; mem:harrow:daughter}
@end

# bl.mthh2
> You read it to him. Dates. Names. A line from somebody called M, last Thursday: *If the Ward goes, it goes. The lamps are the lamps. Don't get sentimental, Tom.*
harrow: Stop. Stop.
harrow: You can't... that's... who else can do this.
* "Every Moth in the city. There are about forty of us."  -> bl.mthh3

# bl.mthh3
harrow: Forty. Forty of you. Reading every... oh, Jesus.
> For the first time all week, Special Agent Thomas Harrow looks like a man who's realized he's standing in the dark.
{do flag:harrowShaken=1; heat-1; xp:30:Signal}
@end
`,'c_blood2');
NL.Act.extraFates.push(S=>{const f=S.flags,o=[];
  if(f.tinyHealed)o.push(['The Reliquary door','Tiny reads a book a week now, on his own time, on a bench by the river. The doctors at St. Jude\'s have him written up as a spontaneous remission. Dr. Rostova keeps the real notes in a locked drawer.']);
  else if(f.tinyBetter)o.push(['The Reliquary door','Tiny goes to St. Jude\'s twice a week now, not three times. He uses the extra mornings to sleep. He says it\'s the best present anyone ever gave him.']);
  if(f.local0Sheriff)o.push(['Local 0','Has a framed bar coaster on the wall behind the bins at the Switchyard: L0 · 1 WK · PAID · THE SHERIFF. Nobody in the Gilded Court has ever been shown it. All of them have heard about it.']);
  if(f.leoMomText&&!f.leoDead)o.push(['A lasagne in a freezer in Scranton','Got eaten, eventually, on a Sunday, by a mother and a son who didn\'t talk about where he\'d been. They talked about the lasagne.']);
  if(f.valkoWalks&&!f.valkoDead)o.push(['The Hound','Walks beside the Sheriff now, not behind. The Court finds it shocking. Valko finds it difficult. He does it anyway.']);
  return o;});
