'use strict';
/* THE NEW LORD — the last twenty minutes, part three; and the Tribunal remembers a little more */
(function(){const O=NL.Script.opt;
O('dw.talk','* Lord Ashby, sitting on the platform edge with his sword across his knees.  -> dw3.ashby {once} {if flag:ashbyStands&!flag:ashbyDead}','start');
O('dw.talk','* Coral, at the back, with a paper cup and a screwdriver.  -> dw3.coral {once} {if flag:coralFree&!flag:purge}','start');
O('dw.talk','* Gregory, holding the Magistrate\'s coat.  -> dw3.greg {once} {if flag:petitionDone&!flag:massacre&!flag:purge}','start');
O('dw.talk','* The old Prince of Lyon, still on the top step.  -> dw3.oldp {once} {if flag:mqOldPrince|mem:oldkin.lyon}','start');
O('dw.talk','* Lady Ottilie, alone in the front row, very still.  -> dw3.ott {once} {if flag:ottConfessed&!flag:massacre&!flag:purge}','start');
O('dw.talk','* Priya, half-hidden behind Gideon.  -> dw3.priya {once} {if flag:priya&!flag:purge}','start');
})();
NL.Script.add(String.raw`
# dw3.ashby
@focus ashby
ashby: I stood up. In the chalk. Sober. I said a true thing in public. My hands are still shaking. Look.
ashby: I haven't done that since 1912. I'd forgotten how it feels. Like falling off a horse, but upward.
* "Bramble would be proud."  -> dw3.ash1 {if mem:ashby.bramble}
* "Thank you, Edmund."  -> dw3.ash2

# dw3.ash1
> He laughs. Then he doesn't. He looks at the grey light coming through the grate.
ashby: Bramble would have thrown me into a hedge for being sentimental. But yes. Yes. I think he might.
{do rel:ashby+2; comp+1}
@next dw.talk

# dw3.ash2
ashby: Don't. Don't, or I'll have to have a drink, and I've promised myself I won't until Christmas. Christmas! Imagine.
{do rel:ashby+1}
@next dw.talk

# dw3.coral
@focus coral
coral: I saw it. I saw someone stand up to them. In the chalk. In front of all of them.
coral: I've got an interview on Monday. I'm going to wear flat shoes. I'm going to sit in a chair that isn't a chaise longue and answer questions about my typing speed.
coral: Thank you. I don't know what for, exactly. For the flat shoes.
{do rel:coral+1; comp+1}
@next dw.talk

# dw3.greg
@focus ghoulchauffeur
ghoulchauffeur: His Lordship has asked me to say: "Adequate." It's the highest compliment he gives. He said it to Absalom twice in two hundred years.
ghoulchauffeur: He also asked me to say: "Christmas Eve. The car. Bring the forty francs." I don't know what that means. I'm told you will.
{do comp+1}
@next dw.talk

# dw3.oldp
@focus oldkin
> The old Prince of Lyon hasn't moved from the top step all night. His black mask is in his lap now. His face is very old and very ordinary: an old man's face, like someone's grandfather at a bus stop.
oldkin: I watched it all. I haven't watched a Tribunal since 1793. It was the same. It was completely different. You said please to the Magistrate. Nobody has ever said please to the Magistrate.
oldkin: Keep the ones who knew you before. Did you? Did you keep them?
* "I tried."  -> dw3.op1
* "Yes."  -> dw3.op2

# dw3.op1
oldkin: Trying is the whole of it. Nobody keeps them all. I kept nobody. You tried. That's the difference between us, and it's everything.
@next dw.talk

# dw3.op2
oldkin: Good. Good. Then I'm going back to my deckchair. The buses start at six.
> He puts the mask back on. He goes up the stairs into the grey street and doesn't look back.
@next dw.talk

# dw3.ott
@focus ottilie
> Lady Ottilie Brand, in grey pearls, alone in the front row. The notebook is gone. Her hands are folded in her lap with nothing in them.
ottilie: They haven't decided what to do with me yet. Ambrose said "another night". He says that when he means "a long time".
ottilie: I've never not had something to write in. I don't know what to do with my hands.
* "Write a letter. To someone who isn't Tom."  -> dw3.ot1
* "You'll think of something."  -> dw3.ot2

# dw3.ot1
ottilie: A letter. To whom? I've only ever written columns.
ottilie: ...My sister. In Bath. I haven't written to her since 1902. She'll be dead, of course. Her granddaughter, then. Or her granddaughter's granddaughter. Someone should tell them I was there.
{do comp+1}
@next dw.talk

# dw3.ot2
ottilie: Yes. I expect I will. I always do. That's the trouble.
@next dw.talk

# dw3.priya
@focus priya
priya: I came. Gideon said I could stand behind him. He said nobody looks behind a pawnbroker.
priya: Is this it? Is this what it's going to be? Forever? Chalk circles and old men in red robes and everybody watching everybody?
* "Sometimes. Mostly it's rats and buses and a coffee you can't drink."  -> dw3.pr1
* "It's whatever you make it, Priya."  -> dw3.pr2

# dw3.pr1
priya: Rats and buses. Okay. I can do rats and buses.
{do comp+1}
@next dw.talk

# dw3.pr2
priya: Whatever I make it. That's a lot of pressure for someone who still can't open a coffin without hitting her head.
@next dw.talk
`,'c_dawn3');
(function(){const {L,T,ENC}=NL.DSL;if(!ENC.tribunal)return;const mv=ENC.tribunal.moves;
ENC.tribunal.moves=function(st,S,G){const M=mv.call(this,st,S,G);const f=S.flags;
  if(f.cohortRos&&!f.rostovaDead)M.push({t:'"Dr. Rostova has two of Cohort B with her tonight. Marisol Vega and Jerome Akers. Living proof."',once:'tb_cohort',ok:st=>{st.prog+=2;return [T('At the edge of the platform, behind Rostova, a woman in a blanket and a big man with grey at his temples step forward into the lamplight. Their eyes catch the light the way an animal\'s do. Amber.'),L('magistrate','...Mortals. Half-made. With a Sovereign\'s blood in them.'),L('jerome','Five hundred dollars and a taxi, your honour. That\'s what they gave us.')];}});
  if(f.sixcSev&&!f.sevDead&&!f.sevVouch)M.push({t:'Hum, under your breath, very quietly, the first bar of the aria from 6C.',once:'tb_tenor',ok:st=>{st.threat=Math.max(0,st.threat-2);return [T('Séverine hears it. Of course she does. Across the chalk, her face does nothing at all. Her next accusation is very short, and she sits down before she\'s finished it.')];}});
  if(f.dinnerDone)M.push({t:'"I had dinner on Wednesday in a flat on the fourth floor of the Rookery with twelve mortals who know what I am. Ask them if I\'m a monster."',once:'tb_dinner',ok:st=>{st.prog+=1;return [L('magistrate','Dinner. With mortals. Who know.'),L('magistrate','...I have presided over this Court for six hundred years and I have never once been invited to dinner by a mortal. Noted.')];}});
  if(f.wenWater)M.push({t:'Close your eyes in the chalk. Listen, the way the old man on the wall taught you. Let them see how still you can be.',once:'tb_wen',ok:st=>{st.threat=Math.max(0,st.threat-1);st.prog+=1;return [T('For eleven seconds the defendant stands in the chalk circle with its eyes shut and does nothing at all. Three hundred Kindred watch. Something in the stillness unsettles them more than any speech.'),L('tenant','(very quietly) The water. You found it. In front of them all.')];}});
  return M;};})();
