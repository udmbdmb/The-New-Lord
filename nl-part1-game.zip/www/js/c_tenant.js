'use strict';
/* THE NEW LORD — conversations with the Tenant, available any time from the character sheet when he has something to say */
NL.Camp.tickHooks.push((S,G)=>{if(!S.flags.woke||S.chapter==='end')return;const a=NL.Script.arcFor('tenant',S);if(a&&S.flags.tenantNudge!==a.id){S.flags.tenantNudge=a.id;setTimeout(()=>G.toast('rel','The Tenant clears his throat. <b>Open your character sheet</b> to listen.','The Tenant'),2200);}});
NL.Script.add(String.raw`
// =====================================================================
// NIGHT ONE
// =====================================================================
# tn1.rules arc=tenant night=1 label="The rules" prio=5
tenant: A word, child, while you're walking. You're about to go into a city that's been running on rules for three hundred years, and you know none of them. That's dangerous. Mostly for other people.
tenant: Three rules. Everything else is commentary.
tenant: One: the Masquerade. Mortals must never know. Not because they'd hunt us, though they would. Because once they know, they never stop knowing, and a city that knows is a city that burns.
tenant: Two: Elysium. Certain places are sanctuary. The crypt under the Reliquary is one. Nobody harms anybody there. Break that and every Kindred in the city has leave to destroy you.
tenant: Three: the Prince. Port Vellum has one. She lives on the Heights, in a house with no windows, and she hasn't been seen by anyone below the rank of Magistrate since 1912. Her word is law. Her Magistrate is her mouth.
* "She?"  -> tn1.she
* "And the Sheriff? You?"  -> tn1.sheriff
* "What happens if I break them?"  -> tn1.break

# tn1.she
tenant: Prince Theodora Vell. The city's named after her family's river, or the river after her family; nobody remembers which came first, and it's rude to ask.
tenant: I met her once. 1803. I was on my knees. She asked me what I thought of the harbour. I said it was very fine. She said, "It's mine," and that was the whole conversation. I was made Sheriff of the Marrow Ward a hundred and twenty years later. I've never been sure if the two things were connected.
{do mem:tenant:prince}
@next tn1.end

# tn1.sheriff
tenant: The Prince's hand in one district. I keep the peace, collect the tithe, settle the disputes, destroy what needs destroying. In return the Court lets me take my ten percent and pretend not to notice.
tenant: I was the law in the Marrow Ward for eighty years. You'll notice the Marrow Ward is not, as a result, especially lawful. Draw your own conclusions.
@next tn1.end

# tn1.break
tenant: The Masquerade, and you'll be hunted by both sides: the Court for embarrassing them, the mortals for existing. Elysium, and you'll be destroyed by whoever gets to you first, which will be Séverine, who's been waiting for an excuse since the Coolidge administration. The Prince, and nothing happens at all, for about a week. Then something does. Nobody ever finds out what.
@next tn1.end

# tn1.end
tenant: That's all. Go on. I'll be here. I'm always here now.
@end

# tn1.clan arc=tenant night=1,2 label="Your blood" if=flag:clanKnown|clan:sovereign|clan:wraiths|clan:glass|clan:choir|clan:butchers|clan:hounds|clan:alchemists|clan:hollow|clan:rot|clan:stray prio=4
tenant: You've seen your face now. In the mirror. You know what your blood is. Let me tell you what it means, since nobody else will.
@gate clan:sovereign ? tn1.c_sov : tn1.c2

# tn1.c2
@gate clan:wraiths ? tn1.c_wra : tn1.c3
# tn1.c3
@gate clan:glass ? tn1.c_gla : tn1.c4
# tn1.c4
@gate clan:choir ? tn1.c_cho : tn1.c5
# tn1.c5
@gate clan:butchers ? tn1.c_but : tn1.c6
# tn1.c6
@gate clan:hounds ? tn1.c_hou : tn1.c7
# tn1.c7
@gate clan:alchemists ? tn1.c_alc : tn1.c8
# tn1.c8
@gate clan:hollow ? tn1.c_hol : tn1.c9
# tn1.c9
@gate clan:rot ? tn1.c_rot : tn1.c_str

# tn1.c_sov
tenant: The Sovereign. My blood. Well: my blood now, whatever it was before. The oldest money in the dark. We drink only the finest; our stomachs refuse the gutter. We rule by being *expected* to rule.
tenant: The curse is the palate. You'll find you can't keep down rat or bag or drunk. It's not snobbery. It's anatomy. Snobbery came afterwards, to make the anatomy feel like a choice.
tenant: You'll do well in the Court. You'll hate yourself for it a little. That's how you know you're doing it properly.
@next tn1.cend

# tn1.c_wra
tenant: The Wraiths. Soot's children. Your face is the curse: the blood eats it, slowly, until you look like what you are. Bright rooms will hurt you more than the rest of us. Masks help. Dark helps more.
tenant: But Wraiths hear things. Pipes, walls, the dead. Soot's whole empire is built on the fact that nobody ever looks at a Wraith long enough to notice they're listening.
tenant: I knew a Wraith once who sat on the Courthouse steps at three and counted stars. I never asked her name. I regret that.
@next tn1.cend

# tn1.c_gla
tenant: The Glass. Rare. Very rare. Your blood sees around corners: in mirrors, in water, in anything that reflects. Sometimes you'll see twenty minutes from now. Sometimes twenty years ago. Sometimes yourself, looking back, disappointed.
tenant: The curse is the mind. It cracks. Fail badly enough, and something in you will shatter for a while and come back in the wrong shape. Keep calm. Keep mirrors close. Don't trust a reflection that smiles first.
@next tn1.cend

# tn1.c_cho
tenant: The Choir. Séverine's lot, though she'd faint to hear me say you belong to her. Your blood is music: a voice that goes into people like wine, songs that stop hearts or start them.
tenant: The curse is beauty. You'll need it. A room without art in it will make you dull and stupid until you've admired something properly. You'll find yourself staring at a well-made door for a full minute. Indulge it. It's cheaper than the alternative.
@next tn1.cend

# tn1.c_but
tenant: The Butchers. Malakor's people. Your blood shapes flesh: your own, others'. Faces, bones, the soft places where a body wants to come apart.
tenant: The curse is that the living can feel it on you. Talk to a mortal long enough and they'll start to feel something's wrong. Uncanny. Like a doll that blinked. Keep it short with the warm ones.
tenant: And the old Butchers say that sooner or later every one of you meets the face you were born with, and has to decide whether to keep it. I never understood what they meant. I think you might.
@next tn1.cend

# tn1.c_hou
tenant: The Hounds. Valko's kind. The Beast is close to the skin in you: you'll smell fear across a street, run faster than you should, fight like a thing in a pit. And you'll be hungrier sooner than the rest of us.
tenant: The curse is the hunger. Feed often or the Beast drives. A Hound who doesn't feed is a disaster that hasn't been scheduled yet.
tenant: Be careful with Valko. He'll know you're one of his before you open your mouth. Hounds always do.
@next tn1.cend

# tn1.c_alc
tenant: The Alchemists. Contract-blood. Your word is in your veins: promise something, and the blood holds you to it. Break a promise and it boils. Literally. You'll find out the first time.
tenant: In return, the blood listens to other people's promises too. You'll know when someone means it. You'll know when they're lying about meaning it. It makes you excellent at business and terrible at parties.
tenant: Promise carefully. I mean that more than I've meant anything tonight.
@next tn1.cend

# tn1.c_hol
tenant: The Hollow. The shadow-blood. Dark is your element: you'll step through it, hide in it, send it to do your errands. Your shadow will sometimes have opinions. Listen to it. It's usually right.
tenant: The curse is the light. You can't be still in bright places. You'll feel watched. You'll be watched. The Hollow are the only Kindred I know who are frightened of their own reflections, because sometimes the reflection isn't theirs.
@next tn1.cend

# tn1.c_rot
tenant: The Rot. The plague-blood. Disease is your friend: you carry it, shape it, cure it, spread it. Mortal blood does less for you unless it's sick. You'll find yourself drawn to hospitals, to the coughing, to the dying. That's not ghoulish. That's appetite.
tenant: The Rot get a bad name. They're the only Kindred who've ever cured anything. Elena Rostova would give her soul to have your blood in a dish. I'm not certain she hasn't already.
@next tn1.cend

# tn1.c_str
tenant: The Stray. No clan. No line. You're what happens when the blood takes someone without ceremony, without a sire who cares. The Court calls you clanless and means rubbish.
tenant: But the Stray can eat anything. Rats, bags, the gutter. Nothing's beneath you, which means nothing can starve you. And nobody's watching you, which in this city is a kind of armour.
tenant: The curse is Elysium. Rooms full of the Court will make you small. Your tongue will trip. Your skin will crawl. Stay out of their crypt when you can. Make your own.
@next tn1.cend

# tn1.cend
tenant: Whatever your blood was before, it's mine now too. We'll find out together what that makes you.
{do flag:clanKnown=1}
@end

// =====================================================================
// NIGHT TWO
// =====================================================================
# tn2.1977 arc=tenant night=2,3 label="1977" if=mem:pemberton.years|mem:pemberton.love prio=2
tenant: Pemberton mentioned 1977. Or nearly did. He never says it out loud. I'll tell you, because you're going to ask him eventually and it would be kinder if you didn't have to.
tenant: There was a Hound called Rask. A friend of Valko's. He went wrong in the summer of '77: stopped feeding properly, started hunting on the docks, three dockers in a week. The papers said a dog. It wasn't a dog.
tenant: The Prince told me to put him down. I took Pemberton because Valko wouldn't come. Valko knew. He sat in the car and wouldn't look at me.
tenant: Rask was waiting for us. He'd known I'd come. He went for Pemberton first, because he knew it would slow me down. He opened Pemberton from shoulder to hip in the container yard at Pier Nine.
* "What did you do?"  -> tn2.77a
* "Pemberton survived."  -> tn2.77b

# tn2.77a
tenant: What do you think. I did what I was sent to do. It took a long time. Rask had been my friend too, a little. And then I knelt in the container yard and fed Pemberton from my wrist for an hour while he bled out and came back and bled out again.
tenant: He lived. He's been mine, in the blood, more than ever since. I think that's why he stays. Not loyalty. Plumbing.
* "You don't believe that."  -> tn2.77c
* "That's a terrible thing to say."  -> tn2.77c

# tn2.77b
tenant: He did. Barely. I fed him from my wrist for an hour in the container yard, with Rask in pieces around us and the gulls coming down. He came back, three times. The third time he said, "Sir, your cuff's ruined." I laughed so hard I nearly lost him again.
@next tn2.77c

# tn2.77c
tenant: ...No. You're right. He stays because he's Pemberton. I've never known what to do with a man like that. I still don't. I'm leaving him to you.
{do mem:tenant:1977; sync+2:Pier Nine}
@end

# tn2.valko arc=tenant night=2,3 label="About Valko" if=flag:knowValkoLove|night:2 prio=1
tenant: Valko will come for you. Tomorrow, probably. Séverine's made sure of it.
tenant: I want you to understand something before he does. I bought him in a dog-pit in 1951 for twelve pounds. I let him out of the cage because I thought that was kindness. Then I beat him for seventy years when he got things wrong, because I thought that was kindness too.
tenant: He'll tell you I never once called him a dog. That's true. I called him Mr. Valko. I thought it made up for the rest. It didn't. I knew it didn't. I kept doing it because he smiled when I said it.
* "Why are you telling me?"  -> tn2.va
* "What should I do when he comes?"  -> tn2.vb

# tn2.va
tenant: Because you're going to have to decide what he is to you. A threat, a servant, a weapon, a friend. I never decided. I let him be all four and called it loyalty.
@next tn2.vb

# tn2.vb
tenant: Don't fight him if you can help it. You'll lose, or you'll win, and either is terrible. Give him something to hold instead of me. A name. A task. A reason.
tenant: And if you can, don't hit him. Ever. Not once. He's had enough.
{do mem:tenant:valko}
@end

# tn2.court arc=tenant night=2,3 label="The Court, the Syndicate, the dead" if=night>=2 prio=0
tenant: You've met them all now, or near enough. Let me tell you who they are underneath. It's quicker than finding out.
tenant: Séverine wants to be loved and has decided to settle for being obeyed. Malakor wants to be understood and has decided to settle for being paid. Soot wants to know everything and has never once settled for anything.
tenant: The Court is old money pretending to be old blood. The Syndicate is new blood pretending to be a business. The Wraiths are the only ones who don't pretend, and nobody listens to them, which suits them perfectly.
* "And you? What were you?"  -> tn2.cyou
* "Who do I side with?"  -> tn2.cside

# tn2.cyou
tenant: The man in the middle. Taking ten percent from all three to keep them from killing each other. A referee who bet on every game.
tenant: It worked for eighty years. That's longer than most things in this city work.
@next tn2.cend

# tn2.cside
tenant: Side? You don't side. You let each of them think you've sided with them, and then on Friday you find out which of them believed you.
tenant: Or you could do something none of us have tried in three hundred years and tell all of them the truth. I've no idea what would happen. I'd like to find out.
@next tn2.cend

# tn2.cend
@end

# tn2.hall arc=tenant night=2,3,4,5 label="The hallway" if=kills>=2 prio=6
tenant: Child. The hallway's getting crowded.
tenant: I told you they come in here. The ones you drain all the way. There are doors along the corridor now, more than there were on Monday. Some of them have people behind them. They knock.
tenant: I sit with them, sometimes. When you're asleep. I tell them where they are. Most of them want to know if anyone's feeding their dog.
* "Who are they?"  -> tn2.h1
* "Can I let them go?"  -> tn2.h2
* "I don't want to know."  -> tn2.h3

# tn2.h1
tenant: Strangers, mostly. A man coming out of a bar. A cop. Whoever it was. They don't tell me their names. They tell me what they were doing when you found them. One of them was going to propose. He had the ring in his pocket. He keeps asking me if she'd have said yes.
{do comp-2:The hallway; sync+3:The corridor}
@next tn2.hend

# tn2.h2
tenant: I don't know. I've never managed it. Four hundred and eleven of mine and not one has left. Maybe you'll be better at it. Maybe that's what Golconda is: an empty corridor.
{do mem:tenant:hallway}
@next tn2.hend

# tn2.h3
tenant: No. Of course not. Neither did I. That's how it gets to four hundred and eleven.
@next tn2.hend

# tn2.hend
tenant: Be careful how many more doors you make. That's all I'm saying. That's all I've got the right to say.
{do lean:restraint+1}
@end

// =====================================================================
// NIGHT THREE
// =====================================================================
# tn3.cure arc=tenant night=3,4 label="Why he wanted the sun" if=flag:readVaneLetter prio=4
tenant: You read the letter. So you know. I went to Elena Rostova because I wanted to stand in the sun.
tenant: Not to be mortal. I'm too old to be mortal; I'd turn to dust like a mummy in a museum. Just to stand in it. Once. On the Courthouse steps at noon with my face turned up.
tenant: Agnes used to describe it to me. Every letter. The color of the harbour. The way the light comes through leaves. I read those letters for thirty-five years. When she died I realized I would never see a single thing she'd described. Not one.
* "And you let seven people die for that."  -> tn3.ca
* "I understand."  -> tn3.cb
* "Was it worth it?"  -> tn3.cc

# tn3.ca
tenant: Yes. For three weeks I knew, and every night I drove past that clinic and told myself she was close, that the next one would work, that the deaths would mean something if she got there.
tenant: That's the oldest lie there is, child. The deaths will mean something. They never do. They're just deaths. I knew that in 1720 and I forgot it in my old age because I wanted something.
{do sync-2:The truth; lean:candour+1}
@next tn3.cend

# tn3.cb
tenant: Don't. Don't understand. That's how it starts.
{do sync+2:Understanding}
@next tn3.cend

# tn3.cc
tenant: I died in a freezer before I found out. So, no. But I'm told that's the usual price of asking.
@next tn3.cend

# tn3.cend
tenant: If you get the chance at the sun, on Friday. If the Vessel's in your hand and the dial's under your thumb. Don't do it for me. Do it for yourself or not at all.
@end

# tn3.eight arc=tenant night=3,4,5 label="Number eight" if=flag:knowVaneWitness prio=5
tenant: I owe you this. I should have said it on Monday, in the study, the first night. I didn't know you'd forgotten. I thought you were being polite.
tenant: October. Elena's basement. I went down at three in the morning to see for myself, and there were eight cots, and on the eighth you were reading *The Idiot* with a drip in your arm.
tenant: You looked up. Everyone else on those cots looked at me and saw a ghost, a doctor, a nightmare. You looked at me and said, "You're not supposed to be down here either, are you?"
nostalgia(5): A tall man in a grey coat in a white basement, sitting on the edge of the next cot, laughing quietly. *No. No, I'm not.*
* "Why did you take me out?"  -> tn3.e1
* "What did I do for you? The job."  -> tn3.e2

# tn3.e1
tenant: Because you asked me to. Very politely. "If you're the sort of person who can walk out of here, could you take me with you?"
tenant: And because you reminded me of someone. Not Agnes. Me, perhaps, a long time ago, before I was this. Someone who'd ask a ghost a question instead of screaming.
@next tn3.e2

# tn3.e2
tenant: A witness. You'd been on the cots for two months; you'd seen everything. On Friday you'd have stood in front of the Prince's Magistrate and told her what Elena did and what LANTERN paid for. A mortal witness. They can't argue with a mortal witness.
tenant: I paid you two thousand a month. You spent it on books and a cat that wasn't yours. I picked you up outside St. Jude's every night that week and drove you to the Courthouse to rehearse, and you read me bits of Dostoevsky in the back of the car, and I pretended to be bored.
tenant: And on Monday morning I brought you with me to Kowalski's to meet a man who said he had proof. There was no man. There was a light.
* "So I'm the witness. I still am."  -> tn3.e3 {do lean:candour+1}
* "You got me killed."  -> tn3.e4

# tn3.e3
tenant: You still are. More than ever. You saw everything, and then you drank the rest. There's never been a witness like you.
{do flag:knowWitnessRole=1; sync+3:Number eight}
@next tn3.eend

# tn3.e4
tenant: Yes. I did. I'm sorry, Casey. I don't think I've said that to anyone in a hundred years and meant it the way I mean it now.
{do sync+2:Number eight; comp+1}
@next tn3.eend

# tn3.eend
tenant: You were reading *The Idiot*. You'd got to the part where Myshkin goes to the party. You never finished it. I've been meaning to tell you how it ends. Badly. Everything Dostoevsky wrote ends badly. You'd have liked it anyway.
@end

# tn3.sev arc=tenant night=3,4 label="Lyon, 1920" if=flag:knowSevSire prio=2
tenant: Séverine told you about her sire. Did she tell you how he died?
tenant: The Prince of Lyon's favorite, the man in the third box. He came to Port Vellum in 1920 to visit his creation. He was cruel to her at the Christmas ball, in public, the way old Kindred are cruel to their childer: about her accent. About her mother.
tenant: Prince Theodora had me deal with him. Not because of Séverine. Because he insulted the harbour.
tenant: I did it on the quay at dawn. I let the sun do it. He begged. I'm told I was very calm.
tenant: Séverine was watching from a carriage. She'd planned it for thirty years. She'd planned to do it herself, slowly, in her own time. And I did it for a Prince who didn't care, and she never forgave me for taking it away from her.
* "So that's what the hate was."  -> tn3.s1
* "Did you know she was watching?"  -> tn3.s2

# tn3.s1
tenant: Mostly. Partly it was the hats.
@next tn3.send

# tn3.s2
tenant: I knew. I waved. That was the unforgivable part, I think. Not the killing. The wave.
@next tn3.send

# tn3.send
tenant: If you want her on your side on Friday, give her something back. Something she wanted to do herself and never got to. She'll pretend not to care. She'll care for a hundred years.
{do mem:tenant:sevsire}
@end

// =====================================================================
// NIGHT FOUR
// =====================================================================
# tn4.ward arc=tenant night=4 label="What keeping the Ward means" prio=3
tenant: Tomorrow, if it goes well, someone will ask you to keep the Marrow Ward. I want you to know what you'd be saying yes to.
tenant: It's not the Court and the Syndicate and Soot. Those are the weather. The Ward is Tariq's light and Gideon's boxes and Mrs. Okafor's tea and Halloran's cats and Margo's freezer and a comedian on a Tuesday. It's four blocks of people who are mostly not monsters and who have learned to live next to the ones who are.
tenant: Keeping it means making sure the monsters stay hungry enough to behave and fed enough not to riot. It means taking money you don't want from people who can't afford it so that worse people don't take more. It means sitting in a chair every night watching a door.
* "Did you ever enjoy it?"  -> tn4.w1
* "I don't want it."  -> tn4.w2 {do lean:pride-1}
* "I want it."  -> tn4.w3 {do lean:pride+1}

# tn4.w1
tenant: Every night at three. Walking past the Lucky Mart. Seeing the boy's light on. That was the whole job, for me. The rest was paperwork.
@next tn4.wend

# tn4.w2
tenant: Good. Then you might be the right person for it. The ones who want it are always the wrong ones. I wanted it terribly, in 1923.
@next tn4.wend

# tn4.w3
tenant: Honest. Good. Then want it for the right reason, or the chair will eat you the way it ate me.
@next tn4.wend

# tn4.wend
@end

# tn4.mirror arc=tenant night=4,5 label="Who's talking" if=sync>=50 prio=4
tenant: Have you noticed? Your handwriting's changing. You signed for the coffee at the Lucky Mart last night and the C had a flourish on it. I've always done the C with a flourish.
tenant: And you stand differently. Your left hand goes to your lapel when you're thinking. That's mine. That's eighty years of mine.
* "Stop it."  -> tn4.m1 {do sync-4:Holding the line}
* "Is it so bad?"  -> tn4.m2 {do sync+3}
* "Which of us is talking right now?"  -> tn4.m3

# tn4.m1
tenant: I'm not doing it on purpose. That's the frightening part, child. Neither of us is doing it on purpose.
@end

# tn4.m2
tenant: For you? I don't know. For me it's like coming home and finding someone's rearranged the furniture, and it's better, and I hate it.
@end

# tn4.m3
tenant: ...I genuinely don't know. Isn't that interesting.
@end

// =====================================================================
// NIGHT FIVE
// =====================================================================
# tn5.last arc=tenant night=5 label="Before one o'clock" prio=5
tenant: Here we are. Friday. I've been dreading this for a week, and you've been dreading it for four days, so I win.
tenant: One last thing. In the chalk circle, when the Magistrate looks at you, he'll be looking for me. He knew me for two hundred years. Whatever you say, he'll be listening for whether it's me saying it.
tenant: Decide before you go down. Whether you want him to hear me or you. I'll do whatever you decide. I mean that. I've never meant anything quite this much.
* "Me. Only me."  -> tn5.me {do sync-5:Your own voice; lean:pride-1}
* "Both of us."  -> tn5.both {do sync+3:Two voices}
* "You. You know them."  -> tn5.you {do sync+6:His voice}

# tn5.me
tenant: Good. Then I'll be very quiet. I'll be the floorboards. You won't hear a thing.
tenant: ...Except perhaps once. If you're about to say something truly stupid. I can't promise about that.
{do flag:tribunalVoice=you}
@next tn5.end

# tn5.both
tenant: Both. A chord. Two voices in one throat. They'll hate it. They'll never have heard anything like it.
{do flag:tribunalVoice=both; flag:chord=1}
@next tn5.end

# tn5.you
tenant: Me. All right. All right. I'll be gentle with your mouth. I'll give it back after.
{do flag:tribunalVoice=him}
@next tn5.end

# tn5.end
tenant: Whatever happens: thank you for this week. It's the most anyone's talked to me in a century. I'd forgotten how much I liked the sound of someone answering.
@end
`,'c_tenant');
