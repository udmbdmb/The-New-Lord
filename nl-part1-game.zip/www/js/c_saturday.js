'use strict';
/* THE NEW LORD — "Saturday": the first night after. If you are the Sheriff, there is one more night to play: three visits, and the first three laws of a new reign. */
(function(){
document.addEventListener('DOMContentLoaded',()=>{const N=NL.STORY.nodes;
  for(const id of ['lord','tenant']){const n=N['end.show.'+id];if(!n)continue;const cs=n.cs;
    n.cs=async(G,S)=>{if(!S.flags.satDone){S.flags.satDone=1;try{await G.talk(id==='tenant'?'sat.ten':'sat.0');}catch(e){console.error('saturday',e);}}return cs(G,S);};}
});
})();
NL.Script.add(String.raw`
// =====================================================================
// SATURDAY · the Sheriff's first night
// =====================================================================
# sat.0
> You sleep through Saturday in Absalom Vane's own coffin, in the room behind the ossuary that Pemberton has aired for you. Rosewood. Brass. A pillow that smells, very faintly, of a cologne nobody has made since 1974.
> At sunset you wake up as the Sheriff of the Marrow Ward.
tenant: Well. Here we are. Do you feel any different?
* "No."  -> sat.no
* "Yes. Heavier."  -> sat.heavy
* "I feel like you."  -> sat.you

# sat.no
tenant: Nor did I. It takes about forty years. Then you feel exactly the same, and older.
@next sat.desk

# sat.heavy
tenant: Good. It should be heavy. The day it stops being heavy is the day you should give it to someone else.
@next sat.desk

# sat.you
tenant: God forbid. Feel like yourself. I was a terrible Sheriff. I was a very good one, and a terrible one, at once. Be a better one.
@next sat.desk

# sat.desk
> The Sheriff's study at the back of Club Reliquary: a desk the size of a car, a green-shaded lamp, a pen-and-ink map of the Ward under glass, and a pile of letters already, sealed with wax, addressed to *The Sheriff* in eleven different hands.
> Pemberton has left a cup of something warm on the blotter that you can't drink. He's left it anyway.
pemberton: Good evening, Sheriff. The Prince has confirmed you by letter. It arrived at 4:17. She writes, and I quote, "Try to be quieter than Absalom." {if alive:pemberton&!flag:pemResigns}
> Pemberton is gone, to the sea, as he said he would. But there's a cup on the blotter, and a note in his handwriting: *For the first evening. One should have something warm on the desk, even if one can't drink it. — A.J.P.* {if alive:pemberton&flag:pemResigns}
tenant: Before anything else: there are people who'll want to see you. Not the Court. The ones who stood with you. You have the whole night. You can't see all of them. You never can.
@next sat.hub

# sat.hub
> The night is long but not that long. You can make three visits before the first decree.
* Leo, on Halloran Street.  -> sat.leo {once} {if alive:leo&!flag:leoGoneTown&!flag:satVisit3}
* Tariq, at the Lucky Mart.  -> sat.tariq {once} {if alive:tariq&!flag:tariqLeicester&!flag:satVisit3}
* Miller, wherever Miller is.  -> sat.miller {once} {if alive:miller&rel:miller>=1&!flag:satVisit3}
* Gideon, at the Pawn & Coffin.  -> sat.gideon {once} {if alive:gideon&!flag:satVisit3}
* Mother Soot, in the pipes.  -> sat.soot {once} {if alive:soot&!flag:satVisit3}
* Valko, wherever Hounds go on a Saturday.  -> sat.valko {once} {if flag:valkoAlly&!flag:valkoDead&!flag:satVisit3}
* Mrs. Okafor, in 404.  -> sat.okafor {once} {if !flag:okaforDead&flag:met404&!flag:satVisit3}
* The payphone on Ferrier Lane. Robin.  -> sat.robin {once} {if flag:sisterTalked&!flag:satVisit3}
* Séverine. She sent a note: "Come and gloat. I'll allow it."  -> sat.sev {once} {if alive:sev&!flag:massacre&!flag:satVisit3}
* Go back to the study. Enough visits.  -> sat.decree

# sat.count
@gate flag:satVisit2 ? sat.c3 : sat.c2b

# sat.c2b
@gate flag:satVisit1 ? sat.c2 : sat.c1

# sat.c1
{do flag:satVisit1=1}
@next sat.hub

# sat.c2
{do flag:satVisit2=1}
@next sat.hub

# sat.c3
{do flag:satVisit3=1}
> The clock in the Sheriff's study, through the walls of the Ward, strikes three. There's no more time for visiting. There's a desk, and eleven letters, and a pen.
@next sat.decree

// --- Leo ---
# sat.leo
@gate flag:leoEmbraced ? sat.leoK : sat.leoM

# sat.leoM
> Room 3B. He opens the door before you knock. He's in a suit. A bad suit, borrowed, brown, two sizes too big.
leo: I was going to come to you. I was going to come to the Reliquary in a suit and ask for an audience with the Sheriff. I've been practising. "Your Excellency." "Your Darkness." Which one is it?
* "It's just me, Leo."  -> sat.leo1
* "Your Darkness. Obviously."  -> sat.leo2

# sat.leo1
leo: Just you. Okay. Good. Because I don't want to bow. My knees are bad. I've been sitting on your couch all week. My couch. You know what I mean.
@next sat.leo3

# sat.leo2
> He bows. It's terrible. Something in his back clicks.
leo: Your Darkness. Ow. Your Darkness, I think I've done something to my spine.
@next sat.leo3

# sat.leo3
leo: I've got a gig. Tuesday. The Lantern Room. I've written a whole new set. It's about a guy whose best mate becomes the boss of all the vampires and he still has to buy his own milk.
leo: Will you come? You don't have to laugh. Just come.
* "Front row."  -> sat.leo4 {do promise:leogig:Front row at Leo's Tuesday gig}
* "I can't be seen there now, Leo. Not as Sheriff."  -> sat.leo5

# sat.leo4
leo: Front row. FRONT ROW. Okay. I'm going to have to make it good now. I'm going to have to make it actually good.
{do rel:leo+2; comp+2; flag:satLeoGig=1}
@next sat.count

# sat.leo5
> His face does the thing it does when a joke doesn't land. He's good at recovering. He's had practice.
leo: No. No, course. Course. That's fine. I get it. You're... yeah. I'll tell you how it goes.
tenant: That's how it begins, child. That's exactly how it began with me.
{do rel:leo-1; flag:satLeoDistant=1}
@next sat.count

# sat.leoK
> Room 3B. He's sitting in the dark with a blanket over the window and a bag of blood from St. Jude's in a mug that says WORLD'S OKAYEST COMEDIAN.
leo: Rostova gave me a bag. She said not to tell you. She said "for the boy, he's too stupid to hunt." I'm not too stupid to hunt. I'm too polite.
leo: Is it always going to be like this? Hungry, and the light hurts, and Mom keeps ringing and I can hear her heart down the phone?
* "It gets easier. I'll show you."  -> sat.leoK1
* "No. It doesn't get easier. You get stronger."  -> sat.leoK2 {do lean:candour+1}

# sat.leoK1
leo: Okay. Okay. Show me Tuesday. After the gig. I've still got a gig. Dead people can do open mics. I checked.
{do rel:leo+2; flag:satLeoGig=1}
@next sat.count

# sat.leoK2
leo: Stronger. Right. Like a muscle. Like a really sad muscle.
{do rel:leo+1}
@next sat.count

// --- Tariq ---
# sat.tariq
> The Lucky Mart. Every light on. The 2014 calendar back on the wall. A new sign in the window, in Tariq's careful marker: UNDER NEW PROTECTION. NO CHARGE. {if !flag:ownMart}
> The Lucky Mart. Every light on. Behind the counter, the new owner, learning the till. {if flag:ownMart}
@gate flag:ownMart ? sat.tarO : sat.tarT

# sat.tarT
tariq: You. The Sheriff. In my shop. Buying nothing, like always.
tariq: Dale and Pruitt didn't come on Wednesday. Or this Wednesday, I mean, the one coming. They won't come. I know they won't come. My wife says I'm smiling in my sleep.
tariq: There's a coffee. You know where it is.
* Take the coffee. Hold it.  -> sat.tar1
* "Tariq, if anyone ever comes for money again, you tell me first."  -> sat.tar2

# sat.tar1
> You hold it. It's warm. He watches you hold it, the way he always has, and doesn't say anything, and neither do you.
{do rel:tariq+1; comp+2}
@next sat.count

# sat.tar2
tariq: First. Before the police. Before my cousin. Before God. Yes. I'll tell you.
tariq: You know, my father paid protection for nineteen years. He'd laugh. He'd say: Tariq, now you pay protection to a ghost, and it's free.
{do rel:tariq+2}
@next sat.count

# sat.tarO
@gate flag:martLuis ? sat.tarL : sat.tarO2

# sat.tarL
luis: You. You found the door for me. Now I have a counter. I stand behind it all night and I don't have to ride anywhere.
luis: My mother comes in on Sundays and moves everything on the shelves. I let her. It's a good shop. Quiet. In here nobody is a number. They're just buying milk.
{do comp+2}
@next sat.count

# sat.tarO2
> Whoever's behind the counter tonight looks up at you and nods. On the counter, at five o'clock, there'll be a coffee. There always is.
{do comp+1}
@next sat.count

// --- Miller ---
# sat.miller
@gate flag:millerAtVan|flag:harrowArrested ? sat.milW : sat.milH

# sat.milW
> Precinct 3. Not 9. She's in a borrowed office with her feet on the desk and her parka still on and a box of files on the floor, and on top of the box, a jam jar.
miller: I got him. I actually got him. Thomas Harrow, in cuffs, in the back of a Precinct 3 car, saying "please" to the officer who put his head down.
miller: It won't stick. Federal. They'll have him out by Christmas. But for one night I got him, and Ray got to hear it, in a jar, on my desk.
* "It'll stick. I'll make sure the Court has nothing to say for him."  -> sat.mil1
* "One night's enough, sometimes."  -> sat.mil2

# sat.mil1
miller: The Court. Your Court. The vampire court. Testifying for the prosecution.
miller: ...I'm going to need a much bigger notebook.
{do rel:miller+1}
@next sat.count

# sat.mil2
miller: Yeah. Yeah, it is. I'm going to go home and sleep for a week. Then I'm going to get a dog. I'm calling him Ray.
{do rel:miller+1; comp+1}
@next sat.count

# sat.milH
> The Lucky Mart parking lot. Her car, engine running for the heater, laptop on the steering wheel. She doesn't look up.
miller: Sheriff. Congratulations. I suppose.
miller: Harrow's gone. Vanished. His vans were on Ferrier Lane at dawn with the engines cold. The Feds are calling it "a reassignment". I'm calling it "he got away".
* "He didn't get away, Ines. He just got tired."  -> sat.milH1 {if flag:harrowWalked}
* "He'll come back. When he does, we'll both be ready."  -> sat.milH2

# sat.milH1
miller: Tired. Is that what you call it, in your world? Tired?
miller: ...Okay. Okay. Tired I can live with. Tired's almost justice.
{do rel:miller+1}
@next sat.count

# sat.milH2
miller: We. Both. The detective and the Sheriff. That's a terrible buddy cop show.
miller: I'd watch it.
{do rel:miller+1; flag:satMillerPartner=1}
@next sat.count

// --- Gideon ---
# sat.gideon
> The Pawn & Coffin. The green banker's lamp. Gideon at his counter with the ledger open to your page.
gideon: Ah. The Sheriff. Box three's still yours if you want it. I didn't let it. It seemed premature.
gideon: I've filled it in. Your page. Would you like to see?
* "Yes."  -> sat.gid1
* "No. Keep it for after."  -> sat.gid2

# sat.gid1
> He turns the ledger round. Under your name, if he knows it, or a blank if he doesn't, in his best copperplate:
> *Box 3. Monday 28th to Friday. Paid in full.*
> And under that, smaller, in fresher ink: *Never complained about the lid.*
{do rel:gideon+1; comp+2}
@next sat.count

# sat.gid2
gideon: After. Yes. That's sensible. The ledger isn't going anywhere. Neither am I, for a few years yet, if I'm careful about stairs.
{do rel:gideon+1}
@next sat.count

// --- Soot ---
# sat.soot
> The shrine. Two hundred candles. A thousand jars. The rats part for you like a crowd for a bride.
soot: Sheriff. Sheriff, sheriff. Mm. Nobody's ever come down here as Sheriff before. Absalom sent letters. Mm. Polite ones. Never came.
soot: You came. You came on the first night. The rats are very impressed. I'm a little bit impressed. Mm. Don't tell them.
* "Mother. What do the Wraiths want? From me. From the Sheriff."  -> sat.soot1
* "I came to say thank you."  -> sat.soot2

# sat.soot1
soot: Want. Want, want. Nobody asks. Mm.
soot: Light. Not the sun. Candles. Wax is so dear now. And for nobody to gas the pipes. And for somebody to come down, once a month, and listen to a jar.
{do flag:satSootAsk=1; rel:soot+1}
@next sat.count

# sat.soot2
soot: Thank you. Mm. Mm. That's a good jar. That one I'll keep.
{do rel:soot+2; comp+1}
@next sat.count

// --- Valko ---
# sat.valko
> The end of Pier Nine. The cranes. The black water. Valko is sitting on a bollard, watching the sea, with something in his lap: a small iron box.
valko: Rask. The lamp they made from him. Under the platform. I went down at dawn and took it out of the vault with my hands. It burned. I didn't care.
valko: I'm going to put him in the sea. Where the pack runs. Will you stand with me?
* Stand with him.  -> sat.val1
* "Wait. Let me say something for him first."  -> sat.val2

# sat.val1
> He opens the iron box. Inside, a cracked quartz cylinder full of something that isn't quite ash. He tips it into the black water. It glows, very faintly, all the way down, like a lantern going into a well.
> He howls. Once. Long. Every dog in the Marrow Ward answers.
{do rel:valko+2; comp+2}
@next sat.count

# sat.val2
* "Rask. Somebody asked. Finally. Somebody asked what was wrong."  -> sat.val3

# sat.val3
> Valko looks at you. His amber eyes are very wet.
valko: ...Yes. Yes. Somebody asked.
> He tips the box into the sea. It glows all the way down.
{do rel:valko+3; comp+3}
@next sat.count

// --- Okafor ---
# sat.okafor
> 404. Two cups on the table. The radio. The window open, though it's cold, because Dani always liked it open.
okafor: The Sheriff. In my kitchen. With the washing up not done.
@gate flag:daniTold|flag:okaforJar ? sat.oka1 : sat.oka2

# sat.oka1
okafor: I listen to her every night. The jar. "Feed the fish." Every night. I bought a new fish. It's called Danielle. It's very stupid. It swims into the glass.
okafor: Will they be safe now? The other girls? The ones like Dani, who need five hundred dollars?
* "Yes. That's my first law."  -> sat.oka3 {do flag:satOkaforLaw=1}
* "I don't know. I'll try."  -> sat.oka4

# sat.oka2
okafor: Do you know yet? What happened to her? You said you'd find out.
* Tell her. All of it.  -> sat.oka5 {do lean:candour+1}
* "Not yet."  -> sat.oka4

# sat.oka3
okafor: Your first law. For Dani. Write it down. I want it written down, somewhere they keep the laws. With her name.
{do rel:okafor+2; comp+1}
@next sat.count

# sat.oka4
okafor: Try. Yes. That's all anyone does. Dani tried. I try.
{do rel:okafor+1}
@next sat.count

# sat.oka5
> You tell her. The study. The fourth floor. The five hundred dollars. The sun, and twenty-two minutes, and a girl standing in it longer than anyone ever had.
> She listens with her hands round the second cup. When you finish she doesn't cry.
okafor: Twenty-two minutes. In the sun. She always hated being indoors.
{do flag:daniTold=1; rel:okafor+2; comp+2}
@next sat.count

// --- Robin ---
# sat.robin
> The payphone on Ferrier Lane. Fifty cents. Eleven numbers. It picks up before the first ring finishes.
robin: Casey?
* "Rob. It's over. I'm okay. I'm... I've got a job."  -> sat.rob1
* "Rob. I'm coming home tonight. Leave the porch light on."  -> sat.rob2 {if flag:sisterSaturday}

# sat.rob1
robin: A job. A JOB. What kind of job do vampires... no, don't tell me. Is it nights? It's nights, isn't it.
robin: Are you happy? You don't have to be. I just want to know.
* "I don't know yet. Ask me in a year."  -> sat.rob3
* "Yes. A bit."  -> sat.rob3

# sat.rob2
robin: The porch light's been on since Wednesday. I haven't turned it off. Mrs. Tully thinks I've gone mad.
robin: Come home. Come home. I've made the soup. I've got a Sharpie.
{do keep:sisterhome; flag:satRobinHome=1; comp+3}
@next sat.count

# sat.rob3
robin: A year. Okay. I'll ask. I'll write it on the calendar. "Ask Casey if they're happy."
{do comp+2; flag:sisterSunday=1}
@next sat.count

// --- Séverine ---
# sat.sev
> The Gilded Court's private room. One candle. The gramophone, back from the platform, playing Caruso. Séverine in a chair by the fire, with two glasses of something old and red.
severine: Sheriff. Come in. Gloat. I've decided to allow it, once, tonight, and then never again.
* Gloat.  -> sat.sev1 {do lean:pride+1}
* "I didn't come to gloat. I came to ask you to be Keeper. Still. Under me."  -> sat.sev2
* Sit with her. Listen to the record.  -> sat.sev3

# sat.sev1
> You gloat. You're surprisingly good at it. It must be his.
severine: Oh, that's very good. The little tilt of the chin. The "I see." Absalom did that "I see" to me in 1888 and I didn't speak to him for nine years.
{do rel:severine+0; sync+1}
@next sat.count

# sat.sev2
severine: Under you.
> She drinks one of the glasses, which you've never seen her do.
severine: Yes. All right. I'll keep Elysium. I'll keep it beautifully and resentfully and I'll tell everyone it was my idea.
{do flag:satSevKeeper=1; rel:severine+2}
@next sat.count

# sat.sev3
> You sit. Caruso sings. She doesn't say anything. At the end of the side, she gets up and turns the record over and sits down again, and at some point her gloved hand rests on the arm of your chair, just next to yours, not touching.
{do rel:severine+2; comp+2}
@next sat.count

// =====================================================================
// THE FIRST DECREES
// =====================================================================
# sat.decree
> Back in the study. The green lamp. The eleven letters. The pen.
tenant: Three laws, on the first night. That's tradition. I made mine in 1946: no feeding in the Heights, ten percent tithe, and nobody touches my car.
tenant: Make yours better.
@next sat.d1

# sat.d1
> The first law.
* "No Kindred feeds from anyone in a hospital bed. St. Jude's is closed to us."  -> sat.d1a
* "Mortals who know are under the Sheriff's protection. Leo, Miller, Tariq. All of them."  -> sat.d1b
* "Any Kindred who joins a mortal program, LANTERN or otherwise, answers to me."  -> sat.d1c
* "The tithe is gone. Nobody pays the Sheriff for the right to exist."  -> sat.d1d

# sat.d1a
{do flag:law_hospital=1; lean:mercy+1}
@next sat.d2

# sat.d1b
{do flag:law_knowers=1; lean:loyalty+1}
@next sat.d2

# sat.d1c
{do flag:law_lantern=1; lean:pride+1}
@next sat.d2

# sat.d1d
{do flag:law_tithe=1; lean:pride-1}
@next sat.d2

# sat.d2
> The second law.
* "The clanless have a seat at Elysium. With a napkin."  -> sat.d2a {if !flag:unionSeat}
* "No Hound hunts for sport. Not ever again."  -> sat.d2b
* "The Wraiths get candles. And nobody gasses the pipes."  -> sat.d2c
* "Every Kindred in the Ward is counted, voluntarily, and the count is given to nobody."  -> sat.d2d

# sat.d2a
{do flag:unionSeat=1; keep:local0; lean:pride-1}
@next sat.d3

# sat.d2b
{do flag:law_hunt=1; lean:mercy+1}
@next sat.d3

# sat.d2c
{do flag:law_candles=1; rel:soot+1}
@next sat.d3

# sat.d2d
{do flag:law_count=1; lean:restraint+1}
@next sat.d3

# sat.d3
> The third law. The one that's yours.
* "Nobody stands at the back. If you want to see something, go to the front."  -> sat.d3a
* "Say please."  -> sat.d3b
* "Nobody walks into the sun alone. If someone wants to go, someone stands with them."  -> sat.d3c
* "Nobody touches my car." (For him.)  -> sat.d3d

# sat.d3a
tenant: ...That's for me. That one's for me, isn't it.
{do flag:law_front=1; sync+1}
@next sat.end

# sat.d3b
tenant: Please. A law that says please. They'll laugh. Let them. They'll do it.
{do flag:law_please=1}
@next sat.end

# sat.d3c
tenant: Like Ambrose. He stands beside them. He always has. Now everybody will.
{do flag:law_alone=1; lean:mercy+1}
@next sat.end

# sat.d3d
> Something in your blood laughs so hard it hurts.
tenant: Oh, child. Oh, I love you. Write it down. Write it in red.
{do flag:law_car=1; sync+2}
@next sat.end

# sat.end
> You write them down. Three laws, in Absalom Vane's ink, in your own hand, which has got a little like his this week. You blot them. You seal them. You give them to whoever is waiting at the door to give to the Court.
> Then you sit in the Sheriff's chair in the green light with the cup going cold on the blotter, and for about four minutes, which is nobody's business but yours, you're very tired, and very sad, and very glad.
> Then the clock strikes four. There's a Ward out there. It's yours.
{do flag:satDone=1}
@end

// =====================================================================
// SATURDAY · if Absalom came back
// =====================================================================
# sat.ten
> You don't wake up on Saturday. He does.
> Absalom Vane sits up in his own coffin, in his own room behind the ossuary, and looks at his own hands for a long time. They're your hands. They'll always be your hands now.
tenant: (in his own voice, out loud, for the first time) ...Well.
> And somewhere very far back, behind his eyes, in the study with the brown rug, in the visitor's chair, you watch.
tenant: Are you there, child? Can you hear me?
* "I'm here."  -> sat.ten1
* Say nothing. Let him have it.  -> sat.ten2

# sat.ten1
tenant: Good. Good. I'll keep the chair warm for you. When you want it, it's yours. I mean that. I've never meant anything more.
tenant: First, though, I have a call to make. A detective. A doctor. A boy with a cactus. They should hear it from me.
{do sync+2}
@next sat.ten3

# sat.ten2
tenant: Silent. Yes. Rest. You've earned it more than I have.
@next sat.ten3

# sat.ten3
> He goes out into the Ward in your body, in his coat. You watch through his eyes as he goes to the Lucky Mart and buys a root beer and doesn't drink it. As he goes to the Rookery and knocks on 3B and Leo opens it and says "you look different" and Absalom says "yes, I'm afraid I do." As he goes to the Heights, to Row J, plot 112, and kneels in the wet grass in front of a stone that says AGNES DUNMORE, 1904–1961, and stays there until the sky goes grey.
> He doesn't stand at the back. Not once. Not all night.
tenant: I went to the front. Do you see? I went to the front.
{do flag:satDone=1; flag:tenantFront=1}
@end
`,'c_saturday');

NL.Act.extraFates.push(S=>{const f=S.flags,o=[];if(!f.satDone)return o;
  const L=[];
  if(f.law_hospital)L.push('no Kindred feeds in a hospital');if(f.law_knowers)L.push('the mortals who know are under the Sheriff\'s protection');if(f.law_lantern)L.push('anyone who works with LANTERN answers to the Sheriff');if(f.law_tithe)L.push('there is no tithe');
  if(f.unionSeat&&!f.law_hospital&&!f.law_knowers&&!f.law_lantern&&!f.law_tithe)L.push('the clanless sit at Elysium');
  if(f.law_hunt)L.push('no Hound hunts for sport');if(f.law_candles)L.push('the Wraiths get candles and the pipes are never gassed');if(f.law_count)L.push('the Ward counts itself and tells no one');
  if(f.law_front)L.push('nobody stands at the back');if(f.law_please)L.push('say please');if(f.law_alone)L.push('nobody walks into the sun alone');if(f.law_car)L.push('nobody touches the Sheriff\'s car');
  if(L.length)o.push(['The laws of the Marrow Ward','Your first three, written on Saturday night in Absalom Vane\'s ink: '+L.join('; ')+'. The Court laughed at the last one. They obey it anyway.']);
  if(f.satLeoGig&&!f.leoDead)o.push(['Tuesday, the Lantern Room','The Sheriff of the Marrow Ward sat in the front row of an open mic in a pub basement and laughed at a joke about milk. Nine people saw it. One of them was Leo. He says it was the best night of his life.']);
  if(f.satLeoDistant)o.push(['Tuesday, the Lantern Room','You didn\'t go. Leo told you it went fine. It didn\'t. He tells you everything is fine now.']);
  if(f.satRobinHome)o.push(['Harbour Row, Saturday','The porch light was on. You came home.']);
  if(f.satSevKeeper)o.push(['Elysium','Kept, beautifully and resentfully, by Séverine, who tells everyone it was her idea.']);
  if(f.tenantFront)o.push(['Row J, plot 112','On Saturday night a tall man in dark glasses knelt in the wet grass in front of Agnes Dunmore\'s stone until the sky went grey. He didn\'t stand at the back. Not once.']);
  return o;});
