#!/usr/bin/env bash
# Full screen, orientation, keep the screen awake. Run after "npx cap add android".
set -e
ORIENTATION="${ORIENTATION:-fullSensor}"
M=android/app/src/main/AndroidManifest.xml
sed -i "s/<activity /<activity android:screenOrientation=\"${ORIENTATION}\" /" $M
S=android/app/src/main/res/values/styles.xml
sed -i 's#<item name="windowNoTitle">true</item>#<item name="windowNoTitle">true</item><item name="android:windowFullscreen">true</item><item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>#g' $S
J=$(find android/app/src/main/java -name MainActivity.java)
cat > "$J" <<'JAVA'
package com.thenewlord.game;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); hide(); }
  @Override public void onWindowFocusChanged(boolean f){ super.onWindowFocusChanged(f); if(f) hide(); }
  private void hide(){ getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN); }
}
JAVA
echo "Android project patched: orientation=${ORIENTATION}, full screen, screen kept awake"
